"""Profile exact timed Luhn binaries; collect no wall-time benchmark samples."""

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

CACHE = Path("/home/dev-user/.cache/relar/profiling-tools/root/usr")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def argument(command, flag):
    require(command.count(flag) == 1, f"expected exactly one {flag}")
    return Path(command[command.index(flag) + 1]).resolve(strict=True)


def callgrind_metrics(path):
    """Separate self instruction costs from outgoing inclusive call edges."""
    lines = path.read_text().splitlines()
    require(lines.count("positions: instr line") == 1 and lines.count("events: Ir") == 1,
            "unexpected Callgrind position/event layout")
    totals = [int(line.split()[1]) for line in lines if line.startswith("summary:")]
    require(len(totals) == 1 and totals[0] > 0, "expected one complete Callgrind part")
    names = {}
    for line in lines:
        match = re.fullmatch(r"c?fn=\((\d+)\) (.+)", line)
        if match:
            require(match[1] not in names or names[match[1]] == match[2], "function ID changed")
            names[match[1]] = match[2]
    costs, calls, inclusive = Counter(), Counter(), Counter()
    function = callee = None
    call_edge = False
    for line in lines:
        match = re.fullmatch(r"(c?fn)=\((\d+)\)(?: .+)?", line)
        if match:
            if match[1] == "fn":
                function, call_edge = names[match[2]], False
            else:
                callee = names[match[2]]
            continue
        if line.startswith("calls="):
            require(callee is not None, "call edge has no callee")
            calls[callee] += int(line.split()[0].split("=")[1])
            call_edge = True
            continue
        match = re.fullmatch(r"(?:0x[0-9a-f]+|[+-]\d+|\*|\d+)\s+(?:[+-]?\d+|\*)\s*(\d*)", line)
        if match:
            cost = int(match[1] or 0)
            if call_edge:
                inclusive[callee] += cost
                call_edge = False
            else:
                require(function is not None, "instruction cost has no function")
                costs[function] += cost
    require(sum(costs.values()) == totals[0], "self costs do not sum to process instructions")
    return {
        "instructions": totals[0],
        "self_cost_sum": sum(costs.values()),
        "functions": [
            {"name": name, "self_instructions": value, "self_fraction": value / totals[0],
             "calls": calls[name], "incoming_inclusive_instructions": inclusive[name]}
            for name, value in costs.most_common()
        ],
        "inclusive_note": "Incoming call-edge costs include descendants and overlap across nesting; do not sum them.",
    }


def dhat_metrics(path):
    heap = json.loads(path.read_text())
    require(heap["mode"] == "heap" and heap["tu"] == "instrs", "unexpected DHAT profile")
    points = heap["pps"]
    return {
        "allocated_bytes": sum(point["tb"] for point in points),
        "allocated_blocks": sum(point["tbk"] for point in points),
        # gb/gbk contribute at the same global peak, unlike independent maxima.
        "peak_live_bytes": sum(point["gb"] for point in points),
        "peak_live_blocks": sum(point["gbk"] for point in points),
        "exit_live_bytes": sum(point["eb"] for point in points),
        "exit_live_blocks": sum(point["ebk"] for point in points),
        "top_allocation_stacks": [
            {"bytes": point["tb"], "blocks": point["tbk"],
             "frames": [heap["ftbl"][index] for index in point["fs"]]}
            for point in sorted(points, key=lambda point: point["tb"], reverse=True)[:12]
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--record", type=Path, required=True, help="completed normal or ThinLTO benchmark JSON")
    parser.add_argument("--relar-build-record", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="fresh directory outside the repository")
    parser.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/relar"))
    parser.add_argument("--timing-status", type=Path,
                        default=Path("/tmp/relar-luhn-performance-v1-timing-status.json"))
    parser.add_argument("--label", required=True)
    parser.add_argument("--digits", type=int, required=True)
    parser.add_argument("--repetitions", type=int, required=True)
    parser.add_argument("--timeout", type=float, default=600)
    parser.add_argument("--valgrind", type=Path, default=CACHE / "bin/valgrind")
    parser.add_argument("--valgrind-lib", type=Path, default=CACHE / "libexec/valgrind")
    parser.add_argument("--annotate", type=Path, default=CACHE / "bin/callgrind_annotate")
    args = parser.parse_args()
    require(args.digits > 0 and args.repetitions > 0 and args.timeout > 0,
            "digits, repetitions, and timeout must be positive")
    require(args.label == f"checksum-{args.digits}", "label must identify the requested checksum size")
    tracer = int(next(line.split(":")[1] for line in Path("/proc/self/status").read_text().splitlines()
                      if line.startswith("TracerPid:")))
    require(tracer == 0, "run final Valgrind profiling outside the ptrace sandbox")
    root, record_path = args.root.resolve(strict=True), args.record.resolve(strict=True)
    record = json.loads(record_path.read_text())
    timing_path = args.timing_status.resolve(strict=True)
    timing = json.loads(timing_path.read_text())
    require(timing["status"] == "passed" and timing["input_guards_passed"]
            and timing["source_unchanged"] and len(timing["runs"]) == 2
            and {run["mode"] for run in timing["runs"]} == {"normal", "thinlto"}
            and all(run["returncode"] == 0 for run in timing["runs"]),
            "both benchmark families must finish successfully before profiling")
    require(record.get("input_guards_passed") is True and record.get("dirty") is False,
            "benchmark must be complete and committed")
    require(type(record.get("thinlto")) is bool, "benchmark linkage mode is missing")
    binaries = {
        "relar": argument(record["compile_command"], "-o"),
        "rust": argument(record["validation_command"], "--rust"),
    }
    llvm = argument(record["compile_command"], "--emit-llvm")
    rust_record_path = binaries["rust"].parent / "build-record.json"
    build_path = args.relar_build_record.resolve(strict=True)
    rust_record, build = json.loads(rust_record_path.read_text()), json.loads(build_path.read_text())
    hashes = record["source_and_tool_sha256"]
    require(sha(binaries["relar"]) == record["binary_sha256"] and sha(llvm) == record["llvm_sha256"],
            "native binary or emitted LLVM changed")
    require(sha(binaries["rust"]) == hashes["rust"] == rust_record["binary_sha256"],
            "Rust binary does not match timing and build records")
    require(sha(rust_record_path) == hashes["rust_build_record"] and rust_record == record["rust_build_record"],
            "Rust build record changed")
    require(sha(build_path) == hashes["relar_build_record"] and build == record["relar_build_record"],
            "Relar build record changed")
    require(build["source_matches_revision"] is True, "Relar build source was not committed")
    validation_index_path = build_path.parent / "index.json"
    validation_index = json.loads(validation_index_path.read_text())
    require(validation_index["status"] == "passed" and validation_index["input_guards_passed"]
            and validation_index["source_unchanged"]
            and validation_index["revision"] == build["revision"]
            and validation_index["build_record"]["sha256"] == sha(build_path),
            "the complete frozen validation matrix does not match the build")
    revision = validation_index["revision"]
    require(record["revision"] == build["revision"] == timing["head"] == revision
            and all(timing[key] == revision for key in
                    ("build_revision", "validation_revision", "timing_revision")),
            "final validation, build, and timing must use one frozen revision")
    changes, patch = [], ""
    require(all(timing["post_validation_changes"][key] == value for key, value in
                {"paths": changes, "patch": patch, "patch_sha256": digest(b"")}.items()),
            "final evidence must have no post-validation source changes")
    mode = "thinlto" if record["thinlto"] else "normal"
    timing_run, = [run for run in timing["runs"] if run["mode"] == mode]
    require(timing_run["record_sha256"] == sha(record_path)
            and argument(timing_run["command"], "--output") == record_path,
            "profile record is not the completed timed record")
    require(sha(timing["protected_paths"]["build_record"]) == sha(build_path)
            and sha(timing["protected_paths"]["validation_index"]) == sha(validation_index_path),
            "timing used another validated build")
    require(rust_record["thinlto"] == record["thinlto"] and rust_record["input_guards_passed"],
            "Rust and Relar linkage modes differ")
    validation_path = argument(record["validation_command"], "--output")
    require(json.loads(validation_path.read_text()) == record["validation"], "validation record changed")
    require(record["validation"]["relar"]["binary_sha256"] == record["binary_sha256"]
            and record["validation"]["rust"]["binary_sha256"] == hashes["rust"],
            "validation is for different binaries")
    baseline_path = Path(timing["protected_paths"][mode + "_baseline"]).resolve(strict=True)
    baseline_record_path = Path(timing["protected_paths"][mode + "_baseline_record"]).resolve(strict=True)
    baseline_validation_path = argument(record["baseline_validation_command"], "--output")
    baseline = json.loads(baseline_record_path.read_text())
    require(baseline == record["baseline_record"] and baseline["input_guards_passed"]
            and baseline["dirty"] is False and baseline["thinlto"] == record["thinlto"]
            and sha(baseline_path) == hashes["baseline"] == baseline["binary_sha256"]
            == record["baseline_provenance"]["binary_sha256"]
            and sha(baseline_record_path) == hashes["baseline_record"]
            == record["baseline_provenance"]["record_sha256"],
            "preserved baseline provenance changed")
    require(argument(record["baseline_validation_command"], "--binary") == baseline_path
            and json.loads(baseline_validation_path.read_text()) == record["baseline_validation"]
            and record["baseline_validation"]["relar"]["binary_sha256"] == hashes["baseline"],
            "fresh baseline validation differs")
    inputs = {
        "compiler": Path(record["compile_command"][0]), "runtime": argument(record["compile_command"], "--runtime"),
        "clang": argument(record["compile_command"], "--clang"), "python": Path(record["validation_command"][0]),
        "rust": binaries["rust"], "rust_build_record": rust_record_path, "relar_build_record": build_path,
        "harness": root / "benchmarks/luhn_benchmark.py", "validator": root / "benchmarks/luhn_validate.py",
        "shared_harness": root / "benchmarks/benchmark.py", "shared_validator": root / "benchmarks/validate.py",
        "baseline": baseline_path, "baseline_record": baseline_record_path,
    }
    if record["thinlto"]:
        inputs["lto_linker"] = argument(record["compile_command"], "--lto-linker")
    prefixes = {"example:": root / "examples/luhn_checksum",
                "rust_source:": root / "benchmarks/reference/luhn_checksum", "relar_source:": root}
    for name in hashes:
        for prefix, directory in prefixes.items():
            if name.startswith(prefix):
                inputs[name] = directory / name.removeprefix(prefix)
    require(set(inputs) == set(hashes), "unrecognized or missing timed provenance input")
    require({name: sha(path) for name, path in inputs.items()} == hashes, "timed source/tool inputs changed")
    require(hashes["compiler"] == build["sha256"]["compiler"]
            and hashes["runtime"] == build["sha256"][mode + "_runtime"],
            "timed compiler/runtime differ from the frozen build")
    workload, = [item for item in record["workloads"] if item["label"] == args.label]
    previous_workload, = [item for item in baseline["workloads"] if item["label"] == args.label]
    require(all(workload[key] == previous_workload[key] for key in
                ("operation", "digits", "input_base64", "input_sha256",
                 "expected_output_base64", "expected_output_sha256")),
            "profile workload differs from the preserved baseline")
    payload = base64.b64decode(workload["input_base64"], validate=True)
    require(workload["operation"] == "checksum" and len(payload) == workload["digits"] == args.digits,
            "profile requires a nonempty checksum workload")
    require(all(48 <= byte <= 57 for byte in payload), "profile requires ASCII decimal digits")
    require(digest(payload) == workload["input_sha256"], "input digest mismatch")
    # Independent ASCII arithmetic checks the exact scalar result and batch sum.
    total = 0
    for index, byte in enumerate(reversed(payload)):
        digit = byte - 48
        weighted = digit * (2 if index % 2 else 1)
        total += weighted - (9 if weighted > 9 else 0)
    checksum = total % 10
    expected = str(checksum).encode()
    require(expected == base64.b64decode(workload["expected_output_base64"], validate=True)
            and digest(expected) == workload["expected_output_sha256"], "independent checksum disagrees")
    require(workload["expected_stdout"] == f"OK\n{checksum * workload['repetitions']}\n",
            "timed accumulated checksum disagrees")
    expected_stdout = f"OK\n{checksum * args.repetitions}\n".encode()
    require({engine for order in record["engine_orders"] for engine in order}
            == {"relar", "rust", "baseline", "cpython"}, "expected four timed engines")
    for engine in ("relar", "rust", "baseline", "cpython"):
        source, output = binaries["relar"].parent / args.label / engine / "input.bin", binaries["relar"].parent / args.label / engine / "output.bin"
        require(source.read_bytes() == payload and output.read_bytes() == expected, "retained timed I/O changed")
        inputs[f"timed_{engine}_input"], inputs[f"timed_{engine}_output"] = source, output
    library = args.valgrind_lib.resolve(strict=True)
    tools = {
        "valgrind": args.valgrind.resolve(strict=True), "annotate": args.annotate.resolve(strict=True),
        "valgrind_binary": args.valgrind.parent.resolve(strict=True) / "valgrind.bin",
        "callgrind": library / "callgrind-amd64-linux", "dhat": library / "dhat-amd64-linux",
        "core_preload": library / "vgpreload_core-amd64-linux.so",
        "dhat_preload": library / "vgpreload_dhat-amd64-linux.so",
        "perl": Path("/usr/bin/perl").resolve(strict=True), "shell": Path("/bin/sh").resolve(strict=True),
        "runner_python": Path(sys.executable).resolve(strict=True),
    }
    inputs.update({f"tool_{name}": path for name, path in tools.items()})
    inputs.update(benchmark_record=record_path, native_llvm=llvm, native_binary=binaries["relar"],
                  validation_matrix=validation_index_path,
                  validation=validation_path, baseline_validation=baseline_validation_path,
                  timing_status=timing_path, profiler=Path(__file__).resolve(strict=True))
    guarded = {name: {"path": str(path), "sha256": sha(path)} for name, path in inputs.items()}

    def guard():
        require(all(sha(inputs[name]) == value["sha256"] for name, value in guarded.items()), "guarded input changed")
        git_env = {**os.environ, "GIT_OPTIONAL_LOCKS": "0"}
        require(subprocess.check_output(["git", "-C", root, "rev-parse", "HEAD"], env=git_env).decode().strip() == record["revision"],
                "source revision changed")
        require(not subprocess.check_output(["git", "-C", root, "status", "--porcelain"], env=git_env), "source tree is dirty")

    guard()
    affinity = record["cpu"]["affinity"]
    require(len(affinity) == 1 and affinity[0] in os.sched_getaffinity(0), "timed CPU is unavailable")
    os.sched_setaffinity(0, set(affinity))
    destination = args.output.resolve()
    require(destination != root and root not in destination.parents, "profile output must be outside repository")
    destination.mkdir(parents=True, exist_ok=False)
    for name, path in {"benchmark-record.json": record_path, "relar-build-record.json": build_path,
                       "rust-build-record.json": rust_record_path, "validation.json": validation_path,
                       "native.ll": llvm, "profiler.py": Path(__file__),
                       "validation-index.json": validation_index_path,
                       "timing-status.json": timing_path, "baseline-record.json": baseline_record_path,
                       "baseline-validation.json": baseline_validation_path}.items():
        shutil.copyfile(path, destination / name)
        require(sha(destination / name) == sha(path), "snapshot copy mismatch")
    snapshots = {path.name: sha(path) for path in destination.iterdir()}
    environment = {"VALGRIND_LIB": str(library), "VALGRIND_OPTS": "", "LC_ALL": "C"}
    env = {**os.environ, **environment}
    result = {
        "schema": 1, "status": "running", "complete": False, "input_guards_passed": False,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "revision": record["revision"], "thinlto": record["thinlto"], "label": args.label,
        "timing_revision": record["revision"], "build_revision": build["revision"],
        "validation_revision": validation_index["revision"],
        "post_validation_changes": {"paths": changes, "patch": patch,
                                    "patch_sha256": digest(patch.encode())},
        "digits": len(payload), "repetitions": args.repetitions, "digits_per_process": len(payload) * args.repetitions,
        "expected_stdout": expected_stdout.decode(), "expected_output_hex": expected.hex(),
        "checksum_per_call": checksum, "snapshot_sha256": snapshots,
        "benchmark_record_sha256": sha(record_path), "guarded_inputs": guarded,
        "timing_status_sha256": sha(timing_path),
        "baseline_provenance": record["baseline_provenance"],
        "cpu_affinity": affinity, "environment": environment, "profiles": [],
        "method": "Four separate whole-process profiles of the exact timed native binaries: Callgrind and DHAT for Relar and Rust. Includes process startup, input decoding, algorithm calls, accumulated checksum, and file I/O. Identical input and repetition counts; complete output and accumulated checksum checked after every run.",
        "instruction_measurement": "Callgrind guest instructions (Ir), not CPU cycles, CPU time, or wall-time speedup. Self costs partition total instructions; inclusive costs overlap.",
        "allocation_measurement": "DHAT requested heap bytes/blocks, not RSS. Peak totals use contributions at the same global peak. Exit-live values alone do not establish leaks.",
    }
    write_json(destination / "summary.json", result)
    try:
        for engine, binary in binaries.items():
            for tool in ("callgrind", "dhat"):
                guard()
                directory = destination / f"{engine}-{tool}"
                directory.mkdir()
                source, output = directory / "input.bin", directory / "output.bin"
                source.write_bytes(payload)
                output.write_bytes(b"unchanged output")
                profile = directory / ("profile.callgrind" if tool == "callgrind" else "profile.json")
                command = [str(tools["valgrind"]), f"--tool={tool}", "--command-line-only=yes",
                           "--num-callers=32", "--error-exitcode=97", f"--log-file={directory / 'valgrind.log'}",
                           f"--{tool}-out-file={profile}"]
                if tool == "callgrind":
                    command += ["--dump-instr=yes", "--collect-jumps=yes"]
                command += [str(binary), "checksum", str(source), str(output), str(args.repetitions)]
                item = {"engine": engine, "tool": tool, "command": command, "cwd": str(directory),
                        "environment": environment, "input_sha256": digest(payload), "binary_sha256": sha(binary),
                        "started_at_utc": datetime.now(timezone.utc).isoformat()}
                write_json(directory / "command.json", item)
                process = subprocess.run(command, input=b"", capture_output=True, cwd=directory, env=env,
                                         timeout=args.timeout, check=False)
                (directory / "stdout.txt").write_bytes(process.stdout)
                (directory / "stderr.txt").write_bytes(process.stderr)
                item.update(returncode=process.returncode, completed_at_utc=datetime.now(timezone.utc).isoformat())
                write_json(directory / "command.json", item)
                require(process.returncode == 0 and not process.stderr, f"{engine}/{tool} process failed")
                require(process.stdout == expected_stdout and output.read_bytes() == expected,
                        f"{engine}/{tool} output or accumulated checksum differs")
                require(source.read_bytes() == payload, "profile input changed")
                item["metrics"] = callgrind_metrics(profile) if tool == "callgrind" else dhat_metrics(profile)
                if tool == "callgrind":
                    item["annotations"] = []
                    for inclusive in ("no", "yes"):
                        command = [str(tools["annotate"]), "--auto=no", f"--inclusive={inclusive}", "--threshold=100", str(profile)]
                        annotation = subprocess.run(command, capture_output=True, cwd=directory, env=env,
                                                    timeout=args.timeout, check=False)
                        (directory / f"inclusive-{inclusive}.txt").write_bytes(annotation.stdout)
                        (directory / f"inclusive-{inclusive}-stderr.txt").write_bytes(annotation.stderr)
                        require(annotation.returncode == 0, "annotation failed")
                        item["annotations"].append({"command": command, "returncode": annotation.returncode,
                                                    "stdout_sha256": digest(annotation.stdout), "stderr_sha256": digest(annotation.stderr)})
                item["status"] = "validated"
                item["files"] = {path.name: sha(path) for path in sorted(directory.iterdir()) if path.is_file()}
                result["profiles"].append(item)
                guard()
                write_json(destination / "summary.json", result)
                print(f"Validated {engine}/{tool}", flush=True)
        require(len(result["profiles"]) == 4, "profile matrix incomplete")
        for item in result["profiles"]:
            for name, expected_hash in item["files"].items():
                require(sha(destination / f"{item['engine']}-{item['tool']}" / name) == expected_hash,
                        "retained profile artifact changed")
        require(all(sha(destination / name) == value for name, value in snapshots.items()), "retained snapshot changed")
        guard()
        result.update(status="passed", complete=True, input_guards_passed=True,
                      completed_at_utc=datetime.now(timezone.utc).isoformat())
        write_json(destination / "summary.json", result)
        write_json(destination / "manifest.json", {str(path.relative_to(destination)): sha(path)
                   for path in sorted(destination.rglob("*")) if path.is_file()})
    except BaseException as error:
        result.update(status="failed", failure=f"{type(error).__name__}: {error}")
        write_json(destination / "summary.json", result)
        raise
    print(destination / "summary.json", flush=True)


if __name__ == "__main__":
    main()
