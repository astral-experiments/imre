"""Independently verify retained Luhn profiles without running measured programs."""

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shlex
import subprocess


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def value(command, flag):
    require(command.count(flag) == 1, f"expected one {flag}")
    return command[command.index(flag) + 1]


def number(value):
    return int(value.replace(",", ""))


def callgrind(path, command, summary, directory):
    """Partition cost rows by explicit calls= successor rows, independently."""
    lines = path.read_text().splitlines()
    require(lines.count("positions: instr line") == 1
            and lines.count("events: Ir") == 1, "unexpected Callgrind layout")
    require([line for line in lines if line.startswith("part:")] == ["part: 1"],
            "expected a single complete Callgrind part")
    require(shlex.split(next(line[4:] for line in lines if line.startswith("cmd:"))) == command,
            "Callgrind command differs from the recorded process")
    totals = [int(line.split()[1]) for line in lines if line.startswith(("summary:", "totals:"))]
    require(len(totals) == 2 and totals[0] == totals[1] > 0, "Callgrind summary/footer differ")
    identifiers = {}
    for line in lines:
        if line.startswith(("fn=(", "cfn=(")):
            identifier, _, name = line.partition(") ")
            if name:
                key = identifier.split("(", 1)[1]
                require(key not in identifiers or identifiers[key] == name, "function ID changed")
                identifiers[key] = name
    self_costs, call_counts, incoming = Counter(), Counter(), Counter()
    function = callee = None
    call_rows = {}
    cost_rows = 0
    for index, line in enumerate(lines):
        if line.startswith("fn=("):
            function = line.split("(", 1)[1].split(")", 1)[0]
        elif line.startswith("cfn=("):
            callee = line.split("(", 1)[1].split(")", 1)[0]
        elif line.startswith("calls="):
            require(callee is not None and index + 1 < len(lines), "incomplete call edge")
            call_rows[index + 1] = callee
            call_counts[identifiers[callee]] += int(line.split()[0][6:])
        columns = line.split()
        if not columns or not re.fullmatch(r"(?:0x[0-9a-f]+|[+-]?\d+|\*)", columns[0]):
            continue
        require(len(columns) in (2, 3) and function in identifiers
                and re.fullmatch(r"(?:[+-]?\d+|\*)", columns[1]),
                f"unrecognized Callgrind cost row: {line}")
        cost = int(columns[2]) if len(columns) == 3 else 0
        require(cost >= 0, "negative instruction count")
        cost_rows += 1
        if index in call_rows:
            incoming[identifiers[call_rows[index]]] += cost
        else:
            self_costs[identifiers[function]] += cost
    require(sum(self_costs.values()) == totals[0] == summary["instructions"]
            == summary["self_cost_sum"], "self instruction partition does not reconcile")
    require(len({item["name"] for item in summary["functions"]}) == len(summary["functions"]),
            "duplicate summarized function names")
    reported = {item["name"]: item for item in summary["functions"]}
    require(set(reported) == set(self_costs), "function coverage differs")
    for name, cost in self_costs.items():
        item = reported[name]
        require(item["self_instructions"] == cost and item["calls"] == call_counts[name]
                and item["incoming_inclusive_instructions"] == incoming[name]
                and math.isclose(item["self_fraction"], cost / totals[0], abs_tol=1e-15),
                f"function cost mismatch: {name}")
    log = (directory / "valgrind.log").read_text()
    require(int(re.search(r"Collected\s*:\s*(\d+)", log)[1]) == totals[0]
            and number(re.search(r"I\s+refs:\s*([\d,]+)", log)[1]) == totals[0],
            "Callgrind log total differs")
    for mode in ("no", "yes"):
        annotation = (directory / f"inclusive-{mode}.txt").read_text()
        match = re.search(r"^\s*([\d,]+)\s+\(100\.0%\)\s+PROGRAM TOTALS$", annotation, re.M)
        require(match and number(match[1]) == totals[0], "annotation program total differs")
    return {
        "instructions": totals[0], "self_cost_sum": sum(self_costs.values()),
        "cost_rows": cost_rows, "call_edges": len(call_rows),
        "function_names": len(self_costs),
        "summary_footer_log_and_annotations_agree": True,
        "all_function_self_and_call_edge_metrics_agree": True,
        "top_self_functions": [
            {"name": name, "instructions": count}
            for name, count in self_costs.most_common(10)
        ],
    }


def dhat(path, command, summary, directory):
    heap = read_json(path)
    require(heap["dhatFileVersion"] == 2 and heap["mode"] == "heap"
            and heap["tu"] == "instrs" and 0 <= heap["tg"] <= heap["te"],
            "unexpected DHAT schema or global-peak timestamp")
    require(shlex.split(heap["cmd"]) == command, "DHAT command differs")
    fields = {
        "allocated_bytes": "tb", "allocated_blocks": "tbk",
        "peak_live_bytes": "gb", "peak_live_blocks": "gbk",
        "exit_live_bytes": "eb", "exit_live_blocks": "ebk",
    }
    points, frames = heap["pps"], heap["ftbl"]
    for point in points:
        require(all(type(point[key]) is int and point[key] >= 0 for key in fields.values()),
                "invalid DHAT counter")
        require(point["tb"] >= max(point["gb"], point["eb"])
                and point["tbk"] >= max(point["gbk"], point["ebk"]),
                "DHAT live contributions exceed cumulative allocations")
        require(all(0 <= frame < len(frames) for frame in point["fs"]), "invalid frame index")
    totals = {name: sum(point[field] for point in points) for name, field in fields.items()}
    require(all(summary[name] == total for name, total in totals.items()), "DHAT summary differs")
    log = (directory / "valgrind.log").read_text()
    for label, byte_key, block_key in (
        ("Total", "allocated_bytes", "allocated_blocks"),
        ("At t-gmax", "peak_live_bytes", "peak_live_blocks"),
        ("At t-end", "exit_live_bytes", "exit_live_blocks"),
    ):
        match = re.search(rf"{re.escape(label)}:\s*([\d,]+) bytes in ([\d,]+) blocks", log)
        require(match and number(match[1]) == totals[byte_key]
                and number(match[2]) == totals[block_key], f"DHAT log differs: {label}")
    for label, field in (("Reads", "rb"), ("Writes", "wb")):
        match = re.search(rf"{label}:\s*([\d,]+) bytes", log)
        require(match and number(match[1]) == sum(point[field] for point in points),
                f"DHAT {label.lower()} differ")
    stacks = [
        {"bytes": point["tb"], "blocks": point["tbk"],
         "frames": [frames[index] for index in point["fs"]]}
        for point in sorted(points, key=lambda point: point["tb"], reverse=True)[:12]
    ]
    require(stacks == summary["top_allocation_stacks"], "DHAT top allocation stacks differ")
    return {
        **totals, "allocation_sites": len(points), "stack_frames": len(frames),
        "global_peak_instruction": heap["tg"], "process_end_instruction": heap["te"],
        "global_peak_uses_gb_gbk_and_matches_log": True,
        "summary_and_allocation_stacks_agree": True,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile-dir", type=Path, required=True)
    parser.add_argument("--timing-prefix", type=Path, default=Path("/tmp/relar-luhn-performance-v1"))
    parser.add_argument("--validation-index", type=Path,
                        default=Path("/tmp/relar-luhn-performance-validation-v1/index.json"))
    parser.add_argument("--label", required=True)
    parser.add_argument("--digits", type=int, required=True)
    parser.add_argument("--repetitions", type=int, required=True)
    parser.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/relar"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(args.digits > 0 and args.repetitions > 0
            and args.label == f"checksum-{args.digits}", "invalid requested checksum workload")
    directory = args.profile_dir.resolve(strict=True)
    require(not args.output.exists() and not args.output.resolve().is_relative_to(directory),
            "audit output must be a fresh file outside the profile evidence")
    summary_path, manifest_path = directory / "summary.json", directory / "manifest.json"
    summary, manifest = read_json(summary_path), read_json(manifest_path)
    require(summary["status"] == "passed" and summary["complete"] and summary["input_guards_passed"],
            "profile is incomplete")
    require(summary["thinlto"] and summary["label"] == args.label
            and summary["digits"] == args.digits and summary["repetitions"] == args.repetitions
            and summary["digits_per_process"] == args.digits * args.repetitions,
            "unexpected profile workload")
    require(not any(path.is_symlink() for path in directory.rglob("*")),
            "profile evidence must not contain symlinks")
    files = {path.relative_to(directory).as_posix(): path
             for path in directory.rglob("*") if path.is_file() and path != manifest_path}
    require(set(files) == set(manifest), "profile manifest does not cover exactly every file")
    for name, path in files.items():
        require(not path.is_symlink() and sha(path) == manifest[name], f"manifest mismatch: {name}")
    require(all(sha(directory / name) == expected for name, expected in summary["snapshot_sha256"].items()),
            "profile snapshot mismatch")
    guarded_before = {name: sha(value["path"]) for name, value in summary["guarded_inputs"].items()}
    require(guarded_before == {name: value["sha256"] for name, value in summary["guarded_inputs"].items()},
            "guarded profile input changed")

    benchmark = read_json(directory / "benchmark-record.json")
    build = read_json(directory / "relar-build-record.json")
    rust_build = read_json(directory / "rust-build-record.json")
    validation_index = read_json(directory / "validation-index.json")
    timing_status_path = Path(str(args.timing_prefix) + "-timing-status.json")
    timing_status = read_json(timing_status_path)
    timing_path = Path(str(args.timing_prefix) + "-thinlto.json")
    require(timing_status["status"] == "passed" and timing_status["input_guards_passed"]
            and timing_status["source_unchanged"] and len(timing_status["runs"]) == 2
            and {run["mode"] for run in timing_status["runs"]} == {"normal", "thinlto"}
            and all(run["returncode"] == 0 for run in timing_status["runs"])
            and benchmark["input_guards_passed"]
            and not benchmark["dirty"] and sha(timing_path) == summary["benchmark_record_sha256"]
            == sha(directory / "benchmark-record.json"), "profile used another timing record")
    require(sha(args.validation_index) == sha(directory / "validation-index.json")
            and sha(timing_status_path) == summary["timing_status_sha256"]
            == sha(directory / "timing-status.json"),
            "validation or timing status snapshot differs")
    revision = read_json(args.validation_index)["revision"]
    require(summary["revision"] == summary["timing_revision"] == benchmark["revision"]
            == timing_status["head"] == revision
            and summary["build_revision"] == summary["validation_revision"] == build["revision"]
            == validation_index["revision"] == revision
            and all(timing_status[key] == revision for key in
                    ("build_revision", "validation_revision", "timing_revision")),
            "final build, validation, and timing revisions differ")
    require(validation_index["status"] == "passed" and validation_index["input_guards_passed"]
            and validation_index["source_unchanged"] and build["source_matches_revision"]
            and build["input_guards_passed"], "validation or build did not pass")
    require(benchmark["relar_build_record"] == build and benchmark["rust_build_record"] == rust_build
            and read_json(directory / "validation.json") == benchmark["validation"],
            "build or correctness snapshot differs")
    empty_changes = {"paths": [], "patch": "", "patch_sha256": hashlib.sha256(b"").hexdigest()}
    require(summary["post_validation_changes"] == empty_changes
            and all(timing_status["post_validation_changes"][key] == expected
                    for key, expected in empty_changes.items()),
            "final evidence has post-validation source changes")
    require(validation_index["build_record"]["sha256"] == sha(directory / "relar-build-record.json")
            == benchmark["source_and_tool_sha256"]["relar_build_record"],
            "validation/build/benchmark hash link differs")
    timing_run, = [run for run in timing_status["runs"] if run["mode"] == "thinlto"]
    require(timing_run["record_sha256"] == sha(timing_path)
            and Path(value(timing_run["command"], "--output")).resolve() == timing_path.resolve(),
            "profile record is not the completed ThinLTO record")
    git_env = {**os.environ, "GIT_OPTIONAL_LOCKS": "0"}
    require(subprocess.check_output(["git", "-C", str(args.root), "rev-parse", "HEAD"],
                                    text=True, env=git_env).strip() == revision
            and not subprocess.check_output(["git", "-C", str(args.root), "status", "--porcelain"],
                                            env=git_env),
            "frozen source revision or worktree changed")
    require(datetime.fromisoformat(summary["started_at_utc"])
            > max(datetime.fromisoformat(run["completed_at_utc"]) for run in timing_status["runs"]),
            "profiling overlapped benchmark execution")
    require(summary["cpu_affinity"] == benchmark["cpu"]["affinity"]
            and len(summary["cpu_affinity"]) == 1,
            "recorded CPU affinity differs")

    workload, = [item for item in benchmark["workloads"] if item["label"] == summary["label"]]
    payload = base64.b64decode(workload["input_base64"], validate=True)
    require(workload["operation"] == "checksum" and workload["digits"] == len(payload) == args.digits
            and all(48 <= byte <= 57 for byte in payload)
            and hashlib.sha256(payload).hexdigest() == workload["input_sha256"],
            "invalid ASCII workload")
    weighted = [(byte - 48) * (2 if index % 2 == len(payload) % 2 else 1)
                for index, byte in enumerate(payload)]
    checksum = sum(digit // 10 + digit % 10 for digit in weighted) % 10
    expected_output = str(checksum).encode()
    expected_stdout = f"OK\n{checksum * summary['repetitions']}\n".encode()
    require(checksum == summary["checksum_per_call"]
            and expected_output == bytes.fromhex(summary["expected_output_hex"])
            == base64.b64decode(workload["expected_output_base64"], validate=True)
            and hashlib.sha256(expected_output).hexdigest() == workload["expected_output_sha256"]
            and workload["expected_stdout"] == f"OK\n{checksum * workload['repetitions']}\n"
            and expected_stdout.decode() == summary["expected_stdout"], "independent arithmetic differs")
    hashes = benchmark["source_and_tool_sha256"]
    require(all(summary["guarded_inputs"][name]["sha256"] == expected
                for name, expected in hashes.items()), "timed source/tool hashes differ")
    require(hashes["compiler"] == build["sha256"]["compiler"]
            and hashes["runtime"] == build["sha256"]["thinlto_runtime"],
            "timed compiler/runtime differs from the validated build")
    baseline = read_json(directory / "baseline-record.json")
    baseline_validation = read_json(directory / "baseline-validation.json")
    baseline_path = Path(timing_status["protected_paths"]["thinlto_baseline"])
    baseline_record_path = Path(timing_status["protected_paths"]["thinlto_baseline_record"])
    require(baseline == benchmark["baseline_record"] and baseline["input_guards_passed"]
            and baseline["dirty"] is False and baseline["thinlto"] is True
            and sha(baseline_path) == hashes["baseline"] == baseline["binary_sha256"]
            == benchmark["baseline_provenance"]["binary_sha256"]
            and sha(baseline_record_path) == sha(directory / "baseline-record.json")
            == hashes["baseline_record"] == benchmark["baseline_provenance"]["record_sha256"]
            and summary["baseline_provenance"] == benchmark["baseline_provenance"],
            "preserved baseline provenance differs")
    require(baseline_validation == benchmark["baseline_validation"]
            == read_json(value(benchmark["baseline_validation_command"], "--output"))
            and baseline_validation["relar"]["binary_sha256"] == hashes["baseline"]
            and Path(value(benchmark["baseline_validation_command"], "--binary")).resolve()
            == baseline_path.resolve(), "fresh baseline validation differs")
    previous_workload, = [item for item in baseline["workloads"] if item["label"] == args.label]
    require(all(workload[key] == previous_workload[key] for key in
                ("operation", "digits", "input_base64", "input_sha256",
                 "expected_output_base64", "expected_output_sha256")),
            "profile workload differs from the preserved baseline")
    require({engine for order in benchmark["engine_orders"] for engine in order}
            == {"relar", "rust", "baseline", "cpython"}, "expected four timed engines")
    for engine in ("relar", "rust", "baseline", "cpython"):
        require(Path(summary["guarded_inputs"][f"timed_{engine}_input"]["path"]).read_bytes() == payload
                and Path(summary["guarded_inputs"][f"timed_{engine}_output"]["path"]).read_bytes()
                == expected_output, "retained timed input/output differs")
    binaries = {
        "relar": Path(value(benchmark["compile_command"], "-o")),
        "rust": Path(value(benchmark["validation_command"], "--rust")),
    }
    binary_hashes = {name: sha(path) for name, path in binaries.items()}
    require(binary_hashes["relar"] == benchmark["binary_sha256"]
            and binary_hashes["rust"] == benchmark["source_and_tool_sha256"]["rust"]
            == rust_build["binary_sha256"], "timed binary identities differ")
    require(sha(directory / "native.ll") == benchmark["llvm_sha256"], "timed LLVM differs")
    require(len(summary["profiles"]) == 4
            and {(item["engine"], item["tool"]) for item in summary["profiles"]}
            == {(engine, tool) for engine in binaries for tool in ("callgrind", "dhat")},
            "profile matrix is incomplete")

    results = {}
    for item in summary["profiles"]:
        engine, tool = item["engine"], item["tool"]
        run_dir = directory / f"{engine}-{tool}"
        require(item["status"] == "validated" and item["returncode"] == 0, "profile process failed")
        command_record = read_json(run_dir / "command.json")
        require(all(command_record[key] == item[key] for key in command_record),
                "process command record differs")
        target = [str(binaries[engine]), "checksum", str(run_dir / "input.bin"),
                  str(run_dir / "output.bin"), str(args.repetitions)]
        require(item["command"][-5:] == target and item["cwd"] == str(run_dir)
                and item["environment"] == summary["environment"]
                and item["binary_sha256"] == binary_hashes[engine],
                "profile command, environment, or binary differs")
        flags = item["command"][1:-5]
        require(f"--tool={tool}" in flags and "--command-line-only=yes" in flags
                and "--num-callers=32" in flags and "--error-exitcode=97" in flags,
                "profiling flags differ")
        require(sha(item["command"][0]) == summary["guarded_inputs"]["tool_valgrind"]["sha256"],
                "Valgrind launcher differs")
        require((run_dir / "input.bin").read_bytes() == payload
                and (run_dir / "output.bin").read_bytes() == expected_output
                and (run_dir / "stdout.txt").read_bytes() == expected_stdout
                and (run_dir / "stderr.txt").read_bytes() == b"",
                "profile input/output/checksum differs")
        require(item["input_sha256"] == hashlib.sha256(payload).hexdigest(),
                "profile input hash differs")
        require({path.name for path in run_dir.iterdir()} == set(item["files"]),
                "profile per-process file set differs")
        require(all(sha(run_dir / name) == expected for name, expected in item["files"].items()),
                "profile per-process hash differs")
        log = (run_dir / "valgrind.log").read_text()
        logged_command = re.search(r"==\d+== Command: (.+)", log)[1]
        require(shlex.split(logged_command) == target, "Valgrind logged another target")
        if tool == "callgrind":
            result = callgrind(run_dir / "profile.callgrind", target, item["metrics"], run_dir)
            require(len(item["annotations"]) == 2, "missing Callgrind annotations")
            for annotation in item["annotations"]:
                mode = next(flag.split("=", 1)[1] for flag in annotation["command"]
                            if flag.startswith("--inclusive="))
                require(annotation["returncode"] == 0
                        and sha(run_dir / f"inclusive-{mode}.txt") == annotation["stdout_sha256"]
                        and sha(run_dir / f"inclusive-{mode}-stderr.txt") == annotation["stderr_sha256"],
                        "annotation evidence differs")
        else:
            result = dhat(run_dir / "profile.json", target, item["metrics"], run_dir)
        results[f"{engine}-{tool}"] = result
    require(all(sha(path) == manifest[name] for name, path in files.items()),
            "profile changed during audit")
    require(guarded_before == {name: sha(value["path"])
                             for name, value in summary["guarded_inputs"].items()},
            "guarded input changed during audit")
    output = {
        "schema": 1, "status": "passed",
        "audited_at_utc": datetime.now(timezone.utc).isoformat(),
        "auditor_sha256": sha(Path(__file__).resolve()),
        "profile_summary_sha256": sha(summary_path),
        "profile_manifest_sha256": sha(manifest_path),
        "profile_manifest_members": len(manifest),
        "guarded_inputs_verified": len(guarded_before),
        "timing_revision": benchmark["revision"],
        "build_revision": build["revision"], "validation_revision": validation_index["revision"],
        "benchmark_record_sha256": sha(timing_path),
        "timing_status_sha256": sha(timing_status_path),
        "validation_index_sha256": sha(args.validation_index),
        "baseline_provenance": benchmark["baseline_provenance"],
        "binary_sha256": binary_hashes,
        "workload": {"label": args.label, "operation": "checksum", "digits": args.digits,
                     "repetitions": args.repetitions,
                     "digits_per_process": args.digits * args.repetitions, "checksum_per_call": checksum,
                     "output_hex": expected_output.hex(), "stdout": expected_stdout.decode()},
        "profiles": results,
        "checks": {
            "four_exact_timed_binary_runs": True,
            "all_manifests_and_snapshots_verified": True,
            "all_commands_and_output_verified": True,
            "profile_started_after_all_timing_completed": True,
            "callgrind_self_rows_reconcile_with_summary_footer_log_and_annotations": True,
            "callgrind_function_self_and_incoming_edges_verified": True,
            "dhat_total_global_peak_exit_fields_reconcile_with_log": True,
            "dhat_top_allocation_stacks_verified": True,
            "source_tool_binary_guards_rehashed_before_and_after": True,
            "preserved_baseline_and_fresh_validation_provenance_verified": True,
            "one_final_build_validation_and_timing_revision": True,
        },
        "limits": [
            "No benchmarks, profilers, compilers, or test programs were executed by this audit.",
            "Callgrind guest instruction counts are not CPU cycles, wall time, or CPU-time percentages.",
            "Incoming inclusive call costs overlap across nested calls; only self costs partition process instructions.",
            "DHAT counts requested heap bytes/blocks, not allocator usable size or RSS.",
            "Global peak uses summed gb/gbk contributions at t-gmax; summed independent site maxima are not a simultaneous process peak.",
            "Profiles include process startup, decoding, file I/O, repeated calls, checksum accumulation, and exit.",
            "Exit-live allocations do not establish leaks; ASan/LSan validation is recorded separately.",
            "Recorded affinity matches timing; past per-child affinity is not independently observable after process exit.",
        ],
    }
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"audit": str(args.output), "sha256": sha(args.output),
                      "profiles": len(results), "manifest_members": len(manifest),
                      "guarded_inputs": len(guarded_before)}, indent=2))


if __name__ == "__main__":
    main()
