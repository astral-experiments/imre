"""Package completed Luhn evidence; never run builds, tests, or measurements.

Example (run only after timing, profiling, and their audits are complete):
    python3 -I -B /tmp/imre-luhn-performance-package-evidence.py \
        --short-profile-dir <short-profile> --short-profile-audit <short-audit> \
        --large-profile-dir <large-profile> --large-profile-audit <large-audit> \
        --profile-audit-script <audit-script> \
        --prefix /tmp/2026-10-20-luhn-performance

The archive contains normalized, sorted regular files. Its external manifest
hashes every member and the archive itself. Repeating with the same inputs and
this script produces identical archive bytes, regardless of the output prefix.
"""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def option(command, flag):
    require(command.count(flag) == 1, f"expected one {flag}: {command}")
    return Path(command[command.index(flag) + 1])


def relative_name(value):
    name = PurePosixPath(value)
    require(not name.is_absolute() and ".." not in name.parts and str(name) != ".",
            f"unsafe archive path: {value}")
    return str(name)


def native_kind(header):
    """Classify native code by bytes, preserving benchmark I/O named *.bin."""
    if header.startswith(b"\x7fELF"):
        return "ELF native executable, object, or shared library"
    if header.startswith((b"!<arch>\n", b"!<thin>\n")):
        return "native static archive"
    if header.startswith((b"BC\xc0\xde", b"\xde\xc0\x17\x0b")):
        return "LLVM bitcode"
    if header[:4] in (b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
                      b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe",
                      b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca"):
        return "Mach-O native code"
    if header.startswith(b"MZ"):
        return "PE native code"
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/imre"))
    parser.add_argument("--validation-dir", type=Path, default=Path("/tmp/imre-luhn-performance-validation-v1"))
    parser.add_argument("--timing-prefix", type=Path, default=Path("/tmp/imre-luhn-performance-v1"))
    parser.add_argument("--timing-audit", type=Path, default=Path("/tmp/imre-luhn-performance-benchmark-audit.json"))
    parser.add_argument("--validation-audit", type=Path, default=Path("/tmp/imre-luhn-performance-validation-audit.json"))
    parser.add_argument("--validation-audit-script", type=Path, default=Path("/tmp/imre-luhn-performance-validation-audit.py"))
    parser.add_argument("--timing-audit-script", type=Path, default=Path("/tmp/imre-luhn-performance-audit-benchmarks.py"))
    for role in ("short", "large"):
        parser.add_argument(f"--{role}-profile-dir", type=Path, required=True)
        parser.add_argument(f"--{role}-profile-audit", type=Path, required=True)
    parser.add_argument("--profile-audit-script", type=Path, required=True)
    parser.add_argument("--baseline-manifest", type=Path,
                        default=Path("/tmp/2026-10-20-luhn-evidence-manifest.json"))
    parser.add_argument("--baseline-archive", type=Path,
                        default=Path("/tmp/2026-10-20-luhn-evidence.tar.gz"))
    parser.add_argument("--baseline-evidence-url", required=True,
                        help="Published URL for the previous evidence archive; its exact hash is retained")
    parser.add_argument("--prefix", type=Path, required=True, help="fresh output prefix under /tmp")
    parser.add_argument("--extra", type=Path, action="append", default=[],
                        help="additional file or directory (including exploratory stages), retained under extras/")
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    validation = args.validation_dir.resolve(strict=True)
    profiles = {role: getattr(args, role + "_profile_dir").resolve(strict=True)
                for role in ("short", "large")}
    profile_audit_paths = {role: getattr(args, role + "_profile_audit").resolve(strict=True)
                           for role in profiles}
    prefix = args.prefix.resolve()
    require(Path("/tmp") in prefix.parents, "outputs must be under /tmp")
    archive_path = Path(str(prefix) + "-evidence.tar.gz")
    manifest_path = Path(str(prefix) + "-evidence-manifest.json")
    require(not archive_path.exists() and not manifest_path.exists(),
            "output files already exist; use a fresh prefix")
    require(prefix.parent.is_dir(), "output parent directory does not exist")

    # Check terminal records before scanning or compressing evidence.
    index = read_json(validation / "index.json")
    build = read_json(validation / "build.json")
    audit_path = args.validation_audit.resolve(strict=True)
    audit = read_json(audit_path)
    timing_status_path = Path(str(args.timing_prefix) + "-timing-status.json")
    timing = read_json(timing_status_path)
    timing_audit = read_json(args.timing_audit)
    profile_summaries = {role: read_json(directory / "summary.json")
                         for role, directory in profiles.items()}
    profile_audits = {role: read_json(path) for role, path in profile_audit_paths.items()}
    require(all(record["status"] == "passed" for record in
                [index, audit, timing, timing_audit, *profile_summaries.values(), *profile_audits.values()]),
            "all validation, timing, profiles, and independent audits must be passed")
    require(index["source_unchanged"] and index["input_guards_passed"]
            and build["source_matches_revision"] and build["input_guards_passed"],
            "a validation/build completion or input guard failed")
    revision = index["revision"]
    require(build["revision"] == audit["validation_revision"] == revision,
            "validation/build/audit revision mismatch")
    for record in (timing, timing_audit, *profile_summaries.values(), *profile_audits.values()):
        require(all(record[field] == revision for field in
                    ("build_revision", "validation_revision", "timing_revision")),
                "final validation, build, timing, and profiles must use one frozen revision")
        if "revision" in record:
            require(record["revision"] == revision, "profile source revision mismatch")
        if "head" in record:
            require(record["head"] == revision, "timing source revision mismatch")
        if "post_validation_changes" in record:
            change = record["post_validation_changes"]
            require(change["paths"] == [] and change["patch"] == ""
                    and change["patch_sha256"] == digest(b""),
                    "final evidence must have no post-validation source changes")
    require(index["job_counts"] == {"passed": len(index["jobs"]), "failed": 0}
            and audit["counts"]["recorded_jobs"] == audit["counts"]["passed_jobs"] == len(index["jobs"])
            and audit["counts"]["failed_jobs"] == 0
            and index["unit_tests_passed"] == audit["counts"]["rust_units"]["total"],
            "validation coverage disagrees with its independent audit")
    require(audit["validation_index_sha256"] == sha(validation / "index.json"),
            "validation audit describes another index")
    require(timing_audit["timing_status_sha256"] == sha(timing_status_path),
            "timing audit describes another run")
    require(timing["source_unchanged"] and timing["input_guards_passed"]
            and timing_audit["validation_index_sha256"] == sha(validation / "index.json"),
            "timing completion or full-validation index binding differs")
    for role, profiling in profile_summaries.items():
        profile_audit = profile_audits[role]
        require(profiling["complete"] and profiling["input_guards_passed"],
                f"incomplete {role} profile input guards")
        require(len(profiling["profiles"]) == 4
                and {(item["engine"], item["tool"]) for item in profiling["profiles"]}
                == {(engine, tool) for engine in ("imre", "rust") for tool in ("callgrind", "dhat")}
                and all(item["status"] == "validated" and item["returncode"] == 0
                        for item in profiling["profiles"]), f"incomplete {role} profile matrix")
        require(profile_audit["profile_summary_sha256"] == sha(profiles[role] / "summary.json")
                and profile_audit["profile_manifest_sha256"] == sha(profiles[role] / "manifest.json")
                and profile_audit["benchmark_record_sha256"] == profiling["benchmark_record_sha256"]
                and profile_audit["validation_index_sha256"] == sha(validation / "index.json"),
                f"{role} profile audit describes another run")
    require(0 < profile_summaries["short"]["digits"] < profile_summaries["large"]["digits"],
            "short and large profiles must cover distinct increasing input lengths")

    def git(*arguments):
        return subprocess.check_output(["git", "-C", str(root), *arguments])

    members = {}
    exclusions = []
    guarded_files = {}

    def verify(path, expected):
        path = Path(path)
        actual = sha(path)
        require(actual == expected, f"hash changed: {path}")
        prior = guarded_files.setdefault(str(path), actual)
        require(prior == actual, f"input changed while packaging: {path}")
        return actual

    def add_bytes(name, data, mode=0o644):
        name = relative_name(name)
        require(name not in members, f"duplicate archive member: {name}")
        require(native_kind(data[:16]) is None, f"native data cannot be an archive member: {name}")
        members[name] = {"data": data, "sha256": digest(data), "bytes": len(data), "mode": mode}

    def add_file(name, path):
        name, path = relative_name(name), Path(path)
        require(path.resolve() != args.baseline_archive.resolve(),
                "previous evidence archive must remain a hashed external reference")
        require(not path.is_symlink() and path.is_file(), f"expected regular file: {path}")
        with path.open("rb") as stream:
            header = stream.read(16)
        reason = native_kind(header)
        if path.suffix == ".pyc" or "__pycache__" in path.parts:
            reason = "generated Python bytecode"
        value = sha(path)
        guarded_files.setdefault(str(path), value)
        if reason:
            exclusions.append({"would_be_member": name, "path": str(path),
                               "sha256": value, "bytes": path.stat().st_size,
                               "reason": reason, "hash_verified_during_packaging": True})
            return
        require(name not in members, f"duplicate archive member: {name}")
        members[name] = {"path": path, "sha256": value, "bytes": path.stat().st_size,
                         "mode": 0o644}

    def add_tree(name, directory):
        for path in sorted(directory.rglob("*")):
            require(not path.is_symlink(), f"unexpected symlink in evidence: {path}")
            if path.is_file():
                add_file(f"{name}/{path.relative_to(directory).as_posix()}", path)

    def verify_manifest(directory, filename):
        manifest = read_json(directory / filename)
        for relative, expected in manifest.items():
            verify(directory / relative_name(relative), expected)
        return len(manifest)

    # Original manifests include omitted native artifacts. Retain them unchanged,
    # and describe the omissions explicitly rather than rewriting prior evidence.
    validation_manifest_count = verify_manifest(validation, "evidence-sha256.json")
    require(validation_manifest_count == audit["guard_checks"]["evidence_manifest_entries"],
            "validation evidence manifest size differs from its audit")
    verify(validation / "evidence-sha256.json", index["evidence_manifest_sha256"])
    verify(validation / "runner.py", index["runner_sha256"])
    verify(validation / "build.json", index["build_record"]["sha256"])
    for job in index["jobs"]:
        require(job["status"] == "passed" and job["exit_code"] == 0, f"failed job: {job['name']}")
        for key in ("record", "stdout", "stderr"):
            verify(job[key], job[key + "_sha256"])
    source = read_json(validation / "source-before.json")
    require(source == read_json(validation / "source-after.json")
            and source["revision"] == revision and source["status"] == "",
            "validation source snapshots differ")
    require(source["tree"] == git("rev-parse", f"{revision}^{{tree}}").decode().strip(),
            "validation source tree differs")
    require(len(source["files"]) == audit["guard_checks"]["source_files_verified_against_original_git_commit"],
            "source snapshot count differs from its audit")

    # Read only committed Git objects. Later report/doc commits do not change the
    # measured source snapshot or falsely move the full validation to a new HEAD.
    names = sorted(source["files"])
    tree_names = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    require(sorted(name for name in tree_names if not name.startswith("benchmarks/results/"))
            == names, "measured source file set changed")
    data = git("archive", "--format=tar", revision, "--", *names)
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:") as archive:
        source_contents = {item.name: (archive.extractfile(item).read(), item.mode)
                           for item in archive if item.isfile()}
    require(set(source_contents) == set(names), "Git source archive is incomplete")
    require(all(digest(source_contents[name][0]) == entry["sha256"]
                and bool(source_contents[name][1] & 0o111) == entry["executable"]
                for name, entry in source["files"].items()), "validation source hashes differ")
    require(all(digest(source_contents[name][0]) == expected
                for name, expected in build["source_sha256"].items()), "build source hashes differ")
    for name, (data, mode) in source_contents.items():
        add_bytes(f"source/{name}", data, 0o755 if mode & 0o111 else 0o644)
    add_tree("validation", validation)
    add_file("audits/validation.json", audit_path)
    add_file("helpers/validation-audit.py", args.validation_audit_script)
    verify(args.validation_audit_script, audit["audit_script_sha256"])

    require(len(timing["runs"]) == 2 and {item["mode"] for item in timing["runs"]}
            == {"normal", "thinlto"}, "incomplete timing matrix")
    add_file("timing/status.json", timing_status_path)
    add_file("audits/timing.json", args.timing_audit)
    add_file("helpers/timing-audit.py", args.timing_audit_script)
    verify(args.timing_audit_script, timing_audit["auditor_sha256"])
    for name, path in timing["protected_paths"].items():
        verify(path, timing["source_and_tool_sha256"][name])
    add_file("helpers/timing-launcher.py", timing["protected_paths"]["helper"])
    timing_records = {}
    for run in timing["runs"]:
        mode = run["mode"]
        record_path = Path(str(args.timing_prefix) + f"-{mode}.json")
        directory = Path(str(args.timing_prefix) + f"-{mode}")
        record = read_json(record_path)
        verify(record_path, run["record_sha256"])
        require(run["returncode"] == 0 and record["revision"] == revision
                and not record["dirty"] and record["input_guards_passed"]
                and record["thinlto"] == (mode == "thinlto"), f"incomplete {mode} timing")
        require(record["imre_build_record"] == build, "timing used another compiler build")
        verify(option(record["compile_command"], "-o"), record["binary_sha256"])
        verify(option(record["compile_command"], "--emit-llvm"), record["llvm_sha256"])
        require(read_json(option(record["validation_command"], "--output")) == record["validation"],
                "timing validation snapshot changed")
        require(timing_audit["identities"][mode]["record_sha256"] == run["record_sha256"],
                "audit timing record mismatch")
        for key in ("stdout", "stderr"):
            verify(run[key], run[key + "_sha256"])
            add_file(f"timing/{mode}.{key}.log", run[key])
        source_keys = {
            "harness": "benchmarks/luhn_benchmark.py",
            "validator": "benchmarks/luhn_validate.py",
            "shared_harness": "benchmarks/benchmark.py",
            "shared_validator": "benchmarks/validate.py",
        }
        for name, expected in record["source_and_tool_sha256"].items():
            relative = source_keys.get(name)
            for key, base in (("imre_source:", ""), ("example:", "examples/luhn_checksum/"),
                              ("rust_source:", "benchmarks/reference/luhn_checksum/")):
                if name.startswith(key):
                    relative = base + name.removeprefix(key)
            if relative is not None:
                require(digest(source_contents[relative][0]) == expected,
                        f"timed source differs from the committed snapshot: {relative}")
        add_file(f"timing/{mode}.json", record_path)
        add_tree(f"timing/{mode}", directory)
        timing_records[mode] = record

    profile_manifest_counts = {}
    for role, profile in profiles.items():
        profiling = profile_summaries[role]
        profile_audit = profile_audits[role]
        require(profiling["benchmark_record_sha256"] in
                {run["record_sha256"] for run in timing["runs"]},
                f"{role} profile is not from this timing run")
        profile_manifest_counts[role] = verify_manifest(profile, "manifest.json")
        require(profile_manifest_counts[role] == profile_audit["profile_manifest_members"],
                f"{role} profile manifest count differs from audit")
        for name, expected in profiling["snapshot_sha256"].items():
            verify(profile / relative_name(name), expected)
        for value in profiling["guarded_inputs"].values():
            verify(value["path"], value["sha256"])
        verify(args.profile_audit_script, profile_audit["auditor_sha256"])
        add_tree(f"profiles/{role}", profile)
        add_file(f"audits/profile-{role}.json", profile_audit_paths[role])
    add_file("helpers/profile-audit.py", args.profile_audit_script)

    baseline_manifest = read_json(args.baseline_manifest)
    require(baseline_manifest["status"] == "passed", "previous evidence manifest is not passed")
    verify(args.baseline_archive, baseline_manifest["archive"]["sha256"])
    require(args.baseline_archive.stat().st_size == baseline_manifest["archive"]["bytes"],
            "previous evidence archive size differs")
    baseline_evidence = {
        "manifest_path": str(args.baseline_manifest),
        "manifest_sha256": sha(args.baseline_manifest),
        "archive_path": str(args.baseline_archive),
        "archive_sha256": baseline_manifest["archive"]["sha256"],
        "archive_bytes": baseline_manifest["archive"]["bytes"],
        "published_url": args.baseline_evidence_url,
        "validation_revision": baseline_manifest["validation_revision"],
        "timing_revision": baseline_manifest["timing_revision"],
        "archive_included": False,
        "reason": "Immutable previous evidence is linked and hashed, not duplicated in this package.",
    }
    add_file("provenance/baseline-evidence-manifest.json", args.baseline_manifest)
    add_bytes("provenance/baseline-evidence.json", json_bytes(baseline_evidence))
    # Baseline binary identities are retained as exclusions; current timing JSON
    # already embeds each original record and the fresh baseline validation.
    for mode, record in timing_records.items():
        baseline_path = Path(timing["protected_paths"][mode + "_baseline"])
        baseline_record = Path(timing["protected_paths"][mode + "_baseline_record"])
        verify(baseline_path, record["baseline_provenance"]["binary_sha256"])
        verify(baseline_record, record["baseline_provenance"]["record_sha256"])
        require(read_json(baseline_record) == record["baseline_record"],
                "embedded previous benchmark record differs")
        require(record["baseline_record"]["revision"] == baseline_manifest["timing_revision"]
                and baseline_manifest["members"][f"timing/{mode}.json"]["sha256"] == sha(baseline_record),
                "previous benchmark record is not described by the linked evidence")
        add_file(f"baseline/{mode}/luhn", baseline_path)
    add_file("helpers/package-evidence.py", Path(__file__).resolve())
    for path in args.extra:
        path = path.resolve(strict=True)
        if path.is_dir():
            add_tree(f"extras/{path.name}", path)
        else:
            add_file(f"extras/{path.name}", path)
    for name, path, source_name in (
        ("runtime", Path("/tmp/imre-luhn-tests-validation-dev/unicode-tables-audit.json"),
         "crates/imre-runtime/src/integer_text.rs"),
        ("reference", Path("/tmp/imre-luhn-unicode-table-validation.json"),
         "benchmarks/reference/luhn_checksum/src/unicode.rs"),
    ):
        unicode_audit = read_json(path)
        binding = audit["unicode_audits"][name]
        current_source = source_contents[source_name][0]
        require(unicode_audit["status"] == "passed"
                and unicode_audit["unicode_version"] == "16.0.0"
                and binding["audit_sha256"] == sha(path)
                and binding["applicable_source_revision"] == revision
                and binding["source_path"] == source_name
                and binding["source_sha256"] == digest(current_source)
                and binding["original_audited_source_sha256"] == unicode_audit["source_sha256"],
                f"Unicode {name} audit binding describes another source")
        original_source = git("show", f"{binding['original_validated_revision']}:{source_name}")
        require(digest(original_source) == unicode_audit["source_sha256"],
                f"Unicode {name} original Git blob differs")
        scope = binding["unchanged_implementation_scope"]
        if "start_marker" in scope:
            marker = scope["start_marker"].encode()
            require(original_source.count(marker) == current_source.count(marker) == 1,
                    f"Unicode {name} scope marker is ambiguous")
            original_scope = marker + original_source.split(marker, 1)[1]
            current_scope = marker + current_source.split(marker, 1)[1]
        else:
            original_scope, current_scope = original_source, current_source
        require(original_scope == current_scope and digest(current_scope) == scope["sha256"]
                and len(current_scope) == scope["bytes"] and not binding["exhaustive_audit_rerun"],
                f"Unicode {name} implementation differs from its original exhaustive audit")
        add_file(f"audits/unicode-{name}.json", path)

    # Toolchains are identified but never copied or recursively scanned.
    external = []
    for name, value in sorted(index["tools"].items()):
        verify(value["path"], value["sha256"])
        external.append({"origin": f"validation.tools.{name}", **value,
                         "reason": "tool executable omitted", "hash_verified_during_packaging": True})
    for role, profiling in profile_summaries.items():
        for name, value in sorted(profiling["guarded_inputs"].items()):
            if name.startswith("tool_"):
                external.append({"origin": f"profiles.{role}.guarded_inputs.{name}", **value,
                                 "reason": "profiling tool omitted", "hash_verified_during_packaging": True})
    metadata = {
        "schema": 1,
        "revision": revision,
        "build_revision": revision,
        "validation_revision": revision,
        "validation_tree": source["tree"],
        "timing_revision": revision,
        "timing_tree": source["tree"],
        "source_files": len(source_contents),
        "post_validation_paths": [],
        "baseline_evidence": baseline_evidence,
        "validation_counts": audit["counts"],
        "validation_index_sha256": sha(validation / "index.json"),
        "validation_build_sha256": sha(validation / "build.json"),
        "profile_manifest_entries": profile_manifest_counts,
        "profiles": {role: {
            "label": summary["label"], "digits": summary["digits"],
            "repetitions": summary["repetitions"],
            "summary_sha256": sha(profiles[role] / "summary.json"),
            "audit_sha256": sha(profile_audit_paths[role]),
        } for role, summary in profile_summaries.items()},
        "limits": audit["limits"],
        "notes": [
            "Final validation, compiler/runtime builds, timing, and both profiles use the same frozen source revision.",
            "The previous immutable evidence archive is linked and hashed rather than nested; exact preserved baseline binaries are remeasured in the new timing records.",
            "Optional extras retain exploratory-stage records separately from final evidence.",
            "Original manifests include native files omitted from this package; exclusions.json identifies those omissions by hash.",
            "All tracked measured source files are included except historical benchmarks/results/ artifacts.",
            "LLVM text and benchmark binary input/output data are retained; executable native code, archives, bitcode, and toolchains are excluded.",
            "Archive members are sorted; timestamps, ownership, and modes are normalized. Gzip mtime is zero.",
        ],
    }
    add_bytes("provenance/package.json", json_bytes(metadata))
    add_bytes("provenance/exclusions.json",
              json_bytes({"artifacts": sorted(exclusions, key=lambda item: item["would_be_member"]),
                          "external_tools": external}))

    # Recheck every selected input, including omitted artifacts and tools, before
    # writing. Each archived file is also checked against its planned bytes.
    for path, expected in guarded_files.items():
        require(sha(path) == expected, f"input changed before archive write: {path}")
    temporary = Path(str(archive_path) + ".partial")
    require(not temporary.exists(), "partial archive already exists")
    with temporary.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, value in sorted(members.items()):
                    data = value["data"] if "data" in value else value["path"].read_bytes()
                    require(digest(data) == value["sha256"] and len(data) == value["bytes"],
                            f"member changed during archive write: {name}")
                    item = tarfile.TarInfo(name)
                    item.size, item.mode, item.mtime = len(data), value["mode"], 0
                    item.uid = item.gid = 0
                    item.uname = item.gname = ""
                    archive.addfile(item, io.BytesIO(data))
    temporary.rename(archive_path)
    with tarfile.open(archive_path, "r:gz") as archive:
        archived = archive.getmembers()
        require([item.name for item in archived] == sorted(members),
                "archive membership differs from the manifest")
        for item in archived:
            data = archive.extractfile(item).read()
            require(item.isfile() and item.size == members[item.name]["bytes"]
                    and digest(data) == members[item.name]["sha256"]
                    and native_kind(data[:16]) is None,
                    f"archive member verification failed: {item.name}")
    for path, expected in guarded_files.items():
        require(sha(path) == expected, f"input changed during archive write: {path}")
    manifest = {
        "schema": 1, "status": "passed", **metadata,
        "archive": {"name": archive_path.name, "sha256": sha(archive_path),
                    "bytes": archive_path.stat().st_size},
        "member_count": len(members),
        "members": {name: {key: value[key] for key in ("sha256", "bytes", "mode")}
                    for name, value in sorted(members.items())},
        "excluded_artifact_count": len(exclusions),
        "packager_sha256": sha(Path(__file__).resolve()),
    }
    with manifest_path.open("xb") as stream:
        stream.write(json_bytes(manifest))
    print(json.dumps({"archive": str(archive_path), "manifest": str(manifest_path),
                      "members": len(members), "excluded_artifacts": len(exclusions),
                      "archive_sha256": manifest["archive"]["sha256"]}, indent=2))


if __name__ == "__main__":
    main()
