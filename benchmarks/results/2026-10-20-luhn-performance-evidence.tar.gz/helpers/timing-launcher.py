"""Run frozen four-engine Luhn comparisons only after final validation and CPU release."""

import argparse
import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path("/home/dev-user/code/oss/relar")
    )
    parser.add_argument("--compiler", type=Path, required=True)
    parser.add_argument("--normal-runtime", type=Path, required=True)
    parser.add_argument("--thinlto-runtime", type=Path, required=True)
    parser.add_argument("--build-record", type=Path, required=True)
    parser.add_argument("--validation-index", type=Path)
    parser.add_argument("--target", default="x86_64-unknown-linux-gnu")
    parser.add_argument("--linker", type=Path, required=True)
    parser.add_argument("--clang", default="clang-18")
    parser.add_argument("--cpu", type=int)
    parser.add_argument(
        "--normal-reference", type=Path, default=Path("/tmp/relar-luhn-reference-normal")
    )
    parser.add_argument(
        "--thinlto-reference",
        type=Path,
        default=Path("/tmp/relar-luhn-reference-thinlto"),
    )
    parser.add_argument(
        "--normal-baseline", type=Path, default=Path("/tmp/relar-luhn-v2-normal/luhn")
    )
    parser.add_argument(
        "--thinlto-baseline", type=Path, default=Path("/tmp/relar-luhn-v2-thinlto/luhn")
    )
    parser.add_argument(
        "--normal-baseline-record",
        type=Path,
        default=Path("/tmp/relar-luhn-v2-normal.json"),
    )
    parser.add_argument(
        "--thinlto-baseline-record",
        type=Path,
        default=Path("/tmp/relar-luhn-v2-thinlto.json"),
    )
    parser.add_argument(
        "--prefix", type=Path, default=Path("/tmp/relar-luhn-performance-v1")
    )
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    python = Path(
        "/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14"
    )
    git = lambda *items: subprocess.check_output(
        ["git", "-C", str(root), *items], text=True
    ).strip()
    head = git("rev-parse", "HEAD")
    assert not git("status", "--porcelain"), "benchmark source tree must be clean"
    validation_path = (
        args.validation_index or args.build_record.parent / "index.json"
    ).resolve(strict=True)
    validation = json.loads(validation_path.read_text())
    assert (
        validation["status"] == "passed"
        and validation["input_guards_passed"]
        and validation["source_unchanged"]
    ), "the complete frozen validation matrix must pass before timing"
    validation_revision = validation["revision"]
    subprocess.run(
        [
            "git",
            "-C",
            str(root),
            "merge-base",
            "--is-ancestor",
            validation_revision,
            head,
        ],
        check=True,
    )
    changed_paths = git("diff", "--name-only", validation_revision, head).splitlines()
    assert changed_paths in ([], ["benchmarks/luhn_benchmark.py"]), (
        "only the benchmark harness may change after validation; its exact patch is retained"
    )
    harness_patch = git(
        "diff", validation_revision, head, "--", "benchmarks/luhn_benchmark.py"
    )
    protected = {
        "helper": Path(__file__).resolve(),
        "harness": root / "benchmarks/luhn_benchmark.py",
        "validator": root / "benchmarks/luhn_validate.py",
        "compiler": args.compiler.resolve(strict=True),
        "normal_runtime": args.normal_runtime.resolve(strict=True),
        "thinlto_runtime": args.thinlto_runtime.resolve(strict=True),
        "build_record": args.build_record.resolve(strict=True),
        "validation_index": validation_path,
        "python": python,
        "clang": Path(shutil.which(args.clang) or args.clang).resolve(strict=True),
        "linker": args.linker.resolve(strict=True),
    }
    references = {
        "normal": args.normal_reference.resolve(strict=True),
        "thinlto": args.thinlto_reference.resolve(strict=True),
    }
    build = json.loads(protected["build_record"].read_text())
    assert build["revision"] == validation_revision and build["input_guards_passed"]
    assert sha(protected["build_record"]) == validation["build_record"]["sha256"]
    for name in ("compiler", "normal_runtime", "thinlto_runtime"):
        assert sha(protected[name]) == build["sha256"][name]
    for mode, directory in references.items():
        protected[mode + "_reference"] = directory / "luhn-reference"
        protected[mode + "_reference_record"] = directory / "build-record.json"
        assert (
            sha(directory / "build-record.json")
            == validation["references"]["luhn-" + mode]["sha256"]
        )
    for mode in ("normal", "thinlto"):
        baseline = getattr(args, mode + "_baseline").resolve(strict=True)
        record = getattr(args, mode + "_baseline_record").resolve(strict=True)
        saved = json.loads(record.read_text())
        assert saved["input_guards_passed"] and saved["dirty"] is False
        assert saved["thinlto"] == (mode == "thinlto")
        assert saved["binary_sha256"] == sha(baseline)
        assert saved["validation"]["relar"]["binary_sha256"] == sha(baseline)
        protected[mode + "_baseline"] = baseline
        protected[mode + "_baseline_record"] = record
    hashes = {name: sha(path) for name, path in protected.items()}
    status = Path(str(args.prefix) + "-timing-status.json")
    assert not status.exists(), "use a fresh prefix"
    audit = {
        "status": "running",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "head": head,
        "timing_revision": head,
        "build_revision": build["revision"],
        "validation_revision": validation_revision,
        "post_validation_changes": {
            "paths": changed_paths,
            "patch": harness_patch,
            "patch_sha256": hashlib.sha256(harness_patch.encode()).hexdigest(),
            "reason": "Any post-validation changes are limited to the benchmark harness and recorded exactly. Compiler, runtime, validators, example, and Rust reference sources remain at the validated revision.",
        },
        "protected_paths": {name: str(path) for name, path in protected.items()},
        "source_and_tool_sha256": hashes,
        "schedule": {
            "method": "Four fixed label rotations of [0, 1, 3, 2], balancing positions and directed adjacent pairs within each round; cross-round transitions are not balanced.",
            "samples": 12,
            "warmups": 8,
            "batch_digits": 16777216,
            "fixed_before_measurement": True,
        },
        "runs": [],
    }
    status.write_text(json.dumps(audit, indent=2) + "\n")
    for mode in ("normal", "thinlto"):
        assert git("rev-parse", "HEAD") == head and not git("status", "--porcelain")
        assert hashes == {name: sha(path) for name, path in protected.items()}
        directory = Path(str(args.prefix) + "-" + mode)
        record = Path(str(directory) + ".json")
        assert not directory.exists() and not record.exists()
        reference = references[mode]
        command = [
            str(python),
            "-I",
            "-B",
            str(protected["harness"]),
            "--compiler",
            str(protected["compiler"]),
            "--runtime",
            str(protected[mode + "_runtime"]),
            "--relar-build-record",
            str(protected["build_record"]),
            "--python",
            str(python),
            "--clang",
            str(protected["clang"]),
            "--target",
            args.target,
            "--rust",
            str(reference / "luhn-reference"),
            "--rust-build-record",
            str(reference / "build-record.json"),
            "--samples",
            "12",
            "--warmups",
            "8",
            "--baseline",
            str(protected[mode + "_baseline"]),
            "--baseline-record",
            str(protected[mode + "_baseline_record"]),
            "--batch-digits",
            "16777216",
            "--artifact-dir",
            str(directory),
            "--output",
            str(record),
        ]
        if mode == "thinlto":
            command += ["--lto-linker", str(protected["linker"])]
        if args.cpu is not None:
            command += ["--cpu", str(args.cpu)]
        item = {
            "mode": mode,
            "command": command,
            "started_at_utc": datetime.now(timezone.utc).isoformat(),
            "stdout": str(directory) + ".stdout.log",
            "stderr": str(directory) + ".stderr.log",
        }
        audit["runs"].append(item)
        status.write_text(json.dumps(audit, indent=2) + "\n")
        with open(item["stdout"], "w") as stdout, open(item["stderr"], "w") as stderr:
            result = subprocess.run(
                command, cwd=root, stdout=stdout, stderr=stderr, check=False
            )
        item["returncode"] = result.returncode
        item["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
        if result.returncode:
            audit["status"] = "failed"
            status.write_text(json.dumps(audit, indent=2) + "\n")
            raise RuntimeError(f"{mode} failed; see {item['stderr']}")
        data = json.loads(record.read_text())
        assert data["revision"] == head and not data["dirty"]
        assert data["input_guards_passed"] and data["thinlto"] == (mode == "thinlto")
        assert data["samples"] == 12 and data["warmups"] == 8
        names = ("relar", "rust", "baseline", "cpython")
        expected_orders = [
            [names[(index + rotation) % 4] for index in (0, 1, 3, 2)]
            for rotation in range(4)
        ]
        assert data["engine_orders"] == expected_orders
        assert (
            data["baseline_provenance"]["binary_sha256"] == hashes[mode + "_baseline"]
        )
        assert (
            data["baseline_provenance"]["record_sha256"]
            == hashes[mode + "_baseline_record"]
        )
        assert data["workload_source"] == "preserved baseline inputs"
        assert len(data["workloads"]) == 12
        item["record_sha256"] = sha(record)
        item["stdout_sha256"] = sha(item["stdout"])
        item["stderr_sha256"] = sha(item["stderr"])
        status.write_text(json.dumps(audit, indent=2) + "\n")
        print(f"{mode}: {record}", flush=True)
    assert git("rev-parse", "HEAD") == head and not git("status", "--porcelain")
    assert hashes == {name: sha(path) for name, path in protected.items()}
    audit["status"] = "passed"
    audit["input_guards_passed"] = True
    audit["source_unchanged"] = True
    audit["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
    status.write_text(json.dumps(audit, indent=2) + "\n")
    print(status)


if __name__ == "__main__":
    main()
