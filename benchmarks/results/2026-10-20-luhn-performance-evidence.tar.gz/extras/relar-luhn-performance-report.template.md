# Optimizing unchanged Luhn toward Rust performance

Relar compiles the original, unannotated [`mmcloughlin/luhn` 0.2.0](https://github.com/mmcloughlin/luhn/tree/d6f3fa71072f99334a4c1d2a3f062fa93982797f) without rewriting its source. This change removes the dominant temporary objects and checked arithmetic from its hot paths through general compiler and runtime optimizations.

@@RESULT_LEAD@@

The [implementation PR](https://github.com/viarius-experiments/relar/pull/55) remains in the existing GitHub stack. The upstream Python module, typed driver, upstream tests and license, and independent Rust implementation are unchanged. The previous [compatibility report](2026-10-20-luhn.md) retains the original measurements; the comparison here reruns its preserved Relar binaries alongside the new build on the same inputs.

## Wall-time comparison

Each workload process handles **16 MiB of ASCII digits** through repeated calls at the indicated input size. Each build family uses eight warmup rounds and twelve measured rounds. Four fixed engine orders balance positions and directed adjacent pairs within each round; transitions between rounds are not balanced.

Values are median milliseconds with inclusive quartiles in brackets. **Previous / current** and **CPython / Relar** are speedups, so higher is better. **Relar / Rust** is a time ratio, so lower is better. Quartiles describe the observed samples, not confidence intervals.

@@TIMING_TABLES@@

The [Rust reference](../reference/luhn_checksum/README.md) implements the same externally visible string operations, validation order, diagnostics, and file protocol. It streams over digits and uses a virtual trailing zero for `generate`, avoiding Python's intermediate digit list. Both engines receive identical inputs and repetition counts and must produce the same complete output and accumulated checksum. Rust uses a black-box barrier around each repeated call. These measurements compare complete implementations, including their different storage and algorithm choices.

Native engines use matching ordinary or ThinLTO configurations. ThinLTO uses matched LLVM import and inline budgets of 1,000. The build families ran separately with their own interleaved baselines; their difference does not isolate the effect of ThinLTO.

@@STARTUP_TABLE@@

The empty-input, one-call controls expose startup and protocol overhead. They are retained without subtraction. @@STARTUP_SCOPE@@

## What changed

The original profile identified character construction, integer parsing, destruction, and temporary `divmod` pairs as the largest costs. The compiler and runtime now:

- Convert exact `list(map(int, text))` consumers directly into an integer list, with an ASCII fast path and the existing Unicode decimal and error behavior.
- Scalarize fixed tuple sums, including immediate `sum(divmod(...))`, and fuse eligible consumed slices and eager comprehensions while preserving evaluation, mutation, and exception order.
- Use closed-call-graph element bounds and a guarded reduction budget to select native accumulator arithmetic. The guarded loop can borrow exact cursor reads before their unique advance without repeated bounds checks. Other reads and uncertain cases retain checked fallbacks.
- Remove redundant ownership work when the old integer value is proved small, and reuse bounded private list buffers and empty headers after all element owners are released.

The accumulator proof directly selects native arithmetic without redundant LLVM assumptions that hide the recurrence. LLVM retains its ordinary transformation legality and profitability decisions. The result is not a Luhn intrinsic: the transformations apply to the corresponding typed IR patterns.

The approach follows useful ideas in scriptc's [array pipeline lowering](https://github.com/vercel-labs/scriptc/blob/dfb0bed8c1e4e387f6901ccb155d0d6b952f6c0a/packages/compiler/src/frontend/lowering/containers/array-pipelines.ts#L555), [guarded dense-array loops](https://github.com/vercel-labs/scriptc/blob/dfb0bed8c1e4e387f6901ccb155d0d6b952f6c0a/packages/compiler/src/backend/llvm/dense-array-loops.ts#L1), and [integer range analysis](https://github.com/vercel-labs/scriptc/blob/dfb0bed8c1e4e387f6901ccb155d0d6b952f6c0a/packages/compiler/src/ir/integer-ranges.ts#L11): expose concrete storage, eliminate unobservable intermediates, and supply facts at the point where they hold. Relar implements its own proofs in Rust and preserves the supported Python behavior.

Private storage reuse retains at most two empty buffers totaling 512 KiB and two empty headers totaling 80 bytes per thread on the supported 64-bit layout, excluding allocator/TLS bookkeeping. No element owner is retained in either cache. Aliased headers cannot be reused; cache reentry or thread-local teardown uses ordinary destruction.

## Allocation and instruction profiles

After wall timing, separate Callgrind and DHAT runs profiled the **exact timed ThinLTO binaries**. The short workload performs 65,536 checksum calls on 16 digits; the large workload performs 64 calls on 4,096 digits. Every run verifies the complete output and accumulated checksum against an independent ASCII arithmetic oracle.

@@PROFILE_TABLE@@

@@PROFILE_FINDINGS@@

These are whole-process guest instruction and requested allocation counts, not hardware cycles, CPU time, RSS, or latency predictions. Callgrind self costs and inclusive call-edge costs are reported separately to avoid double counting. DHAT cumulative allocation differs from peak live allocation. Profiles include startup, input decoding, file I/O, checksum accumulation, and cleanup. They directly attribute `checksum`; they do not by themselves establish the cause of other APIs' timing gaps.

@@REMAINING_GAP@@

## Compatibility and validation

The [upstream manifest](../../examples/luhn_checksum/UPSTREAM.json) still matches the original module, ten tests, and MIT license byte for byte. Each of **five native configurations** passes all ten upstream tests and five doctest examples through adapters, plus **1,144 CPython differential cases**: ordinary O0/O3, ThinLTO O3, and ASan/LSan O0/O1. Both Rust reference builds pass the same library corpus.

Cases cover all 760 Unicode 16 decimal characters, mixed digit families, empty/random/long inputs, invalid-character ordering, exact exception messages and metadata, malformed UTF-8, and output-file preservation. Separate generic fixtures exercise alias mutation, evaluation order, arbitrary-precision fallbacks, control-flow exits, post-advance reads, and ownership. Luhn has no diagnostic exclusions.

The frozen full matrix passes **129 command jobs**, including formatting, strict workspace Clippy, **190 Rust unit tests**, **4,256 generic checks**, all six application oracles, and unchanged Base45 validation. The 81 language/library suite invocations cover 27 suites across ordinary, ThinLTO, and sanitizer configurations; paired optimization levels are grouped within one invocation. The independent [validation audit](2026-10-20-luhn-performance-validation-audit.json) records exact counts and rehashes every retained native artifact.

GitHub CI also [passes at the measured implementation revision](https://github.com/viarius-experiments/relar/actions/runs/39405086975), using the repository's normal Rust toolchain.

ASan/LSan instruments generated code and the custom runtime with leak detection enabled at O0/O1. The compiler, prebuilt Rust standard library, and Rust references are not sanitizer-instrumented. Historical exhaustive Unicode audits remain applicable by exact byte identity of the relevant implementation; they were not rerun over all code points for this change.

The scope remains the library's string API through a strict UTF-8 driver. It does not add a Python-callable extension module or general escaping iterators.

## Measurement and evidence

Compiler/runtime builds, full validation, timing, and final profiles all use the same clean source revision: **8b54eae6572a93926265d78562656dd395ad28b0**. Later report and documentation commits do not move those validation claims to a new source revision. The [build record](2026-10-20-luhn-performance-build.json) identifies exact source, tools, commands, archives, and executables.

Measurements ran on an AMD EPYC-Milan host pinned to CPU 0, outside ptrace tracing. CPython 3.14.5 uses PGO/LTO, with the GIL enabled and JIT disabled. Relar uses Clang 18 at O3; the independent Rust reference uses Ohm 1.98.1-1, rustc 1.98.1-dev, and LLVM 22.1.8.

Timing includes startup, imports, one input read, repeated unchanged-library calls, checksum accumulation, one final complete output write, and exit. Preparation, compilation, hashing, and verification are outside the clock. OS caches are warm; output is not fsynced. Task-owned builds, tests, profiles, and audit sweeps were paused during measurement. Unrelated shared-host activity and frequency remain uncontrolled.

The records retain **2,184 executions: 1,248 measured, 832 warmups, and 104 correctness gates**, including empty-input controls. The independent [benchmark audit](2026-10-20-luhn-performance-benchmark-audit.json) recomputes summaries and ratios, checks order balance and complete results, and verifies source/build/tool/binary identities.

Exploratory candidates are retained separately from final evidence. Forced LLVM vectorization metadata improved some large-input exploratory timings but produced missed-transformation warnings in supported configurations, so it was removed. The final implementation does not suppress those diagnostics or force that transformation. A subsequent matrix exposed unsupported variadic printing in a new test fixture; the fixture was corrected and the complete final matrix rerun. Both unsuccessful matrices remain in the evidence archive. A runtime inlining experiment did not improve latency and was also excluded. An earlier exploratory build reused an uncommitted runtime through the shared build cache; that mixed-source run is excluded from performance claims. Final builds require fresh compiler invocations from the canonical checkout and bind copied artifacts to those invocations.

Raw records: [ordinary linking](2026-10-20-luhn-performance-normal.json.gz), [ThinLTO](2026-10-20-luhn-performance-thinlto.json.gz), [validation index](2026-10-20-luhn-performance-validation.json), [short profile](2026-10-20-luhn-performance-short-profile.json), and [large profile](2026-10-20-luhn-performance-large-profile.json). The [profile attribution](2026-10-20-luhn-performance-profile-analysis.json) and independent [short](2026-10-20-luhn-performance-short-profile-audit.json)/[large](2026-10-20-luhn-performance-large-profile-audit.json) audits bind interpretation to the raw counters and exact timed binaries.

The [evidence archive](2026-10-20-luhn-performance-evidence.tar.gz) and [member manifest](2026-10-20-luhn-performance-evidence-manifest.json) retain measured sources, emitted LLVM, logs, raw timings and outputs, profiles, audits, and reproduction helpers. Native binaries, runtime archives, interpreters, and toolchains remain external and hash-identified. The previous immutable archive is linked and hashed without nesting it. Original commands retain host-specific paths; the [example guide](../../examples/luhn_checksum/README.md) and [Rust reference guide](../reference/luhn_checksum/README.md) provide portable entrypoints.
