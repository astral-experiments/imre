"""Point the usage guides at the audited optimization report."""

import json
from pathlib import Path


def main():
    root = Path("/home/dev-user/code/oss/relar")
    metrics = json.loads(Path("/tmp/relar-luhn-performance-tables.json").read_text())
    thin = metrics["families"]["thinlto"]
    large = thin["rust_by_size"]["4096"]
    short = thin["rust_by_size"]["16"]
    rows = [row for row in thin["rows"] if row["digits"] == 4096]
    speedups = [row["baseline_over_relar"] for row in rows]
    pythons = [row["cpython_over_relar"] for row in rows]

    example = root / "examples/luhn_checksum/README.md"
    old = """The [recorded comparison](../../benchmarks/results/2026-10-20-luhn.md) passes the
upstream tests and 1,144 CPython differential cases in each of five native
configurations. ThinLTO Relar runs 1.60–1.69× faster than CPython but takes
28.9–51.4× the streaming Rust reference's time. The report includes raw timings,
allocation and instruction profiles, validation evidence, and reproduction
metadata."""
    new = f"""The [optimization report](../../benchmarks/results/2026-10-20-luhn-performance.md)
keeps the library unchanged and passes the upstream tests and 1,144 CPython
differential cases in each of five native configurations. With ThinLTO,
4,096-digit calls take {large[0]:.2f}–{large[1]:.2f}× the streaming Rust reference's time and run
{min(speedups):.1f}–{max(speedups):.1f}× faster than the previous Relar build. Short 16-digit calls still
take {short[0]:.2f}–{short[1]:.2f}× Rust's time. The report includes both linking modes, CPython and
preserved-Relar comparisons, allocation/instruction profiles, and audited raw
evidence."""
    text = example.read_text()
    assert text.count(old) == 1
    example.write_text(text.replace(old, new))

    guide = root / "benchmarks/README.md"
    text = guide.read_text()
    old = "The [recorded Luhn comparison](results/2026-10-20-luhn.md) covers all four APIs with ordinary and matched ThinLTO builds. ThinLTO Relar runs 1.60–1.69× faster than CPython and takes 28.9–51.4× the streaming Rust reference's time. Profiles identify character construction, parsing, and destruction as 49.45% of instructions in the checksum workload; temporary `divmod` pair allocation accounts for another 10.71%. The report retains all 1,482 measured, warmup, and correctness-gate executions, independent audits, and the complete local validation matrix."
    new = (
        "The [Luhn optimization report](results/2026-10-20-luhn-performance.md) compares unchanged upstream code with CPython, the preserved Relar executable, and the independent streaming Rust reference. "
        f"With ThinLTO, 4,096-digit calls take {large[0]:.2f}–{large[1]:.2f}× Rust's time, improve {min(speedups):.1f}–{max(speedups):.1f}× over the previous Relar build, and run {min(pythons):.1f}–{max(pythons):.1f}× faster than CPython. "
        f"Short 16-digit calls still take {short[0]:.2f}–{short[1]:.2f}× Rust's time. "
        "Bulk conversion, scalar tuple sums, fused consumers, guarded native reductions, and bounded storage reuse remove the dominant intermediate allocations. "
        "The report retains ordinary and ThinLTO results, all 2,184 process executions, short/large profiles, and independent audits of the frozen build and full validation matrix. "
        "The [original compatibility report](results/2026-10-20-luhn.md) retains the earlier baseline."
    )
    assert text.count(old) == 1
    guide.write_text(text.replace(old, new))


if __name__ == "__main__":
    main()
