#!/bin/sh
set -eu

profile_python=/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14

"$profile_python" -I -B /tmp/relar-luhn-performance-profile.py \
  --record /tmp/relar-luhn-performance-v1-thinlto.json \
  --relar-build-record /tmp/relar-luhn-performance-validation-v3/build.json \
  --timing-status /tmp/relar-luhn-performance-v1-timing-status.json \
  --output /tmp/relar-luhn-performance-short-profile \
  --label checksum-16 --digits 16 --repetitions 65536

"$profile_python" -I -B /tmp/relar-luhn-performance-profile.py \
  --record /tmp/relar-luhn-performance-v1-thinlto.json \
  --relar-build-record /tmp/relar-luhn-performance-validation-v3/build.json \
  --timing-status /tmp/relar-luhn-performance-v1-timing-status.json \
  --output /tmp/relar-luhn-performance-large-profile \
  --label checksum-4096 --digits 4096 --repetitions 64

"$profile_python" -I -B /tmp/relar-luhn-performance-profile-audit.py \
  --profile-dir /tmp/relar-luhn-performance-short-profile \
  --timing-prefix /tmp/relar-luhn-performance-v1 \
  --validation-index /tmp/relar-luhn-performance-validation-v3/index.json \
  --label checksum-16 --digits 16 --repetitions 65536 \
  --output /tmp/relar-luhn-performance-short-profile-audit.json

"$profile_python" -I -B /tmp/relar-luhn-performance-profile-audit.py \
  --profile-dir /tmp/relar-luhn-performance-large-profile \
  --timing-prefix /tmp/relar-luhn-performance-v1 \
  --validation-index /tmp/relar-luhn-performance-validation-v3/index.json \
  --label checksum-4096 --digits 4096 --repetitions 64 \
  --output /tmp/relar-luhn-performance-large-profile-audit.json
