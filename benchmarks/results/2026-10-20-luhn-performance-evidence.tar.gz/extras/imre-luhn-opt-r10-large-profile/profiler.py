"""Profile frozen short Luhn calls; collect instructions/allocations, not timings."""

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys

BASE = Path("/tmp/imre-luhn-opt-r3")
OUT = Path("/tmp/imre-luhn-opt-r3-short-profile")
INPUT = Path("/tmp/imre-luhn-opt-r3-timing/input-16")
BASELINE = Path("/tmp/imre-luhn-v2-thinlto.json")
PARSER = Path("/tmp/imre-luhn-profile.py")
CACHE = Path("/home/dev-user/.cache/imre/profiling-tools/root/usr")
REPETITIONS = 65536


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    global BASE, OUT, INPUT, REPETITIONS
    parser = argparse.ArgumentParser()
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--digits", type=int, choices=(16, 4096), required=True)
    parser.add_argument("--repetitions", type=int, required=True)
    args = parser.parse_args()
    BASE, OUT, INPUT, REPETITIONS = args.build, args.output, args.input, args.repetitions
    require(REPETITIONS == (65536 if args.digits == 16 else 64), "unexpected workload repetitions")
    tracer = next(
        line for line in Path("/proc/self/status").read_text().splitlines()
        if line.startswith("TracerPid:")
    )
    require(int(tracer.split(":")[1]) == 0, "run Valgrind outside the ptrace sandbox")
    require(not OUT.exists(), "profile output must be fresh")
    build_path = BASE / "exploratory-build.json"
    build = json.loads(build_path.read_text())
    baseline = json.loads(BASELINE.read_text())
    validation = json.loads((BASE / "validation.json").read_text())
    for name, expected in build["sha256"].items():
        require(sha(BASE / name) == expected, f"frozen build artifact changed: {name}")
    validation_command = build["commands"][-1]["command"]
    rust = Path(validation_command[validation_command.index("--rust") + 1])
    rust_record_path = rust.parent / "build-record.json"
    rust_record = json.loads(rust_record_path.read_text())
    binaries = {"imre": BASE / "luhn", "rust": rust}
    for name, binary in binaries.items():
        require(sha(binary) == validation[name]["binary_sha256"],
                f"{name} binary does not match validation")
    require(rust_record["input_guards_passed"] and rust_record["thinlto"]
            and sha(rust) == rust_record["binary_sha256"], "Rust build provenance mismatch")
    workload, = [item for item in baseline["workloads"] if item["label"] == f"checksum-{args.digits}"]
    payload = INPUT.read_bytes()
    require(len(payload) == args.digits, "unexpected input length")
    require(payload == base64.b64decode(workload["input_base64"], validate=True)
            and sha(INPUT) == workload["input_sha256"], "baseline input mismatch")
    expected = base64.b64decode(workload["expected_output_base64"], validate=True)
    total = 0
    for index, byte in enumerate(reversed(payload)):
        require(48 <= byte <= 57, "expected ASCII digits")
        digit = (byte - 48) * (2 if index % 2 else 1)
        total += digit - (9 if digit > 9 else 0)
    checksum = total % 10
    require(expected == str(checksum).encode()
            and workload["expected_stdout"] == f"OK\n{checksum * workload['repetitions']}\n",
            "independent checksum disagrees with baseline oracle")
    expected_stdout = f"OK\n{checksum * REPETITIONS}\n".encode()
    library = CACHE / "libexec/valgrind"
    tools = {
        "valgrind": CACHE / "bin/valgrind",
        "valgrind_binary": CACHE / "bin/valgrind.bin",
        "callgrind": library / "callgrind-amd64-linux",
        "dhat": library / "dhat-amd64-linux",
        "core_preload": library / "vgpreload_core-amd64-linux.so",
        "dhat_preload": library / "vgpreload_dhat-amd64-linux.so",
        "annotate": CACHE / "bin/callgrind_annotate",
        "objdump": Path("/usr/bin/objdump"),
        "python": Path(sys.executable).resolve(),
    }
    inputs = {
        **binaries, **tools, "input": INPUT, "baseline_record": BASELINE,
        "build": build_path, "validation": BASE / "validation.json",
        "llvm": BASE / "luhn.ll", "rust_build": rust_record_path,
        "parser": PARSER, "script": Path(__file__),
    }
    guarded = {name: {"path": str(path), "sha256": sha(path)} for name, path in inputs.items()}

    def guard():
        require(all(sha(inputs[name]) == record["sha256"] for name, record in guarded.items()),
                "a frozen profiling input changed")

    parsers = runpy.run_path(str(PARSER))
    OUT.mkdir()
    binary_directory = OUT / "binaries"
    binary_directory.mkdir()
    frozen_binaries = {}
    for engine, source in binaries.items():
        target = binary_directory / engine
        shutil.copy2(source, target)
        require(sha(target) == guarded[engine]["sha256"], "binary copy hash mismatch")
        frozen_binaries[engine] = target
        inputs[f"frozen_{engine}"] = target
        guarded[f"frozen_{engine}"] = {"path": str(target), "sha256": sha(target)}
    for name, source in {
        "build.json": build_path, "baseline.json": BASELINE,
        "validation.json": BASE / "validation.json", "native.ll": BASE / "luhn.ll",
        "rust-build.json": rust_record_path, "profiler.py": Path(__file__),
        "metrics-parser.py": PARSER,
    }.items():
        shutil.copyfile(source, OUT / name)
    env = {**os.environ, "VALGRIND_LIB": str(library), "VALGRIND_OPTS": "", "LC_ALL": "C"}
    result = {
        "status": "running", "complete": False, "input_guards_passed": False,
        "revision": build["revision"], "started_at_utc": now(),
        "digits": len(payload), "repetitions": REPETITIONS,
        "checksum_per_call": checksum, "expected_stdout": expected_stdout.decode(),
        "expected_output_hex": expected.hex(), "guarded_inputs": guarded,
        "method": f"Whole-process Callgrind guest instructions and DHAT requested heap bytes/blocks. Includes startup, input/protocol work, and {REPETITIONS} exact {args.digits}-digit checksum calls. No wall-time benchmark samples. Self instruction costs partition totals; inclusive costs overlap.",
        "profiles": [],
    }
    write(OUT / "summary.json", result)
    try:
        for engine, binary in frozen_binaries.items():
            for tool in ("callgrind", "dhat"):
                guard()
                directory = OUT / f"{engine}-{tool}"
                directory.mkdir()
                source, output = directory / "input.bin", directory / "output.bin"
                source.write_bytes(payload)
                profile = directory / ("profile.callgrind" if tool == "callgrind" else "profile.json")
                command = [
                    str(tools["valgrind"]), f"--tool={tool}", "--command-line-only=yes",
                    "--num-callers=32", "--error-exitcode=97",
                    f"--log-file={directory / 'valgrind.log'}",
                    f"--{tool}-out-file={profile}",
                ]
                if tool == "callgrind":
                    command.extend(["--dump-instr=yes", "--collect-jumps=yes"])
                command.extend([str(binary), "checksum", str(source), str(output), str(REPETITIONS)])
                item = {"engine": engine, "tool": tool, "command": command,
                        "cwd": str(directory), "started_at_utc": now(),
                        "binary_sha256": sha(binary), "input_sha256": sha(source)}
                write(directory / "command.json", item)
                process = subprocess.run(command, input=b"", capture_output=True, cwd=directory,
                                         env=env, timeout=600, check=False)
                (directory / "stdout.txt").write_bytes(process.stdout)
                (directory / "stderr.txt").write_bytes(process.stderr)
                item.update(returncode=process.returncode, completed_at_utc=now())
                write(directory / "command.json", item)
                require(process.returncode == 0 and not process.stderr, f"{engine}/{tool} failed")
                require(process.stdout == expected_stdout and output.read_bytes() == expected
                        and source.read_bytes() == payload, f"{engine}/{tool} output mismatch")
                item["metrics"] = parsers[f"{tool}_metrics"](profile)
                if tool == "callgrind":
                    for inclusive in ("no", "yes"):
                        command = [str(tools["annotate"]), "--auto=no",
                                   f"--inclusive={inclusive}", "--threshold=100", str(profile)]
                        annotated = subprocess.run(command, capture_output=True, env=env, check=True)
                        (directory / f"inclusive-{inclusive}.txt").write_bytes(annotated.stdout)
                        (directory / f"inclusive-{inclusive}-stderr.txt").write_bytes(annotated.stderr)
                item["status"] = "validated"
                item["files"] = {path.name: sha(path) for path in sorted(directory.iterdir())}
                result["profiles"].append(item)
                guard()
                write(OUT / "summary.json", result)
                print(f"Validated {engine}/{tool}", flush=True)
        assembly = subprocess.run(
            [str(tools["objdump"]), "-d", "--no-show-raw-insn", "--disassemble=fn_3",
             str(frozen_binaries["imre"])], capture_output=True, check=True,
        )
        (OUT / "fn_3.asm").write_bytes(assembly.stdout)
        guard()
        result.update(status="passed", complete=True, input_guards_passed=True, completed_at_utc=now())
        write(OUT / "summary.json", result)
        write(OUT / "manifest.json", {str(path.relative_to(OUT)): sha(path)
              for path in sorted(OUT.rglob("*")) if path.is_file()})
        print(OUT / "summary.json", flush=True)
    except BaseException as error:
        result.update(status="failed", failure=f"{type(error).__name__}: {error}")
        write(OUT / "summary.json", result)
        raise


if __name__ == "__main__":
    main()
