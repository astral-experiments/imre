
/tmp/imre-luhn-opt-r10-large-profile/binaries/imre:     file format elf64-x86-64


Disassembly of section .text:

0000000000105cc0 <fn_3>:
  105cc0:	push   %rbp
  105cc1:	push   %r15
  105cc3:	push   %r14
  105cc5:	push   %r13
  105cc7:	push   %r12
  105cc9:	push   %rbx
  105cca:	sub    $0x38,%rsp
  105cce:	addr32 call 118920 <imre_str_int_list>
  105cd4:	mov    %rax,%r14
  105cd7:	xor    %edi,%edi
  105cd9:	call   1269c0 <_RNvYNCNKNvNtNtCs5N6zm3e4tnE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.9386496012789977245>
  105cde:	mov    $0x1,%ebp
  105ce3:	cmpb   $0x0,(%rax)
  105ce6:	jne    10613a <fn_3+0x47a>
  105cec:	mov    %rax,%rbx
  105cef:	mov    %r14,%rdi
  105cf2:	mov    $0xffffffffffffffff,%rsi
  105cf9:	xor    %edx,%edx
  105cfb:	mov    $0xfffffffffffffffd,%rcx
  105d02:	addr32 call 117c00 <imre_list_slice_sum>
  105d08:	cmpb   $0x0,(%rbx)
  105d0b:	jne    10613f <fn_3+0x47f>
  105d11:	test   %r14,%r14
  105d14:	je     105d20 <fn_3+0x60>
  105d16:	incq   -0x10(%r14)
  105d1a:	je     106138 <fn_3+0x478>
  105d20:	mov    %rbx,0x30(%rsp)
  105d25:	mov    %rax,0x8(%rsp)
  105d2a:	movabs $0xc000000000000000,%r15
  105d34:	mov    0x10(%r14),%rax
  105d38:	lea    (%rax,%rax,1),%r12
  105d3c:	movabs $0x666666666666666,%rcx
  105d46:	cmp    %rcx,%rax
  105d49:	jae    105e36 <fn_3+0x176>
  105d4f:	mov    $0x1,%r13d
  105d55:	cmp    $0x2,%rax
  105d59:	jb     105f3e <fn_3+0x27e>
  105d5f:	movabs $0x7fffffffffffffe6,%rbx
  105d69:	inc    %r12
  105d6c:	add    $0x10,%rbx
  105d70:	movabs $0x6f2074756f207865,%rsi
  105d7a:	movabs $0xd765676e61722066,%rdi
  105d84:	movabs $0x646e69207473696c,%r8
  105d8e:	lea    0x10(%rsp),%rbp
  105d93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  105da0:	add    $0xfffffffffffffffc,%r12
  105da4:	mov    %r12,%rax
  105da7:	shr    $1,%rax
  105daa:	cmp    0x10(%r14),%rax
  105dae:	jae    105dea <fn_3+0x12a>
  105db0:	mov    0x8(%r14),%rcx
  105db4:	mov    (%rcx,%rax,8),%rax
  105db8:	test   %rax,%rax
  105dbb:	je     105e2e <fn_3+0x16e>
  105dbd:	mov    %eax,%ecx
  105dbf:	and    $0x1e,%ecx
  105dc2:	xor    %edx,%edx
  105dc4:	cmp    $0xa,%rax
  105dc8:	setae  %dl
  105dcb:	mov    $0x0,%eax
  105dd0:	cmovae %rbx,%rax
  105dd4:	add    %rcx,%rax
  105dd7:	or     %rax,%rdx
  105dda:	lea    0x0(%r13,%rdx,2),%r13
  105ddf:	cmp    $0x4,%r12
  105de3:	jg     105da0 <fn_3+0xe0>
  105de5:	jmp    105f3e <fn_3+0x27e>
  105dea:	mov    %rsi,0x18(%rsp)
  105def:	mov    %rdi,0x20(%rsp)
  105df4:	mov    %r8,0x10(%rsp)
  105df9:	movl   $0x6,0x28(%rsp)
  105e01:	mov    %rbp,%rdi
  105e04:	xor    %esi,%esi
  105e06:	call   1244b0 <_RINvMs0_NtNtCs5N6zm3e4tnE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  105e0b:	movabs $0x6f2074756f207865,%rsi
  105e15:	movabs $0xd765676e61722066,%rdi
  105e1f:	movabs $0x646e69207473696c,%r8
  105e29:	test   %rax,%rax
  105e2c:	jne    105dbd <fn_3+0xfd>
  105e2e:	mov    %r13,%rbp
  105e31:	jmp    10610a <fn_3+0x44a>
  105e36:	inc    %r12
  105e39:	mov    $0x1,%ebp
  105e3e:	lea    0x57fb(%rip),%rbx        # 10b640 <imre_int_binary>
  105e45:	jmp    105e5d <fn_3+0x19d>
  105e47:	lea    0x1(,%rax,2),%r13
  105e4f:	nop
  105e50:	mov    %r13,%rbp
  105e53:	cmp    $0x4,%r12
  105e57:	jbe    105f3e <fn_3+0x27e>
  105e5d:	add    $0xfffffffffffffffc,%r12
  105e61:	mov    %r12,%rax
  105e64:	shr    $1,%rax
  105e67:	cmp    0x10(%r14),%rax
  105e6b:	jae    105ef8 <fn_3+0x238>
  105e71:	mov    0x8(%r14),%rcx
  105e75:	mov    (%rcx,%rax,8),%rax
  105e79:	test   %rax,%rax
  105e7c:	je     106107 <fn_3+0x447>
  105e82:	mov    %eax,%edx
  105e84:	and    $0x1e,%edx
  105e87:	lea    -0xa(%rdx),%rsi
  105e8b:	xor    %ecx,%ecx
  105e8d:	cmp    $0xa,%rax
  105e91:	setae  %cl
  105e94:	cmovb  %rdx,%rsi
  105e98:	or     %rsi,%rcx
  105e9b:	test   $0x1,%bpl
  105e9f:	je     105eb2 <fn_3+0x1f2>
  105ea1:	mov    %rbp,%rax
  105ea4:	sar    $1,%rax
  105ea7:	add    %rcx,%rax
  105eaa:	mov    %rax,%rdx
  105ead:	add    %r15,%rdx
  105eb0:	js     105e47 <fn_3+0x187>
  105eb2:	lea    0x1(,%rcx,2),%rsi
  105eba:	mov    %rbp,%rdi
  105ebd:	xor    %edx,%edx
  105ebf:	call   *%rbx
  105ec1:	mov    %rax,%r13
  105ec4:	test   %rbp,%rbp
  105ec7:	sete   %al
  105eca:	or     %bpl,%al
  105ecd:	test   $0x1,%al
  105ecf:	jne    105e50 <fn_3+0x190>
  105ed5:	lea    -0x10(%rbp),%rax
  105ed9:	mov    %rax,0x10(%rsp)
  105ede:	decq   -0x10(%rbp)
  105ee2:	jne    105e50 <fn_3+0x190>
  105ee8:	lea    0x10(%rsp),%rdi
  105eed:	addr32 call 120230 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  105ef3:	jmp    105e50 <fn_3+0x190>
  105ef8:	movabs $0x6f2074756f207865,%rax
  105f02:	mov    %rax,0x18(%rsp)
  105f07:	movabs $0xd765676e61722066,%rax
  105f11:	mov    %rax,0x20(%rsp)
  105f16:	movabs $0x646e69207473696c,%rax
  105f20:	mov    %rax,0x10(%rsp)
  105f25:	movl   $0x6,0x28(%rsp)
  105f2d:	lea    0x10(%rsp),%rdi
  105f32:	xor    %esi,%esi
  105f34:	call   1244b0 <_RINvMs0_NtNtCs5N6zm3e4tnE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  105f39:	jmp    105e79 <fn_3+0x1b9>
  105f3e:	lea    -0x10(%r14),%rax
  105f42:	mov    %rax,0x10(%rsp)
  105f47:	decq   -0x10(%r14)
  105f4b:	jne    105f58 <fn_3+0x298>
  105f4d:	lea    0x10(%rsp),%rdi
  105f52:	addr32 call 11f5c0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs5N6zm3e4tnE_12imre_runtime4ListE9drop_slowBF_>
  105f58:	test   %r13,%r13
  105f5b:	sete   %al
  105f5e:	or     %r13b,%al
  105f61:	test   $0x1,%al
  105f63:	mov    0x8(%rsp),%rbp
  105f68:	je     105f6f <fn_3+0x2af>
  105f6a:	mov    %r13,%r12
  105f6d:	jmp    105f9c <fn_3+0x2dc>
  105f6f:	incq   -0x10(%r13)
  105f73:	mov    %r13,%r12
  105f76:	je     106138 <fn_3+0x478>
  105f7c:	test   $0x1,%r13b
  105f80:	jne    105f9c <fn_3+0x2dc>
  105f82:	lea    -0x10(%r13),%rax
  105f86:	mov    %rax,0x10(%rsp)
  105f8b:	decq   -0x10(%r13)
  105f8f:	jne    105f9c <fn_3+0x2dc>
  105f91:	lea    0x10(%rsp),%rdi
  105f96:	addr32 call 120230 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  105f9c:	mov    0x30(%rsp),%rax
  105fa1:	cmpb   $0x0,(%rax)
  105fa4:	jne    106144 <fn_3+0x484>
  105faa:	mov    %ebp,%ebx
  105fac:	and    $0x1,%ebx
  105faf:	test   %ebx,%r12d
  105fb2:	je     105fc8 <fn_3+0x308>
  105fb4:	mov    %rbp,%rcx
  105fb7:	sar    $1,%rcx
  105fba:	mov    %r12,%rax
  105fbd:	sar    $1,%rax
  105fc0:	add    %rcx,%rax
  105fc3:	add    %rax,%r15
  105fc6:	js     105ff7 <fn_3+0x337>
  105fc8:	mov    %rbp,%rdi
  105fcb:	mov    %r12,%rsi
  105fce:	xor    %edx,%edx
  105fd0:	addr32 call 10b640 <imre_int_binary>
  105fd6:	mov    %rax,%rbp
  105fd9:	test   $0x1,%bpl
  105fdd:	jne    106005 <fn_3+0x345>
  105fdf:	mov    $0x15,%esi
  105fe4:	mov    %rbp,%rdi
  105fe7:	mov    $0x4,%edx
  105fec:	addr32 call 10b640 <imre_int_binary>
  105ff2:	mov    %rax,%r13
  105ff5:	jmp    106048 <fn_3+0x388>
  105ff7:	lea    0x1(,%rax,2),%rbp
  105fff:	test   $0x1,%bpl
  106003:	je     105fdf <fn_3+0x31f>
  106005:	mov    %rbp,%rcx
  106008:	sar    $1,%rcx
  10600b:	movabs $0x6666666666666667,%rdx
  106015:	mov    %rcx,%rax
  106018:	imul   %rdx
  10601b:	mov    %rdx,%rax
  10601e:	shr    $0x3f,%rax
  106022:	sar    $0x2,%rdx
  106026:	add    %rax,%rdx
  106029:	add    %rdx,%rdx
  10602c:	lea    (%rdx,%rdx,4),%rax
  106030:	sub    %rax,%rcx
  106033:	mov    %rcx,%rax
  106036:	sar    $0x3f,%rax
  10603a:	and    $0xa,%eax
  10603d:	add    %rcx,%rax
  106040:	lea    0x1(,%rax,2),%r13
  106048:	test   %rbp,%rbp
  10604b:	sete   %al
  10604e:	or     %bpl,%al
  106051:	mov    0x30(%rsp),%rcx
  106056:	cmpb   $0x0,(%rcx)
  106059:	jne    10614c <fn_3+0x48c>
  10605f:	test   $0x1,%al
  106061:	jne    10607d <fn_3+0x3bd>
  106063:	lea    -0x10(%rbp),%rax
  106067:	mov    %rax,0x10(%rsp)
  10606c:	decq   -0x10(%rbp)
  106070:	jne    10607d <fn_3+0x3bd>
  106072:	lea    0x10(%rsp),%rdi
  106077:	addr32 call 120230 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  10607d:	mov    %r14,%rax
  106080:	add    $0xfffffffffffffff0,%rax
  106084:	mov    %rax,0x10(%rsp)
  106089:	decq   -0x10(%r14)
  10608d:	jne    10609a <fn_3+0x3da>
  10608f:	lea    0x10(%rsp),%rdi
  106094:	addr32 call 11f5c0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs5N6zm3e4tnE_12imre_runtime4ListE9drop_slowBF_>
  10609a:	mov    0x8(%rsp),%rcx
  10609f:	test   %rcx,%rcx
  1060a2:	sete   %al
  1060a5:	or     %bl,%al
  1060a7:	jne    1060c6 <fn_3+0x406>
  1060a9:	mov    %rcx,%rax
  1060ac:	add    $0xfffffffffffffff0,%rax
  1060b0:	mov    %rax,0x10(%rsp)
  1060b5:	decq   -0x10(%rcx)
  1060b9:	jne    1060c6 <fn_3+0x406>
  1060bb:	lea    0x10(%rsp),%rdi
  1060c0:	addr32 call 120230 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  1060c6:	test   %r12,%r12
  1060c9:	sete   %al
  1060cc:	or     %r12b,%al
  1060cf:	test   $0x1,%al
  1060d1:	jne    1060f5 <fn_3+0x435>
  1060d3:	test   $0x1,%r12b
  1060d7:	jne    1060f5 <fn_3+0x435>
  1060d9:	lea    -0x10(%r12),%rax
  1060de:	mov    %rax,0x10(%rsp)
  1060e3:	decq   -0x10(%r12)
  1060e8:	jne    1060f5 <fn_3+0x435>
  1060ea:	lea    0x10(%rsp),%rdi
  1060ef:	addr32 call 120230 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  1060f5:	mov    %r13,%rax
  1060f8:	add    $0x38,%rsp
  1060fc:	pop    %rbx
  1060fd:	pop    %r12
  1060ff:	pop    %r13
  106101:	pop    %r14
  106103:	pop    %r15
  106105:	pop    %rbp
  106106:	ret
  106107:	mov    %rbp,%r13
  10610a:	mov    %r14,%rdi
  10610d:	addr32 call 111340 <imre_list_release>
  106113:	test   $0x1,%bpl
  106117:	sete   %al
  10611a:	test   %rbp,%rbp
  10611d:	setne  %cl
  106120:	mov    $0x1,%r12d
  106126:	test   %al,%cl
  106128:	mov    0x8(%rsp),%rbp
  10612d:	jne    105f7c <fn_3+0x2bc>
  106133:	jmp    105f9c <fn_3+0x2dc>
  106138:	ud2
  10613a:	xor    %r14d,%r14d
  10613d:	jmp    106144 <fn_3+0x484>
  10613f:	mov    $0x1,%ebp
  106144:	mov    $0x1,%r12d
  10614a:	jmp    10615e <fn_3+0x49e>
  10614c:	test   $0x1,%al
  10614e:	jne    106159 <fn_3+0x499>
  106150:	mov    %rbp,%rdi
  106153:	addr32 call 110920 <imre_int_release>
  106159:	mov    0x8(%rsp),%rbp
  10615e:	mov    %r14,%rdi
  106161:	addr32 call 111340 <imre_list_release>
  106167:	test   %rbp,%rbp
  10616a:	sete   %al
  10616d:	or     %bpl,%al
  106170:	test   $0x1,%al
  106172:	jne    10617d <fn_3+0x4bd>
  106174:	mov    %rbp,%rdi
  106177:	addr32 call 110920 <imre_int_release>
  10617d:	test   %r12,%r12
  106180:	sete   %al
  106183:	or     %r12b,%al
  106186:	mov    $0x1,%r13d
  10618c:	test   $0x1,%al
  10618e:	je     1060d3 <fn_3+0x413>
  106194:	jmp    1060f5 <fn_3+0x435>
  106199:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10619f:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1061a5:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1061ab:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1061b1:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1061b7:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1061bd:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1061c3:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1061c9:	addr32 call eab73 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
