"""Copy completed, reviewed evidence into the documentation child branch."""

import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path


def main():
    root = Path("/home/dev-user/code/oss/imre")
    # Guard the validated parent before copying the report and evidence.
    index = json.loads(
        Path("/tmp/imre-luhn-performance-validation-v3/index.json").read_text()
    )
    parent = index["revision"]
    assert parent == "8b54eae6572a93926265d78562656dd395ad28b0"
    assert (
        subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, text=True
        ).strip()
        == parent
    )
    branch = subprocess.check_output(
        ["git", "branch", "--show-current"], cwd=root, text=True
    ).strip()
    assert branch == "charlie/codex-luhn-performance-benchmarks"
    destination = root / "benchmarks/results"
    prefix = "2026-10-20-luhn-performance"
    report = Path("/tmp/imre-luhn-performance-report.md")
    assert "@@" not in report.read_text()
    sources = {
        ".md": report,
        "-build.json": Path("/tmp/imre-luhn-performance-validation-v3/build.json"),
        "-validation.json": Path("/tmp/imre-luhn-performance-validation-v3/index.json"),
        "-validation-audit.json": Path(
            "/tmp/imre-luhn-performance-validation-audit.json"
        ),
        "-benchmark-audit.json": Path(
            "/tmp/imre-luhn-performance-benchmark-audit.json"
        ),
        "-report-audit.json": Path("/tmp/imre-luhn-performance-report-audit.json"),
        "-timing-status.json": Path("/tmp/imre-luhn-performance-v1-timing-status.json"),
        "-short-profile.json": Path(
            "/tmp/imre-luhn-performance-short-profile/summary.json"
        ),
        "-large-profile.json": Path(
            "/tmp/imre-luhn-performance-large-profile/summary.json"
        ),
        "-short-profile-audit.json": Path(
            "/tmp/imre-luhn-performance-short-profile-audit.json"
        ),
        "-large-profile-audit.json": Path(
            "/tmp/imre-luhn-performance-large-profile-audit.json"
        ),
        "-profile-analysis.json": Path(
            "/tmp/imre-luhn-performance-profile-analysis.json"
        ),
        "-evidence.tar.gz": Path("/tmp/2026-10-20-luhn-performance-evidence.tar.gz"),
        "-evidence-manifest.json": Path(
            "/tmp/2026-10-20-luhn-performance-evidence-manifest.json"
        ),
        "-evidence-audit.json": Path("/tmp/imre-luhn-performance-evidence-audit.json"),
    }
    compressed = {
        f"-{mode}.json.gz": Path(f"/tmp/imre-luhn-performance-v1-{mode}.json")
        for mode in ("normal", "thinlto")
    }
    for suffix, source in {**sources, **compressed}.items():
        assert source.is_file(), source
        assert not (destination / (prefix + suffix)).exists(), suffix
    copied = {}
    for suffix, source in sources.items():
        target = destination / (prefix + suffix)
        shutil.copyfile(source, target)
        assert source.read_bytes() == target.read_bytes()
        copied[target.name] = hashlib.sha256(target.read_bytes()).hexdigest()
    for suffix, source in compressed.items():
        data = source.read_bytes()
        target = destination / (prefix + suffix)
        target.write_bytes(gzip.compress(data, compresslevel=9, mtime=0))
        assert gzip.decompress(target.read_bytes()) == data
        copied[target.name] = hashlib.sha256(target.read_bytes()).hexdigest()
    print(json.dumps(copied, indent=2))


if __name__ == "__main__":
    main()
