
/tmp/relar-luhn-performance-v1-thinlto/luhn:     file format elf64-x86-64


Disassembly of section .text:

0000000000118590 <relar_list_slice_sum>:
  118590:	push   %rbp
  118591:	push   %r15
  118593:	push   %r14
  118595:	push   %r13
  118597:	push   %r12
  118599:	push   %rbx
  11859a:	sub    $0x48,%rsp
  11859e:	mov    %rcx,%r8
  1185a1:	mov    %rdx,%rcx
  1185a4:	mov    %rsi,%rdx
  1185a7:	mov    0x8(%rdi),%rbp
  1185ab:	mov    0x10(%rdi),%r12
  1185af:	lea    0x10(%rsp),%rdi
  1185b4:	mov    %r12,%rsi
  1185b7:	call   117f70 <_RNvMNtNtCs5N6zm3e4tnE_12relar_runtime7objects9sequencesNtB2_12SliceIndices3new>
  1185bc:	mov    0x18(%rsp),%rbx
  1185c1:	mov    0x20(%rsp),%rcx
  1185c6:	mov    0x28(%rsp),%r14
  1185cb:	cmpb   $0x0,0x10(%rsp)
  1185d0:	je     1185e5 <relar_list_slice_sum+0x55>
  1185d2:	cmpl   $0xffffffff,0x30(%rsp)
  1185d7:	jne    1191ee <relar_list_slice_sum+0xc5e>
  1185dd:	mov    %rbx,%rax
  1185e0:	jmp    1191df <relar_list_slice_sum+0xc4f>
  1185e5:	mov    $0x1,%eax
  1185ea:	test   %r14,%r14
  1185ed:	je     1191df <relar_list_slice_sum+0xc4f>
  1185f3:	movzbl 0x30(%rsp),%eax
  1185f8:	cmp    $0x2,%rcx
  1185fc:	jbe    118709 <relar_list_slice_sum+0x179>
  118602:	mov    %rcx,%r15
  118605:	neg    %r15
  118608:	test   $0x1,%al
  11860a:	cmove  %rcx,%r15
  11860e:	cmp    $0x7fffffff,%r14
  118615:	ja     11866f <relar_list_slice_sum+0xdf>
  118617:	movabs $0x100000000,%rcx
  118621:	xor    %eax,%eax
  118623:	mov    %rbx,%rdi
  118626:	xor    %edx,%edx
  118628:	mov    %r14,%rsi
  11862b:	nopl   0x0(%rax,%rax,1)
  118630:	cmp    %r12,%rdi
  118633:	jae    119257 <relar_list_slice_sum+0xcc7>
  118639:	mov    0x0(%rbp,%rdi,8),%r8
  11863e:	mov    %r8d,%r9d
  118641:	not    %r9d
  118644:	mov    %r8,%r10
  118647:	sar    $1,%r10
  11864a:	add    %r10,%rax
  11864d:	add    %rcx,%r8
  118650:	shr    $0x21,%r8
  118654:	and    $0x1,%r9d
  118658:	or     %r9,%rdx
  11865b:	or     %r8,%rdx
  11865e:	add    %r15,%rdi
  118661:	dec    %rsi
  118664:	jne    118630 <relar_list_slice_sum+0xa0>
  118666:	test   %rdx,%rdx
  118669:	je     1188af <relar_list_slice_sum+0x31f>
  11866f:	mov    %rbp,(%rsp)
  118673:	mov    $0x1,%r13d
  118679:	lea    -0xc6d0(%rip),%rbp        # 10bfb0 <relar_int_binary>
  118680:	jmp    1186b6 <relar_list_slice_sum+0x126>
  118682:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  118690:	mov    %rbx,%rax
  118693:	mov    %r12,%rbx
  118696:	mov    %rbp,%r12
  118699:	mov    %r15,%rbp
  11869c:	mov    %r14,%r15
  11869f:	mov    0x8(%rsp),%r14
  1186a4:	dec    %r14
  1186a7:	add    %r15,%rbx
  1186aa:	mov    %rax,%r13
  1186ad:	test   %r14,%r14
  1186b0:	je     1191df <relar_list_slice_sum+0xc4f>
  1186b6:	mov    %r13,0x40(%rsp)
  1186bb:	cmp    %r12,%rbx
  1186be:	jae    119244 <relar_list_slice_sum+0xcb4>
  1186c4:	mov    (%rsp),%rax
  1186c8:	mov    (%rax,%rbx,8),%rsi
  1186cc:	mov    %r13,%rdi
  1186cf:	xor    %edx,%edx
  1186d1:	call   *%rbp
  1186d3:	test   $0x1,%r13b
  1186d7:	jne    1186a4 <relar_list_slice_sum+0x114>
  1186d9:	mov    %r14,0x8(%rsp)
  1186de:	mov    %r15,%r14
  1186e1:	mov    %rbp,%r15
  1186e4:	mov    %r12,%rbp
  1186e7:	mov    %rbx,%r12
  1186ea:	mov    %rax,%rbx
  1186ed:	lea    -0x10(%r13),%rax
  1186f1:	mov    %rax,0x10(%rsp)
  1186f6:	decq   -0x10(%r13)
  1186fa:	jne    118690 <relar_list_slice_sum+0x100>
  1186fc:	lea    0x10(%rsp),%rdi
  118701:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  118707:	jmp    118690 <relar_list_slice_sum+0x100>
  118709:	dec    %r14
  11870c:	mov    %r14,%rsi
  11870f:	imul   %rcx,%rsi
  118713:	test   $0x1,%al
  118715:	je     1187a5 <relar_list_slice_sum+0x215>
  11871b:	mov    %rbx,%rdi
  11871e:	sub    %rsi,%rdi
  118721:	cmp    %r12,%rbx
  118724:	jae    11922c <relar_list_slice_sum+0xc9c>
  11872a:	lea    0x1(%rbx),%rdx
  11872e:	mov    %rdx,%rax
  118731:	sub    %rdi,%rax
  118734:	jb     119231 <relar_list_slice_sum+0xca1>
  11873a:	lea    0x0(,%rdi,8),%r15
  118742:	add    %rbp,%r15
  118745:	cmp    $0x1,%rcx
  118749:	jne    11880e <relar_list_slice_sum+0x27e>
  11874f:	shl    $0x3,%rdi
  118753:	lea    0x0(,%rdx,8),%rax
  11875b:	mov    %rax,%rcx
  11875e:	sub    %rdi,%rcx
  118761:	shr    $0x22,%rcx
  118765:	jne    118f89 <relar_list_slice_sum+0x9f9>
  11876b:	cmp    %rdi,%rax
  11876e:	je     118804 <relar_list_slice_sum+0x274>
  118774:	lea    0x0(,%rdx,8),%rcx
  11877c:	add    %rbp,%rcx
  11877f:	movabs $0x1ffffffffffffffc,%rdx
  118789:	or     $0x3,%rdx
  11878d:	and    %rdx,%r14
  118790:	cmp    $0x3,%r14
  118794:	jae    118e10 <relar_list_slice_sum+0x880>
  11879a:	xor    %r12d,%r12d
  11879d:	xor    %r8d,%r8d
  1187a0:	jmp    118f3e <relar_list_slice_sum+0x9ae>
  1187a5:	add    %rbx,%rsi
  1187a8:	cmp    %r12,%rsi
  1187ab:	jae    11921a <relar_list_slice_sum+0xc8a>
  1187b1:	inc    %rsi
  1187b4:	mov    %rsi,%rdx
  1187b7:	sub    %rbx,%rdx
  1187ba:	jb     11921a <relar_list_slice_sum+0xc8a>
  1187c0:	lea    0x0(,%rbx,8),%r11
  1187c8:	add    %rbp,%r11
  1187cb:	shl    $0x3,%rbx
  1187cf:	cmp    $0x1,%rcx
  1187d3:	mov    %r11,(%rsp)
  1187d7:	jne    118861 <relar_list_slice_sum+0x2d1>
  1187dd:	shl    $0x3,%rsi
  1187e1:	mov    %rsi,%rax
  1187e4:	sub    %rbx,%rax
  1187e7:	mov    %rax,%r13
  1187ea:	shr    $0x3,%r13
  1187ee:	mov    %rax,%rcx
  1187f1:	shr    $0x22,%rcx
  1187f5:	jne    119146 <relar_list_slice_sum+0xbb6>
  1187fb:	cmp    %rbx,%rsi
  1187fe:	jne    1188cf <relar_list_slice_sum+0x33f>
  118804:	mov    $0x1,%eax
  118809:	jmp    1191df <relar_list_slice_sum+0xc4f>
  11880e:	mov    %eax,%r12d
  118811:	and    $0x1,%r12d
  118815:	lea    0x0(,%r12,8),%ecx
  11881d:	add    %rcx,%r15
  118820:	shr    $1,%rax
  118823:	mov    %rax,%r13
  118826:	shl    $0x4,%r13
  11882a:	lea    (%r12,%rax,1),%rdx
  11882e:	cmp    $0x7fffffff,%rdx
  118835:	ja     118aa7 <relar_list_slice_sum+0x517>
  11883b:	test   %rax,%rax
  11883e:	je     1188e4 <relar_list_slice_sum+0x354>
  118844:	lea    (%r15,%r13,1),%rdx
  118848:	lea    -0x10(%r13),%rdi
  11884c:	cmp    $0x30,%rdi
  118850:	jae    1188f8 <relar_list_slice_sum+0x368>
  118856:	xor    %r14d,%r14d
  118859:	xor    %r9d,%r9d
  11885c:	jmp    118a32 <relar_list_slice_sum+0x4a2>
  118861:	movabs $0xffffffffffffffe,%r10
  11886b:	and    %rdx,%r10
  11886e:	mov    %edx,%r14d
  118871:	and    $0x1,%r14d
  118875:	mov    %rdx,%r13
  118878:	shr    $1,%r13
  11887b:	lea    (%r14,%r13,1),%rax
  11887f:	cmp    $0x7fffffff,%rax
  118885:	ja     118d2b <relar_list_slice_sum+0x79b>
  11888b:	movabs $0x100000000,%rax
  118895:	test   %r13,%r13
  118898:	je     1188ef <relar_list_slice_sum+0x35f>
  11889a:	cmp    $0xa,%rdx
  11889e:	jae    118ba1 <relar_list_slice_sum+0x611>
  1188a4:	xor    %ecx,%ecx
  1188a6:	xor    %esi,%esi
  1188a8:	xor    %edx,%edx
  1188aa:	jmp    118cb8 <relar_list_slice_sum+0x728>
  1188af:	movabs $0x4000000000000000,%rcx
  1188b9:	add    %rax,%rcx
  1188bc:	js     11921f <relar_list_slice_sum+0xc8f>
  1188c2:	lea    0x1(,%rax,2),%rax
  1188ca:	jmp    1191df <relar_list_slice_sum+0xc4f>
  1188cf:	cmp    $0x20,%rax
  1188d3:	jae    119006 <relar_list_slice_sum+0xa76>
  1188d9:	xor    %eax,%eax
  1188db:	xor    %edx,%edx
  1188dd:	xor    %ecx,%ecx
  1188df:	jmp    119101 <relar_list_slice_sum+0xb71>
  1188e4:	xor    %r9d,%r9d
  1188e7:	xor    %r14d,%r14d
  1188ea:	jmp    118a70 <relar_list_slice_sum+0x4e0>
  1188ef:	xor    %edx,%edx
  1188f1:	xor    %ecx,%ecx
  1188f3:	jmp    118cfe <relar_list_slice_sum+0x76e>
  1188f8:	shr    $0x4,%rdi
  1188fc:	inc    %rdi
  1188ff:	mov    %rdi,%r8
  118902:	and    $0xfffffffffffffffc,%r8
  118906:	mov    %r8,%r9
  118909:	shl    $0x4,%r9
  11890d:	sub    %r9,%rdx
  118910:	lea    0x0(,%rbx,8),%r10
  118918:	add    %r13,%r10
  11891b:	add    %rcx,%r10
  11891e:	lea    0x0(,%rsi,8),%r9
  118926:	sub    %r9,%r10
  118929:	add    %rbp,%r10
  11892c:	add    $0xfffffffffffffff8,%r10
  118930:	pxor   %xmm0,%xmm0
  118934:	movdqa -0x10717c(%rip),%xmm3        # 117c0 <_IO_stdin_used+0x15c8>
  11893c:	movdqa -0x107a24(%rip),%xmm4        # 10f20 <_IO_stdin_used+0xd28>
  118944:	mov    %r8,%r9
  118947:	pxor   %xmm5,%xmm5
  11894b:	pxor   %xmm2,%xmm2
  11894f:	pxor   %xmm1,%xmm1
  118953:	movq   -0x10(%r10),%xmm6
  118959:	movq   (%r10),%xmm7
  11895e:	punpcklqdq %xmm6,%xmm7
  118962:	movq   -0x30(%r10),%xmm8
  118968:	movq   -0x20(%r10),%xmm6
  11896e:	punpcklqdq %xmm8,%xmm6
  118973:	pshufd $0xed,%xmm7,%xmm8
  118979:	psrad  $0x1,%xmm8
  11897f:	movdqa %xmm7,%xmm9
  118984:	psrlq  $0x1,%xmm9
  11898a:	pshufd $0xe8,%xmm9,%xmm9
  118990:	punpckldq %xmm8,%xmm9
  118995:	paddq  %xmm9,%xmm5
  11899a:	pshufd $0xed,%xmm6,%xmm8
  1189a0:	psrad  $0x1,%xmm8
  1189a6:	movdqa %xmm6,%xmm9
  1189ab:	psrlq  $0x1,%xmm9
  1189b1:	pshufd $0xe8,%xmm9,%xmm9
  1189b7:	punpckldq %xmm8,%xmm9
  1189bc:	paddq  %xmm9,%xmm0
  1189c1:	movdqa %xmm7,%xmm8
  1189c6:	paddq  %xmm4,%xmm8
  1189cb:	movdqa %xmm6,%xmm9
  1189d0:	paddq  %xmm4,%xmm9
  1189d5:	psrlq  $0x21,%xmm8
  1189db:	psrlq  $0x21,%xmm9
  1189e1:	pandn  %xmm3,%xmm7
  1189e5:	por    %xmm7,%xmm2
  1189e9:	por    %xmm8,%xmm2
  1189ee:	pandn  %xmm3,%xmm6
  1189f2:	por    %xmm6,%xmm1
  1189f6:	por    %xmm9,%xmm1
  1189fb:	add    $0xffffffffffffffc0,%r10
  1189ff:	add    $0xfffffffffffffffc,%r9
  118a03:	jne    118953 <relar_list_slice_sum+0x3c3>
  118a09:	paddq  %xmm5,%xmm0
  118a0d:	pshufd $0xee,%xmm0,%xmm3
  118a12:	paddq  %xmm0,%xmm3
  118a16:	movq   %xmm3,%r14
  118a1b:	por    %xmm2,%xmm1
  118a1f:	pshufd $0xee,%xmm1,%xmm0
  118a24:	por    %xmm1,%xmm0
  118a28:	movq   %xmm0,%r9
  118a2d:	cmp    %r8,%rdi
  118a30:	je     118a70 <relar_list_slice_sum+0x4e0>
  118a32:	movabs $0x100000000,%rdi
  118a3c:	mov    %r9,%r8
  118a3f:	nop
  118a40:	mov    -0x8(%rdx),%r10
  118a44:	add    $0xfffffffffffffff0,%rdx
  118a48:	mov    %r10d,%r9d
  118a4b:	not    %r9d
  118a4e:	mov    %r10,%r11
  118a51:	sar    $1,%r11
  118a54:	add    %r11,%r14
  118a57:	add    %rdi,%r10
  118a5a:	shr    $0x21,%r10
  118a5e:	or     %r8,%r10
  118a61:	and    $0x1,%r9d
  118a65:	or     %r10,%r9
  118a68:	mov    %r9,%r8
  118a6b:	cmp    %r15,%rdx
  118a6e:	jne    118a40 <relar_list_slice_sum+0x4b0>
  118a70:	test   %r12,%r12
  118a73:	je     118a9e <relar_list_slice_sum+0x50e>
  118a75:	mov    -0x8(%r15),%rdx
  118a79:	mov    %rdx,%rdi
  118a7c:	movabs $0x100000000,%r8
  118a86:	add    %rdx,%r8
  118a89:	not    %edx
  118a8b:	sar    $1,%rdi
  118a8e:	add    %rdi,%r14
  118a91:	shr    $0x21,%r8
  118a95:	and    $0x1,%edx
  118a98:	or     %r8,%rdx
  118a9b:	or     %rdx,%r9
  118a9e:	test   %r9,%r9
  118aa1:	je     118b81 <relar_list_slice_sum+0x5f1>
  118aa7:	mov    %r12,(%rsp)
  118aab:	mov    %r15,0x8(%rsp)
  118ab0:	test   %rax,%rax
  118ab3:	je     118b2e <relar_list_slice_sum+0x59e>
  118ab5:	lea    0x0(,%rbx,8),%rax
  118abd:	add    %r13,%rax
  118ac0:	add    %rcx,%rax
  118ac3:	shl    $0x3,%rsi
  118ac7:	sub    %rsi,%rax
  118aca:	add    %rax,%rbp
  118acd:	add    $0xfffffffffffffff8,%rbp
  118ad1:	neg    %r13
  118ad4:	mov    $0x1,%r15d
  118ada:	xor    %r14d,%r14d
  118add:	lea    -0xcb34(%rip),%r12        # 10bfb0 <relar_int_binary>
  118ae4:	jmp    118afc <relar_list_slice_sum+0x56c>
  118ae6:	cs nopw 0x0(%rax,%rax,1)
  118af0:	add    $0xfffffffffffffff0,%r14
  118af4:	mov    %rbx,%r15
  118af7:	cmp    %r14,%r13
  118afa:	je     118b33 <relar_list_slice_sum+0x5a3>
  118afc:	mov    0x0(%rbp,%r14,1),%rsi
  118b01:	mov    %r15,%rdi
  118b04:	xor    %edx,%edx
  118b06:	call   *%r12
  118b09:	mov    %rax,%rbx
  118b0c:	test   $0x1,%r15b
  118b10:	jne    118af0 <relar_list_slice_sum+0x560>
  118b12:	lea    -0x10(%r15),%rax
  118b16:	mov    %rax,0x10(%rsp)
  118b1b:	decq   -0x10(%r15)
  118b1f:	jne    118af0 <relar_list_slice_sum+0x560>
  118b21:	lea    0x10(%rsp),%rdi
  118b26:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  118b2c:	jmp    118af0 <relar_list_slice_sum+0x560>
  118b2e:	mov    $0x1,%ebx
  118b33:	cmpq   $0x0,(%rsp)
  118b38:	je     1185dd <relar_list_slice_sum+0x4d>
  118b3e:	mov    0x8(%rsp),%rax
  118b43:	mov    -0x8(%rax),%rsi
  118b47:	mov    %rbx,%rdi
  118b4a:	xor    %edx,%edx
  118b4c:	addr32 call 10bfb0 <relar_int_binary>
  118b52:	test   $0x1,%bl
  118b55:	jne    1191df <relar_list_slice_sum+0xc4f>
  118b5b:	mov    %rax,%r14
  118b5e:	lea    -0x10(%rbx),%rax
  118b62:	mov    %rax,0x10(%rsp)
  118b67:	decq   -0x10(%rbx)
  118b6b:	jne    118de8 <relar_list_slice_sum+0x858>
  118b71:	lea    0x10(%rsp),%rdi
  118b76:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  118b7c:	jmp    118de8 <relar_list_slice_sum+0x858>
  118b81:	movabs $0x4000000000000000,%rax
  118b8b:	add    %r14,%rax
  118b8e:	js     11921f <relar_list_slice_sum+0xc8f>
  118b94:	lea    0x1(,%r14,2),%rax
  118b9c:	jmp    1191df <relar_list_slice_sum+0xc4f>
  118ba1:	mov    %r13d,%ecx
  118ba4:	and    $0x3,%ecx
  118ba7:	mov    $0x4,%edx
  118bac:	cmovne %rcx,%rdx
  118bb0:	mov    %r13,%rcx
  118bb3:	sub    %rdx,%rcx
  118bb6:	lea    (%rbx,%rbp,1),%rdx
  118bba:	add    $0x20,%rdx
  118bbe:	pxor   %xmm0,%xmm0
  118bc2:	movdqa -0x10740a(%rip),%xmm3        # 117c0 <_IO_stdin_used+0x15c8>
  118bca:	movdqa -0x107cb2(%rip),%xmm4        # 10f20 <_IO_stdin_used+0xd28>
  118bd2:	mov    %rcx,%rsi
  118bd5:	pxor   %xmm5,%xmm5
  118bd9:	pxor   %xmm2,%xmm2
  118bdd:	pxor   %xmm1,%xmm1
  118be1:	movq   -0x10(%rdx),%xmm6
  118be6:	movq   -0x20(%rdx),%xmm7
  118beb:	punpcklqdq %xmm6,%xmm7
  118bef:	movq   0x10(%rdx),%xmm8
  118bf5:	movq   (%rdx),%xmm6
  118bf9:	punpcklqdq %xmm8,%xmm6
  118bfe:	pshufd $0xed,%xmm7,%xmm8
  118c04:	psrad  $0x1,%xmm8
  118c0a:	movdqa %xmm7,%xmm9
  118c0f:	psrlq  $0x1,%xmm9
  118c15:	pshufd $0xe8,%xmm9,%xmm9
  118c1b:	punpckldq %xmm8,%xmm9
  118c20:	paddq  %xmm9,%xmm2
  118c25:	pshufd $0xed,%xmm6,%xmm8
  118c2b:	psrad  $0x1,%xmm8
  118c31:	movdqa %xmm6,%xmm9
  118c36:	psrlq  $0x1,%xmm9
  118c3c:	pshufd $0xe8,%xmm9,%xmm9
  118c42:	punpckldq %xmm8,%xmm9
  118c47:	paddq  %xmm9,%xmm1
  118c4c:	movdqa %xmm7,%xmm8
  118c51:	paddq  %xmm4,%xmm8
  118c56:	movdqa %xmm6,%xmm9
  118c5b:	paddq  %xmm4,%xmm9
  118c60:	psrlq  $0x21,%xmm8
  118c66:	psrlq  $0x21,%xmm9
  118c6c:	pandn  %xmm3,%xmm7
  118c70:	por    %xmm7,%xmm5
  118c74:	por    %xmm8,%xmm5
  118c79:	pandn  %xmm3,%xmm6
  118c7d:	por    %xmm6,%xmm0
  118c81:	por    %xmm9,%xmm0
  118c86:	add    $0x40,%rdx
  118c8a:	add    $0xfffffffffffffffc,%rsi
  118c8e:	jne    118be1 <relar_list_slice_sum+0x651>
  118c94:	por    %xmm5,%xmm0
  118c98:	pshufd $0xee,%xmm0,%xmm3
  118c9d:	por    %xmm0,%xmm3
  118ca1:	movq   %xmm3,%rsi
  118ca6:	paddq  %xmm2,%xmm1
  118caa:	pshufd $0xee,%xmm1,%xmm0
  118caf:	paddq  %xmm1,%xmm0
  118cb3:	movq   %xmm0,%rdx
  118cb8:	mov    %r13,%rdi
  118cbb:	sub    %rcx,%rdi
  118cbe:	shl    $0x4,%rcx
  118cc2:	add    %rbx,%rcx
  118cc5:	add    %rcx,%rbp
  118cc8:	nopl   0x0(%rax,%rax,1)
  118cd0:	mov    0x0(%rbp),%r8
  118cd4:	mov    %r8d,%ecx
  118cd7:	not    %ecx
  118cd9:	mov    %r8,%r9
  118cdc:	sar    $1,%r9
  118cdf:	add    %r9,%rdx
  118ce2:	add    %rax,%r8
  118ce5:	shr    $0x21,%r8
  118ce9:	or     %rsi,%r8
  118cec:	and    $0x1,%ecx
  118cef:	or     %r8,%rcx
  118cf2:	add    $0x10,%rbp
  118cf6:	mov    %rcx,%rsi
  118cf9:	dec    %rdi
  118cfc:	jne    118cd0 <relar_list_slice_sum+0x740>
  118cfe:	test   %r14,%r14
  118d01:	je     118d22 <relar_list_slice_sum+0x792>
  118d03:	mov    (%r11,%r10,8),%rsi
  118d07:	mov    %rsi,%rdi
  118d0a:	add    %rsi,%rax
  118d0d:	not    %esi
  118d0f:	sar    $1,%rdi
  118d12:	add    %rdi,%rdx
  118d15:	shr    $0x21,%rax
  118d19:	and    $0x1,%esi
  118d1c:	or     %rax,%rsi
  118d1f:	or     %rsi,%rcx
  118d22:	test   %rcx,%rcx
  118d25:	je     118df0 <relar_list_slice_sum+0x860>
  118d2b:	mov    %r14,0x8(%rsp)
  118d30:	mov    %r10,0x38(%rsp)
  118d35:	test   %r13,%r13
  118d38:	je     118d99 <relar_list_slice_sum+0x809>
  118d3a:	mov    $0x1,%r15d
  118d40:	lea    -0xcd97(%rip),%rbp        # 10bfb0 <relar_int_binary>
  118d47:	lea    0x84f2(%rip),%r14        # 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  118d4e:	mov    %r11,%r12
  118d51:	jmp    118d6c <relar_list_slice_sum+0x7dc>
  118d53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  118d60:	add    $0x10,%r12
  118d64:	mov    %rbx,%r15
  118d67:	dec    %r13
  118d6a:	je     118d9e <relar_list_slice_sum+0x80e>
  118d6c:	mov    (%r12),%rsi
  118d70:	mov    %r15,%rdi
  118d73:	xor    %edx,%edx
  118d75:	call   *%rbp
  118d77:	mov    %rax,%rbx
  118d7a:	test   $0x1,%r15b
  118d7e:	jne    118d60 <relar_list_slice_sum+0x7d0>
  118d80:	lea    -0x10(%r15),%rax
  118d84:	mov    %rax,0x10(%rsp)
  118d89:	decq   -0x10(%r15)
  118d8d:	jne    118d60 <relar_list_slice_sum+0x7d0>
  118d8f:	lea    0x10(%rsp),%rdi
  118d94:	call   *%r14
  118d97:	jmp    118d60 <relar_list_slice_sum+0x7d0>
  118d99:	mov    $0x1,%ebx
  118d9e:	cmpq   $0x0,0x8(%rsp)
  118da4:	je     1185dd <relar_list_slice_sum+0x4d>
  118daa:	mov    (%rsp),%rax
  118dae:	mov    0x38(%rsp),%rcx
  118db3:	mov    (%rax,%rcx,8),%rsi
  118db7:	mov    %rbx,%rdi
  118dba:	xor    %edx,%edx
  118dbc:	addr32 call 10bfb0 <relar_int_binary>
  118dc2:	test   $0x1,%bl
  118dc5:	jne    1191df <relar_list_slice_sum+0xc4f>
  118dcb:	mov    %rax,%r14
  118dce:	lea    -0x10(%rbx),%rax
  118dd2:	mov    %rax,0x10(%rsp)
  118dd7:	decq   -0x10(%rbx)
  118ddb:	jne    118de8 <relar_list_slice_sum+0x858>
  118ddd:	lea    0x10(%rsp),%rdi
  118de2:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  118de8:	mov    %r14,%rax
  118deb:	jmp    1191df <relar_list_slice_sum+0xc4f>
  118df0:	movabs $0x4000000000000000,%rax
  118dfa:	add    %rdx,%rax
  118dfd:	js     11921f <relar_list_slice_sum+0xc8f>
  118e03:	lea    0x1(,%rdx,2),%rax
  118e0b:	jmp    1191df <relar_list_slice_sum+0xc4f>
  118e10:	inc    %r14
  118e13:	movabs $0x4000000000000000,%rdx
  118e1d:	add    $0xfffffffffffffffc,%rdx
  118e21:	and    %r14,%rdx
  118e24:	lea    0x0(,%rdx,8),%r8
  118e2c:	sub    %r8,%rcx
  118e2f:	mov    %r14,%r10
  118e32:	and    $0xfffffffffffffffc,%r10
  118e36:	neg    %r10
  118e39:	lea    -0x8(,%rbx,8),%r8
  118e41:	add    %rbp,%r8
  118e44:	pxor   %xmm0,%xmm0
  118e48:	xor    %r9d,%r9d
  118e4b:	movdqa -0x107693(%rip),%xmm3        # 117c0 <_IO_stdin_used+0x15c8>
  118e53:	movdqa -0x107f3b(%rip),%xmm5        # 10f20 <_IO_stdin_used+0xd28>
  118e5b:	pxor   %xmm4,%xmm4
  118e5f:	pxor   %xmm2,%xmm2
  118e63:	pxor   %xmm1,%xmm1
  118e67:	movdqu -0x10(%r8,%r9,8),%xmm8
  118e6e:	movdqu (%r8,%r9,8),%xmm9
  118e74:	pshufd $0x4e,%xmm9,%xmm7
  118e7a:	pshufd $0x4e,%xmm8,%xmm6
  118e80:	pshufd $0x47,%xmm9,%xmm9
  118e86:	psrad  $0x1,%xmm9
  118e8c:	movdqa %xmm7,%xmm10
  118e91:	psrlq  $0x1,%xmm10
  118e97:	pshufd $0xe8,%xmm10,%xmm10
  118e9d:	punpckldq %xmm9,%xmm10
  118ea2:	paddq  %xmm10,%xmm4
  118ea7:	pshufd $0x47,%xmm8,%xmm8
  118ead:	psrad  $0x1,%xmm8
  118eb3:	movdqa %xmm6,%xmm9
  118eb8:	psrlq  $0x1,%xmm9
  118ebe:	pshufd $0xe8,%xmm9,%xmm9
  118ec4:	punpckldq %xmm8,%xmm9
  118ec9:	paddq  %xmm9,%xmm0
  118ece:	movdqa %xmm7,%xmm8
  118ed3:	paddq  %xmm5,%xmm8
  118ed8:	movdqa %xmm6,%xmm9
  118edd:	paddq  %xmm5,%xmm9
  118ee2:	psrlq  $0x21,%xmm8
  118ee8:	psrlq  $0x21,%xmm9
  118eee:	pandn  %xmm3,%xmm7
  118ef2:	por    %xmm7,%xmm2
  118ef6:	por    %xmm8,%xmm2
  118efb:	pandn  %xmm3,%xmm6
  118eff:	por    %xmm6,%xmm1
  118f03:	por    %xmm9,%xmm1
  118f08:	add    $0xfffffffffffffffc,%r9
  118f0c:	cmp    %r9,%r10
  118f0f:	jne    118e67 <relar_list_slice_sum+0x8d7>
  118f15:	paddq  %xmm4,%xmm0
  118f19:	pshufd $0xee,%xmm0,%xmm3
  118f1e:	paddq  %xmm0,%xmm3
  118f22:	movq   %xmm3,%r12
  118f27:	por    %xmm2,%xmm1
  118f2b:	pshufd $0xee,%xmm1,%xmm0
  118f30:	por    %xmm1,%xmm0
  118f34:	movq   %xmm0,%r8
  118f39:	cmp    %rdx,%r14
  118f3c:	je     118f80 <relar_list_slice_sum+0x9f0>
  118f3e:	movabs $0x100000000,%rdx
  118f48:	mov    %r8,%r9
  118f4b:	nopl   0x0(%rax,%rax,1)
  118f50:	mov    -0x8(%rcx),%r10
  118f54:	add    $0xfffffffffffffff8,%rcx
  118f58:	mov    %r10d,%r8d
  118f5b:	not    %r8d
  118f5e:	mov    %r10,%r11
  118f61:	sar    $1,%r11
  118f64:	add    %r11,%r12
  118f67:	add    %rdx,%r10
  118f6a:	shr    $0x21,%r10
  118f6e:	and    $0x1,%r8d
  118f72:	or     %r9,%r8
  118f75:	or     %r10,%r8
  118f78:	mov    %r8,%r9
  118f7b:	cmp    %r15,%rcx
  118f7e:	jne    118f50 <relar_list_slice_sum+0x9c0>
  118f80:	test   %r8,%r8
  118f83:	je     1191af <relar_list_slice_sum+0xc1f>
  118f89:	cmp    %rdi,%rax
  118f8c:	mov    $0x1,%eax
  118f91:	je     1191df <relar_list_slice_sum+0xc4f>
  118f97:	mov    %rbp,%r15
  118f9a:	mov    %rsi,%rbp
  118f9d:	not    %rbp
  118fa0:	shl    $0x3,%rbp
  118fa4:	lea    (%r15,%rbx,8),%r14
  118fa8:	mov    $0x1,%r12d
  118fae:	xor    %r15d,%r15d
  118fb1:	lea    -0xd008(%rip),%r13        # 10bfb0 <relar_int_binary>
  118fb8:	jmp    118fd3 <relar_list_slice_sum+0xa43>
  118fba:	nopw   0x0(%rax,%rax,1)
  118fc0:	mov    %rbx,%rax
  118fc3:	add    $0xfffffffffffffff8,%r15
  118fc7:	mov    %rax,%r12
  118fca:	cmp    %r15,%rbp
  118fcd:	je     1191df <relar_list_slice_sum+0xc4f>
  118fd3:	mov    (%r14,%r15,1),%rsi
  118fd7:	mov    %r12,%rdi
  118fda:	xor    %edx,%edx
  118fdc:	call   *%r13
  118fdf:	test   $0x1,%r12b
  118fe3:	jne    118fc3 <relar_list_slice_sum+0xa33>
  118fe5:	mov    %rax,%rbx
  118fe8:	lea    -0x10(%r12),%rax
  118fed:	mov    %rax,0x10(%rsp)
  118ff2:	decq   -0x10(%r12)
  118ff7:	jne    118fc0 <relar_list_slice_sum+0xa30>
  118ff9:	lea    0x10(%rsp),%rdi
  118ffe:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  119004:	jmp    118fc0 <relar_list_slice_sum+0xa30>
  119006:	mov    %r13d,%eax
  119009:	and    $0x7ffffffc,%eax
  11900e:	lea    (%rbx,%rbp,1),%rcx
  119012:	add    $0x10,%rcx
  119016:	pxor   %xmm0,%xmm0
  11901a:	xor    %edx,%edx
  11901c:	movdqa -0x107864(%rip),%xmm3        # 117c0 <_IO_stdin_used+0x15c8>
  119024:	movdqa -0x10810c(%rip),%xmm5        # 10f20 <_IO_stdin_used+0xd28>
  11902c:	pxor   %xmm4,%xmm4
  119030:	pxor   %xmm2,%xmm2
  119034:	pxor   %xmm1,%xmm1
  119038:	movdqu -0x10(%rcx,%rdx,8),%xmm7
  11903e:	movdqu (%rcx,%rdx,8),%xmm6
  119043:	pshufd $0xed,%xmm7,%xmm8
  119049:	psrad  $0x1,%xmm8
  11904f:	movdqa %xmm7,%xmm9
  119054:	psrlq  $0x1,%xmm9
  11905a:	pshufd $0xe8,%xmm9,%xmm9
  119060:	punpckldq %xmm8,%xmm9
  119065:	paddq  %xmm9,%xmm2
  11906a:	pshufd $0xed,%xmm6,%xmm8
  119070:	psrad  $0x1,%xmm8
  119076:	movdqa %xmm6,%xmm9
  11907b:	psrlq  $0x1,%xmm9
  119081:	pshufd $0xe8,%xmm9,%xmm9
  119087:	punpckldq %xmm8,%xmm9
  11908c:	paddq  %xmm9,%xmm1
  119091:	movdqa %xmm7,%xmm8
  119096:	paddq  %xmm5,%xmm8
  11909b:	movdqa %xmm6,%xmm9
  1190a0:	paddq  %xmm5,%xmm9
  1190a5:	psrlq  $0x21,%xmm8
  1190ab:	psrlq  $0x21,%xmm9
  1190b1:	pandn  %xmm3,%xmm7
  1190b5:	por    %xmm7,%xmm4
  1190b9:	por    %xmm8,%xmm4
  1190be:	pandn  %xmm3,%xmm6
  1190c2:	por    %xmm6,%xmm0
  1190c6:	por    %xmm9,%xmm0
  1190cb:	add    $0x4,%rdx
  1190cf:	cmp    %rdx,%rax
  1190d2:	jne    119038 <relar_list_slice_sum+0xaa8>
  1190d8:	por    %xmm4,%xmm0
  1190dc:	pshufd $0xee,%xmm0,%xmm3
  1190e1:	por    %xmm0,%xmm3
  1190e5:	movq   %xmm3,%rdx
  1190ea:	paddq  %xmm2,%xmm1
  1190ee:	pshufd $0xee,%xmm1,%xmm0
  1190f3:	paddq  %xmm1,%xmm0
  1190f7:	movq   %xmm0,%rcx
  1190fc:	cmp    %rax,%r13
  1190ff:	je     11913d <relar_list_slice_sum+0xbad>
  119101:	movabs $0x100000000,%r10
  11910b:	mov    %rdx,%rdi
  11910e:	xchg   %ax,%ax
  119110:	mov    (%r11,%rax,8),%r8
  119114:	mov    %r8d,%edx
  119117:	not    %edx
  119119:	mov    %r8,%r9
  11911c:	sar    $1,%r9
  11911f:	add    %r9,%rcx
  119122:	add    %r10,%r8
  119125:	shr    $0x21,%r8
  119129:	or     %rdi,%r8
  11912c:	and    $0x1,%edx
  11912f:	or     %r8,%rdx
  119132:	inc    %rax
  119135:	mov    %rdx,%rdi
  119138:	cmp    %rax,%r13
  11913b:	jne    119110 <relar_list_slice_sum+0xb80>
  11913d:	test   %rdx,%rdx
  119140:	je     1191c8 <relar_list_slice_sum+0xc38>
  119146:	cmp    %rbx,%rsi
  119149:	mov    $0x1,%eax
  11914e:	je     1191df <relar_list_slice_sum+0xc4f>
  119154:	mov    $0x1,%r14d
  11915a:	xor    %r15d,%r15d
  11915d:	lea    -0xd1b4(%rip),%r12        # 10bfb0 <relar_int_binary>
  119164:	lea    0x80d5(%rip),%rbp        # 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  11916b:	jmp    119182 <relar_list_slice_sum+0xbf2>
  11916d:	nopl   (%rax)
  119170:	mov    %rbx,%rax
  119173:	inc    %r15
  119176:	mov    %rax,%r14
  119179:	cmp    %r15,%r13
  11917c:	mov    (%rsp),%r11
  119180:	je     1191df <relar_list_slice_sum+0xc4f>
  119182:	mov    (%r11,%r15,8),%rsi
  119186:	mov    %r14,%rdi
  119189:	xor    %edx,%edx
  11918b:	call   *%r12
  11918e:	test   $0x1,%r14b
  119192:	jne    119173 <relar_list_slice_sum+0xbe3>
  119194:	mov    %rax,%rbx
  119197:	lea    -0x10(%r14),%rax
  11919b:	mov    %rax,0x10(%rsp)
  1191a0:	decq   -0x10(%r14)
  1191a4:	jne    119170 <relar_list_slice_sum+0xbe0>
  1191a6:	lea    0x10(%rsp),%rdi
  1191ab:	call   *%rbp
  1191ad:	jmp    119170 <relar_list_slice_sum+0xbe0>
  1191af:	movabs $0x4000000000000000,%rax
  1191b9:	add    %r12,%rax
  1191bc:	js     11921f <relar_list_slice_sum+0xc8f>
  1191be:	lea    0x1(,%r12,2),%rax
  1191c6:	jmp    1191df <relar_list_slice_sum+0xc4f>
  1191c8:	movabs $0x4000000000000000,%rax
  1191d2:	add    %rcx,%rax
  1191d5:	js     11921f <relar_list_slice_sum+0xc8f>
  1191d7:	lea    0x1(,%rcx,2),%rax
  1191df:	add    $0x48,%rsp
  1191e3:	pop    %rbx
  1191e4:	pop    %r12
  1191e6:	pop    %r13
  1191e8:	pop    %r14
  1191ea:	pop    %r15
  1191ec:	pop    %rbp
  1191ed:	ret
  1191ee:	movq   0x30(%rsp),%xmm0
  1191f4:	mov    %rbx,0x10(%rsp)
  1191f9:	mov    %rcx,0x18(%rsp)
  1191fe:	mov    %r14,0x20(%rsp)
  119203:	movq   %xmm0,0x28(%rsp)
  119209:	lea    0x10(%rsp),%rdi
  11920e:	mov    $0x1,%esi
  119213:	call   1250c0 <_RINvMs0_NtNtCs5N6zm3e4tnE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  119218:	jmp    1191df <relar_list_slice_sum+0xc4f>
  11921a:	mov    %rbx,%rdi
  11921d:	jmp    119234 <relar_list_slice_sum+0xca4>
  11921f:	lea    0x3b5aa(%rip),%rdi        # 1547d0 <anon.76308f6739ee2ec32d8bb5a37ebbcff7.5.llvm.6469393670801744543>
  119226:	addr32 call eabc0 <_RNvNtCs6SLOTazmNXq_4core6option13unwrap_failed>
  11922c:	mov    %rbx,%rsi
  11922f:	jmp    119234 <relar_list_slice_sum+0xca4>
  119231:	mov    %rdx,%rsi
  119234:	lea    0x3b865(%rip),%rcx        # 154aa0 <anon.ddd0a87e6a98674c996a4674a94af0e4.16.llvm.16282241626728798403>
  11923b:	mov    %r12,%rdx
  11923e:	addr32 call ec320 <_RNvNtNtCs6SLOTazmNXq_4core5slice5index16slice_index_fail>
  119244:	lea    0x3ba6d(%rip),%rdx        # 154cb8 <anon.11d3e8b03dbf31303d0b50de7c7d806c.4.llvm.13916118869250896945>
  11924b:	mov    %rbx,%rdi
  11924e:	mov    %r12,%rsi
  119251:	addr32 call eacb2 <_RNvNtCs6SLOTazmNXq_4core9panicking18panic_bounds_check>
  119257:	lea    0x3ba5a(%rip),%rdx        # 154cb8 <anon.11d3e8b03dbf31303d0b50de7c7d806c.4.llvm.13916118869250896945>
  11925e:	mov    %r12,%rsi
  119261:	addr32 call eacb2 <_RNvNtCs6SLOTazmNXq_4core9panicking18panic_bounds_check>
  119267:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  11926d:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  119273:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  119279:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  11927f:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  119285:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  11928b:	lea    0x40(%rsp),%rdi
  119290:	addr32 call 109d10 <_RNvXs0_Cs5N6zm3e4tnE_12relar_runtimeNtB5_3IntNtNtNtCs6SLOTazmNXq_4core3ops4drop4Drop4drop>
  119296:	jmp    11929e <relar_list_slice_sum+0xd0e>
  119298:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  11929e:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
