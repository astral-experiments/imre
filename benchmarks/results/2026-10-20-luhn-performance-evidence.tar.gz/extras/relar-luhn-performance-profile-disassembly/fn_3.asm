
/tmp/relar-luhn-performance-v1-thinlto/luhn:     file format elf64-x86-64


Disassembly of section .text:

0000000000105f60 <fn_3>:
  105f60:	push   %rbp
  105f61:	push   %r15
  105f63:	push   %r14
  105f65:	push   %r13
  105f67:	push   %r12
  105f69:	push   %rbx
  105f6a:	sub    $0x38,%rsp
  105f6e:	addr32 call 1192b0 <relar_str_int_list>
  105f74:	mov    %rax,%r14
  105f77:	xor    %edi,%edi
  105f79:	call   1275b0 <_RNvYNCNKNvNtNtCs5N6zm3e4tnE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.3687425895475854622>
  105f7e:	mov    $0x1,%r15d
  105f84:	cmpb   $0x0,(%rax)
  105f87:	jne    106328 <fn_3+0x3c8>
  105f8d:	mov    %rax,%rbx
  105f90:	mov    %r14,%rdi
  105f93:	mov    $0xffffffffffffffff,%rsi
  105f9a:	xor    %edx,%edx
  105f9c:	mov    $0xfffffffffffffffd,%rcx
  105fa3:	addr32 call 118590 <relar_list_slice_sum>
  105fa9:	cmpb   $0x0,(%rbx)
  105fac:	jne    106333 <fn_3+0x3d3>
  105fb2:	test   %r14,%r14
  105fb5:	je     105fc1 <fn_3+0x61>
  105fb7:	incq   -0x10(%r14)
  105fbb:	je     106326 <fn_3+0x3c6>
  105fc1:	mov    %rbx,0x30(%rsp)
  105fc6:	mov    %rax,0x8(%rsp)
  105fcb:	movabs $0xc000000000000000,%rbp
  105fd5:	mov    0x10(%r14),%rax
  105fd9:	lea    (%rax,%rax,1),%r15
  105fdd:	movabs $0x666666666666666,%rcx
  105fe7:	cmp    %rcx,%rax
  105fea:	jae    106068 <fn_3+0x108>
  105fec:	mov    $0x1,%r12d
  105ff2:	cmp    $0x2,%rax
  105ff6:	jb     106044 <fn_3+0xe4>
  105ff8:	mov    0x8(%r14),%rax
  105ffc:	inc    %r15
  105fff:	movabs $0x7ffffffffffffff6,%rcx
  106009:	nopl   0x0(%rax)
  106010:	add    $0xfffffffffffffffc,%r15
  106014:	mov    %r15,%rdx
  106017:	and    $0xfffffffffffffffe,%rdx
  10601b:	mov    (%rax,%rdx,4),%rdx
  10601f:	mov    %edx,%esi
  106021:	and    $0x1e,%esi
  106024:	lea    (%rsi,%rcx,1),%rdi
  106028:	xor    %r8d,%r8d
  10602b:	cmp    $0xa,%rdx
  10602f:	cmovb  %rsi,%rdi
  106033:	setae  %r8b
  106037:	or     %rdi,%r8
  10603a:	lea    (%r12,%r8,2),%r12
  10603e:	cmp    $0x4,%r15
  106042:	ja     106010 <fn_3+0xb0>
  106044:	mov    %r14,%rdi
  106047:	addr32 call 111cc0 <relar_list_release>
  10604d:	test   %r12,%r12
  106050:	sete   %al
  106053:	or     %r12b,%al
  106056:	test   $0x1,%al
  106058:	je     106176 <fn_3+0x216>
  10605e:	mov    0x8(%rsp),%r15
  106063:	jmp    1061a9 <fn_3+0x249>
  106068:	inc    %r15
  10606b:	mov    $0x1,%r13d
  106071:	lea    0x5f38(%rip),%rbx        # 10bfb0 <relar_int_binary>
  106078:	jmp    106099 <fn_3+0x139>
  10607a:	lea    0x1(,%rax,2),%r12
  106082:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  106090:	mov    %r12,%r13
  106093:	cmp    $0x4,%r15
  106097:	jbe    106044 <fn_3+0xe4>
  106099:	add    $0xfffffffffffffffc,%r15
  10609d:	mov    %r15,%rax
  1060a0:	shr    $1,%rax
  1060a3:	cmp    0x10(%r14),%rax
  1060a7:	jae    106130 <fn_3+0x1d0>
  1060ad:	mov    0x8(%r14),%rcx
  1060b1:	mov    (%rcx,%rax,8),%rax
  1060b5:	test   %rax,%rax
  1060b8:	je     1062fc <fn_3+0x39c>
  1060be:	mov    %eax,%edx
  1060c0:	and    $0x1e,%edx
  1060c3:	lea    -0xa(%rdx),%rsi
  1060c7:	xor    %ecx,%ecx
  1060c9:	cmp    $0xa,%rax
  1060cd:	setae  %cl
  1060d0:	cmovb  %rdx,%rsi
  1060d4:	or     %rsi,%rcx
  1060d7:	test   $0x1,%r13b
  1060db:	je     1060ee <fn_3+0x18e>
  1060dd:	mov    %r13,%rax
  1060e0:	sar    $1,%rax
  1060e3:	add    %rcx,%rax
  1060e6:	mov    %rax,%rdx
  1060e9:	add    %rbp,%rdx
  1060ec:	js     10607a <fn_3+0x11a>
  1060ee:	lea    0x1(,%rcx,2),%rsi
  1060f6:	mov    %r13,%rdi
  1060f9:	xor    %edx,%edx
  1060fb:	call   *%rbx
  1060fd:	mov    %rax,%r12
  106100:	test   %r13,%r13
  106103:	sete   %al
  106106:	or     %r13b,%al
  106109:	test   $0x1,%al
  10610b:	jne    106090 <fn_3+0x130>
  10610d:	lea    -0x10(%r13),%rax
  106111:	mov    %rax,0x10(%rsp)
  106116:	decq   -0x10(%r13)
  10611a:	jne    106090 <fn_3+0x130>
  106120:	lea    0x10(%rsp),%rdi
  106125:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  10612b:	jmp    106090 <fn_3+0x130>
  106130:	movabs $0x6f2074756f207865,%rax
  10613a:	mov    %rax,0x18(%rsp)
  10613f:	movabs $0xd765676e61722066,%rax
  106149:	mov    %rax,0x20(%rsp)
  10614e:	movabs $0x646e69207473696c,%rax
  106158:	mov    %rax,0x10(%rsp)
  10615d:	movl   $0x6,0x28(%rsp)
  106165:	lea    0x10(%rsp),%rdi
  10616a:	xor    %esi,%esi
  10616c:	call   1250c0 <_RINvMs0_NtNtCs5N6zm3e4tnE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  106171:	jmp    1060b5 <fn_3+0x155>
  106176:	incq   -0x10(%r12)
  10617b:	mov    %r12,%r13
  10617e:	mov    0x8(%rsp),%r15
  106183:	je     106326 <fn_3+0x3c6>
  106189:	test   $0x1,%r13b
  10618d:	jne    1061a9 <fn_3+0x249>
  10618f:	lea    -0x10(%r13),%rax
  106193:	mov    %rax,0x10(%rsp)
  106198:	decq   -0x10(%r13)
  10619c:	jne    1061a9 <fn_3+0x249>
  10619e:	lea    0x10(%rsp),%rdi
  1061a3:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  1061a9:	mov    0x30(%rsp),%rax
  1061ae:	cmpb   $0x0,(%rax)
  1061b1:	jne    106339 <fn_3+0x3d9>
  1061b7:	mov    %r15d,%ebx
  1061ba:	and    $0x1,%ebx
  1061bd:	test   %ebx,%r12d
  1061c0:	je     1061d6 <fn_3+0x276>
  1061c2:	mov    %r15,%rcx
  1061c5:	sar    $1,%rcx
  1061c8:	mov    %r12,%rax
  1061cb:	sar    $1,%rax
  1061ce:	add    %rcx,%rax
  1061d1:	add    %rax,%rbp
  1061d4:	js     106205 <fn_3+0x2a5>
  1061d6:	mov    %r15,%rdi
  1061d9:	mov    %r12,%rsi
  1061dc:	xor    %edx,%edx
  1061de:	addr32 call 10bfb0 <relar_int_binary>
  1061e4:	mov    %rax,%rbp
  1061e7:	test   $0x1,%bpl
  1061eb:	jne    106213 <fn_3+0x2b3>
  1061ed:	mov    $0x15,%esi
  1061f2:	mov    %rbp,%rdi
  1061f5:	mov    $0x4,%edx
  1061fa:	addr32 call 10bfb0 <relar_int_binary>
  106200:	mov    %rax,%r13
  106203:	jmp    106256 <fn_3+0x2f6>
  106205:	lea    0x1(,%rax,2),%rbp
  10620d:	test   $0x1,%bpl
  106211:	je     1061ed <fn_3+0x28d>
  106213:	mov    %rbp,%rcx
  106216:	sar    $1,%rcx
  106219:	movabs $0x6666666666666667,%rdx
  106223:	mov    %rcx,%rax
  106226:	imul   %rdx
  106229:	mov    %rdx,%rax
  10622c:	shr    $0x3f,%rax
  106230:	sar    $0x2,%rdx
  106234:	add    %rax,%rdx
  106237:	add    %rdx,%rdx
  10623a:	lea    (%rdx,%rdx,4),%rax
  10623e:	sub    %rax,%rcx
  106241:	mov    %rcx,%rax
  106244:	sar    $0x3f,%rax
  106248:	and    $0xa,%eax
  10624b:	add    %rcx,%rax
  10624e:	lea    0x1(,%rax,2),%r13
  106256:	test   %rbp,%rbp
  106259:	sete   %al
  10625c:	or     %bpl,%al
  10625f:	mov    0x30(%rsp),%rcx
  106264:	cmpb   $0x0,(%rcx)
  106267:	jne    10637a <fn_3+0x41a>
  10626d:	test   $0x1,%al
  10626f:	jne    10628b <fn_3+0x32b>
  106271:	lea    -0x10(%rbp),%rax
  106275:	mov    %rax,0x10(%rsp)
  10627a:	decq   -0x10(%rbp)
  10627e:	jne    10628b <fn_3+0x32b>
  106280:	lea    0x10(%rsp),%rdi
  106285:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  10628b:	mov    %r14,%rdi
  10628e:	addr32 call 111cc0 <relar_list_release>
  106294:	test   %r15,%r15
  106297:	sete   %al
  10629a:	or     %bl,%al
  10629c:	jne    1062bb <fn_3+0x35b>
  10629e:	mov    %r15,%rax
  1062a1:	add    $0xfffffffffffffff0,%rax
  1062a5:	mov    %rax,0x10(%rsp)
  1062aa:	decq   -0x10(%r15)
  1062ae:	jne    1062bb <fn_3+0x35b>
  1062b0:	lea    0x10(%rsp),%rdi
  1062b5:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  1062bb:	test   %r12,%r12
  1062be:	sete   %al
  1062c1:	or     %r12b,%al
  1062c4:	test   $0x1,%al
  1062c6:	jne    1062ea <fn_3+0x38a>
  1062c8:	test   $0x1,%r12b
  1062cc:	jne    1062ea <fn_3+0x38a>
  1062ce:	lea    -0x10(%r12),%rax
  1062d3:	mov    %rax,0x10(%rsp)
  1062d8:	decq   -0x10(%r12)
  1062dd:	jne    1062ea <fn_3+0x38a>
  1062df:	lea    0x10(%rsp),%rdi
  1062e4:	addr32 call 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  1062ea:	mov    %r13,%rax
  1062ed:	add    $0x38,%rsp
  1062f1:	pop    %rbx
  1062f2:	pop    %r12
  1062f4:	pop    %r13
  1062f6:	pop    %r14
  1062f8:	pop    %r15
  1062fa:	pop    %rbp
  1062fb:	ret
  1062fc:	mov    %r14,%rdi
  1062ff:	addr32 call 111cc0 <relar_list_release>
  106305:	test   %r13,%r13
  106308:	sete   %al
  10630b:	or     %r13b,%al
  10630e:	mov    $0x1,%r12d
  106314:	test   $0x1,%al
  106316:	mov    0x8(%rsp),%r15
  10631b:	je     106189 <fn_3+0x229>
  106321:	jmp    1061a9 <fn_3+0x249>
  106326:	ud2
  106328:	xor    %r14d,%r14d
  10632b:	mov    $0x1,%r12d
  106331:	jmp    10633f <fn_3+0x3df>
  106333:	mov    $0x1,%r15d
  106339:	mov    $0x1,%r12d
  10633f:	mov    %r14,%rdi
  106342:	addr32 call 111cc0 <relar_list_release>
  106348:	test   %r15,%r15
  10634b:	sete   %al
  10634e:	or     %r15b,%al
  106351:	test   $0x1,%al
  106353:	jne    10635e <fn_3+0x3fe>
  106355:	mov    %r15,%rdi
  106358:	addr32 call 111290 <relar_int_release>
  10635e:	test   %r12,%r12
  106361:	sete   %al
  106364:	or     %r12b,%al
  106367:	mov    $0x1,%r13d
  10636d:	test   $0x1,%al
  10636f:	je     1062c8 <fn_3+0x368>
  106375:	jmp    1062ea <fn_3+0x38a>
  10637a:	test   $0x1,%al
  10637c:	jne    10633f <fn_3+0x3df>
  10637e:	mov    %rbp,%rdi
  106381:	addr32 call 111290 <relar_int_release>
  106387:	jmp    10633f <fn_3+0x3df>
  106389:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10638f:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  106395:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10639b:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1063a1:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1063a7:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
