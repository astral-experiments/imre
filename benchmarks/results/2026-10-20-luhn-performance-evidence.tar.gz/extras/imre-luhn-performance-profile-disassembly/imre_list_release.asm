
/tmp/imre-luhn-performance-v1-thinlto/luhn:     file format elf64-x86-64


Disassembly of section .text:

0000000000111cc0 <imre_list_release>:
  111cc0:	push   %rbp
  111cc1:	push   %r15
  111cc3:	push   %r14
  111cc5:	push   %r13
  111cc7:	push   %r12
  111cc9:	push   %rbx
  111cca:	sub    $0x68,%rsp
  111cce:	test   %rdi,%rdi
  111cd1:	je     11203e <imre_list_release+0x37e>
  111cd7:	lea    -0x10(%rdi),%rax
  111cdb:	mov    %rax,0x28(%rsp)
  111ce0:	mov    -0x10(%rdi),%rcx
  111ce4:	cmpq   $0x1,-0x8(%rdi)
  111ce9:	jne    111d3d <imre_list_release+0x7d>
  111ceb:	cmp    $0x1,%rcx
  111cef:	jne    111d59 <imre_list_release+0x99>
  111cf1:	mov    0x10(%rdi),%rax
  111cf5:	mov    %rax,0x40(%rsp)
  111cfa:	movdqu (%rdi),%xmm0
  111cfe:	movdqa %xmm0,0x30(%rsp)
  111d04:	movq   $0x0,(%rdi)
  111d0b:	movq   $0x8,0x8(%rdi)
  111d13:	movq   $0x0,0x10(%rdi)
  111d1b:	mov    0x38(%rsp),%rbx
  111d20:	mov    0x40(%rsp),%r12
  111d25:	test   %r12,%r12
  111d28:	je     111dc5 <imre_list_release+0x105>
  111d2e:	cmp    $0x4,%r12
  111d32:	jae    111d64 <imre_list_release+0xa4>
  111d34:	mov    $0x1,%ecx
  111d39:	xor    %eax,%eax
  111d3b:	jmp    111db0 <imre_list_release+0xf0>
  111d3d:	dec    %rcx
  111d40:	mov    %rcx,(%rax)
  111d43:	jne    11203e <imre_list_release+0x37e>
  111d49:	lea    0x28(%rsp),%rdi
  111d4e:	addr32 call 1205d0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs5N6zm3e4tnE_12imre_runtime4ListE9drop_slowBF_>
  111d54:	jmp    11203e <imre_list_release+0x37e>
  111d59:	dec    %rcx
  111d5c:	mov    %rcx,(%rax)
  111d5f:	jmp    11203e <imre_list_release+0x37e>
  111d64:	mov    %r12,%rax
  111d67:	and    $0xfffffffffffffffc,%rax
  111d6b:	pcmpeqd %xmm0,%xmm0
  111d6f:	movdqa -0x100677(%rip),%xmm1        # 11700 <_IO_stdin_used+0x1508>
  111d77:	xor    %ecx,%ecx
  111d79:	nopl   0x0(%rax)
  111d80:	movdqu (%rbx,%rcx,8),%xmm2
  111d85:	pand   %xmm2,%xmm1
  111d89:	movdqu 0x10(%rbx,%rcx,8),%xmm2
  111d8f:	pand   %xmm2,%xmm0
  111d93:	add    $0x4,%rcx
  111d97:	cmp    %rcx,%rax
  111d9a:	jne    111d80 <imre_list_release+0xc0>
  111d9c:	pand   %xmm1,%xmm0
  111da0:	pshufd $0xee,%xmm0,%xmm1
  111da5:	pand   %xmm0,%xmm1
  111da9:	movq   %xmm1,%rcx
  111dae:	jmp    111db7 <imre_list_release+0xf7>
  111db0:	and    (%rbx,%rax,8),%rcx
  111db4:	inc    %rax
  111db7:	cmp    %rax,%r12
  111dba:	jne    111db0 <imre_list_release+0xf0>
  111dbc:	test   %rcx,%rcx
  111dbf:	je     111e65 <imre_list_release+0x1a5>
  111dc5:	movq   $0x0,0x40(%rsp)
  111dce:	mov    0x30(%rsp),%rsi
  111dd3:	lea    -0x1(%rsi),%rax
  111dd7:	cmp    $0x7fff,%rax
  111ddd:	ja     111f8d <imre_list_release+0x2cd>
  111de3:	mov    0x40(%rsp),%rax
  111de8:	mov    %rax,0x60(%rsp)
  111ded:	movdqa 0x30(%rsp),%xmm0
  111df3:	movdqa %xmm0,0x50(%rsp)
  111df9:	movq   $0x0,0x30(%rsp)
  111e02:	movq   $0x8,0x38(%rsp)
  111e0b:	movq   $0x0,0x40(%rsp)
  111e14:	data16 data16 data16 data16 mov %fs:0x0,%rax
  111e21:	lea    -0x110(%rax),%rbx
  111e28:	movzbl -0xd8(%rax),%eax
  111e2f:	test   %eax,%eax
  111e31:	jne    111eab <imre_list_release+0x1eb>
  111e33:	cmpq   $0x0,(%rbx)
  111e37:	je     111ed2 <imre_list_release+0x212>
  111e3d:	mov    0x50(%rsp),%r14
  111e42:	mov    0x58(%rsp),%rax
  111e47:	mov    %rax,0x20(%rsp)
  111e4c:	mov    0x60(%rsp),%rbp
  111e51:	mov    $0x8,%ebx
  111e56:	cmp    $0xffffffffffffffff,%r14
  111e5a:	jne    111f24 <imre_list_release+0x264>
  111e60:	jmp    111f88 <imre_list_release+0x2c8>
  111e65:	lea    0x8(%rbx),%r14
  111e69:	mov    %rsp,%r15
  111e6c:	lea    0xf3cd(%rip),%r13        # 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  111e73:	jmp    111e8d <imre_list_release+0x1cd>
  111e75:	data16 cs nopw 0x0(%rax,%rax,1)
  111e80:	add    $0x8,%r14
  111e84:	dec    %r12
  111e87:	je     111f88 <imre_list_release+0x2c8>
  111e8d:	mov    -0x8(%r14),%rax
  111e91:	test   $0x1,%al
  111e93:	jne    111e80 <imre_list_release+0x1c0>
  111e95:	lea    -0x10(%rax),%rcx
  111e99:	mov    %rcx,(%rsp)
  111e9d:	decq   -0x10(%rax)
  111ea1:	jne    111e80 <imre_list_release+0x1c0>
  111ea3:	mov    %r15,%rdi
  111ea6:	call   *%r13
  111ea9:	jmp    111e80 <imre_list_release+0x1c0>
  111eab:	cmp    $0x1,%eax
  111eae:	jne    11205d <imre_list_release+0x39d>
  111eb4:	lea    0xe4a5(%rip),%rsi        # 120360 <_RINvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local6native5eager7destroyINtNtCs6SLOTazmNXq_4core4cell7RefCellAINtNtCscJq9HK9IcCJ_5alloc3vec3VecNtCs5N6zm3e4tnE_12imre_runtime3IntEj2_EEB2g_.llvm.11615576440995450655>
  111ebb:	mov    %rbx,%rdi
  111ebe:	addr32 call a0580 <_RNvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local11destructors10linux_like8register>
  111ec4:	movb   $0x0,0x38(%rbx)
  111ec8:	cmpq   $0x0,(%rbx)
  111ecc:	jne    111e3d <imre_list_release+0x17d>
  111ed2:	mov    0x18(%rbx),%rax
  111ed6:	mov    %rax,0x10(%rsp)
  111edb:	movups 0x8(%rbx),%xmm0
  111edf:	movaps %xmm0,(%rsp)
  111ee3:	movaps 0x50(%rsp),%xmm0
  111ee8:	movups %xmm0,0x8(%rbx)
  111eec:	mov    0x60(%rsp),%rax
  111ef1:	mov    %rax,0x18(%rbx)
  111ef5:	mov    0x20(%rbx),%r14
  111ef9:	mov    0x28(%rbx),%rax
  111efd:	mov    %rax,0x20(%rsp)
  111f02:	mov    0x30(%rbx),%rbp
  111f06:	movdqa (%rsp),%xmm0
  111f0b:	movdqu %xmm0,0x20(%rbx)
  111f10:	mov    0x10(%rsp),%rax
  111f15:	mov    %rax,0x30(%rbx)
  111f19:	mov    $0x8,%ebx
  111f1e:	cmp    $0xffffffffffffffff,%r14
  111f22:	je     111f88 <imre_list_release+0x2c8>
  111f24:	test   %rbp,%rbp
  111f27:	je     111f68 <imre_list_release+0x2a8>
  111f29:	mov    0x20(%rsp),%rax
  111f2e:	lea    0x8(%rax),%r12
  111f32:	mov    %rsp,%r13
  111f35:	lea    0xf304(%rip),%r15        # 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  111f3c:	jmp    111f49 <imre_list_release+0x289>
  111f3e:	xchg   %ax,%ax
  111f40:	add    $0x8,%r12
  111f44:	dec    %rbp
  111f47:	je     111f68 <imre_list_release+0x2a8>
  111f49:	mov    -0x8(%r12),%rax
  111f4e:	test   $0x1,%al
  111f50:	jne    111f40 <imre_list_release+0x280>
  111f52:	lea    -0x10(%rax),%rcx
  111f56:	mov    %rcx,(%rsp)
  111f5a:	decq   -0x10(%rax)
  111f5e:	jne    111f40 <imre_list_release+0x280>
  111f60:	mov    %r13,%rdi
  111f63:	call   *%r15
  111f66:	jmp    111f40 <imre_list_release+0x280>
  111f68:	test   %r14,%r14
  111f6b:	je     111f88 <imre_list_release+0x2c8>
  111f6d:	shl    $0x3,%r14
  111f71:	mov    $0x8,%ebx
  111f76:	mov    $0x8,%edx
  111f7b:	mov    0x20(%rsp),%rdi
  111f80:	mov    %r14,%rsi
  111f83:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  111f88:	mov    0x30(%rsp),%rsi
  111f8d:	test   %rsi,%rsi
  111f90:	je     111fa3 <imre_list_release+0x2e3>
  111f92:	shl    $0x3,%rsi
  111f96:	mov    $0x8,%edx
  111f9b:	mov    %rbx,%rdi
  111f9e:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  111fa3:	mov    0x28(%rsp),%r14
  111fa8:	mov    %r14,(%rsp)
  111fac:	data16 data16 data16 data16 mov %fs:0x0,%rax
  111fb9:	lea    -0xd0(%rax),%rbx
  111fc0:	movzbl -0xb8(%rax),%eax
  111fc7:	test   %eax,%eax
  111fc9:	jne    111fea <imre_list_release+0x32a>
  111fcb:	cmpq   $0x0,(%rbx)
  111fcf:	je     112009 <imre_list_release+0x349>
  111fd1:	movq   $0x0,(%rsp)
  111fd9:	lea    0x8(%rsp),%rdi
  111fde:	mov    %r14,0x8(%rsp)
  111fe3:	decq   (%r14)
  111fe6:	jne    11203e <imre_list_release+0x37e>
  111fe8:	jmp    112038 <imre_list_release+0x378>
  111fea:	cmp    $0x1,%eax
  111fed:	jne    11204d <imre_list_release+0x38d>
  111fef:	lea    0xe2fa(%rip),%rsi        # 1202f0 <_RINvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local6native5eager7destroyINtNtCs6SLOTazmNXq_4core4cell7RefCellAINtNtB1a_6option6OptionINtNtCscJq9HK9IcCJ_5alloc2rc2RcNtCs5N6zm3e4tnE_12imre_runtime4ListEEj2_EEB2B_.llvm.11615576440995450655>
  111ff6:	mov    %rbx,%rdi
  111ff9:	addr32 call a0580 <_RNvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local11destructors10linux_like8register>
  111fff:	movb   $0x0,0x18(%rbx)
  112003:	cmpq   $0x0,(%rbx)
  112007:	jne    111fd1 <imre_list_release+0x311>
  112009:	mov    0x8(%rbx),%rcx
  11200d:	mov    0x10(%rbx),%rax
  112011:	mov    %r14,0x8(%rbx)
  112015:	mov    %rcx,0x10(%rbx)
  112019:	movq   $0x0,(%rsp)
  112021:	mov    %rax,0x8(%rsp)
  112026:	test   %rax,%rax
  112029:	je     11203e <imre_list_release+0x37e>
  11202b:	lea    0x8(%rsp),%rdi
  112030:	mov    %rax,%r14
  112033:	decq   (%r14)
  112036:	jne    11203e <imre_list_release+0x37e>
  112038:	addr32 call 1205d0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs5N6zm3e4tnE_12imre_runtime4ListE9drop_slowBF_>
  11203e:	add    $0x68,%rsp
  112042:	pop    %rbx
  112043:	pop    %r12
  112045:	pop    %r13
  112047:	pop    %r14
  112049:	pop    %r15
  11204b:	pop    %rbp
  11204c:	ret
  11204d:	decq   (%r14)
  112050:	jne    11203e <imre_list_release+0x37e>
  112052:	mov    %rsp,%rdi
  112055:	addr32 call 1205d0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs5N6zm3e4tnE_12imre_runtime4ListE9drop_slowBF_>
  11205b:	jmp    11203e <imre_list_release+0x37e>
  11205d:	lea    0x50(%rsp),%rdi
  112062:	call   11c750 <_RNvXso_NtCscJq9HK9IcCJ_5alloc3vecINtB5_3VecNtCs5N6zm3e4tnE_12imre_runtime3IntENtNtNtCs6SLOTazmNXq_4core3ops4drop4Drop4dropBH_>
  112067:	mov    0x50(%rsp),%rsi
  11206c:	test   %rsi,%rsi
  11206f:	je     112084 <imre_list_release+0x3c4>
  112071:	mov    0x58(%rsp),%rdi
  112076:	shl    $0x3,%rsi
  11207a:	mov    $0x8,%edx
  11207f:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  112084:	mov    $0x8,%ebx
  112089:	jmp    111f88 <imre_list_release+0x2c8>
  11208e:	mov    0x50(%rsp),%rsi
  112093:	test   %rsi,%rsi
  112096:	je     112109 <imre_list_release+0x449>
  112098:	mov    0x58(%rsp),%rdi
  11209d:	shl    $0x3,%rsi
  1120a1:	mov    $0x8,%edx
  1120a6:	jmp    112104 <imre_list_release+0x444>
  1120a8:	lea    0x50(%rsp),%rdi
  1120ad:	call   107e20 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtB4_4cell10UnsafeCellINtNtCscJq9HK9IcCJ_5alloc3vec3VecNtCs5N6zm3e4tnE_12imre_runtime3IntEEEB1z_.llvm.6469393670801744543>
  1120b2:	jmp    112109 <imre_list_release+0x449>
  1120b4:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  1120ba:	decq   (%r14)
  1120bd:	jne    11216d <imre_list_release+0x4ad>
  1120c3:	mov    %rsp,%rdi
  1120c6:	addr32 call 1205d0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs5N6zm3e4tnE_12imre_runtime4ListE9drop_slowBF_>
  1120cc:	jmp    11216d <imre_list_release+0x4ad>
  1120d1:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  1120d7:	dec    %rbp
  1120da:	je     1120ee <imre_list_release+0x42e>
  1120dc:	lea    0x8(%r12),%rbx
  1120e1:	mov    %r12,%rdi
  1120e4:	call   109d10 <_RNvXs0_Cs5N6zm3e4tnE_12imre_runtimeNtB5_3IntNtNtNtCs6SLOTazmNXq_4core3ops4drop4Drop4drop>
  1120e9:	mov    %rbx,%r12
  1120ec:	jmp    1120d7 <imre_list_release+0x417>
  1120ee:	test   %r14,%r14
  1120f1:	je     112109 <imre_list_release+0x449>
  1120f3:	shl    $0x3,%r14
  1120f7:	mov    $0x8,%edx
  1120fc:	mov    0x20(%rsp),%rdi
  112101:	mov    %r14,%rsi
  112104:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  112109:	lea    0x30(%rsp),%rdi
  11210e:	call   107d50 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtCs5N6zm3e4tnE_12imre_runtime11StorageCellINtNtCscJq9HK9IcCJ_5alloc3vec3VecNtBE_3IntEEEBE_.llvm.6469393670801744543>
  112113:	jmp    112158 <imre_list_release+0x498>
  112115:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  11211b:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  112121:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  112127:	dec    %r12
  11212a:	je     11213d <imre_list_release+0x47d>
  11212c:	lea    0x8(%r14),%r15
  112130:	mov    %r14,%rdi
  112133:	call   109d10 <_RNvXs0_Cs5N6zm3e4tnE_12imre_runtimeNtB5_3IntNtNtNtCs6SLOTazmNXq_4core3ops4drop4Drop4drop>
  112138:	mov    %r15,%r14
  11213b:	jmp    112127 <imre_list_release+0x467>
  11213d:	mov    0x30(%rsp),%rsi
  112142:	test   %rsi,%rsi
  112145:	je     112158 <imre_list_release+0x498>
  112147:	shl    $0x3,%rsi
  11214b:	mov    $0x8,%edx
  112150:	mov    %rbx,%rdi
  112153:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  112158:	mov    0x28(%rsp),%rax
  11215d:	decq   (%rax)
  112160:	jne    11216d <imre_list_release+0x4ad>
  112162:	lea    0x28(%rsp),%rdi
  112167:	addr32 call 1205d0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs5N6zm3e4tnE_12imre_runtime4ListE9drop_slowBF_>
  11216d:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  112173:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  112179:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
