
/tmp/imre-luhn-performance-v1-thinlto/luhn:     file format elf64-x86-64


Disassembly of section .text:

00000000001192b0 <imre_str_int_list>:
  1192b0:	push   %rbp
  1192b1:	push   %r15
  1192b3:	push   %r14
  1192b5:	push   %r13
  1192b7:	push   %r12
  1192b9:	push   %rbx
  1192ba:	sub    $0x68,%rsp
  1192be:	mov    %rdi,%rbx
  1192c1:	movzbl 0x17(%rdi),%eax
  1192c5:	lea    0x40(%rax),%ecx
  1192c8:	movzbl %cl,%ecx
  1192cb:	cmp    $0x18,%cl
  1192ce:	mov    $0x18,%edx
  1192d3:	cmovb  %ecx,%edx
  1192d6:	cmp    $0xd8,%rax
  1192dc:	mov    (%rdi),%rdi
  1192df:	cmovb  %rbx,%rdi
  1192e3:	movzbl %dl,%esi
  1192e6:	mov    0x8(%rbx),%rcx
  1192ea:	cmovae %rcx,%rsi
  1192ee:	cmp    $0x40,%rsi
  1192f2:	jae    1193df <imre_str_int_list+0x12f>
  1192f8:	mov    %rsi,%rdx
  1192fb:	and    $0x38,%rdx
  1192ff:	je     11931d <imre_str_int_list+0x6d>
  119301:	movabs $0x8080808080808080,%r8
  11930b:	test   %r8,(%rdi)
  11930e:	jne    119460 <imre_str_int_list+0x1b0>
  119314:	cmp    $0x8,%edx
  119317:	jne    119456 <imre_str_int_list+0x1a6>
  11931d:	mov    %esi,%r8d
  119320:	and    $0x7,%r8d
  119324:	je     1193a0 <imre_str_int_list+0xf0>
  119326:	cmpb   $0x0,(%rdi,%rdx,1)
  11932a:	js     119460 <imre_str_int_list+0x1b0>
  119330:	cmp    $0x1,%r8d
  119334:	je     1193a0 <imre_str_int_list+0xf0>
  119336:	cmpb   $0x0,0x1(%rdi,%rdx,1)
  11933b:	js     119460 <imre_str_int_list+0x1b0>
  119341:	cmp    $0x2,%r8d
  119345:	je     1193a0 <imre_str_int_list+0xf0>
  119347:	cmpb   $0x0,0x2(%rdi,%rdx,1)
  11934c:	js     119460 <imre_str_int_list+0x1b0>
  119352:	cmp    $0x3,%r8d
  119356:	je     1193a0 <imre_str_int_list+0xf0>
  119358:	cmpb   $0x0,0x3(%rdi,%rdx,1)
  11935d:	js     119460 <imre_str_int_list+0x1b0>
  119363:	cmp    $0x4,%r8d
  119367:	je     1193a0 <imre_str_int_list+0xf0>
  119369:	cmpb   $0x0,0x4(%rdi,%rdx,1)
  11936e:	js     119460 <imre_str_int_list+0x1b0>
  119374:	cmp    $0x5,%r8d
  119378:	je     1193a0 <imre_str_int_list+0xf0>
  11937a:	cmpb   $0x0,0x5(%rdi,%rdx,1)
  11937f:	js     119460 <imre_str_int_list+0x1b0>
  119385:	cmp    $0x6,%r8d
  119389:	je     1193a0 <imre_str_int_list+0xf0>
  11938b:	cmpb   $0x0,0x6(%rdi,%rdx,1)
  119390:	js     119460 <imre_str_int_list+0x1b0>
  119396:	cmp    $0x7,%r8d
  11939a:	jne    119460 <imre_str_int_list+0x1b0>
  1193a0:	mov    %rax,%rdx
  1193a3:	add    $0xffffffffffffff40,%rdx
  1193aa:	cmp    $0x18,%rdx
  1193ae:	mov    $0x18,%r15d
  1193b4:	cmovb  %rdx,%r15
  1193b8:	cmp    $0xd8,%al
  1193ba:	cmovae %rcx,%r15
  1193be:	mov    $0x1,%r13b
  1193c1:	lea    -0x8001(%r15),%rax
  1193c8:	mov    $0x8,%r12d
  1193ce:	cmp    $0xffffffffffff8000,%rax
  1193d4:	jae    11948f <imre_str_int_list+0x1df>
  1193da:	jmp    1194bc <imre_str_int_list+0x20c>
  1193df:	movabs $0x7fffffffffffffc0,%rdx
  1193e9:	and    %rsi,%rdx
  1193ec:	add    %rdi,%rdx
  1193ef:	mov    %esi,%r8d
  1193f2:	and    $0x3f,%r8d
  1193f6:	mov    %rdi,%r9
  1193f9:	nopl   0x0(%rax)
  119400:	movdqu (%r9),%xmm0
  119405:	movdqu 0x10(%r9),%xmm1
  11940b:	por    %xmm0,%xmm1
  11940f:	movdqu 0x20(%r9),%xmm0
  119415:	movdqu 0x30(%r9),%xmm2
  11941b:	por    %xmm0,%xmm2
  11941f:	por    %xmm1,%xmm2
  119423:	pmovmskb %xmm2,%r10d
  119428:	test   %r10d,%r10d
  11942b:	jne    119460 <imre_str_int_list+0x1b0>
  11942d:	add    $0x40,%r9
  119431:	cmp    %rdx,%r9
  119434:	jne    119400 <imre_str_int_list+0x150>
  119436:	xor    %r9d,%r9d
  119439:	nopl   0x0(%rax)
  119440:	cmp    %r9,%r8
  119443:	je     1193a0 <imre_str_int_list+0xf0>
  119449:	cmpb   $0x0,(%rdx,%r9,1)
  11944e:	lea    0x1(%r9),%r9
  119452:	jns    119440 <imre_str_int_list+0x190>
  119454:	jmp    119460 <imre_str_int_list+0x1b0>
  119456:	test   %r8,0x8(%rdi)
  11945a:	je     119b5d <imre_str_int_list+0x8ad>
  119460:	cmp    $0x20,%rsi
  119464:	jae    11946e <imre_str_int_list+0x1be>
  119466:	addr32 call ebe40 <_RNvNtNtCs6SLOTazmNXq_4core3str5count23char_count_general_case>
  11946c:	jmp    119474 <imre_str_int_list+0x1c4>
  11946e:	addr32 call eb880 <_RNvNtNtCs6SLOTazmNXq_4core3str5count14do_count_chars>
  119474:	mov    %rax,%r15
  119477:	xor    %r13d,%r13d
  11947a:	lea    -0x8001(%r15),%rax
  119481:	mov    $0x8,%r12d
  119487:	cmp    $0xffffffffffff8000,%rax
  11948d:	jb     1194bc <imre_str_int_list+0x20c>
  11948f:	data16 data16 data16 data16 mov %fs:0x0,%rax
  11949c:	lea    -0x110(%rax),%r14
  1194a3:	movzbl -0xd8(%rax),%eax
  1194aa:	test   %eax,%eax
  1194ac:	jne    119cee <imre_str_int_list+0xa3e>
  1194b2:	cmpq   $0x0,(%r14)
  1194b6:	je     119d16 <imre_str_int_list+0xa66>
  1194bc:	xor    %esi,%esi
  1194be:	xor    %ebp,%ebp
  1194c0:	mov    %rsi,0x18(%rsp)
  1194c5:	mov    %r12,0x20(%rsp)
  1194ca:	mov    %rbp,0x28(%rsp)
  1194cf:	mov    %rsi,%rdx
  1194d2:	sub    %rbp,%rdx
  1194d5:	cmp    %rdx,%r15
  1194d8:	ja     1197b7 <imre_str_int_list+0x507>
  1194de:	test   %r13b,%r13b
  1194e1:	mov    %rsi,0x58(%rsp)
  1194e6:	je     11980d <imre_str_int_list+0x55d>
  1194ec:	cmp    %rdx,%r15
  1194ef:	ja     119bca <imre_str_int_list+0x91a>
  1194f5:	movzbl 0x17(%rbx),%eax
  1194f9:	lea    0x40(%rax),%ecx
  1194fc:	movzbl %cl,%ecx
  1194ff:	cmp    $0x18,%cl
  119502:	mov    $0x18,%edx
  119507:	cmovb  %ecx,%edx
  11950a:	cmp    $0xd8,%al
  11950c:	mov    (%rbx),%rax
  11950f:	cmovb  %rbx,%rax
  119513:	movzbl %dl,%ecx
  119516:	cmovae 0x8(%rbx),%rcx
  11951b:	cmp    %r15,%rcx
  11951e:	cmovae %r15,%rcx
  119522:	test   %rcx,%rcx
  119525:	je     119993 <imre_str_int_list+0x6e3>
  11952b:	lea    (%r12,%rbp,8),%rsi
  11952f:	cmp    $0x6,%rcx
  119533:	jb     119553 <imre_str_int_list+0x2a3>
  119535:	lea    (%rax,%rcx,1),%rdx
  119539:	cmp    %rdx,%rsi
  11953c:	jae    1195f7 <imre_str_int_list+0x347>
  119542:	lea    (%rcx,%rbp,1),%rdx
  119546:	lea    (%r12,%rdx,8),%rdx
  11954a:	cmp    %rdx,%rax
  11954d:	jae    1195f7 <imre_str_int_list+0x347>
  119553:	xor    %edi,%edi
  119555:	xor    %edx,%edx
  119557:	mov    %rdx,%r8
  11955a:	or     $0x1,%r8
  11955e:	test   $0x1,%cl
  119561:	je     11958a <imre_str_int_list+0x2da>
  119563:	movzbl (%rax,%rdx,1),%r9d
  119568:	add    $0xd0,%r9b
  11956c:	cmp    $0xa,%r9b
  119570:	setae  %r10b
  119574:	or     %r10b,%dil
  119577:	movzbl %r9b,%r9d
  11957b:	lea    0x1(,%r9,2),%r9
  119583:	mov    %r9,(%rsi,%rdx,8)
  119587:	mov    %r8,%rdx
  11958a:	cmp    %r8,%rcx
  11958d:	je     119715 <imre_str_int_list+0x465>
  119593:	lea    (%r12,%rbp,8),%rsi
  119597:	add    $0x8,%rsi
  11959b:	nopl   0x0(%rax,%rax,1)
  1195a0:	movzbl (%rax,%rdx,1),%r8d
  1195a5:	add    $0xd0,%r8b
  1195a9:	cmp    $0xa,%r8b
  1195ad:	setae  %r9b
  1195b1:	or     %dil,%r9b
  1195b4:	movzbl %r8b,%edi
  1195b8:	lea    0x1(,%rdi,2),%rdi
  1195c0:	mov    %rdi,-0x8(%rsi,%rdx,8)
  1195c5:	movzbl 0x1(%rax,%rdx,1),%edi
  1195ca:	add    $0xd0,%dil
  1195ce:	movzbl %dil,%r8d
  1195d2:	lea    0x1(,%r8,2),%r8
  1195da:	mov    %r8,(%rsi,%rdx,8)
  1195de:	add    $0x2,%rdx
  1195e2:	cmp    $0xa,%dil
  1195e6:	setae  %dil
  1195ea:	or     %r9b,%dil
  1195ed:	cmp    %rdx,%rcx
  1195f0:	jne    1195a0 <imre_str_int_list+0x2f0>
  1195f2:	jmp    119715 <imre_str_int_list+0x465>
  1195f7:	mov    %rcx,%rdx
  1195fa:	and    $0xfffffffffffffffc,%rdx
  1195fe:	lea    (%r12,%rbp,8),%rdi
  119602:	add    $0x10,%rdi
  119606:	pxor   %xmm0,%xmm0
  11960a:	xor    %r8d,%r8d
  11960d:	movdqa -0x1082e5(%rip),%xmm1        # 11330 <_IO_stdin_used+0x1138>
  119615:	movdqa -0x10828d(%rip),%xmm3        # 11390 <_IO_stdin_used+0x1198>
  11961d:	pcmpeqd %xmm4,%xmm4
  119621:	movdqa -0x107e69(%rip),%xmm6        # 117c0 <_IO_stdin_used+0x15c8>
  119629:	pxor   %xmm5,%xmm5
  11962d:	pxor   %xmm2,%xmm2
  119631:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  119640:	movzwl (%rax,%r8,1),%r9d
  119645:	movd   %r9d,%xmm7
  11964a:	movzwl 0x2(%rax,%r8,1),%r9d
  119650:	movd   %r9d,%xmm8
  119655:	paddb  %xmm1,%xmm7
  119659:	paddb  %xmm1,%xmm8
  11965e:	movdqa %xmm7,%xmm9
  119663:	pminub %xmm3,%xmm9
  119668:	pcmpeqb %xmm7,%xmm9
  11966d:	punpcklbw %xmm9,%xmm9
  119672:	pxor   %xmm4,%xmm9
  119677:	pshuflw $0x50,%xmm9,%xmm9
  11967d:	pshufd $0x50,%xmm9,%xmm9
  119683:	por    %xmm9,%xmm5
  119688:	movdqa %xmm8,%xmm9
  11968d:	pminub %xmm3,%xmm9
  119692:	pcmpeqb %xmm8,%xmm9
  119697:	punpcklbw %xmm9,%xmm9
  11969c:	pxor   %xmm4,%xmm9
  1196a1:	pshuflw $0x50,%xmm9,%xmm9
  1196a7:	pshufd $0x50,%xmm9,%xmm9
  1196ad:	por    %xmm9,%xmm2
  1196b2:	punpcklbw %xmm0,%xmm7
  1196b6:	punpcklwd %xmm0,%xmm7
  1196ba:	punpckldq %xmm0,%xmm7
  1196be:	punpcklbw %xmm0,%xmm8
  1196c3:	punpcklwd %xmm0,%xmm8
  1196c8:	punpckldq %xmm0,%xmm8
  1196cd:	paddq  %xmm7,%xmm7
  1196d1:	paddq  %xmm8,%xmm8
  1196d6:	por    %xmm6,%xmm7
  1196da:	por    %xmm6,%xmm8
  1196df:	movdqu %xmm7,-0x10(%rdi,%r8,8)
  1196e6:	movdqu %xmm8,(%rdi,%r8,8)
  1196ec:	add    $0x4,%r8
  1196f0:	cmp    %r8,%rdx
  1196f3:	jne    119640 <imre_str_int_list+0x390>
  1196f9:	por    %xmm5,%xmm2
  1196fd:	psllq  $0x3f,%xmm2
  119702:	movmskpd %xmm2,%edi
  119706:	test   %edi,%edi
  119708:	setne  %dil
  11970c:	cmp    %rdx,%rcx
  11970f:	jne    119557 <imre_str_int_list+0x2a7>
  119715:	test   $0x1,%dil
  119719:	je     119993 <imre_str_int_list+0x6e3>
  11971f:	movzbl 0x17(%rbx),%eax
  119723:	lea    0x40(%rax),%ecx
  119726:	movzbl %cl,%ecx
  119729:	cmp    $0x18,%cl
  11972c:	mov    $0x18,%edx
  119731:	cmovb  %ecx,%edx
  119734:	cmp    $0xd8,%al
  119736:	mov    (%rbx),%rsi
  119739:	cmovb  %rbx,%rsi
  11973d:	movzbl %dl,%eax
  119740:	cmovae 0x8(%rbx),%rax
  119745:	test   %rax,%rax
  119748:	je     119764 <imre_str_int_list+0x4b4>
  11974a:	xor    %edx,%edx
  11974c:	nopl   0x0(%rax)
  119750:	movzbl (%rsi,%rdx,1),%ecx
  119754:	add    $0xc6,%cl
  119757:	cmp    $0xf6,%cl
  11975a:	jb     119771 <imre_str_int_list+0x4c1>
  11975c:	inc    %rdx
  11975f:	cmp    %rdx,%rax
  119762:	jne    119750 <imre_str_int_list+0x4a0>
  119764:	lea    0x3b37d(%rip),%rdi        # 154ae8 <anon.ddd0a87e6a98674c996a4674a94af0e4.21.llvm.16282241626728798403>
  11976b:	addr32 call eabc0 <_RNvNtCs6SLOTazmNXq_4core6option13unwrap_failed>
  119771:	test   %rdx,%rdx
  119774:	je     119780 <imre_str_int_list+0x4d0>
  119776:	cmpb   $0xbf,(%rsi,%rdx,1)
  11977a:	jle    119e33 <imre_str_int_list+0xb83>
  119780:	lea    -0x1(%rax),%rcx
  119784:	cmp    %rdx,%rcx
  119787:	je     119794 <imre_str_int_list+0x4e4>
  119789:	cmpb   $0xbf,0x1(%rsi,%rdx,1)
  11978e:	jle    119e33 <imre_str_int_list+0xb83>
  119794:	add    %rdx,%rsi
  119797:	lea    0x30(%rsp),%rdi
  11979c:	mov    $0x1,%edx
  1197a1:	call   11a000 <_RNvNtCs5N6zm3e4tnE_12imre_runtime12integer_text15invalid_literal>
  1197a6:	lea    0x30(%rsp),%rdi
  1197ab:	xor    %esi,%esi
  1197ad:	call   1250c0 <_RINvMs0_NtNtCs5N6zm3e4tnE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  1197b2:	jmp    119ae3 <imre_str_int_list+0x833>
  1197b7:	mov    %rbp,%rcx
  1197ba:	add    %r15,%rcx
  1197bd:	jb     119e16 <imre_str_int_list+0xb66>
  1197c3:	lea    0x30(%rsp),%rdi
  1197c8:	mov    $0x8,%r8d
  1197ce:	mov    $0x8,%r9d
  1197d4:	mov    %r12,%rdx
  1197d7:	mov    %rcx,%r14
  1197da:	call   11bab0 <_RNvMs5_NtCscJq9HK9IcCJ_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs5N6zm3e4tnE_12imre_runtime.llvm.7503688146152330008>
  1197df:	cmpl   $0x1,0x30(%rsp)
  1197e4:	je     119e16 <imre_str_int_list+0xb66>
  1197ea:	mov    0x38(%rsp),%r12
  1197ef:	mov    %r12,0x20(%rsp)
  1197f4:	mov    %r14,0x18(%rsp)
  1197f9:	mov    %r15,%rdx
  1197fc:	mov    %r14,%rsi
  1197ff:	test   %r13b,%r13b
  119802:	mov    %rsi,0x58(%rsp)
  119807:	jne    1194ec <imre_str_int_list+0x23c>
  11980d:	cmp    %rdx,%r15
  119810:	ja     119bd3 <imre_str_int_list+0x923>
  119816:	movzbl 0x17(%rbx),%eax
  11981a:	lea    0x40(%rax),%ecx
  11981d:	movzbl %cl,%ecx
  119820:	cmp    $0x18,%cl
  119823:	mov    $0x18,%edx
  119828:	cmovb  %ecx,%edx
  11982b:	cmp    $0xd8,%al
  11982d:	mov    (%rbx),%rax
  119830:	cmovb  %rbx,%rax
  119834:	movzbl %dl,%ecx
  119837:	cmovae 0x8(%rbx),%rcx
  11983c:	test   %r15,%r15
  11983f:	je     119993 <imre_str_int_list+0x6e3>
  119845:	lea    (%r12,%rbp,8),%rdx
  119849:	lea    0x0(,%r15,8),%rsi
  119851:	add    %rax,%rcx
  119854:	xor    %edi,%edi
  119856:	lea    -0xee479(%rip),%r8        # 2b3e4 <anon.a0394fcca565d9ffac7ff94a671f9ce6.7.llvm.8127815363409927359>
  11985d:	xor    %r10d,%r10d
  119860:	cmp    %rcx,%rax
  119863:	je     119993 <imre_str_int_list+0x6e3>
  119869:	movzbl (%rax),%r9d
  11986d:	test   %r9b,%r9b
  119870:	js     119880 <imre_str_int_list+0x5d0>
  119872:	inc    %rax
  119875:	jmp    1198f0 <imre_str_int_list+0x640>
  119877:	nopw   0x0(%rax,%rax,1)
  119880:	mov    %r9d,%r11d
  119883:	and    $0x1f,%r11d
  119887:	movzbl 0x1(%rax),%r14d
  11988c:	and    $0x3f,%r14d
  119890:	cmp    $0xdf,%r9b
  119894:	jbe    1198ca <imre_str_int_list+0x61a>
  119896:	movzbl 0x2(%rax),%ebx
  11989a:	shl    $0x6,%r14d
  11989e:	and    $0x3f,%ebx
  1198a1:	or     %r14d,%ebx
  1198a4:	cmp    $0xf0,%r9b
  1198a8:	jb     1198da <imre_str_int_list+0x62a>
  1198aa:	movzbl 0x3(%rax),%r9d
  1198af:	add    $0x4,%rax
  1198b3:	and    $0x7,%r11d
  1198b7:	shl    $0x12,%r11d
  1198bb:	shl    $0x6,%ebx
  1198be:	and    $0x3f,%r9d
  1198c2:	or     %ebx,%r9d
  1198c5:	or     %r11d,%r9d
  1198c8:	jmp    1198f0 <imre_str_int_list+0x640>
  1198ca:	add    $0x2,%rax
  1198ce:	shl    $0x6,%r11d
  1198d2:	or     %r14d,%r11d
  1198d5:	mov    %r11d,%r9d
  1198d8:	jmp    1198f0 <imre_str_int_list+0x640>
  1198da:	add    $0x3,%rax
  1198de:	shl    $0xc,%r11d
  1198e2:	or     %r11d,%ebx
  1198e5:	mov    %ebx,%r9d
  1198e8:	nopl   0x0(%rax,%rax,1)
  1198f0:	cmp    $0x10d30,%r9d
  1198f7:	mov    $0x26,%r11d
  1198fd:	cmovb  %rdi,%r11
  119901:	cmp    %r9d,0x4c(%r8,%r11,4)
  119906:	lea    0x13(%r11),%rbx
  11990a:	cmova  %r11,%rbx
  11990e:	cmp    %r9d,0x24(%r8,%rbx,4)
  119913:	lea    0x9(%rbx),%r11
  119917:	cmova  %rbx,%r11
  11991b:	cmp    %r9d,0x14(%r8,%r11,4)
  119920:	lea    0x5(%r11),%rbx
  119924:	cmova  %r11,%rbx
  119928:	cmp    %r9d,0x8(%r8,%rbx,4)
  11992d:	lea    0x2(%rbx),%r11
  119931:	cmova  %rbx,%r11
  119935:	cmp    %r9d,0x4(%r8,%r11,4)
  11993a:	lea    0x1(%r11),%rbx
  11993e:	cmova  %r11,%rbx
  119942:	cmp    %r9d,0x4(%r8,%rbx,4)
  119947:	lea    0x1(%rbx),%r14
  11994b:	cmova  %rbx,%r14
  11994f:	xor    %r11d,%r11d
  119952:	cmp    %r9d,(%r8,%r14,4)
  119956:	setbe  %r11b
  11995a:	add    %r14,%r11
  11995d:	je     119a3b <imre_str_int_list+0x78b>
  119963:	mov    %r9d,%ebx
  119966:	sub    -0x4(%r8,%r11,4),%ebx
  11996b:	jb     119a3b <imre_str_int_list+0x78b>
  119971:	cmp    $0x9,%ebx
  119974:	ja     119a3b <imre_str_int_list+0x78b>
  11997a:	lea    0x1(,%rbx,2),%r9d
  119982:	mov    %r9,(%rdx,%r10,1)
  119986:	add    $0x8,%r10
  11998a:	cmp    %r10,%rsi
  11998d:	jne    119860 <imre_str_int_list+0x5b0>
  119993:	mov    %r15,0x28(%rsp)
  119998:	mov    %r15,0x10(%rsp)
  11999d:	movdqu 0x18(%rsp),%xmm0
  1199a3:	movdqa %xmm0,(%rsp)
  1199a8:	data16 data16 data16 data16 mov %fs:0x0,%rax
  1199b5:	lea    -0xd0(%rax),%r14
  1199bc:	movzbl -0xb8(%rax),%eax
  1199c3:	test   %eax,%eax
  1199c5:	jne    119bf5 <imre_str_int_list+0x945>
  1199cb:	cmpq   $0x0,(%r14)
  1199cf:	je     119c1d <imre_str_int_list+0x96d>
  1199d5:	mov    0x28(%rsp),%rax
  1199da:	mov    %rax,0x50(%rsp)
  1199df:	movdqu 0x18(%rsp),%xmm0
  1199e5:	movdqu %xmm0,0x40(%rsp)
  1199eb:	movq   $0x1,0x30(%rsp)
  1199f4:	movq   $0x1,0x38(%rsp)
  1199fd:	mov    $0x28,%edi
  119a02:	mov    $0x8,%esi
  119a07:	call   75720 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  119a0c:	test   %rax,%rax
  119a0f:	je     119be5 <imre_str_int_list+0x935>
  119a15:	mov    %rax,%rbx
  119a18:	mov    0x50(%rsp),%rax
  119a1d:	mov    %rax,0x20(%rbx)
  119a21:	movdqu 0x30(%rsp),%xmm0
  119a27:	movdqu 0x40(%rsp),%xmm1
  119a2d:	movdqu %xmm1,0x10(%rbx)
  119a32:	movdqu %xmm0,(%rbx)
  119a36:	jmp    119cd8 <imre_str_int_list+0xa28>
  119a3b:	movl   $0x0,(%rsp)
  119a42:	cmp    $0x80,%r9d
  119a49:	jae    119a56 <imre_str_int_list+0x7a6>
  119a4b:	mov    %r9b,(%rsp)
  119a4f:	mov    $0x1,%edx
  119a54:	jmp    119aca <imre_str_int_list+0x81a>
  119a56:	mov    %r9d,%eax
  119a59:	and    $0x3f,%al
  119a5b:	or     $0x80,%al
  119a5d:	mov    %r9d,%ecx
  119a60:	shr    $0x6,%ecx
  119a63:	cmp    $0x800,%r9d
  119a6a:	jae    119a7d <imre_str_int_list+0x7cd>
  119a6c:	or     $0xc0,%cl
  119a6f:	mov    %cl,(%rsp)
  119a72:	mov    %al,0x1(%rsp)
  119a76:	mov    $0x2,%edx
  119a7b:	jmp    119aca <imre_str_int_list+0x81a>
  119a7d:	and    $0x3f,%cl
  119a80:	or     $0x80,%cl
  119a83:	mov    %r9d,%edx
  119a86:	shr    $0xc,%edx
  119a89:	cmp    $0xffff,%r9d
  119a90:	ja     119aa7 <imre_str_int_list+0x7f7>
  119a92:	or     $0xe0,%dl
  119a95:	mov    %dl,(%rsp)
  119a98:	mov    %cl,0x1(%rsp)
  119a9c:	mov    %al,0x2(%rsp)
  119aa0:	mov    $0x3,%edx
  119aa5:	jmp    119aca <imre_str_int_list+0x81a>
  119aa7:	and    $0x3f,%dl
  119aaa:	or     $0x80,%dl
  119aad:	shr    $0x12,%r9d
  119ab1:	or     $0xf0,%r9b
  119ab5:	mov    %r9b,(%rsp)
  119ab9:	mov    %dl,0x1(%rsp)
  119abd:	mov    %cl,0x2(%rsp)
  119ac1:	mov    %al,0x3(%rsp)
  119ac5:	mov    $0x4,%edx
  119aca:	lea    0x30(%rsp),%rdi
  119acf:	mov    %rsp,%rsi
  119ad2:	call   11a000 <_RNvNtCs5N6zm3e4tnE_12imre_runtime12integer_text15invalid_literal>
  119ad7:	lea    0x30(%rsp),%rdi
  119adc:	xor    %esi,%esi
  119ade:	call   1250c0 <_RINvMs0_NtNtCs5N6zm3e4tnE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  119ae3:	mov    %rax,%rbx
  119ae6:	mov    0x20(%rsp),%r15
  119aeb:	test   %rbp,%rbp
  119aee:	je     119b39 <imre_str_int_list+0x889>
  119af0:	lea    0x8(%r15),%r12
  119af4:	lea    0x30(%rsp),%r13
  119af9:	lea    0x7740(%rip),%r14        # 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  119b00:	jmp    119b19 <imre_str_int_list+0x869>
  119b02:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  119b10:	add    $0x8,%r12
  119b14:	dec    %rbp
  119b17:	je     119b39 <imre_str_int_list+0x889>
  119b19:	mov    -0x8(%r12),%rax
  119b1e:	test   $0x1,%al
  119b20:	jne    119b10 <imre_str_int_list+0x860>
  119b22:	lea    -0x10(%rax),%rcx
  119b26:	mov    %rcx,0x30(%rsp)
  119b2b:	decq   -0x10(%rax)
  119b2f:	jne    119b10 <imre_str_int_list+0x860>
  119b31:	mov    %r13,%rdi
  119b34:	call   *%r14
  119b37:	jmp    119b10 <imre_str_int_list+0x860>
  119b39:	mov    0x58(%rsp),%rsi
  119b3e:	test   %rsi,%rsi
  119b41:	je     119cdc <imre_str_int_list+0xa2c>
  119b47:	shl    $0x3,%rsi
  119b4b:	mov    $0x8,%edx
  119b50:	mov    %r15,%rdi
  119b53:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  119b58:	jmp    119cdc <imre_str_int_list+0xa2c>
  119b5d:	cmp    $0x10,%edx
  119b60:	je     11931d <imre_str_int_list+0x6d>
  119b66:	test   %r8,0x10(%rdi)
  119b6a:	jne    119460 <imre_str_int_list+0x1b0>
  119b70:	cmp    $0x18,%edx
  119b73:	je     11931d <imre_str_int_list+0x6d>
  119b79:	test   %r8,0x18(%rdi)
  119b7d:	jne    119460 <imre_str_int_list+0x1b0>
  119b83:	cmp    $0x20,%edx
  119b86:	je     11931d <imre_str_int_list+0x6d>
  119b8c:	test   %r8,0x20(%rdi)
  119b90:	jne    119460 <imre_str_int_list+0x1b0>
  119b96:	cmp    $0x28,%edx
  119b99:	je     11931d <imre_str_int_list+0x6d>
  119b9f:	test   %r8,0x28(%rdi)
  119ba3:	jne    119460 <imre_str_int_list+0x1b0>
  119ba9:	cmp    $0x30,%edx
  119bac:	je     11931d <imre_str_int_list+0x6d>
  119bb2:	test   %r8,0x30(%rdi)
  119bb6:	jne    119460 <imre_str_int_list+0x1b0>
  119bbc:	cmp    $0x38,%edx
  119bbf:	je     11931d <imre_str_int_list+0x6d>
  119bc5:	jmp    119460 <imre_str_int_list+0x1b0>
  119bca:	lea    0x3af5f(%rip),%rcx        # 154b30 <anon.ddd0a87e6a98674c996a4674a94af0e4.24.llvm.16282241626728798403>
  119bd1:	jmp    119bda <imre_str_int_list+0x92a>
  119bd3:	lea    0x3aef6(%rip),%rcx        # 154ad0 <anon.ddd0a87e6a98674c996a4674a94af0e4.20.llvm.16282241626728798403>
  119bda:	xor    %edi,%edi
  119bdc:	mov    %r15,%rsi
  119bdf:	addr32 call ec320 <_RNvNtNtCs6SLOTazmNXq_4core5slice5index16slice_index_fail>
  119be5:	mov    $0x8,%edi
  119bea:	mov    $0x28,%esi
  119bef:	addr32 call dd389 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  119bf5:	cmp    $0x2,%eax
  119bf8:	je     1199d5 <imre_str_int_list+0x725>
  119bfe:	lea    0x66eb(%rip),%rsi        # 1202f0 <_RINvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local6native5eager7destroyINtNtCs6SLOTazmNXq_4core4cell7RefCellAINtNtB1a_6option6OptionINtNtCscJq9HK9IcCJ_5alloc2rc2RcNtCs5N6zm3e4tnE_12imre_runtime4ListEEj2_EEB2B_.llvm.11615576440995450655>
  119c05:	mov    %r14,%rdi
  119c08:	addr32 call a0580 <_RNvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local11destructors10linux_like8register>
  119c0e:	movb   $0x0,0x18(%r14)
  119c13:	cmpq   $0x0,(%r14)
  119c17:	jne    1199d5 <imre_str_int_list+0x725>
  119c1d:	mov    0x8(%r14),%rbx
  119c21:	mov    0x10(%r14),%rax
  119c25:	movq   $0x0,0x10(%r14)
  119c2d:	mov    %rax,0x8(%r14)
  119c31:	test   %rbx,%rbx
  119c34:	je     1199d5 <imre_str_int_list+0x725>
  119c3a:	mov    %rbx,0x60(%rsp)
  119c3f:	cmpq   $0x1,0x8(%rbx)
  119c44:	jne    119dfd <imre_str_int_list+0xb4d>
  119c4a:	cmpq   $0x1,(%rbx)
  119c4e:	jne    119dfd <imre_str_int_list+0xb4d>
  119c54:	lea    0x10(%rbx),%r12
  119c58:	mov    0x20(%rbx),%r13
  119c5c:	test   %r13,%r13
  119c5f:	je     119ca7 <imre_str_int_list+0x9f7>
  119c61:	mov    0x18(%rbx),%r14
  119c65:	add    $0x8,%r14
  119c69:	lea    0x30(%rsp),%r15
  119c6e:	lea    0x75cb(%rip),%rbp        # 121240 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  119c75:	jmp    119c89 <imre_str_int_list+0x9d9>
  119c77:	nopw   0x0(%rax,%rax,1)
  119c80:	add    $0x8,%r14
  119c84:	dec    %r13
  119c87:	je     119ca7 <imre_str_int_list+0x9f7>
  119c89:	mov    -0x8(%r14),%rax
  119c8d:	test   $0x1,%al
  119c8f:	jne    119c80 <imre_str_int_list+0x9d0>
  119c91:	lea    -0x10(%rax),%rcx
  119c95:	mov    %rcx,0x30(%rsp)
  119c9a:	decq   -0x10(%rax)
  119c9e:	jne    119c80 <imre_str_int_list+0x9d0>
  119ca0:	mov    %r15,%rdi
  119ca3:	call   *%rbp
  119ca5:	jmp    119c80 <imre_str_int_list+0x9d0>
  119ca7:	mov    (%r12),%rsi
  119cab:	test   %rsi,%rsi
  119cae:	je     119cc2 <imre_str_int_list+0xa12>
  119cb0:	mov    0x18(%rbx),%rdi
  119cb4:	shl    $0x3,%rsi
  119cb8:	mov    $0x8,%edx
  119cbd:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  119cc2:	mov    0x28(%rsp),%rax
  119cc7:	mov    %rax,0x10(%r12)
  119ccc:	movdqu 0x18(%rsp),%xmm0
  119cd2:	movdqu %xmm0,(%r12)
  119cd8:	add    $0x10,%rbx
  119cdc:	mov    %rbx,%rax
  119cdf:	add    $0x68,%rsp
  119ce3:	pop    %rbx
  119ce4:	pop    %r12
  119ce6:	pop    %r13
  119ce8:	pop    %r14
  119cea:	pop    %r15
  119cec:	pop    %rbp
  119ced:	ret
  119cee:	cmp    $0x1,%eax
  119cf1:	jne    119df0 <imre_str_int_list+0xb40>
  119cf7:	lea    0x6662(%rip),%rsi        # 120360 <_RINvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local6native5eager7destroyINtNtCs6SLOTazmNXq_4core4cell7RefCellAINtNtCscJq9HK9IcCJ_5alloc3vec3VecNtCs5N6zm3e4tnE_12imre_runtime3IntEj2_EEB2g_.llvm.11615576440995450655>
  119cfe:	mov    %r14,%rdi
  119d01:	addr32 call a0580 <_RNvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local11destructors10linux_like8register>
  119d07:	movb   $0x0,0x38(%r14)
  119d0c:	cmpq   $0x0,(%r14)
  119d10:	jne    1194bc <imre_str_int_list+0x20c>
  119d16:	lea    (%r15,%r15,1),%rax
  119d1a:	mov    0x8(%r14),%rdx
  119d1e:	mov    0x20(%r14),%rcx
  119d22:	cmp    %rdx,%r15
  119d25:	seta   %sil
  119d29:	cmp    %rax,%rdx
  119d2c:	seta   %dil
  119d30:	or     %sil,%dil
  119d33:	je     119d56 <imre_str_int_list+0xaa6>
  119d35:	cmp    %rcx,%r15
  119d38:	seta   %dl
  119d3b:	cmp    %rax,%rcx
  119d3e:	seta   %al
  119d41:	or     %dl,%al
  119d43:	mov    $0x1,%eax
  119d48:	je     119d74 <imre_str_int_list+0xac4>
  119d4a:	movq   $0x0,(%r14)
  119d51:	jmp    1194bc <imre_str_int_list+0x20c>
  119d56:	cmp    %rcx,%r15
  119d59:	setbe  %sil
  119d5d:	cmp    %rax,%rcx
  119d60:	setbe  %al
  119d63:	test   %al,%sil
  119d66:	je     119d72 <imre_str_int_list+0xac2>
  119d68:	xor    %eax,%eax
  119d6a:	cmp    %rcx,%rdx
  119d6d:	seta   %al
  119d70:	jmp    119d74 <imre_str_int_list+0xac4>
  119d72:	xor    %eax,%eax
  119d74:	lea    0x8(%r14),%rcx
  119d78:	lea    (%rax,%rax,2),%rdx
  119d7c:	mov    (%rcx,%rdx,8),%rsi
  119d80:	mov    0x8(%rcx,%rdx,8),%r12
  119d85:	mov    0x10(%rcx,%rdx,8),%rbp
  119d8a:	movq   $0x0,(%rcx,%rdx,8)
  119d92:	movq   $0x8,0x8(%rcx,%rdx,8)
  119d9b:	movq   $0x0,0x10(%rcx,%rdx,8)
  119da4:	test   %rax,%rax
  119da7:	jne    119ddf <imre_str_int_list+0xb2f>
  119da9:	lea    0x20(%r14),%rax
  119dad:	mov    0x10(%rcx),%rdx
  119db1:	mov    %rdx,0x40(%rsp)
  119db6:	movups (%rcx),%xmm0
  119db9:	movaps %xmm0,0x30(%rsp)
  119dbe:	mov    0x10(%rax),%rdx
  119dc2:	mov    %rdx,0x10(%rcx)
  119dc6:	movups (%rax),%xmm0
  119dc9:	movups %xmm0,(%rcx)
  119dcc:	mov    0x40(%rsp),%rcx
  119dd1:	mov    %rcx,0x10(%rax)
  119dd5:	movdqa 0x30(%rsp),%xmm0
  119ddb:	movdqu %xmm0,(%rax)
  119ddf:	movq   $0x0,(%r14)
  119de6:	cmp    $0xffffffffffffffff,%rsi
  119dea:	jne    1194c0 <imre_str_int_list+0x210>
  119df0:	xor    %esi,%esi
  119df2:	mov    $0x8,%r12d
  119df8:	jmp    1194be <imre_str_int_list+0x20e>
  119dfd:	lea    -0xef153(%rip),%rdi        # 2acb1 <anon.76308f6739ee2ec32d8bb5a37ebbcff7.23.llvm.6469393670801744543>
  119e04:	lea    0x3aabd(%rip),%rdx        # 1548c8 <anon.76308f6739ee2ec32d8bb5a37ebbcff7.24.llvm.6469393670801744543>
  119e0b:	mov    $0x1c,%esi
  119e10:	addr32 call eab80 <_RNvNtCs6SLOTazmNXq_4core6option13expect_failed>
  119e16:	lea    -0xeeaa8(%rip),%rdi        # 2b375 <anon.ddd0a87e6a98674c996a4674a94af0e4.0.llvm.16282241626728798403>
  119e1d:	lea    -0xeeaa4(%rip),%rdx        # 2b380 <anon.ddd0a87e6a98674c996a4674a94af0e4.8.llvm.16282241626728798403>
  119e24:	mov    $0xb,%esi
  119e29:	mov    $0x16,%ecx
  119e2e:	call   1092a0 <_RNvCs5N6zm3e4tnE_12imre_runtime4fail>
  119e33:	lea    0x1(%rdx),%rcx
  119e37:	lea    0x3acc2(%rip),%r8        # 154b00 <anon.ddd0a87e6a98674c996a4674a94af0e4.22.llvm.16282241626728798403>
  119e3e:	mov    %rsi,%rdi
  119e41:	mov    %rax,%rsi
  119e44:	addr32 call ea570 <_RNvNtCs6SLOTazmNXq_4core3str16slice_error_fail>
  119e4a:	jmp    119f16 <imre_str_int_list+0xc66>
  119e4f:	lea    -0x10146(%rip),%r15        # 109d10 <_RNvXs0_Cs5N6zm3e4tnE_12imre_runtimeNtB5_3IntNtNtNtCs6SLOTazmNXq_4core3ops4drop4Drop4drop>
  119e56:	cs nopw 0x0(%rax,%rax,1)
  119e60:	dec    %r13
  119e63:	je     119e74 <imre_str_int_list+0xbc4>
  119e65:	lea    0x8(%r14),%rbp
  119e69:	mov    %r14,%rdi
  119e6c:	call   *%r15
  119e6f:	mov    %rbp,%r14
  119e72:	jmp    119e60 <imre_str_int_list+0xbb0>
  119e74:	mov    (%r12),%rsi
  119e78:	test   %rsi,%rsi
  119e7b:	je     119e8f <imre_str_int_list+0xbdf>
  119e7d:	mov    0x18(%rbx),%rdi
  119e81:	shl    $0x3,%rsi
  119e85:	mov    $0x8,%edx
  119e8a:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  119e8f:	mov    0x28(%rsp),%rax
  119e94:	mov    %rax,0x10(%r12)
  119e99:	movdqu 0x18(%rsp),%xmm0
  119e9f:	movdqu %xmm0,(%r12)
  119ea5:	xor    %ebp,%ebp
  119ea7:	jmp    119f01 <imre_str_int_list+0xc51>
  119ea9:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  119eaf:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  119eb5:	lea    -0x101ac(%rip),%rbx        # 109d10 <_RNvXs0_Cs5N6zm3e4tnE_12imre_runtimeNtB5_3IntNtNtNtCs6SLOTazmNXq_4core3ops4drop4Drop4drop>
  119ebc:	nopl   0x0(%rax)
  119ec0:	dec    %rbp
  119ec3:	je     119ed4 <imre_str_int_list+0xc24>
  119ec5:	lea    0x8(%r12),%r14
  119eca:	mov    %r12,%rdi
  119ecd:	call   *%rbx
  119ecf:	mov    %r14,%r12
  119ed2:	jmp    119ec0 <imre_str_int_list+0xc10>
  119ed4:	cmpq   $0x0,0x58(%rsp)
  119eda:	je     119f42 <imre_str_int_list+0xc92>
  119edc:	mov    0x58(%rsp),%rsi
  119ee1:	shl    $0x3,%rsi
  119ee5:	mov    $0x8,%edx
  119eea:	mov    %r15,%rdi
  119eed:	call   75790 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  119ef2:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  119ef8:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  119efe:	mov    $0x1,%bpl
  119f01:	decq   (%rbx)
  119f04:	jne    119f11 <imre_str_int_list+0xc61>
  119f06:	lea    0x60(%rsp),%rdi
  119f0b:	addr32 call 1205d0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs5N6zm3e4tnE_12imre_runtime4ListE9drop_slowBF_>
  119f11:	test   %bpl,%bpl
  119f14:	je     119f42 <imre_str_int_list+0xc92>
  119f16:	mov    %rsp,%rdi
  119f19:	call   108300 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc3vec3VecNtCs5N6zm3e4tnE_12imre_runtime3IntEEB1a_.llvm.6469393670801744543>
  119f1e:	jmp    119f42 <imre_str_int_list+0xc92>
  119f20:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  119f26:	lea    0x30(%rsp),%rdi
  119f2b:	call   107f30 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerNtCs5N6zm3e4tnE_12imre_runtime4ListEEB1d_.llvm.6469393670801744543>
  119f30:	jmp    119f42 <imre_str_int_list+0xc92>
  119f32:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  119f38:	lea    0x18(%rsp),%rdi
  119f3d:	call   117e90 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc3vec3VecNtCs5N6zm3e4tnE_12imre_runtime3IntEEB1a_.llvm.16282241626728798403>
  119f42:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  119f48:	addr32 call eac9e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
