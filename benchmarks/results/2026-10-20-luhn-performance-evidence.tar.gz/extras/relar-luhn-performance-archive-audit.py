"""Independently inspect the final archive without running retained workloads."""

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
from datetime import datetime, timezone


REVISION = "8b54eae6572a93926265d78562656dd395ad28b0"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def native(data):
    return (
        data.startswith((b"\x7fELF", b"!<arch>\n", b"!<thin>\n", b"BC\xc0\xde", b"\xde\xc0\x17\x0b", b"MZ"))
        or data[:4] in (
            b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
            b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe",
            b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", type=Path, required=True)
    parser.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/relar"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    archive_path = Path(str(args.prefix) + "-evidence.tar.gz")
    manifest_path = Path(str(args.prefix) + "-evidence-manifest.json")
    manifest = json.loads(manifest_path.read_text())
    assert manifest["status"] == "passed"
    assert all(manifest[name] == REVISION for name in
               ("revision", "build_revision", "validation_revision", "timing_revision"))
    assert manifest["post_validation_paths"] == []
    assert sha(archive_path) == manifest["archive"]["sha256"]
    assert archive_path.stat().st_size == manifest["archive"]["bytes"]
    with archive_path.open("rb") as stream:
        header = stream.read(10)
    assert header[:3] == b"\x1f\x8b\x08" and header[4:8] == b"\0" * 4
    assert not header[3] & 8
    selected = {}
    source = {}
    total_bytes = 0
    retained = {
        "provenance/package.json", "provenance/baseline-evidence.json",
        "provenance/exclusions.json", "validation/source-before.json",
        "validation/source-after.json", "validation/index.json", "validation/build.json",
        "audits/validation.json", "audits/timing.json", "timing/status.json",
        "timing/normal.json", "timing/thinlto.json",
        "profiles/short/summary.json", "profiles/large/summary.json",
        "audits/profile-short.json", "audits/profile-large.json",
        "extras/relar-luhn-performance-validation-v1/index.json",
        "extras/relar-luhn-performance-validation-v2/index.json",
        "extras/relar-luhn-performance-report.md",
        "extras/relar-luhn-performance-report-audit.json",
    }
    with tarfile.open(archive_path, "r:gz") as archive:
        entries = archive.getmembers()
        names = [item.name for item in entries]
        assert names == sorted(manifest["members"])
        assert len(names) == len(set(names)) == manifest["member_count"]
        for item in entries:
            path = PurePosixPath(item.name)
            assert not path.is_absolute() and ".." not in path.parts
            assert item.isfile() and item.mode in (0o644, 0o755)
            assert item.uid == item.gid == item.mtime == 0
            assert item.uname == item.gname == ""
            data = archive.extractfile(item).read()
            expected = manifest["members"][item.name]
            assert len(data) == item.size == expected["bytes"]
            assert item.mode == expected["mode"]
            assert digest(data) == expected["sha256"]
            assert not native(data[:16])
            assert path.suffix != ".pyc" and "__pycache__" not in path.parts
            total_bytes += len(data)
            if item.name.startswith("source/"):
                source[item.name.removeprefix("source/")] = data
            elif item.name in retained:
                selected[item.name] = data
    assert set(selected) == retained

    def record(name):
        return json.loads(selected[name])

    package = record("provenance/package.json")
    assert package["revision"] == REVISION
    source_snapshot = record("validation/source-before.json")
    assert source_snapshot == record("validation/source-after.json")
    assert source_snapshot["revision"] == REVISION and source_snapshot["status"] == ""
    assert set(source) == set(source_snapshot["files"])
    assert len(source) == manifest["source_files"]
    assert all(digest(data) == source_snapshot["files"][name]["sha256"]
               for name, data in source.items())
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    git_command = ["git", "-C", str(args.root), "archive", "--format=tar", REVISION, "--", *sorted(source)]
    git_bytes = subprocess.check_output(git_command, env=environment)
    with tarfile.open(fileobj=io.BytesIO(git_bytes), mode="r:") as archive:
        original = {item.name: archive.extractfile(item).read()
                    for item in archive if item.isfile()}
    assert original == source
    index = record("validation/index.json")
    build = record("validation/build.json")
    validation = record("audits/validation.json")
    assert index["status"] == validation["status"] == "passed"
    assert index["revision"] == build["revision"] == validation["validation_revision"] == REVISION
    assert digest(selected["validation/index.json"]) == manifest["validation_index_sha256"]
    assert digest(selected["validation/build.json"]) == manifest["validation_build_sha256"]
    assert index["job_counts"] == {"passed": 129, "failed": 0}
    assert validation["counts"] == manifest["validation_counts"]
    timing = record("timing/status.json")
    timing_audit = record("audits/timing.json")
    assert timing["status"] == timing_audit["status"] == "passed"
    assert timing["input_guards_passed"] and timing["source_unchanged"]
    assert all(timing[name] == REVISION for name in
               ("head", "build_revision", "validation_revision", "timing_revision"))
    assert timing["post_validation_changes"]["paths"] == []
    assert timing["post_validation_changes"]["patch"] == ""
    assert digest(selected["timing/status.json"]) == timing_audit["timing_status_sha256"]
    assert timing_audit["validation_index_sha256"] == digest(selected["validation/index.json"])
    for mode in ("normal", "thinlto"):
        timed = record(f"timing/{mode}.json")
        assert timed["revision"] == REVISION and timed["relar_build_record"] == build
        assert digest(selected[f"timing/{mode}.json"]) == timing_audit["identities"][mode]["record_sha256"]
    for role in ("short", "large"):
        summary = record(f"profiles/{role}/summary.json")
        audit = record(f"audits/profile-{role}.json")
        assert summary["status"] == audit["status"] == "passed"
        assert summary["complete"] and summary["input_guards_passed"]
        assert all(summary[name] == REVISION for name in
                   ("revision", "build_revision", "validation_revision", "timing_revision"))
        assert digest(selected[f"profiles/{role}/summary.json"]) == audit["profile_summary_sha256"]
        assert audit["validation_index_sha256"] == digest(selected["validation/index.json"])
    baseline = record("provenance/baseline-evidence.json")
    assert baseline["archive_included"] is False
    assert baseline == manifest["baseline_evidence"]
    assert not any(Path(name).name == Path(baseline["archive_path"]).name
                   for name in manifest["members"])
    exclusions = record("provenance/exclusions.json")
    assert len(exclusions["artifacts"]) == manifest["excluded_artifact_count"]
    assert all(item["hash_verified_during_packaging"] for item in exclusions["artifacts"])
    assert all(item["would_be_member"] not in manifest["members"] for item in exclusions["artifacts"])
    historical = {}
    for attempt, passed, failed in (("v1", 124, 5), ("v2", 126, 3)):
        previous = record(f"extras/relar-luhn-performance-validation-{attempt}/index.json")
        assert previous["status"] == "failed"
        assert previous["job_counts"] == {"passed": passed, "failed": failed}
        historical[attempt] = previous["job_counts"]
    assert "extras/relar-luhn-opt-r7-provenance-issue.json" in manifest["members"]
    report_name = "extras/relar-luhn-performance-report.md"
    report = selected[report_name].decode()
    assert "@@" not in report and REVISION in report
    report_audit = record("extras/relar-luhn-performance-report-audit.json")
    assert report_audit["status"] == "passed" and report_audit["remaining_placeholders"] == []
    assert report_audit["input_sha256"]["/tmp/relar-luhn-performance-report.md"] == digest(selected[report_name])
    result = {
        "schema": 1,
        "status": "passed",
        "at_utc": datetime.now(timezone.utc).isoformat(),
        "revision": REVISION,
        "auditor_sha256": sha(__file__),
        "archive": {"path": str(archive_path), "sha256": sha(archive_path), "bytes": archive_path.stat().st_size},
        "manifest": {"path": str(manifest_path), "sha256": sha(manifest_path)},
        "member_count": len(manifest["members"]),
        "uncompressed_member_bytes": total_bytes,
        "source_files_verified_against_git_revision": len(source),
        "excluded_native_artifacts": manifest["excluded_artifact_count"],
        "checks": {
            "all_member_hashes_sizes_modes_and_names_match": True,
            "normalized_archive_metadata": True,
            "no_native_or_bytecode_members": True,
            "final_build_validation_timing_profiles_report_bound": True,
            "baseline_archive_linked_not_nested": True,
            "failed_attempts_retained_as_historical_extras": historical,
            "r7_mixed_source_issue_retained": True,
        },
        "limits": [
            "No retained workloads were rerun.",
            "Native artifacts are excluded; this audit verifies retained identities and omission records rather than repackaging binaries.",
            "Historical exploratory extras are preserved but are not promoted into final validation or performance claims.",
        ],
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "output": str(args.output), "members": result["member_count"], "source_files": len(source)}))


if __name__ == "__main__":
    main()
