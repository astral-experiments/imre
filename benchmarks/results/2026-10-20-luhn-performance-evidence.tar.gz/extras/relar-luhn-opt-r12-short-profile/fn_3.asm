
/tmp/relar-luhn-opt-r12-short-profile/binaries/relar:     file format elf64-x86-64


Disassembly of section .text:

0000000000105f60 <fn_3>:
  105f60:	push   %rbp
  105f61:	push   %r15
  105f63:	push   %r14
  105f65:	push   %r13
  105f67:	push   %r12
  105f69:	push   %rbx
  105f6a:	sub    $0x38,%rsp
  105f6e:	addr32 call 1192c0 <relar_str_int_list>
  105f74:	mov    %rax,%r14
  105f77:	xor    %edi,%edi
  105f79:	call   1275c0 <_RNvYNCNKNvNtNtCs5N6zm3e4tnE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.3687425895475854622>
  105f7e:	mov    $0x1,%r15d
  105f84:	cmpb   $0x0,(%rax)
  105f87:	jne    106338 <fn_3+0x3d8>
  105f8d:	mov    %rax,%rbx
  105f90:	mov    %r14,%rdi
  105f93:	mov    $0xffffffffffffffff,%rsi
  105f9a:	xor    %edx,%edx
  105f9c:	mov    $0xfffffffffffffffd,%rcx
  105fa3:	addr32 call 1185a0 <relar_list_slice_sum>
  105fa9:	cmpb   $0x0,(%rbx)
  105fac:	jne    106343 <fn_3+0x3e3>
  105fb2:	test   %r14,%r14
  105fb5:	je     105fc1 <fn_3+0x61>
  105fb7:	incq   -0x10(%r14)
  105fbb:	je     106336 <fn_3+0x3d6>
  105fc1:	mov    %rbx,0x30(%rsp)
  105fc6:	mov    %rax,0x8(%rsp)
  105fcb:	movabs $0xc000000000000000,%rbp
  105fd5:	mov    0x10(%r14),%rax
  105fd9:	lea    (%rax,%rax,1),%r15
  105fdd:	movabs $0x666666666666666,%rcx
  105fe7:	cmp    %rcx,%rax
  105fea:	jae    10607b <fn_3+0x11b>
  105ff0:	mov    $0x1,%r12d
  105ff6:	cmp    $0x2,%rax
  105ffa:	jb     106057 <fn_3+0xf7>
  105ffc:	movabs $0x7fffffffffffffe6,%rax
  106006:	mov    0x8(%r14),%rcx
  10600a:	inc    %r15
  10600d:	add    $0x10,%rax
  106011:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  106020:	add    $0xfffffffffffffffc,%r15
  106024:	mov    %r15,%rdx
  106027:	and    $0xfffffffffffffffe,%rdx
  10602b:	mov    (%rcx,%rdx,4),%rdx
  10602f:	mov    %edx,%esi
  106031:	and    $0x1e,%esi
  106034:	xor    %edi,%edi
  106036:	cmp    $0xa,%rdx
  10603a:	setae  %dil
  10603e:	mov    $0x0,%edx
  106043:	cmovae %rax,%rdx
  106047:	add    %rsi,%rdx
  10604a:	or     %rdx,%rdi
  10604d:	lea    (%r12,%rdi,2),%r12
  106051:	cmp    $0x4,%r15
  106055:	ja     106020 <fn_3+0xc0>
  106057:	mov    %r14,%rdi
  10605a:	addr32 call 111cd0 <relar_list_release>
  106060:	test   %r12,%r12
  106063:	sete   %al
  106066:	or     %r12b,%al
  106069:	test   $0x1,%al
  10606b:	je     106186 <fn_3+0x226>
  106071:	mov    0x8(%rsp),%r15
  106076:	jmp    1061b9 <fn_3+0x259>
  10607b:	inc    %r15
  10607e:	mov    $0x1,%r13d
  106084:	lea    0x5f35(%rip),%rbx        # 10bfc0 <relar_int_binary>
  10608b:	jmp    1060a9 <fn_3+0x149>
  10608d:	lea    0x1(,%rax,2),%r12
  106095:	data16 cs nopw 0x0(%rax,%rax,1)
  1060a0:	mov    %r12,%r13
  1060a3:	cmp    $0x4,%r15
  1060a7:	jbe    106057 <fn_3+0xf7>
  1060a9:	add    $0xfffffffffffffffc,%r15
  1060ad:	mov    %r15,%rax
  1060b0:	shr    $1,%rax
  1060b3:	cmp    0x10(%r14),%rax
  1060b7:	jae    106140 <fn_3+0x1e0>
  1060bd:	mov    0x8(%r14),%rcx
  1060c1:	mov    (%rcx,%rax,8),%rax
  1060c5:	test   %rax,%rax
  1060c8:	je     10630c <fn_3+0x3ac>
  1060ce:	mov    %eax,%edx
  1060d0:	and    $0x1e,%edx
  1060d3:	lea    -0xa(%rdx),%rsi
  1060d7:	xor    %ecx,%ecx
  1060d9:	cmp    $0xa,%rax
  1060dd:	setae  %cl
  1060e0:	cmovb  %rdx,%rsi
  1060e4:	or     %rsi,%rcx
  1060e7:	test   $0x1,%r13b
  1060eb:	je     1060fe <fn_3+0x19e>
  1060ed:	mov    %r13,%rax
  1060f0:	sar    $1,%rax
  1060f3:	add    %rcx,%rax
  1060f6:	mov    %rax,%rdx
  1060f9:	add    %rbp,%rdx
  1060fc:	js     10608d <fn_3+0x12d>
  1060fe:	lea    0x1(,%rcx,2),%rsi
  106106:	mov    %r13,%rdi
  106109:	xor    %edx,%edx
  10610b:	call   *%rbx
  10610d:	mov    %rax,%r12
  106110:	test   %r13,%r13
  106113:	sete   %al
  106116:	or     %r13b,%al
  106119:	test   $0x1,%al
  10611b:	jne    1060a0 <fn_3+0x140>
  10611d:	lea    -0x10(%r13),%rax
  106121:	mov    %rax,0x10(%rsp)
  106126:	decq   -0x10(%r13)
  10612a:	jne    1060a0 <fn_3+0x140>
  106130:	lea    0x10(%rsp),%rdi
  106135:	addr32 call 121250 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  10613b:	jmp    1060a0 <fn_3+0x140>
  106140:	movabs $0x6f2074756f207865,%rax
  10614a:	mov    %rax,0x18(%rsp)
  10614f:	movabs $0xd765676e61722066,%rax
  106159:	mov    %rax,0x20(%rsp)
  10615e:	movabs $0x646e69207473696c,%rax
  106168:	mov    %rax,0x10(%rsp)
  10616d:	movl   $0x6,0x28(%rsp)
  106175:	lea    0x10(%rsp),%rdi
  10617a:	xor    %esi,%esi
  10617c:	call   1250d0 <_RINvMs0_NtNtCs5N6zm3e4tnE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  106181:	jmp    1060c5 <fn_3+0x165>
  106186:	incq   -0x10(%r12)
  10618b:	mov    %r12,%r13
  10618e:	mov    0x8(%rsp),%r15
  106193:	je     106336 <fn_3+0x3d6>
  106199:	test   $0x1,%r13b
  10619d:	jne    1061b9 <fn_3+0x259>
  10619f:	lea    -0x10(%r13),%rax
  1061a3:	mov    %rax,0x10(%rsp)
  1061a8:	decq   -0x10(%r13)
  1061ac:	jne    1061b9 <fn_3+0x259>
  1061ae:	lea    0x10(%rsp),%rdi
  1061b3:	addr32 call 121250 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  1061b9:	mov    0x30(%rsp),%rax
  1061be:	cmpb   $0x0,(%rax)
  1061c1:	jne    106349 <fn_3+0x3e9>
  1061c7:	mov    %r15d,%ebx
  1061ca:	and    $0x1,%ebx
  1061cd:	test   %ebx,%r12d
  1061d0:	je     1061e6 <fn_3+0x286>
  1061d2:	mov    %r15,%rcx
  1061d5:	sar    $1,%rcx
  1061d8:	mov    %r12,%rax
  1061db:	sar    $1,%rax
  1061de:	add    %rcx,%rax
  1061e1:	add    %rax,%rbp
  1061e4:	js     106215 <fn_3+0x2b5>
  1061e6:	mov    %r15,%rdi
  1061e9:	mov    %r12,%rsi
  1061ec:	xor    %edx,%edx
  1061ee:	addr32 call 10bfc0 <relar_int_binary>
  1061f4:	mov    %rax,%rbp
  1061f7:	test   $0x1,%bpl
  1061fb:	jne    106223 <fn_3+0x2c3>
  1061fd:	mov    $0x15,%esi
  106202:	mov    %rbp,%rdi
  106205:	mov    $0x4,%edx
  10620a:	addr32 call 10bfc0 <relar_int_binary>
  106210:	mov    %rax,%r13
  106213:	jmp    106266 <fn_3+0x306>
  106215:	lea    0x1(,%rax,2),%rbp
  10621d:	test   $0x1,%bpl
  106221:	je     1061fd <fn_3+0x29d>
  106223:	mov    %rbp,%rcx
  106226:	sar    $1,%rcx
  106229:	movabs $0x6666666666666667,%rdx
  106233:	mov    %rcx,%rax
  106236:	imul   %rdx
  106239:	mov    %rdx,%rax
  10623c:	shr    $0x3f,%rax
  106240:	sar    $0x2,%rdx
  106244:	add    %rax,%rdx
  106247:	add    %rdx,%rdx
  10624a:	lea    (%rdx,%rdx,4),%rax
  10624e:	sub    %rax,%rcx
  106251:	mov    %rcx,%rax
  106254:	sar    $0x3f,%rax
  106258:	and    $0xa,%eax
  10625b:	add    %rcx,%rax
  10625e:	lea    0x1(,%rax,2),%r13
  106266:	test   %rbp,%rbp
  106269:	sete   %al
  10626c:	or     %bpl,%al
  10626f:	mov    0x30(%rsp),%rcx
  106274:	cmpb   $0x0,(%rcx)
  106277:	jne    10638a <fn_3+0x42a>
  10627d:	test   $0x1,%al
  10627f:	jne    10629b <fn_3+0x33b>
  106281:	lea    -0x10(%rbp),%rax
  106285:	mov    %rax,0x10(%rsp)
  10628a:	decq   -0x10(%rbp)
  10628e:	jne    10629b <fn_3+0x33b>
  106290:	lea    0x10(%rsp),%rdi
  106295:	addr32 call 121250 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  10629b:	mov    %r14,%rdi
  10629e:	addr32 call 111cd0 <relar_list_release>
  1062a4:	test   %r15,%r15
  1062a7:	sete   %al
  1062aa:	or     %bl,%al
  1062ac:	jne    1062cb <fn_3+0x36b>
  1062ae:	mov    %r15,%rax
  1062b1:	add    $0xfffffffffffffff0,%rax
  1062b5:	mov    %rax,0x10(%rsp)
  1062ba:	decq   -0x10(%r15)
  1062be:	jne    1062cb <fn_3+0x36b>
  1062c0:	lea    0x10(%rsp),%rdi
  1062c5:	addr32 call 121250 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  1062cb:	test   %r12,%r12
  1062ce:	sete   %al
  1062d1:	or     %r12b,%al
  1062d4:	test   $0x1,%al
  1062d6:	jne    1062fa <fn_3+0x39a>
  1062d8:	test   $0x1,%r12b
  1062dc:	jne    1062fa <fn_3+0x39a>
  1062de:	lea    -0x10(%r12),%rax
  1062e3:	mov    %rax,0x10(%rsp)
  1062e8:	decq   -0x10(%r12)
  1062ed:	jne    1062fa <fn_3+0x39a>
  1062ef:	lea    0x10(%rsp),%rdi
  1062f4:	addr32 call 121250 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12relar_runtime>
  1062fa:	mov    %r13,%rax
  1062fd:	add    $0x38,%rsp
  106301:	pop    %rbx
  106302:	pop    %r12
  106304:	pop    %r13
  106306:	pop    %r14
  106308:	pop    %r15
  10630a:	pop    %rbp
  10630b:	ret
  10630c:	mov    %r14,%rdi
  10630f:	addr32 call 111cd0 <relar_list_release>
  106315:	test   %r13,%r13
  106318:	sete   %al
  10631b:	or     %r13b,%al
  10631e:	mov    $0x1,%r12d
  106324:	test   $0x1,%al
  106326:	mov    0x8(%rsp),%r15
  10632b:	je     106199 <fn_3+0x239>
  106331:	jmp    1061b9 <fn_3+0x259>
  106336:	ud2
  106338:	xor    %r14d,%r14d
  10633b:	mov    $0x1,%r12d
  106341:	jmp    10634f <fn_3+0x3ef>
  106343:	mov    $0x1,%r15d
  106349:	mov    $0x1,%r12d
  10634f:	mov    %r14,%rdi
  106352:	addr32 call 111cd0 <relar_list_release>
  106358:	test   %r15,%r15
  10635b:	sete   %al
  10635e:	or     %r15b,%al
  106361:	test   $0x1,%al
  106363:	jne    10636e <fn_3+0x40e>
  106365:	mov    %r15,%rdi
  106368:	addr32 call 1112a0 <relar_int_release>
  10636e:	test   %r12,%r12
  106371:	sete   %al
  106374:	or     %r12b,%al
  106377:	mov    $0x1,%r13d
  10637d:	test   $0x1,%al
  10637f:	je     1062d8 <fn_3+0x378>
  106385:	jmp    1062fa <fn_3+0x39a>
  10638a:	test   $0x1,%al
  10638c:	jne    10634f <fn_3+0x3ef>
  10638e:	mov    %rbp,%rdi
  106391:	addr32 call 1112a0 <relar_int_release>
  106397:	jmp    10634f <fn_3+0x3ef>
  106399:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10639f:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1063a5:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1063ab:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1063b1:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  1063b7:	addr32 call eae13 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
