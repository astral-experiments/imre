#!/bin/sh
set -eu

profile_python=/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14

"$profile_python" -I -B /tmp/imre-luhn-performance-profile.py \
  --record /tmp/imre-luhn-performance-v1-thinlto.json \
  --imre-build-record /tmp/imre-luhn-performance-validation-v3/build.json \
  --timing-status /tmp/imre-luhn-performance-v1-timing-status.json \
  --output /tmp/imre-luhn-performance-short-profile \
  --label checksum-16 --digits 16 --repetitions 65536

"$profile_python" -I -B /tmp/imre-luhn-performance-profile.py \
  --record /tmp/imre-luhn-performance-v1-thinlto.json \
  --imre-build-record /tmp/imre-luhn-performance-validation-v3/build.json \
  --timing-status /tmp/imre-luhn-performance-v1-timing-status.json \
  --output /tmp/imre-luhn-performance-large-profile \
  --label checksum-4096 --digits 4096 --repetitions 64

"$profile_python" -I -B /tmp/imre-luhn-performance-profile-audit.py \
  --profile-dir /tmp/imre-luhn-performance-short-profile \
  --timing-prefix /tmp/imre-luhn-performance-v1 \
  --validation-index /tmp/imre-luhn-performance-validation-v3/index.json \
  --label checksum-16 --digits 16 --repetitions 65536 \
  --output /tmp/imre-luhn-performance-short-profile-audit.json

"$profile_python" -I -B /tmp/imre-luhn-performance-profile-audit.py \
  --profile-dir /tmp/imre-luhn-performance-large-profile \
  --timing-prefix /tmp/imre-luhn-performance-v1 \
  --validation-index /tmp/imre-luhn-performance-validation-v3/index.json \
  --label checksum-4096 --digits 4096 --repetitions 64 \
  --output /tmp/imre-luhn-performance-large-profile-audit.json
