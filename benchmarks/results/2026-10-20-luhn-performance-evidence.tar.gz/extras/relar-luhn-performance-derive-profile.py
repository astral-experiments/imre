"""Read-only attribution of frozen, independently audited Luhn profiles."""

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import runpy


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def record(path):
    return {"path": str(path), "sha256": sha(path)}


ROOT = Path("/tmp")
REVISION = "8b54eae6572a93926265d78562656dd395ad28b0"
AUDITOR = ROOT / "relar-luhn-performance-profile-audit.py"
audit_functions = runpy.run_path(str(AUDITOR), run_name="profile_audit_library")
ASSEMBLY = ROOT / "relar-luhn-performance-profile-disassembly"
assembly_commands = read(ASSEMBLY / "commands.json")
assert sha(assembly_commands["binary"]) == assembly_commands["binary_sha256"]
for command in assembly_commands["commands"]:
    assert command["command"][-1] == assembly_commands["binary"]
    assert sha(command["command"][0]) == assembly_commands["tool_sha256"]
    assert sha(ASSEMBLY / command["output"]) == command["sha256"]


def load_profile(directory, audit_path, current):
    summary = read(directory / "summary.json")
    manifest = read(directory / "manifest.json")
    audit = read(audit_path)
    assert summary["status"] == audit["status"] == "passed"
    assert summary["complete"] and summary["input_guards_passed"]
    assert audit["profile_summary_sha256"] == sha(directory / "summary.json")
    assert audit["profile_manifest_sha256"] == sha(directory / "manifest.json")
    assert audit["benchmark_record_sha256"] == summary["benchmark_record_sha256"]
    assert sha(directory / "benchmark-record.json") == summary["benchmark_record_sha256"]
    files = {p.relative_to(directory).as_posix(): p
             for p in directory.rglob("*") if p.is_file() and p.name != "manifest.json"}
    assert not any(p.is_symlink() for p in directory.rglob("*"))
    assert files.keys() == manifest.keys()
    assert len(files) == audit["profile_manifest_members"]
    assert all(sha(path) == manifest[name] for name, path in files.items())
    assert all(sha(directory / name) == digest
               for name, digest in summary["snapshot_sha256"].items())
    if current:
        assert all(summary[key] == REVISION for key in
                   ("revision", "build_revision", "validation_revision", "timing_revision"))
        assert audit["auditor_sha256"] == sha(AUDITOR)
        assert all(sha(item["path"]) == item["sha256"]
                   for item in summary["guarded_inputs"].values())
        assert audit["validation_index_sha256"] == sha(directory / "validation-index.json")
    metrics, raw_audits = {}, {}
    for item in summary["profiles"]:
        engine, tool = item["engine"], item["tool"]
        run_dir = directory / f"{engine}-{tool}"
        assert item["status"] == "validated" and item["returncode"] == 0
        target = item["command"][-5:]
        assert target[1] == "checksum" and int(target[-1]) == summary["repetitions"]
        assert sha(target[0]) == item["binary_sha256"] == audit["binary_sha256"][engine]
        assert sha(run_dir / "input.bin") == item["input_sha256"]
        assert (run_dir / "output.bin").read_bytes().hex() == summary["expected_output_hex"]
        assert (run_dir / "stdout.txt").read_text() == summary["expected_stdout"]
        assert (run_dir / "stderr.txt").read_bytes() == b""
        raw = run_dir / ("profile.callgrind" if tool == "callgrind" else "profile.json")
        result = audit_functions[tool](raw, target, item["metrics"], run_dir)
        metrics[engine, tool] = item["metrics"]
        raw_audits[f"{engine}-{tool}"] = {"raw": record(raw), "reconciliation": result}
    return summary, metrics, {
        "directory": str(directory), "summary": record(directory / "summary.json"),
        "manifest": record(directory / "manifest.json"), "audit": record(audit_path),
        "manifest_members_verified": len(manifest),
        "current_external_guards_rehashed": len(summary["guarded_inputs"]) if current else 0,
        "historical_guard_policy": None if current else (
            "Original source guards remain in immutable snapshots and the passed historical audit. "
            "Current source is intentionally changed; historical executables, manifests, snapshots, "
            "raw profiles, complete outputs, and shared immutable source/tool identities are reverified."
        ),
        "revision": summary["revision"], "build_revision": summary["build_revision"],
        "validation_revision": summary["validation_revision"],
        "timing_revision": summary["timing_revision"],
        "benchmark_record_sha256": summary["benchmark_record_sha256"],
        "binary_sha256": audit["binary_sha256"],
        "llvm_sha256": sha(directory / "native.ll"),
        "input_sha256": summary["profiles"][0]["input_sha256"],
        "digits": summary["digits"], "repetitions": summary["repetitions"],
        "expected_stdout": summary["expected_stdout"],
        "expected_output_hex": summary["expected_output_hex"],
        "raw_profiles": raw_audits,
    }


def instruction_edges(directory, metrics):
    """Separate self rows from immediately preceding calls= edge rows."""
    lines = (directory / "relar-callgrind/profile.callgrind").read_text().splitlines()
    names = {}
    for line in lines:
        match = re.fullmatch(r"c?fn=\((\d+)\) (.+)", line)
        if match:
            names[match[1]] = match[2]
    caller = callee = None
    address = 0
    pending_call = False
    self_at = defaultdict(Counter)
    edges, calls = Counter(), Counter()
    for line in lines:
        match = re.fullmatch(r"(c?fn)=\((\d+)\)(?: .+)?", line)
        if match:
            if match[1] == "fn":
                caller = names[match[2]]
                pending_call = False
                address = 0
            else:
                callee = names[match[2]]
            continue
        if line.startswith("calls="):
            calls[caller, callee] += int(line.split()[0].split("=")[1])
            pending_call = True
            continue
        match = re.fullmatch(
            r"(0x[0-9a-f]+|[+-]\d+|\*|\d+)\s+(?:[+-]?\d+|\*)\s*(\d*)", line)
        if not match:
            continue
        position, count = match.groups()
        if position.startswith("0x"):
            address = int(position, 16)
        elif position.startswith(("+", "-")):
            address += int(position)
        elif position != "*":
            address = int(position)
        value = int(count or "0")
        if pending_call:
            edges[caller, callee] += value
            pending_call = False
        else:
            self_at[caller][address] += value
    by_name = {item["name"]: item for item in metrics["relar", "callgrind"]["functions"]}
    assert sum(sum(counts.values()) for counts in self_at.values()) == (
        metrics["relar", "callgrind"]["instructions"])
    assert {name: sum(counts.values()) for name, counts in self_at.items()} == (
        {name: item["self_instructions"] for name, item in by_name.items()})
    for name in ("fn_3", "relar_str_int_list", "relar_list_slice_sum", "relar_list_release"):
        outgoing = sum(value for (source, _), value in edges.items() if source == name)
        assert outgoing + sum(self_at[name].values()) == (
            by_name[name]["incoming_inclusive_instructions"])
        addresses = {int(value, 16) for value in re.findall(
            r"^\s+([0-9a-f]+):", (ASSEMBLY / f"{name}.asm").read_text(), re.M)}
        assert self_at[name].keys() <= addresses
    return self_at, edges, calls, by_name


REGIONS = {
    "fn_3": {
        "scalar_loop_cursor_and_load": (0x106010, 0x10601F),
        "scalar_loop_digit_arithmetic": (0x10601F, 0x10603A),
        "scalar_loop_accumulator_and_latch": (0x10603A, 0x106044),
        "checked_arbitrary_integer_fallback": (0x106068, 0x106176),
    },
    "relar_str_int_list": {
        "ascii_validation_vector_loop": (0x119400, 0x119436),
        "digit_validation_and_tagged_storage_vector_loop": (0x119640, 0x1196F9),
        "scalar_digit_pair_tail": (0x1195A0, 0x1195F2),
    },
    "relar_list_slice_sum": {
        "reverse_stride_two_vector_loop": (0x118953, 0x118A09),
        "reverse_stride_two_scalar_tail": (0x118A40, 0x118A70),
        "reverse_stride_two_first_element": (0x118A75, 0x118A9E),
    },
    "relar_list_release": {
        "immediate_value_vector_scan": (0x111D80, 0x111D9C),
        "heap_value_release_loop": (0x111E65, 0x111EAB),
    },
}


def attribution(directory, summary, metrics):
    self_at, edges, calls, by_name = instruction_edges(directory, metrics)
    repetitions, digits = summary["repetitions"], summary["digits"]
    process_total = metrics["relar", "callgrind"]["instructions"]
    subtree = by_name["fn_3"]["incoming_inclusive_instructions"]
    partition = [{"component": "checksum self", "instructions": by_name["fn_3"]["self_instructions"]}]
    for (caller, callee), value in edges.items():
        if caller == "fn_3":
            partition.append({"component": callee, "instructions": value,
                              "calls": calls[caller, callee]})
    assert sum(row["instructions"] for row in partition) == subtree
    for row in partition:
        row["instructions_per_checksum"] = row["instructions"] / repetitions
        row["fraction_of_process"] = row["instructions"] / process_total
        row["fraction_of_checksum_subtree"] = row["instructions"] / subtree
    regions = {}
    for name, ranges in REGIONS.items():
        assembly = {int(address, 16): instruction for address, instruction in re.findall(
            r"^\s+([0-9a-f]+):\s+(.+)$", (ASSEMBLY / f"{name}.asm").read_text(), re.M)}
        covered = set()
        entries = {}
        for label, (start, end) in ranges.items():
            positions = {address for address in assembly if start <= address < end}
            assert not positions & covered
            covered |= positions
            values = [{"address": hex(address), "assembly": assembly[address],
                       "executions": self_at[name][address]} for address in sorted(positions)]
            entries[label] = {
                "half_open_address_range": [hex(start), hex(end)],
                "instructions": sum(row["executions"] for row in values),
                "instructions_per_checksum": sum(row["executions"] for row in values) / repetitions,
                "static_instructions": len(values), "address_counts": values,
            }
        remaining = sum(value for address, value in self_at[name].items() if address not in covered)
        entries["other_self_instructions"] = {
            "instructions": remaining, "instructions_per_checksum": remaining / repetitions}
        assert sum(row["instructions"] for row in entries.values()) == by_name[name]["self_instructions"]
        regions[name] = entries
    scalar = regions["fn_3"]
    assert scalar["checked_arbitrary_integer_fallback"]["instructions"] == 0
    for key, expected in (
        ("scalar_loop_cursor_and_load", 4), ("scalar_loop_digit_arithmetic", 8),
        ("scalar_loop_accumulator_and_latch", 3),
    ):
        assert scalar[key]["instructions"] == expected * (digits // 2) * repetitions
        assert all(item["executions"] == (digits // 2) * repetitions
                   for item in scalar[key]["address_counts"])
    assert regions["relar_list_release"]["heap_value_release_loop"]["instructions"] == 0
    for name, label, iterations in (
        ("relar_str_int_list", "digit_validation_and_tagged_storage_vector_loop", digits // 4),
        ("relar_list_slice_sum", "reverse_stride_two_vector_loop", (digits // 2 - 1) // 4),
        ("relar_list_release", "immediate_value_vector_scan", digits // 4),
    ):
        assert all(row["executions"] == repetitions * iterations
                   for row in regions[name][label]["address_counts"])
    normalizer = next(name for name in by_name if "SliceIndices>::new" in name)
    return {
        "process_instruction_total": process_total,
        "checksum_subtree_instructions": subtree,
        "outside_checksum_subtree_instructions": process_total - subtree,
        "checksum_subtree_partition": partition,
        "partition_method": (
            "fn_3 self plus its four direct outgoing call-edge inclusive totals are disjoint "
            "dynamic call subtrees and exactly equal fn_3 incoming inclusive cost. Nested helper "
            "self costs and regions below are alternative breakdowns, never added again."
        ),
        "top_process_self_functions": metrics["relar", "callgrind"]["functions"][:12],
        "self_instruction_regions": regions,
        "slice_normalization": {
            "name": normalizer, "self_instructions": by_name[normalizer]["self_instructions"],
            "instructions_per_checksum": by_name[normalizer]["self_instructions"] / repetitions,
            "included_within": "relar_list_slice_sum inclusive subtree",
        },
        "digit_conversion_outgoing_edges": [
            {"callee": callee, "calls": calls[caller, callee], "instructions": value}
            for (caller, callee), value in edges.items() if caller == "relar_str_int_list"
        ],
        "actual_path": (
            "The checksum reduction executes the scalar 15-instruction loop; no forced loop "
            "vectorization metadata occurs in retained native.ll. The digit conversion, "
            "reverse stride-two subtotal, and immediate-value destruction scan execute SIMD."
        ),
    }


def allocations(directory, engine):
    heap = read(directory / f"{engine}-dhat/profile.json")
    categories = defaultdict(lambda: {"bytes": 0, "blocks": 0, "point_indices": []})
    points = []
    for index, point in enumerate(heap["pps"]):
        frames = [heap["ftbl"][frame] for frame in point["fs"]]
        joined = "\n".join(frames)
        if engine == "relar":
            if "relar_str_int_list" in joined:
                if "try_reserve_exact" in joined:
                    category = "digit_list_buffer"
                elif "thread_local/native" in joined:
                    category = "cache_tls_registrations"
                else:
                    category = "list_header"
            elif "FileState>::read_bytes" in joined or "relar_bytes_decode" in joined:
                category = "input_bytes_and_decoded_text"
            elif "bufwriter.rs" in joined or "linewriter::LineWriter" in joined:
                category = "io_buffers"
            else:
                category = "other_startup_and_protocol"
        elif "std::fs::read::inner" in joined:
            category = "input_bytes"
        elif any("transform (main.rs:153)" in frame for frame in frames):
            category = "final_checksum_string"
        else:
            category = "other_startup_and_protocol"
        categories[category]["bytes"] += point["tb"]
        categories[category]["blocks"] += point["tbk"]
        categories[category]["point_indices"].append(index)
        points.append({"index": index, "category": category,
                       "bytes": point["tb"], "blocks": point["tbk"], "frames": frames})
    assert sum(x["bytes"] for x in categories.values()) == sum(x["tb"] for x in heap["pps"])
    assert sum(x["blocks"] for x in categories.values()) == sum(x["tbk"] for x in heap["pps"])
    assert sorted(i for group in categories.values() for i in group["point_indices"]) == list(range(len(points)))
    if engine == "relar":
        assert categories["digit_list_buffer"]["blocks"] == 1
        assert categories["list_header"]["bytes"] == 40 and categories["list_header"]["blocks"] == 1
        assert categories["cache_tls_registrations"]["bytes"] == 64
        assert categories["cache_tls_registrations"]["blocks"] == 2
        assert categories["io_buffers"]["bytes"] == 17408
        assert categories["other_startup_and_protocol"]["bytes"] == 1020
    return {"categories": dict(categories), "points": points,
            "partition_check": "Every DHAT allocation point appears exactly once."}


result = {
    "schema": 1, "status": "passed", "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "source_revision": REVISION, "derivation_script": record(__file__),
    "auditor": record(AUDITOR), "measurement_scope": [
        "Read-only analysis; no measured process, test, compiler, or profiler is executed.",
        "Guest instructions are not CPU cycles or CPU-time percentages. Separate audited elapsed medians are explicitly labeled.",
        "Profiles include startup, input decoding, repeated checksum calls, checksum accumulation, I/O, and exit.",
        "DHAT bytes are requested allocations, not RSS or allocator usable size. Global peaks use simultaneous gb/gbk.",
        "Only checksum is profiled here; these attributions do not establish the costs of verify, generate, or append.",
    ],
    "profiles": {}, "disassembly": {
        "commands": record(ASSEMBLY / "commands.json"),
        "files": {name: record(ASSEMBLY / f"{name}.asm") for name in REGIONS},
    },
}
loaded = {}
for label in ("short", "large"):
    directory = ROOT / f"relar-luhn-performance-{label}-profile"
    summary, metrics, provenance = load_profile(
        directory, ROOT / f"relar-luhn-performance-{label}-profile-audit.json", True)
    assert "llvm.loop.vectorize" not in (directory / "native.ll").read_text()
    loaded[label] = summary, metrics, provenance
    assert provenance["binary_sha256"]["relar"] == assembly_commands["binary_sha256"]
    result["profiles"][label] = {
        "provenance": provenance, "instructions": {
            engine: metrics[engine, "callgrind"]["instructions"] for engine in ("relar", "rust")},
        "relar_over_rust_instruction_ratio": (
            metrics["relar", "callgrind"]["instructions"] / metrics["rust", "callgrind"]["instructions"]),
        "allocation_totals": {engine: {key: value for key, value in metrics[engine, "dhat"].items()
                                      if key != "top_allocation_stacks"}
                              for engine in ("relar", "rust")},
        "instruction_attribution": attribution(directory, summary, metrics),
        "allocations": {engine: allocations(directory, engine) for engine in ("relar", "rust")},
    }

old_dir = ROOT / "relar-luhn-profile-final"
old_summary, old_metrics, old_provenance = load_profile(
    old_dir, ROOT / "relar-luhn-profile-audit.json", False)
new_summary, new_metrics, new_provenance = loaded["large"]
for key in ("input_sha256", "digits", "repetitions", "expected_stdout", "expected_output_hex"):
    assert old_provenance[key] == new_provenance[key]
assert old_provenance["digits"] == 4096 and old_provenance["repetitions"] == 64
assert old_provenance["binary_sha256"]["rust"] == new_provenance["binary_sha256"]["rust"]
assert old_provenance["binary_sha256"]["relar"] == new_summary["baseline_provenance"]["binary_sha256"]
assert old_provenance["benchmark_record_sha256"] == new_summary["baseline_provenance"]["record_sha256"]
assert old_provenance["revision"] == new_summary["baseline_provenance"]["revision"]
shared_keys = [key for key in old_summary["guarded_inputs"]
               if ((key.startswith(("example:", "rust_source:", "tool_"))
                    and not key.endswith(".md"))
                   or key in ("validator", "shared_harness", "shared_validator", "clang", "python", "lto_linker"))]
for key in shared_keys:
    assert old_summary["guarded_inputs"][key]["sha256"] == new_summary["guarded_inputs"][key]["sha256"], key
    assert sha(new_summary["guarded_inputs"][key]["path"]) == new_summary["guarded_inputs"][key]["sha256"]
old_analysis_path = ROOT / "relar-luhn-profile-analysis.json"
old_analysis = read(old_analysis_path)
assert old_analysis["profile_summary_sha256"] == old_provenance["summary"]["sha256"]
assert old_analysis["profile_manifest_sha256"] == old_provenance["manifest"]["sha256"]
assert old_analysis["binary_sha256"] == old_provenance["binary_sha256"]["relar"]
assert old_analysis["llvm_sha256"] == old_provenance["llvm_sha256"]
assert all(old_analysis["raw_profile_sha256"][name] == item["raw"]["sha256"]
           for name, item in old_provenance["raw_profiles"].items())
old_heap = read(old_dir / "relar-dhat/profile.json")
old_indices = []
for category in old_analysis["allocation_categories"].values():
    ids = category["point_indices"]
    old_indices += ids
    assert sum(old_heap["pps"][i]["tb"] for i in ids) == category["bytes"]
    assert sum(old_heap["pps"][i]["tbk"] for i in ids) == category["blocks"]
assert sorted(old_indices) == list(range(len(old_heap["pps"])))
old_instructions = old_metrics["relar", "callgrind"]["instructions"]
new_instructions = new_metrics["relar", "callgrind"]["instructions"]
old_bytes = old_metrics["relar", "dhat"]["allocated_bytes"]
new_bytes = new_metrics["relar", "dhat"]["allocated_bytes"]
old_blocks = old_metrics["relar", "dhat"]["allocated_blocks"]
new_blocks = new_metrics["relar", "dhat"]["allocated_blocks"]
result["original_large_baseline_comparison"] = {
    "provenance": old_provenance, "original_attribution": record(old_analysis_path),
    "same_unchanged_example_rust_and_profile_tool_keys": shared_keys,
    "same_rust_binary": True, "same_input_repetitions_full_output_and_accumulated_checksum": True,
    "original_allocation_categories_reconciled": old_analysis["allocation_categories"],
    "relar_instructions": {"baseline": old_instructions, "current": new_instructions,
                          "baseline_over_current": old_instructions / new_instructions,
                          "reduction_fraction": 1 - new_instructions / old_instructions},
    "relar_requested_bytes": {"baseline": old_bytes, "current": new_bytes,
                             "reduction_fraction": 1 - new_bytes / old_bytes},
    "relar_requested_blocks": {"baseline": old_blocks, "current": new_blocks,
                              "reduction_fraction": 1 - new_blocks / old_blocks},
    "rust_control": {
        "baseline_instructions": old_metrics["rust", "callgrind"]["instructions"],
        "current_instructions": new_metrics["rust", "callgrind"]["instructions"],
        "baseline_requested_bytes": old_metrics["rust", "dhat"]["allocated_bytes"],
        "current_requested_bytes": new_metrics["rust", "dhat"]["allocated_bytes"],
        "note": "Same executable/input/repetitions; small process-level differences include changed argument paths.",
    },
}
timing_path = ROOT / "relar-luhn-performance-v1-thinlto.json"
timing_audit_path = ROOT / "relar-luhn-performance-benchmark-audit.json"
timing = read(timing_path)
timing_audit = read(timing_audit_path)
assert timing_audit["status"] == "passed"
assert sha(timing_path) == new_summary["benchmark_record_sha256"]
assert all(timing_audit[key] == REVISION for key in
           ("timing_revision", "build_revision", "validation_revision"))
assert timing_audit["identities"]["thinlto"]["record_sha256"] == sha(timing_path)
assert timing_audit["identities"]["thinlto"]["binary_sha256"] == (
    new_provenance["binary_sha256"]["relar"])
assert timing_audit["validation_index_sha256"] == sha(
    ROOT / "relar-luhn-performance-large-profile/validation-index.json")
result["separate_audited_wall_time"] = {
    "record": record(timing_path), "audit": record(timing_audit_path),
    "unit": "seconds", "workloads": [
        {key: value for key, value in item.items() if key in (
            "label", "digits", "repetitions", "summary", "relar_over_rust", "baseline_over_relar",
            "cpython_over_relar")}
        for item in timing["workloads"] if item["label"] in ("checksum-16", "checksum-4096")
    ],
    "note": "Elapsed-time batches and repetitions differ from instrumented profiles; no instruction-to-time conversion.",
}
result["findings"] = [
    "The final checksum loop is scalar: four cursor/load, eight digit arithmetic, and three accumulator/latch instructions per selected digit. No checked arbitrary-integer fallback executes for the profiled ASCII digits.",
    "Digit conversion and tagged storage, reverse-stride subtotal, and immediate-value release scans execute vector instructions. SIMD in these runtime helpers does not imply a vector checksum loop.",
    "The requested allocations inside repeated checksum calls consist of one digit buffer, one list header, and two TLS registrations per process. There are no recurring one-character strings, divmod pairs, slice lists, or comprehension-result buffers.",
    "Remaining work includes materializing tagged digit storage, rescanning it for a subtotal and small-value destruction, scalar digit arithmetic, and fixed helper/cache/normalization calls. Streaming and proof propagation are possible generic future directions, not measured outcomes.",
    "The unchanged Python library and independent Rust reference implement the same outputs with different storage and iteration strategies. Rust streams digits; the compiler still materializes a reusable integer list.",
]
result["runtime_reuse_contract"] = {
    "source": new_summary["guarded_inputs"]["relar_source:crates/relar-runtime/src/lib.rs"],
    "maximum_empty_vector_buffers_per_thread": 2,
    "maximum_vector_capacity_in_ints": 32768,
    "maximum_retained_vector_storage_bytes_per_thread": 524288,
    "maximum_empty_list_headers_per_thread": 2,
    "list_header_bytes_on_profiled_target": 40,
    "maximum_retained_header_storage_bytes_per_thread": 80,
    "ownership": (
        "Only empty buffers and uniquely owned empty headers are retained; headers have no buffer. "
        "Strong aliases and Weak observers prevent header reuse; no element owners survive caching. "
        "TLS teardown and reentrant cache borrowing fall back to normal allocation/destruction."
    ),
    "limit": "The bound excludes TLS bookkeeping, allocator metadata, and ordinary live program objects.",
}
result["excluded_exploratory_evidence"] = [
    {
        "record": record(ROOT / "relar-luhn-opt-r7-provenance-issue.json"),
        "reason": (
            "R7's runtime was byte-identical to an uncommitted inlining experiment despite a "
            "different declared source. None of its timings or profiles enter this final attribution."
        ),
    },
    {
        "record": record(ROOT / "relar-luhn-slice-inline-v3-analysis.json"),
        "reason": (
            "The normalization-inlining experiment was not integrated. Its instruction reduction "
            "is not evidence of an elapsed-time improvement and is excluded from final comparisons."
        ),
    },
]
result["derivation_command"] = [
    "/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14",
    "-I", "-B", str(Path(__file__).resolve()),
]
result["derivation_python"] = record(result["derivation_command"][0])
result["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
output = ROOT / "relar-luhn-performance-profile-analysis.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(output)
for label, item in result["profiles"].items():
    print(label, item["instructions"], item["allocation_totals"]["relar"])
    print("subtree", item["instruction_attribution"]["checksum_subtree_partition"])
    for name, regions in item["instruction_attribution"]["self_instruction_regions"].items():
        print(name, {key: value["instructions"] for key, value in regions.items()})
print("comparison", result["original_large_baseline_comparison"]["relar_instructions"])
