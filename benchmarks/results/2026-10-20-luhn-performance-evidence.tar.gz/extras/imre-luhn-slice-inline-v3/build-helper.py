"""Build and freeze a runtime-only slice-inlining experiment."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path("/home/dev-user/code/oss/imre-luhn-iterables")
BASE = Path("/tmp/imre-luhn-opt-r6")
OUT = Path("/tmp/imre-luhn-slice-inline-v3")
TARGET = Path("/home/dev-user/.cache/imre/luhn-iterables-target")
PYTHON = "/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14"
LINKER = "/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def sources():
    names = git("ls-files", "crates/imre-runtime", "Cargo.toml", "Cargo.lock").decode().splitlines()
    return {name: sha(ROOT / name) for name in names}


assert not OUT.exists()
revision = git("rev-parse", "HEAD").decode().strip()
assert revision == "1d3e1be42bd6d301481f619942679beb7ff167fc"
assert git("diff", "--name-only").decode().splitlines() == [
    "crates/imre-runtime/src/objects/sequences.rs"
]
assert not git("diff", "--cached")
patch = git("diff", "--binary")
source_hashes = sources()
base = json.loads((BASE / "exploratory-build.json").read_text())
assert all(sha(BASE / name) == value for name, value in base["sha256"].items())
OUT.mkdir()
(OUT / "source.patch").write_bytes(patch)
shutil.copy2(__file__, OUT / "build-helper.py")
shutil.copy2(BASE / "imre", OUT / "imre")
environment = {
    **os.environ,
    "CARGO_HOME": "/home/dev-user/.cache/imre/cargo-home",
    "CARGO_TARGET_DIR": str(TARGET),
    "CARGO_BUILD_BUILD_DIR": "/home/dev-user/.cache/ohm/shared-build",
    "CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST": "all",
    "CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST": "all",
    "RUSTFLAGS": "",
}
commands = []


def run(command, **overrides):
    item = {"command": command, "environment_overrides": overrides}
    commands.append(item)
    with (OUT / f"command-{len(commands)}.log").open("wb") as output:
        result = subprocess.run(command, cwd=ROOT, env={**environment, **overrides},
                                stdout=output, stderr=subprocess.STDOUT, check=False)
    item["exit_code"] = result.returncode
    print("completed", command, "exit", result.returncode, flush=True)
    result.check_returncode()


cargo = ["cargo", "+ohm", "-Zohm-defaults=no"]
run([*cargo, "fmt", "--all", "--", "--check"])
run([*cargo, "test", "-p", "imre-runtime", "--lib", "--locked"])
run([*cargo, "clippy", "-p", "imre-runtime", "--all-targets", "--locked", "--", "-D", "warnings"])
run([*cargo, "build", "-p", "imre-runtime", "--profile", "imre-luhn-validation-lto",
     "--config", 'profile.imre-luhn-validation-lto.inherits="release"', "--locked"],
    RUSTFLAGS="-Clinker-plugin-lto")
shutil.copy2(TARGET / "imre-luhn-validation-lto/libimre_runtime.a", OUT / "thinlto-runtime.a")
run([str(OUT / "imre"), "build", "examples/luhn_checksum/driver.py", "--module-root",
     "examples/luhn_checksum", "--runtime", str(OUT / "thinlto-runtime.a"), "--clang",
     "/usr/bin/clang-18", "--opt-level", "3", "--target", "x86_64-unknown-linux-gnu",
     "--lto-linker", LINKER, "--emit-llvm", str(OUT / "luhn.ll"), "-o", str(OUT / "luhn")])
run([PYTHON, "-I", "-B", "benchmarks/luhn_validate.py", "--binary", str(OUT / "luhn"),
     "--rust", "/tmp/imre-luhn-reference-thinlto/luhn-reference",
     "--output", str(OUT / "validation.json")])
assert git("rev-parse", "HEAD").decode().strip() == revision
assert git("diff", "--binary") == patch and sources() == source_hashes
record = {
    "revision": revision,
    "candidate_patch_sha256": sha(OUT / "source.patch"),
    "compiler_build_record_sha256": sha(BASE / "exploratory-build.json"),
    "source_sha256": source_hashes,
    "input_guards_passed": True,
    "commands": commands,
    "sha256": {path.name: sha(path) for path in OUT.iterdir() if path.is_file()},
}
(OUT / "exploratory-build.json").write_text(json.dumps(record, indent=2) + "\n")
print(OUT / "exploratory-build.json", flush=True)
