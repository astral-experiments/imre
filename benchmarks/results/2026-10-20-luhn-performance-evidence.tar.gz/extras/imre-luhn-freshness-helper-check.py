"""Exercise freshness parsing with synthetic Cargo output; never invokes Cargo."""

import ast
import hashlib
import json
from pathlib import Path
import shlex
import tempfile
from types import SimpleNamespace


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


runner = Path("/tmp/imre-luhn-validate.py")
audit = Path("/tmp/imre-luhn-performance-validation-audit.py")
syntax = ast.parse(runner.read_text())
validation = next(node for node in syntax.body if isinstance(node, ast.ClassDef) and node.name == "Validation")
method = next(node for node in validation.body if isinstance(node, ast.FunctionDef) and node.name == "fresh_cargo")
namespace = {"Path": Path, "digest": digest, "write_json": write_json, "json": json}
exec(compile(ast.Module(body=[method], type_ignores=[]), str(runner), "exec"), namespace)


class FakeValidation:
    fresh_cargo = namespace["fresh_cargo"]

    def __init__(self, directory, fault=None):
        self.root = directory / "repo"
        self.output = directory / "output"
        self.args = SimpleNamespace(revision="1" * 40)
        self.cargo = ["cargo", "+ohm", "-Zohm-defaults=no"]
        self.frozen = {}
        self.index = {"jobs": [], "artifacts": {}}
        self.before = {"files": {}}
        self.fault = fault
        for package in ("imre-compiler", "imre-runtime"):
            relative = f"crates/{package}/src/lib.rs"
            source = self.root / relative
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_text("pub fn source() {}\n")
            (source.parent.parent / "Cargo.toml").write_text("[package]\n")
            self.before["files"][relative] = {"sha256": digest(source)}

    def guard(self):
        assert all(digest(self.root / path) == value["sha256"] for path, value in self.before["files"].items())
        assert all(digest(path) == expected for path, expected in self.frozen.items())

    def save(self):
        pass

    def command(self, name, command, environment=None):
        directory = self.output / "jobs" / name
        directory.mkdir(parents=True)
        packages = ["imre-compiler", "imre-runtime"] if name in {"unit", "clippy", "build-ordinary"} else ["imre-runtime"]
        messages, lines = [], []
        for package in packages:
            manifest = self.root / "crates" / package / "Cargo.toml"
            source = manifest.parent / "src/lib.rs"
            target = package.replace("-", "_")
            produced = directory / (target + ".artifact")
            produced.write_bytes(b"synthetic output")
            message = {
                "reason": "compiler-artifact", "manifest_path": str(manifest),
                "target": {"name": target, "src_path": str(source)},
                "fresh": False, "filenames": [str(produced)],
            }
            if self.fault == "cached":
                message["fresh"] = True
            if self.fault == "manifest":
                message["manifest_path"] = "/other/Cargo.toml"
            if self.fault == "source":
                message["target"]["src_path"] = "/other/src/lib.rs"
            messages.append(message)
            lines.append(f"     Running `/tool/rustc --crate-name {target} {source}`")
            if name.startswith("build-"):
                label = "compiler" if package == "imre-compiler" else name.removeprefix("build-")
                copied = directory / (target + ".copy")
                copied.write_bytes(produced.read_bytes())
                self.index["artifacts"][label] = {
                    "source": str(produced), "path": str(copied),
                    "sha256": digest(copied), "build_job": name,
                }
        messages.append({"reason": "build-finished", "success": self.fault != "failed"})
        if self.fault == "duplicate":
            messages.append(messages[-1])
        stdout, stderr = directory / "stdout", directory / "stderr"
        stdout.write_text("\n".join(json.dumps(value) for value in messages) + "\ntest result: ok. 1 passed; 0 failed;\n")
        stderr.write_text("" if self.fault == "verbose" else "\n".join(lines) + "\n")
        self.index["jobs"].append({
            "name": name, "command": command, "cwd": str(self.root),
            "stdout": str(stdout), "stderr": str(stderr),
        })
        return stdout


checks = []
with tempfile.TemporaryDirectory(prefix="imre-freshness-mock-") as temporary:
    directory = Path(temporary)
    for fault in ("cached", "manifest", "source", "failed", "duplicate", "verbose"):
        fake = FakeValidation(directory / fault, fault)
        try:
            fake.fresh_cargo("unit", ["test"], ["imre-compiler", "imre-runtime"])
        except RuntimeError:
            checks.append("reject_" + fault)
        else:
            raise AssertionError(f"accepted {fault}")
    fake = FakeValidation(directory / "positive")
    specs = {
        "clippy": (["clippy", "--", "-D", "warnings"], ["imre-compiler", "imre-runtime"]),
        "unit": (["test"], ["imre-compiler", "imre-runtime"]),
        "build-ordinary": (["build"], ["imre-compiler", "imre-runtime"]),
        "build-thinlto": (["build"], ["imre-runtime"]),
        "build-asan": (["build"], ["imre-runtime"]),
    }
    for name, (arguments, packages) in specs.items():
        fake.fresh_cargo(name, arguments, packages)
        checks.append("accept_" + name)
    clippy = fake.index["jobs"][0]["command"]
    assert clippy.index("--message-format=json-render-diagnostics") < clippy.index("--")
    checks.append("clippy_flags_before_separator")
    evidence = {
        path.relative_to(fake.output).as_posix(): digest(path)
        for path in fake.output.rglob("*") if path.is_file()
    }
    audit_syntax = ast.parse(audit.read_text())
    start = next(i for i, node in enumerate(audit_syntax.body) if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "expected_fresh_packages" for target in node.targets))
    stop = next(i for i, node in enumerate(audit_syntax.body) if i > start and isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "syntax" for target in node.targets))
    context = {
        "Path": Path, "json": json, "shlex": shlex, "digest": digest,
        "index": fake.index, "build": {"fresh_compilation": fake.index["fresh_compilation"]},
        "jobs": fake.index["jobs"], "repository": fake.root,
        "DIRECTORY": fake.output, "REVISION": fake.args.revision,
        "before": fake.before, "evidence": evidence,
    }
    exec(compile(ast.Module(body=audit_syntax.body[start:stop], type_ignores=[]), str(audit), "exec"), context)
    assert len(context["fresh_compilation"]) == 5
    checks.append("independent_audit_reparses_all_five_jobs_and_copies")
    output = fake.index["artifacts"]["ordinary"]["path"]
    Path(output).write_bytes(b"wrong copy")
    try:
        exec(compile(ast.Module(body=audit_syntax.body[start:stop], type_ignores=[]), str(audit), "exec"), context)
    except AssertionError:
        checks.append("independent_audit_rejects_changed_copy")
    else:
        raise AssertionError("independent audit accepted changed copy")

report = {
    "status": "passed", "checks": checks, "count": len(checks),
    "runner_sha256": digest(runner), "audit_sha256": digest(audit),
    "check_script_sha256": digest(__file__),
    "cargo_or_native_program_executed": False,
}
write_json(Path("/tmp/imre-luhn-freshness-helper-check.json"), report)
print(json.dumps(report))
