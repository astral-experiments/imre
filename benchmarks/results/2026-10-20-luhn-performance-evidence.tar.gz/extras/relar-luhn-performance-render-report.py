"""Render audited numbers into the report; leave attribution for review."""

import json
from pathlib import Path


def main():
    template = Path("/tmp/relar-luhn-performance-report.template.md").read_text()
    metrics = json.loads(Path("/tmp/relar-luhn-performance-tables.json").read_text())
    families = metrics["families"]
    thin = families["thinlto"]
    large_rows = [row for row in thin["rows"] if row["digits"] == 4096]
    large_rust = thin["rust_by_size"]["4096"]
    old_range = [
        min(row["baseline_over_relar"] for row in large_rows),
        max(row["baseline_over_relar"] for row in large_rows),
    ]
    py_range = [
        min(row["cpython_over_relar"] for row in large_rows),
        max(row["cpython_over_relar"] for row in large_rows),
    ]
    short = thin["rust_by_size"]["16"]
    medium = thin["rust_by_size"]["256"]
    ordinary = families["normal"]["rust_by_size"]
    lead = (
        f"With ThinLTO, **4,096-digit calls take {large_rust[0]:.2f}–{large_rust[1]:.2f}× "
        f"Rust's time**, or {(large_rust[0] - 1) * 100:.0f}–{(large_rust[1] - 1) * 100:.0f}% more. "
        f"They run **{old_range[0]:.1f}–{old_range[1]:.1f}× faster than the preserved Relar build** "
        f"and {py_range[0]:.1f}–{py_range[1]:.1f}× faster than CPython.\n\n"
        f"Short-call Rust parity remains open: 16-digit calls take "
        f"**{short[0]:.2f}–{short[1]:.2f}× Rust's time**; 256-digit calls take "
        f"{medium[0]:.2f}–{medium[1]:.2f}×. Ordinary linking takes "
        f"{ordinary['4096'][0]:.2f}–{ordinary['4096'][1]:.2f}× Rust's time at 4,096 digits "
        f"and {ordinary['16'][0]:.2f}–{ordinary['16'][1]:.2f}× at 16 digits."
    )
    startup = [
        "| Build family | Relar ms | Rust ms | CPython ms | Previous Relar ms |",
        "|---|---:|---:|---:|---:|",
    ]
    for mode, label in (("normal", "Ordinary"), ("thinlto", "ThinLTO")):
        values = families[mode]["startup_median_ms"]
        startup.append(
            f"| {label} | "
            + " | ".join(
                f"{values[engine]:.3f}"
                for engine in ("relar", "rust", "cpython", "baseline")
            )
            + " |"
        )
    maxima = {
        engine: max(
            family["startup_fraction_max"][engine] for family in families.values()
        )
        for engine in ("relar", "rust", "cpython", "baseline")
    }
    scope = (
        "Across both build families, the control is at most "
        f"{maxima['relar'] * 100:.2f}% of current Relar's median workload time, "
        f"{maxima['rust'] * 100:.2f}% of Rust's, {maxima['cpython'] * 100:.2f}% of CPython's, "
        f"and {maxima['baseline'] * 100:.2f}% of the previous Relar build's."
    )
    profiles = [
        "| Workload | Engine | Allocated bytes | Allocation blocks | Peak live bytes | Guest instructions |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for size in ("short", "large"):
        summary = json.loads(
            Path(f"/tmp/relar-luhn-performance-{size}-profile/summary.json").read_text()
        )
        audit = json.loads(
            Path(f"/tmp/relar-luhn-performance-{size}-profile-audit.json").read_text()
        )
        assert summary["status"] == audit["status"] == "passed"
        for engine in ("relar", "rust"):
            by_tool = {
                p["tool"]: p["metrics"]
                for p in summary["profiles"]
                if p["engine"] == engine
            }
            heap = by_tool["dhat"]
            profiles.append(
                f"| {summary['digits']:,} digits × {summary['repetitions']:,} calls "
                f"| {'Relar' if engine == 'relar' else 'Rust'} "
                f"| {heap['allocated_bytes']:,} | {heap['allocated_blocks']:,} "
                f"| {heap['peak_live_bytes']:,} | {by_tool['callgrind']['instructions']:,} |"
            )
    replacements = {
        "RESULT_LEAD": lead,
        "TIMING_TABLES": Path("/tmp/relar-luhn-performance-tables.md")
        .read_text()
        .rstrip(),
        "STARTUP_TABLE": "\n".join(startup),
        "STARTUP_SCOPE": scope,
        "PROFILE_TABLE": "\n".join(profiles),
    }
    for name, value in replacements.items():
        marker = f"@@{name}@@"
        assert template.count(marker) == 1
        template = template.replace(marker, value)
    output = Path("/tmp/relar-luhn-performance-report.md")
    assert not output.exists()
    output.write_text(template)
    print(output)


if __name__ == "__main__":
    main()
