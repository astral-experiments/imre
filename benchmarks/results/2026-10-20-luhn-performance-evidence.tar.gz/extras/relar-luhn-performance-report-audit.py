"""Check report tables against raw samples and profile counters without workloads."""

import argparse
import hashlib
import json
import re
import statistics
from datetime import datetime, timezone
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    text = args.report.read_text()
    audit_path = Path("/tmp/relar-luhn-performance-benchmark-audit.json")
    audit = read(audit_path)
    assert audit["status"] == "passed"
    expected_revision = "8b54eae6572a93926265d78562656dd395ad28b0"
    assert audit["timing_revision"] == expected_revision
    assert expected_revision in text
    inputs = {str(args.report): sha(args.report), str(audit_path): sha(audit_path)}
    displayed = {}
    mode = None
    for line in text.splitlines():
        if line == "### Ordinary linking":
            mode = "normal"
        elif line == "### ThinLTO":
            mode = "thinlto"
        match = re.match(r"\| `(checksum|verify|generate|append)` / ([\d,]+) \|", line)
        if match:
            key = (mode, match[1], int(match[2].replace(",", "")))
            assert key not in displayed
            displayed[key] = line
    assert len(displayed) == 24
    maxima = dict.fromkeys(("relar", "rust", "cpython", "baseline"), 0.0)
    ranges = {}
    for mode in ("normal", "thinlto"):
        path = Path(f"/tmp/relar-luhn-performance-v1-{mode}.json")
        record = read(path)
        inputs[str(path)] = sha(path)
        assert inputs[str(path)] == audit["identities"][mode]["record_sha256"]
        assert record["revision"] == expected_revision
        startup = {
            engine: statistics.median(
                sample[engine]["elapsed_ns"] / 1e9
                for sample in record["startup_control"]["samples"]
            )
            for engine in maxima
        }
        label = "Ordinary" if mode == "normal" else "ThinLTO"
        startup_line = f"| {label} | " + " | ".join(
            f"{startup[engine] * 1000:.3f}" for engine in maxima
        ) + " |"
        assert startup_line in text
        for point in record["workloads"]:
            medians, cells = {}, []
            for engine in maxima:
                samples = [sample[engine]["elapsed_ns"] / 1e9 for sample in point["samples"]]
                assert len(samples) == 12
                medians[engine] = statistics.median(samples)
                q1, _, q3 = statistics.quantiles(samples, n=4, method="inclusive")
                if engine != "baseline":
                    cells.append(
                        f"{medians[engine] * 1000:.3f} "
                        f"[{q1 * 1000:.3f}–{q3 * 1000:.3f}]"
                    )
                maxima[engine] = max(maxima[engine], startup[engine] / medians[engine])
            ratios = (
                medians["baseline"] / medians["relar"],
                medians["relar"] / medians["rust"],
                medians["cpython"] / medians["relar"],
            )
            key = (mode, point["operation"], point["digits"])
            expected = (
                f"| `{point['operation']}` / {point['digits']:,} | "
                + " | ".join(cells)
                + f" | {medians['baseline'] * 1000:.3f} | "
                + " | ".join(f"{ratio:.3f}×" for ratio in ratios)
                + " |"
            )
            assert displayed[key] == expected, key
            ranges.setdefault((mode, point["digits"]), []).append(ratios)
    startup_claims = re.search(
        r"control is at most ([\d.]+)%.*?([\d.]+)% of Rust's, "
        r"([\d.]+)% of CPython's, and ([\d.]+)%", text
    )
    assert startup_claims
    for engine, claimed in zip(maxima, startup_claims.groups()):
        assert float(claimed) >= maxima[engine] * 100
        assert float(claimed) - maxima[engine] * 100 < 0.01
    profile_rows = []
    for label in ("short", "large"):
        directory = Path(f"/tmp/relar-luhn-performance-{label}-profile")
        summary_path = directory / "summary.json"
        summary = read(summary_path)
        profile_audit_path = Path(f"/tmp/relar-luhn-performance-{label}-profile-audit.json")
        profile_audit = read(profile_audit_path)
        inputs[str(summary_path)] = sha(summary_path)
        inputs[str(profile_audit_path)] = sha(profile_audit_path)
        assert profile_audit["status"] == summary["status"] == "passed"
        assert summary["revision"] == expected_revision
        assert profile_audit["profile_summary_sha256"] == inputs[str(summary_path)]
        for engine in ("relar", "rust"):
            heap_path = directory / f"{engine}-dhat/profile.json"
            instruction_path = directory / f"{engine}-callgrind/profile.callgrind"
            heap = read(heap_path)
            totals = re.findall(r"^totals:\s+(\d+)\s*$", instruction_path.read_text(), re.M)
            assert len(totals) == 1
            values = (
                sum(point["tb"] for point in heap["pps"]),
                sum(point["tbk"] for point in heap["pps"]),
                sum(point.get("gb", 0) for point in heap["pps"]),
                int(totals[0]),
            )
            expected = (
                f"| {summary['digits']:,} digits × {summary['repetitions']:,} calls "
                f"| {'Relar' if engine == 'relar' else 'Rust'} | "
                + " | ".join(f"{value:,}" for value in values)
                + " |"
            )
            assert expected in text
            profile_rows.append({"label": label, "engine": engine, "values": values})
            inputs[str(heap_path)] = sha(heap_path)
            inputs[str(instruction_path)] = sha(instruction_path)
    validation_path = Path("/tmp/relar-luhn-performance-validation-audit.json")
    validation = read(validation_path)
    assert validation["status"] == "passed"
    assert validation["validation_revision"] == expected_revision
    inputs[str(validation_path)] = sha(validation_path)
    result = {
        "schema": 1,
        "status": "passed",
        "at_utc": datetime.now(timezone.utc).isoformat(),
        "revision": expected_revision,
        "auditor_sha256": sha(__file__),
        "input_sha256": inputs,
        "checks": {
            "timing_rows": 24,
            "displayed_duration_values": 240,
            "displayed_ratios": 72,
            "startup_medians": 8,
            "startup_upper_bounds": 4,
            "profile_rows_from_raw_counters": 4,
        },
        "startup_maxima_percent": {engine: value * 100 for engine, value in maxima.items()},
        "profile_rows": profile_rows,
        "remaining_placeholders": re.findall(r"@@[A-Z_]+@@", text),
        "limits": [
            "This verifies numeric table rendering against raw samples and profile counters.",
            "Narrative ranges and validation/provenance wording receive a separate manual review.",
            "No native program, compiler, test suite, benchmark, or profiler is executed.",
        ],
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "status": "passed", "checks": result["checks"]}))


if __name__ == "__main__":
    main()
