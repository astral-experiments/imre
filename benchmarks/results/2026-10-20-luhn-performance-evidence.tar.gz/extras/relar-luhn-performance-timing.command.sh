#!/bin/sh
set -eu

validation_dir=${1:?Pass the completed frozen validation directory}
prefix=${2:-/tmp/relar-luhn-performance-v1}

exec /home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14 \
  -I -B /tmp/relar-luhn-performance-run-benchmarks.py \
  --root /home/dev-user/code/oss/relar \
  --compiler "$validation_dir/artifacts/relar" \
  --normal-runtime "$validation_dir/artifacts/ordinary-runtime.a" \
  --thinlto-runtime "$validation_dir/artifacts/thinlto-runtime.a" \
  --build-record "$validation_dir/build.json" \
  --validation-index "$validation_dir/index.json" \
  --target x86_64-unknown-linux-gnu \
  --linker /home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld \
  --clang /usr/bin/clang-18 \
  --normal-reference "$validation_dir/references/luhn-normal" \
  --thinlto-reference "$validation_dir/references/luhn-thinlto" \
  --normal-baseline /tmp/relar-luhn-v2-normal/luhn \
  --normal-baseline-record /tmp/relar-luhn-v2-normal.json \
  --thinlto-baseline /tmp/relar-luhn-v2-thinlto/luhn \
  --thinlto-baseline-record /tmp/relar-luhn-v2-thinlto.json \
  --prefix "$prefix"
