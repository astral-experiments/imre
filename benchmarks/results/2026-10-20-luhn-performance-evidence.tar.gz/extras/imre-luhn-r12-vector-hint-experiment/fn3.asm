
/tmp/imre-luhn-r12-vector-hint-experiment/luhn:     file format elf64-x86-64


Disassembly of section .text:

0000000000105f90 <fn_3>:
  105f90:	push   %rbp
  105f91:	push   %r15
  105f93:	push   %r14
  105f95:	push   %r13
  105f97:	push   %r12
  105f99:	push   %rbx
  105f9a:	sub    $0x38,%rsp
  105f9e:	addr32 call 119470 <imre_str_int_list>
  105fa4:	mov    %rax,%r14
  105fa7:	xor    %edi,%edi
  105fa9:	call   127770 <_RNvYNCNKNvNtNtCs5N6zm3e4tnE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.3687425895475854622>
  105fae:	mov    $0x1,%ebp
  105fb3:	cmpb   $0x0,(%rax)
  105fb6:	jne    1064ec <fn_3+0x55c>
  105fbc:	mov    %rax,%rbx
  105fbf:	mov    %r14,%rdi
  105fc2:	mov    $0xffffffffffffffff,%rsi
  105fc9:	xor    %edx,%edx
  105fcb:	mov    $0xfffffffffffffffd,%rcx
  105fd2:	addr32 call 118750 <imre_list_slice_sum>
  105fd8:	cmpb   $0x0,(%rbx)
  105fdb:	jne    1064f1 <fn_3+0x561>
  105fe1:	test   %r14,%r14
  105fe4:	je     105ff0 <fn_3+0x60>
  105fe6:	incq   -0x10(%r14)
  105fea:	je     1064ea <fn_3+0x55a>
  105ff0:	mov    %rbx,0x30(%rsp)
  105ff5:	mov    %rax,0x8(%rsp)
  105ffa:	movabs $0xc000000000000000,%r15
  106004:	mov    0x10(%r14),%rax
  106008:	lea    (%rax,%rax,1),%rbp
  10600c:	movabs $0x666666666666666,%rcx
  106016:	cmp    %rcx,%rax
  106019:	jae    106228 <fn_3+0x298>
  10601f:	mov    $0x1,%r12d
  106025:	cmp    $0x2,%rax
  106029:	jb     106204 <fn_3+0x274>
  10602f:	lea    -0x3(,%rax,2),%rax
  106037:	movabs $0x7ffffffffffffff6,%rcx
  106041:	mov    0x8(%r14),%rdx
  106045:	cmp    $0x4,%rax
  106049:	mov    $0x4,%edi
  10604e:	cmovb  %rax,%rdi
  106052:	mov    %rbp,%rsi
  106055:	sub    %rdi,%rsi
  106058:	cmp    $0xc,%rsi
  10605c:	jb     1061d0 <fn_3+0x240>
  106062:	shr    $0x2,%rsi
  106066:	inc    %rsi
  106069:	lea    0x6(%rcx),%rdi
  10606d:	and    %rsi,%rdi
  106070:	lea    0x0(,%rdi,4),%r8
  106078:	sub    %r8,%rax
  10607b:	add    $0xfffffffffffffff1,%rbp
  10607f:	pxor   %xmm0,%xmm0
  106083:	movd   -0xf5ef7(%rip),%xmm1        # 10194 <anon.76308f6739ee2ec32d8bb5a37ebbcff7.40.llvm.6469393670801744543+0x78>
  10608b:	movdqa -0xf4813(%rip),%xmm2        # 11880 <_IO_stdin_used+0x1684>
  106093:	movdqa -0xf4d8b(%rip),%xmm3        # 11310 <_IO_stdin_used+0x1114>
  10609b:	movdqa -0xf48f3(%rip),%xmm4        # 117b0 <_IO_stdin_used+0x15b4>
  1060a3:	movdqa -0xf4bdb(%rip),%xmm5        # 114d0 <_IO_stdin_used+0x12d4>
  1060ab:	mov    %rdi,%r8
  1060ae:	xchg   %ax,%ax
  1060b0:	lea    0x30(,%rbp,4),%r9
  1060b8:	and    $0xfffffffffffffff8,%r9
  1060bc:	lea    0x20(,%rbp,4),%r10
  1060c4:	and    $0xfffffffffffffff8,%r10
  1060c8:	lea    0x10(,%rbp,4),%r11
  1060d0:	and    $0xfffffffffffffff8,%r11
  1060d4:	lea    0x0(,%rbp,4),%rbx
  1060dc:	and    $0xfffffffffffffff8,%rbx
  1060e0:	movq   (%rdx,%r10,1),%xmm6
  1060e6:	movq   (%rdx,%r9,1),%xmm8
  1060ec:	punpcklqdq %xmm6,%xmm8
  1060f1:	movq   (%rdx,%rbx,1),%xmm6
  1060f6:	movq   (%rdx,%r11,1),%xmm7
  1060fc:	punpcklqdq %xmm6,%xmm7
  106100:	movdqa %xmm8,%xmm9
  106105:	pand   %xmm2,%xmm9
  10610a:	movdqa %xmm7,%xmm6
  10610e:	pand   %xmm2,%xmm6
  106112:	pxor   %xmm4,%xmm8
  106117:	pshufd $0xf5,%xmm8,%xmm10
  10611d:	pcmpeqd %xmm4,%xmm10
  106122:	pcmpgtd %xmm5,%xmm8
  106127:	pshufd $0xa0,%xmm8,%xmm11
  10612d:	pand   %xmm10,%xmm11
  106132:	pshufd $0xf5,%xmm8,%xmm8
  106138:	por    %xmm11,%xmm8
  10613d:	movdqa %xmm8,%xmm10
  106142:	pand   %xmm3,%xmm10
  106147:	paddq  %xmm9,%xmm10
  10614c:	pxor   %xmm4,%xmm7
  106150:	pshufd $0xf5,%xmm7,%xmm9
  106156:	pcmpeqd %xmm4,%xmm9
  10615b:	pcmpgtd %xmm5,%xmm7
  10615f:	pshufd $0xa0,%xmm7,%xmm11
  106165:	pand   %xmm9,%xmm11
  10616a:	pshufd $0xf5,%xmm7,%xmm7
  10616f:	por    %xmm11,%xmm7
  106174:	movdqa %xmm7,%xmm9
  106179:	pand   %xmm3,%xmm9
  10617e:	paddq  %xmm6,%xmm9
  106183:	psubq  %xmm8,%xmm10
  106188:	psubq  %xmm7,%xmm9
  10618d:	paddq  %xmm10,%xmm10
  106192:	paddq  %xmm10,%xmm1
  106197:	paddq  %xmm9,%xmm9
  10619c:	paddq  %xmm9,%xmm0
  1061a1:	add    $0xfffffffffffffff0,%rbp
  1061a5:	add    $0xfffffffffffffffc,%r8
  1061a9:	jne    1060b0 <fn_3+0x120>
  1061af:	paddq  %xmm1,%xmm0
  1061b3:	pshufd $0xee,%xmm0,%xmm1
  1061b8:	paddq  %xmm0,%xmm1
  1061bc:	movq   %xmm1,%r12
  1061c1:	cmp    %rdi,%rsi
  1061c4:	je     106204 <fn_3+0x274>
  1061c6:	cs nopw 0x0(%rax,%rax,1)
  1061d0:	mov    %rax,%rsi
  1061d3:	and    $0xfffffffffffffffe,%rsi
  1061d7:	mov    (%rdx,%rsi,4),%rsi
  1061db:	mov    %esi,%edi
  1061dd:	and    $0x1e,%edi
  1061e0:	xor    %r8d,%r8d
  1061e3:	cmp    $0xa,%rsi
  1061e7:	setae  %r8b
  1061eb:	mov    $0x0,%esi
  1061f0:	cmovae %rcx,%rsi
  1061f4:	add    %rdi,%rsi
  1061f7:	or     %rsi,%r8
  1061fa:	lea    (%r12,%r8,2),%r12
  1061fe:	sub    $0x4,%rax
  106202:	ja     1061d0 <fn_3+0x240>
  106204:	mov    %r14,%rdi
  106207:	addr32 call 111e80 <imre_list_release>
  10620d:	test   %r12,%r12
  106210:	sete   %al
  106213:	or     %r12b,%al
  106216:	test   $0x1,%al
  106218:	je     106336 <fn_3+0x3a6>
  10621e:	mov    0x8(%rsp),%rbp
  106223:	jmp    106369 <fn_3+0x3d9>
  106228:	inc    %rbp
  10622b:	mov    $0x1,%r13d
  106231:	lea    0x5f38(%rip),%rbx        # 10c170 <imre_int_binary>
  106238:	jmp    106259 <fn_3+0x2c9>
  10623a:	lea    0x1(,%rax,2),%r12
  106242:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  106250:	mov    %r12,%r13
  106253:	cmp    $0x4,%rbp
  106257:	jbe    106204 <fn_3+0x274>
  106259:	add    $0xfffffffffffffffc,%rbp
  10625d:	mov    %rbp,%rax
  106260:	shr    $1,%rax
  106263:	cmp    0x10(%r14),%rax
  106267:	jae    1062f0 <fn_3+0x360>
  10626d:	mov    0x8(%r14),%rcx
  106271:	mov    (%rcx,%rax,8),%rax
  106275:	test   %rax,%rax
  106278:	je     1064c0 <fn_3+0x530>
  10627e:	mov    %eax,%edx
  106280:	and    $0x1e,%edx
  106283:	lea    -0xa(%rdx),%rsi
  106287:	xor    %ecx,%ecx
  106289:	cmp    $0xa,%rax
  10628d:	setae  %cl
  106290:	cmovb  %rdx,%rsi
  106294:	or     %rsi,%rcx
  106297:	test   $0x1,%r13b
  10629b:	je     1062ae <fn_3+0x31e>
  10629d:	mov    %r13,%rax
  1062a0:	sar    $1,%rax
  1062a3:	add    %rcx,%rax
  1062a6:	mov    %rax,%rdx
  1062a9:	add    %r15,%rdx
  1062ac:	js     10623a <fn_3+0x2aa>
  1062ae:	lea    0x1(,%rcx,2),%rsi
  1062b6:	mov    %r13,%rdi
  1062b9:	xor    %edx,%edx
  1062bb:	call   *%rbx
  1062bd:	mov    %rax,%r12
  1062c0:	test   %r13,%r13
  1062c3:	sete   %al
  1062c6:	or     %r13b,%al
  1062c9:	test   $0x1,%al
  1062cb:	jne    106250 <fn_3+0x2c0>
  1062cd:	lea    -0x10(%r13),%rax
  1062d1:	mov    %rax,0x10(%rsp)
  1062d6:	decq   -0x10(%r13)
  1062da:	jne    106250 <fn_3+0x2c0>
  1062e0:	lea    0x10(%rsp),%rdi
  1062e5:	addr32 call 121400 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  1062eb:	jmp    106250 <fn_3+0x2c0>
  1062f0:	movabs $0x6f2074756f207865,%rax
  1062fa:	mov    %rax,0x18(%rsp)
  1062ff:	movabs $0xd765676e61722066,%rax
  106309:	mov    %rax,0x20(%rsp)
  10630e:	movabs $0x646e69207473696c,%rax
  106318:	mov    %rax,0x10(%rsp)
  10631d:	movl   $0x6,0x28(%rsp)
  106325:	lea    0x10(%rsp),%rdi
  10632a:	xor    %esi,%esi
  10632c:	call   125280 <_RINvMs0_NtNtCs5N6zm3e4tnE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  106331:	jmp    106275 <fn_3+0x2e5>
  106336:	incq   -0x10(%r12)
  10633b:	mov    %r12,%r13
  10633e:	mov    0x8(%rsp),%rbp
  106343:	je     1064ea <fn_3+0x55a>
  106349:	test   $0x1,%r13b
  10634d:	jne    106369 <fn_3+0x3d9>
  10634f:	lea    -0x10(%r13),%rax
  106353:	mov    %rax,0x10(%rsp)
  106358:	decq   -0x10(%r13)
  10635c:	jne    106369 <fn_3+0x3d9>
  10635e:	lea    0x10(%rsp),%rdi
  106363:	addr32 call 121400 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  106369:	mov    0x30(%rsp),%rax
  10636e:	cmpb   $0x0,(%rax)
  106371:	jne    1064f6 <fn_3+0x566>
  106377:	mov    %ebp,%ebx
  106379:	and    $0x1,%ebx
  10637c:	test   %ebx,%r12d
  10637f:	je     106395 <fn_3+0x405>
  106381:	mov    %rbp,%rcx
  106384:	sar    $1,%rcx
  106387:	mov    %r12,%rax
  10638a:	sar    $1,%rax
  10638d:	add    %rcx,%rax
  106390:	add    %rax,%r15
  106393:	js     1063c4 <fn_3+0x434>
  106395:	mov    %rbp,%rdi
  106398:	mov    %r12,%rsi
  10639b:	xor    %edx,%edx
  10639d:	addr32 call 10c170 <imre_int_binary>
  1063a3:	mov    %rax,%rbp
  1063a6:	test   $0x1,%bpl
  1063aa:	jne    1063d2 <fn_3+0x442>
  1063ac:	mov    $0x15,%esi
  1063b1:	mov    %rbp,%rdi
  1063b4:	mov    $0x4,%edx
  1063b9:	addr32 call 10c170 <imre_int_binary>
  1063bf:	mov    %rax,%r13
  1063c2:	jmp    106415 <fn_3+0x485>
  1063c4:	lea    0x1(,%rax,2),%rbp
  1063cc:	test   $0x1,%bpl
  1063d0:	je     1063ac <fn_3+0x41c>
  1063d2:	mov    %rbp,%rcx
  1063d5:	sar    $1,%rcx
  1063d8:	movabs $0x6666666666666667,%rdx
  1063e2:	mov    %rcx,%rax
  1063e5:	imul   %rdx
  1063e8:	mov    %rdx,%rax
  1063eb:	shr    $0x3f,%rax
  1063ef:	sar    $0x2,%rdx
  1063f3:	add    %rax,%rdx
  1063f6:	add    %rdx,%rdx
  1063f9:	lea    (%rdx,%rdx,4),%rax
  1063fd:	sub    %rax,%rcx
  106400:	mov    %rcx,%rax
  106403:	sar    $0x3f,%rax
  106407:	and    $0xa,%eax
  10640a:	add    %rcx,%rax
  10640d:	lea    0x1(,%rax,2),%r13
  106415:	test   %rbp,%rbp
  106418:	sete   %al
  10641b:	or     %bpl,%al
  10641e:	mov    0x30(%rsp),%rcx
  106423:	cmpb   $0x0,(%rcx)
  106426:	jne    1064fe <fn_3+0x56e>
  10642c:	test   $0x1,%al
  10642e:	jne    10644a <fn_3+0x4ba>
  106430:	lea    -0x10(%rbp),%rax
  106434:	mov    %rax,0x10(%rsp)
  106439:	decq   -0x10(%rbp)
  10643d:	jne    10644a <fn_3+0x4ba>
  10643f:	lea    0x10(%rsp),%rdi
  106444:	addr32 call 121400 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  10644a:	mov    %r14,%rdi
  10644d:	addr32 call 111e80 <imre_list_release>
  106453:	mov    0x8(%rsp),%rcx
  106458:	test   %rcx,%rcx
  10645b:	sete   %al
  10645e:	or     %bl,%al
  106460:	jne    10647f <fn_3+0x4ef>
  106462:	mov    %rcx,%rax
  106465:	add    $0xfffffffffffffff0,%rax
  106469:	mov    %rax,0x10(%rsp)
  10646e:	decq   -0x10(%rcx)
  106472:	jne    10647f <fn_3+0x4ef>
  106474:	lea    0x10(%rsp),%rdi
  106479:	addr32 call 121400 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  10647f:	test   %r12,%r12
  106482:	sete   %al
  106485:	or     %r12b,%al
  106488:	test   $0x1,%al
  10648a:	jne    1064ae <fn_3+0x51e>
  10648c:	test   $0x1,%r12b
  106490:	jne    1064ae <fn_3+0x51e>
  106492:	lea    -0x10(%r12),%rax
  106497:	mov    %rax,0x10(%rsp)
  10649c:	decq   -0x10(%r12)
  1064a1:	jne    1064ae <fn_3+0x51e>
  1064a3:	lea    0x10(%rsp),%rdi
  1064a8:	addr32 call 121400 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs5N6zm3e4tnE_12imre_runtime>
  1064ae:	mov    %r13,%rax
  1064b1:	add    $0x38,%rsp
  1064b5:	pop    %rbx
  1064b6:	pop    %r12
  1064b8:	pop    %r13
  1064ba:	pop    %r14
  1064bc:	pop    %r15
  1064be:	pop    %rbp
  1064bf:	ret
  1064c0:	mov    %r14,%rdi
  1064c3:	addr32 call 111e80 <imre_list_release>
  1064c9:	test   %r13,%r13
  1064cc:	sete   %al
  1064cf:	or     %r13b,%al
  1064d2:	mov    $0x1,%r12d
  1064d8:	test   $0x1,%al
  1064da:	mov    0x8(%rsp),%rbp
  1064df:	je     106349 <fn_3+0x3b9>
  1064e5:	jmp    106369 <fn_3+0x3d9>
  1064ea:	ud2
  1064ec:	xor    %r14d,%r14d
  1064ef:	jmp    1064f6 <fn_3+0x566>
  1064f1:	mov    $0x1,%ebp
  1064f6:	mov    $0x1,%r12d
  1064fc:	jmp    106510 <fn_3+0x580>
  1064fe:	test   $0x1,%al
  106500:	jne    10650b <fn_3+0x57b>
  106502:	mov    %rbp,%rdi
  106505:	addr32 call 111450 <imre_int_release>
  10650b:	mov    0x8(%rsp),%rbp
  106510:	mov    %r14,%rdi
  106513:	addr32 call 111e80 <imre_list_release>
  106519:	test   %rbp,%rbp
  10651c:	sete   %al
  10651f:	or     %bpl,%al
  106522:	test   $0x1,%al
  106524:	jne    10652f <fn_3+0x59f>
  106526:	mov    %rbp,%rdi
  106529:	addr32 call 111450 <imre_int_release>
  10652f:	test   %r12,%r12
  106532:	sete   %al
  106535:	or     %r12b,%al
  106538:	mov    $0x1,%r13d
  10653e:	test   $0x1,%al
  106540:	je     10648c <fn_3+0x4fc>
  106546:	jmp    1064ae <fn_3+0x51e>
  10654b:	addr32 call eae43 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  106551:	addr32 call eae43 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  106557:	addr32 call eae43 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10655d:	addr32 call eae43 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  106563:	addr32 call eae43 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  106569:	addr32 call eae43 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
