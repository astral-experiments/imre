"""Independently audit the frozen Luhn timing matrix and derive its comparison."""

import argparse
import base64
import hashlib
import importlib.util
import itertools
import json
import math
import statistics
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def option(command, name):
    return command[command.index(name) + 1]


def close(left, right):
    assert math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-15), (left, right)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path("/home/dev-user/code/oss/relar")
    )
    parser.add_argument("--prefix", type=Path, default=Path("/tmp/relar-luhn-performance-v1"))
    parser.add_argument(
        "--validation-index", type=Path,
        default=Path("/tmp/relar-luhn-performance-validation-v3/index.json"),
    )
    parser.add_argument(
        "--revision", default="8b54eae6572a93926265d78562656dd395ad28b0",
    )
    parser.add_argument(
        "--output", type=Path, default=Path("/tmp/relar-luhn-performance-benchmark-audit.json")
    )
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    status_path = Path(str(args.prefix) + "-timing-status.json")
    status = json.loads(status_path.read_text())
    assert status["status"] == "passed"
    assert status["input_guards_passed"] and status["source_unchanged"]
    assert len(status["runs"]) == 2
    assert {run["mode"] for run in status["runs"]} == {"normal", "thinlto"}
    assert all(run["returncode"] == 0 for run in status["runs"])
    assert {
        name: digest(path) for name, path in status["protected_paths"].items()
    } == status["source_and_tool_sha256"]
    validation_path = args.validation_index.resolve(strict=True)
    assert Path(status["protected_paths"]["validation_index"]).resolve(strict=True) == validation_path
    matrix = json.loads(validation_path.read_text())
    assert matrix["status"] == "passed" and matrix["input_guards_passed"]
    assert matrix["source_unchanged"]
    assert (
        matrix["revision"] == status["validation_revision"] == status["build_revision"]
        == status["head"] == status["timing_revision"] == args.revision
    )
    git = lambda *items: subprocess.check_output(
        ["git", "-C", str(root), *items], text=True
    ).strip()
    assert git("rev-parse", "HEAD") == status["head"]
    assert not git("status", "--porcelain")
    changed_paths = git("diff", "--name-only", matrix["revision"], status["head"]).splitlines()
    assert changed_paths == []
    assert changed_paths == status["post_validation_changes"]["paths"]
    patch = git("diff", matrix["revision"], status["head"])
    assert patch == status["post_validation_changes"]["patch"] == ""
    assert hashlib.sha256(patch.encode()).hexdigest() == status["post_validation_changes"]["patch_sha256"]
    spec = importlib.util.spec_from_file_location(
        "independent_luhn_oracle", root / "examples/luhn_checksum/luhn.py"
    )
    codec = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(codec)
    rows, identities = [], {}
    sample_count = 0
    for run in status["runs"]:
        mode = run["mode"]
        record_path = Path(str(args.prefix) + "-" + mode + ".json")
        record = json.loads(record_path.read_text())
        assert digest(record_path) == run["record_sha256"]
        assert digest(run["stdout"]) == run["stdout_sha256"]
        assert digest(run["stderr"]) == run["stderr_sha256"]
        assert Path(run["stderr"]).read_bytes() == b"" and run["returncode"] == 0
        assert record["revision"] == status["head"] and not record["dirty"]
        assert record["input_guards_passed"] and record["thinlto"] == (
            mode == "thinlto"
        )
        assert record["samples"] == 12 and record["warmups"] == 8
        assert record["batch_digits"] == 16 * 1024 * 1024
        assert len(record["cpu"]["affinity"]) == 1
        assert record["python"]["implementation"] == "cpython"
        compile_command = record["compile_command"]
        measured_binary = Path(option(compile_command, "-o"))
        llvm = Path(option(compile_command, "--emit-llvm"))
        assert digest(measured_binary) == record["binary_sha256"]
        assert digest(llvm) == record["llvm_sha256"]
        validation_path = Path(option(record["validation_command"], "--output"))
        assert json.loads(validation_path.read_text()) == record["validation"]
        validation = record["validation"]
        assert validation["relar"]["binary_sha256"] == record["binary_sha256"]
        assert (
            validation["rust"]["binary_sha256"]
            == record["source_and_tool_sha256"]["rust"]
        )
        for engine in ("relar", "rust"):
            assert validation[engine]["native_adapter_calls"] == 15
            assert len(validation[engine]["upstream_native_adapter"]["tests"]) == 10
            assert (
                validation[engine]["upstream_native_adapter"]["doctest_examples"] == 5
            )
            assert validation[engine]["exact_message_cases"] == len(
                validation[engine]["differential_cases"]
            )
            assert len(validation[engine]["differential_cases"]) >= 1144
        upstream = json.loads(
            (root / "examples/luhn_checksum/UPSTREAM.json").read_text()
        )
        assert upstream == record["upstream"] == validation["upstream"]
        assert upstream["commit"] == "d6f3fa71072f99334a4c1d2a3f062fa93982797f"
        for name, original in upstream["files"].items():
            path = root / "examples/luhn_checksum" / name
            assert (
                digest(path) == original["sha256"]
                and path.stat().st_size == original["bytes"]
            )
        paths = {
            "compiler": Path(compile_command[0]),
            "runtime": Path(option(compile_command, "--runtime")),
            "python": Path(record["python"]["executable"]),
            "clang": Path(option(compile_command, "--clang")),
            "rust": Path(option(run["command"], "--rust")),
            "rust_build_record": Path(option(run["command"], "--rust-build-record")),
            "baseline": Path(option(run["command"], "--baseline")),
            "baseline_record": Path(option(run["command"], "--baseline-record")),
            "harness": root / "benchmarks/luhn_benchmark.py",
            "validator": root / "benchmarks/luhn_validate.py",
            "shared_harness": root / "benchmarks/benchmark.py",
            "shared_validator": root / "benchmarks/validate.py",
            "relar_build_record": Path(option(run["command"], "--relar-build-record")),
        }
        if mode == "thinlto":
            paths["lto_linker"] = Path(option(compile_command, "--lto-linker"))
        for name in record["source_and_tool_sha256"]:
            if name.startswith("example:"):
                paths[name] = (
                    root / "examples/luhn_checksum" / name.removeprefix("example:")
                )
            elif name.startswith("rust_source:"):
                paths[name] = (
                    root
                    / "benchmarks/reference/luhn_checksum"
                    / name.removeprefix("rust_source:")
                )
            elif name.startswith("relar_source:"):
                paths[name] = root / name.removeprefix("relar_source:")
        assert set(paths) == set(record["source_and_tool_sha256"])
        assert {name: digest(path) for name, path in paths.items()} == record[
            "source_and_tool_sha256"
        ]
        rust_record = json.loads(paths["rust_build_record"].read_text())
        assert rust_record == record["rust_build_record"]
        assert rust_record["binary_sha256"] == digest(paths["rust"])
        assert rust_record["thinlto"] == (mode == "thinlto")
        for name, value in rust_record["sources"].items():
            assert digest(root / "benchmarks/reference/luhn_checksum" / name) == value
            assert (
                hashlib.sha256(
                    rust_record["source_contents"][name].encode()
                ).hexdigest()
                == value
            )
        assert (
            json.loads(paths["relar_build_record"].read_text())
            == record["relar_build_record"]
        )
        assert record["relar_build_record"]["revision"] == status["build_revision"]
        baseline = json.loads(paths["baseline_record"].read_text())
        assert baseline == record["baseline_record"]
        assert baseline["input_guards_passed"] and baseline["dirty"] is False
        assert baseline["binary_sha256"] == digest(paths["baseline"])
        assert baseline["validation"]["relar"]["binary_sha256"] == baseline["binary_sha256"]
        assert baseline["requested_target"] == record["requested_target"]
        assert baseline["thinlto"] == record["thinlto"]
        assert option(baseline["compile_command"], "--opt-level") == "3"
        assert ("--lto-linker" in baseline["compile_command"]) == record["thinlto"]
        assert baseline["upstream"] == record["upstream"]
        old_hashes, new_hashes = baseline["source_and_tool_sha256"], record["source_and_tool_sha256"]
        matching_tools = ["python", "clang", "validator", "shared_harness", "shared_validator"]
        if mode == "thinlto":
            matching_tools.append("lto_linker")
        assert all(old_hashes[name] == new_hashes[name] for name in matching_tools)
        assert baseline["rust_build_record"]["input_guards_passed"]
        assert all(
            baseline["rust_build_record"][name] == rust_record[name]
            for name in ("sources", "tool_sha256", "thinlto", "llvm_budget")
        )
        differences = []
        for name in sorted(old_hashes.keys() | new_hashes.keys()):
            if not name.startswith(("example:", "rust_source:")):
                continue
            previous, current = old_hashes.get(name), new_hashes.get(name)
            if previous != current:
                assert name.endswith(".md"), name
                differences.append({"path": name, "baseline_sha256": previous, "current_sha256": current})
        provenance = record["baseline_provenance"]
        assert provenance["record_sha256"] == digest(paths["baseline_record"])
        assert provenance["binary_sha256"] == baseline["binary_sha256"]
        assert provenance["revision"] == baseline["revision"]
        assert provenance["documentation_differences"] == differences
        assert provenance["requested_target"] == record["requested_target"]
        assert provenance["thinlto"] == record["thinlto"]
        baseline_validation_path = Path(option(record["baseline_validation_command"], "--output"))
        baseline_validation = json.loads(baseline_validation_path.read_text())
        assert baseline_validation == record["baseline_validation"]
        assert baseline_validation["upstream"] == record["upstream"]
        assert baseline_validation["relar"]["binary_sha256"] == baseline["binary_sha256"]
        assert baseline_validation["relar"]["native_adapter_calls"] == 15
        assert baseline_validation["relar"]["exact_message_cases"] == 1144
        assert len(baseline_validation["relar"]["differential_cases"]) == 1144
        assert record["workload_source"] == "preserved baseline inputs"
        original_points = {point["label"]: point for point in baseline["workloads"]}
        assert len(original_points) == len(baseline["workloads"])
        expected_engines = ("relar", "rust", "baseline", "cpython")
        expected_orders = tuple(
            tuple(expected_engines[(position + rotation) % 4] for position in (0, 1, 3, 2))
            for rotation in range(4)
        )
        assert tuple(map(tuple, record["engine_orders"])) == expected_orders
        assert all(Counter(position) == Counter(expected_engines) for position in zip(*expected_orders))
        assert Counter(
            pair for order in expected_orders for pair in zip(order, order[1:])
        ) == Counter(itertools.permutations(expected_engines, 2))
        assert "Transitions between rounds are not balanced" in record["order_method"]
        points = [record["startup_control"], *record["workloads"]]
        assert {point["label"] for point in record["workloads"]} == {
            f"{operation}-{size}"
            for operation in ("checksum", "verify", "generate", "append")
            for size in (16, 256, 4096)
        }
        for point in points:
            payload = base64.b64decode(point["input_base64"], validate=True)
            assert hashlib.sha256(payload).hexdigest() == point["input_sha256"]
            value = getattr(codec, point["operation"])(payload.decode())
            output = str(value).encode()
            contribution = len(value) if point["operation"] == "append" else int(value)
            stdout = f"OK\n{contribution * point['repetitions']}\n"
            assert base64.b64decode(point["expected_output_base64"]) == output
            assert point["expected_stdout"] == stdout
            assert point["expected_output_sha256"] == hashlib.sha256(output).hexdigest()
            engines = tuple(point["summary"])
            assert engines == expected_engines
            if point["label"] != "empty-control":
                prior = original_points[point["label"]]
                for field in ("input_base64", "input_sha256", "digits", "operation", "expected_output_base64", "expected_output_sha256"):
                    assert point[field] == prior[field], (point["label"], field)
            for phase, count in (("warmups", 8), ("samples", 12)):
                samples = point[phase]
                assert len(samples) == count
                orders = [tuple(sample["order"]) for sample in samples]
                assert orders == [expected_orders[index % 4] for index in range(count)]
                assert Counter(orders) == {order: count // 4 for order in expected_orders}
                assert all(
                    Counter(position) == Counter({engine: count // 4 for engine in engines})
                    for position in zip(*orders)
                )
                assert Counter(
                    pair for order in orders for pair in zip(order, order[1:])
                ) == Counter({pair: count // 4 for pair in itertools.permutations(engines, 2)})
                assert [sample["index"] for sample in samples] == list(range(count))
            executions = [point["gates"], *point["warmups"], *point["samples"]]
            for execution in executions:
                for engine in engines:
                    item = execution[engine]
                    assert (
                        isinstance(item["elapsed_ns"], int) and item["elapsed_ns"] > 0
                    )
                    assert item["returncode"] == 0 and item["stderr"] == ""
                    assert item["stdout"] == stdout
                    assert item["output_sha256"] == point["expected_output_sha256"]
                    command = item["command"]
                    assert command[-4] == point["operation"]
                    assert int(command[-1]) == point["repetitions"]
                    assert Path(command[-3]).read_bytes() == payload
                    assert Path(command[-2]).read_bytes() == output
                    expected_engine = {
                        "relar": measured_binary,
                        "rust": paths["rust"],
                        "baseline": paths["baseline"],
                        "cpython": paths["python"],
                    }[engine]
                    assert digest(command[0]) == digest(expected_engine)
                    sample_count += 1
            for engine in engines:
                seconds = [
                    sample[engine]["elapsed_ns"] / 1e9 for sample in point["samples"]
                ]
                quartiles = statistics.quantiles(seconds, n=4, method="inclusive")
                expected_summary = {
                    "median_seconds": statistics.median(seconds),
                    "min_seconds": min(seconds),
                    "max_seconds": max(seconds),
                    "p25_seconds": quartiles[0],
                    "p75_seconds": quartiles[2],
                }
                for name, value in expected_summary.items():
                    close(point["summary"][engine][name], value)
            medians = {
                name: value["median_seconds"]
                for name, value in point["summary"].items()
            }
            for left, right in (
                ("cpython", "relar"),
                ("relar", "rust"),
                ("cpython", "rust"),
                ("baseline", "relar"),
                ("baseline", "rust"),
                ("cpython", "baseline"),
            ):
                close(point[f"{left}_over_{right}"], medians[left] / medians[right])
            if point is not record["startup_control"]:
                for engine in engines:
                    close(
                        point["startup_control_fraction"][engine],
                        record["startup_control"]["summary"][engine]["median_seconds"]
                        / medians[engine],
                    )
                rows.append(
                    {
                        "mode": mode,
                        "label": point["label"],
                        "digits": point["digits"],
                        "repetitions": point["repetitions"],
                        "summary": point["summary"],
                        "cpython_over_relar": point["cpython_over_relar"],
                        "relar_over_rust": point["relar_over_rust"],
                        "baseline_over_relar": point["baseline_over_relar"],
                        "baseline_over_rust": point["baseline_over_rust"],
                        "cpython_over_baseline": point["cpython_over_baseline"],
                        "startup_control_fraction": point["startup_control_fraction"],
                    }
                )
        identities[mode] = {
            "record_sha256": digest(record_path),
            "binary_sha256": record["binary_sha256"],
            "rust_binary_sha256": digest(paths["rust"]),
            "baseline_binary_sha256": digest(paths["baseline"]),
            "baseline_record_sha256": digest(paths["baseline_record"]),
            "baseline_validation_sha256": digest(baseline_validation_path),
            "baseline_revision": baseline["revision"],
            "baseline_documentation_differences": differences,
            "validation_sha256": digest(validation_path),
            "llvm_sha256": digest(llvm),
            "cpu": record["cpu"],
        }
    assert len(rows) == 24 and set(identities) == {"normal", "thinlto"}
    assert sample_count == 2 * 13 * 4 * (1 + 8 + 12) == 2184
    assert status["schedule"]["samples"] == 12 and status["schedule"]["warmups"] == 8
    assert status["schedule"]["fixed_before_measurement"]
    assert status["schedule"]["batch_digits"] == 16 * 1024 * 1024
    assert (
        identities["normal"]["cpu"]["affinity"]
        == identities["thinlto"]["cpu"]["affinity"]
    )
    audit = {
        "status": "passed",
        "at_utc": datetime.now(timezone.utc).isoformat(),
        "auditor_sha256": digest(__file__),
        "timing_status_sha256": digest(status_path),
        "validation_index_sha256": digest(validation_path),
        "head": status["head"],
        "timing_revision": status["timing_revision"],
        "build_revision": status["build_revision"],
        "validation_revision": status["validation_revision"],
        "post_validation_changes": status["post_validation_changes"],
        "identities": identities,
        "checked_executions_including_gates": sample_count,
        "schedule": {
            "engines": expected_engines, "orders": expected_orders,
            "warmups_per_point": 8, "samples_per_point": 12,
            "position_balance_verified": True,
            "within_round_predecessor_balance_verified": True,
            "cross_round_predecessor_balance_claimed": False,
            "fixed_before_measurement": True,
        },
        "timed_sample_duration_count": 2 * 13 * 4 * 12,
        "workload_sample_duration_count_excluding_controls": 2 * 12 * 4 * 12,
        "limits": [
            "This audits stored records and recomputes tiny CPython output oracles; no compiler, native test, profile, or timing workload is run.",
            "The exact four-order schedule balances engine positions and directed adjacent pairs within each round; transitions between rounds are not balanced.",
            "The baseline is remeasured under current conditions from its exact preserved binary; the older timing medians are not substituted.",
            "Build, full-validation, and timing use one exact frozen revision with no post-validation source changes. The preserved baseline revision is reported separately.",
        ],
        "units": {
            "durations": "seconds",
            "ratios": "dimensionless",
            "input_size": "ASCII digits",
        },
        "comparison": rows,
    }
    args.output.write_text(json.dumps(audit, indent=2) + "\n")
    print(
        json.dumps(
            {
                "audit": str(args.output),
                "sha256": digest(args.output),
                "rows": len(rows),
                "executions": sample_count,
            }
        )
    )


if __name__ == "__main__":
    main()
