"""Derive report tables from independently audited final timing records."""

import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--prefix", type=Path, default=Path("/tmp/relar-luhn-performance-v1")
    )
    parser.add_argument(
        "--audit",
        type=Path,
        default=Path("/tmp/relar-luhn-performance-benchmark-audit.json"),
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    audit = json.loads(args.audit.read_text())
    assert audit["status"] == "passed"
    metric_path = args.output.with_suffix(".json")
    assert not args.output.exists() and not metric_path.exists()
    lines = []
    result = {"sources": {}, "families": {}}
    for family in ("normal", "thinlto"):
        path = Path(f"{args.prefix}-{family}.json")
        record = json.loads(path.read_text())
        assert record["input_guards_passed"] and not record["dirty"]
        source_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        assert source_hash == audit["identities"][family]["record_sha256"]
        assert record["revision"] == audit["timing_revision"]
        result["sources"][str(path)] = source_hash
        lines += [
            f"### {'Ordinary linking' if family == 'normal' else 'ThinLTO'}",
            "",
            "| API / digits | Relar ms [Q1–Q3] | Rust ms [Q1–Q3] | CPython ms [Q1–Q3] | Previous Relar ms | Previous / current | Relar / Rust | CPython / Relar |",
            "|---|---:|---:|---:|---:|---:|---:|---:|",
        ]
        rows = []
        for point in record["workloads"]:
            summary = point["summary"]
            medians = {
                engine: data["median_seconds"] for engine, data in summary.items()
            }
            ratio = {
                "relar_over_rust": medians["relar"] / medians["rust"],
                "cpython_over_relar": medians["cpython"] / medians["relar"],
                "baseline_over_relar": medians["baseline"] / medians["relar"],
            }
            values = []
            for engine in ("relar", "rust", "cpython"):
                data = summary[engine]
                values.append(
                    f"{1000 * data['median_seconds']:.3f} "
                    f"[{1000 * data['p25_seconds']:.3f}–{1000 * data['p75_seconds']:.3f}]"
                )
            lines.append(
                f"| `{point['operation']}` / {point['digits']:,} | "
                + " | ".join(values)
                + f" | {1000 * medians['baseline']:.3f} "
                + f"| {ratio['baseline_over_relar']:.3f}× "
                + f"| {ratio['relar_over_rust']:.3f}× "
                + f"| {ratio['cpython_over_relar']:.3f}× |"
            )
            rows.append({"label": point["label"], "digits": point["digits"], **ratio})
        lines.append("")
        result["families"][family] = {
            "rows": rows,
            "ranges": {
                name: [min(row[name] for row in rows), max(row[name] for row in rows)]
                for name in (
                    "relar_over_rust",
                    "cpython_over_relar",
                    "baseline_over_relar",
                )
            },
            "rust_by_size": {
                size: [
                    min(row["relar_over_rust"] for row in rows if row["digits"] == size),
                    max(row["relar_over_rust"] for row in rows if row["digits"] == size),
                ]
                for size in (16, 256, 4096)
            },
            "startup_median_ms": {
                engine: data["median_seconds"] * 1000
                for engine, data in record["startup_control"]["summary"].items()
            },
            "startup_fraction_max": {
                engine: max(
                    point["startup_control_fraction"][engine]
                    for point in record["workloads"]
                )
                for engine in ("relar", "rust", "cpython", "baseline")
            },
        }
    args.output.write_text("\n".join(lines))
    metric_path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"table": str(args.output), "metrics": str(metric_path)}))


if __name__ == "__main__":
    main()
