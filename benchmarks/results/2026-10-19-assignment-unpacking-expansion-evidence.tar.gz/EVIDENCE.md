# Assignment, unpacking, and expansion evidence

Measurements use clean source commit 3cc767b401f988ece94e1eb4bb98c43cd06c02b2. `source/` is that Git tree,
excluding historical benchmark results. `retained/` holds all four current raw
families, exact old/new application sources, captured baseline workload cases,
generated LLVM, build records, test snapshots, validation logs and receipts,
and launch/audit/publication scripts.

The application family combines source and compiler/runtime changes. The
common-source family holds the old application source fixed. Each family is a
separate sequential measurement batch, so cross-family source-effect ratios
are not paired causal estimates. Each run retains all six workloads, 48 sample
rounds, two warmups, and four engines in balanced permutation order.

The portable audit checks every retained byte and recomputes saved statistics,
orders, output/filesystem oracles, and validation joins. It needs Python and
these text/source records; it does not execute native artifacts. Executables,
runtime archives, caches, toolchains, and historical raw result archives are
excluded. Their original paths/hashes and baseline publication references are
recorded. Captured baseline cases preserve the comparison's workload contract.

All 2,417 semantic checks, 92 Rust tests,
and 205 inventory ASan outcomes are reported separately. All validation uses
the measured source commit and its frozen compiler/runtime artifacts. Initial
sandbox runs aborted during LeakSanitizer process inspection; their logs are
retained alongside the successful reruns with sandbox permission. ASan covers emitted
application LLVM and the custom runtime, with leaks enabled outside ptrace;
the prebuilt Rust standard library was not rebuilt with ASan.
