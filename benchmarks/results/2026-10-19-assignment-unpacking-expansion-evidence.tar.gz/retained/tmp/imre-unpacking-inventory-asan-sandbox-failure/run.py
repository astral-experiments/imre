"""Freeze and validate the inventory example with final Imre ASan/LSan artifacts."""

import hashlib
import json
import os
import platform
import runpy
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/dev-user/code/oss/imre')
OUT = Path('/tmp/imre-unpacking-inventory-asan')
INPUTS = OUT / 'inputs'
TOOLS = ROOT / 'benchmarks/local/unpacking-tools-final'
EXPECTED_HEAD = '3cc767b401f988ece94e1eb4bb98c43cd06c02b2'
EXPECTED_COMPILER = '497bf8e34ee7ff5ebfbdd65e6e9d7c86b0045b81b3d07ec3674f0ba330c1a537'
PYTHON = Path('/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14')


def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def save(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    return path


def git(*arguments):
    return subprocess.check_output(['git', '-C', str(ROOT), *arguments], text=True).strip()


def execution():
    status = dict(line.split(':', 1) for line in Path('/proc/self/status').read_text().splitlines())
    return {
        'tracer_pid': int(status['TracerPid']),
        'affinity': sorted(os.sched_getaffinity(0)),
        'asan_options': os.environ['ASAN_OPTIONS'],
        'lsan_options': os.environ['LSAN_OPTIONS'],
        'platform': platform.platform(),
        'python': sys.version,
        'pid': os.getpid(),
    }


def main():
    started = datetime.now(timezone.utc).isoformat()
    assert git('rev-parse', 'HEAD') == EXPECTED_HEAD
    initial_status = git('status', '--porcelain')
    os.environ['ASAN_OPTIONS'] = 'detect_leaks=1:halt_on_error=1:abort_on_error=1'
    os.environ['LSAN_OPTIONS'] = 'exitcode=23:abort_on_error=1'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    context_before = execution()
    assert context_before['tracer_pid'] == 0, 'LSan must execute outside ptrace'
    assert Path('/dev/full').is_char_device()

    source_paths = sorted((ROOT / 'examples/inventory_reconciliation').rglob('*.py'))
    harness_paths = [ROOT / ('benchmarks/' + name) for name in (
        'inventory_validate.py', 'manifest_validate.py', 'batch_validate.py',
        'incremental_validate.py', 'inventory_benchmark.py',
    )]
    frozen = {}
    for path in source_paths + harness_paths:
        relative = path.relative_to(ROOT)
        expected = subprocess.check_output(['git', '-C', str(ROOT), 'show', f'{EXPECTED_HEAD}:{relative}'])
        assert path.read_bytes() == expected, f'uncommitted input: {relative}'
        destination = INPUTS / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
        frozen[str(relative)] = {'original': str(path), 'snapshot': str(destination), 'sha256': sha(path)}
        assert sha(destination) == frozen[str(relative)]['sha256']
    source_manifest = save('source-manifest.json', frozen)

    build_record_path = OUT / 'build-record.json'
    shutil.copyfile(TOOLS / 'build-record.json', build_record_path)
    build = json.loads(build_record_path.read_text())
    assert build['git_head'] == EXPECTED_HEAD
    for name, digest in build['source_sha256'].items():
        assert sha(ROOT / name) == digest, f'compiler source differs: {name}'

    clang = Path('/usr/bin/clang-18').resolve()
    tool_paths = {
        'compiler': TOOLS / 'imre',
        'runtime_asan': TOOLS / 'libimre_runtime_asan.a',
        'cpython': PYTHON.resolve(),
        'clang': clang,
        'linker': Path('/usr/bin/ld').resolve(),
        'build_record': build_record_path,
        'driver': Path(__file__).resolve(),
    }
    tools = {name: {'path': str(path), 'sha256': sha(path)} for name, path in tool_paths.items()}
    assert tools['compiler']['sha256'] == EXPECTED_COMPILER
    for name in ('compiler', 'runtime_asan'):
        path = tool_paths[name]
        assert build['sha256'][str(path.relative_to(ROOT))] == tools[name]['sha256']
    for name in ('compiler', 'cpython', 'clang', 'linker'):
        tools[name]['version'] = subprocess.check_output([str(tool_paths[name]), '--version'], text=True).strip()
    dependency_paths = set()
    for name in ('compiler', 'cpython', 'clang'):
        output = subprocess.check_output(['ldd', str(tool_paths[name])], text=True)
        (OUT / f'{name}-ldd.log').write_text(output)
        for line in output.splitlines():
            for token in line.split():
                if token.startswith('/') and Path(token).is_file():
                    dependency_paths.add(Path(token).resolve())
    dependencies = {str(path): sha(path) for path in sorted(dependency_paths)}
    tool_manifest = save('tool-manifest.json', {
        'tools': tools,
        'dynamic_libraries': dependencies,
        'runtime_asan_rustflags': build['runtime_asan_rustflags'],
        'compiled_source_sha256': build['source_sha256'],
    })

    validator = runpy.run_path(str(INPUTS / 'benchmarks/inventory_validate.py'))
    corpus = [validator['case_record'](value) for value in validator['cases']()]
    assert len(corpus) == 204
    corpus_path = save('case-corpus.json', corpus)
    binary = OUT / 'inventory_reconciliation'
    llvm = OUT / 'inventory_reconciliation.ll'
    command = [
        str(tool_paths['compiler']), 'build', str(validator['ENTRY']),
        '--module-root', str(validator['PACKAGE_ROOT']),
        '-o', str(binary), '--runtime', str(tool_paths['runtime_asan']),
        '--clang', str(clang), '--opt-level', '1', '--emit-llvm', str(llvm),
        '--target', 'x86_64-unknown-linux-gnu', '--sanitize',
    ]
    commands_path = save('commands.json', {
        'driver': [str(PYTHON), '-I', str(Path(__file__).resolve())],
        'compile': command,
        'validate': {
            'call': 'inventory_validate.validate_commands',
            'commands': {'imre_asan': [str(binary)]},
            'timeout_seconds': 120,
            'validation_only': True,
            'note': 'Direct validation-only API, as in the prior sequence sanitizer helper; no timing samples.',
        },
    })
    print('COMPILE inventory O1 with frozen compiler/runtime; TracerPid=0', flush=True)
    compilation_started = time.monotonic()
    compiled = subprocess.run(command, capture_output=True, timeout=120, check=False)
    (OUT / 'compile.stdout').write_bytes(compiled.stdout)
    (OUT / 'compile.stderr').write_bytes(compiled.stderr)
    assert compiled.returncode == 0 and not compiled.stdout and not compiled.stderr, compiled
    compile_seconds = time.monotonic() - compilation_started

    print('VALIDATE 204 independent cases plus /dev/full; ASan/LSan enabled', flush=True)
    validation_started = time.monotonic()
    validation = validator['validate_commands']({'imre_asan': [str(binary)]}, 120)
    validation_seconds = time.monotonic() - validation_started
    assert validation['cases'] == 204
    assert [record['case'] for record in validation['records']] == corpus
    for record in validation['records']:
        expected = record['expected']
        actual = record['engines']['imre_asan']
        stderr = '' if expected['error_category'] is None else (
            expected['error_category'] + ': ' + expected['error_message'] + '\n'
        )
        assert actual['stderr'] == stderr, (record['case']['label'], actual['stderr'], stderr)
    device = validation['device_check']
    assert device['case'] == 'terminal-report-device-error'
    assert device['engines']['imre_asan']['returncode'] == 1
    assert device['engines']['imre_asan']['stderr'] == 'OSError: report: cannot write\n'
    validation_path = save('validation.json', validation)

    for record in frozen.values():
        assert sha(record['original']) == sha(record['snapshot']) == record['sha256']
    for name, record in tools.items():
        assert sha(record['path']) == record['sha256'], name
    for path, digest in dependencies.items():
        assert sha(path) == digest
    for name, digest in build['source_sha256'].items():
        assert sha(ROOT / name) == digest, name
    context_after = execution()
    assert context_before == context_after
    artifacts = {name: {'path': str(path), 'sha256': sha(path)} for name, path in {
        'binary': binary, 'llvm': llvm, 'validation': validation_path,
        'source_manifest': source_manifest, 'tool_manifest': tool_manifest,
        'corpus': corpus_path, 'commands': commands_path,
        'compile_stdout': OUT / 'compile.stdout',
        'compile_stderr': OUT / 'compile.stderr',
    }.items()}
    receipt = {
        'source_commit': EXPECTED_HEAD,
        'started_at_utc': started,
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'git_status_before': initial_status,
        'git_head_after': git('rev-parse', 'HEAD'),
        'git_status_after': git('status', '--porcelain'),
        'optimization': 'O1',
        'validation_only': True,
        'execution_before': context_before,
        'execution_after': context_after,
        'input_hashes_unchanged': True,
        'source_files': len(source_paths),
        'harness_files': len(harness_paths),
        'compiler_sha256': tools['compiler']['sha256'],
        'runtime_asan_sha256': tools['runtime_asan']['sha256'],
        'runtime_asan_rustflags': build['runtime_asan_rustflags'],
        'compile_command': command,
        'compile_returncode': compiled.returncode,
        'compile_seconds': compile_seconds,
        'validation_seconds': validation_seconds,
        'cases': validation['cases'],
        'successful': validation['successful'],
        'terminal_errors': validation['terminal_errors'],
        'device_checks': 1,
        'total_native_executions': validation['cases'] + 1,
        'engine': 'imre_asan',
        'comparisons': {
            'exit_status': 'exact oracle comparison on all 205 executions',
            'stdout': 'exact bytes on all 205 executions',
            'stderr': 'exact canonical bytes, with no sanitizer diagnostics, on all 205 executions',
            'filesystem': 'all file bytes and directory names match independent oracle on all 205 executions',
        },
        'device_result': device,
        'artifacts': artifacts,
        'logs': [str(OUT / name) for name in ('run.stdout', 'run.stderr', 'compile.stdout', 'compile.stderr')],
    }
    save('receipt.json', receipt)
    print(json.dumps({key: receipt[key] for key in (
        'cases', 'successful', 'terminal_errors', 'device_checks',
        'total_native_executions', 'input_hashes_unchanged',
    )}, indent=2), flush=True)
    print('PASS: exact output/error/filesystem checks; no ASan/LSan diagnostics', flush=True)


if __name__ == '__main__':
    main()
