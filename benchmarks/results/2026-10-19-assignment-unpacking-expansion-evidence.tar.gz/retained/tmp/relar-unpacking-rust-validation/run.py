"""Capture final Rust and formatting checks against one clean source commit."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/dev-user/code/oss/relar')
OUT = Path(__file__).resolve().parent
COMMIT = sys.argv[1]

def guard():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == COMMIT
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

cargo=['sh','/tmp/relar-cargo.sh']
profile=['--config','profile.relar-integrated.inherits="release"']
focused=['tests/unpacking.py','tests/containers.py','tests/comprehensions.py','tests/fixtures/unpacking','tests/fixtures/comprehensions/unpacking.py','examples/inventory_reconciliation']
commands=[
    cargo+profile+['test','--workspace','--profile','relar-integrated','--locked'],
    cargo+['clippy']+profile+['--workspace','--all-targets','--profile','relar-integrated','--locked','--','-D','warnings'],
    cargo+['fmt','--all','--','--check'],
    ['git','diff','--check'],
    ['uvx','--no-config','--offline','ruff','check',*focused],
    ['uvx','--no-config','--offline','ruff','format','--check',*focused],
]
guard()
receipt={'source_commit':COMMIT,'started':datetime.datetime.now(datetime.UTC).isoformat(),'commands':[],'driver_sha256':sha(__file__),'cargo_wrapper_sha256':sha('/tmp/relar-cargo.sh')}
for index,command in enumerate(commands):
    started=time.monotonic(); log=OUT/f'{index}.log'
    with log.open('w') as stream:
        completed=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,'UV_TOOL_DIR':'/home/dev-user/.cache/relar/uv-tools'})
    receipt['commands'].append({'command':command,'status':completed.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log),'log_sha256':sha(log)})
    print(f'check {index}: returncode={completed.returncode}',flush=True)
    if completed.returncode:
        print(log.read_text(),flush=True)
        break
    guard()
receipt.update(status='passed' if len(receipt['commands'])==len(commands) and all(item['status']==0 for item in receipt['commands']) else 'failed',completed=datetime.datetime.now(datetime.UTC).isoformat())
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(0 if receipt['status']=='passed' else 1)
