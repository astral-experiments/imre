"""Use the tracked benchmark harness with an explicitly selected application source."""

import argparse
import importlib.util
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__, add_help=False)
    parser.add_argument("--repository", required=True, type=Path)
    parser.add_argument("--application-source-root", required=True, type=Path)
    args, remaining = parser.parse_known_args()
    script = args.repository.resolve(strict=True) / "benchmarks/inventory_benchmark.py"
    source = args.application_source_root.resolve(strict=True)
    spec = importlib.util.spec_from_file_location("inventory_comparison", script)
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    selected = {
        "PACKAGE_ROOT": source,
        "PACKAGE": source / "inventory_reconciliation",
        "ENTRY": source / "inventory_reconciliation/__main__.py",
    }
    # runpy returns a separate dictionary, while the validator's functions share
    # their original globals. Update both that dictionary and its public view.
    harness.validator.package_sources.__globals__.update(selected)
    for name, value in selected.items():
        setattr(harness.validator, name, value)
    sys.argv = [str(script), *remaining]
    harness.main()


if __name__ == "__main__":
    main()
