"""Join frozen unpacking validation receipts with the measured source tree."""

import hashlib
import json
from pathlib import Path
import re

COMMIT = "3cc767b401f988ece94e1eb4bb98c43cd06c02b2"
ROOT = Path("/home/dev-user/code/oss/relar")
TOOLS = ROOT / "benchmarks/local/unpacking-tools-final"
TESTS = Path("/tmp/relar-unpacking-tests")
RUST = Path("/tmp/relar-unpacking-rust-validation")
INVENTORY = Path("/tmp/relar-unpacking-inventory-asan")


def info(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def count(log):
    matches = re.findall(r"Passed\s+(\d+)[^\n]*checks|(\d+) import checks passed", log)
    assert matches, log
    return int(next(value for value in matches[-1] if value))


def validate(read_bytes, source_bytes):
    """Check archived receipts without executing native code."""
    retained = {}

    def read(path, expected=None):
        path = str(path)
        data = read_bytes(path)
        actual = info(data)
        assert expected is None or actual["sha256"] == expected, path
        retained[path] = actual
        return data

    def load(path, expected=None):
        return json.loads(read(path, expected))

    build = load(TOOLS / "build-record.json")
    joined = load(TESTS / "combined-summary.json")
    assert build["git_head"] == joined["source_commit"] == COMMIT
    assert build["compiled_sources_match_commit"] and not build["git_status"]
    assert joined["success"]
    artifacts = {name: item["sha256"] for name, item in build["artifacts"].items()}
    assert joined["artifact_sha256"] == artifacts
    assert joined["build_record_sha256"] == info(read(TOOLS / "build-record.json"))["sha256"]
    for name, expected in build["source_sha256"].items():
        assert info(source_bytes(name))["sha256"] == expected
        assert build["source_contents"][name].encode() == source_bytes(name)

    totals = {}
    expected_suites = {"normal": 18, "thin-lto": 7, "asan": 7}
    assert set(joined["groups"]) == set(expected_suites)
    for mode, group in joined["groups"].items():
        assert group["success"] and len(group["suites"]) == expected_suites[mode]
        assert len({suite["suite"] for suite in group["suites"]}) == len(group["suites"])
        totals[mode] = 0
        for suite in group["suites"]:
            path = Path(suite["receipt"])
            receipt = load(path, suite["receipt_sha256"])
            assert receipt["returncode"] == 0 and receipt["mode"] == mode
            assert receipt["source_commit"] == COMMIT
            assert count(receipt["stdout"]) == suite["checks"] == receipt["checks"]
            assert read(path.with_suffix(".stdout.log")).decode() == receipt["stdout"]
            assert read(path.with_suffix(".stderr.log")).decode() == receipt["stderr"] == ""
            manifest = load(path.parent / "manifest.json", receipt["manifest_sha256"])
            summary = load(path.parent / "summary.json")
            assert summary["success"] and summary["inputs_unchanged"]
            assert summary["inputs_after"] == manifest["inputs"]
            assert manifest["source_commit"] == COMMIT
            if mode == "asan":
                assert manifest["tracer_pid"] == "0"
                assert manifest["environment"]["ASAN_OPTIONS"] == "detect_leaks=1:halt_on_error=1"
                assert manifest["environment"]["LSAN_OPTIONS"] == "exitcode=23"
                assert "--sanitize" in receipt["command"]
            runtime = {"normal": "librelar_runtime.a", "thin-lto": "librelar_runtime_lto.a", "asan": "librelar_runtime_asan.a"}[mode]
            for flag, name in (("--compiler", "relar"), ("--runtime", runtime)):
                artifact = receipt["command"][receipt["command"].index(flag) + 1]
                assert manifest["inputs"][artifact] == artifacts[name]
            for name, expected in manifest["inputs"].items():
                value = Path(name)
                if value.is_relative_to(TESTS):
                    read(value, expected)
                    if value.is_relative_to(TESTS / "source"):
                        relative = str(value.relative_to(TESTS / "source"))
                        assert expected == info(source_bytes(relative))["sha256"], relative
            totals[mode] += suite["checks"]
        assert totals[mode] == group["total_checks"]
    assert totals == joined["native_checks"]

    rust = load(RUST / "receipt.json")
    assert rust["status"] == "passed" and rust["source_commit"] == COMMIT
    rust_count = 0
    for command in rust["commands"]:
        assert command["status"] == 0
        log = read(command["log"], command["log_sha256"]).decode()
        rust_count += sum(map(int, re.findall(r"test result: ok\. (\d+) passed; 0 failed;", log)))
    assert rust_count > 0

    inventory = load(INVENTORY / "receipt.json")
    assert inventory["source_commit"] == inventory["git_head_after"] == COMMIT
    assert not inventory["git_status_before"] and not inventory["git_status_after"]
    assert inventory["input_hashes_unchanged"] and inventory["compile_returncode"] == 0
    assert inventory["cases"] == 204 and inventory["device_checks"] == 1
    assert inventory["total_native_executions"] == 205
    assert inventory["compiler_sha256"] == artifacts["relar"]
    assert inventory["runtime_asan_sha256"] == artifacts["librelar_runtime_asan.a"]
    assert inventory["runtime_asan_rustflags"] == build["runtime_asan_rustflags"]
    for when in ("before", "after"):
        execution = inventory["execution_" + when]
        assert execution["tracer_pid"] == 0 and "detect_leaks=1" in execution["asan_options"]
        assert "exitcode=23" in execution["lsan_options"]
    for name, item in inventory["artifacts"].items():
        if name != "binary":
            read(item["path"], item["sha256"])
    for name, item in load(INVENTORY / "source-manifest.json").items():
        read(item["snapshot"], item["sha256"])
        assert info(source_bytes(name))["sha256"] == item["sha256"]

    sandbox = load(TESTS / "sanitizer-sandbox-failure.json")
    for name, expected in sandbox["preserved"].items():
        read(name, expected)
    assert "LeakSanitizer" in read(INVENTORY.with_name(INVENTORY.name + "-sandbox-failure") / "run.stderr").decode()

    return {
        "schema": "relar-unpacking-validation-v1",
        "status": "passed",
        "source_commit": COMMIT,
        "build_record_sha256": info(read(TOOLS / "build-record.json"))["sha256"],
        "native_checks": totals,
        "total_native_semantic_checks": sum(totals.values()),
        "rust_unit_tests": rust_count,
        "inventory_asan": {"cases": 204, "device_checks": 1, "native_executions": 205, "receipt": str(INVENTORY / "receipt.json")},
        "combined_receipt": str(TESTS / "combined-summary.json"),
        "retained_sandbox_failure": str(TESTS / "sanitizer-sandbox-failure.json"),
        "retained_evidence_files": retained,
        "sanitizer_limit": "Application LLVM and the custom runtime were instrumented; leak checking was enabled outside ptrace. The prebuilt Rust standard library was not rebuilt with sanitizer instrumentation.",
        "scope": "Semantic checks include accepted programs, expected errors, and compile-time rejections; Rust unit tests and inventory ASan outcomes are separate. Native artifact identities are joined through recorded hashes; native bytes are external to the text/source archive.",
    }
