"""Join the three final semantic test groups with the frozen build identity."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
TOOLS=Path('/home/dev-user/code/oss/relar/benchmarks/local/unpacking-tools-final')
def load(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
build=load(TOOLS/'build-record.json')
combined={'source_commit':build['git_head'],'success':True,'build_record_sha256':sha(TOOLS/'build-record.json'),'artifact_sha256':{name:item['sha256'] for name,item in build['artifacts'].items()},'groups':{},'native_checks':{}}
for mode,expected in [('normal',18),('thin-lto',7),('asan',7)]:
    summary=load(ROOT/mode/'summary.json')
    assert summary['success'] and summary['source_commit']==build['git_head']
    assert len(summary['results'])==expected
    suites=[]
    for row in summary['results']:
        path=ROOT/mode/(row['suite']+'.json'); receipt=load(path)
        assert receipt['returncode']==0 and receipt['checks'] is not None
        suites.append({'suite':row['suite'],'receipt':str(path),'receipt_sha256':sha(path),'source_commit':receipt['source_commit'],'checks':receipt['checks']})
    total=sum(row['checks'] for row in suites)
    assert total==summary['total_checks']
    combined['groups'][mode]={'success':True,'suites':suites,'total_checks':total}
    combined['native_checks'][mode]=total
(ROOT/'combined-summary.json').write_text(json.dumps(combined,indent=2)+'\n')
print(combined['native_checks'])
