import json
from pathlib import Path

HERE = Path(__file__).parent
PREFIX = "2026-10-19-assignment-unpacking-expansion"
audit = json.loads(Path("/tmp/imre-unpacking-independent-audit/audit.json").read_text())
assert audit["passed"]
families = audit["families"]


def application_table(mode):
    lines = [
        "| Input | CPython ms | Previous Imre ms | Current Imre ms | Rust BigInt ms | Imre time change |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in families[f"application-{mode}"]["rows"]:
        times = row["median_ms"]
        cells = [row["workload"]]
        cells += [f"{times[engine]:.3f}" for engine in ("cpython", "baseline", "imre", "rust_bigint")]
        cells += [f'{row["new_vs_baseline_time_change_percent"]:+.2f}%']
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def common_table():
    lines = [
        "| Input | Ordinary previous ms | Ordinary current ms | Change | ThinLTO previous ms | ThinLTO current ms | Change |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    ordinary = families["common-source-normal"]["rows"]
    thin_lto = families["common-source-lto"]["rows"]
    for normal, lto in zip(ordinary, thin_lto, strict=True):
        assert normal["workload"] == lto["workload"]
        cells = [normal["workload"]]
        for row in (normal, lto):
            cells += [f'{row["median_ms"][engine]:.3f}' for engine in ("baseline", "imre")]
            cells += [f'{row["new_vs_baseline_time_change_percent"]:+.2f}%']
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


from datetime import datetime
import runpy
COMMIT = runpy.run_path(str(HERE / "evidence_validation.py"))["COMMIT"]

validation = json.loads((HERE / 'validation.json').read_text())
session = json.loads(Path('/home/dev-user/code/oss/imre/benchmarks/local/unpacking-comparison-final/session.json').read_text())
large = families['application-lto']['rows'][-2:]
assert [row['workload'] for row in large] == ['dense-16384', 'sparse-16384']
dense, sparse = large
normal_dense, normal_sparse = families['application-normal']['rows'][-2:]
common = [row for mode in ('normal', 'lto') for row in families[f'common-source-{mode}']['rows']]
changes = [row['new_vs_baseline_time_change_percent'] for row in common]
nonoverlap = [row for row in common if not row['iqr_overlap_vs_previous']]
control_note = ('Every current/preserved Imre interquartile range overlaps.' if not nonoverlap else f'{len(nonoverlap)} of the twelve current/preserved Imre interquartile-range pairs do not overlap.')
start = datetime.fromisoformat(session['started_at_utc']).strftime('%H:%M:%S')
end = datetime.fromisoformat(session['completed_at_utc']).strftime('%H:%M:%S')
checks = validation['native_checks']

report = f'''# Chained assignment, sequence unpacking, and container expansion

Imre now supports chained assignment, nested and starred sequence unpacking, and typed list/set/dictionary expansion. The inventory reconciler uses all three while preserving its input, error, and report behavior. On the two large workloads, ThinLTO Imre runs **{dense['cpython_speedup']:.2f}× faster than CPython for dense input and {sparse['cpython_speedup']:.2f}× for sparse input**. Its median time relative to Rust BigInt is **{dense['rust_gap_percent']:+.1f}% and {sparse['rust_gap_percent']:+.1f}%**, respectively; a positive value means Imre takes more time.

The [compiler implementation](https://github.com/viarius-experiments/imre/pull/45) continues GitHub Stack 4 after the [truthiness and loop-else milestone](2026-10-19-truthiness-loop-else.md). Measurements and final validation use clean source commit `{COMMIT}`. Results and the README refresh are committed afterward.

## Capability and application

- **Chained assignment:** the RHS evaluates once; targets store from left to right and retain shared mutable identity. Declared targets can provide context for empty literals.
- **Sequence unpacking:** fixed tuples, lists, strings, and bytes support nested patterns and one starred target per level. Targets include names, fields, and list/dictionary subscripts, including in container loops and comprehensions. Each level snapshots its values before storing targets; later nested failures preserve earlier stores. Dynamic length failures raise `ValueError`. Starred remainders are fresh shallow lists with concrete element layouts.
- **Container expansion:** list/set `*source` uses existing typed iteration sources, including dictionary keys, strings, bytes, range/enumerate, and compatible fixed tuples. Dictionary `**source` copies concrete mappings in order. Each expansion completes before the next entry evaluates; duplicate keys retain their original position while the last value wins.

Exact storage types remain enforced. Fixed-tuple arity errors stay static, and tuple result expansion, call argument expansion, variadic parameters, and user-defined iterator protocols remain outside this milestone. The [language contract](../../docs/subset.md#assignment-and-container-expansion) details context, aliases, constructors, and remaining boundaries.

The inventory entry point unpacks `sys.argv` with a starred remainder and checks the three paths through sequence unpacking. The parser unpacks count and SKU/quantity rows while retaining the previous diagnostics and conversion order. Reconciliation expands requested dictionary keys into a membership set; rendering initializes three totals with chained assignment. Rust retains its existing eager algorithm, arbitrary-precision quantities, source, and executables.

The compiler reuses existing typed primitives and scoped IR. Tuple scalarization and integer range analysis now account for expression-scope writes and cleanup, including short-circuit joins and while conditions. These changes preserve the existing concrete storage and native index optimizations. Runtime sources and the private ABI are unchanged.

## Updated-application comparisons

CPython and current Imre run the updated application. Preserved Imre runs the previous application because its compiler cannot accept the new syntax. These comparisons combine the compiler change and application rewrite. Times are median milliseconds; positive time change means more time than preserved Imre.

**Ordinary linking**

{application_table('normal')}

**ThinLTO**

{application_table('lto')}

The large ordinary-linking medians take {normal_dense['new_vs_baseline_time_change_percent']:+.2f}% and {normal_sparse['new_vs_baseline_time_change_percent']:+.2f}% more time than preserved Imre. The corresponding ThinLTO changes are {dense['new_vs_baseline_time_change_percent']:+.2f}% and {sparse['new_vs_baseline_time_change_percent']:+.2f}%. Both ordinary sparse workloads have nonoverlapping current/previous interquartile ranges; all six ThinLTO application pairs overlap. This is a compatibility milestone with a modest ordinary-linking regression, not a native speedup claim.

These are complete-program measurements, not isolated unpacking costs. Small cases include substantial process startup and small-file overhead. No new CPU or allocation profiles were collected.

## Unchanged-application controls

Current and preserved Imre also run the exact previous six-file application, with CPython and unchanged Rust participating in the same balanced rounds. This holds application source fixed for the compiler comparison.

{common_table()}

Across these twelve comparisons, median changes range from **{min(changes):+.2f}% to {max(changes):+.2f}%**. {control_note} Interquartile ranges describe sample spread; they are not confidence intervals or proof of equivalent performance. Application and unchanged-source families ran as separate sequential batches, so subtracting their changes would not establish a causal source-only effect. The [summary]({PREFIX}-summary.json) retains all four engines' statistics and exact quantiles in every family.

## Method and provenance

The complete session ran on October 19, 2026, from {start} to {end} UTC. Four families each use six workloads, 48 measured rounds covering all 24 engine permutations twice, and two warmup rounds: **4,608 measured executions, 192 warmups, and 96 workload gates**. Measured execution positions and directed within-round predecessors are balanced. Warmups, cross-round predecessors, and workload order are not balanced.

Before timing, every family checks the independent 204-case oracle and `/dev/full` on all four engines: **3,264 oracle outcomes and 16 device-error outcomes**. Every timed run and warmup checks exit status, stdout/stderr, complete report bytes, and filesystem effects. Clean source, frozen tools, preserved references, and CPython bytecode caches are verified before and after the session.

Fresh processes run on CPU 0 outside the execution sandbox. Timing includes startup/imports, file reading/decoding/parsing, reconciliation, rendering, buffered writes, flush/close, and exit. Builds, fixture preparation, oracles, hashing, verification, and deletion stay outside the clock. OS caches are warm; writes are not fsynced. All task-owned builds, tests, and profiling stop during timing. CPU frequency and unrelated activity on the shared host remain uncontrolled.

CPython is 3.14.5. Imre uses Clang 18 at `-O3`, with the pinned Rust toolchain's LLD for cross-language ThinLTO and matched LLVM optimization budgets. Rust uses native containers, borrowed strings, direct formatting, and arbitrary-precision integers. The raw records retain exact tool versions, configurations, source hashes, and environment details. These results apply to this program and recorded environment.

## Validation and evidence

All **{validation['total_native_semantic_checks']:,} semantic/regression checks** pass: **{checks['normal']:,} ordinary checks** across all 18 suites, **{checks['thin-lto']} targeted ThinLTO checks**, and **{checks['asan']} targeted ASan/LSan checks**. Counts include static rejections. Targeted suites cover unpacking/expansion, assignment expressions, comprehensions, containers, classes, exceptions, and files. The source also passes **{validation['rust_unit_tests']} Rust unit tests**, Clippy with warnings denied, formatting, and focused Ruff checks.

The inventory separately passes **204 oracle cases and `/dev/full`** under O1 ASan/LSan, with leak detection enabled and no diagnostics. Initial sandboxed sanitizer attempts aborted during LeakSanitizer process inspection; unchanged inputs passed with sandbox permission, and both failed-attempt logs and successful receipts are retained. Sanitizers cover generated application code and the custom runtime; the prebuilt Rust standard library remains uninstrumented.

Imre's existing exception model has no traceback/frame references. Exited frames release their owners during propagation, so implicit file closure can precede CPython's release of traceback-held locals. This preexisting boundary is documented in the subset guide; explicit `with` and `close` provide deterministic file handling.

The [independent audit]({PREFIX}-audit.json) passed **{audit['checks']:,} checks** over raw integer-nanosecond samples, exact quantiles, order, outcomes, source-family separation, and provenance. The [build record]({PREFIX}-build.json), [session]({PREFIX}-session.json), and [validation index]({PREFIX}-validation.json) connect the final results to the measured source and frozen artifacts.

Original records are available for [application/ordinary]({PREFIX}-application-normal.json.gz), [application/ThinLTO]({PREFIX}-application-lto.json.gz), [unchanged-source/ordinary]({PREFIX}-common-source-normal.json.gz), and [unchanged-source/ThinLTO]({PREFIX}-common-source-lto.json.gz). The [evidence archive]({PREFIX}-evidence.tar.gz) and [manifest]({PREFIX}-evidence-manifest.json) retain source, generated LLVM, logs, raw records, and reproduction/audit scripts. Native executables, runtime archives, interpreters, toolchains, and bytecode caches remain external and are identified by hashes. The [portable audit]({PREFIX}-portable-audit.json) verifies the retained text/source evidence without executing native artifacts.
'''
(HERE / 'report.md').write_text(report)
