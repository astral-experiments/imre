"""Print, validate, or run the application and common-source inventory comparisons."""

import argparse
import hashlib
import importlib.util
import json
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/home/dev-user/code/oss/imre")
HERE = Path(__file__).resolve().parent
MANIFEST = HERE / "prepared-manifest.json"
WRAPPER = HERE / "run_comparison.py"
SPEC = importlib.util.spec_from_file_location(
    "earlier_launcher", ROOT / "benchmarks/local/sequence-access-final-launch.py"
)
PRIOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PRIOR)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def source_hashes(source):
    return {str(path.relative_to(source)): sha(path)
            for path in sorted((source / "inventory_reconciliation").rglob("*.py"))}


def preserved_guard(prepared):
    protected = dict(prepared["preserved_tools"])
    for value in prepared["modes"].values():
        protected.update({path: value["sha256"][name]
                          for name, path in value["paths"].items()})
        for key in ("comparison", "published", "rust_build_record"):
            protected[value[key]] = value[key + "_sha256"]
        for name, expected in value["rust_sources"].items():
            protected[str(ROOT / "benchmarks/reference/inventory_reconciliation" / name)] = expected
    actual = {name: sha(name) for name in protected}
    if actual != protected:
        raise RuntimeError("preserved baseline, tool, or reference input changed")
    snapshots = {}
    for kind in ("baseline_source", "application_source"):
        value = prepared[kind]
        snapshots[kind] = source_hashes(Path(value["root"]))
        if snapshots[kind] != value["sources"]:
            raise RuntimeError("source snapshot changed: " + kind)
    if source_hashes(ROOT / "examples") != prepared["application_source"]["sources"]:
        raise RuntimeError("current application differs from the prepared source")
    return {"sha256": actual, "snapshots": snapshots}


def current_guard(tools, expected_head):
    result = PRIOR.clean_sources(tools, expected_head)
    record = json.loads((tools / "build-record.json").read_text())
    artifacts = {}
    for name in ("imre", "libimre_runtime.a", "libimre_runtime_lto.a"):
        digest = sha(tools / name)
        if not any(Path(path).name == name and expected == digest
                   for path, expected in record["sha256"].items()):
            raise RuntimeError("current frozen artifact differs from its build record")
        artifacts[name] = digest
    return {**result, "artifact_sha256": artifacts}


def commands_for(prepared, tools, output_dir, validate_only):
    commands = {}
    for mode in ("normal", "lto"):
        preserved = prepared["modes"][mode]
        paths = preserved["paths"]
        for family in ("application", "common-source"):
            name = family + "-" + mode
            source = (ROOT / "examples" if family == "application"
                      else Path(prepared["baseline_source"]["root"]))
            command = [
                sys.executable, "-u", str(WRAPPER), "--repository", str(ROOT),
                "--application-source-root", str(source),
                "--compiler", str(tools / "imre"),
                "--runtime", str(tools / ("libimre_runtime_lto.a" if mode == "lto" else "libimre_runtime.a")),
                "--imre-build-record", str(tools / "build-record.json"),
                "--rust-bigint", paths["rust_bigint"],
                "--rust-build-record", preserved["rust_build_record"],
                "--inventory-baseline", paths["inventory_binary"],
                "--inventory-baseline-record", preserved["comparison"],
                "--inventory-baseline-source-root", prepared["baseline_source"]["root"],
                "--python", paths["python"], "--clang", paths["clang"],
                "--target", "x86_64-unknown-linux-gnu", "--cpu", "0",
                "--samples", "48", "--warmups", "2",
                "--artifact-dir", str(output_dir / name),
                "--output", str(output_dir / (name + ".json")),
            ]
            if mode == "lto":
                command += ["--lto-linker", paths["lto_linker"]]
            if validate_only:
                command.append("--validate-only")
            commands[name] = command
    return commands


def cache_state(python, prepared):
    return {
        name: json.loads(subprocess.check_output(
            [python, "-I", "-c", PRIOR.CACHE_PROBE, str(source / "inventory_reconciliation")],
            cwd=ROOT, text=True,
        ))
        for name, source in (("current", ROOT / "examples"),
                             ("baseline", Path(prepared["baseline_source"]["root"])))
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tools", required=True, type=Path)
    parser.add_argument("--expected-head")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--execute", action="store_true",
                        help="run only after the parent authorizes this frozen session")
    args = parser.parse_args()
    prepared = json.loads(MANIFEST.read_text())
    tools, output_dir = args.tools.resolve(), args.output_dir.resolve()
    commands = commands_for(prepared, tools, output_dir, args.validate_only)
    if not args.execute:
        for name, command in commands.items():
            print(name + ":\n" + shlex.join(command) + "\n")
        return
    if (args.expected_head is None or len(args.expected_head) != 40
            or any(character not in "0123456789abcdef" for character in args.expected_head)):
        parser.error("--execute requires the full expected source commit")
    if output_dir.exists():
        raise RuntimeError("output directory must be new; preserve all earlier evidence")
    source_before = current_guard(tools, args.expected_head)
    preserved_before = preserved_guard(prepared)
    scripts = {str(path): sha(path) for path in (Path(__file__), WRAPPER, MANIFEST, Path(PRIOR.__file__))}
    python = prepared["modes"]["normal"]["paths"]["python"]
    preparation = [python, "-I", "-m", "compileall", "-q",
                   str(ROOT / "examples/inventory_reconciliation"),
                   str(Path(prepared["baseline_source"]["root"]) / "inventory_reconciliation")]
    subprocess.run(preparation, cwd=ROOT, check=True)
    bytecode_before = cache_state(python, prepared)
    output_dir.mkdir(parents=True)
    session_path = output_dir / "session.json"
    session = {
        "source_commit": args.expected_head,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "validation_only": args.validate_only,
        "source_guard_before": source_before,
        "preserved_guard_before": preserved_before,
        "scripts": scripts,
        "comparison_families": {
            "application": "CPython/current Imre run the rewritten source; preserved Imre runs the verified old source; Rust source is unchanged. Application and compiler effects are combined.",
            "common-source": "CPython/current Imre/preserved Imre run the verified old source; Rust source is unchanged. Current/preserved Imre compares compiler/runtime changes with application source fixed.",
        },
        "cache_preparation": {"command": preparation, "timed": False},
        "bytecode_before": bytecode_before,
        "runs": {},
    }

    def save():
        session_path.write_text(json.dumps(session, indent=2) + "\n")

    def guard():
        if current_guard(tools, args.expected_head) != source_before:
            raise RuntimeError("current frozen sources/tools changed")
        if preserved_guard(prepared) != preserved_before:
            raise RuntimeError("preserved inputs changed")
        if {name: sha(name) for name in scripts} != scripts:
            raise RuntimeError("launcher, wrapper, or prepared manifest changed")
        if cache_state(python, prepared) != bytecode_before:
            raise RuntimeError("CPython bytecode cache changed")

    save()
    for name, command in commands.items():
        guard()
        item = {"command": command, "started_at_utc": datetime.now(timezone.utc).isoformat()}
        session["runs"][name] = item
        save()
        print("Starting " + name, flush=True)
        log_path = output_dir / (name + ".log")
        with log_path.open("w") as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        item.update(returncode=result.returncode,
                    completed_at_utc=datetime.now(timezone.utc).isoformat(),
                    log_sha256=sha(log_path))
        record_path = output_dir / (name + ".json")
        if record_path.exists():
            item["record_sha256"] = sha(record_path)
        save()
        print(log_path.read_text(), end="", flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
        guard()
    session.update(completed_at_utc=datetime.now(timezone.utc).isoformat(),
                   source_guard_after=current_guard(tools, args.expected_head),
                   preserved_guard_after=preserved_guard(prepared),
                   bytecode_after=cache_state(python, prepared))
    save()
    print("Saved " + str(session_path), flush=True)


if __name__ == "__main__":
    main()
