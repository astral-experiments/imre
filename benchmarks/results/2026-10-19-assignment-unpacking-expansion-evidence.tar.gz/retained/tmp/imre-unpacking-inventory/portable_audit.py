"""Audit the published unpacking text evidence without native artifacts.

Archive validation follows the preceding portable audit. Outcome, order and
Fraction-statistics checks reuse the retained independent audit helpers.
"""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import runpy
import tarfile
import tempfile
from types import SimpleNamespace

PREFIX = "2026-10-19-assignment-unpacking-expansion"
COMMIT = "3cc767b401f988ece94e1eb4bb98c43cd06c02b2"
ROOT = Path("/home/dev-user/code/oss/imre")
HERE = Path("/tmp/imre-unpacking-inventory")
AUDIT = Path("/tmp/imre-unpacking-independent-audit")
RUNS = ROOT / "benchmarks/local/unpacking-comparison-final"
FAMILIES = (
    "application-normal",
    "common-source-normal",
    "application-lto",
    "common-source-lto",
)
ENGINES = ("cpython", "imre", "rust_bigint", "baseline")


def info(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def enrich(rows, record, helper):
    """Reproduce the independent audit's exact quantiles and derived columns."""
    for row, workload in zip(rows, record["workloads"]["inventory"], strict=True):
        exact = {
            engine: {
                key: helper.quantile(
                    [sample[engine]["elapsed_ns"] for sample in workload["samples"]],
                    n,
                    d,
                )
                for key, n, d in (
                    ("p25_ns", 1, 4),
                    ("median_ns", 1, 2),
                    ("p75_ns", 3, 4),
                )
            }
            for engine in ENGINES
        }
        row["exact_quantiles_ns"] = {
            engine: {
                key: {"numerator": value.numerator, "denominator": value.denominator}
                for key, value in values.items()
            }
            for engine, values in exact.items()
        }
        for numerator in ENGINES:
            for denominator in ENGINES:
                if numerator != denominator:
                    helper.close(
                        row["ratios_of_medians"][numerator + "_over_" + denominator],
                        float(
                            exact[numerator]["median_ns"]
                            / exact[denominator]["median_ns"]
                        ),
                        "exact ratio",
                    )
        row["cpython_speedup"] = row["ratios_of_medians"]["cpython_over_imre"]
        row["rust_gap_percent"] = 100 * (
            row["ratios_of_medians"]["imre_over_rust_bigint"] - 1
        )
        stats = row["statistics"]
        for label, engine in (("previous", "baseline"), ("rust", "rust_bigint")):
            row["iqr_overlap_vs_" + label] = max(
                stats["imre"]["p25_ns"], stats[engine]["p25_ns"]
            ) <= min(stats["imre"]["p75_ns"], stats[engine]["p75_ns"])
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    directory = args.directory.resolve()
    manifest_bytes = (directory / (PREFIX + "-evidence-manifest.json")).read_bytes()
    manifest = json.loads(manifest_bytes)
    assert manifest["source_commit"] == COMMIT
    for name, expected in manifest["companions"].items():
        data = (directory / name).read_bytes()
        assert info(data) == {key: expected[key] for key in ("sha256", "bytes")}, name
        if name.endswith(".gz"):
            assert (
                data[:3] == b"\x1f\x8b\x08" and int.from_bytes(data[4:8], "little") == 0
            )
        if "uncompressed" in expected:
            assert info(gzip.decompress(data)) == expected["uncompressed"]
    archive_data = (directory / (PREFIX + "-evidence.tar.gz")).read_bytes()
    members = {}
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode="r:gz") as archive:
        for item in archive:
            assert item.isfile() and not Path(item.name).is_absolute()
            assert ".." not in Path(item.name).parts and item.name not in members
            assert item.mtime == item.uid == item.gid == 0 and item.mode == 0o644
            assert not {"__pycache__", "target", ".git", ".cache"}.intersection(
                Path(item.name).parts
            )
            data = archive.extractfile(item).read()
            data.decode("utf-8")
            assert not data.startswith((b"\x7fELF", b"!<arch>\n", b"BC\xc0\xde"))
            assert Path(item.name).suffix not in {
                ".a",
                ".o",
                ".so",
                ".rlib",
                ".bc",
                ".exe",
                ".pyc",
            }
            members[item.name] = data
    assert set(members) == {*manifest["members"], "manifest.json"}
    assert info(members["manifest.json"]) == manifest["archive_manifest"]
    inner = json.loads(members["manifest.json"])
    assert inner["source_commit"] == COMMIT and inner["members"] == manifest["members"]
    by_source = {}
    for name, expected in manifest["members"].items():
        assert info(members[name]) == {
            key: expected[key] for key in ("sha256", "bytes")
        }
        if expected["source"] in by_source:
            assert by_source[expected["source"]] == members[name]
        by_source[expected["source"]] = members[name]

    def retained(path):
        return by_source[str(path)]

    def load(path):
        return json.loads(retained(path))

    def published(suffix):
        return json.loads((directory / (PREFIX + "-" + suffix)).read_text())

    build, session, summary = (
        published("build.json"),
        published("session.json"),
        published("summary.json"),
    )
    independent, validation = published("audit.json"), published("validation.json")
    assert (
        build["git_head"]
        == session["source_commit"]
        == summary["source_commit"]
        == validation["source_commit"]
        == COMMIT
    )
    assert build["compiled_sources_match_commit"] and not build["git_status"]
    assert (
        independent["passed"] and summary["status"] == validation["status"] == "passed"
    )
    assert (
        summary["independent_audit_sha256"]
        == info((directory / (PREFIX + "-audit.json")).read_bytes())["sha256"]
    )
    assert (
        summary["validation_sha256"]
        == info((directory / (PREFIX + "-validation.json")).read_bytes())["sha256"]
    )
    for suffix, path in (
        (
            "build.json",
            ROOT / "benchmarks/local/unpacking-tools-final/build-record.json",
        ),
        ("session.json", RUNS / "session.json"),
        ("audit.json", AUDIT / "audit.json"),
        ("summary.json", HERE / "summary.json"),
        ("validation.json", HERE / "validation.json"),
    ):
        assert (directory / (PREFIX + "-" + suffix)).read_bytes() == retained(path)
    assert (directory / (PREFIX + ".md")).read_bytes() == retained(HERE / "report.md")
    assert session["source_guard_before"] == session["source_guard_after"]
    assert session["preserved_guard_before"] == session["preserved_guard_after"]
    assert session["bytecode_before"] == session["bytecode_after"]
    assert list(session["runs"]) == list(FAMILIES)
    for path, expected in session["scripts"].items():
        assert info(retained(path))["sha256"] == expected
    assert (
        info(retained(AUDIT / "audit.py"))["sha256"]
        == independent["audit_script_sha256"]
    )
    assert (
        info(retained(AUDIT / "reused_helpers.py"))["sha256"]
        == independent["reused_helper_sha256"]
    )
    prepared = load(HERE / "prepared-manifest.json")
    baseline = load(HERE / "baseline-manifest.json")
    recomputed = {}
    with tempfile.TemporaryDirectory(prefix="imre-unpacking-portable-") as temporary:
        root = Path(temporary)
        for name, data in members.items():
            if name.startswith("source/"):
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        helper_path, join_path = (
            root / "reused_helpers.py",
            root / "evidence_validation.py",
        )
        helper_path.write_bytes(retained(AUDIT / "reused_helpers.py"))
        join_path.write_bytes(retained(HERE / "evidence_validation.py"))
        helper = SimpleNamespace(**runpy.run_path(str(helper_path)))
        join = runpy.run_path(str(join_path))["validate"]
        assert join(retained, lambda name: members["source/" + name]) == validation
        validator = runpy.run_path(
            str(root / "source/benchmarks/inventory_validate.py")
        )
        totals = {
            key: 0
            for key in (
                "measured_process_runs",
                "warmup_process_runs",
                "inventory_gate_runs",
                "oracle_process_results",
                "device_process_results",
            )
        }
        last = session["started_at_utc"]
        for name in FAMILIES:
            raw = gzip.decompress(
                (directory / (PREFIX + "-" + name + ".json.gz")).read_bytes()
            )
            assert raw == retained(RUNS / (name + ".json"))
            run = session["runs"][name]
            assert (
                run["returncode"] == 0 and info(raw)["sha256"] == run["record_sha256"]
            )
            assert info(retained(RUNS / (name + ".log")))["sha256"] == run["log_sha256"]
            assert last <= run["started_at_utc"] <= run["completed_at_utc"]
            last = run["completed_at_utc"]
            record = json.loads(raw)
            family, mode = name.rsplit("-", 1)
            assert record["git"] == {"revision": COMMIT, "dirty": False}
            assert record["host"]["cpu"]["affinity"] == [0]
            assert (
                record["options"]["samples"] == 48 and record["options"]["warmups"] == 2
            )
            assert all(item["tracer_pid"] == 0 for item in record["execution"].values())
            assert record["sha256"]["compiler"] == build["artifacts"]["imre"]["sha256"]
            runtime = "libimre_runtime_lto.a" if mode == "lto" else "libimre_runtime.a"
            assert record["sha256"]["runtime"] == build["artifacts"][runtime]["sha256"]
            selected = prepared[
                "application_source" if family == "application" else "baseline_source"
            ]
            assert (
                record["sources"] == selected["sources"] and len(record["sources"]) == 6
            )
            for relative, expected in record["sources"].items():
                data = (
                    members["source/examples/" + relative]
                    if family == "application"
                    else retained(Path(selected["root"]) / relative)
                )
                assert info(data)["sha256"] == expected
            for relative, expected in record["rust_sources"].items():
                assert (
                    info(
                        members[
                            "source/benchmarks/reference/inventory_reconciliation/"
                            + relative
                        ]
                    )["sha256"]
                    == expected
                )
            for key, expected in record["sha256"].items():
                if key.startswith("harness:"):
                    assert (
                        info(members["source/benchmarks/" + key.split(":", 1)[1]])[
                            "sha256"
                        ]
                        == expected
                    )
                elif key.startswith("imre_source:"):
                    assert (
                        info(members["source/" + key.split(":", 1)[1]])["sha256"]
                        == expected
                    )
            cc = record["method"]["compile_commands"]["inventory"]
            assert (
                info(retained(cc[cc.index("--emit-llvm") + 1]))["sha256"]
                == record["sha256"]["inventory_ir"]
            )
            prior = baseline["modes"][mode]
            assert (
                info(retained(prior["tool_paths"]["inventory_ir"]))["sha256"]
                == prior["sha256"]["inventory_ir"]
            )
            outcome = helper.correctness(record, validator, ENGINES)
            rows, ordering, measured, warmups, gates = helper.audit_workloads(
                record, prior, validator, ENGINES, "imre"
            )
            rows = enrich(rows, record, helper)
            saved = independent["families"][name]
            assert rows == saved["rows"] and ordering == saved["ordering"]
            assert saved == summary["families"][name]
            assert saved["record_sha256"] == info(raw)["sha256"]
            assert saved["validation_process_results"] == outcome
            assert (
                saved["measured_process_runs"],
                saved["warmup_process_runs"],
                saved["inventory_gate_runs"],
            ) == (measured, warmups, gates)
            totals["measured_process_runs"] += measured
            totals["warmup_process_runs"] += warmups
            totals["inventory_gate_runs"] += gates
            totals["oracle_process_results"] += outcome["inventory"]
            totals["device_process_results"] += outcome["inventory_device"]
            recomputed[name] = {
                "workloads": len(rows),
                "measured": measured,
                "warmups": warmups,
                "gates": gates,
                "oracle_outcomes": outcome,
            }
        assert last <= session["completed_at_utc"]
        assert (
            totals
            == independent["totals"]
            == summary["totals"]
            == {
                "measured_process_runs": 4608,
                "warmup_process_runs": 192,
                "inventory_gate_runs": 96,
                "oracle_process_results": 3264,
                "device_process_results": 16,
            }
        )
        inventory = load("/tmp/imre-unpacking-inventory-asan/validation.json")
        asan = helper.correctness(
            {"validation": {"inventory": inventory}}, validator, ("imre_asan",)
        )
        assert asan == {"inventory": 204, "inventory_device": 1}
    result = {
        "status": "passed",
        "source_commit": COMMIT,
        "archive_members": len(members),
        "companions": len(manifest["companions"]),
        "totals_recomputed": totals,
        "inventory_asan_outcomes_recomputed": asan,
        "native_semantic_checks_joined": validation["total_native_semantic_checks"],
        "rust_unit_tests_joined": validation["rust_unit_tests"],
        "recomputed": recomputed,
        "archive_sha256": info(archive_data)["sha256"],
        "manifest_sha256": info(manifest_bytes)["sha256"],
        "script_sha256": info(Path(__file__).read_bytes())["sha256"],
        "note": "Only retained text/source records were read. Native artifacts, caches and historical raw benchmark archives remain external; their recorded provenance is joined without re-executing native work or recovering external bytes from hashes.",
    }
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {key: value for key, value in result.items() if key != "recomputed"},
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
