"""Package completed unpacking evidence; never compile or execute native work.

The deterministic text-only archive helpers follow the preceding control-flow
publication script. Validation joins are shared with the portable audit.
"""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from evidence_validation import COMMIT, INVENTORY, RUST, TESTS, validate

ROOT = Path("/home/dev-user/code/oss/imre")
LOCAL = ROOT / "benchmarks/local"
HERE = Path(__file__).resolve().parent
TOOLS = LOCAL / "unpacking-tools-final"
RUNS = LOCAL / "unpacking-comparison-final"
AUDIT = Path("/tmp/imre-unpacking-independent-audit")
PREFIX = "2026-10-19-assignment-unpacking-expansion"
FAMILIES = (
    "application-normal",
    "common-source-normal",
    "application-lto",
    "common-source-lto",
)
TEXT = {
    ".py",
    ".rs",
    ".c",
    ".toml",
    ".json",
    ".log",
    ".md",
    ".txt",
    ".ll",
    ".sh",
    ".yaml",
    ".yml",
    ".stderr",
    ".stdout",
    ".lock",
}


def info(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def sha(path):
    return info(Path(path).read_bytes())["sha256"]


def load(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def compressed(data):
    output = io.BytesIO()
    with gzip.GzipFile(
        fileobj=output, mode="wb", filename="", mtime=0, compresslevel=9
    ) as stream:
        stream.write(data)
    return output.getvalue()


def archive_path(path):
    path = path.absolute()
    if path.is_relative_to(ROOT):
        return "retained/" + str(path.relative_to(ROOT))
    assert path.is_relative_to(Path("/tmp")), path
    return "retained/tmp/" + str(path.relative_to("/tmp"))


class Package:
    def __init__(self):
        self.data = {}
        self.members = {}

    def add(self, name, data, source):
        assert not Path(name).is_absolute() and ".." not in Path(name).parts
        assert not data.startswith((b"\x7fELF", b"!<arch>\n", b"BC\xc0\xde"))
        assert Path(name).suffix not in {
            ".a",
            ".o",
            ".so",
            ".rlib",
            ".bc",
            ".exe",
            ".pyc",
        }
        assert not {"__pycache__", "target", ".git", ".cache"}.intersection(
            Path(name).parts
        )
        data.decode("utf-8")
        if name in self.data:
            assert self.data[name] == data
            return
        self.data[name] = data
        self.members[name] = {**info(data), "source": source}

    def file(self, path, expected=None):
        path = Path(path)
        assert path.is_file() and not path.is_symlink(), str(path)
        data = path.read_bytes()
        assert expected is None or info(data)["sha256"] == expected, str(path)
        self.add(archive_path(path), data, str(path))
        return data

    def text_tree(self, root):
        for path in sorted(root.rglob("*")):
            if (
                path.is_file()
                and path.suffix in TEXT
                and not {"__pycache__", "target", ".git", ".cache"}.intersection(
                    path.parts
                )
                and path.name not in {"portable-audit.json", "publication-run.json"}
            ):
                self.file(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--stage", type=Path, default=LOCAL / "unpacking-publication-stage"
    )
    parser.add_argument("--report", type=Path, default=HERE / "report.md")
    args = parser.parse_args()
    build, session, audit = (
        load(TOOLS / "build-record.json"),
        load(RUNS / "session.json"),
        load(AUDIT / "audit.json"),
    )
    assert (
        build["git_head"]
        == session["source_commit"]
        == audit["source_commit"]
        == COMMIT
    )
    assert (
        build["compiled_sources_match_commit"]
        and not build["git_status"]
        and audit["passed"]
    )
    assert "completed_at_utc" in session and list(session["runs"]) == list(FAMILIES)
    assert session["source_guard_before"] == session["source_guard_after"]
    assert session["preserved_guard_before"] == session["preserved_guard_after"]
    assert session["bytecode_before"] == session["bytecode_after"]
    assert args.report.is_file()
    for item in build["artifacts"].values():
        assert sha(item["path"]) == item["sha256"]

    package = Package()
    names = subprocess.check_output(
        ["git", "-C", str(ROOT), "ls-tree", "-r", "--name-only", COMMIT], text=True
    ).splitlines()
    names = [name for name in names if not name.startswith("benchmarks/results/")]
    source = subprocess.check_output(
        ["git", "-C", str(ROOT), "archive", "--format=tar", COMMIT, "--", *names]
    )
    with tarfile.open(fileobj=io.BytesIO(source), mode="r:") as archive:
        for member in archive:
            if member.isdir():
                continue
            assert member.isfile()
            package.add(
                "source/" + member.name,
                archive.extractfile(member).read(),
                "git:" + COMMIT + ":" + member.name,
            )
    assert {name[7:] for name in package.data} == set(names)
    validation = validate(package.file, lambda name: package.data["source/" + name])
    write(HERE / "validation.json", validation)

    prepared = load(HERE / "prepared-manifest.json")
    baseline = {
        "schema": "imre-unpacking-baseline-capture-v1",
        "modes": {},
        "source": prepared["baseline_source"],
    }
    keys = (
        "label",
        "case",
        "expected_stdout",
        "expected_file_inventory",
        "expected_changed_files",
        "stock_rows",
        "stock_skus",
        "batches",
        "request_rows",
        "positive_requests",
    )
    for mode in ("normal", "lto"):
        preserved = prepared["modes"][mode]
        assert sha(preserved["comparison"]) == preserved["comparison_sha256"]
        previous = load(preserved["comparison"])
        baseline["modes"][mode] = {
            "original_record": preserved["comparison"],
            "original_record_sha256": preserved["comparison_sha256"],
            "published_record": preserved["published"],
            "published_record_sha256": preserved["published_sha256"],
            "git": previous["git"],
            "sources": previous["sources"],
            "tool_paths": preserved["paths"],
            "sha256": preserved["sha256"],
            "workloads": {
                "inventory": [
                    {key: row[key] for key in keys}
                    for row in previous["workloads"]["inventory"]
                ]
            },
        }
        package.file(
            preserved["paths"]["inventory_ir"], preserved["sha256"]["inventory_ir"]
        )
        package.file(
            preserved["rust_build_record"], preserved["rust_build_record_sha256"]
        )
    write(HERE / "baseline-manifest.json", baseline)
    for name in FAMILIES:
        record = load(RUNS / (name + ".json"))
        run = session["runs"][name]
        assert run["returncode"] == 0
        package.file(RUNS / (name + ".json"), run["record_sha256"])
        package.file(RUNS / (name + ".log"), run["log_sha256"])
        cc = record["method"]["compile_commands"]["inventory"]
        package.file(cc[cc.index("--emit-llvm") + 1], record["sha256"]["inventory_ir"])
    old_build = LOCAL / "control-flow-tools-final-v2/build-record.json"
    package.file(old_build)
    previous_audit = audit["preserved_baseline_audit"]
    package.file(previous_audit["audit_path"], previous_audit["audit_sha256"])
    for item in load(old_build).get("retained_provenance", {}).values():
        package.file(item["path"], item["sha256"])
    for name, expected in session["scripts"].items():
        package.file(name, expected)

    summary = {
        "schema": "imre-unpacking-summary-v1",
        "status": "passed",
        "source_commit": COMMIT,
        "statistics_method": audit["statistical_method"],
        "comparison_families": audit["comparison_families"],
        "cross_family_caveat": audit["cross_family_caveat"],
        "families": audit["families"],
        "totals": audit["totals"],
        "changed_application_sources": prepared["changed_application_sources"],
        "independent_audit_checks": audit["checks"],
        "independent_audit_sha256": sha(AUDIT / "audit.json"),
        "validation_sha256": sha(HERE / "validation.json"),
        "native_validation_checks": validation["native_checks"],
        "total_native_semantic_checks": validation["total_native_semantic_checks"],
        "rust_unit_tests": validation["rust_unit_tests"],
        "inventory_asan_executions": 205,
        "provenance_note": "Measurements use the clean source commit above. Report and publication files were produced afterward and are not claimed to belong to the measured source tree.",
    }
    write(HERE / "summary.json", summary)
    for directory in (TOOLS, TESTS, RUST, INVENTORY, Path(str(INVENTORY) + "-sandbox-failure"), HERE, AUDIT):
        package.text_tree(directory)
    package.file(RUNS / "session.json")
    package.file(args.report)
    guide = f"""# Assignment, unpacking, and expansion evidence

Measurements use clean source commit {COMMIT}. `source/` is that Git tree,
excluding historical benchmark results. `retained/` holds all four current raw
families, exact old/new application sources, captured baseline workload cases,
generated LLVM, build records, test snapshots, validation logs and receipts,
and launch/audit/publication scripts.

The application family combines source and compiler/runtime changes. The
common-source family holds the old application source fixed. Each family is a
separate sequential measurement batch, so cross-family source-effect ratios
are not paired causal estimates. Each run retains all six workloads, 48 sample
rounds, two warmups, and four engines in balanced permutation order.

The portable audit checks every retained byte and recomputes saved statistics,
orders, output/filesystem oracles, and validation joins. It needs Python and
these text/source records; it does not execute native artifacts. Executables,
runtime archives, caches, toolchains, and historical raw result archives are
excluded. Their original paths/hashes and baseline publication references are
recorded. Captured baseline cases preserve the comparison's workload contract.

All {validation["total_native_semantic_checks"]:,} semantic checks, {validation["rust_unit_tests"]} Rust tests,
and 205 inventory ASan outcomes are reported separately. All validation uses
the measured source commit and its frozen compiler/runtime artifacts. Initial
sandbox runs aborted during LeakSanitizer process inspection; their logs are
retained alongside the successful reruns with sandbox permission. ASan covers emitted
application LLVM and the custom runtime, with leaks enabled outside ptrace;
the prebuilt Rust standard library was not rebuilt with ASan.
"""
    package.add("EVIDENCE.md", guide.encode(), "generated evidence guide")
    inner = {
        "schema": "imre-unpacking-evidence-v1",
        "source_commit": COMMIT,
        "members": package.members,
    }
    manifest_bytes = (json.dumps(inner, indent=2) + "\n").encode()
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:", format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(
            {**package.data, "manifest.json": manifest_bytes}.items()
        ):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(data), 0o644
            member.uid = member.gid = member.mtime = 0
            archive.addfile(member, io.BytesIO(data))
    args.stage.mkdir(parents=True, exist_ok=True)
    companions = {}

    def publish(suffix, data, original=None):
        name = PREFIX + "-" + suffix
        (args.stage / name).write_bytes(data)
        companions[name] = info(data)
        if original is not None:
            companions[name]["uncompressed"] = info(original)

    publish("evidence.tar.gz", compressed(output.getvalue()))
    for suffix, path in (
        ("build.json", TOOLS / "build-record.json"),
        ("session.json", RUNS / "session.json"),
        ("audit.json", AUDIT / "audit.json"),
        ("summary.json", HERE / "summary.json"),
        ("validation.json", HERE / "validation.json"),
    ):
        publish(suffix, path.read_bytes())
    for family in FAMILIES:
        raw = (RUNS / (family + ".json")).read_bytes()
        publish(family + ".json.gz", compressed(raw), raw)
    report_name = PREFIX + ".md"
    report = args.report.read_bytes()
    (args.stage / report_name).write_bytes(report)
    companions[report_name] = {
        **info(report),
        "provenance": "Written after measurement; a separate content hash from the measured Git tree.",
    }
    outer = {
        **inner,
        "archive_manifest": info(manifest_bytes),
        "companions": companions,
    }
    write(args.stage / (PREFIX + "-evidence-manifest.json"), outer)
    print(
        json.dumps(
            {
                "stage": str(args.stage),
                "members": len(package.members),
                "companions": len(companions),
                "archive_bytes": companions[PREFIX + "-evidence.tar.gz"]["bytes"],
                "native_checks": validation["native_checks"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
