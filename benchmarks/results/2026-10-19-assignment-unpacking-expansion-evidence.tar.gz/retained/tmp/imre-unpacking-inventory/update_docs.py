"""Refresh visible results after the frozen benchmark and audits finish."""
import json
from pathlib import Path
ROOT = Path('/home/dev-user/code/oss/imre')
PREFIX = '2026-10-19-assignment-unpacking-expansion'
audit = json.loads(Path('/tmp/imre-unpacking-independent-audit/audit.json').read_text())
assert audit['passed']
large = audit['families']['application-lto']['rows'][-2:]
assert [row['workload'] for row in large] == ['dense-16384', 'sparse-16384']
low, high = min(row['rust_gap_percent'] for row in large), max(row['rust_gap_percent'] for row in large)
assert low > 0
speed_min, speed_max = min(row['cpython_speedup'] for row in large), max(row['cpython_speedup'] for row in large)
readme = ROOT / 'README.md'
s = readme.read_text()
for name, row in zip(('Dense', 'Sparse'), large, strict=True):
    prefix = f'| {name} inventory reconciliation |'
    before = next(line for line in s.splitlines() if line.startswith(prefix))
    time = row['median_ms']
    after = f"{prefix} 16,384 | {time['imre']:.2f} ms | {time['cpython']:.2f} ms | {row['cpython_speedup']:.2f}× |"
    s = s.replace(before, after)
s = s.replace('benchmarks/results/2026-10-19-truthiness-loop-else.md', f'benchmarks/results/{PREFIX}.md')
s = s.replace('Imre takes 4.1–8.7% more', f'Imre takes {low:.1f}–{high:.1f}% more')
readme.write_text(s)
guide = ROOT / 'benchmarks/README.md'
s = guide.read_text()
assert PREFIX not in s
s += f'\nThe [assignment, unpacking, and expansion milestone](results/{PREFIX}.md) adopts chained assignment, starred argument unpacking, row unpacking, and dictionary-key expansion in the inventory reconciler. ThinLTO runs the large cases {speed_min:.2f}–{speed_max:.2f}× faster than CPython and takes {low:.1f}–{high:.1f}% more time than Rust BigInt. Four families compare the updated application and unchanged previous source under ordinary and ThinLTO linking, retaining all 4,608 measured executions. The report includes the preserved-Imre comparisons, sample spreads, independently audited provenance, 2,417 semantic checks, 92 Rust tests, and inventory ASan/LSan validation. These measurements assess the compatibility milestone; they do not establish an isolated syntax cost or a native speedup.\n'
guide.write_text(s)
