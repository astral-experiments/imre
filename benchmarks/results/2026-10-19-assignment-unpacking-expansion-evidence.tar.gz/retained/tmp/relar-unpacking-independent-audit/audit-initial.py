"""Audit saved unpacking benchmark evidence without rerunning timed workloads.

The generic oracle, result, and exact-Fraction statistics helpers are retained
byte-for-byte from the earlier independent audit. This entry point verifies the
new four-family design, source migration, frozen tools, and complete session.
"""

import argparse
import gzip
import hashlib
import importlib.util
import json
import runpy
import stat
import struct
import subprocess
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
HELPER_SHA = "ff001415dca986218ccf6f26cb3fb7a4ba027e7e32bc551a4602b4795df02d72"
SOURCE = "3cc767b401f988ece94e1eb4bb98c43cd06c02b2"
BASE_SOURCE = "8a96c8249bad8249e232af0af0e5921fe8c77680"
BASE_COMPILER = "5b3e8438376091340f6610d7e603b9808d7ed65c"
ENGINES = ("cpython", "relar", "rust_bigint", "baseline")
RUNS = (
    "application-normal",
    "common-source-normal",
    "application-lto",
    "common-source-lto",
)

helper_path = HERE / "reused_helpers.py"
if hashlib.sha256(helper_path.read_bytes()).hexdigest() != HELPER_SHA:
    raise RuntimeError("independent audit helpers changed")
spec = importlib.util.spec_from_file_location("retained_audit_helpers", helper_path)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
require = h.require
verify_file = h.verify_file
load_json = h.load_json


def git(root, *arguments):
    return subprocess.check_output(["git", "-C", str(root), *arguments])


def sources_at(root, sources, revision):
    actual = {
        str(path.relative_to(root)): h.file_info(path)["sha256"]
        for path in sorted((root / "inventory_reconciliation").rglob("*.py"))
    }
    require(actual == sources and len(actual) == 6, "complete six-file application")
    return {"examples/" + name: value for name, value in sources.items()}


def prepared_inputs(root, manifest):
    """Verify the old executable and both source snapshots independently of guards."""
    require(manifest["schema_version"] == 1, "prepared manifest schema")
    baseline = manifest["baseline_source"]
    application = manifest["application_source"]
    require(baseline["commit"] == BASE_SOURCE, "baseline application revision")
    require(
        set(baseline["sources"]) == set(application["sources"]), "source set unchanged"
    )
    for item in (baseline, application):
        committed = sources_at(Path(item["root"]), item["sources"], item["commit"])
        h.verify_committed(root, item["commit"], committed)
    h.verify_committed(
        root, SOURCE, sources_at(root / "examples", application["sources"], SOURCE)
    )
    changed = {
        name: {
            "baseline_sha256": baseline["sources"][name],
            "application_sha256": application["sources"][name],
        }
        for name in baseline["sources"]
        if baseline["sources"][name] != application["sources"][name]
    }
    require(
        changed == manifest["changed_application_sources"], "source migration inventory"
    )
    require(
        set(changed)
        == {
            "inventory_reconciliation/__main__.py",
            "inventory_reconciliation/load.py",
            "inventory_reconciliation/reconcile.py",
            "inventory_reconciliation/render.py",
        },
        "four intended source rewrites",
    )
    protected = dict(manifest["preserved_tools"])
    originals = {}
    for mode, prepared in manifest["modes"].items():
        require(mode in ("normal", "lto"), "known prepared mode")
        previous = load_json(prepared["comparison"])
        originals[mode] = previous
        require(
            previous["git"] == {"revision": BASE_COMPILER, "dirty": False},
            "clean old compiler measurement",
        )
        require(
            prepared["compiler_source_commit"] == BASE_COMPILER,
            "prepared compiler source",
        )
        require(
            previous["sources"] == baseline["sources"],
            "old measured application matches snapshot",
        )
        require(previous["options"] == prepared["options"], "prepared baseline options")
        for name, path in prepared["paths"].items():
            expected = prepared["sha256"][name]
            require(
                previous["sha256"][name] == expected,
                "prepared old artifact identity: " + name,
            )
            protected[path] = expected
        for name in ("comparison", "published", "rust_build_record"):
            protected[prepared[name]] = prepared[name + "_sha256"]
        require(
            gzip.decompress(Path(prepared["published"]).read_bytes())
            == Path(prepared["comparison"]).read_bytes(),
            "published old raw record bytes",
        )
        rust = load_json(prepared["rust_build_record"])
        require(
            rust == previous["rust_build_record"]
            and rust["sources"] == prepared["rust_sources"],
            "preserved Rust build record",
        )
        for name, expected in rust["sources"].items():
            protected[
                str(root / "benchmarks/reference/inventory_reconciliation" / name)
            ] = expected
        for workload in previous["workloads"]["inventory"]:
            require(
                h.digest(json.dumps(workload["case"], sort_keys=True).encode())
                == prepared["case_sha256"][workload["label"]],
                "prepared workload bytes",
            )
    require(set(originals) == {"normal", "lto"}, "both prepared modes")
    for path, expected in protected.items():
        verify_file(path, expected)
    old_build = h.verify_build(
        root,
        root / "benchmarks/local/control-flow-tools-final-v2/build-record.json",
        BASE_COMPILER,
    )
    for previous in originals.values():
        for key, value in previous["relar_build_provenance"].items():
            require(old_build[key] == value, "preserved build provenance projection")
    return originals, protected, old_build


def current_build(root, session):
    directory = root / "benchmarks/local/unpacking-tools-final"
    path = directory / "build-record.json"
    build = h.verify_build(root, path, SOURCE)
    names = (
        git(
            root,
            "ls-tree",
            "-r",
            "--name-only",
            SOURCE,
            "Cargo.toml",
            "Cargo.lock",
            "rust-toolchain.toml",
            ".cargo",
            "crates",
        )
        .decode()
        .splitlines()
    )
    require(
        set(build["source_sha256"]) == set(names), "complete compiled source closure"
    )
    for name, expected in build["source_sha256"].items():
        verify_file(root / name, expected)
    require(
        build["source_proof"]
        == {
            "before_and_after_each_build_match_clean_commit": True,
            "independent_regular_artifact_copies": True,
        },
        "frozen source proof",
    )
    expected = {
        "relar",
        "librelar_runtime.a",
        "librelar_runtime_lto.a",
        "librelar_runtime_asan.a",
    }
    require(set(build["artifacts"]) == expected, "complete frozen artifact inventory")
    for name, item in build["artifacts"].items():
        path, origin = Path(item["path"]), Path(item["source_path"])
        require(path == directory / name, "frozen artifact location")
        info = path.lstat()
        require(
            stat.S_ISREG(info.st_mode)
            and info.st_nlink == 1
            and not path.samefile(origin),
            "frozen artifact is an independent regular copy",
        )
        require(info.st_mode & 0o222 == 0, "frozen artifact is read-only")
        verify_file(path, item["sha256"])
        require(
            build["sha256"][str(path.relative_to(root))] == item["sha256"],
            "build artifact maps agree",
        )
    require(
        build["runtime_lto_rustflags"] == "-Clinker-plugin-lto", "ThinLTO archive flags"
    )
    require(
        build["runtime_asan_rustflags"]
        == "-Zsanitizer=address -Cforce-frame-pointers=yes",
        "sanitized archive flags",
    )
    require(
        set(build["commands"]) == {"ordinary", "thinlto", "asan"},
        "three recorded builds",
    )
    require(
        build["commands"]["ordinary"]["environment"] == {"CARGO_BUILD_JOBS": "4"},
        "ordinary build environment",
    )
    require(
        build["commands"]["thinlto"]["environment"]
        == {"CARGO_BUILD_JOBS": "4", "RUSTFLAGS": "-Clinker-plugin-lto"},
        "ThinLTO build environment",
    )
    for item in build["commands"].values():
        require(
            build["started_at_utc"]
            <= item["started_at_utc"]
            <= item["completed_at_utc"]
            <= build["completed_at_utc"]
            <= session["started_at_utc"],
            "build precedes measurement",
        )
    verify_file(directory / "freeze.py", build["build_script_sha256"])
    require(
        h.digest(build["cargo_wrapper"]["source"].encode())
        == build["cargo_wrapper"]["sha256"],
        "recorded Cargo wrapper source",
    )
    require(
        "-Zohm-defaults=no" in build["cargo_wrapper"]["source"],
        "Ohm experimental defaults disabled",
    )
    return build


def preserved_audit_evidence(root, old_build):
    """Join the previous published audit to its exact frozen compiler build."""
    path = root / "benchmarks/results/2026-10-19-truthiness-loop-else-audit.json"
    previous = load_json(path)
    require(previous["passed"] is True and previous["source_commit"] == BASE_COMPILER,
            "preserved baseline audit passed")
    record = root / "benchmarks/local/control-flow-tools-final-v2/build-record.json"
    require(previous["frozen_build"]["build_record_sha256"] == h.file_info(record)["sha256"],
            "published audit covers preserved build")
    require(previous["frozen_build"]["artifacts"] == old_build["artifacts"],
            "published audit identifies preserved artifacts")
    return {"audit_path": str(path), "audit_sha256": h.file_info(path)["sha256"],
            "original_checks": previous["checks"], "scope": previous["frozen_build"]}


def session_provenance(root, session, manifest, protected, build, manifest_path):
    require(
        session["source_commit"] == SOURCE and session["validation_only"] is False,
        "timed final source session",
    )
    require(list(session["runs"]) == list(RUNS), "four sequential comparison families")
    require(
        session["source_guard_before"] == session["source_guard_after"],
        "unchanged source guards",
    )
    guard = session["source_guard_before"]
    require(
        guard["head"] == SOURCE
        and guard["dirty"] is False
        and guard["all_compiled_sources_match_commit"] is True,
        "clean measured source guard",
    )
    require(
        guard["build_record_sha256"]
        == h.file_info(
            root / "benchmarks/local/unpacking-tools-final/build-record.json"
        )["sha256"],
        "session frozen build identity",
    )
    require(
        guard["application_source_sha256"]
        == {
            "examples/" + key: value
            for key, value in manifest["application_source"]["sources"].items()
        },
        "source guard application identity",
    )
    require(
        guard["artifact_sha256"]
        == {
            name: build["artifacts"][name]["sha256"]
            for name in ("relar", "librelar_runtime.a", "librelar_runtime_lto.a")
        },
        "source guard artifact identity",
    )
    require(
        session["preserved_guard_before"] == session["preserved_guard_after"],
        "unchanged preserved guards",
    )
    require(
        session["preserved_guard_before"]
        == {
            "sha256": protected,
            "snapshots": {
                kind: manifest[kind]["sources"]
                for kind in ("baseline_source", "application_source")
            },
        },
        "complete independent preserved guard",
    )
    expected_scripts = {
        str(manifest_path),
        str(manifest_path.with_name("launch.py")),
        str(manifest_path.with_name("run_comparison.py")),
        str(root / "benchmarks/local/sequence-access-final-launch.py"),
    }
    require(set(session["scripts"]) == expected_scripts, "launcher helper coverage")
    for name, expected in session["scripts"].items():
        verify_file(name, expected)
    require(
        set(session["comparison_families"]) == {"application", "common-source"},
        "separate source-migration and compiler comparisons",
    )
    last = session["started_at_utc"]
    for name in RUNS:
        run = session["runs"][name]
        require(
            last <= run["started_at_utc"] <= run["completed_at_utc"],
            "serial measurement order",
        )
        last = run["completed_at_utc"]
    require(last <= session["completed_at_utc"], "completed measurement session")


def caches(root, session, manifest, python):
    require(
        session["bytecode_before"] == session["bytecode_after"],
        "bytecode unchanged during all four runs",
    )
    require(
        set(session["bytecode_before"]) == {"current", "baseline"},
        "both source caches captured",
    )
    require(
        session["cache_preparation"]["timed"] is False, "cache preparation excluded"
    )
    source_roots = {
        "current": root / "examples",
        "baseline": Path(manifest["baseline_source"]["root"]),
    }
    preparation = [
        manifest["modes"]["normal"]["paths"]["python"],
        "-I",
        "-m",
        "compileall",
        "-q",
        *(str(path / "inventory_reconciliation") for path in source_roots.values()),
    ]
    require(
        session["cache_preparation"]["command"] == preparation,
        "both source caches prepared outside timings",
    )
    for family, record in session["bytecode_before"].items():
        require(
            record["python"] == python["version"]
            and record["cache_tag"] == "cpython-314",
            "cache interpreter",
        )
        require(
            record["pycache_prefix"] is None and record["dont_write_bytecode"] is False,
            "cache policy",
        )
        sources = manifest[
            "application_source" if family == "current" else "baseline_source"
        ]["sources"]
        require(
            set(record["files"])
            == {str(source_roots[family] / name) for name in sources},
            "cache covers complete source",
        )
        for source, item in record["files"].items():
            source = Path(source)
            relative = str(source.relative_to(source_roots[family]))
            require(item["source_sha256"] == sources[relative], "cache source hash")
            verify_file(source, item["source_sha256"])
            require(
                source.stat().st_mtime_ns == item["source_mtime_ns"],
                "cache source timestamp unchanged",
            )
            verify_file(item["cache_path"], item["cache_sha256"], item["cache_bytes"])
            data = Path(item["cache_path"]).read_bytes()
            require(data[:4].hex() == record["magic"], "cache magic")
            flags, timestamp, size = struct.unpack("<III", data[4:16])
            require(
                flags == item["flags"] == 0 and item["valid_header"] is True,
                "timestamp cache mode",
            )
            require(
                timestamp == ((item["source_mtime_ns"] // 1_000_000_000) & 0xFFFFFFFF)
                and size == (source.stat().st_size & 0xFFFFFFFF),
                "cache header matches complete source",
            )
    return {
        "source_and_cache_pairs": 12,
        "before_after_identical": True,
        "timestamp_headers_match_sources": True,
        "preparation_timed": False,
    }


def rust_provenance(root, record, previous, prepared, mode):
    rust = load_json(prepared["rust_build_record"])
    require(
        record["rust_build_record"] == previous["rust_build_record"] == rust,
        "same preserved Rust build",
    )
    require(
        rust["entrypoint"] == "inventory"
        and rust["sources"] == record["rust_sources"] == prepared["rust_sources"],
        "Rust source identity",
    )
    require(
        set(rust["sources"])
        == set(rust["source_contents"])
        == {"Cargo.toml", "Cargo.lock", "src/main.rs"},
        "complete Rust source capture",
    )
    for name, expected in rust["sources"].items():
        verify_file(
            root / "benchmarks/reference/inventory_reconciliation" / name, expected
        )
        require(
            h.digest(rust["source_contents"][name].encode()) == expected,
            "Rust captured source bytes",
        )
    h.verify_committed(
        root,
        SOURCE,
        {
            "benchmarks/reference/inventory_reconciliation/" + name: value
            for name, value in rust["sources"].items()
        },
    )
    require(
        rust["binaries"]["bigint"]["sha256"] == record["sha256"]["rust_bigint"],
        "Rust executable bytes",
    )
    require(
        h.digest(rust["build_script"].encode())
        == rust["build_script_sha256"]
        == record["sha256"]["rust_build_script"],
        "Rust build script bytes",
    )
    require(
        h.digest(rust["cargo_wrapper"]["source"].encode())
        == rust["cargo_wrapper"]["sha256"],
        "Rust wrapper bytes",
    )
    thin = mode == "lto"
    env = rust["environment"]
    require(env.get("CARGO_PROFILE_RELEASE_OPT_LEVEL", "3") == "3", "Rust O3")
    require(rust["llvm_budget"] == (1000 if thin else None), "Rust LLVM budget")
    require(
        env.get("CARGO_PROFILE_RELEASE_LTO") == ("thin" if thin else None),
        "Rust LTO mode",
    )
    require(
        env.get("CARGO_ENCODED_RUSTFLAGS") == (None if thin else ""),
        "Rust encoded flags",
    )
    require(
        env["RUSTFLAGS"]
        == (
            "-Cllvm-args=-import-instr-limit=1000 -Cllvm-args=-inline-threshold=1000"
            if thin
            else ""
        ),
        "Rust matched explicit optimizer budget",
    )
    require("host: x86_64-unknown-linux-gnu" in rust["rustc_verbose"], "Rust target")
    for tool, expected in rust["tool_sha256"].items():
        path = subprocess.check_output(
            ["rustup", "which", tool, "--toolchain", "ohm"], text=True
        ).strip()
        verify_file(path, expected)


def artifact_provenance(
    root, directory, name, record, session, manifest, build, previous
):
    family, mode = name.rsplit("-", 1)
    command = session["runs"][name]["command"]
    require(h.flag(command, "--repository") == str(root), "launcher repository")
    source = (
        root / "examples"
        if family == "application"
        else Path(manifest["baseline_source"]["root"])
    )
    require(
        h.flag(command, "--application-source-root") == str(source),
        "explicit selected source family",
    )
    require(
        h.flag(command, "--cpu") == "0"
        and h.flag(command, "--samples") == "48"
        and h.flag(command, "--warmups") == "2"
        and "--validate-only" not in command,
        "launcher timing configuration",
    )
    require(
        h.flag(command, "--output") == str(directory / (name + ".json"))
        and h.flag(command, "--artifact-dir") == str(directory / name),
        "distinct run outputs",
    )
    option_paths = {
        "compiler": "--compiler",
        "runtime": "--runtime",
        "relar_build_record": "--relar-build-record",
        "rust_bigint": "--rust-bigint",
        "rust_record": "--rust-build-record",
        "python": "--python",
        "inventory_baseline": "--inventory-baseline",
        "inventory_baseline_record": "--inventory-baseline-record",
    }
    paths = {key: Path(h.flag(command, flag)) for key, flag in option_paths.items()}
    tools = root / "benchmarks/local/unpacking-tools-final"
    require(
        paths["compiler"] == tools / "relar"
        and paths["relar_build_record"] == tools / "build-record.json",
        "current frozen compiler path",
    )
    require(
        paths["runtime"]
        == tools / ("librelar_runtime_lto.a" if mode == "lto" else "librelar_runtime.a"),
        "runtime mode pairing",
    )
    require(
        record["sha256"]["compiler"] == build["artifacts"]["relar"]["sha256"],
        "frozen compiler in record",
    )
    selected_sources = manifest[
        "application_source" if family == "application" else "baseline_source"
    ]["sources"]
    require(record["sources"] == selected_sources, "record selected application source")
    migration = record["inventory_baseline_source"]
    changed = {
        key: {
            "baseline_sha256": previous["sources"][key],
            "current_sha256": selected_sources[key],
        }
        for key in selected_sources
        if previous["sources"][key] != selected_sources[key]
    }
    require(
        migration
        == {
            "snapshot_root": manifest["baseline_source"]["root"],
            "recorded_sources": previous["sources"],
            "current_sources": selected_sources,
            "changed_sources": changed,
        },
        "complete source migration control",
    )
    require(
        len(changed) == (3 if family == "application" else 0),
        "source migration family separation",
    )
    compiled = record["method"]["compile_commands"]
    require(set(compiled) == {"inventory"}, "single application compilation")
    cc = compiled["inventory"]
    require(
        cc[:3]
        == [
            str(paths["compiler"]),
            "build",
            str(source / "inventory_reconciliation/__main__.py"),
        ]
        and h.flag(cc, "--module-root") == str(source),
        "compiled entry and imports use selected source",
    )
    require(
        h.flag(cc, "--runtime") == str(paths["runtime"])
        and h.flag(cc, "--opt-level") == "3"
        and h.flag(cc, "--target") == "x86_64-unknown-linux-gnu"
        and "--sanitize" not in cc,
        "measured native build mode",
    )
    paths.update(
        inventory_binary=Path(h.flag(cc, "-o")),
        inventory_ir=Path(h.flag(cc, "--emit-llvm")),
        clang=Path(h.flag(cc, "--clang")),
        rust_build_script=root
        / "benchmarks/reference/inventory_reconciliation/build.py",
        tracked_rust_build_script=root
        / "benchmarks/reference/inventory_reconciliation/build.py",
        guard_helpers=root
        / "benchmarks/reference/dependency_planner/check_boundaries.py",
    )
    require(
        paths["inventory_binary"] == directory / name / "inventory_reconciliation"
        and paths["inventory_ir"] == directory / name / "inventory_reconciliation.ll",
        "native artifact location",
    )
    if mode == "lto":
        paths["lto_linker"] = Path(h.flag(cc, "--lto-linker"))
        require(paths["lto_linker"].name == "ld.lld", "lexical linker mode")
    else:
        require("--lto-linker" not in cc, "ordinary linking mode")
    require(
        record["compilation"]["inventory"]["returncode"] == 0
        and record["compilation"]["inventory"]["stderr"] == "",
        "successful compilation",
    )
    committed = {}
    for key, expected in record["sha256"].items():
        if key.startswith("harness:"):
            paths[key] = root / "benchmarks" / key.split(":", 1)[1]
        elif key.startswith("relar_source:"):
            relative = key.split(":", 1)[1]
            paths[key] = root / relative
            require(
                build["source_sha256"][relative] == expected, "record compiler source"
            )
        elif key.startswith("inventory_baseline_source:"):
            relative = key.split(":", 1)[1]
            paths[key] = Path(manifest["baseline_source"]["root"]) / relative
            require(
                previous["sources"][relative] == expected, "record baseline snapshot"
            )
        require(key in paths, "mapped recorded artifact: " + key)
        verify_file(paths[key], expected)
        if key.startswith(("harness:", "relar_source:")) or key in (
            "guard_helpers",
            "tracked_rust_build_script",
        ):
            committed[str(paths[key].relative_to(root))] = expected
    h.verify_committed(root, SOURCE, committed)
    for key, info in record["artifacts"].items():
        require(
            h.file_info(paths[key])["bytes"] == info["bytes"], "record artifact size"
        )
    for key, value in record["relar_build_provenance"].items():
        require(build[key] == value, "current build projection")
    for key, value in record["inventory_baseline_provenance"].items():
        require(previous[key] == value, "old benchmark projection")
    prepared = manifest["modes"][mode]
    require(
        str(paths["inventory_baseline"]) == prepared["paths"]["inventory_binary"]
        and str(paths["inventory_baseline_record"]) == prepared["comparison"],
        "old executable and record pairing",
    )
    for key in ("clang", "python", "rust_bigint", "lto_linker"):
        if key in paths:
            require(
                record["sha256"][key] == prepared["sha256"][key],
                "unchanged comparison tool: " + key,
            )
    for key in ("cpython", "clang", "lto_linker"):
        require(
            record["tools"][key] == previous["tools"][key], "unchanged tool metadata"
        )
    commands = record["method"]["commands"]["inventory"]
    require(tuple(commands) == ENGINES, "engine command order")
    require(
        commands["cpython"][:3] == [str(paths["python"]), "-I", "-c"]
        and len(commands["cpython"]) == 5
        and commands["cpython"][4] == str(source),
        "isolated CPython source family",
    )
    for engine, artifact in (
        ("relar", "inventory_binary"),
        ("rust_bigint", "rust_bigint"),
        ("baseline", "inventory_baseline"),
    ):
        require(commands[engine] == [str(paths[artifact])], "native engine command")
    rust_provenance(root, record, previous, prepared, mode)


def benchmark(root, directory, name, session, manifest, build, previous, validator):
    path = directory / (name + ".json")
    record = load_json(path)
    run = session["runs"][name]
    verify_file(path, run["record_sha256"])
    verify_file(path.with_suffix(".log"), run["log_sha256"])
    require(run["returncode"] == 0, "successful comparison runner")
    require(
        run["started_at_utc"]
        <= record["started_at_utc"]
        <= record["completed_at_utc"]
        <= run["completed_at_utc"],
        "captured timing interval",
    )
    require(
        record["schema_version"] == 1
        and record["example"] == "inventory_reconciliation",
        "record schema",
    )
    require(
        record["git"] == {"revision": SOURCE, "dirty": False}, "clean measured commit"
    )
    family, mode = name.rsplit("-", 1)
    require(
        record["options"] == manifest["modes"][mode]["options"],
        "identical measured options",
    )
    require(
        record["baseline_provenance"] is None and record["workloads"]["control"] == [],
        "no unrelated control workloads",
    )
    context = record["execution"]
    require(
        set(context) == {"before", "before_samples", "after"}
        and context["before"] == context["before_samples"] == context["after"],
        "runtime context checkpoints unchanged",
    )
    require(context["before"]["tracer_pid"] == 0, "timing outside ptrace")
    for variable in ("LD_PRELOAD", "ASAN_OPTIONS", "LSAN_OPTIONS", "UBSAN_OPTIONS"):
        require(
            context["before"]["inherited_environment"][variable] is None,
            "uninstrumented timing environment",
        )
    require(
        record["host"]["cpu"]["affinity"] == [0]
        and 0 in record["host"]["cpu"]["allowed_cpus_before_pinning"],
        "CPU zero pinned",
    )
    require(
        record["clock"]["monotonic"] is True
        and record["clock"]["adjustable"] is False
        and record["clock"]["resolution"] == 1e-9,
        "monotonic nanosecond clock",
    )
    python = record["tools"]["cpython"]
    require(
        python["implementation"] == "cpython"
        and python["version_number"] == "3.14.5"
        and python["gil_enabled"] is True
        and python["free_threaded_build"] is False
        and python["jit_enabled"] is False
        and python["debug_build"] is False,
        "CPython interpreter configuration",
    )
    require(
        python["pgo"]["configure_enable_optimizations"] is True
        and python["pgo"]["profile_use_flag_present"] is True
        and python["lto"]["lto_flag_present"] is True,
        "CPython optimized PGO/LTO build",
    )
    artifact_provenance(
        root, directory, name, record, session, manifest, build, previous
    )
    validation = h.correctness(record, validator)
    rows, order, measured, warmups, gates = h.audit_workloads(
        record, previous, validator, ENGINES, "relar"
    )
    for row, workload in zip(rows, record["workloads"]["inventory"]):
        exact = {
            engine: {
                key: h.quantile(
                    [sample[engine]["elapsed_ns"] for sample in workload["samples"]],
                    n,
                    d,
                )
                for key, n, d in (
                    ("p25_ns", 1, 4),
                    ("median_ns", 1, 2),
                    ("p75_ns", 3, 4),
                )
            }
            for engine in ENGINES
        }
        row["exact_quantiles_ns"] = {
            engine: {
                key: {"numerator": value.numerator, "denominator": value.denominator}
                for key, value in stats.items()
            }
            for engine, stats in exact.items()
        }
        for numerator in ENGINES:
            for denominator in ENGINES:
                if numerator != denominator:
                    ratio = (
                        exact[numerator]["median_ns"] / exact[denominator]["median_ns"]
                    )
                    h.close(
                        row["ratios_of_medians"][numerator + "_over_" + denominator],
                        float(ratio),
                        "exact median ratio",
                    )
        row["cpython_speedup"] = row["ratios_of_medians"]["cpython_over_relar"]
        row["rust_gap_percent"] = 100 * (
            row["ratios_of_medians"]["relar_over_rust_bigint"] - 1
        )
        stats = row["statistics"]
        for label, engine in (("previous", "baseline"), ("rust", "rust_bigint")):
            row["iqr_overlap_vs_" + label] = max(
                stats["relar"]["p25_ns"], stats[engine]["p25_ns"]
            ) <= min(stats["relar"]["p75_ns"], stats[engine]["p75_ns"])
    return {
        "family": family,
        "mode": mode,
        "record_sha256": h.file_info(path)["sha256"],
        "measured_process_runs": measured,
        "warmup_process_runs": warmups,
        "inventory_gate_runs": gates,
        "validation_process_results": validation,
        "ordering": order,
        "rows": rows,
        "changed_application_sources": list(
            record["inventory_baseline_source"]["changed_sources"]
        ),
        "ir_sha256": record["sha256"]["inventory_ir"],
        "old_ir_sha256": previous["sha256"]["inventory_ir"],
    }, record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path("/home/dev-user/code/oss/relar")
    )
    parser.add_argument("--directory", type=Path)
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("/tmp/relar-unpacking-inventory/prepared-manifest.json"),
    )
    parser.add_argument("--output", type=Path, default=HERE / "audit.json")
    args = parser.parse_args()
    root = args.root.resolve()
    directory = (
        args.directory or root / "benchmarks/local/unpacking-comparison-final"
    )
    started = datetime.now(timezone.utc).isoformat()
    session = load_json(directory / "session.json")
    require(
        "completed_at_utc" in session and "source_guard_after" in session,
        "timing must finish before auditing",
    )
    manifest = load_json(args.manifest)
    originals, protected, old_build = prepared_inputs(root, manifest)
    build = current_build(root, session)
    old_audit = preserved_audit_evidence(root, old_build)
    session_provenance(root, session, manifest, protected, build, args.manifest)
    for key in ("rustc_verbose", "cargo_version", "runtime_lto_rustflags"):
        require(
            build[key].rstrip("\n") == old_build[key].rstrip("\n"),
            "current and old Relar toolchain: " + key,
        )
    # Hash and reconcile the oracle's transitive source inputs before loading it.
    first = load_json(directory / (RUNS[0] + ".json"))
    for name in (
        "inventory_validate.py",
        "manifest_validate.py",
        "batch_validate.py",
        "incremental_validate.py",
    ):
        verify_file(root / "benchmarks" / name, first["sha256"]["harness:" + name])
    validator = runpy.run_path(str(root / "benchmarks/inventory_validate.py"))
    results, records = {}, {}
    for name in RUNS:
        results[name], records[name] = benchmark(
            root,
            directory,
            name,
            session,
            manifest,
            build,
            originals[name.rsplit("-", 1)[1]],
            validator,
        )
    first_record = records[RUNS[0]]
    for record in records.values():
        for key in ("rust_sources", "relar_build_provenance", "git", "execution"):
            require(
                record[key] == first_record[key], "cross-family shared identity: " + key
            )
        require(
            record["tools"]["cpython"] == first_record["tools"]["cpython"],
            "same CPython across all four runs",
        )
        require(record["host"] == first_record["host"], "same measured host")
        for previous, current in zip(
            first_record["workloads"]["inventory"], record["workloads"]["inventory"]
        ):
            excluded = {"gates", "warmups", "samples", "summary"}
            require(
                {k: v for k, v in previous.items() if k not in excluded}
                == {k: v for k, v in current.items() if k not in excluded},
                "same captured cases across families",
            )
    for family in ("application", "common-source"):
        normal, thin = records[family + "-normal"], records[family + "-lto"]
        require(
            normal["sources"] == thin["sources"]
            and normal["sha256"]["inventory_ir"] == thin["sha256"]["inventory_ir"],
            "linking modes use identical application and generated LLVM IR",
        )
    bytecode = caches(root, session, manifest, first_record["tools"]["cpython"])
    totals = {
        key: sum(value[key] for value in results.values())
        for key in (
            "measured_process_runs",
            "warmup_process_runs",
            "inventory_gate_runs",
        )
    }
    totals["oracle_process_results"] = sum(
        value["validation_process_results"]["inventory"] for value in results.values()
    )
    totals["device_process_results"] = sum(
        value["validation_process_results"]["inventory_device"]
        for value in results.values()
    )
    require(
        totals
        == {
            "measured_process_runs": 4608,
            "warmup_process_runs": 192,
            "inventory_gate_runs": 96,
            "oracle_process_results": 3264,
            "device_process_results": 16,
        },
        "complete four-family process accounting",
    )
    h.file_info(helper_path)
    h.file_info(HERE / "helper-origin.json")
    h.file_info(Path(__file__))
    for path, (_, expected) in list(h.FILES.items()):
        with path.open("rb") as stream:
            require(
                hashlib.file_digest(stream, "sha256").hexdigest() == expected,
                "input unchanged during audit: " + str(path),
            )
    audit_script_hash = h.file_info(Path(__file__))["sha256"]
    build_record_hash = h.file_info(
        root / "benchmarks/local/unpacking-tools-final/build-record.json"
    )["sha256"]
    report = {
        "passed": True,
        "source_commit": SOURCE,
        "baseline_application_commit": BASE_SOURCE,
        "baseline_compiler_commit": BASE_COMPILER,
        "started_at_utc": started,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "checks": h.CHECKS,
        "scope": "saved evidence only; no benchmarks, compilers, or native workloads rerun",
        "statistical_method": "Exact Fraction interpolation of sorted integer ns at p*(n-1), inclusive Q1/median/Q3; ratios of engine medians. IQR overlap is descriptive, not a significance test.",
        "comparison_families": {
            "application": "Rewritten application on current Relar and CPython; preserved old application on baseline Relar. Changes combine source and compiler/runtime effects.",
            "common-source": "Exact old application on current Relar, preserved Relar, and CPython. Current-versus-preserved Relar holds application source fixed.",
        },
        "cross_family_caveat": "Families are sequential measurement batches; direct cross-family source-effect ratios are not paired or causal estimates.",
        "reused_helper_sha256": HELPER_SHA,
        "audit_script_sha256": audit_script_hash,
        "preserved_baseline_audit": old_audit,
        "totals": totals,
        "bytecode": bytecode,
        "frozen_build": {
            "source_files": len(build["source_sha256"]),
            "artifacts": build["artifacts"],
            "build_record_sha256": build_record_hash,
        },
        "families": results,
        "inputs": {
            str(path): {"sha256": value, "bytes": signature[0]}
            for path, (signature, value) in sorted(h.FILES.items())
        },
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {
                "passed": True,
                "checks": h.CHECKS,
                "totals": totals,
                "output": str(args.output),
            },
            indent=2,
        )
    )
    for name, result in results.items():
        for row in result["rows"]:
            print(
                name,
                row["workload"],
                "CPython speedup",
                round(row["cpython_speedup"], 4),
                "Rust gap %",
                round(row["rust_gap_percent"], 4),
                "old Relar change %",
                round(row["new_vs_baseline_time_change_percent"], 4),
                "old IQR overlap",
                row["iqr_overlap_vs_previous"],
                "Rust IQR overlap",
                row["iqr_overlap_vs_rust"],
            )


if __name__ == "__main__":
    main()
