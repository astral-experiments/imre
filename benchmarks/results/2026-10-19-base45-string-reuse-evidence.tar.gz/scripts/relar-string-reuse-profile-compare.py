"""Verify retained Base45 profiles and compare measured instruction/heap totals."""

import hashlib
import json
from pathlib import Path


OLD = Path("/tmp/relar-base45-profile")
NEW = Path("/tmp/relar-string-reuse-profile")
OUTPUT = Path("/tmp/relar-string-reuse-profile-comparison.json")


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def identity(path):
    return {"sha256": sha(path), "bytes": path.stat().st_size}


def read(path):
    return json.loads(path.read_text())


def metrics(entry, directory):
    profile = directory / ("profile.json" if entry["tool"] == "dhat" else "profile.callgrind")
    assert sha(profile) == entry["profile_sha256"]
    log = directory / ("valgrind.log" if (directory / "valgrind.log").exists() else "stderr.log")
    assert sha(log) == entry["log_sha256"]
    assert sha(directory / "input.bin") == entry["input_sha256"]
    assert sha(directory / "output.bin") == entry["output_sha256"]
    output = (directory / "output.bin").read_bytes()
    checksum = (len(output) + (output[0] + output[-1] if output else 0)) * entry["repetitions"]
    assert entry["stdout"] == f"OK\n{checksum}\n"
    if entry["tool"] == "dhat":
        raw = read(profile)
        assert raw["mode"] == "heap" and raw["tu"] == "instrs"
        result = {
            name: sum(point[key] for point in raw["pps"])
            for name, key in (
                ("total_allocated_bytes", "tb"),
                ("total_allocated_blocks", "tbk"),
                ("peak_live_bytes", "gb"),
                ("exit_live_bytes", "eb"),
            )
        }
    else:
        lines = profile.read_text().splitlines()
        events = [line.split()[1:] for line in lines if line.startswith("events:")]
        totals = [[int(value) for value in line.split()[1:]] for line in lines if line.startswith("summary:")]
        assert len(events) == len(totals) == 1
        result = {"instructions": totals[0][events[0].index("Ir")]}
    assert all(entry[key] == value for key, value in result.items())
    return result


def main():
    old, new = read(OLD / "summary.json"), read(NEW / "summary.json")
    assert old["guards_passed"] and new["guards_passed"] and new["complete"]
    manifest = read(NEW / "manifest.json")["files"]
    actual = {str(path.relative_to(NEW)) for path in NEW.rglob("*") if path.is_file()}
    assert actual == set(manifest) | {"manifest.json"}
    for relative, expected in manifest.items():
        assert identity(NEW / relative) == expected, relative
    for name, expected in new["guarded_inputs"].items():
        assert identity(Path(expected["path"])) == {key: expected[key] for key in ("sha256", "bytes")}, name
    assert len(old["profiles"]) == 6 and len(new["profiles"]) == 12
    prior_record = Path("/tmp/relar-base45-thinlto.json")
    assert sha(prior_record) == old["benchmark_record_sha256"]
    prior = read(prior_record)
    assert prior["binary_sha256"] == old["binary_sha256"]
    old_command = prior["compile_command"]
    assert sha(Path(old_command[old_command.index("-o") + 1])) == old["binary_sha256"]
    assert prior["source_and_tool_sha256"]["codec"] == new["timed_source_and_tool_sha256"]["codec"]
    assert all(old["tools"][tool] == new["guarded_inputs"][f"tool_{tool}"]["sha256"] for tool in ("dhat", "callgrind"))

    data = {}
    for engine, summary, directory in (("old_relar", old, OLD), ("new", new, NEW)):
        for entry in summary["profiles"]:
            name = engine if engine == "old_relar" else entry["engine"]
            label = entry["label"]
            dirname = f"{label}-{entry['tool']}" if engine == "old_relar" else f"{label}-{name}-{entry['tool']}"
            item = data.setdefault(label, {})
            item.setdefault(name, {}).update(metrics(entry, directory / dirname))
            comparable = {key: entry[key] for key in ("repetitions", "raw_bytes_per_process", "input_sha256", "output_sha256", "stdout")}
            if "workload" in item:
                assert item["workload"] == comparable
            item["workload"] = comparable
    for item in data.values():
        item["ratios"] = {
            metric: {
                "old_relar_over_new_relar": item["old_relar"][metric] / item["relar"][metric],
                "relar_reduction_percent": 100 * (1 - item["relar"][metric] / item["old_relar"][metric]),
                "new_relar_over_rust": item["relar"][metric] / item["rust"][metric],
            }
            for metric in ("total_allocated_bytes", "total_allocated_blocks", "peak_live_bytes", "instructions")
        }
    result = {
        "verified": True,
        "summaries": {"old": identity(OLD / "summary.json"), "new": identity(NEW / "summary.json")},
        "new_manifest": identity(NEW / "manifest.json"),
        "new_manifest_files_verified": len(manifest),
        "new_original_inputs_verified": len(new["guarded_inputs"]),
        "old_profiles_verified": len(old["profiles"]),
        "new_profiles_verified": len(new["profiles"]),
        "same_profile_inputs_outputs_repetitions_and_checksums": True,
        "same_upstream_codec_sha256": new["timed_source_and_tool_sha256"]["codec"],
        "same_dhat_and_callgrind_engine_sha256": True,
        "source_revisions": {"old": old["source_revision"], "new": new["source_revision"]},
        "workloads": data,
        "caveats": [
            "Instruction totals are instrumented Callgrind guest Ir counts, not CPU cycles, CPU time, or wall-time speedups.",
            "Each process handles 64 KiB of raw data; whole-process totals include startup, checksum, and file I/O. These profiles do not reproduce sustained benchmark batch sizes.",
            "DHAT measures requested heap allocation bytes and blocks, not copied bytes or RSS. Global peak uses allocation-point contributions at the global peak, not summed pointwise maxima.",
            "Historical and new Relar profiles cover the complete compiler/runtime change, not an isolated ablation of owned append. Program paths and startup details differ, so tiny changes are not meaningful.",
            "Both versions use the same upstream codec and profile input/output/checksum. Rust is an independent implementation with direct byte processing and output preallocation; it is not an identical-source comparison.",
            "Large encode cumulative allocation falls sharply, while peak live heap rises by about 10.7 percent. Lower total allocation does not imply lower peak memory.",
            "Decode allocation and instruction totals remain effectively unchanged; the separate decode gap to the Rust reference remains substantial.",
        ],
    }
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
    print(f"Verified {len(manifest)} retained files, {len(new['guarded_inputs'])} guarded originals, and all 18 profiles; saved {OUTPUT}")


if __name__ == "__main__":
    main()
