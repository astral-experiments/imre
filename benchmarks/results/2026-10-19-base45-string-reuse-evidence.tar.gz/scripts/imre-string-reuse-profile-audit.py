"""Independently verify retained Base45 profiles without running target binaries."""

import argparse
import base64
import hashlib
import json
import re
import subprocess
from collections import Counter
from pathlib import Path


def require(value, label):
    if not value:
        raise ValueError(label)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--profile", type=Path, default=Path("/tmp/imre-string-reuse-profile")
    )
    parser.add_argument(
        "--timing", type=Path, default=Path("/tmp/imre-string-reuse-thinlto.json")
    )
    parser.add_argument(
        "--benchmark-audit",
        type=Path,
        default=Path("/tmp/imre-string-reuse-audit.json"),
    )
    parser.add_argument(
        "--output", type=Path, default=Path("/tmp/imre-string-reuse-profile-audit.json")
    )
    args = parser.parse_args()
    root = args.profile.resolve()
    require(
        not args.output.resolve().is_relative_to(root),
        "audit output must not alter profiled artifact tree",
    )
    summary = read_json(root / "summary.json")
    manifest = read_json(root / "manifest.json")
    timing = read_json(args.timing)
    benchmark_audit = read_json(args.benchmark_audit)
    require(benchmark_audit["passed"] is True, "benchmark audit has not passed")
    require(
        summary["schema"] == 1
        and summary["complete"] is True
        and summary["guards_passed"] is True,
        "profile incomplete",
    )
    require(
        summary["source_dirty"] is False
        and summary["source_revision"] == timing["revision"],
        "profile source identity",
    )
    require(
        summary["timed_source_and_tool_sha256"] == timing["source_and_tool_sha256"],
        "timed source/tool hashes",
    )
    require(
        summary["timed_binary_sha256"]
        == {
            "imre": timing["binary_sha256"],
            "rust": timing["source_and_tool_sha256"]["rust"],
        },
        "timed executable hashes",
    )
    require(
        summary["timed_cpu"] == timing["cpu"]
        and summary["cpu_affinity"] == timing["cpu"]["affinity"],
        "CPU identity",
    )
    require(summary["raw_bytes_per_process"] == 65536, "profile batch size")
    require(
        digest(args.timing.read_bytes()) == summary["benchmark_record_sha256"],
        "profile benchmark record hash",
    )
    require(
        (root / "benchmark-record.json").read_bytes() == args.timing.read_bytes(),
        "retained benchmark bytes",
    )
    require(
        read_json(root / "rust-build-record.json") == timing["rust_build_record"],
        "Rust build record",
    )
    require(
        read_json(root / "tool-versions.json") == summary["tool_versions"],
        "tool versions",
    )

    verified = {}

    def verify(path, identity):
        path = path.resolve(strict=True)
        stat = path.stat()
        actual = {"sha256": digest(path.read_bytes()), "bytes": stat.st_size}
        require(actual == identity, f"retained file identity: {path}")
        verified[str(path)] = (stat.st_size, stat.st_mtime_ns, actual["sha256"])

    actual_files = {
        str(path.relative_to(root))
        for path in root.rglob("*")
        if path.is_file() and path.name != "manifest.json"
    }
    require(set(manifest["files"]) == actual_files, "manifest file inventory")
    for relative, identity in manifest["files"].items():
        path = root / relative
        require(
            path.resolve().is_relative_to(root),
            "manifest path escaped profile directory",
        )
        verify(path, identity)
    for name, value in summary["guarded_inputs"].items():
        verify(Path(value["path"]), {key: value[key] for key in ["sha256", "bytes"]})
        if name in ["binary_imre", "binary_rust"]:
            require(
                value["sha256"]
                == summary["timed_binary_sha256"][name.removeprefix("binary_")],
                "guarded binary differs from timing",
            )
    require(
        read_json(Path(summary["guarded_inputs"]["validation"]["path"]))
        == timing["validation"],
        "exact timed binary validation",
    )
    require(
        summary["guarded_inputs"]["llvm"]["sha256"] == timing["llvm_sha256"],
        "timed LLVM identity",
    )

    labels = ["encode-64", "encode-16384", "decode-bytes-16384"]
    expected_matrix = {
        (label, engine, tool)
        for label in labels
        for engine in ["imre", "rust"]
        for tool in ["dhat", "callgrind"]
    }
    require(
        Counter(
            (entry["label"], entry["engine"], entry["tool"])
            for entry in summary["profiles"]
        )
        == Counter(expected_matrix),
        "profile matrix",
    )
    rows = {label: {} for label in labels}
    annotation_count = 0
    for entry in summary["profiles"]:
        label, engine, tool = entry["label"], entry["engine"], entry["tool"]
        directory = root / f"{label}-{engine}-{tool}"
        workload = next(item for item in timing["workloads"] if item["label"] == label)
        payload = base64.b64decode(workload["input_base64"], validate=True)
        output = (directory / "output.bin").read_bytes()
        repetitions = 65536 // workload["raw_bytes"]
        require(
            entry["repetitions"] == repetitions
            and entry["raw_bytes_per_process"] == 65536,
            "profile repetition count",
        )
        require(
            entry["input_bytes_per_process"] == len(payload) * repetitions,
            "profile input throughput unit",
        )
        require(
            (directory / "input.bin").read_bytes() == payload
            and entry["input_sha256"] == digest(payload),
            "profile input identity",
        )
        require(
            entry["output_sha256"]
            == digest(output)
            == workload["expected_output_sha256"],
            "full profile output identity",
        )
        require(
            entry["output_bytes"] == len(output) == workload["expected_output_bytes"],
            "profile output length",
        )
        expected_stdout = (
            f"OK\n{(len(output) + output[0] + output[-1]) * repetitions}\n"
        )
        require(
            entry["stdout"]
            == (directory / "stdout.txt").read_text()
            == expected_stdout,
            "profile output checksum",
        )
        require(
            entry["stdout_sha256"] == digest(expected_stdout.encode()), "stdout hash"
        )
        require(
            entry["returncode"] == 0
            and (directory / "process-stderr.txt").read_bytes() == b"",
            "profile process status",
        )
        command_record = read_json(directory / "command.json")
        require(
            command_record["command"] == entry["command"]
            and command_record["cwd"] == str(directory)
            and command_record["environment"] == summary["environment"],
            "profile command record",
        )
        expected_program = [
            summary["guarded_inputs"][f"binary_{engine}"]["path"],
            workload["operation"],
            str(directory / "input.bin"),
            str(directory / "output.bin"),
            str(repetitions),
        ]
        require(
            entry["command"][-5:] == expected_program
            and f"--tool={tool}" in entry["command"]
            and "--error-exitcode=97" in entry["command"],
            "profile executable or arguments",
        )
        require(
            set(entry["files"])
            == {
                str(path.relative_to(root))
                for path in directory.iterdir()
                if path.is_file()
            },
            "per-profile file inventory",
        )
        for relative, identity in entry["files"].items():
            require(
                identity == manifest["files"][relative], "per-profile manifest identity"
            )
        raw_path = directory / (
            "profile.json" if tool == "dhat" else "profile.callgrind"
        )
        require(
            entry["profile_sha256"] == digest(raw_path.read_bytes()), "raw profile hash"
        )
        log = (directory / "valgrind.log").read_text()
        require(entry["log_sha256"] == digest(log.encode()), "profile log hash")
        row = rows[label].setdefault(engine, {})
        if tool == "dhat":
            raw = read_json(raw_path)
            require(
                raw["dhatFileVersion"] == 2
                and raw["mode"] == "heap"
                and raw["tu"] == "instrs",
                "DHAT schema",
            )
            require(
                raw["cmd"] == " ".join(expected_program), "DHAT executable/arguments"
            )
            for field, metric in [
                ("tb", "total_allocated_bytes"),
                ("tbk", "total_allocated_blocks"),
                ("gb", "peak_live_bytes"),
                ("gbk", "peak_live_blocks"),
                ("eb", "exit_live_bytes"),
                ("ebk", "exit_live_blocks"),
            ]:
                value = sum(point[field] for point in raw["pps"])
                require(value == entry[metric], f"DHAT recomputed {metric}")
                row[metric] = value
            for log_name, metric_bytes, metric_blocks in [
                ("Total", "total_allocated_bytes", "total_allocated_blocks"),
                ("At t-gmax", "peak_live_bytes", "peak_live_blocks"),
                ("At t-end", "exit_live_bytes", "exit_live_blocks"),
            ]:
                matches = re.findall(
                    re.escape(log_name) + r":\s+([\d,]+) bytes in ([\d,]+) blocks", log
                )
                require(len(matches) == 1, "DHAT log totals missing/duplicated")
                require(
                    tuple(int(value.replace(",", "")) for value in matches[0])
                    == (row[metric_bytes], row[metric_blocks]),
                    "DHAT raw/log totals disagree",
                )
            top = [
                {
                    "bytes": point["tb"],
                    "blocks": point["tbk"],
                    "frames": [raw["ftbl"][index] for index in point["fs"]],
                }
                for point in sorted(
                    raw["pps"], key=lambda point: point["tb"], reverse=True
                )[:8]
            ]
            require(top == entry["top_allocation_stacks"], "DHAT top allocation stacks")
            row["top_allocation_stacks"] = top[:3]
        else:
            raw = raw_path.read_text()
            require(
                re.findall(r"^cmd:\s*(.*)$", raw, re.MULTILINE)
                == [" ".join(expected_program)],
                "Callgrind executable/arguments",
            )
            require(
                re.findall(r"^events:\s*(.*)$", raw, re.MULTILINE) == ["Ir"],
                "Callgrind event inventory",
            )
            values = re.findall(r"^(?:summary|totals):\s*(\d+)$", raw, re.MULTILINE)
            require(
                len(values) == 2 and values[0] == values[1],
                "Callgrind raw summary/totals differ",
            )
            instructions = int(values[0])
            require(
                instructions > 0
                and entry["instructions"] == instructions
                and entry["events"] == {"Ir": instructions},
                "Callgrind instructions",
            )
            log_counts = re.findall(r"Collected\s*:\s*([\d,]+)", log)
            require(
                len(log_counts) == 1
                and int(log_counts[0].replace(",", "")) == instructions,
                "Callgrind log total",
            )
            row["instructions"] = instructions
            require(
                {annotation["inclusive"] for annotation in entry["annotations"]}
                == {"no", "yes"},
                "annotation inventory",
            )
            for annotation in entry["annotations"]:
                inclusive = annotation["inclusive"]
                command = [
                    summary["guarded_inputs"]["tool_callgrind_annotate"]["path"],
                    "--auto=no",
                    f"--inclusive={inclusive}",
                    "--threshold=100",
                    str(raw_path),
                ]
                require(
                    annotation["command"] == command and annotation["returncode"] == 0,
                    "annotation command/status",
                )
                completed = subprocess.run(
                    command,
                    capture_output=True,
                    input=b"",
                    cwd=directory,
                    timeout=30,
                    check=True,
                )
                require(
                    completed.stdout
                    == (
                        directory / f"functions-inclusive-{inclusive}.txt"
                    ).read_bytes(),
                    "fresh annotation differs from retained output",
                )
                require(
                    completed.stderr
                    == (
                        directory / f"functions-inclusive-{inclusive}-stderr.txt"
                    ).read_bytes()
                    == b"",
                    "annotation stderr",
                )
                require(
                    digest(completed.stdout) == annotation["stdout_sha256"]
                    and digest(completed.stderr) == annotation["stderr_sha256"],
                    "annotation hashes",
                )
                annotation_count += 1
                if inclusive == "no":
                    hotspots = re.findall(
                        r"^\s*([\d,]+)\s+\(\s*([\d.]+)%\)\s+(.*)$",
                        completed.stdout.decode(),
                        re.MULTILINE,
                    )
                    row["top_exclusive_functions"] = [
                        {
                            "instructions": int(count.replace(",", "")),
                            "percent": float(percent),
                            "function": name,
                        }
                        for count, percent, name in hotspots
                        if name != "PROGRAM TOTALS"
                    ][:5]

    for path, (size, mtime, _) in verified.items():
        current = Path(path).stat()
        require(
            (current.st_size, current.st_mtime_ns) == (size, mtime),
            f"artifact changed during audit: {path}",
        )
    result = {
        "passed": True,
        "script_sha256": digest(Path(__file__).read_bytes()),
        "summary_sha256": digest((root / "summary.json").read_bytes()),
        "manifest_sha256": digest((root / "manifest.json").read_bytes()),
        "benchmark_audit_sha256": digest(args.benchmark_audit.read_bytes()),
        "timed_binary_sha256": summary["timed_binary_sha256"],
        "verified_files": len(verified),
        "profiles_checked": len(summary["profiles"]),
        "annotations_recomputed": annotation_count,
        "raw_bytes_per_profiled_process": 65536,
        "allocation_unit": "DHAT requested heap bytes/blocks, whole process; gb/gbk give global peak contributions",
        "instruction_unit": "Callgrind instrumented guest instructions, whole process; not timing or CPU cycles",
        "tables": rows,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                key: result[key]
                for key in [
                    "passed",
                    "verified_files",
                    "profiles_checked",
                    "annotations_recomputed",
                ]
            }
        )
    )


if __name__ == "__main__":
    main()
