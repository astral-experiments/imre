"""Package frozen Base45 evidence without running builds, programs, or profilers."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


ROOT = Path('/home/dev-user/code/oss/relar')
RESULTS = ROOT / 'benchmarks/results'
PREFIX = '2026-10-19-base45-string-reuse'
MEASURED = '3349b85efc78e5ac09a92d8d367d914264679067'
TMP = Path('/tmp')
VALIDATION = TMP / 'relar-string-reuse-validation'
FILES = {}
MODES = {}
ORIGINALS = {}
EXTERNAL = {}
PUBLIC = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'sha256': value, 'bytes': path.stat().st_size}


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def read(path):
    return json.loads(path.read_text())


def add(name, data, mode=0o644):
    assert name not in FILES, name
    assert not name.startswith('/') and '..' not in Path(name).parts, name
    assert not data.startswith((b'\x7fELF', b'!<arch>\n', b'!<thin>\n')), name
    FILES[name] = data
    MODES[name] = mode


def external(path, reason, expected=None):
    path = path.resolve(strict=True)
    actual = identity(path)
    if expected is not None:
        assert actual['sha256'] == expected, path
    item = EXTERNAL.setdefault(str(path), {**actual, 'reasons': []})
    assert {key: item[key] for key in actual} == actual
    if reason not in item['reasons']:
        item['reasons'].append(reason)


def retain(name, path):
    path = path.resolve(strict=True)
    with path.open('rb') as stream:
        magic = stream.read(8)
    if magic.startswith((b'\x7fELF', b'!<arch>\n', b'!<thin>\n')):
        external(path, f'Native artifact excluded from archive member {name}')
        return
    data = path.read_bytes()
    ORIGINALS[str(path)] = {'sha256': digest(data), 'bytes': len(data)}
    add(name, data)


def tree(prefix, directory):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            retain(f'{prefix}/{path.relative_to(directory)}', path)


def snapshot(revision, paths, prefix):
    archive = subprocess.run(
        ['git', 'archive', '--format=tar', revision, '--', *paths],
        cwd=ROOT, capture_output=True, check=True,
    ).stdout
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for member in tar:
            if member.isdir():
                continue
            assert member.isfile(), member.name
            add(f'{prefix}/{member.name}', tar.extractfile(member).read(), member.mode)


def public(name, data):
    target = f'{PREFIX}-{name}'
    assert target not in PUBLIC
    PUBLIC[target] = data


def main():
    assert ROOT.resolve() == ROOT
    common = subprocess.run(['git', 'rev-parse', '--git-common-dir'], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
    build_path = TMP / 'relar-string-reuse-frozen/build.json'
    build = read(build_path)
    assert build['source_matches_revision'] and build['revision'].startswith('31bffb7')
    compiler_revision = build['revision']
    records = {}
    for name in ('normal', 'thinlto', 'sustained', 'before-after'):
        path = TMP / f'relar-string-reuse-{name}.json'
        retain(f'records/{name}.json', path)
        value = records[name] = read(path)
        assert value['input_guards_passed'] and value['revision'] == MEASURED and value['dirty'] is False
        raw = FILES[f'records/{name}.json']
        compressed = gzip.compress(raw, mtime=0)
        assert gzip.decompress(compressed) == raw
        public(f'{name}.json.gz', compressed)
    for name, path in (
        ('build', build_path),
        ('audit', TMP / 'relar-string-reuse-audit.json'),
        ('profile', TMP / 'relar-string-reuse-profile/summary.json'),
        ('profile-comparison', TMP / 'relar-string-reuse-profile-comparison.json'),
        ('profile-audit', TMP / 'relar-string-reuse-profile-audit.json'),
    ):
        retain(f'records/{name}.json', path)
        public(f'{name}.json', FILES[f'records/{name}.json'])
    audit = json.loads(FILES['records/audit.json'])
    profile_audit = json.loads(FILES['records/profile-audit.json'])
    assert audit['passed'] and profile_audit['passed']
    for name in ('normal', 'thinlto', 'sustained'):
        assert audit['records'][name]['sha256'] == digest(FILES[f'records/{name}.json'])
    assert profile_audit['summary_sha256'] == digest(FILES['records/profile.json'])
    assert profile_audit['benchmark_audit_sha256'] == digest(FILES['records/audit.json'])
    assert audit['before_after']['sha256'] == digest(FILES['records/before-after.json'])

    names = subprocess.run(['git', 'ls-tree', '-r', '--name-only', MEASURED], cwd=ROOT, capture_output=True, text=True, check=True).stdout.splitlines()
    names = [name for name in names if not name.startswith('benchmarks/results/')]
    snapshot(MEASURED, names, 'source')
    compiler_names = [*build['source_sha256'], 'LICENSE-MIT', 'LICENSE-APACHE']
    snapshot(compiler_revision, compiler_names, 'compiler-source')
    for name, expected in build['source_sha256'].items():
        assert digest(FILES[f'compiler-source/{name}']) == expected, name
        assert FILES[f'source/{name}'] == FILES[f'compiler-source/{name}'], name
    add('source-provenance.json', encoded({
        'measured_source_revision': MEASURED,
        'compiler_source_revision': compiler_revision,
        'measured_source_files': len(names),
        'compiler_source_files': len(compiler_names),
        'compiler_source_matches_measured_snapshot': True,
        'selection': 'All files tracked at the clean measured commit except benchmarks/results historical evidence; complete tests and fixtures are included.',
        'compiler_selection': 'Every compiler/runtime/build source hash in the frozen build record plus both project licenses.',
        'checkout': str(ROOT), 'git_common_directory': str((ROOT / common).resolve()),
    }))

    for item in build['artifacts'].values():
        external(Path(item['path']), 'Frozen compiler/runtime artifact identified by build record', item['sha256'])
    for item in build['tools'].values():
        external(Path(item['path']), 'Build tool identified by frozen build record', item['sha256'])
    for name in ('normal', 'thinlto', 'sustained'):
        record = records[name]
        command = record['compile_command']
        binary = Path(command[command.index('-o') + 1])
        llvm = Path(command[command.index('--emit-llvm') + 1])
        external(binary, f'Exact timed {name} Relar executable', record['binary_sha256'])
        assert identity(llvm)['sha256'] == record['llvm_sha256']
        tree(f'timing/{name}', binary.parent)
        assert read(binary.parent / 'validation.json') == record['validation']
    tree('timing/before-after', TMP / 'relar-string-reuse-before-after')
    for name in ('normal', 'thinlto', 'sustained', 'before-after'):
        retain(f'timing/{name}.log', TMP / f'relar-string-reuse-{name}.log')

    tree('validation', VALIDATION)
    for name in ('focused', 'asan-focused', 'asan-focused-untraced'):
        tree(f'pre-freeze-validation/{name}', TMP / f'relar-string-reuse-{name}')
    add('pre-freeze-validation/README.json', encoded({
        'scope': 'Earlier focused development checks, retained for transparency and excluded from all final measured-revision validation totals.',
        'focused': 'The first guarded-range fixture was rejected for unsupported builtin arguments. The final committed fixture and complete ordinary/ThinLTO/sanitizer runs pass.',
        'asan-focused': 'Initial sanitizer execution reported that LeakSanitizer does not work under ptrace. Original failures and tracebacks are retained.',
        'asan-focused-untraced': 'The focused sanitizer suites subsequently passed outside tracing; the complete final ASan/LeakSanitizer O0/O1 suite is retained separately under validation/asan/.',
        'provenance_limit': 'These preliminary checks predate the frozen measured revision. Their argv/stdout/stderr are retained, but their then-current compiler and fixture source bytes were not separately frozen.',
    }))
    apps = read(VALIDATION / 'applications/index.json')
    assert apps['status'] == 'passed' and apps['input_guards_passed'] and apps['artifact_hash_verification_passed']
    for relative, expected in apps['artifact_sha256'].items():
        path = VALIDATION / 'applications' / relative
        assert identity(path)['sha256'] == expected, relative
    for path, expected in apps['source_and_tool_sha256'].items():
        path = Path(path)
        assert identity(path)['sha256'] == expected, path
        with path.open('rb') as stream:
            magic = stream.read(8)
        if magic.startswith((b'\x7fELF', b'!<arch>\n', b'!<thin>\n')):
            external(path, 'Application validation dependency', expected)
        elif path.is_relative_to(ROOT) and f'source/{path.relative_to(ROOT)}' in FILES:
            assert digest(FILES[f'source/{path.relative_to(ROOT)}']) == expected, path

    profile = json.loads(FILES['records/profile.json'])
    assert profile['complete'] and profile['guards_passed']
    for name, item in profile['guarded_inputs'].items():
        path = Path(item['path'])
        assert identity(path) == {key: item[key] for key in ('sha256', 'bytes')}, name
        if name.startswith(('binary_', 'tool_')):
            external(path, f'Profile guarded dependency {name}', item['sha256'])
    tree('profiles', TMP / 'relar-string-reuse-profile')
    for flavor, dirname in (('normal', 'base45-reference-dev'), ('thinlto', 'base45-reference-thinlto-dev')):
        directory = ROOT / 'benchmarks/local' / dirname
        rust_record = read(directory / 'build-record.json')
        assert rust_record == records[flavor]['rust_build_record']
        assert identity(directory / 'build-record.json')['sha256'] == records[flavor]['source_and_tool_sha256']['rust_build_record']
        external(directory / 'base45-reference', f'Timed {flavor} Rust reference', records[flavor]['source_and_tool_sha256']['rust'])
        retain(f'rust/{flavor}-build-record.json', directory / 'build-record.json')
        if (directory / 'validation.json').exists():
            retain(f'rust/{flavor}-validation.json', directory / 'validation.json')

    families = {}
    original_failure = None
    for name, expected_count, levels in (('normal', 1414, ['0', '3']), ('thinlto', 1064, ['3']), ('asan', 1414, ['0', '1'])):
        runs = read(VALIDATION / name / 'results.json')
        assert len(runs) == 23
        effective = {run['suite']: run for run in runs}
        retries = []
        if name == 'thinlto':
            original_failure = effective['floats']
            assert original_failure['returncode'] != 0 and 'TimeoutExpired' in original_failure['stderr']
            retries = read(VALIDATION / 'thinlto-retry/results.json')
            assert len(retries) == 1 and retries[0]['suite'] == 'floats'
            effective['floats'] = retries[0]
        assert all(run['returncode'] == 0 and not run['stderr'] for run in effective.values())
        counts = {}
        for suite, run in effective.items():
            if suite == 'base45':
                assert len(run['stdout'].splitlines()) == len(levels)
                assert all('323 upstream native calls, 289 differential cases, and 2 compile-time type rejections' in line for line in run['stdout'].splitlines())
            else:
                match = re.search(r'(?:Passed )?(\d+).*checks', run['stdout'])
                assert match, run
                counts[suite] = int(match[1])
        assert sum(counts.values()) == expected_count
        families[name] = {
            'optimization_levels': levels, 'sanitizers': ['AddressSanitizer', 'LeakSanitizer'] if name == 'asan' else [],
            'suites': len(runs), 'passed_after_recorded_retries': True,
            'language_checks_excluding_base45': sum(counts.values()), 'counts': counts,
            'original_results': runs, 'retry_results': retries,
        }
    unit_log = (VALIDATION / 'rust-tests.log').read_text()
    unit_counts = [int(value) for value in re.findall(r'test result: ok\. (\d+) passed', unit_log)]
    assert sum(unit_counts) == 116 and 46 in unit_counts and 70 in unit_counts
    rust312 = read(VALIDATION / 'rust-reference-python312.json')
    assert rust312['python'].startswith('3.12.')
    assert len(rust312['rust']['differential_cases']) == 295
    assert rust312['rust']['exact_message_cases'] == 291
    assert len(rust312['rust']['diagnostic_boundaries']) == 4
    assert rust312['rust']['binary_sha256'] == records['normal']['source_and_tool_sha256']['rust']
    add('validation/rust-reference-python312-command.json', encoded({
        'command': ['python3', '-I', '-B', 'benchmarks/base45_validate.py', '--rust', 'benchmarks/local/base45-reference-dev/base45-reference', '--output', '/tmp/relar-string-reuse-validation/rust-reference-python312.json'],
        'cwd': str(ROOT), 'returncode': 0,
        'observed_terminal_output': 'Passed 295 Rust differential checks\n',
        'provenance': 'Invocation, exit status and combined terminal output transcribed after execution from the recorded terminal observation. No redirected stdout/stderr logs were retained; stream separation is not asserted.',
    }))
    validation = {
        'compiler_source_revision': compiler_revision, 'application_source_revision': MEASURED,
        'rust_unit_tests': {'compiler': 46, 'runtime': 70, 'total': 116, 'log': 'validation/rust-tests.log'},
        'unit_and_clippy_command_provenance': 'Original unit-test and Clippy argv were not retained. Their full logs are included; the following commands are reproduction suggestions, not reconstructed observations.',
        'reproduction_commands': [
            ['sh', 'scripts/relar-cargo.sh', 'test', '--workspace', '--locked'],
            ['sh', 'scripts/relar-cargo.sh', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings'],
            ['sh', 'scripts/relar-cargo.sh', 'fmt', '--all', '--check'],
        ],
        'families': families,
        'language_checks_excluding_base45': sum(item['language_checks_excluding_base45'] for item in families.values()),
        'base45_per_optimization_mode': {'upstream_test_methods': 5, 'upstream_native_calls': 323, 'differential_cases': 289, 'compile_time_type_rejections': 2},
        'base45_modes': ['ordinary O0', 'ordinary O3', 'ThinLTO O3', 'ASan/LSan O0', 'ASan/LSan O1'],
        'applications': {'status': apps['status'], 'case_summary': apps['case_summary'], 'index': 'validation/applications/index.json', 'index_sha256': digest(FILES['validation/applications/index.json'])},
        'rust_python312': {'python': rust312['python'], 'cases': 295, 'exact_message_cases': 291, 'declared_diagnostic_boundaries': 4, 'binary_sha256': rust312['rust']['binary_sha256'], 'record': 'validation/rust-reference-python312.json', 'record_sha256': digest(FILES['validation/rust-reference-python312.json']), 'command': 'validation/rust-reference-python312-command.json'},
        'caveats': [
            'The first ThinLTO float suite timed out while compiling; the original failed result and traceback are retained. The isolated retry passed all 35 float checks and supplies the effective ThinLTO count.',
            'Language counts include compile-time rejections and combine the listed optimization levels; they are not all distinct source programs.',
            'The 935 application cases plus 135 repeated dependency graph checks represent 1070 Relar application executions.',
            'Sanitizers cover generated native code and the custom runtime. The prebuilt Rust standard library is not instrumented.',
            'The Rust codec reference has four declared Unicode representation-message boundaries; Relar retains exact CPython checking for those cases.',
        ],
    }
    assert validation['language_checks_excluding_base45'] == 3892
    assert apps['case_summary']['application_cases_excluding_repeated_dependency_graph_corpus'] == 935
    assert apps['case_summary']['relar_case_executions_including_dependency_graph_replay'] == 1070
    add('records/validation.json', encoded(validation))
    public('validation.json', FILES['records/validation.json'])

    for suffix in ('bench', 'freeze', 'before-after', 'profile', 'profile-compare', 'audit', 'profile-audit', 'run-suites', 'publish-evidence'):
        path = TMP / f'relar-string-reuse-{suffix}.py'
        retain(f'scripts/{path.name}', path)
    retain('scripts/relar-cargo.sh', TMP / 'relar-cargo.sh')
    assert digest(FILES['scripts/relar-cargo.sh']) == build['cargo_wrapper']['sha256']
    for name, path in (
        ('normal.json', TMP / 'relar-base45-normal.json'),
        ('thinlto.json', TMP / 'relar-base45-thinlto.json'),
        ('build.json', TMP / 'relar-base45-frozen/build.json'),
        ('profile.json', TMP / 'relar-base45-profile/summary.json'),
        ('evidence-manifest.json', RESULTS / '2026-10-19-base45-evidence-manifest.json'),
    ):
        retain(f'historical/{name}', path)
    historical_manifest = json.loads(FILES['historical/evidence-manifest.json'])
    assert identity(RESULTS / historical_manifest['archive'])['sha256'] == historical_manifest['archive_sha256']
    add('historical/archive-reference.json', encoded({
        'repository_path': f'benchmarks/results/{historical_manifest["archive"]}',
        'sha256': historical_manifest['archive_sha256'],
        'contents': 'Historical raw DHAT/Callgrind profiles, logs, annotations, measured source and validation remain in this previously committed archive. This new archive includes the old raw benchmark JSON, build manifest and profile summary needed for comparisons.',
    }))

    add('external-artifacts.json', encoded({
        'policy': 'Native executables, runtime archives, toolchains and interpreters remain external. Paths identify the measured environment; hashes identify exact bytes. Script launchers listed as tools are also external unless separately retained under scripts/.',
        'artifacts': EXTERNAL,
    }))
    add('original-inputs.json', encoded(ORIGINALS))
    add('PACKAGING.json', encoded({
        'script': 'scripts/relar-string-reuse-publish-evidence.py',
        'measured_source_revision': MEASURED, 'compiler_source_revision': compiler_revision,
        'archives_are_deterministic': 'Members sorted by name; ownership and timestamps zeroed; gzip timestamp zero.',
        'scope': 'Retained source and test fixtures, raw benchmark and correctness records, complete validation logs including failed attempt and retry, generated LLVM, raw profiles and annotations, independent audits, Rust provenance, original command records and reproduction scripts.',
        'reproduction_note': 'Original commands retain absolute paths from the measurement host. Relocate paths or recreate the pinned checkout and external tools to rerun them. Original unit/Clippy argv was not retained; validation.json distinguishes reproduction suggestions from observations.',
        'excluded': 'Historical benchmark reports/evidence are not duplicated in source/. Native ELF/ar artifacts and Python bytecode caches are excluded. Historical raw profiles are referenced by the prior archive hash.',
    }))
    for path, expected in ORIGINALS.items():
        assert identity(Path(path)) == expected, path
    for path, expected in EXTERNAL.items():
        assert identity(Path(path)) == {key: expected[key] for key in ('sha256', 'bytes')}, path

    tar_bytes = io.BytesIO()
    with tarfile.open(fileobj=tar_bytes, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, data in sorted(FILES.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = MODES[name]
            member.mtime = member.uid = member.gid = 0
            tar.addfile(member, io.BytesIO(data))
    compressed = gzip.compress(tar_bytes.getvalue(), mtime=0)
    archive_name = f'{PREFIX}-evidence.tar.gz'
    PUBLIC[archive_name] = compressed
    manifest = {
        'archive': archive_name, 'archive_sha256': digest(compressed),
        'archive_bytes': len(compressed), 'member_count': len(FILES),
        'uncompressed_member_bytes': sum(map(len, FILES.values())),
        'measured_source_revision': MEASURED, 'compiler_source_revision': compiler_revision,
        'files': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(FILES.items())},
        'public_artifacts': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(PUBLIC.items())},
    }
    PUBLIC[f'{PREFIX}-evidence-manifest.json'] = encoded(manifest)
    # Verify the bytes that will be published, not only the in-memory source map.
    with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(FILES) and len({member.name for member in members}) == len(FILES)
        for member in members:
            assert member.isfile()
            data = tar.extractfile(member).read()
            assert data == FILES[member.name]
            assert manifest['files'][member.name] == {'bytes': len(data), 'sha256': digest(data)}
    for name in ('normal', 'thinlto', 'sustained', 'before-after'):
        assert gzip.decompress(PUBLIC[f'{PREFIX}-{name}.json.gz']) == FILES[f'records/{name}.json']
    previous_manifest_path = RESULTS / f'{PREFIX}-evidence-manifest.json'
    previous_manifest = read(previous_manifest_path) if previous_manifest_path.exists() else None
    if previous_manifest:
        assert previous_manifest['archive'] == archive_name
        for name, expected in previous_manifest['public_artifacts'].items():
            assert identity(RESULTS / name) == expected, f'Previously packaged artifact changed: {name}'
    for name, data in PUBLIC.items():
        target = RESULTS / name
        if target.exists() and target.read_bytes() != data:
            assert previous_manifest is not None and (name in previous_manifest['public_artifacts'] or name == previous_manifest_path.name), f'Refusing to replace unrecognized evidence: {target}'
        target.write_bytes(data)
        assert target.read_bytes() == data
    summary = {
        'passed': True, 'archive': str(RESULTS / archive_name), 'archive_bytes': len(compressed),
        'archive_sha256': digest(compressed), 'member_count': len(FILES),
        'uncompressed_member_bytes': manifest['uncompressed_member_bytes'],
        'external_artifacts': len(EXTERNAL), 'original_files_verified': len(ORIGINALS),
        'source_files': len(names), 'compiler_source_files': len(compiler_names),
        'generated_paths': [str(RESULTS / name) for name in PUBLIC],
    }
    (TMP / 'relar-string-reuse-packaging-verification.json').write_bytes(encoded(summary))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
