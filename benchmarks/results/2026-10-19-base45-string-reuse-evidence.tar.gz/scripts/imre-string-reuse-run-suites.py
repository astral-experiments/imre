import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/dev-user/code/oss/imre')
PYTHON = '/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
COMPILER = '/home/dev-user/.cache/imre/target/imre-integrated/imre'
SUITES = 'differential imports classes containers comprehensions fstrings calls expressions floats bytes matching assignments truthiness loop_else unpacking primitives string_reuse unions module_values exceptions io files base45'.split()

parser = argparse.ArgumentParser()
parser.add_argument('--runtime', required=True)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--workers', type=int, default=4)
parser.add_argument('--suites', nargs='+', default=SUITES)
parser.add_argument('--flags', nargs=argparse.REMAINDER, default=[])
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)

def run(suite):
    command = [PYTHON, '-I', '-B', str(ROOT / 'tests' / (suite + '.py')), '--compiler', COMPILER,
               '--runtime', args.runtime, '--clang', 'clang-18', '--python', PYTHON, *args.flags]
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=900,
                            check=False, env={**os.environ, 'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1'})
    (args.output / (suite + '.log')).write_text(result.stdout + result.stderr)
    record = {'suite': suite, 'command': command, 'returncode': result.returncode,
              'seconds': time.monotonic() - start, 'stdout': result.stdout, 'stderr': result.stderr}
    print(suite, result.returncode, result.stdout.strip().splitlines()[-1:] or result.stderr[-200:], flush=True)
    return record

records = []
with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
    for result in pool.map(run, args.suites):
        records.append(result)
        (args.output / 'results.json').write_text(json.dumps(records, indent=2) + '\n')
assert all(record['returncode'] == 0 for record in records), 'See per-suite logs'
