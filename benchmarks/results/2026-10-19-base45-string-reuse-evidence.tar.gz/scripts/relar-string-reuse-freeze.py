"""Retain the exact final compiler/runtime artifacts and their source identities."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from datetime import datetime, timezone

ROOT = Path('/home/dev-user/code/oss/relar')
TARGET = Path('/home/dev-user/.cache/relar/target')
DESTINATION = Path('/tmp/relar-string-reuse-frozen')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(*command):
    return subprocess.check_output(command, cwd=ROOT, text=True).strip()


parser = argparse.ArgumentParser()
parser.add_argument('--revision', required=True)
args = parser.parse_args()
revision = run('git', 'rev-parse', args.revision)
source_paths = [ROOT / name for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml')]
source_paths.extend(sorted((ROOT / 'crates').rglob('*.rs')))
source_paths.extend(sorted((ROOT / 'crates').rglob('Cargo.toml')))
hashes = {str(path.relative_to(ROOT)): sha(path) for path in source_paths}
for name, digest in hashes.items():
    committed = subprocess.check_output(['git', 'show', revision + ':' + name], cwd=ROOT)
    assert hashlib.sha256(committed).hexdigest() == digest, name
DESTINATION.mkdir(exist_ok=False)
artifacts = {}
for label, source, filename in (
    ('compiler', TARGET / 'relar-integrated/relar', 'relar'),
    ('normal_runtime', TARGET / 'relar-integrated/librelar_runtime.a', 'normal_runtime.a'),
    ('thinlto_runtime', TARGET / 'relar-truthiness-lto/librelar_runtime.a', 'thinlto_runtime.a'),
    ('asan_runtime', TARGET / 'x86_64-unknown-linux-gnu/relar-truthiness-asan/librelar_runtime.a', 'asan_runtime.a'),
):
    destination = DESTINATION / filename
    before = sha(source)
    shutil.copy2(source, destination)
    assert sha(source) == before == sha(destination)
    artifacts[label] = {'path': str(destination), 'sha256': before, 'bytes': destination.stat().st_size}
tool_paths = {
    name: Path(run('rustup', 'which', '--toolchain', 'ohm', name)).resolve()
    for name in ('cargo', 'rustc')
}
tool_paths['clang'] = Path(shutil.which('clang-18')).resolve()
lld = Path('/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld')
tool_paths['lld'] = lld.resolve()
wrapper = Path('/tmp/relar-cargo.sh')
record = {
    'captured_at_utc': datetime.now(timezone.utc).isoformat(),
    'revision': revision,
    'source_matches_revision': True,
    'build_note': 'Artifacts were built before committing these exact compiler/runtime source bytes. Source hashes are verified against the retained revision; unrelated benchmark changes were present in the worktree during the builds.',
    'artifacts': artifacts,
    'source_sha256': hashes,
    'tools': {name: {'path': str(path), 'sha256': sha(path)} for name, path in tool_paths.items()},
    'rustc': run('rustc', '+ohm', '--version', '--verbose'),
    'cargo': run('sh', str(wrapper), '--version'),
    'clang': run('clang-18', '--version'),
    'lld': run(str(lld), '--version'),
    'cargo_wrapper': {'path': str(wrapper), 'sha256': sha(wrapper), 'contents': wrapper.read_text()},
    'build_commands': {
        'compiler_and_normal_runtime': ['sh', str(wrapper), 'build', '--workspace', '--profile', 'relar-integrated', '--config', 'profile.relar-integrated.inherits="release"', '--locked'],
        'thinlto_runtime': ['env', 'RUSTFLAGS=-Clinker-plugin-lto', 'sh', str(wrapper), 'build', '-p', 'relar-runtime', '--profile', 'relar-truthiness-lto', '--config', 'profile.relar-truthiness-lto.inherits="release"', '--locked'],
        'asan_runtime': ['env', 'RUSTC_BOOTSTRAP=1', 'RUSTFLAGS=-Zsanitizer=address -Cforce-frame-pointers=yes', 'sh', str(wrapper), 'build', '-p', 'relar-runtime', '--target', 'x86_64-unknown-linux-gnu', '--profile', 'relar-truthiness-asan', '--config', 'profile.relar-truthiness-asan.inherits="release"', '--locked'],
    },
    'notes': 'The Ohm experimental defaults were disabled. Target and shared build directories are distinct. ThinLTO uses matching LLVM22 LLD; generated LLVM is lowered by Clang18.',
}
(DESTINATION / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
print(DESTINATION / 'build.json')
