"""Validate frozen Imre applications with retained reference provenance."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import traceback

ROOT = Path('/home/dev-user/code/oss/imre')
HERE = Path(__file__).resolve().parent
TOOLS = Path('/home/dev-user/.cache/imre/target/imre-integrated')
COMPILER = TOOLS / 'imre'
RUNTIME = TOOLS / 'libimre_runtime.a'
PYTHON = Path('/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14')
CLANG = Path(shutil.which('clang-18')).resolve()

SPECS = {
    'route': ('route_planner.py', 'validate.py', None, None),
    'dependency': ('dependency_planner/__main__.py', 'dependency_validate.py', 'dependency_planner', 'dependency-reference-tuned-lto'),
    'incremental': ('incremental_planner/__main__.py', 'incremental_validate.py', 'incremental_planner', 'incremental-reference-normal-final'),
    'batch': ('batch_planner/__main__.py', 'batch_validate.py', 'incremental_planner', 'batch-reference-normal-final'),
    'manifest': ('manifest_planner/__main__.py', 'manifest_validate.py', 'incremental_planner', 'manifest-reference-normal-final'),
    'inventory': ('inventory_reconciliation/__main__.py', 'inventory_validate.py', 'inventory_reconciliation', 'keyword-arguments-reference-final-normal'),
}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def reference(name, package, folder):
    directory = ROOT / 'benchmarks/local' / folder
    path = directory / 'build-record.json'
    record = json.loads(path.read_text())
    source = ROOT / 'benchmarks/reference' / package
    actual = {
        str(path.relative_to(source)): digest(path)
        for path in [source / 'Cargo.toml', source / 'Cargo.lock', *sorted((source / 'src').rglob('*.rs'))]
    }
    differences = {}
    for filename in sorted(actual.keys() | record['sources'].keys()):
        old = record['source_contents'].get(filename, '')
        if filename in record['sources']:
            assert hashlib.sha256(old.encode()).hexdigest() == record['sources'][filename], filename
        current = (source / filename).read_text() if filename in actual else ''
        if old != current:
            differences[filename] = ''.join(difflib.unified_diff(old.splitlines(True), current.splitlines(True), fromfile='retained/' + filename, tofile='current/' + filename))
    binaries = {}
    for mode, metadata in record['binaries'].items():
        binary = directory / metadata['name']
        assert digest(binary) == metadata['sha256'], binary
        binaries[mode] = binary
    saved = HERE / name / 'reference-build-record.json'
    saved.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, saved)
    review = {
        'route': None,
        'dependency': 'Only later license metadata differs; Rust implementation and Cargo.lock are exact.',
        'incremental': 'Later license metadata and new batch/manifest feature-gated entrypoints differ; both retained modes omit those features and preserve the exact active planner implementation and Cargo.lock.',
        'batch': 'Later license metadata, inactive manifest entrypoint/module, and visibility widening of the unchanged shared parse function differ; the retained batch behavior and Cargo.lock are unchanged.',
        'manifest': 'Only later license metadata differs; every Rust implementation file and Cargo.lock is exact.',
        'inventory': 'Every source and Cargo.lock hash matches the current reference exactly.',
    }[name]
    provenance = {
        'directory': str(directory),
        'build_record_sha256': digest(path),
        'saved_build_record': str(saved),
        'binaries': {mode: {'path': str(binary), 'sha256': digest(binary)} for mode, binary in binaries.items()},
        'current_sources': actual,
        'source_hashes_identical': record['sources'] == actual,
        'compatibility_review': review,
        'source_differences': differences,
    }
    write_json(HERE / name / 'reference-provenance.json', provenance)
    return binaries, provenance, [path, *binaries.values()]


def execute(directory, label, command):
    started = now()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=1200, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    stdout = directory / f'{label}.stdout.txt'
    stderr = directory / f'{label}.stderr.txt'
    stdout.write_text(result.stdout)
    stderr.write_text(result.stderr)
    command_record = {
        'command': [str(part) for part in command],
        'shell_display': shlex.join(str(part) for part in command),
        'cwd': str(ROOT),
        'started_at': started,
        'finished_at': now(),
        'returncode': result.returncode,
        'stdout': str(stdout),
        'stderr': str(stderr),
    }
    write_json(directory / f'{label}.command.json', command_record)
    if result.returncode:
        raise RuntimeError(f'{label} failed: {result.stderr[-4000:]}')
    return command_record, result.stdout


def validate_application(name, spec, refs):
    source, validator, _, _ = spec
    directory = HERE / name
    directory.mkdir(exist_ok=True)
    binary = directory / name
    llvm = directory / f'{name}.ll'
    record = {'application': name, 'started_at': now(), 'commands': [], 'status': 'running'}
    try:
        command = [str(COMPILER), 'build', str(ROOT / 'examples' / source), '--module-root', str(ROOT / 'examples'), '--runtime', str(RUNTIME), '--clang', str(CLANG), '--opt-level', '3', '--emit-llvm', str(llvm), '-o', str(binary)]
        compiled, _ = execute(directory, 'compile', command)
        record['commands'].append(compiled)
        output = directory / 'validation.json'
        command = [str(PYTHON), '-I', '-B', str(ROOT / 'benchmarks' / validator), '--python', str(PYTHON), '--binary', str(binary)]
        if name not in ('route', 'dependency'):
            command += ['--rust-bigint', str(refs['bigint']), '--output', str(output)]
            if name == 'incremental':
                command += ['--rust-i64', str(refs['i64'])]
        validated, stdout = execute(directory, 'validate', command)
        record['commands'].append(validated)
        if name in ('route', 'dependency'):
            write_json(output, json.loads(stdout))
        result = json.loads(output.read_text())
        record['validation'] = str(output)
        record['counts'] = {key: value for key, value in result.items() if key not in ('checks', 'parser_checks', 'records')}
        if name == 'dependency':
            output = directory / 'boundaries.json'
            command = [str(PYTHON), '-I', '-B', str(ROOT / 'benchmarks/reference/dependency_planner/check_boundaries.py'), '--python', str(PYTHON), '--imre', str(binary), '--rust-bigint', str(refs['bigint']), '--rust-i64', str(refs['i64']), '--output', str(output)]
            validated, _ = execute(directory, 'boundaries', command)
            record['commands'].append(validated)
            result = json.loads(output.read_text())
            record['boundaries'] = {'path': str(output), 'cases': result['cases'], 'i64_overflow_rejections': result['i64_overflow_rejections'], 'validation': {key: value for key, value in result['validation'].items() if key != 'checks'}}
        record.update(status='passed', binary_sha256=digest(binary), llvm_sha256=digest(llvm))
    except Exception:
        record.update(status='failed', error=traceback.format_exc())
        (directory / 'failure.txt').write_text(record['error'])
    record['finished_at'] = now()
    write_json(directory / 'record.json', record)
    return record


def main():
    HERE.mkdir(parents=True, exist_ok=True)
    inputs = [COMPILER, RUNTIME, PYTHON, CLANG, Path(__file__), *sorted((ROOT / 'examples').rglob('*.py')), *sorted((ROOT / 'benchmarks').glob('*.py'))]
    inputs += [*sorted((ROOT / 'benchmarks/reference').rglob('*.py'))]
    references = {}
    provenance = {}
    for name, (_, _, package, folder) in SPECS.items():
        if package:
            references[name], provenance[name], paths = reference(name, package, folder)
            inputs += paths
            source = ROOT / 'benchmarks/reference' / package
            inputs += [source / 'Cargo.toml', source / 'Cargo.lock', *sorted((source / 'src').rglob('*.rs'))]
    before = {str(path): digest(path) for path in set(inputs)}
    index = {
        'started_at': now(),
        'status': 'running',
        'scope': 'Six current first-party applications, ordinary O3, full existing validation corpora, CPython and independent/Rust oracles; no benchmark timings and no Cargo builds.',
        'max_parallel_applications': 3,
        'source_and_tool_sha256': before,
        'retained_references': provenance,
        'applications': {},
    }
    write_json(HERE / 'index.json', index)
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {executor.submit(validate_application, name, spec, references.get(name, {})): name for name, spec in SPECS.items()}
        for future in as_completed(futures):
            record = future.result()
            index['applications'][record['application']] = record
            write_json(HERE / 'index.json', index)
            print(json.dumps({'application': record['application'], 'status': record['status'], 'counts': record.get('counts'), 'error': record.get('error')}, ensure_ascii=False), flush=True)
    index['input_guards_passed'] = all(digest(Path(path)) == value for path, value in before.items())
    index['status'] = 'passed' if index['input_guards_passed'] and all(record['status'] == 'passed' for record in index['applications'].values()) else 'failed'
    index['finished_at'] = now()
    index['artifact_sha256'] = {str(path.relative_to(HERE)): digest(path) for path in sorted(HERE.rglob('*')) if path.is_file() and path.name != 'index.json'}
    write_json(HERE / 'index.json', index)
    print(json.dumps({'status': index['status'], 'applications': len(index['applications']), 'input_guards_passed': index['input_guards_passed'], 'index': str(HERE / 'index.json')}), flush=True)
    if index['status'] != 'passed':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
