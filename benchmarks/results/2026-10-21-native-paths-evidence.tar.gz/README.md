# Native path evidence

The content-addressed logical index retains original preparation, timing,
validation and checked filesystem bytes. Source entries bind the measured commit,
Git blob IDs, modes, SHA-256 hashes and byte lengths. Every historical file under
benchmarks/results is omitted; its Git identity remains available for tree proof.
The source commit object is retained, and portable replay verifies the full Git
tree identity using retained and omitted blob identities.

Native programs, static archives, LLVM bitcode and Python bytecode are external,
hash-identified artifacts. LLVM text, build/test logs and captured outputs remain
included. Each compute workload includes its zero-repetition preload control.

Run 2026-10-21-native-paths-replay.py beside the archive, manifest and index.
Replay checks data and output oracles without a developer checkout, Git, compiler
or native engine. It does not remeasure performance or authenticate timestamps.
