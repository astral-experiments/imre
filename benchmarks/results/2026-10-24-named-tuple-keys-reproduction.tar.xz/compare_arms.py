"""Establish exact ELF and split IR parity across a rebase or a legality-only edit."""
from pathlib import Path
import hashlib
import sys
import json

out=Path(__file__).resolve().parent
left,right=sys.argv[1:3]
names=sys.argv[3:] or ["catalog","ruff"]
def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()
result={}
same=True
for name in names:
    binaries = {arm: digest(out/"apps"/arm/name) for arm in (left,right)}
    units = {arm: {path.name:digest(path) for path in (out/"units"/arm/name).glob("*.ll")} for arm in (left,right)}
    result[name]={"ELF_sha256":binaries,"llvm_units_sha256":units,
                  "identical_ELF":binaries[left]==binaries[right],
                  "identical_units":bool(units[left]) and units[left]==units[right]}
    same &= result[name]["identical_ELF"] and result[name]["identical_units"]
    print(name,binaries,result[name]["identical_units"])
directory=out/"head-comparisons"
directory.mkdir(exist_ok=True)
(directory/f"{left}-against-{right}.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
sys.exit(0 if same else 1)
