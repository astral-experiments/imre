"""Refresh the shipping-workload gate on the revised JSON runtime."""
import json
from pathlib import Path
import subprocess
import sys
import hashlib

out=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve()
rev=sys.argv[2]
run_prefix=sys.argv[3] if len(sys.argv)>3 else rev
primary_seed=int(sys.argv[4]) if len(sys.argv)>4 else 5810927
merge_check=len(sys.argv)>5 and sys.argv[5]=="merge-check"
archive=out/f"refresh-{rev}/runtime.a"
stem="short" if merge_check else "new-rt"
main,hand,candidate=(f"{stem}-{arm}" for arm in ("main","hand","candidate"))
timer=[sys.executable,"-B",out/"timing.py",repo]
def measure(case,run,cpu,blocks,seed,arms):
    subprocess.run([*timer,"--case",case,"--cpu",str(cpu),"--blocks",str(blocks),
                    "--seed",str(seed),"--run",run,"--arms",*arms],check=True)
    return json.loads((out/f"timing/{run}/{case}/result.json").read_text())
for arm in (main,hand,candidate):
    for app in ("catalog","ruff"):
        provenance=json.loads((out/f"apps/{arm}/{app}.json").read_text())
        assert provenance["runtime_sha256"]==hashlib.sha256(archive.read_bytes()).hexdigest()
        assert provenance["ELF_sha256"]==hashlib.sha256((out/f"apps/{arm}/{app}").read_bytes()).hexdigest()
primary=f"{run_prefix}-primary"
p10=measure("catalog-10-plain",primary,12,48 if merge_check else 96,primary_seed,[main,hand,candidate])
p1=measure("catalog-1-plain",primary,12,48 if merge_check else 72,primary_seed,[main,hand,candidate])
speedup=f"{main}/{candidate}"
if merge_check or (p10["paired_speedup_95ci"][speedup][1] > 1 and
        p1["paired_speedup_95ci"][speedup][1] >= 1/1.01):
    confirm=[]
    for arm in (main,candidate):
        alias=f"{arm}-confirm"
        subprocess.run([sys.executable,"-B",out/"build.py",repo,alias,out/f"normal-tools/{arm}/relar",
                        "--runtime",archive,"--app","catalog"],check=True)
        assert (out/f"apps/{arm}/catalog").read_bytes() == (out/f"apps/{alias}/catalog").read_bytes()
        confirm.append(alias)
    measure("catalog-10-plain",f"{run_prefix}-confirmation",24,60 if merge_check else 72,
            5214743 if merge_check else 1387901,confirm)
measure("ruff-1-diff",primary,18,48,primary_seed,[main,candidate])
measure("ruff-10-diff",primary,22,48 if merge_check else 144,primary_seed if merge_check else 4023019,[main,candidate])
