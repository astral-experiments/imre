"""Prepare native sources, real replay inputs and fresh CPython output hashes."""
from pathlib import Path
import difflib
import json
import shutil
import sys
from types import SimpleNamespace

out = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
old = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else (out.parent / "splitlines-fusion/inputs").resolve()
sys.path.insert(0, str(repo / "benchmarks"))
import splitlines_benchmark as bench

for path in ("hand-source/examples", "inputs", "logs", "oracles"):
    (out / path).mkdir(parents=True, exist_ok=True)
package = out / "hand-source/examples/python_catalog"
shutil.copytree(repo / "examples/python_catalog", package, dirs_exist_ok=True)
file = package / "catalog.py"
before = file.read_text()
needle = """        labels = (artifact.platform, artifact.variant)
        target = selection.targets.get(labels)"""
repl = """        label_platform = artifact.platform
        label_variant = artifact.variant
        target = selection.targets.get((label_platform, label_variant))"""
assert before.count(needle) == 1 and before.count("selection.targets[labels] = target") == 1
after = before.replace(needle, repl).replace("selection.targets[labels] = target",
                                            "selection.targets[(label_platform, label_variant)] = target")
file.write_text(after)
(out / "hand-rewrite.patch").write_text("".join(difflib.unified_diff(
    before.splitlines(True), after.splitlines(True), fromfile="a/examples/python_catalog/catalog.py",
    tofile="b/examples/python_catalog/catalog.py")))
for name in ("catalog", "panels"):
    link = out / "inputs" / name
    if not link.exists():
        link.symlink_to(old / name, target_is_directory=True)
for scale in (1, 10):
    if not (out / f"inputs/ruff/{scale}x").exists():
        bench.ruff.replay(old / "panels", old / "suite-metadata", scale, out / "inputs/ruff")
args = SimpleNamespace(work=out, python=Path(sys.executable))
catalog = bench.catalog_validate
data = {}
for app, kind in (("catalog", "plain"), ("ruff", "diff")):
    for scale in (1, 10):
        case = (app, scale, kind)
        _, result = bench.invoke(args, case, "python", out / "oracles", audit=True)
        if app == "catalog":
            expected = (old / "catalog/expected.json").read_bytes()
            assert result["sha256"] == bench.sha(expected)
            import subprocess
            dest = out / "oracles/hand.json"
            run = subprocess.run([str(args.python), "-I", "-B", "-c", catalog.BOOTSTRAP,
                "python_catalog", str(package.parent), str(repo / "stdlib"),
                str(old / f"catalog/{scale}x.ndjson"), str(dest)], capture_output=True,
                env=catalog.environment(), check=True)
            assert not run.stderr and not run.stdout and dest.read_bytes() == expected
        data[bench.label(case)] = result
        print(bench.label(case), result, flush=True)
bench.write(out / "oracles/outputs.json", data)
