import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import tempfile


parser = argparse.ArgumentParser()
parser.add_argument("--arm", required=True)
parser.add_argument("--compiler", type=Path, required=True)
parser.add_argument("--runtime", type=Path, required=True)
parser.add_argument("--fixture", type=Path, required=True)
parser.add_argument("--python", default=sys.executable)
parser.add_argument("--level", required=True)
parser.add_argument("--sanitize", action="store_true")
args = parser.parse_args()
here = Path(__file__).resolve().parent
out = here / (args.arm + "-O" + args.level + ("-asan" if args.sanitize else ""))
out.mkdir(exist_ok=True)
env = dict(os.environ, IMRE_CACHE_DIR=str(out / "cache"), ASAN_OPTIONS="detect_leaks=1:halt_on_error=1")
rows = []
rng = random.Random(20261024)

for source, seeds in [(args.fixture, [None]), (here / "mutations.py", [0, 1, -1, 2**96, -2**96] + [rng.randrange(-2**64, 2**64) for _ in range(40)])]:
    exe = out / source.stem
    cmd = [args.compiler, "build", source, "--opt-level", args.level, "--runtime", args.runtime, "-o", exe]
    if args.sanitize:
        cmd.extend(["--clang", "/usr/bin/clang-18", "--sanitize"])
    built = subprocess.run(cmd, env=env, capture_output=True)
    if built.returncode:
        raise RuntimeError((cmd, built.stderr.decode()))
    for seed in seeds:
        stdin = b"" if seed is None else f"{seed}\n".encode()
        with tempfile.TemporaryDirectory() as ref_dir, tempfile.TemporaryDirectory() as actual_dir:
            expected = subprocess.run([args.python, "-IB", source], cwd=ref_dir, env=env, input=stdin, capture_output=True)
            actual = subprocess.run([exe], cwd=actual_dir, env=env, input=stdin, capture_output=True)
            def files(dir_path):
                return {p.name: p.read_bytes() for p in Path(dir_path).iterdir()}
            if files(ref_dir) != files(actual_dir):
                raise RuntimeError((source, seed, files(ref_dir), files(actual_dir)))
        if (expected.returncode, actual.returncode, expected.stderr, actual.stderr) != (0, 0, b"", b"") or expected.stdout != actual.stdout:
            raise RuntimeError((source, seed, (expected.stderr, actual.stderr), (expected.stdout[:2500], actual.stdout[:2500])))
        rows.append(dict(source=source.name, seed=seed, bytes=len(expected.stdout), sha256=hashlib.sha256(expected.stdout).hexdigest()))
(out / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
print(f"{out.name}: {len(rows)} CPython comparisons passed")
