from dataclasses import dataclass


@dataclass
class Parts:
    first: str
    second: str


def mutate(parts: Parts, seed: int) -> str:
    parts.first = f"overwritten-{seed}"
    return parts.second


def default(parts: Parts, saved: dict[tuple[str, str], int], value: int) -> int:
    saved[(parts.first, parts.second)] = value
    parts.first = "default changed the first field"
    parts.second = "default changed the second field"
    return -2


def checked(parts: Parts, seed: int) -> str:
    parts.first = "partially evaluated"
    if seed % 3 == 0:
        raise ValueError(f"failed field {seed % 7}")
    return parts.second


def probe(seed: int) -> None:
    saved: dict[tuple[str, str], int] = {}
    parts = Parts("", "")
    for i in range(57):
        seed = (seed * 1664525 + 1013904223) % 4294967296
        parts.first = f"κ-{seed % 4}"
        parts.second = f"📍-{seed % 7}"
        key = (parts.first, mutate(parts, seed))
        parts.second = f"modified-{i}"
        found = saved.get(key)
        if found is None:
            if seed % 3 != 0:
                parts.first = "set key must use its snapshot"
                saved[key] = i
        else:
            print(f"{i} {found}")
    for key_seen, value in saved.items():
        print(f"{key_seen[0]} {key_seen[1]} {value}")


def defaults_and_failures(seed: int) -> None:
    saved: dict[tuple[str, str], int] = {}
    parts = Parts("initial", "value")
    prior = ("old", "key")
    for i in range(16):
        parts.first = f"κ-{(seed+i) % 5}"
        parts.second = f"📍-{i % 4}"
        k = (parts.first, parts.second)
        print(saved.get(k, default(parts, saved, i)))
        try:
            prior = (parts.first, checked(parts, seed+i))
        except ValueError as err:
            print(str(err))
        print(saved.get(prior, -1))


def retained_keys(seed: int) -> None:
    parts = Parts(f"first-{seed}", "middle")
    history: list[tuple[str, str]] = []
    one: dict[tuple[str, str], int] = {}
    two: dict[tuple[str, str], int] = {}
    for i in range(5):
        key = (parts.first, parts.second)
        history.append(key)
        parts.first = f"changed-{i}"
        if one.get(key) is None:
            one[key] = i
            two[key] = 100 + i
    for stored in history:
        print(f"{stored[0]} {stored[1]} {one[stored]} {two[stored]}")


def main() -> None:
    seed = int(input())
    probe(seed)
    defaults_and_failures(seed)
    retained_keys(seed)


main()
