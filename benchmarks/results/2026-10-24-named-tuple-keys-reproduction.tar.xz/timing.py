"""Measure uninstrumented process wall time in balanced complete permutation blocks."""
import argparse
import fcntl
import hashlib
import itertools
import json
import os
from pathlib import Path
import random
import statistics
import sys
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("repo", type=Path)
parser.add_argument("--run", default="primary")
parser.add_argument("--seed", type=int, default=4370321)
parser.add_argument("--cpu", type=int, default=12)
parser.add_argument("--blocks", type=int, required=True)
parser.add_argument("--case", required=True, choices=["catalog-1-plain", "catalog-10-plain", "ruff-1-diff", "ruff-10-diff"])
parser.add_argument("--arms", nargs="+")
args = parser.parse_args()
out = Path(__file__).resolve().parent
if (out / "timing" / args.run / "excluded.json").exists():
    raise SystemExit(f"{args.run} excluded from shipping evidence; ending before next case")
# Separate sandbox command sessions may not see each other's subprocesses.
# Keep this lock alive for the whole invocation, including the last child.
(out / "timing").mkdir(exist_ok=True)
lock = (out / "timing/active-case.lock").open("a+")
try:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    raise SystemExit("another benchmark case owns this study directory")
sys.path.insert(0, str(args.repo.resolve() / "benchmarks"))
import splitlines_benchmark as bench

os.sched_setaffinity(0, {args.cpu})
app, scale, kind = args.case.split("-")
case = (app, int(scale), kind)
arms = tuple(args.arms or (["main", "hand", "prototype"] if app == "catalog" else ["main", "prototype"]))
orderings = list(itertools.permutations(arms))
assert args.blocks % len(orderings) == 0
target = out / "timing" / args.run / args.case
target.mkdir(parents=True, exist_ok=True)
state = SimpleNamespace(work=out, python=Path(sys.executable), apps=out / "apps")
expected = json.loads((out / "oracles/outputs.json").read_text())[args.case]
rng = random.Random(args.seed)
orders = []
for _ in range(args.blocks // len(orderings)):
    rng.shuffle(orderings)
    orders.extend(orderings)

def host():
    return {"cpu_ticks":next(line for line in Path("/proc/stat").read_text().splitlines() if line.startswith(f"cpu{args.cpu} ")),
            "loadavg":os.getloadavg()}

def interval(rows, a, b):
    ratios = [row[a]/row[b] for row in rows]
    width = len(orderings)
    groups = [ratios[j:j+width] for j in range(0, len(ratios), width)]
    sample = random.Random(588491)
    dist = sorted(statistics.median(itertools.chain.from_iterable(sample.choices(groups, k=len(groups))))
                  for _ in range(8000))
    return [statistics.median(ratios), dist[200], dist[7799]]

before = host()
for arm in arms:
    for repeat in range(2):
        bench.checked(state, case, arm, target, expected, audit=(repeat == 0))
rows = []
for order in orders:
    row = {}
    for arm in order:
        row[arm] = bench.checked(state, case, arm, target, expected)
    rows.append(row)
    if len(rows) % len(orderings) == 0:
        (target / "progress.json").write_text(json.dumps({"completed":len(rows), "blocks":args.blocks}))
after = host()
result = {"case":args.case, "seed":args.seed, "cpu":args.cpu, "blocks":args.blocks, "warmups_per_arm":2,
          "host_before":before, "host_after":after, "arms":arms, "orders":orders, "samples_ns":rows,
          "oracle":expected, "ELF_sha256":{arm:hashlib.sha256((out / "apps" / arm / app).read_bytes()).hexdigest() for arm in arms},
          "median_ms":{arm:statistics.median(row[arm] for row in rows)/1e6 for arm in arms},
          "paired_speedup_95ci":{f"{a}/{b}":interval(rows,a,b) for a,b in itertools.combinations(arms,2)},
          "bootstrap":"median paired elapsed ratio; 8000 resamples of complete permutation-balanced cycles"}
bench.write(target / "result.json", result)
print(args.case, result["median_ms"], result["paired_speedup_95ci"], flush=True)
