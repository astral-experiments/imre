"""Run each prespecified case sequentially to avoid sharing the L3 or disk bandwidth."""
from pathlib import Path
import argparse
import subprocess
import sys

out = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("repo")
parser.add_argument("--candidate", default="prototype")
parser.add_argument("--run", default="primary")
parser.add_argument("--seed", type=int, default=4370321)
parser.add_argument("--cpu", type=int, default=12)
parser.add_argument("--ruff-cpu", type=int, default=18)
args=parser.parse_args()
base = [sys.executable, "-B", out / "timing.py", args.repo, "--seed", str(args.seed), "--run", args.run]
for case, cpu, blocks in [
        ("catalog-10-plain", args.cpu, 96), ("catalog-1-plain", args.cpu, 72),
        ("ruff-10-diff", args.ruff_cpu, 48), ("ruff-1-diff", args.ruff_cpu, 48)]:
    arms = ["main", "hand", args.candidate] if case.startswith("catalog") else ["main", args.candidate]
    command = [*base, "--case", case, "--cpu", str(cpu), "--blocks", str(blocks)]
    subprocess.run([*command, "--arms", *arms], check=True)
