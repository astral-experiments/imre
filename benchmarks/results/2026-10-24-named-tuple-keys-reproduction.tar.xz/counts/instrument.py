"""Count dynamic operations at compiler-emitted LLVM sites, in separate untimed builds."""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess


ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
TOOLCHAIN = STUDY / "toolchain"
ABI_RC = re.compile(r"imre_(\w+)_(retain|release)$")
PTR_GUARD = re.compile(r"(\w+)_(retain|release)_if_present$")
INT_GUARD = re.compile(r"(retain|release)_int(?:_(heap|nonzero))?$")
DEFINE = re.compile(r"^define .*?@([\w.$]+)\(")
CALL = re.compile(r"\bcall \w+ @(\w+)\(([^)]*)\)")
LAYOUT = re.compile(r"@layout_(\w+)")
SSA = r"%[\w.]+"


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def helper(name):
    return bool(PTR_GUARD.fullmatch(name) or INT_GUARD.fullmatch(name))


def cached_layout(lines, line, result):
    # The compiler selects the cached result or a fresh record in a following phi.
    for target in lines[line + 1 : line + 9]:
        if " = phi ptr " not in target or not re.search(re.escape(result) + r"\b", target):
            continue
        for incoming in re.findall(r"\[\s*(%\w+),", target):
            if incoming != result:
                for source in reversed(lines[max(0, line - 15) : line]):
                    if re.search(r"\b" + re.escape(incoming[1:]) + r" = call ptr @imre_record_new\(", source):
                        return LAYOUT.search(source).group(1)
    raise ValueError(("cannot identify cached record's layout", lines[line]))


def instrument(path, sites):
    lines = path.read_text().splitlines()
    out = []
    function = None
    for index, line in enumerate(lines):
        if m := DEFINE.search(line):
            function = m.group(1)
        if line == "}":
            function = None
        out.append(line)
        if not function or not (m := CALL.search(line)):
            continue
        symbol, args = m.groups()

        def add(family, operation, predicate="", layout=None):
            n = len(sites)
            sites.append(dict(unit=path.name, fn=function, line=index + 1, family=family,
                              op=operation, callee=symbol, layout=layout))
            if predicate:
                value = f"%keycount.p.{n}"
                out.extend((f"  {value} = {predicate}", f"  %keycount.d.{n} = zext i1 {value} to i64"))
                delta = f"%keycount.d.{n}"
            else:
                delta = "1"
            out.append(f"  call void @keyop_add(i64 {n}, i64 {delta})")

        if m := ABI_RC.fullmatch(symbol):
            add("rc_direct", f"{m[1]}.{m[2]}")
        elif (m := PTR_GUARD.fullmatch(symbol)) and not helper(function):
            add("rc_attributed", f"{m[1]}.{m[2]}", f"icmp ne {args}, null")
        elif (m := INT_GUARD.fullmatch(symbol)) and not helper(function):
            arg = args.removeprefix("i64 ")
            n = len(sites)
            if m[2] == "heap":
                cond = ""
            else:
                out.extend((f"  %keycount.tag.{n} = and i64 {arg}, 1",
                            f"  %keycount.big.{n} = icmp eq i64 %keycount.tag.{n}, 0"))
                if m[2] == "nonzero":
                    cond = f"and i1 %keycount.big.{n}, true"
                else:
                    out.append(f"  %keycount.live.{n} = icmp ne i64 {arg}, 0")
                    cond = f"and i1 %keycount.big.{n}, %keycount.live.{n}"
            add("rc_attributed", f"int.{m[1]}", cond)
        elif symbol in ("imre_record_new", "imre_tuple_probe"):
            layout = LAYOUT.search(args).group(1)
            add("record", "new" if symbol == "imre_record_new" else "probe", layout=layout)
        elif symbol == "imre_record_cached_result":
            result = re.search(SSA + r"(?= = call)", line).group()
            layout = cached_layout(lines, index, result)
            add("record", "cached", layout=layout)
            add("record", "reused", f"icmp eq {args}, {result}", layout=layout)
        elif symbol == "imre_dict_try_get":
            result = re.search(SSA + r"(?= = call)", line).group()
            add("lookup", "try_get")
            add("lookup", "hit", f"icmp ne i32 {result}, 0")
        elif symbol == "imre_dict_set":
            add("lookup", "set")
    return "\n".join(out) + "\ndeclare void @keyop_add(i64, i64) nounwind\n"


def build(args):
    out = args.out
    tool = args.tool
    sites = []
    original = {}
    objects = []
    units = sorted(args.units.glob("*.ll"))
    if len(units) != (3 if args.app == "catalog" else 1):
        raise ValueError(("missing units", units))
    # Keep source units intact. The output copy is marked to prevent timing it by mistake.
    for source in units:
        dest = out / source.name
        dest.write_text(instrument(source, sites))
        original[source.name] = sha(source.read_bytes())
        obj = dest.with_suffix(".o")
        objects.append(obj)
        subprocess.run([tool / "bin/clang", "--no-default-config", "-O3", "-Wno-override-module",
                        "-c", "-x", "ir", dest, "-o", obj], check=True)
    sink = out / "sink.o"
    subprocess.run(["cc", "-O2", "-c", f"-DNUM_SITES={len(sites)}", ROOT / "sink.c", "-o", sink], check=True)
    executable = out / "counted"
    link = tool / "link"
    subprocess.run([tool / "bin/clang", "--no-default-config", "-B", link, "-L", link,
                    f"--ld-path={tool / 'bin/ld.lld'}", "-O3", *objects, sink, args.runtime,
                    "-ldl", "-lpthread", "-lm", "-lrt", "-lutil", "-Wl,--gc-sections",
                    "-Wl,-z,relro,-z,now", "-o", executable], check=True)
    dump(out / "sites.json", sites)
    dump(out / "provenance.json", dict(artifacts=original, runtime=sha(args.runtime.read_bytes()),
                                      counted_elf=sha(executable.read_bytes())))
    print("built", executable, len(sites), "sites")


def summarize(sites, counts, app):
    whole_direct = Counter()
    whole_from_origins = Counter()
    fn_rc = defaultdict(Counter)
    records = defaultdict(Counter)
    tuple_ops = Counter()
    dict_sites = defaultdict(Counter)
    for site, count in zip(sites, counts, strict=True):
        family, fn, op, layout = (site[k] for k in ("family", "fn", "op", "layout"))
        location = f"{site['unit']}::{fn}"
        if family == "rc_direct":
            whole_direct[op] += count
        if family in ("rc_direct", "rc_attributed") and not helper(fn):
            whole_from_origins[op] += count
            fn_rc[location][op] += count
        if family == "record":
            records[location + ":" + layout][op] += count
            if layout.startswith("tuple_"):
                tuple_ops[op] += count
        if family == "lookup":
            dict_sites[f"{location}:{site['line']}"][op] += count
    # Verify per-origin attribution independently against the actual underlying ABI calls,
    # including calls from emitted conditional helper bodies and non-immediate integers.
    assert whole_direct == whole_from_origins, (whole_direct, whole_from_origins)

    def record_totals(totals):
        return dict(new=totals["new"], cached=totals["cached"], reused=totals["reused"],
                    fresh=totals["new"] + totals["cached"] - totals["reused"],
                    owned_constructions=totals["new"] + totals["cached"], probe=totals["probe"])
    result = dict(all_rc=dict(sorted(whole_direct.items())), all_tuples=record_totals(tuple_ops),
                  rc_by_function=fn_rc, records_by_fn_layout={k:record_totals(v) for k,v in records.items()},
                  dictionary_sites=dict_sites)
    if app == "catalog":
        fn = "python_catalog.catalog.ll::fn_m2_10"
        assert fn in fn_rc
        # The catalog's labels is the only pair-of-str layout in select_line. Verify
        # the descriptor in the entry unit for each freshly generated arm.
        result["select_line_rc"] = fn_rc[fn]
    return result


def measure(args):
    out = args.out
    sites = json.loads((out / "sites.json").read_text())
    oracles = json.loads(args.oracles.read_bytes())
    for scale in (1, 10):
        run_dir = out / f"{scale}x"
        run_dir.mkdir(exist_ok=True)
        raw = run_dir / "counter-values.bin"
        raw.unlink(missing_ok=True)
        env = dict(os.environ, IMRE_TUPLE_KEY_COUNTERS=str(raw), TZ="UTC", LC_ALL="C",
                   RAYON_NUM_THREADS="1", CONFORMANCE_SUITE_COMMIT="835b70f3f795f8e061b1f7621178515b0a77a0ad")
        if args.app == "catalog":
            cwd = args.inputs / "catalog"
            dest = run_dir / "catalog.json"
            dest.write_bytes(b"before\n")
            argv = [cwd / f"{scale}x.ndjson", dest]
            case = f"catalog-{scale}-plain"
        else:
            cwd = args.inputs / "ruff" / f"{scale}x"
            argv = ["--tests-path", cwd, "--old-ty", cwd / "old-ty", "--new-ty", cwd / "new-ty",
                    "--format", "diff"]
            case = f"ruff-{scale}-diff"
        run = subprocess.run([out / "counted", *argv], cwd=cwd, env=env, capture_output=True, check=True)
        if run.stderr or (args.app == "catalog" and run.stdout):
            raise ValueError((run.stdout[:500], run.stderr[:500]))
        data = dest.read_bytes() if args.app == "catalog" else run.stdout
        identity = dict(bytes=len(data), sha256=sha(data))
        assert all(oracles[case][k] == v for k, v in identity.items()), (oracles[case], identity)
        counts = struct.unpack(f"={len(sites)}Q", raw.read_bytes())
        summary = summarize(sites, counts, args.app)
        summary["output"] = identity
        if args.app == "catalog":
            layouts = {}
            for path in args.units.glob("*.ll"):
                for name, kinds in re.findall(r"@kinds_(tuple_\d+) = [^\n]+?\[\d+ x i32\] \[([^\]]+)\]", path.read_text()):
                    layouts[name] = re.findall(r"i32 (\d+)", kinds)
            labels = [name for name, kinds in layouts.items() if kinds == ["3","3"]]
            assert len(labels) == 1, labels
            key = f"python_catalog.catalog.ll::fn_m2_10:{labels[0]}"
            summary["labels_tuple"] = summary["records_by_fn_layout"][key]
            own_sites = [v for k,v in summary["dictionary_sites"].items()
                         if k.startswith("python_catalog.catalog.ll::fn_m2_10:")]
            gets = [v for v in own_sites if "try_get" in v]
            sets = [v for v in own_sites if "set" in v]
            assert len(gets) == len(sets) == 3
            # select_line looks up group, labels, previous, and inserts labels, group, selected.
            summary["labels_dictionary"] = dict(lookups=gets[1]["try_get"], hits=gets[1]["hit"], stores=sets[0]["set"])
        dump(run_dir / "summary.json", summary)
        print(case, identity, summary.get("labels_tuple"), summary.get("labels_dictionary"))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("build", "run", "all"))
    p.add_argument("arm")
    p.add_argument("app", choices=("catalog", "ruff"))
    p.add_argument("--units", type=Path)
    p.add_argument("--tool", type=Path, default=TOOLCHAIN / "imre-toolchain")
    p.add_argument("--runtime", type=Path, default=TOOLCHAIN / "runtime.a")
    p.add_argument("--inputs", type=Path, default=STUDY / "inputs")
    p.add_argument("--oracles", type=Path, default=STUDY / "oracles/outputs.json")
    args = p.parse_args()
    args.units = (args.units or STUDY / "units" / args.arm / args.app).resolve(strict=True)
    args.out = ROOT / args.arm / args.app
    args.out.mkdir(exist_ok=True, parents=True)
    args.inputs = args.inputs.resolve(strict=True)
    if args.mode in ("build", "all"):
        build(args)
    if args.mode in ("run", "all"):
        measure(args)


if __name__ == "__main__":
    main()
