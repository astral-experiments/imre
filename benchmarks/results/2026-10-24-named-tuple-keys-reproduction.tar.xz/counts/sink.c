#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* The native workload executes its generated Python code on one thread. */
static uint64_t counters[NUM_SITES];

void keyop_add(uint64_t site, uint64_t count) {
    counters[site] += count;
}

__attribute__((destructor)) static void save_counts(void) {
    const char *path = getenv("IMRE_TUPLE_KEY_COUNTERS");
    if (path == NULL)
        return;
    FILE *out = fopen(path, "wb");
    if (out == NULL || fwrite(counters, sizeof(*counters), NUM_SITES, out) != NUM_SITES || fclose(out))
        abort();
}
