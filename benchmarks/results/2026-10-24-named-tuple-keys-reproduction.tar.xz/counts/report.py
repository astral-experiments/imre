"""Collect the reproducible operation summaries beside the full per-callsite traces."""

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key_rows(arm):
    path = ROOT / arm / "catalog"
    if not (path / "10x/summary.json").exists():
        return None
    data = {}
    for scale in ("1x", "10x"):
        summary = json.loads((path / scale / "summary.json").read_text())
        rc = summary["all_rc"]
        data[scale] = dict(labels=summary["labels_tuple"], dictionary=summary["labels_dictionary"],
                           all_tuples=summary["all_tuples"], rc_by_kind=rc, rc_total=sum(rc.values()),
                           select_line_rc=summary["select_line_rc"], output=summary["output"])
    return data


def verified_binary(arm, app, runtime_hash):
    metadata = json.loads((arm / f"{app}.json").read_text())
    assert metadata["runtime_sha256"] == runtime_hash
    assert metadata["ELF_sha256"] == sha(arm / app)
    return metadata["ELF_sha256"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arms", nargs="+", default=["main", "hand", "prototype", "prototype-v2"])
    parser.add_argument("--baseline", default="main", help="Ruff control within this group of builds")
    parser.add_argument("--runtime", type=Path, help="assert the same archive was linked into each counted arm")
    parser.add_argument("--base", help="Git commit of the base release")
    parser.add_argument("--output", type=Path, default=ROOT / "comparison.json")
    args = parser.parse_args()
    if args.baseline not in args.arms:
        parser.error("the baseline must be included in the measured arms")
    archive_hash = sha(args.runtime) if args.runtime else None
    arms, ruff = {}, {}
    provenance = {}
    units = STUDY / "units"
    for name in args.arms:
        arm = STUDY / "apps" / name
        if not (row := key_rows(arm.name)):
            raise ValueError(("missing uv count results", name))
        if args.runtime:
            catalog_provenance = json.loads((ROOT / name / "catalog/provenance.json").read_text())
            assert catalog_provenance["runtime"] == archive_hash
            assert {p.name: sha(p) for p in (units / name / "catalog").glob("*.ll")} == catalog_provenance["artifacts"]
            provenance[name] = {"catalog": dict(catalog_provenance, uninstrumented_elf=verified_binary(arm, "catalog", archive_hash))}
        arms[arm.name] = row
        if (arm / "ruff").exists():
            entry = {"elf_sha256": sha(arm / "ruff"),
                     "ir_sha256": sha(units / arm.name / "ruff/conformance.ll")}
            if (ROOT / arm.name / "ruff/10x/summary.json").exists():
                ref = arm.name
            elif entry["elf_sha256"] == sha(STUDY / "apps" / args.baseline / "ruff") and entry["ir_sha256"] == sha(units / args.baseline / "ruff/conformance.ll"):
                ref = args.baseline
            else:
                raise ValueError(("missing counts for changed Ruff binary", arm.name))
            if args.runtime:
                ruff_provenance = json.loads((ROOT / ref / "ruff/provenance.json").read_text())
                assert ruff_provenance["runtime"] == archive_hash
                assert ruff_provenance["artifacts"]["conformance.ll"] == entry["ir_sha256"]
                provenance[name]["ruff"] = dict(ruff_provenance, uninstrumented_elf=verified_binary(arm, "ruff", archive_hash))
            entry["counted_from"] = ref
            for scale in ("1x", "10x"):
                s = json.loads((ROOT / ref / "ruff" / scale / "summary.json").read_text())
                entry[scale] = dict(all_tuples=s["all_tuples"], rc_by_kind=s["all_rc"],
                                    rc_total=sum(s["all_rc"].values()), output=s["output"])
            ruff[arm.name] = entry
    data = dict(uv=arms, ruff=ruff,
                definitions={
                    "fresh": "Direct imre_record_new calls plus cached results that returned a different pointer.",
                    "owned_constructions": "Direct new calls plus all cached-result calls, including reuses.",
                    "probe": "Calls to imre_tuple_probe with this static tuple descriptor.",
                    "rc_total": "Dynamic calls from all compiler-emitted code to runtime retain/release ABI symbols. Wrapper null/small-int paths are excluded. Internal Rust reference changes, including the +1 in a reused cached result, are not included.",
                    "output": "SHA-256 and byte length checked against the complete CPython app result."})
    if args.runtime:
        data.update(base=args.base, runtime_sha256=archive_hash,
                    oracles_sha256=sha(STUDY / "oracles/outputs.json"), provenance=provenance)
    args.output.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
