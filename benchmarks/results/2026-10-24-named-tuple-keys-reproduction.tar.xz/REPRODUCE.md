# Reproduce named tuple-key lookups

The shipping series compares baseline main `98671de0f9d2b128252af3ac658236091f4093c9`, its hand-rewritten uv example, and the compiler from this PR. Unpack this archive into an empty directory. Set `BASE` and `CANDIDATE` to the absolute paths of the two checkouts. The machine used Linux x86-64, CPython 3.14.5, the system allocator, and Relar's packaged Clang and LLD 18.1.3.

## Build the compilers and prepare the inputs

Build each compiler with Cargo's locked release profile in a distinct target directory. Build the release runtime by itself in the baseline checkout so all three arms receive the same Cargo features. The study used `cargo +ohm -Zohm-defaults=no build --release --locked -p relar-runtime`. When using Ohm's shared build directory, use `--config 'profile.release.package.relar-compiler.codegen-units=16'` for the baseline and `15` for the candidate in `cargo +ohm -Zohm-defaults=no build --release --locked -p relar-compiler` to distinguish the host compiler binaries. Both host compilers generate normal native split-module `-O3` applications.

Set `MAIN_CLI` and `CANDIDATE_CLI` to the freshly built executables, `RUNTIME` to the baseline's release `librelar_runtime.a`, `TOOLCHAIN` to the unpacked Relar toolchain, and `PYTHON` to CPython 3.14.5. Choose a new absolute `INPUTS_WORK`. Set `TYPING_SUITE` to the `conformance` directory in python/typing at commit `835b70f3f795f8e061b1f7621178515b0a77a0ad`.

```sh
mkdir -p toolchain refresh-98671de
ln -s "$TOOLCHAIN" toolchain/relar-toolchain
cp "$RUNTIME" toolchain/runtime.a
cp "$RUNTIME" refresh-98671de/runtime.a
"$PYTHON" -B "$BASE/benchmarks/splitlines_benchmark.py" prepare --work "$INPUTS_WORK" --typing-conformance "$TYPING_SUITE"
ln -s "$TYPING_SUITE" "$INPUTS_WORK/inputs/suite-metadata"
"$PYTHON" -B setup.py "$BASE" "$INPUTS_WORK/inputs"
"$PYTHON" -B build.py "$BASE" short-main "$MAIN_CLI" --runtime refresh-98671de/runtime.a
"$PYTHON" -B build.py "$BASE" short-hand "$MAIN_CLI" --hand-source --runtime refresh-98671de/runtime.a
"$PYTHON" -B build.py "$CANDIDATE" short-candidate "$CANDIDATE_CLI" --runtime refresh-98671de/runtime.a
```

The setup driver creates the hand rewrite, checks the full output against CPython, and records the reference hashes. The build driver captures every split LLVM unit and compares the executable byte-for-byte with a regular, uninstrumented release build.

## Time the full applications

```sh
"$PYTHON" -B run_refresh.py "$BASE" 98671de 98671de-merge 3812671 merge-check
```

Run one workload at a time. The driver uses 48 three-arm blocks at each uv scale on CPU 12, then recompiles both 10× confirmation arms and compares their ELF bytes with the primary arms. It runs 60 confirmation pairs on CPU 24 with seed 5214743, followed by 48 Ruff pairs at each scale on CPUs 18 and 22. Change CPU numbers to available cores if needed. The individual samples, order, CPU, seed, output digest and paired intervals are recorded under `timing/`.

## Count operations and exercise mutations

```sh
for arm in short-main short-hand short-candidate; do
    "$PYTHON" -B counts/instrument.py all "$arm" catalog --runtime refresh-98671de/runtime.a
done
"$PYTHON" -B counts/instrument.py all short-main ruff --runtime refresh-98671de/runtime.a
"$PYTHON" -B counts/report.py --arms short-main short-hand short-candidate --baseline short-main --base 98671de0f9d2b128252af3ac658236091f4093c9 --runtime refresh-98671de/runtime.a --output counts/short-comparison.json
for level in 0 3; do
    "$PYTHON" -B parity/run.py --python "$PYTHON" --compiler "$PWD/normal-tools/short-candidate/relar" --runtime "$PWD/refresh-98671de/runtime.a" --fixture "$CANDIDATE/tests/fixtures/tuple_keys/named_lookup.py" --level "$level" --arm candidate
done
```

The counter driver uses separate untimed binaries. It checks each output and attributes calls by source LLVM unit, function, record layout and call site. Cached constructions are counted as reuse when the old and returned pointers match. The driver reconciles actual retain/release calls with the calls attributed to individual sites. Reference changes inside Rust helpers are outside this metric. Ruff counts are shared after verifying its identical LLVM and ELF. For the sanitized mutation run, build the sanitizer-enabled runtime with the repository's CI flags, pass that archive to the parity driver, and add `--sanitize --level 1`.

## Earlier experiments

The full study on main `0412f8bac6f58bdeb356c6616624691af6d01e28` used the JSON encoder runtime introduced at `33fbb4d`. Corresponding LLVM and executables were identical on `33fbb4d`, `726b6a0` and `0412f8b`. To repeat it, use that baseline and its matching release archive, name the three arms `new-rt-main`, `new-rt-hand` and `new-rt-candidate`, copy the archive to `refresh-33fbb4d/runtime.a`, and run `run_refresh.py "$BASE" 33fbb4d 726b6a0-isolated 8125607`. The raw data also records the initial runtime at `2848e2a`. To recreate the intermediate compiler that retains fields for each probe, apply `rooted-fields.patch` in a separate candidate checkout and rebuild.
