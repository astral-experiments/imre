"""Collect measured artifacts without including built binaries or generated inputs."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import platform
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("artifact", type=Path)
parser.add_argument("--include-run", action="append")
parser.add_argument("--reference", default="2848e2a26e7d2c71bb8a8ec23fefc39977606b64")
parser.add_argument("--runtime", type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def identify(program, app):
    result = {"sha256":digest(program)}
    for row in subprocess.check_output(["objdump", "-h", program], text=True).splitlines():
        fields = row.split()
        if len(fields) > 4 and fields[1] == ".text":
            result["text_bytes"] = int(fields[2],16)
            result["text_address"] = int(fields[3],16)
    if app == "catalog":
        for row in subprocess.check_output(["nm", "-S", program],text=True).splitlines():
            if row.endswith(" fn_m2_10"):
                address,length,_,name=row.split()
                result["select_line"]={"address":int(address,16),"bytes":int(length,16),"symbol":name}
                break
    return result

results = {}
for path in sorted((root / "timing").glob("*/*/result.json")):
    study, case = path.parts[-3:-1]
    if (path.parent.parent/"excluded.json").exists():
        continue
    if args.include_run and study not in args.include_run:
        continue
    results.setdefault(study, {})[case] = json.loads(path.read_text())
arms = sorted({arm for cases in results.values() for case in cases.values() for arm in case["arms"]})
programs={}
counts={}
for arm in arms:
    programs[arm]={}
    for app in ("catalog", "ruff"):
        path = root / "apps" / arm / app
        if not path.is_file():
            continue
        programs[arm][app]={**identify(path,app),"split_units":{ll.name:digest(ll) for ll in sorted((root / "units" / arm / app).glob("*.ll"))}}
        manifest=path.with_suffix(".json")
        if manifest.is_file():
            programs[arm][app]["build"]=json.loads(manifest.read_text())
        for summary in sorted((root / "counts" / arm / app).glob("*/summary.json")):
            counts.setdefault(arm,{})[f"{app}-{summary.parent.name}"] = json.loads(summary.read_text())
catalog = json.loads((root/"inputs/catalog/inputs.json").read_text())
result = {
    "reference":args.reference,
    "oracles":json.loads((root / "oracles/outputs.json").read_text()),
    "input_catalog":{"provenance":catalog["provenance"],
                     "inputs":{key:{name:value[name] for name in ("bytes","sha256")} for key,value in catalog["inputs"].items()},
                     "expected":{name:catalog["expected"][name] for name in ("bytes","sha256")},
                     "entries":catalog["entries"]},
    "oracle_interpreter":"CPython 3.14.5",
    "runtime_sha256":digest(args.runtime or root / "toolchain/runtime.a"),
    "clang":subprocess.check_output([root / "toolchain/relar-toolchain/bin/clang", "--version"],text=True).splitlines()[0],
    "lld":subprocess.check_output([root / "toolchain/relar-toolchain/bin/ld.lld", "--version"],text=True).strip(),
    "machine":platform.machine(),
    "cpu_model":next(line.split(":",1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name")),
    "kernel":platform.release(),"programs":programs,"timing":results,"counts":counts,
    "hand_source_diff":(root/"hand-rewrite.patch").read_text(),
    "head_comparisons":{p.stem:json.loads(p.read_text()) for p in sorted((root/"head-comparisons").glob("*.json"))},
    "excluded_series":{p.parent.name:json.loads(p.read_text()) for p in sorted((root/"timing").glob("*/excluded.json"))},
}
args.artifact.write_bytes(gzip.compress(json.dumps(result,sort_keys=True,separators=(",",":")).encode(),mtime=0))
for run, data in results.items():
    for case, value in data.items():
        print(run,case,value["median_ms"],value["paired_speedup_95ci"])
