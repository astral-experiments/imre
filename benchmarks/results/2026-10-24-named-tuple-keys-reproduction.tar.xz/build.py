"""Build ordinary split O3 executables, then capture and verify each split IR input."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("repo", type=Path)
parser.add_argument("arm")
parser.add_argument("compiler", type=Path)
parser.add_argument("--app", choices=["catalog", "ruff"], action="append")
parser.add_argument("--hand-source", action="store_true", help="Use the benchmark's hand-rewritten catalog")
parser.add_argument("--runtime", type=Path, help="Link against a separate locked release archive")
args = parser.parse_args()
out = Path(__file__).resolve().parent
repo = args.repo.resolve()
arm = args.arm
compiler = args.compiler.resolve(strict=True)
archive = (args.runtime or (out / "toolchain/runtime.a")).resolve(strict=True)
bundle = (out / "toolchain/relar-toolchain").resolve(strict=True)
app_dir = out / "apps" / arm
scratch = out / "capture-tools" / arm
for path in (scratch / "relar-toolchain/bin", app_dir):
    path.mkdir(parents=True, exist_ok=True)
# Relar finds the packaged toolchain beside its executable.
# Each captured compilation forwards the unchanged argv and inputs to the same Clang.
for name in ("link", "lib", "bin/ld.lld"):
    link = scratch / "relar-toolchain" / name
    if not link.exists():
        link.symlink_to(bundle / name)
shimcli = scratch / "relar"
shutil.copy2(compiler, shimcli)
shim = scratch / "relar-toolchain/bin/clang"
shim.write_text("""#!/bin/sh
set -eu
case " $* " in
  *" -c -x ir module.ll -o unit-"*) for last in "$@"; do :; done
    cp module.ll "$RELAR_STUDY_IR/${last%.o}.ll" ;;
esac
exec "$RELAR_STUDY_CLANG" "$@"
""")
shim.chmod(0o755)
normal_tools = out / "normal-tools" / arm
normal_tools.mkdir(parents=True, exist_ok=True)
normal_cli = normal_tools / "relar"
shutil.copy2(compiler, normal_cli)
if not (normal_tools / "relar-toolchain").exists():
    (normal_tools / "relar-toolchain").symlink_to(bundle)

for app in args.app or ["catalog", "ruff"]:
    source_dir = out / "hand-source" if (arm == "hand" or args.hand_source) and app == "catalog" else repo
    if app == "catalog":
        source = "examples/python_catalog/__main__.py"
        modules = ["python_catalog.__main__", "python_catalog", "python_catalog.catalog"]
    else:
        source = "examples/conformance_report/upstream/conformance.py"
        modules = ["conformance"]
    units = out / "units" / arm / app
    units.mkdir(parents=True, exist_ok=True)
    def build(cli, stage, dest):
        log = out / f"logs/{arm}-{app}{stage}.log"
        cache = out / "cache" / f"{arm}-{app}{stage}"
        env = {**os.environ, "RELAR_CACHE_DIR": str(cache), "RELAR_CACHE_TRACE": "1",
               "RELAR_STUDY_CLANG": str(bundle / "bin/clang"), "RELAR_STUDY_IR": str(units)}
        with log.open("w") as handle:
            subprocess.run([cli, "build", source, "--opt-level", "3", "--runtime", archive, "-v",
                            "--no-cache", "--verbose-link", "-o", dest], cwd=source_dir,
                           env=env, stdout=handle, stderr=subprocess.STDOUT, check=True)
    build(normal_cli, "", app_dir / app)
    build(shimcli, "-capture", scratch / app)
    normal = (app_dir / app).read_bytes()
    assert normal == (scratch / app).read_bytes(), f"{app} captured binary differs"
    for i, module in enumerate(modules):
        (units / f"unit-{i}.ll").replace(units / f"{module}.ll")
    metadata = {"compiler_sha256":hashlib.sha256(compiler.read_bytes()).hexdigest(),
                "runtime_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),
                "ELF_sha256":hashlib.sha256(normal).hexdigest(), "split_modules":modules}
    (app_dir/f"{app}.json").write_text(json.dumps(metadata,indent=2,sort_keys=True)+"\n")
    print(arm, app, hashlib.sha256(normal).hexdigest(), flush=True)
