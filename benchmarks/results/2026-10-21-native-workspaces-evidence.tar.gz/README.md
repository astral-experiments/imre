# Native workspace evidence

The content-addressed logical index retains original preparation, timing,
validation and checked filesystem bytes. Source entries bind the measured commit,
Git blob IDs, modes, SHA-256 hashes and byte lengths. Every historical file under
benchmarks/results is omitted; its Git identity remains available for tree proof.
The source commit object is retained, and portable replay verifies the full Git
tree identity using retained and omitted blob identities.

The native compiler/runtime artifacts retain their original build revision.
All 74 compiled inputs are byte-identical in the measurement commit; both Git
trees and commit identities prove that equivalence. Earlier successful language
suites retain their original revision, commands and logs. Superseded failures
remain separate from the successful current validation and timing records.

Native programs, static archives, LLVM bitcode and Python bytecode are external,
hash-identified artifacts. LLVM text, build/test logs and captured outputs remain
included. Each synthetic layout includes persisted transcript and atomic-file
controls, plus separate zero- and eight-repetition compute rows. Failed validation
cases retain their exact partial file and symlink effects in checked records.

Run 2026-10-21-native-workspaces-replay.py beside the archive, manifest and index.
Replay checks data and output oracles without a developer checkout, Git, compiler
or native engine. It does not remeasure performance or authenticate timestamps.
