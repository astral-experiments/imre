"""Run frozen telemetry comparisons after compiler validation and preparation."""

import argparse
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/home/dev-user/code/oss/relar")
VALIDATION = Path("/tmp/relar-iterator-validation-v1")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", type=Path, required=True)
    parser.add_argument(
        "--modes",
        nargs="+",
        choices=("normal", "thinlto"),
        default=["normal", "thinlto"],
    )
    parser.add_argument("--samples", type=int, default=12)
    parser.add_argument("--warmups", type=int, default=8)
    parser.add_argument("--batch-pairs", type=int, default=1048576)
    parser.add_argument("--sizes", nargs="+", type=int, default=[16, 256, 4096])
    parser.add_argument("--scenarios", nargs="+")
    parser.add_argument("--cpu", type=int, default=0)
    parser.add_argument("--exploratory", action="store_true")
    args = parser.parse_args()
    assert args.samples > 0 and args.samples % 6 == 0
    assert args.warmups > 0 and args.batch_pairs > 0
    assert all(size > 0 for size in args.sizes)
    assert args.cpu in os.sched_getaffinity(0)
    tracer = next(
        line
        for line in Path("/proc/self/status").read_text().splitlines()
        if line.startswith("TracerPid:")
    )
    assert int(tracer.split()[1]) == 0, "timing must run outside ptrace"
    index = json.loads((VALIDATION / "index.json").read_text())
    build = json.loads((VALIDATION / "build.json").read_text())
    assert index["status"] == "passed"
    assert index["source_unchanged"] and index["input_guards_passed"]
    assert index["build_record"]["sha256"] == sha(VALIDATION / "build.json")
    assert index["revision"] == build["revision"]
    head = git("rev-parse", "HEAD")
    assert not git("status", "--porcelain"), "timed checkout must be clean"
    subprocess.run(
        [
            "git",
            "-C",
            str(ROOT),
            "merge-base",
            "--is-ancestor",
            index["revision"],
            head,
        ],
        check=True,
    )
    changes = git("diff", "--name-only", index["revision"], head).splitlines()
    assert set(changes) <= {
        "benchmarks/telemetry_benchmark.py",
        "benchmarks/reference/telemetry_comparison/README.md",
    }, changes
    patch = subprocess.check_output(
        ["git", "-C", str(ROOT), "diff", index["revision"], head]
    )
    templates = json.loads(Path("/tmp/relar-telemetry-commands.json").read_text())
    paths = {
        "runner": Path(__file__).resolve(),
        "command_templates": Path("/tmp/relar-telemetry-commands.json"),
        "validation_index": VALIDATION / "index.json",
        "validation_build": VALIDATION / "build.json",
    }
    for mode in args.modes:
        prepared_path = Path(f"/tmp/relar-telemetry-prepared-{mode}.json")
        prepared = json.loads(prepared_path.read_text())
        assert prepared["revision"] == head and not prepared["dirty"]
        assert prepared["input_guards_passed"]
        paths[f"{mode}_preparation"] = prepared_path
        for name, path in prepared["source_and_tool_paths"].items():
            paths[f"{mode}:{name}"] = Path(path)
        for name in ("binary", "llvm", "validation"):
            key = "validation_path" if name == "validation" else name
            paths[f"{mode}:{name}"] = Path(prepared[key])
        reference_record = (
            VALIDATION / "references" / f"telemetry-{mode}" / "build-record.json"
        )
        assert index["references"][f"telemetry-{mode}"]["sha256"] == sha(
            reference_record
        )
    hashes = {name: sha(path) for name, path in paths.items()}
    status_path = Path(str(args.prefix) + "-timing-status.json")
    assert not status_path.exists(), "choose a fresh prefix"
    record = {
        "schema": 1,
        "status": "running",
        "exploratory": args.exploratory,
        "started_at_utc": now(),
        "head": head,
        "timing_revision": head,
        "build_revision": build["revision"],
        "validation_revision": index["revision"],
        "validation_index_sha256": sha(VALIDATION / "index.json"),
        "post_validation_changes": {
            "paths": changes,
            "patch": patch.decode(),
            "patch_sha256": hashlib.sha256(patch).hexdigest(),
            "reason": "Only the benchmark target-verification harness and its guide may differ. Compiler, runtime, examples, validators, tests, and Rust reference sources remain unchanged from full validation.",
        },
        "schedule": vars(args) | {"prefix": str(args.prefix)},
        "tracer_pid": 0,
        "allowed_cpus": sorted(os.sched_getaffinity(0)),
        "protected_paths": {name: str(path) for name, path in paths.items()},
        "source_and_tool_sha256": hashes,
        "runs": [],
    }

    def save():
        status_path.write_text(json.dumps(record, indent=2) + "\n")

    def guard():
        assert git("rev-parse", "HEAD") == head
        assert not git("status", "--porcelain")
        assert hashes == {name: sha(path) for name, path in paths.items()}

    save()
    try:
        for mode in args.modes:
            guard()
            directory = Path(str(args.prefix) + "-" + mode)
            output = Path(str(directory) + ".json")
            assert not directory.exists() and not output.exists()
            command = templates[mode] + [
                "--prepared-record",
                str(paths[f"{mode}_preparation"]),
                "--artifact-dir",
                str(directory),
                "--output",
                str(output),
                "--cpu",
                str(args.cpu),
                "--samples",
                str(args.samples),
                "--warmups",
                str(args.warmups),
                "--batch-pairs",
                str(args.batch_pairs),
                "--sizes",
                *map(str, args.sizes),
            ]
            if args.scenarios:
                command += ["--scenarios", *args.scenarios]
            run = {
                "mode": mode,
                "command": command,
                "started_at_utc": now(),
                "output": str(output),
            }
            record["runs"].append(run)
            save()
            print(f"Starting {mode}: {args.prefix}", flush=True)
            process = subprocess.run(command, cwd=ROOT, check=False)
            run["exit_code"] = process.returncode
            run["completed_at_utc"] = now()
            assert process.returncode == 0
            result = json.loads(output.read_text())
            assert result["input_guards_passed"]
            assert result["revision"] == head and not result["dirty"]
            run["output_sha256"] = sha(output)
            run["status"] = "passed"
            guard()
            save()
        record["status"] = "passed"
        record["source_unchanged"] = True
        record["input_guards_passed"] = True
    except BaseException as error:
        record["status"] = "failed"
        record["error"] = repr(error)
        raise
    finally:
        record["completed_at_utc"] = now()
        save()


if __name__ == "__main__":
    main()
