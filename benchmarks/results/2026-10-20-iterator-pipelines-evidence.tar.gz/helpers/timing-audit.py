"""Independently audit frozen telemetry records; never build or execute an engine.

Run only after all measurement processes have stopped. This program uses Python's
standard library, raw input/output records, file hashes, and read-only Git calls;
it imports neither the benchmark harness nor the application's implementation.
"""

import argparse
import base64
import collections
import hashlib
import itertools
import json
import math
import os
import statistics
import subprocess
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path("/home/dev-user/code/oss/relar")
ENGINES = ("relar", "cpython", "rust")
ORDERS = tuple(itertools.permutations(ENGINES))
ALLOWED_PATCH = {
    "benchmarks/telemetry_benchmark.py",
    "benchmarks/reference/telemetry_comparison/README.md",
}
VALIDATION_REVISION = "547c7252cde4b0e5e4b1eae3f39670c71d902989"
TIMING_REVISION = "13ed29910b6f52df7959a37afd12ad46b1e5d638"
HARNESS_PATCH_SHA256 = "8e3672d3e78fa7bfde47318d0f383e1b2eb62ac650feaf17627a7000370245d7"
PYTHON_BOOTSTRAP = (
    "import runpy, sys; sys.path.insert(0, sys.argv[1]); "
    "sys.argv = ['telemetry_comparison', *sys.argv[2:]]; "
    "runpy.run_module('telemetry_comparison', run_name='__main__', alter_sys=True)"
)
HASHES = {}
CHECKS = collections.Counter()


def require(condition, message):
    CHECKS[message] += 1
    if not condition:
        raise AssertionError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    path = Path(path)
    key = str(path.resolve())
    if key not in HASHES:
        with path.open("rb") as source:
            HASHES[key] = hashlib.file_digest(source, "sha256").hexdigest()
    return HASHES[key]


def read_json(path):
    return json.loads(Path(path).read_text())


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def close(actual, expected, label):
    require(math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-14), label)


def decoded_files(files):
    result = {}
    for name, value in files.items():
        data = base64.b64decode(value["base64"], validate=True)
        require(len(data) == value["bytes"], "embedded file byte count")
        require(digest(data) == value["sha256"], "embedded file hash")
        result[name] = data
    return result


def file_metadata(files):
    return {
        name: {"bytes": len(data), "sha256": digest(data)}
        for name, data in files.items()
    }


def check_output(result, stdout, files, directories):
    require(result["returncode"] == 0, "successful protocol exit")
    require(result["stdout"] == stdout, "complete stdout equality")
    require(result["stderr"] == "", "empty stderr")
    require(result["files"] == file_metadata(files), "complete file snapshot equality")
    require(result["directories"] == directories, "complete directory equality")


def parse_rows(data):
    lines = data.decode("ascii").splitlines()
    count = int(lines[0])
    require(count == len(lines) - 1, "timing input sample count")
    rows = [tuple(map(int, line.split())) for line in lines[1:]]
    require(all(len(row) == 2 for row in rows), "timing input row arity")
    require(all(rows[i][0] < rows[i + 1][0] for i in range(count - 1)), "increasing timing timestamps")
    return rows


def independent_query(workload, batch):
    case = workload["case"]
    files = decoded_files(case["files"])
    require(case["directories"] == [] and case["hardlinks"] == {}, "simple timing filesystem")
    operation, ref_path, observed_path, report_path, limit, repeats = case["arguments"]
    threshold, repetitions = int(limit), int(repeats)
    require(threshold == 3 and repetitions > 0, "timing threshold and repetitions")
    reference, observed = parse_rows(files[ref_path]), parse_rows(files[observed_path])
    require(len(reference) == len(observed), "full input length alignment")
    require([r[0] for r in reference] == [r[0] for r in observed], "full timestamp alignment")
    errors = [observed[i][1] - reference[i][1] for i in range(len(reference))]
    absolute = [abs(error) for error in errors]
    breaches = [i for i, error in enumerate(absolute) if error > threshold]
    alert, within = bool(breaches), not breaches
    latest = reference[breaches[-1]][0] if breaches else None
    signed, distance, squared = sum(errors), sum(absolute), sum(error * error for error in errors)
    if operation == "report":
        output = (
            f"TELEMETRY\nSAMPLES {len(reference)}\nSIGNED_ERROR {signed}\n"
            f"ABSOLUTE_ERROR {distance}\nSQUARED_ERROR {squared}\n"
            f"ALERT {alert}\nWITHIN {within}\nLATEST {latest}\nEND\n"
        )
        checksum = (signed + distance + squared) * repetitions
    elif operation in ("alert", "within"):
        flag = alert if operation == "alert" else within
        output, checksum = f"{flag}\n", int(flag) * repetitions
    else:
        require(operation == "latest", "known timing operation")
        output, checksum = f"{latest}\n", (latest or 0) * repetitions
    files[report_path] = output.encode()
    stdout = f"OK\n{checksum}\n"
    require(workload["expected_stdout"] == stdout, "independent timing checksum")
    require(decoded_files(workload["expected_files"]) == files, "independent complete report and input files")
    require(workload["repetitions"] == repetitions, "workload repetition metadata")
    size = len(reference)
    if workload["scenario"] == "empty-control":
        require(size == 0 and repetitions == 1, "empty protocol control")
        visits = 0
    else:
        require(workload["label"] == f"{workload['scenario']}-{size}", "workload label and size")
        first = breaches[0] + 1 if breaches else size
        last = size - breaches[-1] if breaches else size
        visits = 3 * size + 2 * first + last if operation == "report" else last if operation == "latest" else first
        require(repetitions == max(1, batch // visits), "source-level work normalization")
        pattern = workload["scenario"].split("-", 1)[1]
        if pattern == "quiet":
            require(not breaches, "quiet workload scans to exhaustion")
        elif pattern == "early":
            require(breaches == [0], "early workload exits at first sample")
        elif pattern == "recent":
            require(breaches == [size - 1], "reverse workload exits at latest sample")
        else:
            require(pattern == "mixed" and bool(breaches), "mixed report workload")
        require(max(absolute, default=0) <= 9, "bounded measured errors")
        require(all(-10000 <= row[1] <= 10000 for row in reference), "bounded measured reference values")
    require(workload["inspected_pairs_per_call"] == visits, "source-level visit count")
    return stdout, files, size


def percentile(values, fraction):
    values = sorted(values)
    position = (len(values) - 1) * fraction
    lower = int(position)
    upper = min(lower + 1, len(values) - 1)
    return values[lower] + (values[upper] - values[lower]) * (position - lower)


def audit_workload(workload, record, control=None):
    stdout, files, size = independent_query(workload, record["batch_pairs"])
    arguments = workload["case"]["arguments"]
    prepared = record["preparation"]
    prefixes = {
        "relar": [prepared["binary"]],
        "rust": [prepared["source_and_tool_paths"]["rust"]],
    }
    processes = 0
    for name in ENGINES:
        check_output(workload["gates"][name], stdout, files, [])
        processes += 1
    for phase, count in (("warmups", record["warmups"]), ("samples", record["samples"])):
        rounds = workload[phase]
        require(len(rounds) == count, "complete phase round count")
        for index, sample in enumerate(rounds):
            order = tuple(sample["order"])
            require(sample["index"] == index and order == ORDERS[index % 6], "declared round order")
            for name in ENGINES:
                result = sample[name]
                require(type(result["elapsed_ns"]) is int and result["elapsed_ns"] > 0, "positive raw duration")
                require(result["command"][-6:] == arguments, "identical engine arguments")
                if name in prefixes:
                    require(result["command"] == prefixes[name] + arguments, "frozen native executable command")
                else:
                    require(result["command"][0] == prepared["source_and_tool_paths"]["python"], "frozen CPython executable command")
                    require(result["command"][1:4] == ["-I", "-B", "-c"], "isolated CPython invocation")
                    require(result["command"][5] == str(ROOT / "examples"), "CPython example import path")
                    require(result["command"] == [prepared["source_and_tool_paths"]["python"], "-I", "-B", "-c", PYTHON_BOOTSTRAP, str(ROOT / "examples"), *arguments], "exact CPython program invocation")
                check_output(result, stdout, files, [])
                processes += 1
        if phase == "samples":
            counts = collections.Counter(tuple(sample["order"]) for sample in rounds)
            require(counts == {order: count // 6 for order in ORDERS}, "all six measured permutations balanced")
            positions = collections.Counter((name, pos) for sample in rounds for pos, name in enumerate(sample["order"]))
            require(set(positions.values()) == {count // 3}, "measured engine positions balanced")
            predecessors = collections.Counter((sample["order"][i], sample["order"][i + 1]) for sample in rounds for i in (0, 1))
            require(set(predecessors.values()) == {count // 3}, "within-round directed predecessors balanced")
    medians = {}
    for name in ENGINES:
        values = [sample[name]["elapsed_ns"] / 1e9 for sample in workload["samples"]]
        computed = {
            "median_seconds": statistics.median(values),
            "min_seconds": min(values),
            "max_seconds": max(values),
            "p25_seconds": percentile(values, 0.25),
            "p75_seconds": percentile(values, 0.75),
        }
        require(set(workload["summary"][name]) == set(computed), "complete summary statistics")
        for key, value in computed.items():
            close(workload["summary"][name][key], value, "recomputed " + key)
        medians[name] = computed["median_seconds"]
    ratios = {}
    for left, right in (("cpython", "relar"), ("relar", "rust"), ("cpython", "rust")):
        key = f"{left}_over_{right}"
        ratios[key] = medians[left] / medians[right]
        close(workload[key], ratios[key], "recomputed " + key)
    fractions = {}
    if control:
        for name in ENGINES:
            fractions[name] = control["medians"][name] / medians[name]
            close(workload["startup_control_fraction"][name], fractions[name], "recomputed startup fraction")
    return {
        "label": workload["label"], "size": size, "scenario": workload["scenario"],
        "repetitions": workload["repetitions"], "medians": medians,
        "ratios": ratios, "startup_fractions": fractions, "checked_processes": processes,
    }


def elf(path):
    with Path(path).open("rb") as source:
        data = source.read(20)
    require(data[:5] == b"\x7fELF\x02", "actual ELF64 executable")
    byte_order = {1: "little", 2: "big"}[data[5]]
    return {"bits": 64, "byte_order": byte_order, "machine": int.from_bytes(data[18:20], byte_order)}


def audit_validation(validation):
    require(validation["input_guards_passed"] is True, "functional validation input guards")
    require(validation["cases"] == len(validation["records"]) == 258, "258 complete functional cases")
    require(set(validation["engines"]) == set(ENGINES), "functional validation three engines")
    labels = set()
    for item in validation["records"]:
        label = item["case"]["label"]
        require(label not in labels, "unique functional case labels")
        labels.add(label)
        decoded_files(item["case"]["files"])
        expected_files = decoded_files(item["expected_files"])
        require(set(item["engines"]) == set(ENGINES), "complete functional engine results")
        directories = item["engines"]["cpython"]["directories"]
        for result in item["engines"].values():
            check_output(result, item["expected_stdout"], expected_files, directories)
    device = validation["output_device"]
    require(set(device) == set(ENGINES), "all engines checked on full output device")
    require(all(value == device["cpython"] for value in device.values()), "device error complete effects equal")
    require(device["cpython"]["stdout"] == "ERROR\nOSError\nreport: cannot write\n", "terminal output error observed")
    return len(labels)


def audit_preparation(record, status, mode):
    prep = record["preparation"]
    preparation_path = status["protected_paths"][mode + "_preparation"]
    require(sha(preparation_path) == record["preparation_record_sha256"], "timing bound to preparation record")
    require(read_json(preparation_path) == prep, "embedded preparation exactly matches file")
    require(prep["input_guards_passed"] is True and prep["dirty"] is False, "clean guarded preparation")
    require(prep["revision"] == status["timing_revision"], "preparation timing revision")
    paths, hashes = prep["source_and_tool_paths"], prep["source_and_tool_sha256"]
    require(set(paths) == set(hashes), "preparation path and hash key equality")
    for name, path in paths.items():
        require(sha(path) == hashes[name], "rehash frozen source or tool")
    require(record["source_and_tool_sha256"] == hashes, "timing source and tool binding")
    for key in ("binary", "llvm", "validation"):
        file_path = prep["validation_path"] if key == "validation" else prep[key]
        require(sha(file_path) == prep[key + "_sha256"], "prepared artifact hash")
    require(record["binary_sha256"] == prep["binary_sha256"], "timed native executable hash")
    require(read_json(prep["validation_path"]) == prep["validation"], "embedded functional validation matches file")
    require(prep["validation"]["source_and_binary_sha256"]["relar"] == prep["binary_sha256"], "validated Relar executable is timed executable")
    require(prep["validation"]["source_and_binary_sha256"]["rust"] == hashes["rust"], "validated Rust executable is timed executable")
    for name, value in prep["validation"]["source_and_binary_sha256"].items():
        require(value == (prep["binary_sha256"] if name == "relar" else hashes[name]), "validation source and binary binding")
    rust, build = prep["rust_build_record"], prep["relar_build_record"]
    require(read_json(paths["rust_build_record"]) == rust, "embedded Rust build record matches file")
    require(read_json(paths["relar_build_record"]) == build, "embedded Relar build record matches file")
    require(build["revision"] == status["build_revision"], "compiler build revision")
    require(build["source_matches_revision"] is True and build["input_guards_passed"] is True, "compiler build source guards")
    for tool in build["tools"].values():
        require(sha(tool["path"]) == tool["sha256"], "compiler build toolchain binary rehash")
    require(hashes["compiler"] == build["sha256"]["compiler"], "exact built compiler selected")
    require(hashes["runtime"] == build["sha256"]["thinlto_runtime" if mode == "thinlto" else "normal_runtime"], "exact linking-mode runtime selected")
    require(rust["input_guards_passed"] is True, "Rust build input guards")
    require(rust["native_artifact"]["fresh"] is False, "Rust local crate freshly compiled")
    for name in ("cargo", "rustc"):
        require(rust["tool_sha256"][name] == build["tools"]["ohm-" + name]["sha256"], "Rust reference actual toolchain binding")
    require("+ohm" in rust["command"] and "-Zohm-defaults=no" in rust["command"], "Rust reference disables experimental Ohm defaults")
    require(all(flag in rust["command"] for flag in ("--release", "--locked", "--offline", "--verbose", "--message-format=json-render-diagnostics")), "Rust reproducible release build command")
    artifacts = []
    for line in rust["build_stdout"].splitlines():
        try:
            item = json.loads(line)
        except ValueError:
            continue
        if item.get("reason") == "compiler-artifact" and item.get("executable") == rust["native_artifact"]["executable"]:
            artifacts.append(item)
    require(artifacts == [rust["native_artifact"]], "fresh Rust artifact retained in raw Cargo output")
    require(rust["binary_sha256"] == hashes["rust"] == rust["binaries"]["reference"]["sha256"], "Rust fresh artifact hash binding")
    require(Path(paths["rust"]).stat().st_size == rust["binary_bytes"] == rust["binaries"]["reference"]["bytes"], "Rust executable byte count")
    require(rust["native_artifact"]["profile"]["opt_level"] == "3", "Rust artifact O3 profile")
    for name, value in rust["sources"].items():
        require(digest(rust["source_contents"][name].encode()) == value == hashes["rust_source:" + name], "Rust embedded source content binding")
    for name, value in build["source_sha256"].items():
        require(value == hashes["relar_source:" + name], "compiler source content binding")
    thin = mode == "thinlto"
    require(record["thinlto"] == prep["thinlto"] == rust["thinlto"] == thin, "matching linking modes")
    env = rust["environment"]
    require(Path(rust["native_artifact"]["executable"]) == Path(env["CARGO_TARGET_DIR"]) / "release/telemetry-reference", "Rust native host artifact path")
    require(env["CARGO_PROFILE_RELEASE_OPT_LEVEL"] == "3", "Rust explicit O3")
    require(env["CARGO_PROFILE_RELEASE_CODEGEN_UNITS"] == "16", "Rust matching codegen unit policy")
    require(env["CARGO_PROFILE_RELEASE_LTO"] == ("thin" if thin else "off"), "Rust explicit linking mode")
    require(rust["llvm_budget"] == (1000 if thin else None), "matching LLVM ThinLTO budget")
    require(env["RUSTFLAGS"] == ("-Cllvm-args=-import-instr-limit=1000 -Cllvm-args=-inline-threshold=1000" if thin else ""), "Rust optimization flag binding")
    require(env["CARGO_ENCODED_RUSTFLAGS"] == (None if thin else ""), "Rust encoded optimization flag binding")
    host = next(line.split(": ", 1)[1] for line in rust["rustc_verbose"].splitlines() if line.startswith("host: "))
    require(host == build["target"] == prep["effective_target"], "matching compiler and Rust host target")
    require(prep["native_elf"] == elf(prep["binary"]) == elf(paths["rust"]), "actual native executable target equality")
    command = prep["compile_command"]
    require(command[0] == paths["compiler"], "frozen compiler command")
    require(command[1:3] == ["build", str(ROOT / "examples/telemetry_comparison/__main__.py")], "compiled telemetry entrypoint")
    for flag, expected in (("--target", host), ("--runtime", paths["runtime"]), ("--clang", paths["clang"]), ("--opt-level", "3"), ("--module-root", str(ROOT / "examples")), ("-o", prep["binary"]), ("--emit-llvm", prep["llvm"])):
        require(command[command.index(flag) + 1] == expected, "explicit compile flag " + flag)
    require(("--lto-linker" in command) == thin, "Relar linking mode command")
    if thin:
        require(command[command.index("--lto-linker") + 1] == paths["lto_linker"], "frozen ThinLTO linker command")
    require(not any("sanitize" in arg for arg in command), "timing binary unsanitized")
    cases = audit_validation(prep["validation"])
    return {"preparation": str(preparation_path), "functional_cases": cases, "target": host, "native_sha256": prep["binary_sha256"], "rust_sha256": hashes["rust"]}


def audit_status(path, final):
    status = read_json(path)
    require(status["status"] == "passed", "timing runner terminal success")
    require(status["source_unchanged"] is True and status["input_guards_passed"] is True, "timing runner final guards")
    require(status["tracer_pid"] == 0, "timing outside ptrace")
    if final:
        require(status["exploratory"] is False, "final timing non-exploratory")
        require(status["schedule"]["samples"] == 12 and status["schedule"]["warmups"] == 8, "final 12 measured and 8 warmup rounds")
    require(status["build_revision"] == status["validation_revision"], "build and validation revision equality")
    require(status["validation_revision"] == VALIDATION_REVISION and status["timing_revision"] == TIMING_REVISION, "reviewed frozen implementation and timing revisions")
    patch = status["post_validation_changes"]
    require(set(patch["paths"]) <= ALLOWED_PATCH, "post-validation changes restricted to harness and guide")
    require(digest(patch["patch"].encode()) == patch["patch_sha256"], "recorded post-validation patch hash")
    require(patch["patch_sha256"] == HARNESS_PATCH_SHA256, "only the independently reviewed target-provenance patch")
    require(git("diff", status["validation_revision"], status["timing_revision"]).decode() == patch["patch"], "exact Git post-validation patch")
    require(set(git("diff", "--name-only", status["validation_revision"], status["timing_revision"]).decode().splitlines()) == set(patch["paths"]), "exact Git post-validation path set")
    require(set(status["protected_paths"]) == set(status["source_and_tool_sha256"]), "runner protected paths cover hashes")
    for name, value in status["source_and_tool_sha256"].items():
        require(sha(status["protected_paths"][name]) == value, "runner protected input rehash")
    index_path = status["protected_paths"]["validation_index"]
    require(sha(index_path) == status["validation_index_sha256"], "full validation index binding")
    index = read_json(index_path)
    require(index["status"] == "passed" and index["source_unchanged"] is True and index["input_guards_passed"] is True, "full validation terminal success and guards")
    require(index["revision"] == status["validation_revision"], "full validation source revision binding")
    require(index["build_record"]["sha256"] == sha(status["protected_paths"]["validation_build"]), "full validation compiler build binding")
    schedule = status["schedule"]
    require(len(status["runs"]) == len(schedule["modes"]), "complete runner linking modes")
    records = []
    for run, mode in zip(status["runs"], schedule["modes"]):
        require(run["mode"] == mode and run["status"] == "passed" and run["exit_code"] == 0, "successful scheduled linking mode")
        require(sha(run["output"]) == run["output_sha256"], "timing output record hash")
        record = read_json(run["output"])
        require(datetime.fromisoformat(run["started_at_utc"]) <= datetime.fromisoformat(record["started_at_utc"]) <= datetime.fromisoformat(record["completed_at_utc"]) <= datetime.fromisoformat(run["completed_at_utc"]), "timing record within runner interval")
        require(datetime.fromisoformat(record["preparation"]["completed_at_utc"]) < datetime.fromisoformat(record["started_at_utc"]), "compilation and functional validation finished before timing")
        require(record["kind"] == "telemetry-benchmark" and record["input_guards_passed"] is True, "complete telemetry benchmark record")
        require(record["revision"] == status["timing_revision"] and record["dirty"] is False, "clean timed source revision")
        for field in ("samples", "warmups", "batch_pairs"):
            require(record[field] == schedule[field], "scheduled " + field)
        require(record["cpu"]["affinity"] == [schedule["cpu"]], "single scheduled CPU affinity")
        require(record["python"]["implementation"] == "cpython" and record["python"]["jit_enabled"] is False, "declared CPython comparison configuration")
        require(tuple(map(tuple, record["engine_orders"])) == ORDERS, "six declared engine permutations")
        preparation = audit_preparation(record, status, mode)
        require(sha(record["preparation"]["source_and_tool_paths"]["rust_build_record"]) == index["references"]["telemetry-" + mode]["sha256"], "timed Rust reference is full-validation reference")
        control = audit_workload(record["startup_control"], record)
        workloads = [audit_workload(workload, record, control) for workload in record["workloads"]]
        require([(w["size"], w["scenario"]) for w in workloads] == list(itertools.product(schedule["sizes"], schedule["scenarios"])), "complete scheduled workload cross-product")
        records.append({"mode": mode, "record": run["output"], "record_sha256": run["output_sha256"], "preparation": preparation, "control": control, "workloads": workloads})
    return {"status_record": str(path), "sha256": sha(path), "timing_revision": status["timing_revision"], "validation_revision": status["validation_revision"], "schedule": schedule, "records": records}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--status", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pilot", action="store_true")
    args = parser.parse_args()
    allowed = os.sched_getaffinity(0)
    os.sched_setaffinity(0, {max(allowed)})
    statuses = [audit_status(path, not args.pilot) for path in args.status]
    records = [record for status in statuses for record in status["records"]]
    if not args.pilot:
        require(len(statuses) == 2 and len(records) == 4, "two final statuses and four timing records")
        scenarios = {"report-mixed", "alert-quiet", "within-quiet", "latest-quiet", "alert-early", "within-early", "latest-recent"}
        for mode in ("normal", "thinlto"):
            items = [w for record in records if record["mode"] == mode for w in record["workloads"]]
            require(len(items) == 21 and {(w["size"], w["scenario"]) for w in items} == set(itertools.product((16, 256, 4096), scenarios)), "all 21 final workloads per linking mode")
        for status in statuses:
            selected = set(status["schedule"]["scenarios"])
            full = {"report-mixed", "alert-quiet", "within-quiet", "latest-quiet"}
            early = {"alert-early", "within-early", "latest-recent"}
            require(selected in (full, early), "final scenario batching groups")
            require(status["schedule"]["batch_pairs"] == (8388608 if selected == full else 2097152), "pilot-selected final batching")
    intervals = sorted((datetime.fromisoformat(read_json(path)["started_at_utc"]), datetime.fromisoformat(read_json(path)["completed_at_utc"])) for path in args.status)
    require(all(intervals[i][1] <= intervals[i + 1][0] for i in range(len(intervals) - 1)), "timing groups do not overlap")
    checked = sum(record["control"]["checked_processes"] + sum(w["checked_processes"] for w in record["workloads"]) for record in records)
    output = {"kind": "independent-telemetry-raw-record-audit", "status": "passed", "completed_at_utc": datetime.now(timezone.utc).isoformat(), "auditor_sha256": sha(__file__), "engine_processes_executed_by_auditor": 0, "timed_and_warmup_and_gate_process_records_checked": checked, "distinct_files_rehashed": len(HASHES), "checks": dict(CHECKS), "statuses": statuses}
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({key: value for key, value in output.items() if key not in ("checks", "statuses")}, indent=2))


if __name__ == "__main__":
    main()
