r"""Package completed iterator/telemetry evidence without running any experiments.

All paths are explicit. Repeat --timing-status and --timing for separate final
measurement batches; labels must be unique, but their normal/ThinLTO modes may
repeat. Both modes must be represented. Audits must already have passed and bind
every supplied status and timing record by SHA256.

Example (only after validation, preparation, timing, and audits finish):
  python3 -I -B /tmp/imre-iterator-package-evidence.py \
    --root /home/dev-user/code/oss/imre \
    --validation-dir /tmp/imre-iterator-validation-v1 \
    --validation-audit /tmp/imre-iterator-validation-audit.json \
    --validation-audit-script /tmp/imre-iterator-validation-audit.py \
    --timing-status full /tmp/telemetry-full-timing-status.json \
    --timing full-normal /tmp/telemetry-full-normal.json /tmp/telemetry-full-normal \
    --timing full-thinlto /tmp/telemetry-full-thinlto.json /tmp/telemetry-full-thinlto \
    --preparation normal /tmp/imre-telemetry-prepared-normal.json /tmp/imre-telemetry-prepared-normal \
    --preparation thinlto /tmp/imre-telemetry-prepared-thinlto.json /tmp/imre-telemetry-prepared-thinlto \
    --timing-audit /tmp/imre-telemetry-timing-audit.json \
    --timing-audit-script /tmp/imre-telemetry-timing-audit.py \
    --allowed-post-validation-patch /tmp/imre-telemetry-target-fix.patch \
    --prefix /tmp/2026-10-20-iterator

The allowed patch must be the exact `git diff VALIDATION TIMING` bytes retained
in each timing status. Only telemetry_benchmark.py and its reference README may
differ. The original validated source and the timing-source overlay are retained.
Archive member ordering, ownership, modes, and timestamps are normalized. Output
prefixes do not affect archive bytes. All selected files and directory membership
are guarded before and after writing; native code and bytecode are hash-recorded
exclusions, while LLVM text and raw benchmark input/output files are retained.
"""

import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile


ALLOWED_CHANGES = {
    "benchmarks/telemetry_benchmark.py",
    "benchmarks/reference/telemetry_comparison/README.md",
}
TOOLS = {"python", "clang", "lto_linker"}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def relative_name(value):
    name = PurePosixPath(value)
    require(not name.is_absolute() and ".." not in name.parts and str(name) != ".",
            f"unsafe archive member: {value}")
    return str(name)


def native_kind(header):
    """Inspect bytes, preserving data files merely named *.bin, *.a, or *.pyc."""
    if header.startswith(b"\x7fELF"):
        return "ELF executable, object, or shared library"
    if header.startswith((b"!<arch>\n", b"!<thin>\n")):
        return "static archive"
    if header.startswith((b"BC\xc0\xde", b"\xde\xc0\x17\x0b")):
        return "LLVM bitcode"
    if header[:4] in {b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
                      b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe",
                      b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",
                      b"\xca\xfe\xba\xbf", b"\xbf\xba\xfe\xca"}:
        return "Mach-O native code or Java bytecode"
    if header.startswith(b"MZ"):
        return "PE executable or object"
    if header.startswith(b"\0asm"):
        return "WebAssembly bytecode"
    magic = int.from_bytes(header[:2], "little")
    if (header[:4] == importlib.util.MAGIC_NUMBER
            or header[2:4] == b"\r\n" and (3000 <= magic < 4000 or magic == 62211)):
        return "Python bytecode"
    return None


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def hash_values(value):
    """Collect audit hash bindings without depending on its presentation layout."""
    if isinstance(value, str):
        return {value} if re.fullmatch(r"[0-9a-f]{64}", value) else set()
    if isinstance(value, dict):
        return set().union(*(hash_values(item) for item in value.values()))
    if isinstance(value, list):
        return set().union(*(hash_values(item) for item in value))
    return set()


def command_option(command, name):
    require(command.count(name) == 1, f"expected exactly one {name} in command")
    return Path(command[command.index(name) + 1]).resolve(strict=True)


class Package:
    def __init__(self):
        self.files = {}
        self.trees = {}
        self.members = {}
        self.exclusions = []

    def guard(self, path, expected=None):
        path = Path(path).absolute()
        require(path.is_file(), f"missing regular input: {path}")
        value = {"sha256": sha(path), "bytes": path.stat().st_size,
                 "resolved": str(path.resolve(strict=True)),
                 "symlink": os.readlink(path) if path.is_symlink() else None}
        require(expected is None or value["sha256"] == expected,
                f"input hash mismatch: {path}")
        prior = self.files.setdefault(path, value)
        require(prior == value, f"input changed while packaging: {path}")
        return value["sha256"]

    def read_json(self, path):
        self.guard(path)
        data = Path(path).read_bytes()
        require(digest(data) == self.files[Path(path).absolute()]["sha256"],
                f"JSON changed while reading: {path}")
        return json.loads(data)

    def add_bytes(self, name, data, mode=0o644):
        name = relative_name(name)
        require(name not in self.members, f"duplicate archive member: {name}")
        require(native_kind(data[:16]) is None, f"native bytes in source member: {name}")
        self.members[name] = {"data": data, "sha256": digest(data),
                              "bytes": len(data), "mode": mode}

    def add_file(self, name, path, *, omit=None):
        name, path = relative_name(name), Path(path).absolute()
        value = self.guard(path)
        with path.open("rb") as stream:
            reason = omit or native_kind(stream.read(16))
        if reason:
            self.exclusions.append({"would_be_member": name, "path": str(path),
                                    "sha256": value, "bytes": path.stat().st_size,
                                    "reason": reason})
            return
        require(not path.is_symlink(), f"symlink cannot be archived: {path}")
        require(name not in self.members, f"duplicate archive member: {name}")
        self.members[name] = {"path": path, "sha256": value,
                              "bytes": path.stat().st_size, "mode": 0o644}

    @staticmethod
    def tree_entries(directory):
        require(directory.is_dir() and not directory.is_symlink(),
                f"expected regular input directory: {directory}")
        entries = {}
        for path in sorted(directory.rglob("*")):
            mode = path.lstat().st_mode
            require(stat.S_ISDIR(mode) or stat.S_ISREG(mode),
                    f"special file or symlink in evidence: {path}")
            entries[path.relative_to(directory).as_posix()] = stat.S_ISDIR(mode)
        return entries

    def add_tree(self, name, directory):
        directory = Path(directory).absolute()
        entries = self.tree_entries(directory)
        require(self.trees.setdefault(directory, entries) == entries,
                f"directory changed while packaging: {directory}")
        for relative, is_directory in entries.items():
            if not is_directory:
                self.add_file(f"{name}/{relative}", directory / relative)

    def check(self):
        for path in list(self.files):
            self.guard(path)
        for directory, entries in self.trees.items():
            require(self.tree_entries(directory) == entries,
                    f"directory membership changed: {directory}")

    def write(self, prefix, metadata):
        archive_path = Path(str(prefix) + "-evidence.tar.gz")
        manifest_path = Path(str(prefix) + "-evidence-manifest.json")
        temporary = Path(str(archive_path) + ".partial")
        require(not any(path.exists() for path in (archive_path, manifest_path, temporary)),
                "output already exists; choose a fresh prefix")
        require(all(directory != prefix.parent and directory not in prefix.parents
                    for directory in self.trees), "outputs overlap an input directory")
        self.add_bytes("provenance/package.json", json_bytes(metadata))
        self.add_bytes("provenance/exclusions.json", json_bytes(sorted(
            self.exclusions, key=lambda item: item["would_be_member"])))
        self.check()
        with temporary.open("xb") as raw:
            with gzip.GzipFile(filename="", mode="wb", fileobj=raw,
                               mtime=0, compresslevel=9) as compressed:
                with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                    for name, value in sorted(self.members.items()):
                        data = value["data"] if "data" in value else value["path"].read_bytes()
                        require(digest(data) == value["sha256"] and len(data) == value["bytes"],
                                f"member changed during write: {name}")
                        member = tarfile.TarInfo(name)
                        member.size, member.mode, member.mtime = len(data), value["mode"], 0
                        member.uid = member.gid = 0
                        member.uname = member.gname = ""
                        archive.addfile(member, io.BytesIO(data))
        with tarfile.open(temporary, "r:gz") as archive:
            require(archive.getnames() == sorted(self.members), "archive member set differs")
            for member in archive:
                require(member.isfile(), f"non-regular archive member: {member.name}")
                data = archive.extractfile(member).read()
                expected = self.members[member.name]
                require(digest(data) == expected["sha256"] and len(data) == expected["bytes"]
                        and member.mode == expected["mode"] and member.mtime == 0
                        and member.uid == member.gid == 0 and not member.uname and not member.gname
                        and native_kind(data[:16]) is None, f"bad archive member: {member.name}")
        self.check()
        manifest = {"schema": 1, "status": "passed", **metadata,
                    "archive": {"name": archive_path.name, "sha256": sha(temporary),
                                "bytes": temporary.stat().st_size},
                    "member_count": len(self.members),
                    "members": {name: {key: value[key] for key in ("sha256", "bytes", "mode")}
                                for name, value in sorted(self.members.items())},
                    "excluded_artifact_count": len(self.exclusions),
                    "guarded_input_files": len(self.files), "guarded_input_trees": len(self.trees)}
        # Exclusive creation never overwrites evidence from an earlier run.
        os.link(temporary, archive_path)
        temporary.unlink()
        with manifest_path.open("xb") as stream:
            stream.write(json_bytes(manifest))
        print(json.dumps({"archive": str(archive_path), "manifest": str(manifest_path),
                          "archive_sha256": manifest["archive"]["sha256"],
                          "members": len(self.members), "excluded": len(self.exclusions)}, indent=2))


def labeled(values):
    result = {}
    for label, *paths in values:
        require(re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_-]*", label), f"unsafe label: {label}")
        require(label not in result, f"duplicate label: {label}")
        result[label] = tuple(Path(path).resolve(strict=True) for path in paths)
    return dict(sorted(result.items()))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    for flag in ("root", "validation-dir", "validation-audit", "validation-audit-script",
                 "timing-audit", "timing-audit-script", "allowed-post-validation-patch", "prefix"):
        parser.add_argument("--" + flag, type=Path, required=True)
    parser.add_argument("--timing-status", nargs=2, action="append", required=True,
                        metavar=("LABEL", "JSON"))
    for flag in ("timing", "preparation"):
        parser.add_argument("--" + flag, nargs=3, action="append", required=True,
                            metavar=("LABEL", "RECORD", "DIRECTORY"))
    parser.add_argument("--extra", nargs=2, action="append", default=[], metavar=("LABEL", "PATH"))
    args = parser.parse_args()
    root, validation = args.root.resolve(strict=True), args.validation_dir.resolve(strict=True)
    prefix = args.prefix.resolve()
    require(Path("/tmp") in prefix.parents and prefix.parent.is_dir(), "output parent must exist under /tmp")
    package = Package()
    statuses, timings, preparations, extras = map(labeled, (
        args.timing_status, args.timing, args.preparation, args.extra))
    require(len({paths[0] for paths in timings.values()}) == len(timings),
            "distinct timing labels must select distinct record paths")
    require(len({paths[0] for paths in statuses.values()}) == len(statuses),
            "distinct timing status labels must select distinct paths")

    def git(*arguments):
        return subprocess.check_output(["git", "-C", str(root), *arguments])

    index = package.read_json(validation / "index.json")
    build = package.read_json(validation / "build.json")
    validation_audit = package.read_json(args.validation_audit)
    timing_audit = package.read_json(args.timing_audit)
    require(all(value["status"] == "passed" for value in (index, validation_audit, timing_audit)),
            "validation and both audits must be passed")
    require(index["source_unchanged"] and index["input_guards_passed"]
            and build["source_matches_revision"] and build["input_guards_passed"],
            "validation/build guards did not pass")
    revision = index["revision"]
    require(build["revision"] == validation_audit["validation_revision"] == revision,
            "build and validation revision mismatch")
    package.guard(validation / "index.json", validation_audit["validation_index_sha256"])
    package.guard(validation / "build.json", index["build_record"]["sha256"])
    package.guard(args.validation_audit_script, validation_audit["audit_script_sha256"])
    package.guard(args.timing_audit_script,
                  timing_audit.get("auditor_sha256", timing_audit.get("audit_script_sha256")))
    require(package.guard(args.timing_audit_script) in hash_values(timing_audit),
            "timing audit does not bind its auditor script")
    require(index["job_counts"] == {"passed": len(index["jobs"]), "failed": 0},
            "validation jobs are incomplete")
    counts = validation_audit["counts"]
    require(counts["recorded_jobs"] == counts["passed_jobs"] == len(index["jobs"])
            and counts["failed_jobs"] == 0
            and counts["rust_units"]["total"] == index["unit_tests_passed"],
            "validation coverage differs from audit")
    for job in index["jobs"]:
        require(job["status"] == "passed" and job["exit_code"] == 0, "failed validation job")
        for key in ("record", "stdout", "stderr"):
            package.guard(job[key], job[key + "_sha256"])
    evidence_manifest = package.read_json(validation / "evidence-sha256.json")
    package.guard(validation / "evidence-sha256.json", index["evidence_manifest_sha256"])
    require(len(evidence_manifest) == validation_audit["guard_checks"]["evidence_manifest_entries"],
            "validation evidence manifest count differs")
    for name, expected in evidence_manifest.items():
        package.guard(validation / relative_name(name), expected)
    package.guard(validation / "runner.py", index["runner_sha256"])
    source = package.read_json(validation / "source-before.json")
    require(source == package.read_json(validation / "source-after.json")
            and source["revision"] == revision and source["status"] == "", "validation source changed")
    require(source["tree"] == git("rev-parse", revision + "^{tree}").decode().strip(),
            "validation Git tree differs")
    names = sorted(source["files"])
    require(names == sorted(name for name in git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
                            if not name.startswith("benchmarks/results/")), "source snapshot is incomplete")
    with tarfile.open(fileobj=io.BytesIO(git("archive", "--format=tar", revision, "--", *names))) as archive:
        contents = {item.name: (archive.extractfile(item).read(), item.mode)
                    for item in archive if item.isfile()}
    require(set(contents) == set(names), "Git source archive is incomplete")
    for name, entry in source["files"].items():
        data, mode = contents[name]
        require(digest(data) == entry["sha256"] and bool(mode & 0o111) == entry["executable"],
                f"Git source snapshot differs: {name}")
        package.add_bytes("source/" + name, data, 0o755 if mode & 0o111 else 0o644)
    require(all(digest(contents[name][0]) == value for name, value in build["source_sha256"].items()),
            "compiler/runtime build source differs")
    package.add_tree("validation", validation)
    package.add_file("audits/validation.json", args.validation_audit)
    package.add_file("audits/timing.json", args.timing_audit)
    package.add_file("helpers/validation-audit.py", args.validation_audit_script)
    package.add_file("helpers/timing-audit.py", args.timing_audit_script)
    for name, value in sorted(index["tools"].items()):
        package.guard(value["path"], value["sha256"])
        package.add_file(f"tools/validation/{name}", value["path"], omit="external tool executable")

    status_records = {label: package.read_json(paths[0]) for label, paths in statuses.items()}
    timing_revision, = {value["timing_revision"] for value in status_records.values()}
    require(timing_revision != revision, "expected the explicit post-validation harness fix")
    subprocess.run(["git", "-C", str(root), "merge-base", "--is-ancestor", revision, timing_revision], check=True)
    changed = git("diff", "--name-only", revision, timing_revision).decode().splitlines()
    require(set(changed) <= ALLOWED_CHANGES and "benchmarks/telemetry_benchmark.py" in changed,
            f"post-validation measured source changed: {changed}")
    patch = git("diff", "--no-ext-diff", "--no-textconv", revision, timing_revision)
    package.guard(args.allowed_post_validation_patch, digest(patch))
    package.add_file("provenance/post-validation.patch", args.allowed_post_validation_patch)
    for name in changed:
        contents[name] = (git("show", f"{timing_revision}:{name}"), contents[name][1])
        package.add_bytes("timing-source-overlay/" + name, contents[name][0])
    audit_hashes = hash_values(timing_audit)
    audited_statuses = {}
    for audited in timing_audit["statuses"]:
        path = Path(audited["status_record"]).resolve(strict=True)
        require(path not in audited_statuses, "timing audit repeats a status record")
        require(audited["validation_revision"] == revision
                and audited["timing_revision"] == timing_revision,
                "timing audit describes another source or validation")
        audited_statuses[path] = audited
    require(set(audited_statuses) == {paths[0] for paths in statuses.values()},
            "explicit timing statuses must exactly cover the independent audit")
    run_bindings = {}
    for label, status in status_records.items():
        audited = audited_statuses[statuses[label][0]]
        require(status["status"] == "passed" and not status["exploratory"]
                and status["source_unchanged"] and status["input_guards_passed"],
                f"incomplete or exploratory timing status: {label}")
        require(status["head"] == status["timing_revision"] == timing_revision
                and status["validation_revision"] == status["build_revision"] == revision
                and status["validation_index_sha256"] == package.guard(validation / "index.json"),
                f"timing revision or validation mismatch: {label}")
        require(package.guard(statuses[label][0], audited["sha256"]) in audit_hashes
                and audited["schedule"] == status["schedule"],
                f"independent timing status binding differs: {label}")
        for key, path in (("validation_index", validation / "index.json"),
                          ("validation_build", validation / "build.json")):
            require(Path(status["protected_paths"][key]).resolve(strict=True) == path
                    and status["source_and_tool_sha256"][key] == package.guard(path),
                    f"timing status does not bind the validated index/build: {label}")
        change = status["post_validation_changes"]
        require(change["paths"] == changed and change["patch"].encode() == patch
                and change["patch_sha256"] == digest(patch), f"different allowed patch: {label}")
        require(package.guard(statuses[label][0]) in audit_hashes, f"unaudited timing status: {label}")
        package.add_file(f"timing/status/{label}.json", statuses[label][0])
        require(set(status["protected_paths"]) == set(status["source_and_tool_sha256"]),
                f"incomplete timing input guards: {label}")
        for name, path in sorted(status["protected_paths"].items()):
            package.guard(path, status["source_and_tool_sha256"][name])
            if name in {"runner", "helper", "command_templates"}:
                package.add_file(f"helpers/{label}/{Path(path).name}", path)
        audited_runs = {}
        for audited_run in audited["records"]:
            path = Path(audited_run["record"]).resolve(strict=True)
            require(path not in audited_runs, "independent audit repeats a timing record")
            audited_runs[path] = audited_run
        require(set(audited_runs) == {Path(run["output"]).resolve(strict=True) for run in status["runs"]},
                f"independent timing audit run set differs: {label}")
        for run in status["runs"]:
            require(run["status"] == "passed" and run["exit_code"] == 0, "incomplete timing run")
            path = Path(run["output"]).resolve(strict=True)
            require(path not in run_bindings, f"timing record selected twice: {path}")
            package.guard(path, run["output_sha256"])
            require(audited_runs[path]["mode"] == run["mode"]
                    and audited_runs[path]["record_sha256"] == run["output_sha256"],
                    f"independent timing audit record identity differs: {path}")
            require(command_option(run["command"], "--output") == path,
                    "timing command output differs from its run record")
            run_bindings[path] = (run["mode"], command_option(run["command"], "--artifact-dir"))
    require(set(run_bindings) == {paths[0] for paths in timings.values()},
            "explicit timing records must exactly cover every selected status run")

    prepared_records = {}
    for label, (path, directory) in preparations.items():
        prepared = package.read_json(path)
        require(prepared["kind"] == "telemetry-preparation" and prepared["input_guards_passed"]
                and prepared["revision"] == timing_revision and not prepared["dirty"],
                f"incomplete or differently sourced preparation: {label}")
        require(prepared["imre_build_record"] == build, f"preparation used another compiler build: {label}")
        for key in ("binary", "llvm", "validation"):
            artifact = Path(prepared["validation_path" if key == "validation" else key]).resolve(strict=True)
            require(directory in artifact.parents, f"prepared artifact outside explicit directory: {artifact}")
            package.guard(artifact, prepared[key + "_sha256"])
        require(prepared["validation"] == package.read_json(prepared["validation_path"])
                and prepared["validation"]["input_guards_passed"], "preparation validation differs")
        paths, hashes = prepared["source_and_tool_paths"], prepared["source_and_tool_sha256"]
        require(set(paths) == set(hashes), "preparation source/tool guard set differs")
        for name, value in sorted(paths.items()):
            artifact = Path(value).absolute()
            package.guard(artifact, hashes[name])
            if root in artifact.parents:
                relative = artifact.relative_to(root).as_posix()
                require(relative in contents and digest(contents[relative][0]) == hashes[name],
                        f"timed source differs from Git snapshot: {relative}")
            elif name not in {"imre_build_record", "rust_build_record"}:
                package.add_file(f"inputs/{label}/{name.replace(':', '_')}/{artifact.name}", artifact,
                                 omit="external tool executable" if name in TOOLS else None)
        rust_record = package.read_json(paths["rust_build_record"])
        require(rust_record == prepared["rust_build_record"] and rust_record["input_guards_passed"],
                "Rust build provenance differs")
        mode = "thinlto" if prepared["thinlto"] else "normal"
        reference = index["references"]["telemetry-" + mode]
        package.guard(paths["rust_build_record"], reference["sha256"])
        require(prepared["binary_sha256"] == prepared["validation"]["source_and_binary_sha256"]["imre"]
                and hashes["rust"] == prepared["validation"]["source_and_binary_sha256"]["rust"],
                "preparation validation used another binary")
        value = package.guard(path)
        require(value not in prepared_records, "the same preparation was supplied more than once")
        prepared_records[value] = prepared
        package.add_file(f"preparation/{label}.json", path)
        package.add_tree(f"preparation/{label}", directory)
    modes = set()
    used_preparations = set()
    timing_metadata = {}
    for label, (path, directory) in timings.items():
        record = package.read_json(path)
        value = package.guard(path)
        require(value in audit_hashes, f"unaudited timing record: {label}")
        require(record["kind"] == "telemetry-benchmark" and record["input_guards_passed"]
                and record["completed_at_utc"] and record["revision"] == timing_revision
                and not record["dirty"], f"incomplete timing: {label}")
        prepared = prepared_records[record["preparation_record_sha256"]]
        used_preparations.add(record["preparation_record_sha256"])
        require(record["preparation"] == prepared
                and record["source_and_tool_sha256"] == prepared["source_and_tool_sha256"]
                and record["binary_sha256"] == prepared["binary_sha256"]
                and record["thinlto"] == prepared["thinlto"], "timing preparation differs")
        mode = "thinlto" if record["thinlto"] else "normal"
        require((mode, directory) == run_bindings[path],
                "timing runtime mode or artifact directory differs from its status")
        modes.add(mode)
        package.add_file(f"timing/records/{label}.json", path)
        package.add_tree(f"timing/artifacts/{label}", directory)
        timing_metadata[label] = {"mode": mode, "record_sha256": value,
                                  "preparation_record_sha256": record["preparation_record_sha256"]}
    require(modes == {"normal", "thinlto"}, "final timing must include normal and ThinLTO")
    require(used_preparations == set(prepared_records), "an explicit preparation was not used for final timing")
    package.add_file("helpers/package-evidence.py", Path(__file__).resolve())
    for label, (path,) in extras.items():
        if path.is_dir():
            package.add_tree("extras/" + label, path)
        else:
            package.add_file(f"extras/{label}/{path.name}", path)
    metadata = {
        "schema": 1, "build_revision": revision, "validation_revision": revision,
        "validation_tree": source["tree"], "timing_revision": timing_revision,
        "timing_tree": git("rev-parse", timing_revision + "^{tree}").decode().strip(),
        "post_validation_paths": changed, "post_validation_patch_sha256": digest(patch),
        "validation_index_sha256": package.guard(validation / "index.json"),
        "validation_build_sha256": package.guard(validation / "build.json"),
        "validation_audit_sha256": package.guard(args.validation_audit),
        "timing_audit_sha256": package.guard(args.timing_audit),
        "timing_status_sha256": {label: package.guard(paths[0]) for label, paths in statuses.items()},
        "timing_records": timing_metadata, "validation_counts": counts,
        "source_files": len(source["files"]), "packager_sha256": package.guard(__file__),
        "notes": [
            "Compiler, runtime, examples, validators, tests, and Rust reference sources are unchanged between full validation and timing.",
            "source/ is the fully validated Git snapshot; timing-source-overlay/ and the exact supplied patch retain the timing harness correction.",
            "No baseline or profile is required. Optional extras remain separate from final validation and timing evidence.",
            "Original manifests are retained unchanged; provenance/exclusions.json hashes omitted native code, archives, bytecode, and external tools.",
            "LLVM text, sources, scripts, logs, and raw input/output files are retained. Every selected file and directory membership is guarded before and after writing.",
        ],
    }
    package.write(prefix, metadata)


if __name__ == "__main__":
    main()
