"""Audit frozen validation records without rebuilding or running native workloads."""

import argparse
import ast
import base64
import hashlib
import json
import re
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--directory", type=Path, default=Path("/tmp/relar-iterator-validation-v1"))
parser.add_argument("--output", type=Path, default=Path("/tmp/relar-iterator-validation-audit.json"))
parser.add_argument("--revision", required=True, help="Exact frozen source revision expected for this run")
parser.add_argument("--index-sha256", help="Optional independently recorded index hash")
parser.add_argument("--rehash-native", action="store_true", help="Also rehash all retained native binaries and archives")
args = parser.parse_args()
DIRECTORY = args.directory.resolve(strict=True)
OUTPUT = args.output
REVISION = args.revision
INDEX_SHA256 = hashlib.sha256((DIRECTORY / "index.json").read_bytes()).hexdigest()
if args.index_sha256:
    assert INDEX_SHA256 == args.index_sha256


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(name):
    return json.loads((DIRECTORY / name).read_text())


index = read("index.json")
before, after = read("source-before.json"), read("source-after.json")
build, evidence = read("build.json"), read("evidence-sha256.json")
assert digest(DIRECTORY / "index.json") == INDEX_SHA256
assert index["status"] == "passed" and index["input_guards_passed"]
assert index["source_unchanged"] and before == after and before["status"] == ""
assert before["revision"] == index["revision"] == build["revision"] == REVISION
assert digest(DIRECTORY / "source-before.json") == index["source_manifest_sha256"]
assert build["source_manifest_sha256"] == index["source_manifest_sha256"]
assert digest(DIRECTORY / "build.json") == index["build_record"]["sha256"]
assert digest(DIRECTORY / "runner.py") == index["runner_sha256"]
assert build["runner_sha256"] == index["runner_sha256"]
assert digest(DIRECTORY / "evidence-sha256.json") == index["evidence_manifest_sha256"]
assert all(
    before["files"][name]["sha256"] == value
    for name, value in build["source_sha256"].items()
)

# Resolve immutable Git objects, not the current worktree/HEAD. A later harness
# commit must neither invalidate nor inherit claims about this validation run.
repository = Path(index["root"])
tree = subprocess.check_output(
    ["git", "rev-parse", REVISION + "^{tree}"], cwd=repository, text=True
).strip()
assert tree == before["tree"]
entries = subprocess.check_output(
    ["git", "ls-tree", "-r", "-z", REVISION], cwd=repository
).split(b"\0")
blobs = []
source_contents = {}
for entry in entries:
    if not entry:
        continue
    header, name = entry.split(b"\t", 1)
    mode, kind, identity = header.split()
    name = name.decode()
    if name.startswith("benchmarks/results/"):
        continue
    assert kind == b"blob"
    blobs.append((name, mode, identity))
assert {name for name, _, _ in blobs} == set(before["files"])
objects = subprocess.check_output(
    ["git", "cat-file", "--batch"],
    cwd=repository,
    input=b"".join(identity + b"\n" for _, _, identity in blobs),
)
offset = 0
source_bytes = 0
for name, mode, identity in blobs:
    end = objects.index(b"\n", offset)
    got, kind, size = objects[offset:end].split()
    assert got == identity and kind == b"blob"
    offset = end + 1
    data = objects[offset : offset + int(size)]
    offset += int(size) + 1
    source_bytes += len(data)
    source_contents[name] = data
    metadata = before["files"][name]
    if mode == b"120000":
        assert metadata == {"symlink": data.decode()}, name
    else:
        assert hashlib.sha256(data).hexdigest() == metadata["sha256"], name
        assert metadata["executable"] == (mode == b"100755"), name
assert offset == len(objects)

jobs = index["jobs"]
assert len(jobs) == len({job["name"] for job in jobs})
assert index["job_counts"] == {"passed": len(jobs), "failed": 0}
assert {"format", "clippy", "unit", "lto-linking", "build-ordinary", "build-thinlto", "build-asan"} <= {job["name"] for job in jobs}
for job in jobs:
    assert job["status"] == "passed" and job["exit_code"] == 0
    assert job["error"] is None
    for field in ("record", "stdout", "stderr"):
        path = Path(job[field])
        expected = job[field + "_sha256"]
        assert evidence[str(path.relative_to(DIRECTORY))] == expected
        assert digest(path) == expected
for name in ("build.json", "runner.py", "source-before.json", "source-after.json"):
    assert evidence[name] == digest(DIRECTORY / name)
for record in index["references"].values():
    assert digest(record["build_record"]) == record["sha256"]
labels = {
    "compiler": "compiler",
    "normal_runtime": "ordinary",
    "thinlto_runtime": "thinlto",
    "asan_runtime": "asan",
}
for name, label in labels.items():
    assert build["artifacts"][name] == index["artifacts"][label]
    assert build["sha256"][name] == index["artifacts"][label]["sha256"]
for name, job in build["build_jobs"].items():
    assert job == next(value for value in jobs if value["name"] == name)

# Independently derive compilation freshness from the raw Cargo streams, rather
# than accepting the runner's summary booleans as proof of actual compilation.
expected_fresh_packages = {
    "clippy": ["relar-compiler", "relar-runtime"],
    "unit": ["relar-compiler", "relar-runtime"],
    "build-ordinary": ["relar-compiler", "relar-runtime"],
    "build-thinlto": ["relar-runtime"],
    "build-asan": ["relar-runtime"],
}
assert set(index["fresh_compilation"]) == set(expected_fresh_packages)
assert build["fresh_compilation"] == index["fresh_compilation"]
fresh_compilation = {}
for name, packages in expected_fresh_packages.items():
    job = next(value for value in jobs if value["name"] == name)
    assert Path(job["cwd"]).resolve() == repository.resolve()
    command = job["command"]
    assert "+ohm" in command and "-v" in command
    assert "--message-format=json-render-diagnostics" in command
    if "--" in command:
        assert command.index("--message-format=json-render-diagnostics") < command.index("--")
    reference = index["fresh_compilation"][name]
    record_path = Path(reference["record"])
    inputs_path = Path(reference["source_timestamp_inputs"])
    assert digest(record_path) == reference["sha256"]
    assert digest(inputs_path) == reference["source_timestamp_inputs_sha256"]
    assert evidence[str(record_path.relative_to(DIRECTORY))] == reference["sha256"]
    assert evidence[str(inputs_path.relative_to(DIRECTORY))] == reference["source_timestamp_inputs_sha256"]
    record = json.loads(record_path.read_text())
    inputs = json.loads(inputs_path.read_text())
    assert record["status"] == "passed" and record["job"] == name
    assert record["revision"] == inputs["revision"] == REVISION
    assert record["packages"] == inputs["packages"] == reference["packages"] == packages
    assert record["source_timestamp_inputs"] == str(inputs_path)
    assert record["source_timestamp_inputs_sha256"] == digest(inputs_path)
    expected_sources = {
        path for path in before["files"]
        if path.endswith(".rs")
        and any(path.startswith(f"crates/{package}/src/") for package in packages)
    }
    assert len(inputs["sources"]) == len(expected_sources)
    assert {item["relative"] for item in inputs["sources"]} == expected_sources
    for item in inputs["sources"]:
        assert Path(item["path"]).resolve() == (repository / item["relative"]).resolve()
        assert item["sha256"] == before["files"][item["relative"]]["sha256"]
        assert isinstance(item["previous_mtime_ns"], int) and isinstance(item["mtime_ns"], int)
        # A filesystem can coalesce two very close timestamp updates. The raw
        # fresh=false artifacts and compiler invocations establish compilation.
        assert item["mtime_ns"] > 0 and item["previous_mtime_ns"] > 0
    stdout = Path(job["stdout"]).read_text()
    stderr = Path(job["stderr"]).read_text()
    assert record["cargo_stdout_sha256"] == digest(job["stdout"])
    assert record["cargo_stderr_sha256"] == digest(job["stderr"])
    messages = []
    for line in stdout.splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(message, dict):
            messages.append(message)
    completions = [message for message in messages if message.get("reason") == "build-finished"]
    assert len(completions) == 1 and completions[0]["success"] is True
    selected = []
    invocations = set()
    for package in packages:
        manifest = (repository / "crates" / package / "Cargo.toml").resolve()
        artifacts = [
            message for message in messages
            if message.get("reason") == "compiler-artifact"
            and Path(message["manifest_path"]).resolve() == manifest
        ]
        assert artifacts and all(item.get("fresh") is False for item in artifacts)
        for artifact in artifacts:
            target = artifact["target"]
            source = Path(target["src_path"]).resolve()
            assert manifest.parent in source.parents
            assert source.relative_to(repository.resolve()).as_posix() in expected_sources
            matching = []
            for line in stderr.splitlines():
                if "Running `" not in line or not line.endswith("`"):
                    continue
                arguments = shlex.split(line.split("Running `", 1)[1][:-1])
                if "--crate-name" not in arguments:
                    continue
                if arguments[arguments.index("--crate-name") + 1] != target["name"]:
                    continue
                if not any(Path(value).name in {"rustc", "clippy-driver"} for value in arguments):
                    continue
                if not any(
                    (repository / value).resolve() == source
                    for value in arguments
                    if value.endswith(".rs")
                ):
                    continue
                matching.append(line)
            assert matching, (name, target["name"], source)
            invocations.update(matching)
        selected.extend(artifacts)
    assert selected == record["compiler_artifacts"]
    assert sorted(invocations) == record["verbose_compiler_invocations"]
    produced = {Path(path).resolve() for item in selected for path in item["filenames"]}
    copied = {}
    for label, artifact in index["artifacts"].items():
        if artifact["build_job"] != name:
            continue
        assert Path(artifact["source"]).resolve() in produced
        assert digest(artifact["path"]) == artifact["sha256"]
        copied[label] = artifact["sha256"]
    fresh_compilation[name] = {
        "record_sha256": digest(record_path),
        "inputs_sha256": digest(inputs_path),
        "packages": packages,
        "unchanged_source_timestamps": len(expected_sources),
        "raw_cargo_artifacts_fresh_false": len(selected),
        "canonical_verbose_compiler_invocations": len(invocations),
        "copied_output_sha256_verified": copied,
    }

syntax = ast.parse((DIRECTORY / "runner.py").read_text())
node = next(
    statement.value
    for statement in syntax.body
    if isinstance(statement, ast.Assign)
    and any(isinstance(target, ast.Name) and target.id == "SUITES" for target in statement.targets)
)
assert isinstance(node, ast.Call) and node.func.attr == "split"
suites = ast.literal_eval(node.func.value).split()
levels = {"ordinary": ["0", "3"], "thinlto": ["3"], "asan": ["0", "1"]}
actual = set()
generic_checks = {}
special = {}
for job in jobs:
    if not job["name"].startswith("suite-"):
        continue
    _, mode, suite = job["name"].split("-", 2)
    actual.add((mode, suite))
    command = job["command"]
    assert command[command.index("--opt-levels") + 1 :] == levels[mode]
    assert command[command.index("--runtime") + 1] == index["artifacts"][mode]["path"]
    assert command[command.index("--compiler") + 1] == index["artifacts"]["compiler"]["path"]
    assert ("--sanitize" in command) == (mode == "asan")
    assert ("--lto-linker" in command) == (mode == "thinlto")
    if mode == "thinlto":
        assert command[command.index("--target") + 1] == index["target"]
        assert command[command.index("--lto-linker") + 1] == index["tools"]["lto-linker"]["path"]
    stdout = Path(job["stdout"]).read_text()
    matched = re.search(r"^Passed (\d+) .*checks", stdout, re.M) or re.search(
        r"^(\d+) import checks passed$", stdout, re.M
    )
    if matched:
        generic_checks[mode] = generic_checks.get(mode, 0) + int(matched[1])
    else:
        special[job["name"]] = stdout.splitlines()
        if suite == "luhn":
            assert special[job["name"]] == [
                f"O{level}: relar: 15 upstream calls, 1144 differential cases"
                for level in levels[mode]
            ]
        else:
            assert suite == "base45"
            assert special[job["name"]] == [
                f"O{level}: Passed 323 upstream native calls, 289 differential cases, and 2 compile-time type rejections"
                for level in levels[mode]
            ]
assert actual == {(mode, suite) for mode in levels for suite in suites}
assert len(suites) == 28 and len(actual) == 84
# Verify the enlarged iterable suite is discovered by the immutable shared runner.
iterable_source = ast.parse(source_contents["tests/iterables.py"])
iterable_assignments = {
    target.id: node.value
    for node in iterable_source.body if isinstance(node, ast.Assign)
    for target in node.targets if isinstance(target, ast.Name)
}
iterable_rejections = ast.literal_eval(iterable_assignments["REJECTED"])
iterable_errors = ast.literal_eval(iterable_assignments["ERRORS"])
iterable_fixtures = sorted(
    name for name in before["files"]
    if name.startswith("tests/fixtures/iterables/") and name.endswith(".py")
)
required_fixtures = {
    "bulk_mapping.py", "comprehension_sum.py", "comprehension_sum_scope.py",
    "divmod_sum.py", "list_bounds.py", "list_specialization.py", "list_sum.py",
    "proven_reads.py", "reduction_bounds.py", "reverse_slice_sum.py", "slice_sum.py",
}
assert required_fixtures <= {Path(name).name for name in iterable_fixtures}
iterable_checks = {}
for mode, optimizations in levels.items():
    expected = (len(iterable_fixtures) + len(iterable_errors)) * len(optimizations) + len(iterable_rejections)
    job = next(job for job in jobs if job["name"] == f"suite-{mode}-iterables")
    matched = re.fullmatch(
        r"Passed (\d+) iterable consumer checks \(31 rejections; optimization levels \[.*\]; ASan=(True|False)\)\n",
        Path(job["stdout"]).read_text(),
    )
    assert matched and int(matched[1]) == expected
    assert (matched[2] == "True") == (mode == "asan")
    iterable_checks[mode] = expected
assert len(iterable_rejections) == 31 and len(iterable_errors) == 5
workflow = source_contents[".github/workflows/ci.yml"].decode()
assert "tests/iterables.py" in workflow
assert all(suite in workflow for suite in suites)
unit = (DIRECTORY / "jobs/unit/stdout").read_text()
unit_counts = [
    int(value)
    for value in re.findall(r"test result: ok\. (\d+) passed; 0 failed;", unit)
]
nonzero_units = [value for value in unit_counts if value]
assert len(nonzero_units) == 2
unit_executables = {}
for line in unit.splitlines():
    try:
        message = json.loads(line)
    except json.JSONDecodeError:
        continue
    if not isinstance(message, dict) or message.get("reason") != "compiler-artifact":
        continue
    if not message["profile"]["test"] or not message["executable"]:
        continue
    assert Path(message["manifest_path"]).resolve() in {
        (repository / "crates/relar-compiler/Cargo.toml").resolve(),
        (repository / "crates/relar-runtime/Cargo.toml").resolve(),
    }
    unit_executables[Path(message["executable"]).resolve()] = message["target"]["name"]
assert set(unit_executables.values()) == {"relar_compiler", "relar", "relar_runtime"}
unit_order = []
for line in (DIRECTORY / "jobs/unit/stderr").read_text().splitlines():
    if "Running `" not in line or not line.endswith("`"):
        continue
    command = shlex.split(line.split("Running `", 1)[1][:-1])
    target = unit_executables.get(Path(command[0]).resolve())
    if target is not None:
        assert len(command) == 1
        unit_order.append(target)
assert unit_order == ["relar_compiler", "relar", "relar_runtime"]
assert unit_counts[:3] == [nonzero_units[0], 0, nonzero_units[1]]
assert all(value == 0 for value in unit_counts[3:])
assert sum(unit_counts) == index["unit_tests_passed"]
rust_units = {"compiler": nonzero_units[0], "runtime": nonzero_units[1], "total": sum(unit_counts)}
assert index["environment"]["ASAN_OPTIONS"] == "detect_leaks=1:halt_on_error=1"

applications = sorted(
    job["name"].removeprefix("application-oracle-")
    for job in jobs
    if job["name"].startswith("application-oracle-")
)
assert applications == ["batch", "dependency", "incremental", "inventory", "manifest", "route", "telemetry"]
assert any(job["name"] == "application-boundaries-dependency" for job in jobs)
assert len(index["references"]) == 11
reference_counts = {}
for name in ("luhn-normal", "luhn-thinlto", "base45-normal", "base45-thinlto"):
    result = read(f"references/{name}/validation.json")["rust"]
    reference_counts[name] = {
        "differential_cases": len(result["differential_cases"]),
        "exact_message_cases": result["exact_message_cases"],
    }
    if name.startswith("luhn"):
        assert result["native_adapter_calls"] == 15
        assert len(result["differential_cases"]) == result["exact_message_cases"] == 1144
        reference_counts[name]["upstream_adapter_calls"] = 15
    else:
        assert len(result["differential_cases"]) == 295
        assert result["exact_message_cases"] == 291
        assert len(result["diagnostic_boundaries"]) == 4
        reference_counts[name]["documented_diagnostic_boundaries"] = 4


# Exact command coverage, not merely a count of successful rows.
runner_assignments = {
    target.id: node.value
    for node in syntax.body if isinstance(node, ast.Assign)
    for target in node.targets if isinstance(target, ast.Name)
}
application_specs = ast.literal_eval(runner_assignments['APPLICATIONS'])
reference_specs = ast.literal_eval(runner_assignments['REFERENCE_SPECS'])
expected_names = set('''select-cargo select-rustc select-rustfmt select-cargo-clippy
select-clippy-driver rustc-version rust-sysroot cargo-version python-version
clang-version linker-version format clippy unit build-ordinary build-thinlto
build-asan compiler-version thinlto-members thinlto-member asan-symbols lto-linking
application-boundaries-dependency'''.split())
expected_names |= {f'suite-{mode}-{suite}' for mode in levels for suite in suites}
expected_names |= {f'application-{action}-{name}' for action in ('build', 'oracle') for name in application_specs}
expected_names |= {f'reference-build-{name}' for name, _, _ in reference_specs}
reference_oracles = ['base45-normal', 'base45-thinlto', 'luhn-normal', 'luhn-thinlto', 'telemetry-normal', 'telemetry-thinlto']
expected_names |= {f'reference-oracle-{name}' for name in reference_oracles}
assert len(expected_names) == 138
assert {job['name'] for job in jobs} == expected_names
assert {path.name for path in (DIRECTORY / 'jobs').iterdir()} == expected_names
assert set(evidence) == {
    str(path.relative_to(DIRECTORY)) for path in DIRECTORY.rglob('*')
    if path.is_file() and path.name not in {'index.json', 'evidence-sha256.json'}
}
for job in jobs:
    record = json.loads(Path(job['record']).read_text())
    assert record == {key: value for key, value in job.items() if key not in {'record', 'record_sha256'}}
    assert Path(job['record']).parent == DIRECTORY / 'jobs' / job['name']
    assert set(path.name for path in Path(job['record']).parent.iterdir()) == {'command.json', 'stdout', 'stderr'}
    stderr = Path(job['stderr']).read_text()
    assert not re.search(r'(^|\n)(?:==\d+==)?(?:ERROR: (?:AddressSanitizer|LeakSanitizer)|AddressSanitizer:DEADLYSIGNAL|SUMMARY: (?:AddressSanitizer|LeakSanitizer)|thread .+ panicked at|Traceback \(most recent call last\):)', stderr), job['name']
assert (DIRECTORY / 'jobs/thinlto-member/stdout').read_bytes()[:4] in (b'BC\xc0\xde', b'\xde\xc0\x17\x0b')
assert '__asan_init' in (DIRECTORY / 'jobs/asan-symbols/stdout').read_text()
assert (DIRECTORY / 'jobs/lto-linking/stdout').read_text() == 'Passed 10 ThinLTO CLI checks\n'
assert (DIRECTORY / 'jobs/python-version/stdout').read_text().strip() == 'Python 3.14.5'
assert 'cached_results_reuse_only_exclusive_records_and_release_their_fields ... ok' in unit
for tool in index['tools'].values():
    assert digest(tool['path']) == tool['sha256']

pipeline_tree = ast.parse(source_contents['tests/iterator_pipelines.py'])
pipeline_assignments = {
    target.id: node.value for node in pipeline_tree.body if isinstance(node, ast.Assign)
    for target in node.targets if isinstance(target, ast.Name)
}
pipeline_rejections = ast.literal_eval(pipeline_assignments['REJECTED'])
pipeline_errors = ast.literal_eval(pipeline_assignments['ERRORS'])
pipeline_fixtures = sorted(name for name in before['files'] if name.startswith('tests/fixtures/iterator_pipelines/') and name.endswith('.py'))
assert len(pipeline_fixtures) == 9 and len(pipeline_errors) == 5 and len(pipeline_rejections) == 47
iterator_checks = {'fixtures': pipeline_fixtures, 'positive_fixtures': 9, 'expected_error_cases': 5, 'compile_rejections': 47, 'checks_by_mode': {}}
for mode, optimizations in levels.items():
    expected = (len(pipeline_fixtures) + len(pipeline_errors)) * len(optimizations) + len(pipeline_rejections)
    stdout = (DIRECTORY / f'jobs/suite-{mode}-iterator_pipelines/stdout').read_text()
    assert stdout == f'Passed {expected} iterator pipeline checks (47 rejections; optimization levels {optimizations}; ASan={mode == "asan"})\n'
    iterator_checks['checks_by_mode'][mode] = expected

# Bind reference build source text, builder, binaries and selected tools. Only
# telemetry builders preserve raw fresh=false records, so distinguish their proof.
reference_build_details = {}
for name, package, flags in reference_specs:
    reference = index['references'][name]
    record = json.loads(Path(reference['build_record']).read_text())
    prefix = f'benchmarks/reference/{package}/'
    for relative, expected in record['sources'].items():
        assert before['files'][prefix + relative]['sha256'] == expected
        assert record['source_contents'][relative].encode() == source_contents[prefix + relative]
    if 'build_script_sha256' in record:
        assert record['build_script_sha256'] == before['files'][prefix + 'build.py']['sha256']
        assert record['build_script'].encode() == source_contents[prefix + 'build.py']
    for tool, expected in record.get('tool_sha256', {}).items():
        assert expected == index['tools']['ohm-' + tool]['sha256']
    binaries = record.get('binaries', {'reference': {'name': 'luhn-reference', 'sha256': record.get('binary_sha256'), 'bytes': record.get('binary_bytes')}})
    assert set(binaries) == set(reference['binaries'])
    for label, value in binaries.items():
        path = Path(reference['binaries'][label])
        assert path.name == value['name'] and digest(path) == value['sha256']
        if value.get('bytes') is not None:
            assert path.stat().st_size == value['bytes']
    fresh = False
    if name.startswith('telemetry-'):
        messages = [json.loads(line) for line in record['build_stdout'].splitlines()]
        manifest = str(repository / prefix / 'Cargo.toml')
        selected = [item for item in messages if item.get('reason') == 'compiler-artifact' and item.get('manifest_path') == manifest]
        assert selected == [record['native_artifact']] and selected[0]['fresh'] is False
        assert [item for item in messages if item.get('reason') == 'build-finished'] == [{'reason': 'build-finished', 'success': True}]
        assert '--crate-name telemetry_reference' in record['build_stderr']
        assert record['input_guards_passed']
        fresh = True
    reference_build_details[name] = {'source_files': len(record['sources']), 'binaries': len(binaries), 'raw_fresh_compilation_proved': fresh, 'build_record_sha256': reference['sha256']}

# Recheck retained oracle observations against their independent expected values.
# This performs data/hash comparisons only; it executes no example or oracle code.
def bytes_identity(value):
    data = base64.b64decode(value['base64'], validate=True)
    assert hashlib.sha256(data).hexdigest() == value['sha256']
    assert len(data) == value['bytes']
    return {'sha256': value['sha256'], 'bytes': value['bytes']}


def verify_result(actual, expected, expected_files=None):
    assert actual['returncode'] == expected.get('returncode', 0)
    stdout = expected['stdout'].encode()
    if 'stdout' in actual:
        assert actual['stdout'].encode() == stdout
    else:
        assert actual['stdout_sha256'] == hashlib.sha256(stdout).hexdigest()
        assert actual['stdout_bytes'] == len(stdout)
    if expected.get('error_category'):
        final = actual['stderr'].rstrip().splitlines()[-1]
        assert final.split(':', 1)[0] == expected['error_category'], final
        if expected.get('usage_message'):
            assert final == expected['error_category'] + ': ' + expected['usage_message']
    else:
        assert actual['stderr'] == ''
    if expected_files is not None:
        assert actual['files'] == {name: bytes_identity(value) for name, value in expected_files.items()}
        assert actual['directories'] == expected.get('directories', [])


application_details = {}
for name, (source, validator) in application_specs.items():
    job = next(job for job in jobs if job['name'] == f'application-build-{name}')
    command = job['command']
    assert command[0] == index['artifacts']['compiler']['path']
    assert command[2] == str(repository / 'examples' / source)
    assert command[command.index('--runtime') + 1] == index['artifacts']['ordinary']['path']
    assert command[command.index('--opt-level') + 1] == '3'
    path = DIRECTORY / 'applications' / name / 'validation.json'
    data = json.loads(path.read_text())
    summary = {'validation_sha256': digest(path)}
    if name == 'route':
        assert data['input_cases'] == 22 and data['routes'] == 64
        summary.update(cases=22, routes=64, detail='aggregate only')
    elif name == 'dependency':
        assert data['inputs'] == 135 and data['native_checked']
        assert sum(data[key] for key in ('valid_plans', 'cycles', 'missing_dependencies', 'negative_durations')) == 135
        summary.update(cases=135, detail='aggregate only')
    elif name in ('batch', 'manifest', 'inventory'):
        rows = data.get('records', data.get('checks'))
        assert len(rows) == data['cases'] == {'batch': 194, 'manifest': 196, 'inventory': 204}[name]
        for row in rows:
            expected = row['expected']
            results = row.get('engines', row.get('results'))
            assert set(results) == {'cpython', 'relar', 'rust_bigint'}
            expected_files = row.get('expected_files', expected.get('files'))
            for result in results.values():
                verify_result(result, expected, expected_files)
        summary.update(cases=len(rows), engines=['cpython', 'relar', 'rust_bigint'])
    elif name == 'incremental':
        assert data['oracle_cases'] == len(data['checks']) == 155
        assert data['i64_overflow_rejections_checked'] == len(data['i64_excluded_cases']) == 17
        for row in data['checks']:
            assert set(row['results']) == {'cpython', 'relar', 'rust_bigint', 'rust_i64'}
            for engine, result in row['results'].items():
                if engine == 'rust_i64' and row['i64_exclusion']:
                    assert result['returncode'] == 1 and result['stdout_bytes'] == 0
                    assert result['stderr'].startswith('OverflowError:')
                else:
                    verify_result(result, {'stdout': row['expected_stdout']})
        assert len(data['parser_checks']) == data['parser_cases'] == 17
        for row in data['parser_checks']:
            for result in row['results'].values():
                verify_result(result, {'stdout': row['expected_stdout'], 'returncode': row['expected_returncode'], 'error_category': row['expected_error_category']})
        summary.update(cases=155, parser_cases=17, i64_exclusions_with_explicit_overflow=17)
    application_details[name] = summary

manifest_device = read('applications/manifest/validation.json')['linux_device_checks']
assert manifest_device['cases'] == len(manifest_device['checks']) == 1
assert manifest_device['passed_by_engine'] == {'cpython': 1, 'relar': 1, 'rust_bigint': 1}
for row in manifest_device['checks']:
    for result in row['results'].values():
        verify_result(result, row['expected'], row['expected']['files'])
application_details['manifest']['output_device_cases'] = 1
inventory_device = read('applications/inventory/validation.json')['device_check']
assert inventory_device['case'] == 'terminal-report-device-error'
assert set(inventory_device['engines']) == {'cpython', 'relar', 'rust_bigint'}
for result in inventory_device['engines'].values():
    verify_result(result, {'stdout': '', 'returncode': 1, 'error_category': 'OSError'})
application_details['inventory']['output_device_cases'] = 1

boundaries = read('applications/dependency/boundaries.json')
assert len(boundaries['checks']) == boundaries['cases'] == 10
for row in boundaries['checks']:
    assert set(row['results']) == {'cpython', 'relar', 'rust_bigint', 'rust_i64'}
    for engine, result in row['results'].items():
        if engine == 'rust_i64' and row['i64_rejects']:
            assert result['returncode'] == 1 and result['stdout_bytes'] == 0 and result['stderr'].startswith('OverflowError:')
        else:
            verify_result(result, {'stdout': row['expected_stdout']})
application_details['dependency']['boundary_cases'] = 10

for prefix, engines in [('applications/telemetry', {'cpython', 'relar', 'rust'}), ('references/telemetry-normal', {'cpython', 'rust'}), ('references/telemetry-thinlto', {'cpython', 'rust'})]:
    data = read(prefix + '/validation.json')
    assert data['input_guards_passed'] and len(data['records']) == data['cases'] == 258
    assert set(data['engines']) == engines
    for row in data['records']:
        assert set(row['engines']) == engines
        for result in row['engines'].values():
            verify_result(result, {'stdout': row['expected_stdout'], 'directories': row['case']['directories']}, row['expected_files'])
    assert set(data['output_device']) == engines
    for result in data['output_device'].values():
        verify_result(result, {'stdout': 'ERROR\nOSError\nreport: cannot write\n'})
    identities = data['source_and_binary_sha256']
    for key, source in {'validator': 'benchmarks/telemetry_validate.py', 'filesystem_validator': 'benchmarks/manifest_validate.py', 'batch_validator': 'benchmarks/batch_validate.py', 'incremental_validator': 'benchmarks/incremental_validate.py'}.items():
        assert identities[key] == before['files'][source]['sha256']
    assert identities['python'] == index['tools']['python']['sha256']
    for key, expected in identities.items():
        if key.startswith('example:'):
            assert expected == before['files']['examples/telemetry_comparison/' + key.split(':')[1]]['sha256']
    reference_name = 'telemetry-normal' if prefix.startswith('applications/') else prefix.split('/')[1]
    assert identities['rust'] == digest(index['references'][reference_name]['binaries']['reference'])
    if 'relar' in engines:
        assert identities['relar'] == digest(DIRECTORY / 'applications/telemetry/telemetry')
        application_details['telemetry'].update(cases=258, output_device_cases=1, engines=sorted(engines))
    else:
        reference_counts[reference_name] = {'cases': 258, 'output_device_cases': 1, 'engines': sorted(engines)}

for codec in ('base45', 'luhn'):
    first, second = [read(f'references/{codec}-{mode}/validation.json') for mode in ('normal', 'thinlto')]
    assert first['rust']['differential_cases'] == second['rust']['differential_cases']
    for mode, data in [('normal', first), ('thinlto', second)]:
        assert data['rust']['binary_sha256'] == digest(index['references'][f'{codec}-{mode}']['binaries']['reference'])
        assert data['python'].startswith('3.14.5 ')
        if codec == 'luhn':
            assert data['python_executable_sha256'] == index['tools']['python']['sha256']
            assert data['unicode_version'] == '16.0.0'
        for relative, metadata in data['upstream']['files'].items():
            path = f'examples/vendor/{codec}/{relative}'
            matches = [name for name in before['files'] if name.endswith('/' + relative) and before['files'][name].get('sha256') == metadata['sha256']]
            assert matches, (codec, relative)


if args.rehash_native:
    for name, expected in evidence.items():
        assert digest(DIRECTORY / name) == expected, name
else:
    # Rehash every text/JSON/log evidence member; native artifact identities remain
    # covered by the runner's recorded before/after guards.
    for name, expected in evidence.items():
        path = DIRECTORY / name
        if path.suffix in {".json", ".py", ".ll"} or path.name in {"stdout", "stderr"}:
            assert digest(path) == expected, name

report = {
    "schema": 1,
    "status": "passed",
    "audited_at_utc": datetime.now(timezone.utc).isoformat(),
    "revision": REVISION,
    "validation_revision": REVISION,
    "validation_tree": tree,
    "validation_index": str(DIRECTORY / "index.json"),
    "validation_index_sha256": INDEX_SHA256,
    "audit_script_sha256": digest(__file__),
    "fresh_compilation": fresh_compilation,
    "counts": {
        "recorded_jobs": len(jobs),
        "passed_jobs": len(jobs),
        "failed_jobs": 0,
        "rust_units": rust_units,
        "language_suites": 28,
        "suite_invocations": 84,
        "optimization_configurations": levels,
        "generic_suite_count": 26,
        "generic_checks_by_mode": generic_checks,
        "generic_checks_total": sum(generic_checks.values()),
        "iterable_fixtures": iterable_fixtures,
        "iterable_fixture_count": len(iterable_fixtures),
        "iterable_checks_by_mode": iterable_checks,
        "iterable_expected_error_cases": len(iterable_errors),
        "iterable_compile_rejections": len(iterable_rejections),
        "luhn_native": {
            "configurations": 5,
            "upstream_calls_per_configuration": 15,
            "differential_cases_per_configuration": 1144,
            "upstream_calls_total": 75,
            "differential_cases_total": 5720,
            "upstream_tests": 10,
            "upstream_doctest_examples": 5,
        },
        "base45_native": {
            "configurations": 5,
            "upstream_calls_per_configuration": 323,
            "differential_cases_per_configuration": 289,
            "compile_rejections_per_configuration": 2,
        },
        "application_oracles": applications,
        "application_details": application_details,
        "iterator_pipelines": iterator_checks,
        "reference_build_details": reference_build_details,
        "dependency_boundary_checks": True,
        "reference_builds": len(index["references"]),
        "reference_oracles": reference_counts,
    },
    "guard_checks": {
        "before_after_source_manifests_identical": True,
        "clean_validation_source": True,
        "source_files_verified_against_original_git_commit": len(before["files"]),
        "source_bytes_verified": source_bytes,
        "build_source_hashes_match_source_manifest": len(build["source_sha256"]),
        "command_record_and_output_hashes_verified": len(jobs) * 3,
        "runner_build_source_manifest_hashes_verified": True,
        "reference_build_record_hashes_verified": len(index["references"]),
        "complete_expected_job_directory_set_verified": True,
        "complete_evidence_file_set_verified": True,
        "unexpected_sanitizer_panic_traceback_markers": 0,
        "oracle_outputs_rechecked_against_retained_expected_values": True,
        "artifact_metadata_matches_build_record": True,
        "fresh_cargo_json_inputs_and_compiler_invocations_independently_reparsed": True,
        "unit_test_execution_order_bound_to_raw_cargo_artifact_executables": unit_order,
        "frozen_compiler_and_three_runtime_copies_independently_rehashed": True,
        "recorded_final_tool_artifact_guards_passed": index["input_guards_passed"],
        "independent_binary_archive_rehash_performed": args.rehash_native,
        "evidence_manifest_entries": len(evidence),
        "evidence_manifest_sha256": index["evidence_manifest_sha256"],
        "build_record_sha256": index["build_record"]["sha256"],
        "source_manifest_sha256": index["source_manifest_sha256"],
    },
    "limits": [
        f"This audits validation at {REVISION}; later commits do not inherit a claim that this full matrix ran at their revision.",
        f"{len(jobs)} counts orchestration commands, including tool discovery/builds; it is not a count of independent test cases.",
        f"The {sum(generic_checks.values()):,} generic suite checks exclude the separately reported Base45/Luhn corpus checks and application/reference oracles.",
        "ASan/LSan covers generated programs and the runtime at O0/O1 with leak detection enabled; the compiler and Rust references are not sanitizer-instrumented.",
        "Luhn comparison covers all four str APIs using CPython 3.14.5 / Unicode 16; no Luhn diagnostic exclusions.",
        "Native Base45/Luhn per-case JSON lived in temporary suite directories because --output was omitted; retained summaries, exit status, and guarded harness source establish completion. Detailed Rust-reference JSON is retained.",
        "Ruff checks, if any, are identified only by their retained jobs; earlier exploratory checks are not counted in this matrix.",
        "All native artifacts were independently rehashed by this audit." if args.rehash_native else "The frozen compiler and three runtime archives were independently rehashed; other generated/reference binaries retain the runner's recorded final identity guards.",
        "Historical benchmarks/results paths are excluded from per-file source hashes; the clean committed Git tree identifies those paths.",
        "Compiler/runtime and telemetry Rust-reference compilation have fresh=false Cargo evidence. Other reference builders reran against frozen source and retained source/binary hashes, but may reuse Cargo artifacts; this audit does not claim fresh native compilation for them.",
        "Route/dependency application validators retain aggregate summaries only; detailed per-case observations are retained for the other five applications and dependency boundaries.",
        "Native Base45/Luhn oracle records retain validated outputs and protocol hashes; this audit compares normal/ThinLTO records and provenance, without rerunning their algorithms.",
        "No builds, tests, profiling, or benchmark workloads were executed by this independent audit.",
    ],
}
assert digest(DIRECTORY / "index.json") == INDEX_SHA256
OUTPUT.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "audit": str(OUTPUT), "sha256": digest(OUTPUT)}))
