"""Render the telemetry report from final measured records, without running engines."""

import json
from pathlib import Path

PREFIX = "2026-10-20-iterator-pipelines"
RECORDS = {
    (family, mode): Path(f"/tmp/relar-telemetry-{family}-v1-{mode}.json")
    for family in ("full", "early")
    for mode in ("normal", "thinlto")
}


def load(path):
    return json.loads(Path(path).read_text())


def span(values, places=2):
    return f"{min(values):.{places}f}–{max(values):.{places}f}"


def milliseconds(summary):
    return f"{summary['median_seconds'] * 1000:.3f}"


def main():
    records = {key: load(path) for key, path in RECORDS.items()}
    assert all(
        record["input_guards_passed"] and not record["dirty"]
        for record in records.values()
    )
    heads = {record["revision"] for record in records.values()}
    assert len(heads) == 1
    validation = load("/tmp/relar-iterator-validation-v1/index.json")
    audit = load("/tmp/relar-iterator-validation-audit.json")
    assert validation["status"] == audit["status"] == "passed"
    large = {
        family: [
            workload
            for workload in records[(family, "thinlto")]["workloads"]
            if int(workload["label"].rsplit("-", 1)[1]) == 4096
        ]
        for family in ("full", "early")
    }
    profile = load("/tmp/relar-telemetry-profile/summary.json")
    assert profile["status"] == "passed" and profile["complete"]
    profile_rows = []
    for engine in ("relar", "rust"):
        cpu = next(
            p["metrics"]
            for p in profile["profiles"]
            if p["engine"] == engine and p["tool"] == "callgrind"
        )
        heap = next(
            p["metrics"]
            for p in profile["profiles"]
            if p["engine"] == engine and p["tool"] == "dhat" and p["repetitions"] == 128
        )
        growth = profile["allocation_growth"][engine]["allocated_bytes"][
            "per_additional_query"
        ]
        profile_rows.append(
            f"| {engine.title()} | {cpu['instructions']:,} | {heap['allocated_bytes']:,} | {heap['allocated_blocks']:,} | {growth:g} |"
        )
    lines = [
        "# Generator expressions and telemetry comparison",
        "",
        (
            "Relar now compiles immediately consumed generator expressions, `zip` "
            "(including `strict=True`), `reversed`, `any`, and `all`. The "
            "[telemetry comparator](../../examples/telemetry_comparison/README.md) "
            "runs the same typed Python package on CPython and Relar, with an "
            "independent Rust implementation of the same file protocol and queries."
        ),
        "",
        (
            f"At 4,096 samples with ThinLTO, the full-scan group runs "
            f"**{span([w['cpython_over_relar'] for w in large['full']])}× faster than CPython** "
            f"and takes **{span([w['relar_over_rust'] for w in large['full']])}× Rust's time**. "
            f"Early-exit queries run "
            f"**{span([w['cpython_over_relar'] for w in large['early']])}× faster than CPython** "
            f"and take **{span([w['relar_over_rust'] for w in large['early']])}× Rust's time**. "
            "These are complete-program measurements, not isolated iterator instruction costs."
        ),
        "",
        (
            "The [implementation PR](https://github.com/viarius-experiments/relar/pull/57) "
            "continues the existing GitHub stack. This milestone adds functionality "
            "and measures its cost; the remaining Rust gap is visible in the results."
        ),
        "",
        "## Supported behavior",
        "",
        (
            "Generator expressions can compose nested clauses and filters with "
            "the supported builtin iterators when consumed directly by loops, eager "
            "comprehensions, `list`, exact-integer `sum`, `any`, or `all`. Construction "
            "and iterator acquisition happen at the required time; pulls, filters, "
            "exceptions, live captures, and strict-length checks remain lazy. "
            "`any` and `all` stop at the first decisive value. Reverse list iteration "
            "observes mutation, and strings reverse by Unicode code point."
        ),
        "",
        (
            "The compiler lowers these pipelines to typed local state. It can remove "
            "private destructured zip/enumerate tuples without allocating a generator "
            "closure. Tuples that transitively own files preserve CPython's observable "
            "iterator-cache ownership and cleanup behavior. General generator "
            "functions, escaping iterator values, and user-defined iterator protocols "
            "remain outside the supported subset; see the "
            "[subset reference](../../docs/subset.md)."
        ),
        "",
        "## Workload and comparison",
        "",
        (
            "The program reads reference and observed timestamp/value recordings, "
            "validates complete timestamp alignment using strict zip, then answers "
            "repeated queries. `report-mixed` makes separate signed, absolute, and "
            "squared-error reductions, two threshold predicates, and a reverse "
            "search. Quiet predicates and searches scan the complete input. "
            "Early/recent cases stop after one inspected pair. Complete alignment "
            "is validated once before queries, so an early result cannot hide a "
            "missing sample."
        ),
        "",
        (
            "All engines retain arbitrary-precision integer results and the same "
            "errors. The independent Rust reference uses contiguous native records "
            "and checked `i128` reductions when values fit, restarting a pure query "
            "with `BigInt` on overflow. Relar uses the typed Python object's storage "
            "and generated loops. Rust applies `black_box` around every repeated "
            "query and result; all engines render the final complete result once "
            "and return a repetition checksum."
        ),
        "",
        (
            "Full-scan processes target **8,388,608 source-level inspected pairs**; "
            "early-exit processes target **2,097,152**. Repetition counts round down "
            "to whole queries. Input sizes are 16, 256, and 4,096 records per file. "
            "The raw records retain each exact input, pair count, repetition count, "
            "output, and filesystem result."
        ),
        "",
        (
            "Each condition has eight warmup rounds and twelve measured rounds. "
            "All six engine permutations occur twice in measured rounds, balancing "
            "positions and within-round directed predecessors. Cross-round "
            "transitions and the eight warmup rounds are not fully balanced."
        ),
        "",
        "## Wall-time results",
        "",
        (
            "Values are median milliseconds. **CPython / Relar** is a speedup "
            "(higher is better); **Relar / Rust** is a time ratio (lower is better). "
            "Raw samples and inclusive quartiles are retained in the linked records."
        ),
        "",
    ]
    for mode, title in (("normal", "Ordinary linking"), ("thinlto", "ThinLTO")):
        lines += [
            f"### {title}",
            "",
            "| Workload / records | Relar ms | Rust ms | CPython ms | CPython / Relar | Relar / Rust |",
            "|---|---:|---:|---:|---:|---:|",
        ]
        for family in ("full", "early"):
            for item in records[(family, mode)]["workloads"]:
                summary = item["summary"]
                lines.append(
                    f"| `{item['scenario']}` / {int(item['label'].rsplit('-', 1)[1]):,} | "
                    f"{milliseconds(summary['relar'])} | {milliseconds(summary['rust'])} | "
                    f"{milliseconds(summary['cpython'])} | "
                    f"{item['cpython_over_relar']:.3f}× | {item['relar_over_rust']:.3f}× |"
                )
        lines.append("")
    lines += [
        (
            "Ordinary and ThinLTO families have separate interleaved baselines. "
            "Native engines use matching linking modes; ThinLTO uses matched LLVM "
            "import and inline budgets of 1,000. Differences between families "
            "do not isolate the effect of linking alone."
        ),
        "",
        "### Startup controls",
        "",
        "| Batch / linking | Relar ms | Rust ms | CPython ms |",
        "|---|---:|---:|---:|",
    ]
    for (family, mode), record in records.items():
        summary = record["startup_control"]["summary"]
        lines.append(
            f"| {family} / {mode} | {milliseconds(summary['relar'])} | "
            f"{milliseconds(summary['rust'])} | {milliseconds(summary['cpython'])} |"
        )
    fractions = {
        engine: max(
            item["startup_control_fraction"][engine]
            for record in records.values()
            for item in record["workloads"]
        )
        for engine in ("relar", "rust", "cpython")
    }
    conditions = [
        item
        for record in records.values()
        for item in [record["startup_control"], *record["workloads"]]
    ]
    gates = sum(len(item["gates"]) for item in conditions)
    samples = sum(3 * len(item["samples"]) for item in conditions)
    warmups = sum(3 * len(item["warmups"]) for item in conditions)
    lines += [
        "",
        (
            "The empty-recording, one-query controls are reported without subtraction. "
            f"The largest control/workload median fractions are "
            f"{fractions['relar']:.2%} for Relar, {fractions['rust']:.2%} for Rust, and "
            f"{fractions['cpython']:.2%} for CPython. The pilot used smaller batches; "
            "the final batch sizes were selected before final measurement to reduce "
            "startup's contribution."
        ),
        (
            "The empty control excludes nonempty parsing and alignment, so it is "
            "not an estimate of all fixed costs. Those operations remain included "
            "in every workload measurement. Rust startup remains material, so these ratios should not be presented as isolated steady-state throughput."
        ),
        "",
        "## CPU and allocation profile",
        "",
        "Profiles use the exact timed ThinLTO executables on `alert-quiet-4096`, with 128 queries (524,288 inspected pairs). Callgrind and DHAT run separately from wall-time measurements; a second DHAT run uses 256 queries. All six executions pass the complete output and filesystem oracle.",
        "",
        "| Engine | Guest instructions | Allocated bytes, 128 queries | Allocation blocks | Additional bytes / query, 128→256 |",
        "|---|---:|---:|---:|---:|",
        *profile_rows,
        "",
        "The generated alert query (`fn_7`) accounts for 46.86% of Relar self instructions; `relar_seq_get` accounts for another 23.43%, with 1,056,768 calls. Concrete class fields already use direct loads. The query still performs generic sequence access, bounds and exception checks, record ownership handoffs, and tagged-integer arithmetic around each pair. Borrowed sequence access and stronger integer proofs are candidates for later specialization; the emitted LLVM does not assign a measured cost to each individual check. Callgrind counts guest instructions, not CPU cycles or wall-time shares.",
        "",
        "Doubling queries adds 40 bytes and one allocation per extra Relar query, and no allocations for Rust. This two-point observation suggests that most allocation work is in loading and setup, while repeated per-pair operations dominate the query gap; it is not a proof of allocation behavior for other inputs. The Rust reference also spends substantial profile work parsing and loading. Both profiles include the complete process, so the instruction ratio is not an isolated query-loop ratio.",
        "",
        f"See the [profile summary]({PREFIX}-profile.json), [independent profile audit]({PREFIX}-profile-audit.json), and raw Callgrind/DHAT data in the evidence archive.",
        "",
        "## Validation and provenance",
        "",
        (
            f"The frozen compiler/runtime revision `{validation['revision']}` passed "
            f"**{validation['job_counts']['passed']} validation jobs** and "
            f"**{validation['unit_tests_passed']} Rust unit tests**. All 28 language "
            "suites ran with ordinary O0/O3, ThinLTO O3, and ASan/LSan O0/O1. "
            "The iterator suite passed 75, 61, and 75 checks respectively, including "
            "47 compile-time rejections per build mode. Seven application oracles "
            "and six reference oracles passed. The telemetry oracle compares "
            "258 cases plus output-device failure, including malformed input, "
            "overflow fallback, huge integers, timestamp/length errors, aliases, "
            "hard links, and complete filesystem effects."
        ),
        "",
        (
            f"Timing used clean revision `{next(iter(heads))}`. Its only changes "
            "after full validation fix target verification in the benchmark harness "
            "and explain that verification in the reference guide. Compiler, runtime, "
            "examples, validators, tests, and Rust reference source are unchanged. "
            "The exact patch is retained. Both exact timed binary pairs passed the "
            "full telemetry oracle again during preparation. A later metadata-only correction names input counts `records` so they cannot be overwritten by measured `samples` round lists. These original records are unchanged; their labels and retained inputs establish the input counts."
        ),
        "",
        (
            "Compiler, runtime, and telemetry reference builds have raw evidence "
            "of fresh compiler invocations. Other regression reference builds are "
            "source-bound invocations with preserved artifact hashes; some reused "
            "their build cache. The independent validation audit distinguishes them."
        ),
        "",
        (
            "An unchanged-Luhn control compares emitted LLVM from the previous and "
            "current compiler. Every byte is identical after removing only the two "
            "new, unused runtime declarations. This checks generated-code stability; "
            "it is not a new Luhn wall-time measurement."
        ),
        "",
        (
            "Measurements ran pinned to CPU 0, outside ptrace, with task-owned "
            "builds, tests, profiles, and large evidence audits stopped. The host is "
            "AMD EPYC-Milan; CPython 3.14.5 has PGO/LTO, the GIL enabled, and JIT "
            "disabled. Relar uses Clang 18 at O3; Rust uses Ohm 1.98.1-1, rustc "
            "1.98.1-dev, and LLVM 22.1.8. Shared-host activity and frequency remain "
            "uncontrolled."
        ),
        "",
        (
            "Timing includes process startup, imports, parsing and complete input "
            "alignment once, repeated queries, checksum accumulation, final output, "
            "flush/close, and exit. Fixture creation, verification, compilation, "
            "and hashing are outside the clock. OS caches are warm and output is "
            "not fsynced."
        ),
        "",
        (
            f"The final records retain **{gates + samples + warmups:,} executions: "
            f"{samples:,} measured, {warmups:,} warmups, and {gates:,} correctness "
            "gates**, including four empty-input controls. Every execution checks "
            "complete stdout, stderr, status, and filesystem contents. The independent "
            "audit recomputes summaries and ratios, checks order balance, and binds "
            "results to exact source, tool, build, validation, and binary identities."
        ),
        "",
        "Raw records: "
        + ", ".join(
            f"[{family}/{mode}]({PREFIX}-{family}-{mode}.json.gz)"
            for family, mode in RECORDS
        )
        + f". See the [validation audit]({PREFIX}-validation-audit.json), "
        f"[benchmark audit]({PREFIX}-benchmark-audit.json), "
        f"[evidence archive]({PREFIX}-evidence.tar.gz), and "
        f"[member manifest]({PREFIX}-evidence-manifest.json).",
        "",
        (
            "The archive preserves measured sources, LLVM, logs, complete raw "
            "results, the exploratory pilot, audits, and reproduction helpers. "
            "Native binaries, runtime archives, interpreters, and toolchains remain "
            "external and hash-identified. Prior evidence archives are not nested. "
            "Original commands retain host-specific paths; the "
            "[example guide](../../examples/telemetry_comparison/README.md) and "
            "[Rust reference guide](../reference/telemetry_comparison/README.md) "
            "provide portable entrypoints."
        ),
        "",
    ]
    output = Path("/tmp/relar-iterator-report.md")
    output.write_text("\n".join(lines))
    print(output)


if __name__ == "__main__":
    main()
