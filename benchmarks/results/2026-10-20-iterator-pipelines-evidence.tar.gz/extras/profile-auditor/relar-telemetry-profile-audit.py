"""Independently audit retained telemetry profiles without executing workloads."""

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shlex


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def decoded_file(value):
    data = base64.b64decode(value['base64'], validate=True)
    require(sha(data) == value['sha256'] and len(data) == value['bytes'], 'encoded file identity differs')
    return data


def parse_callgrind(path):
    """Separate self-event rows from the single event row following each call."""
    lines = path.read_text().splitlines()
    require([line for line in lines if line.startswith('positions:')] == ['positions: instr line'], 'unexpected positions')
    require([line for line in lines if line.startswith('events:')] == ['events: Ir'], 'unexpected events')
    summaries = [int(line.partition(':')[2].strip()) for line in lines if line.startswith('summary:')]
    require(len(summaries) == 1 and summaries[0] > 0, 'missing instruction summary')
    identities = {}
    for line in lines:
        match = re.fullmatch(r'(?:c?fn)=\((\d+)\) (.+)', line)
        if match:
            old = identities.setdefault(match[1], match[2])
            require(old == match[2], 'function identity changed')
    own, calls, incoming = Counter(), Counter(), Counter()
    current = callee = pending = None
    for line in lines:
        match = re.fullmatch(r'(c?fn)=\((\d+)\)(?: .+)?', line)
        if match:
            if match[1] == 'fn':
                require(pending is None, 'unfinished call edge')
                current = identities[match[2]]
            else:
                callee = identities[match[2]]
            continue
        if line.startswith('calls='):
            require(callee is not None and pending is None, 'invalid call setup')
            calls[callee] += int(line.split()[0].split('=')[1])
            pending = callee
            continue
        fields = line.split()
        if len(fields) not in (2, 3) or not re.fullmatch(r'(?:0x[0-9a-f]+|[+-]?\d+|\*)', fields[0]):
            continue
        if not re.fullmatch(r'(?:[+-]?\d+|\*)', fields[1]):
            continue
        count = int(fields[2]) if len(fields) == 3 else 0
        require(count >= 0, 'negative instruction count')
        if pending is not None:
            incoming[pending] += count
            pending = None
        else:
            require(current is not None, 'self count without function')
            own[current] += count
    require(pending is None and sum(own.values()) == summaries[0], 'raw self counts do not match total')
    functions = {
        name: {'self_instructions': count, 'calls': calls[name], 'incoming_inclusive_instructions': incoming[name]}
        for name, count in own.items()
    }
    return summaries[0], functions


def parse_dhat(path):
    heap = json.loads(path.read_text())
    require(heap['mode'] == 'heap' and heap['tu'] == 'instrs', 'unexpected DHAT mode')
    mapping = {
        'allocated_bytes': 'tb', 'allocated_blocks': 'tbk',
        'peak_live_bytes': 'gb', 'peak_live_blocks': 'gbk',
        'exit_live_bytes': 'eb', 'exit_live_blocks': 'ebk',
    }
    metrics = {}
    for name, field in mapping.items():
        require(all(isinstance(point[field], int) and point[field] >= 0 for point in heap['pps']), 'invalid DHAT count')
        metrics[name] = sum(point[field] for point in heap['pps'])
    metrics['top_allocation_stacks'] = [
        {'bytes': point['tb'], 'blocks': point['tbk'], 'frames': [heap['ftbl'][index] for index in point['fs']]}
        for point in sorted(heap['pps'], key=lambda point: point['tb'], reverse=True)[:20]
    ]
    return metrics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path('/tmp/relar-telemetry-profile'))
    parser.add_argument('--output', type=Path, default=Path('/tmp/relar-telemetry-profile-audit.json'))
    args = parser.parse_args()
    root = args.directory.resolve(strict=True)
    read = lambda name: json.loads((root / name).read_text())
    summary = read('summary.json')
    summary_hash = digest(root / 'summary.json')
    require(summary['status'] == 'passed' and summary['complete'] and summary['input_guards_passed'], 'profile is incomplete')
    require(summary['thinlto'] and summary['label'] == 'alert-quiet-4096', 'wrong profile scope')
    manifest = read('manifest.json')
    require(set(manifest) == {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file() and path.name != 'manifest.json'}, 'retained file set differs')
    for name, expected in manifest.items():
        require(digest(root / name) == expected, 'artifact hash differs: ' + name)
    for name, expected in summary['snapshot_sha256'].items():
        require(digest(root / name) == expected, 'snapshot hash differs: ' + name)
    for name, value in summary['guarded_inputs'].items():
        require(digest(value['path']) == value['sha256'], 'guarded source/tool/artifact changed: ' + name)
    prepared, benchmark, timing = read('preparation.json'), read('benchmark-record.json'), read('timing-status.json')
    build, rust_build, validation = read('relar-build-record.json'), read('rust-build-record.json'), read('validation-index.json')
    require(digest(root / 'preparation.json') == summary['preparation_record_sha256'], 'preparation hash differs')
    require(digest(root / 'benchmark-record.json') == summary['benchmark_record_sha256'], 'benchmark hash differs')
    require(digest(root / 'timing-status.json') == summary['timing_status_sha256'], 'timing status hash differs')
    require(timing['status'] == 'passed' and not timing['exploratory'] and timing['input_guards_passed'] and timing['source_unchanged'], 'timing incomplete')
    require(datetime.fromisoformat(summary['started_at_utc']) > datetime.fromisoformat(timing['completed_at_utc']), 'profiling overlaps the bound timing run')
    runs = [run for run in timing['runs'] if run['mode'] == 'thinlto']
    require(len(runs) == 1 and runs[0]['status'] == 'passed' and runs[0]['exit_code'] == 0, 'wrong ThinLTO timing run')
    require(runs[0]['output_sha256'] == summary['benchmark_record_sha256'], 'profile uses another timing record')
    require(benchmark['kind'] == 'telemetry-benchmark' and benchmark['input_guards_passed'] and benchmark['completed_at_utc'] and benchmark['thinlto'] and not benchmark['dirty'], 'invalid benchmark record')
    require(benchmark['preparation'] == prepared and benchmark['preparation_record_sha256'] == summary['preparation_record_sha256'], 'preparation not used by benchmark')
    require(prepared['kind'] == 'telemetry-preparation' and prepared['input_guards_passed'] and prepared['thinlto'] and not prepared['dirty'], 'invalid preparation')
    require(prepared['revision'] == benchmark['revision'] == timing['timing_revision'] == summary['timing_revision'], 'timing source revision differs')
    require(prepared['relar_build_record'] == build and prepared['rust_build_record'] == rust_build, 'build snapshot differs')
    require(build['input_guards_passed'] and build['source_matches_revision'], 'invalid Relar build')
    require(build['revision'] == timing['build_revision'] == timing['validation_revision'] == summary['build_revision'] == summary['validation_revision'] == validation['revision'], 'build/validation source revision differs')
    require(validation['status'] == 'passed' and validation['input_guards_passed'] and validation['source_unchanged'], 'validation incomplete')
    require(digest(root / 'validation-index.json') == timing['validation_index_sha256'], 'different validation index')
    require(summary['post_validation_changes'] == timing['post_validation_changes'], 'revision-difference declaration changed')
    require(digest(root / 'relar-build-record.json') == validation['build_record']['sha256'] == prepared['source_and_tool_sha256']['relar_build_record'], 'Relar artifact provenance differs')
    require(rust_build['input_guards_passed'] and rust_build['thinlto'], 'invalid Rust build')
    require(digest(root / 'rust-build-record.json') == prepared['source_and_tool_sha256']['rust_build_record'], 'Rust build record differs')
    require(digest(root / 'native.ll') == prepared['llvm_sha256'], 'LLVM differs from timed build')
    require(read('prepared-validation.json') == prepared['validation'] and digest(root / 'prepared-validation.json') == prepared['validation_sha256'], 'prepared validation differs')
    require(benchmark['source_and_tool_sha256'] == prepared['source_and_tool_sha256'], 'timed source/tool identities differ')
    for name, expected in prepared['source_and_tool_sha256'].items():
        guard = summary['guarded_inputs'][name]
        require(guard['sha256'] == expected and Path(guard['path']).resolve() == Path(prepared['source_and_tool_paths'][name]).resolve(), 'prepared source/tool guard differs: ' + name)
    for name in ('validator', 'filesystem_validator', 'batch_validator', 'incremental_validator', 'shared_validator'):
        copied = root / ('oracle-' + Path(prepared['source_and_tool_paths'][name]).name)
        require(digest(copied) == prepared['source_and_tool_sha256'][name], 'independent oracle snapshot differs')
    require(digest(root / 'profiler.py') == summary['guarded_inputs']['profiler']['sha256'], 'profiler helper snapshot differs')
    binary_hashes = {'relar': prepared['binary_sha256'], 'rust': prepared['source_and_tool_sha256']['rust']}
    require(benchmark['binary_sha256'] == binary_hashes['relar'] and rust_build['binary_sha256'] == binary_hashes['rust'], 'native binary provenance differs')
    binaries = {'relar': Path(prepared['binary']).resolve(), 'rust': Path(prepared['source_and_tool_paths']['rust']).resolve()}
    for name, binary in binaries.items():
        require(digest(binary) == binary_hashes[name], 'exact timed binary changed')
    workloads = [workload for workload in benchmark['workloads'] if workload['label'] == summary['label']]
    require(len(workloads) == 1, 'workload missing or repeated')
    workload = workloads[0]
    require(workload['scenario'] == 'alert-quiet' and workload['label'] == 'alert-quiet-4096' and workload['inspected_pairs_per_call'] == 4096, 'unexpected workload')
    require(set(summary['cases']) == {'128', '256'}, 'wrong query counts')
    cases = {}
    for count in (128, 256):
        metadata = summary['cases'][str(count)]
        case = metadata['case']
        expected_case = json.loads(json.dumps(workload['case']))
        expected_case['arguments'][-1] = str(count)
        require(case == expected_case and metadata['pairs'] == count * 4096, 'profile inputs changed beyond repeat count')
        args_ = case['arguments']
        require(len(args_) == 6 and args_[0] == 'alert' and int(args_[-1]) == count, 'wrong invocation')
        files = {name: decoded_file(value) for name, value in case['files'].items()}
        reference, observed = [files[name].decode('utf-8').splitlines() for name in args_[1:3]]
        require(int(reference[0]) == int(observed[0]) == 4096 and len(reference) == len(observed) == 4097, 'sample counts differ')
        left = [tuple(map(int, row.split())) for row in reference[1:]]
        right = [tuple(map(int, row.split())) for row in observed[1:]]
        threshold = int(args_[4])
        require(all(len(a) == len(b) == 2 and a[0] == b[0] and abs(a[1] - b[1]) <= threshold for a, b in zip(left, right, strict=True)), 'quiet workload can alert')
        require(all(rows[i - 1][0] < rows[i][0] for rows in (left, right) for i in range(1, len(rows))), 'timestamps not increasing')
        require(metadata['expected_stdout'] == 'OK\n0\n', 'false-query repetition checksum is wrong')
        expected_files = {name: decoded_file(value) for name, value in metadata['expected_files'].items()}
        files[args_[3]] = b'False\n'
        require(expected_files == files and metadata['expected_directories'] == [], 'unexpected independent file oracle')
        require(case['directories'] == [] and case['hardlinks'] == {}, 'unexpected filesystem shape')
        cases[count] = (case, expected_files)
    expected_profiles = {(engine, tool, count) for engine in binaries for tool, count in (('callgrind', 128), ('dhat', 128), ('dhat', 256))}
    require({(item['engine'], item['tool'], item['repetitions']) for item in summary['profiles']} == expected_profiles and len(summary['profiles']) == 6, 'incomplete/duplicate profile runs')
    parsed = {}
    for item in summary['profiles']:
        engine, tool, count = item['engine'], item['tool'], item['repetitions']
        name = f'{engine}-{tool}-{count}'
        directory = root / name
        record = json.loads((directory / 'command.json').read_text())
        require(record == {key: value for key, value in item.items() if key != 'files'}, 'profile command record differs')
        require(item['returncode'] == 0 and item['status'] == 'validated' and item['binary_sha256'] == binary_hashes[engine], 'profile command did not validate')
        require(item['pairs'] == count * 4096 and Path(item['cwd']) == directory / 'work', 'profile workload/cwd differs')
        command = item['command']
        require(Path(command[0]).resolve() == Path(summary['guarded_inputs']['tool_valgrind']['path']).resolve(), 'different Valgrind executable')
        require('--num-callers=32' in command, 'different allocation stack depth')
        if tool == 'callgrind':
            require('--dump-instr=yes' in command and '--collect-jumps=yes' in command, 'different instruction collection')
        require('--tool=' + tool in command and '--command-line-only=yes' in command and '--error-exitcode=97' in command, 'unsafe/different profiler invocation')
        position = command.index(str(binaries[engine]))
        require(command[position + 1:] == cases[count][0]['arguments'], 'native arguments differ')
        require(item['environment'] == summary['environment'] and summary['environment']['LC_ALL'] == 'C' and summary['environment']['VALGRIND_OPTS'] == '', 'environment differs')
        require((directory / 'stdout.txt').read_bytes() == summary['cases'][str(count)]['expected_stdout'].encode(), 'complete stdout/checksum differs')
        require((directory / 'stderr.txt').read_bytes() == b'', 'native stderr is nonempty')
        require({path.relative_to(directory / 'work').as_posix(): path.read_bytes() for path in (directory / 'work').rglob('*') if path.is_file()} == cases[count][1], 'final filesystem differs')
        require(not any(path.is_dir() for path in (directory / 'work').iterdir()), 'unexpected output directory')
        require(set(item['files']) == {path.relative_to(directory).as_posix() for path in directory.rglob('*') if path.is_file()}, 'profile file inventory differs')
        for relative, expected in item['files'].items():
            require(digest(directory / relative) == expected, 'profile member hash differs')
        log = (directory / 'valgrind.log').read_text()
        require(not re.search(r'ERROR SUMMARY: [1-9]|Fatal error|unhandled instruction|Process terminating with', log), 'Valgrind failure marker')
        if tool == 'callgrind':
            total, functions = parse_callgrind(directory / 'profile.callgrind')
            raw_lines = (directory / 'profile.callgrind').read_text().splitlines()
            raw_commands = [line.partition(':')[2].strip() for line in raw_lines if line.startswith('cmd:')]
            require(len(raw_commands) == 1 and shlex.split(raw_commands[0]) == command[position:], 'Callgrind profiled another command')
            require([int(line.partition(':')[2]) for line in raw_lines if line.startswith('totals:')] == [total], 'Callgrind final totals differ')
            metrics = item['metrics']
            require(metrics['instructions'] == metrics['self_cost_sum'] == total, 'instruction summary differs')
            recorded = {row['name']: {key: row[key] for key in ('self_instructions', 'calls', 'incoming_inclusive_instructions')} for row in metrics['functions']}
            require(len(recorded) == len(metrics['functions']) and recorded == functions, 'raw function counts differ')
            require(all(row['self_fraction'] == row['self_instructions'] / total for row in metrics['functions']), 'function fraction differs')
            require(len(item['annotations']) == 2 and all(value['returncode'] == 0 for value in item['annotations']), 'annotation incomplete')
            for inclusive in ('no', 'yes'):
                require((directory / f'inclusive-{inclusive}-stderr.txt').read_bytes() == b'', 'annotation stderr nonempty')
            parsed[name] = {'instructions': total, 'instructions_per_inspected_pair': total / item['pairs'], 'top_self_functions': metrics['functions'][:15]}
        else:
            metrics = parse_dhat(directory / 'profile.json')
            raw_heap = json.loads((directory / 'profile.json').read_text())
            require(shlex.split(raw_heap['cmd']) == command[position:], 'DHAT profiled another command')
            require(metrics == item['metrics'], 'raw DHAT totals/stacks differ')
            parsed[name] = metrics
    slopes = {}
    for engine in binaries:
        slopes[engine] = {}
        for field in ('allocated_bytes', 'allocated_blocks'):
            a, b = [parsed[f'{engine}-dhat-{count}'][field] for count in (128, 256)]
            expected = {'at_128_queries': a, 'at_256_queries': b, 'per_additional_query': (b - a) / 128, 'two_point_fixed_estimate': 2 * a - b}
            require(summary['allocation_growth'][engine][field] == expected, 'allocation growth arithmetic differs')
            slopes[engine][field] = {**expected, 'per_additional_inspected_pair': (b - a) / (128 * 4096)}
    allocation_stack_growth = {}
    for engine in binaries:
        captures = []
        for count in (128, 256):
            heap = json.loads((root / f'{engine}-dhat-{count}/profile.json').read_text())
            totals = {}
            for point in heap['pps']:
                frames = tuple(heap['ftbl'][index] for index in point['fs'])
                item = totals.setdefault(frames, [0, 0])
                item[0] += point['tb']
                item[1] += point['tbk']
            captures.append(totals)
        differences = []
        for frames in captures[0].keys() | captures[1].keys():
            left, right = [capture.get(frames, [0, 0]) for capture in captures]
            delta = [right[index] - left[index] for index in (0, 1)]
            if any(delta):
                differences.append({'additional_bytes': delta[0], 'additional_blocks': delta[1], 'frames': list(frames)})
        require(sum(item['additional_bytes'] for item in differences) == slopes[engine]['allocated_bytes']['at_256_queries'] - slopes[engine]['allocated_bytes']['at_128_queries'], 'allocation stack byte deltas differ')
        require(sum(item['additional_blocks'] for item in differences) == slopes[engine]['allocated_blocks']['at_256_queries'] - slopes[engine]['allocated_blocks']['at_128_queries'], 'allocation stack block deltas differ')
        allocation_stack_growth[engine] = sorted(differences, key=lambda item: (item['additional_bytes'], item['frames']), reverse=True)
    require(digest(root / 'summary.json') == summary_hash, 'summary changed during audit')
    report = {
        'schema': 1, 'status': 'passed', 'audited_at_utc': datetime.now(timezone.utc).isoformat(),
        'profile_directory': str(root), 'profile_summary_sha256': summary_hash,
        'profile_manifest_sha256': digest(root / 'manifest.json'), 'audit_script_sha256': digest(__file__),
        'timing_revision': summary['timing_revision'], 'build_revision': summary['build_revision'],
        'validation_revision': summary['validation_revision'], 'post_validation_changes': summary['post_validation_changes'],
        'benchmark_record_sha256': summary['benchmark_record_sha256'], 'timing_status_sha256': summary['timing_status_sha256'],
        'preparation_record_sha256': summary['preparation_record_sha256'], 'binary_sha256': binary_hashes,
        'llvm_sha256': prepared['llvm_sha256'], 'profiles_verified': 6, 'evidence_files_verified': len(manifest),
        'complete_stdout_checksum_and_files_verified': True, 'quiet_input_proved_independently': True,
        'raw_profile_counts_independently_reparsed': True, 'profiles_started_after_bound_timing_completed': True,
        'metrics': parsed, 'allocation_growth': slopes, 'allocation_stack_growth': allocation_stack_growth,
        'whole_process_instruction_ratio_relar_over_rust': parsed['relar-callgrind-128']['instructions'] / parsed['rust-callgrind-128']['instructions'],
        'limits': [
            'Guest instructions are not CPU cycles or wall-time speedups; inclusive call edges overlap and must not be added as independent costs.',
            'Profiles cover whole processes including startup/loading; only allocation differences between query counts isolate descriptive query-dependent growth.',
            'DHAT requested heap bytes/blocks are not RSS. Global-peak and exit-live counts are different metrics; exit-live memory alone does not establish leaks.',
            'Two query counts support a descriptive allocation slope, not proof of linearity across workloads or counts.',
            'No engines, oracle programs, builds, tests, benchmark timing, or profiles were executed by this audit.',
        ],
    }
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'audit': str(args.output), 'sha256': digest(args.output)}))


if __name__ == '__main__':
    main()
