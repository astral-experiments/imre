"""Record already-built frozen tools against the final clean integration commit."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/home/dev-user/code/oss/relar')
DEST = ROOT / 'benchmarks/local/four-feature-tools-final'
EXPECTED = '97cb1000565035162c31e6e455d207cf65b54993'
WRAPPER = Path('/tmp/relar-cargo.sh')
RUNTIME_ROOT = Path('/tmp/relar-integrated-runtimes')
NORMAL_RECORD = Path('/tmp/relar-bytes-integrated-validation/build.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sources():
    paths = [ROOT / name for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml')]
    paths += sorted((ROOT / 'crates').rglob('*.rs'))
    paths += sorted((ROOT / 'crates').glob('*/Cargo.toml'))
    paths += sorted((ROOT / '.cargo').glob('*.toml'))
    return {str(path.relative_to(ROOT)): sha(path) for path in paths}


def committed_sources():
    assert git('rev-parse', 'HEAD').decode().strip() == EXPECTED
    assert not git('status', '--porcelain')
    current = sources()
    for name, expected in current.items():
        assert hashlib.sha256(git('show', EXPECTED + ':' + name)).hexdigest() == expected, name
    return current


before = committed_sources()
copies = json.loads((DEST / 'copies.json').read_text())
assert copies['git_head'] == EXPECTED
normal = json.loads(NORMAL_RECORD.read_text())
combined_path = RUNTIME_ROOT / 'build-record.json'
combined = json.loads(combined_path.read_text())
assert combined['runtime_and_cargo_sources_unchanged']
assert combined['source_sha256_before'] == combined['source_sha256_after'] == combined['source_sha256']
for name, expected in combined['source_sha256'].items():
    assert before[name] == expected, name
normal_runtime_sources = {
    name: value for name, value in normal['sources'].items()
    if name in ('Cargo.toml', 'Cargo.lock') or name.startswith('crates/relar-runtime/')
}
for name, expected in normal_runtime_sources.items():
    assert before[name] == expected, name
assert normal['artifacts']['librelar_runtime.a'] == copies['artifacts']['librelar_runtime.a']['sha256']
live_runtime = Path('/home/dev-user/.cache/relar/target/relar-integrated/librelar_runtime.a')
assert sha(live_runtime) == normal['artifacts']['librelar_runtime.a']
for mode in ('lto', 'asan'):
    assert copies['artifacts'][f'librelar_runtime_{mode}.a']['sha256'] == combined['builds'][mode]['artifact']['sha256']
for item in copies['artifacts'].values():
    target = Path(item['path'])
    assert target.is_file() and not target.is_symlink() and target.stat().st_nlink == 1
    assert sha(target) == item['sha256'] == sha(Path(item['source_path']))

provenance = DEST / 'provenance'
provenance.mkdir(exist_ok=False)
retained = {}
for name, source in {
    'ordinary-origin-build.json': NORMAL_RECORD,
    'combined-runtime-build.json': combined_path,
    'runtime-build.py': RUNTIME_ROOT / 'build.py',
    'cargo-lto.sh': RUNTIME_ROOT / 'cargo-lto.sh',
    'cargo-asan.sh': RUNTIME_ROOT / 'cargo-asan.sh',
    'ordinary-cargo.sh': WRAPPER,
}.items():
    target = provenance / name
    shutil.copy2(source, target)
    retained[name] = {'path': str(target), 'source_path': str(source), 'sha256': sha(target)}
logs = {}
for mode, source in {
    'ordinary': Path('/tmp/relar-four-feature-build-final.log'),
    'thinlto': RUNTIME_ROOT / 'lto.log',
    'asan': RUNTIME_ROOT / 'asan.log',
}.items():
    target = DEST / (mode + '.log')
    shutil.copy2(source, target)
    logs[mode] = {'path': str(target), 'source_path': str(source), 'sha256': sha(target)}
assert 'Finished `relar-integrated` profile' in (DEST / 'ordinary.log').read_text()
shutil.copy2(Path(__file__), DEST / 'freeze.py')
commands = {
    'ordinary': {
        'command': ['sh', str(WRAPPER), 'build', '--workspace', '--locked', '--profile',
                    'relar-integrated', '--config', 'profile.relar-integrated.inherits="release"'],
        'environment': {'CARGO_BUILD_JOBS': '6'},
        'profile': 'relar-integrated (inherits release)',
        'returncode': 0,
        'result_evidence': 'Parent reported successful completion immediately before freeze; retained log confirms the matching final profile build. This freeze did not rerun Cargo.',
        'log_sha256': logs['ordinary']['sha256'],
    },
}
for mode, label in (('lto', 'thinlto'), ('asan', 'asan')):
    item = combined['builds'][mode]
    commands[label] = {
        'command': item['command'], 'profile': item['profile'], 'returncode': item['returncode'],
        'environment': {'CARGO_BUILD_JOBS': '4',
                        'RUSTFLAGS': combined['runtime_' + mode + '_rustflags'],
                        'RUSTC_BOOTSTRAP': '1' if mode == 'asan' else None,
                        'CARGO_ENCODED_RUSTFLAGS': None},
        'log_sha256': logs[label]['sha256'],
        'started_at_utc': item['started_at_utc'], 'finished_at_utc': item['finished_at_utc'],
    }
record = {
    'stage': 'four-feature-tools-final',
    'started_at_utc': copies['started_at_utc'],
    'git_head': EXPECTED, 'git_status': '', 'compiled_sources_match_commit': True,
    'source_sha256': before,
    'source_contents': {name: (ROOT / name).read_text() for name in before},
    'sha256': {str(Path(item['path']).relative_to(ROOT)): item['sha256']
               for item in copies['artifacts'].values()},
    'artifacts': copies['artifacts'],
    'rustc_verbose': subprocess.check_output(['rustc', '+ohm', '-vV'], text=True),
    'cargo_version': subprocess.check_output(['cargo', '+ohm', '-Zohm-defaults=no', '--version'], text=True).strip(),
    'cargo_wrapper': {'path': str(WRAPPER), 'sha256': sha(WRAPPER), 'source': WRAPPER.read_text()},
    'commands': commands, 'logs': logs, 'retained_provenance': retained,
    'runtime_lto_rustflags': '-Clinker-plugin-lto',
    'runtime_asan_rustflags': '-Zsanitizer=address -Cforce-frame-pointers=yes',
    'build_environment': {
        'scope': 'Explicit wrapper settings and parent-reported ordinary command; observed ambient flags at freeze are recorded separately, not claimed as a historical environment capture.',
        'CARGO_HOME': '/home/dev-user/.cache/relar/cargo-home',
        'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/shared-build',
        'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST': 'all',
        'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST': 'all',
        'ordinary_target_dir': '/home/dev-user/.cache/relar/target',
        'lto_target_dir': '/home/dev-user/.cache/relar-integrated-lto/target',
        'asan_target_dir': '/home/dev-user/.cache/relar-integrated-asan/target',
        'ohm_automatic_defaults': 'disabled with -Zohm-defaults=no',
        'observed_ambient_flags_at_freeze': {name: os.environ.get(name) for name in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_BOOTSTRAP')},
    },
    'source_proof': {
        'final_committed_files_checked': len(before),
        'all_current_files_match_git_blobs': True,
        'compiler': 'Final parent-reported workspace build on the clean committed source; every compiled Rust/Cargo input rechecked against HEAD before and after freeze. No pre-build capture is claimed here.',
        'normal_runtime_recorded_source_sha256': normal_runtime_sources,
        'normal_runtime_matches_final_workspace_artifact': True,
        'normal_runtime_note': 'The selected previously tested archive is byte-identical to the final workspace build output. Its recorded runtime/root Cargo source hashes also match the final commit; final crate manifest/toolchain inputs are verified through the workspace build and final committed-source check.',
        'lto_asan_runtime_recorded_source_sha256': combined['source_sha256'],
        'lto_asan_sources_unchanged_before_after_builds': True,
        'lto_asan_source_hashes_match_final_commit': True,
        'lto_asan_note': 'Earlier runtime builds ran during compiler integration. All 15 captured runtime/Cargo/toolchain inputs now reconcile exactly with the final commit; changed compiler files were not inputs to those runtime-only builds.',
    },
    'freshness': {'independent_regular_copies': True,
                  'source_artifact_hashes_rechecked_after_copy': True,
                  'no_other_builds_or_source_mutations_during_freeze': 'parent-coordinated hold'},
    'build_script': (DEST / 'freeze.py').read_text(),
    'build_script_sha256': sha(DEST / 'freeze.py'),
}
after = committed_sources()
assert before == after
for item in copies['artifacts'].values():
    assert sha(Path(item['path'])) == item['sha256']
record['completed_at_utc'] = datetime.now(timezone.utc).isoformat()
path = DEST / 'build-record.json'
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + '\n')
print('Build record: ' + str(path))
print('Build record SHA256: ' + sha(path))
print('Committed source files reconciled: ' + str(len(before)))
print('Runtime build inputs reconciled: ' + str(len(combined['source_sha256'])))
