#!/bin/sh
export CARGO_BUILD_JOBS=4
export CARGO_HOME=/home/dev-user/.cache/relar/cargo-home
export CARGO_TARGET_DIR=/home/dev-user/.cache/relar-integrated-lto/target
export CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/shared-build
export CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST=all
export CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST=all
export RUSTFLAGS='-Clinker-plugin-lto'
unset CARGO_ENCODED_RUSTFLAGS
unset RUSTC_BOOTSTRAP
relar_command=$1
shift
exec cargo +ohm -Zohm-defaults=no "$relar_command" --profile relar-integrated-lto --config 'profile.relar-integrated-lto.inherits="release"' "$@"
