#!/bin/sh
export CARGO_BUILD_JOBS=4
export CARGO_HOME=/home/dev-user/.cache/imre/cargo-home
export CARGO_TARGET_DIR=/home/dev-user/.cache/imre-integrated-lto/target
export CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/shared-build
export CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST=all
export CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST=all
export RUSTFLAGS='-Clinker-plugin-lto'
unset CARGO_ENCODED_RUSTFLAGS
unset RUSTC_BOOTSTRAP
imre_command=$1
shift
exec cargo +ohm -Zohm-defaults=no "$imre_command" --profile imre-integrated-lto --config 'profile.imre-integrated-lto.inherits="release"' "$@"
