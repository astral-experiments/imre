#!/bin/sh
export CARGO_HOME=/home/dev-user/.cache/relar/cargo-home
export CARGO_TARGET_DIR=/home/dev-user/.cache/relar/target
export CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/shared-build
export CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST=all
export CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST=all
exec cargo +ohm -Zohm-defaults=no "$@"
