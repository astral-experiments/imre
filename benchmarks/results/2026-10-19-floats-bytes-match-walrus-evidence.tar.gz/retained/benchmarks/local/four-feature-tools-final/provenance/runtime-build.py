from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,sys
ROOT=Path('/home/dev-user/code/oss/imre')
HERE=Path(__file__).resolve().parent
TARGET='x86_64-unknown-linux-gnu'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def sources():
 paths=[ROOT/'Cargo.toml',ROOT/'Cargo.lock',ROOT/'rust-toolchain.toml',*sorted((ROOT/'crates/imre-runtime').rglob('*.rs')),ROOT/'crates/imre-runtime/Cargo.toml']
 paths.extend(sorted((ROOT/'.cargo').glob('*.toml')))
 return {str(path.relative_to(ROOT)):sha(path) for path in paths}
initial=sources()
record={'started_at_utc':datetime.now(timezone.utc).isoformat(),'git_head_before':git('rev-parse','HEAD'),'git_status_before':git('status','--porcelain'),'source_sha256_before':initial,'source_contents':{name:(ROOT/name).read_text() for name in initial},'rustc_verbose':subprocess.check_output(['rustc','+ohm','-vV'],text=True),'cargo_version':subprocess.check_output(['cargo','+ohm','-Zohm-defaults=no','--version'],text=True).strip(),'target':TARGET,'jobs':4,'shared_build_dir':'/home/dev-user/.cache/ohm/shared-build','runtime_lto_rustflags':'-Clinker-plugin-lto','runtime_asan_rustflags':'-Zsanitizer=address -Cforce-frame-pointers=yes','builds':{},'note':'Runtime/Cargo sources are frozen while the parent continues compiler integration; dirty compiler files and changing HEAD are expected. No tests or timings are run.'}
def save():(HERE/'build-record.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for mode in ['lto','asan']:
 before=sources()
 assert before==initial,'runtime/Cargo source changed before '+mode
 wrapper=HERE/f'cargo-{mode}.sh'
 command=['sh',str(wrapper),'build','-p','imre-runtime','--locked','--target',TARGET]
 log=HERE/f'{mode}.log'
 item={'command':command,'profile':f'imre-integrated-{mode} (inherits release)','wrapper_sha256':sha(wrapper),'started_at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256_before':before}
 record['builds'][mode]=item;save()
 print('Building '+mode+' runtime; log: '+str(log),flush=True)
 with log.open('w') as stream:result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
 item.update(returncode=result.returncode,finished_at_utc=datetime.now(timezone.utc).isoformat(),log_sha256=sha(log),source_sha256_after=sources());save()
 if result.returncode:
  print(log.read_text(),flush=True);sys.exit(result.returncode)
 assert item['source_sha256_after']==initial,'runtime/Cargo source changed during '+mode
 artifact=Path(f'/home/dev-user/.cache/imre-integrated-{mode}/target')/TARGET/f'imre-integrated-{mode}/libimre_runtime.a'
 frozen=HERE/f'libimre_runtime_{mode}.a'
 assert not frozen.exists()
 shutil.copyfile(artifact,frozen)
 assert not frozen.is_symlink() and frozen.stat().st_nlink==1
 item['artifact']={'path':str(frozen),'source_path':str(artifact),'bytes':frozen.stat().st_size,'sha256':sha(frozen),'regular_independent_copy':True};save()
 print('Frozen '+str(frozen)+' '+item['artifact']['sha256'],flush=True)
record.update(completed_at_utc=datetime.now(timezone.utc).isoformat(),source_sha256_after=sources(),git_head_after=git('rev-parse','HEAD'),git_status_after=git('status','--porcelain'))
assert record['source_sha256_after']==initial
record['runtime_and_cargo_sources_unchanged']=True
record['sha256']={item['artifact']['path']:item['artifact']['sha256'] for item in record['builds'].values()}
record['source_sha256']=initial
save()
print('Build record: '+str(HERE/'build-record.json'),flush=True)
