"""Verify the published evidence and saved outcomes without native artifacts."""

import argparse
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import re
import runpy
import statistics
import tarfile
import tempfile

PREFIX = '2026-10-19-floats-bytes-match-walrus'
COMMIT = '97cb1000565035162c31e6e455d207cf65b54993'
ENGINES = ('cpython', 'imre', 'rust_bigint', 'baseline')


def info(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def close(actual, expected):
    assert math.isclose(actual, expected, rel_tol=2e-13, abs_tol=1e-12), (actual, expected)


def count(log):
    matches = re.findall(r'Passed\s+(\d+)[^\n]*checks|(\d+) import checks passed', log)
    assert matches
    return int(next(value for value in matches[-1] if value))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', required=True, type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    directory = args.directory.resolve()
    manifest_bytes = (directory / (PREFIX + '-evidence-manifest.json')).read_bytes()
    manifest = json.loads(manifest_bytes)
    assert manifest['source_commit'] == COMMIT
    for name, expected in manifest['companions'].items():
        data = (directory / name).read_bytes()
        assert info(data) == {key: expected[key] for key in ('sha256', 'bytes')}, name
        if name.endswith('.gz'):
            assert data[:3] == b'\x1f\x8b\x08' and int.from_bytes(data[4:8], 'little') == 0
        if 'uncompressed' in expected:
            assert info(gzip.decompress(data)) == expected['uncompressed'], name
    archive_data = (directory / (PREFIX + '-evidence.tar.gz')).read_bytes()
    members = {}
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode='r:gz') as archive:
        for item in archive:
            assert item.isfile() and not Path(item.name).is_absolute()
            assert '..' not in Path(item.name).parts and item.name not in members
            assert item.mtime == item.uid == item.gid == 0
            data = archive.extractfile(item).read()
            data.decode('utf-8')
            assert not data.startswith((b'\x7fELF', b'!<arch>\n', b'BC\xc0\xde'))
            assert Path(item.name).suffix not in {'.a', '.o', '.so', '.rlib', '.bc', '.exe', '.pyc'}
            members[item.name] = data
    assert set(members) == {*manifest['members'], 'manifest.json'}
    assert info(members['manifest.json']) == manifest['archive_manifest']
    inner = json.loads(members['manifest.json'])
    assert inner['source_commit'] == COMMIT and inner['members'] == manifest['members']
    by_source = {}
    for name, expected in manifest['members'].items():
        assert info(members[name]) == {key: expected[key] for key in ('sha256', 'bytes')}
        by_source[expected['source']] = members[name]

    def retained(source):
        return by_source[str(source)]

    def retained_json(source):
        return json.loads(retained(source))

    def published(suffix):
        return json.loads((directory / (PREFIX + '-' + suffix)).read_text())

    build, session = published('build.json'), published('session.json')
    summary, validation = published('summary.json'), published('validation.json')
    independent = published('audit.json')
    assert build['git_head'] == session['source_commit'] == summary['source_commit'] == validation['source_commit'] == COMMIT
    assert validation['status'] == summary['status'] == 'passed' and independent['passed']
    assert build['compiled_sources_match_commit'] and not build['git_status']
    assert session['source_guard_before'] == session['source_guard_after']
    assert session['baseline_guard_before'] == session['baseline_guard_after']
    assert session['bytecode_before'] == session['bytecode_after']
    assert all(run['returncode'] == 0 for run in session['runs'].values())
    assert summary['independent_audit_sha256'] == info((directory / (PREFIX + '-audit.json')).read_bytes())['sha256']
    assert summary['validation_sha256'] == info((directory / (PREFIX + '-validation.json')).read_bytes())['sha256']
    audited_summary = summary['independent_audit_input_summary']
    assert info(retained(audited_summary['path'])) == independent['inputs']['/tmp/imre-four-feature-inventory/summary.json']
    assert info(retained(audited_summary['path'])) == {key: audited_summary[key] for key in ('sha256', 'bytes')}
    assert validation['build_record_sha256'] == info((directory / (PREFIX + '-build.json')).read_bytes())['sha256']
    for hashes in (build['source_sha256'], validation['verified_committed_sources']):
        for name, expected in hashes.items():
            assert info(members['source/' + name])['sha256'] == expected, name
    for name, expected in build['source_sha256'].items():
        assert info(build['source_contents'][name].encode())['sha256'] == expected
    for path, expected in validation['retained_evidence_files'].items():
        assert info(retained(path)) == expected, path

    normal = retained_json('/tmp/imre-final-regression/receipt.json')
    assert normal['all_passed'] and normal['git_head_at_freeze'] == COMMIT
    totals = {'normal': 0, 'asan': 0}
    for suite in normal['suites']:
        log = retained(suite['log'])
        assert suite['ok'] and info(log)['sha256'] == suite['log_sha256']
        assert count(log.decode()) == suite['checks']
        totals[suite['id'].split('-')[0]] += suite['checks']
    assert totals == {'normal': 1113, 'asan': 1435}
    assert normal['setup_correction']['affected_invocations_retried'] == 23
    correction = retained_json(normal['setup_correction']['details'])
    assert correction['all_content_hashes_unchanged']
    for path in normal['setup_correction']['initial_results']:
        assert retained(path)
    leak = retained_json(normal['sanitizer_preflight'])
    assert leak['leak_reported'] and leak['returncode'] != 0

    lto = retained_json('/tmp/imre-final-thinlto-validation/test-receipt.json')
    assert lto['passed'] and lto['source_head'] == COMMIT
    for run in lto['runs'].values():
        log = retained(run['log'])
        assert run['exit_code'] == 0 and info(log)['sha256'] == run['log_sha256']
        assert count(log.decode()) == run['checks']
    assert sum(run['checks'] for run in lto['runs'].values()) == 861
    assert validation['native_checks'] == {**totals, 'thinlto': 851, 'thinlto_cli': 10}
    assert validation['total_native_semantic_and_cli_checks'] == 3409
    rust = retained_json('/tmp/imre-four-feature-final-validation/receipt.json')
    assert rust['status'] == 'passed' and rust['rust_unit_tests'] == validation['rust_unit_tests'] == 81
    for item in rust['logs'].values():
        assert info(retained(item['path']))['sha256'] == item['sha256']
    scope = validation['outside_subset_probes']
    probe_bytes = retained(scope['results']['path'])
    assert info(probe_bytes) == {key: scope['results'][key] for key in ('sha256', 'bytes')}
    probes = json.loads(probe_bytes)
    assert len(probes) == scope['count'] == 9 and not scope['included_in_native_semantic_suite_counts']
    assert all(item['cpython_status'] == 0 and item['imre_status'] != 0 for item in probes.values())
    for path, expected in scope['source_sha256'].items():
        assert info(retained(path))['sha256'] == expected
    dead_info = validation['supplemental_dead_code_probes']
    dead_bytes = retained(dead_info['receipt']['path'])
    assert info(dead_bytes) == {key: dead_info['receipt'][key] for key in ('sha256', 'bytes')}
    dead = json.loads(dead_bytes)
    assert dead_info['count'] == dead['checks'] == 4 and dead['all_rejected']
    assert not dead_info['included_in_native_semantic_suite_counts']
    assert dead['source_commit'] == COMMIT and dead['compiler_sha256'] == build['artifacts']['imre']['sha256']
    for item in dead['records']:
        assert item['returncode'] == 1 and not item['native_artifact_exists']
        assert not item['stdout'] and 'Imre:' in item['stderr']
        assert info(retained(item['source']))['sha256'] == item['source_sha256']

    baseline = retained_json('/tmp/imre-four-feature-inventory/baseline-manifest.json')
    recomputed = {}
    with tempfile.TemporaryDirectory(prefix='imre-four-feature-publication-audit-') as temporary:
        root = Path(temporary)
        for name, data in members.items():
            if name.startswith('source/'):
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        audit_path = root / 'independent-audit.py'
        audit_path.write_bytes(retained('/tmp/imre-four-feature-independent-audit/audit.py'))
        audit = runpy.run_path(str(audit_path))
        validator = runpy.run_path(str(root / 'source/benchmarks/inventory_validate.py'))
        measured = warmups = gates = oracles = devices = 0
        for mode in ('normal', 'lto'):
            raw = gzip.decompress((directory / (PREFIX + '-' + mode + '.json.gz')).read_bytes())
            assert raw == retained('/home/dev-user/code/oss/imre/benchmarks/local/four-feature-inventory-regression/' + mode + '.json')
            assert info(raw)['sha256'] == session['runs'][mode]['record_sha256']
            record = json.loads(raw)
            assert record['git']['revision'] == COMMIT and not record['git']['dirty']
            assert record['host']['cpu']['affinity'] == [0]
            assert all(item['tracer_pid'] == 0 for item in record['execution'].values())
            assert record['options']['samples'] == 48 and record['options']['warmups'] == 2
            assert record['sha256']['compiler'] == build['artifacts']['imre']['sha256']
            runtime = 'libimre_runtime_lto.a' if mode == 'lto' else 'libimre_runtime.a'
            assert record['sha256']['runtime'] == build['artifacts'][runtime]['sha256']
            assert record['sources'] == baseline['modes'][mode]['sources'] and len(record['sources']) == 6
            for name, expected in record['sources'].items():
                assert info(members['source/examples/' + name])['sha256'] == expected
            outcome = audit['correctness'](record, validator, ENGINES)
            rows, ordering, count_samples, count_warmups, count_gates = audit['audit_workloads'](
                record, baseline['modes'][mode], validator, ENGINES, 'imre')
            for row in rows:
                stats = row['statistics']
                row['cpython_speedup'] = row['ratios_of_medians']['cpython_over_imre']
                row['rust_gap_percent'] = 100 * (row['ratios_of_medians']['imre_over_rust_bigint'] - 1)
                row['iqr_overlap_vs_previous'] = max(stats['imre']['p25_ns'], stats['baseline']['p25_ns']) <= min(stats['imre']['p75_ns'], stats['baseline']['p75_ns'])
                row['iqr_overlap_vs_rust'] = max(stats['imre']['p25_ns'], stats['rust_bigint']['p25_ns']) <= min(stats['imre']['p75_ns'], stats['rust_bigint']['p75_ns'])
            saved_modes = independent['modes']
            saved = saved_modes[mode] if isinstance(saved_modes, dict) else next(item for item in saved_modes if item['mode'] == mode)
            assert rows == saved['rows'] and ordering == saved['ordering']
            for row, stated in zip(rows, summary['modes'][mode]['rows'], strict=True):
                assert row['statistics'] == stated['statistics_ns']
                assert row['ratios_of_medians'] == stated['ratios_of_medians']
                assert row['iqr_overlap_vs_previous'] == stated['iqr_overlap_vs_previous']
                assert row['iqr_overlap_vs_rust'] == stated['iqr_overlap_vs_rust']
            for workload, row in zip(record['workloads']['inventory'], summary['modes'][mode]['rows'], strict=True):
                assert workload['label'] == row['workload']
                medians = {engine: statistics.median(sample[engine]['elapsed_ns'] for sample in workload['samples']) / 1e6 for engine in ENGINES}
                for engine in ENGINES:
                    close(row['median_ms'][engine], medians[engine])
                close(row['cpython_over_imre'], medians['cpython'] / medians['imre'])
                close(row['imre_over_rust'], medians['imre'] / medians['rust_bigint'])
                close(row['imre_over_previous'], medians['imre'] / medians['baseline'])
                close(row['imre_change_percent'], 100 * (medians['imre'] / medians['baseline'] - 1))
            measured += count_samples
            warmups += count_warmups
            gates += count_gates
            oracles += outcome['inventory']
            devices += outcome['inventory_device']
            recomputed[mode] = {'workloads': len(rows), 'measured': count_samples,
                                'warmups': count_warmups, 'gates': count_gates,
                                'oracle_outcomes': outcome}
        inventory = retained_json('/tmp/imre-final-inventory-asan/receipt.json')
        assert inventory['input_hashes_unchanged'] and inventory['compile_returncode'] == 0
        assert inventory['source_commit'] == inventory['git_head_after'] == COMMIT
        assert inventory['compiler_sha256'] == build['artifacts']['imre']['sha256']
        assert inventory['runtime_asan_sha256'] == build['artifacts']['libimre_runtime_asan.a']['sha256']
        assert inventory['runtime_asan_rustflags'] == build['runtime_asan_rustflags']
        for when in ('before', 'after'):
            execution = inventory['execution_' + when]
            assert execution['tracer_pid'] == 0 and 'detect_leaks=1' in execution['asan_options']
        asan_outcome = audit['correctness'](
            {'validation': {'inventory': retained_json('/tmp/imre-final-inventory-asan/validation.json')}},
            validator, ('imre_asan',))
        assert asan_outcome == {'inventory': 204, 'inventory_device': 1}
    assert (measured, warmups, gates, oracles, devices) == (2304, 96, 48, 1632, 8)
    result = {
        'status': 'passed', 'source_commit': COMMIT, 'archive_members': len(members),
        'companions': len(manifest['companions']), 'measured_process_runs_recomputed': measured,
        'warmup_process_runs_recomputed': warmups, 'workload_gates_recomputed': gates,
        'timing_oracle_outcomes_recomputed': oracles, 'timing_device_outcomes_recomputed': devices,
        'inventory_asan_outcomes_recomputed': asan_outcome, 'native_semantic_cli_checks_joined': 3409,
        'rust_unit_tests_joined': 81, 'recomputed': recomputed,
        'archive_sha256': info(archive_data)['sha256'], 'manifest_sha256': info(manifest_bytes)['sha256'],
        'script_sha256': info(Path(__file__).read_bytes())['sha256'],
        'note': 'This audit reads the published text/source/records only. Native artifacts and historical raw result files remain external; their recorded provenance is joined, not re-executed or independently recovered from hashes.',
    }
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'recomputed'}, indent=2))


if __name__ == '__main__':
    main()
