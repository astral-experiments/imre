The existing inventory benchmark and prepared launcher require one final clean source commit.

- `git_head` is the full final source commit, `git_status` is empty, and `compiled_sources_match_commit` is true only after reconciling all captured compiler/runtime source hashes with that commit.
- `source_sha256` maps repository-relative compiled Rust/Cargo inputs to their actual SHA256 digests. The launcher verifies each against the current file and `git show`; the benchmark checks them again before/after execution.
- `sha256` includes the frozen `imre`, `libimre_runtime.a`, and `libimre_runtime_lto.a` artifacts. Basenames matter for distinguishing ordinary from ThinLTO runtime archives. Include the tested ASan artifact as well when joining validation receipts.
- `runtime_lto_rustflags` must be exactly `-Clinker-plugin-lto`. Record release-derived local profiles, flags, unique target directories, toolchain versions, build commands, and before/after source proof. Do not substitute the earlier dev-profile byte-agent runtime.
- The interim float/byte `build.json` uses a different schema (`head`, `status`, `sources`, `artifacts`) and cannot be passed directly as `--imre-build-record`.
- The two current combined runtimes under `/tmp/imre-integrated-runtimes` already have captured runtime/Cargo sources. Reconcile those hashes with the final committed source before incorporating them into the final freeze record; no claim about a clean commit should be inferred from their earlier dirty-worktree build.

The existing six-file inventory package must remain byte-identical to the sequence-access comparison. The prepared baseline guard rechecked this successfully on 2026-10-19. No old-source snapshot or extra source control is needed.

Run normal then ThinLTO after final validation and the coordinated heavy-work stop, outside ptrace. The prepared launcher fixes CPython 3.14.5, matching Clang/LLD and Rust references, CPU 0, six captured workloads, 48 rounds over all 24 four-engine permutations twice, and two warmups. It preserves old evidence and rejects an existing output directory. Frozen tools go in the argument to `--tools`; `--expected-head` identifies the source commit, separately from the later report commit.
