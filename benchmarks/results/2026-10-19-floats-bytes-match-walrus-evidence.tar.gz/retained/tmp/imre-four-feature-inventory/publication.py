"""Package the completed four-feature experiment without executing native work."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/dev-user/code/oss/imre')
LOCAL = ROOT / 'benchmarks/local'
HERE = Path(__file__).resolve().parent
TOOLS = LOCAL / 'four-feature-tools-final'
RUNS = LOCAL / 'four-feature-inventory-regression'
STAGE = LOCAL / 'four-feature-publication-stage'
PREFIX = '2026-10-19-floats-bytes-match-walrus'
COMMIT = '97cb1000565035162c31e6e455d207cf65b54993'
AUDIT = Path('/tmp/imre-four-feature-independent-audit')
DEAD_PROBES = Path('/tmp/imre-final-dead-code-probes')
VALIDATORS = [Path('/tmp') / name for name in (
    'imre-final-regression', 'imre-final-thinlto-validation',
    'imre-four-feature-final-validation', 'imre-final-inventory-asan')]
TEXT = {'.py', '.rs', '.c', '.toml', '.json', '.log', '.md', '.txt', '.ll',
        '.sh', '.yaml', '.yml', '.stderr', '.stdout'}


def info(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def sha(path):
    return info(path.read_bytes())['sha256']


def load(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def compressed(data):
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0,
                       compresslevel=9) as stream:
        stream.write(data)
    return output.getvalue()


def archive_path(path):
    path = path.absolute()
    if path.is_relative_to(ROOT):
        return 'retained/' + str(path.relative_to(ROOT))
    assert path.is_relative_to(Path('/tmp'))
    return 'retained/tmp/' + str(path.relative_to('/tmp'))


class Package:
    def __init__(self):
        self.data = {}
        self.members = {}

    def add(self, name, data, source):
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert not data.startswith((b'\x7fELF', b'!<arch>\n', b'BC\xc0\xde'))
        assert Path(name).suffix not in {'.a', '.o', '.so', '.rlib', '.bc', '.exe', '.pyc'}
        data.decode('utf-8')
        if name in self.data:
            assert self.data[name] == data
            return
        self.data[name] = data
        self.members[name] = {**info(data), 'source': source}

    def file(self, path, expected=None):
        assert path.is_file() and not path.is_symlink(), str(path)
        data = path.read_bytes()
        assert expected is None or info(data)['sha256'] == expected, str(path)
        self.add(archive_path(path), data, str(path))

    def text_tree(self, root):
        for path in sorted(root.rglob('*')):
            if path.is_file() and path.suffix in TEXT and '__pycache__' not in path.parts:
                self.file(path)


def validation_index(package, build):
    verified = dict(build['source_sha256'])
    retained = {}

    def retain(path, expected=None):
        package.file(path, expected)
        retained[str(path)] = info(path.read_bytes())
        return load(path) if path.suffix == '.json' else path.read_text()

    def committed(hashes):
        for name, value in hashes.items():
            expected = value['sha256'] if isinstance(value, dict) else value
            assert info(package.data['source/' + name])['sha256'] == expected, name
            assert name not in verified or verified[name] == expected
            verified[name] = expected

    def count(log):
        matches = re.findall(r'Passed\s+(\d+)[^\n]*checks|(\d+) import checks passed', log)
        assert matches
        return int(next(value for value in matches[-1] if value))

    normal_root, lto_root, rust_root, inventory_root = VALIDATORS
    normal = retain(normal_root / 'receipt.json')
    assert normal['git_head_at_freeze'] == COMMIT and normal['all_passed']
    assert normal['compiler_sha256'] == build['artifacts']['imre']['sha256']
    assert normal['runtime_sha256'] == build['artifacts']['libimre_runtime.a']['sha256']
    assert normal['asan_runtime_sha256'] == build['artifacts']['libimre_runtime_asan.a']['sha256']
    committed(retain(Path(normal['source_manifest']), normal['source_manifest_sha256']))
    harness = retain(Path(normal['harness_manifest']), normal['harness_manifest_sha256'])
    files = {name: item for name, item in harness.items() if 'sha256' in item}
    committed(files)
    for name, item in files.items():
        retain(normal_root / 'inputs' / name, item['sha256'])
    totals = {'normal': 0, 'asan': 0}
    for suite in normal['suites']:
        assert suite['ok']
        assert count(retain(Path(suite['log']), suite['log_sha256'])) == suite['checks']
        totals[suite['id'].split('-')[0]] += suite['checks']
    assert totals == {'normal': 1113, 'asan': 1435}
    assert totals == {name: item['checks'] for name, item in normal['groups'].items()}
    corrections = retain(Path(normal['setup_correction']['details']))
    assert corrections['all_content_hashes_unchanged']
    assert normal['setup_correction']['affected_invocations_retried'] == 23
    preflight = retain(Path(normal['sanitizer_preflight']))
    assert preflight['leak_reported'] and preflight['returncode'] != 0
    assert sha(normal_root / 'leak_preflight.c') == preflight['source_sha256']

    lto = retain(lto_root / 'test-receipt.json')
    assert lto['source_head'] == COMMIT and lto['passed'] and lto['artifacts_and_sources_verified_unchanged']
    assert lto['suite_checks'] == 851 and lto['cli_checks'] == 10 and lto['total_checks'] == 861
    lto_source = retain(Path(lto['source_receipt']))
    assert lto_source['source_head'] == COMMIT
    committed(lto_source['files'])
    for name, expected in lto_source['files'].items():
        retain(Path(lto_source['suite_root']) / name, expected)
    for run in lto['runs'].values():
        assert run['exit_code'] == 0
        assert count(retain(Path(run['log']), run['log_sha256'])) == run['checks']
    assert sum(run['checks'] for run in lto['runs'].values()) == 861
    for name in ('imre', 'libimre_runtime_lto.a'):
        recorded = lto['artifacts'][str(TOOLS / name)]
        expected = recorded['sha256'] if isinstance(recorded, dict) else recorded
        assert expected == build['artifacts'][name]['sha256']

    rust = retain(rust_root / 'receipt.json')
    assert rust['source_commit'] == COMMIT and rust['status'] == 'passed'
    assert rust['rust_unit_tests'] == 81
    assert rust['compiler_sha256'] == build['artifacts']['imre']['sha256']
    assert rust['build_record_sha256'] == sha(TOOLS / 'build-record.json')
    committed(rust['source_sha256'])
    for item in rust['logs'].values():
        retain(Path(item['path']), item['sha256'])

    inventory = retain(inventory_root / 'receipt.json')
    assert inventory['source_commit'] == inventory['git_head_after'] == COMMIT
    assert not inventory['git_status_before'] and not inventory['git_status_after']
    assert inventory['input_hashes_unchanged'] and inventory['compile_returncode'] == 0
    assert inventory['cases'] == 204 and inventory['device_checks'] == 1 and inventory['total_native_executions'] == 205
    assert inventory['compiler_sha256'] == build['artifacts']['imre']['sha256']
    assert inventory['runtime_asan_sha256'] == build['artifacts']['libimre_runtime_asan.a']['sha256']
    assert inventory['runtime_asan_rustflags'] == build['runtime_asan_rustflags']
    for when in ('before', 'after'):
        execution = inventory['execution_' + when]
        assert execution['tracer_pid'] == 0
        assert execution['asan_options'] == 'detect_leaks=1:halt_on_error=1:abort_on_error=1'
        assert execution['lsan_options'] == 'exitcode=23:abort_on_error=1'
    for name, item in inventory['artifacts'].items():
        if name != 'binary':
            retain(Path(item['path']), item['sha256'])
    inventory_sources = load(inventory_root / 'source-manifest.json')
    committed(inventory_sources)
    for item in inventory_sources.values():
        retain(Path(item['snapshot']), item['sha256'])

    for directory in VALIDATORS:
        package.text_tree(directory)
        for path in directory.rglob('*'):
            if path.is_file() and path.suffix in TEXT and '__pycache__' not in path.parts:
                retained[str(path)] = info(path.read_bytes())
    probe_path = AUDIT / 'nan-contract/results.json'
    probes = load(probe_path)
    assert len(probes) == 9
    assert all(item['cpython_status'] == 0 and item['imre_status'] != 0 for item in probes.values())
    dead = load(DEAD_PROBES / 'receipt.json')
    assert dead['source_commit'] == COMMIT and dead['checks'] == 4 and dead['all_rejected']
    assert dead['compiler_sha256'] == build['artifacts']['imre']['sha256']
    for item in dead['records']:
        assert item['returncode'] == 1 and not item['native_artifact_exists']
        assert not item['stdout'] and 'Imre:' in item['stderr']
        assert sha(Path(item['source'])) == item['source_sha256']
    return {
        'schema': 'imre-four-feature-validation-index-v1', 'status': 'passed',
        'source_commit': COMMIT, 'build_record_sha256': sha(TOOLS / 'build-record.json'),
        'native_checks': {**totals, 'thinlto': 851, 'thinlto_cli': 10},
        'total_native_semantic_and_cli_checks': 3409, 'rust_unit_tests': 81,
        'inventory_asan': {'cases': 204, 'device_checks': 1, 'native_executions': 205,
                           'receipt': str(inventory_root / 'receipt.json')},
        'outside_subset_probes': {
            'count': 9, 'included_in_native_semantic_suite_counts': False,
            'description': 'NaN list/tuple membership and comparisons, list count/index, and float identity remain outside the admitted subset; all nine probes were rejected.',
            'results': {'path': str(probe_path), **info(probe_path.read_bytes())},
            'source_sha256': {str(AUDIT / 'nan-contract' / (name + '.py')):
                              sha(AUDIT / 'nan-contract' / (name + '.py')) for name in probes},
        },
        'supplemental_dead_code_probes': {
            'count': 4, 'included_in_native_semantic_suite_counts': False,
            'description': 'The exact checker rejects wrong return, assignment, operand and argument types after an earlier return in an unused function.',
            'receipt': {'path': str(DEAD_PROBES / 'receipt.json'),
                        **info((DEAD_PROBES / 'receipt.json').read_bytes())},
        },
        'receipts': {str(directory): str(directory / ('test-receipt.json' if directory == lto_root else 'receipt.json'))
                     for directory in VALIDATORS},
        'setup_correction': normal['setup_correction'],
        'retained_failed_setup_attempts': 'Initial normal/ASan logs and results are retained alongside successful retry logs. Writable fixture permissions were restored without changing bytes; 23 affected invocations were retried. No benchmark samples were rerun.',
        'sanitizer_limit': 'Application LLVM and the custom Imre runtime were instrumented with AddressSanitizer, with leak detection enabled; the prebuilt Rust standard library was not rebuilt with sanitizer instrumentation. The intentional-leak preflight confirms LeakSanitizer activation.',
        'runtime_provenance_limit': 'The compiler was built from the final clean commit. Previously built runtime archives reconcile to that commit through actual runtime/Cargo/toolchain source hashes; the ordinary archive additionally matches the final workspace output. No claim is made that all archives were freshly rebuilt after the final commit.',
        'verified_committed_sources': verified, 'retained_evidence_files': retained,
    }


def main():
    build = load(TOOLS / 'build-record.json')
    session = load(RUNS / 'session.json')
    audit = load(AUDIT / 'audit.json')
    assert build['git_head'] == session['source_commit'] == COMMIT
    assert build['compiled_sources_match_commit'] and not build['git_status']
    assert audit['passed']
    for item in build['artifacts'].values():
        assert sha(Path(item['path'])) == item['sha256']
    package = Package()
    names = subprocess.check_output(['git', '-C', str(ROOT), 'ls-tree', '-r', '--name-only', COMMIT], text=True).splitlines()
    names = [name for name in names if not name.startswith('benchmarks/results/')]
    data = subprocess.check_output(['git', '-C', str(ROOT), 'archive', '--format=tar', COMMIT, '--', *names])
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:') as archive:
        for item in archive:
            if item.isdir():
                continue
            assert item.isfile()
            package.add('source/' + item.name, archive.extractfile(item).read(), 'git:' + COMMIT + ':' + item.name)
    assert {name[7:] for name in package.data} == set(names)
    for name, expected in build['source_sha256'].items():
        assert info(package.data['source/' + name])['sha256'] == expected
        assert build['source_contents'][name].encode() == package.data['source/' + name]
    validation = validation_index(package, build)
    write(HERE / 'validation.json', validation)

    prepared = load(HERE / 'prepared-manifest.json')
    baseline = {'schema': 'imre-sequence-baseline-capture-v1', 'modes': {}}
    keys = ('label', 'case', 'expected_stdout', 'expected_file_inventory', 'expected_changed_files',
            'stock_rows', 'stock_skus', 'batches', 'request_rows', 'positive_requests')
    for mode in ('normal', 'lto'):
        previous_path = Path(prepared[mode]['comparison'])
        assert sha(previous_path) == prepared[mode]['comparison_sha256']
        previous = load(previous_path)
        current = load(RUNS / (mode + '.json'))
        assert current['sources'] == previous['sources'] and len(current['sources']) == 6
        baseline['modes'][mode] = {
            'original_record': prepared[mode]['comparison'],
            'original_record_sha256': prepared[mode]['comparison_sha256'],
            'published_record': prepared[mode]['published_record'],
            'published_record_sha256': prepared[mode]['published_record_sha256'],
            'published_reference': 'https://github.com/viarius-experiments/imre/blob/4ecd8a28456a3f25b3af92a33dd24d3e6f3cf770/benchmarks/results/2026-10-18-sequence-access-' + mode + '.json.gz',
            'git': previous['git'], 'sources': previous['sources'],
            'tool_paths': prepared[mode]['paths'], 'sha256': prepared[mode]['sha256'],
            'workloads': {'inventory': [{key: row[key] for key in keys} for row in previous['workloads']['inventory']]},
        }
        for record in (previous, current):
            command = record['method']['compile_commands']['inventory']
            package.file(Path(command[command.index('--emit-llvm') + 1]))
        for suffix in ('.json', '.log'):
            package.file(RUNS / (mode + suffix))
        package.file(Path(prepared[mode]['rust_build_record']), prepared[mode]['rust_build_record_sha256'])
    write(HERE / 'baseline-manifest.json', baseline)
    package.file(Path(prepared['preserved_tools']['path']), prepared['preserved_tools']['sha256'])
    audited_summary = HERE / 'summary-audited-input.json'
    expected_summary = audit['inputs'][str(HERE / 'summary.json')]
    if not audited_summary.exists():
        original_summary = (HERE / 'summary.json').read_bytes()
        assert info(original_summary) == expected_summary
        audited_summary.write_bytes(original_summary)
    assert info(audited_summary.read_bytes()) == expected_summary
    summary = load(audited_summary)
    summary['status'] = 'passed'
    summary['statistics_method'] = audit['statistical_method']
    summary['independent_audit_checks'] = audit['checks']
    summary['independent_audit_input_summary'] = {
        'path': str(audited_summary), **expected_summary,
        'note': 'Exact provisional summary verified by the independent audit, retained before publication added its audited quartiles and provenance.',
    }
    for mode in ('normal', 'lto'):
        for row, verified in zip(summary['modes'][mode]['rows'], audit['modes'][mode]['rows'], strict=True):
            assert row['workload'] == verified['workload']
            row['median_ms'] = verified['median_ms']
            row['statistics_ns'] = verified['statistics']
            row['quartiles_ms'] = {
                engine: {'q1': values['p25_ns'] / 1e6, 'median': values['median_ns'] / 1e6,
                         'q3': values['p75_ns'] / 1e6}
                for engine, values in verified['statistics'].items()
            }
            row['ratios_of_medians'] = verified['ratios_of_medians']
            row['cpython_over_imre'] = verified['cpython_speedup']
            row['imre_over_rust'] = verified['ratios_of_medians']['imre_over_rust_bigint']
            row['imre_over_previous'] = verified['ratios_of_medians']['imre_over_baseline']
            row['imre_change_percent'] = verified['new_vs_baseline_time_change_percent']
            row['iqr_overlap_vs_previous'] = verified['iqr_overlap_vs_previous']
            row['iqr_overlap_vs_rust'] = verified['iqr_overlap_vs_rust']
        summary['modes'][mode]['imre_change_percent_range'] = [
            min(row['imre_change_percent'] for row in summary['modes'][mode]['rows']),
            max(row['imre_change_percent'] for row in summary['modes'][mode]['rows']),
        ]
    summary['independent_audit_sha256'] = sha(AUDIT / 'audit.json')
    summary['validation_sha256'] = sha(HERE / 'validation.json')
    summary['provenance_note'] = 'Measurements use the clean source commit above; report and packaging files were produced afterward and are not claimed to belong to that measured commit.'
    write(HERE / 'summary.json', summary)
    package.text_tree(TOOLS)
    package.text_tree(Path('/tmp/imre-integrated-runtimes'))
    package.text_tree(HERE)
    package.text_tree(AUDIT)
    package.text_tree(DEAD_PROBES)
    package.file(RUNS / 'session.json')
    package.file(LOCAL / 'sequence-access-final-launch.py')
    assert Path(session['prior_launcher']['path']) == LOCAL / 'sequence-access-final-launch.py'
    assert sha(Path(session['prior_launcher']['path'])) == session['prior_launcher']['sha256']
    guide = f'''# Four-feature experiment evidence

Measurements use clean source commit {COMMIT}. Exact UTC timestamps are in the
records. `source/` is that Git tree, excluding historical benchmark results.
`retained/` contains current raw samples, captured baseline workload/source
manifests, generated LLVM, tool-build provenance, all validator source snapshots,
logs, setup-failure/retry receipts, and audit/packaging scripts.

All six inventory source files are unchanged from the sequence milestone. The
comparison uses the preserved sequence binary directly; there is no separate
source-migration/control experiment. Native binaries, runtime archives, Python,
toolchains, caches, and historical raw timing/result archives are excluded.
Original artifact paths/hashes and baseline publication references are retained.

The final compiler was built at the measured commit. Earlier runtime archives
were reconciled by actual runtime/Cargo/toolchain source hashes to that commit;
the ordinary archive also equals the final workspace build output. ASan covers
the application LLVM and custom runtime, with leak checking; the prebuilt Rust
standard library was not rebuilt with ASan. Initial fixture-permission setup
failures and successful retries are retained; no timed samples were repeated.

The portable audit verifies all archived bytes and recomputes sample statistics,
balanced orders, output/filesystem oracles and saved validation joins. It needs
only these text records and Python, not the original machine or native artifacts.
Report/packaging source is generated after the measured commit and kept separate
from its captured source tree. A live rerun would still need compatible external
compiler/runtime/interpreter/reference artifacts.
'''
    package.add('EVIDENCE.md', guide.encode(), 'generated evidence guide')
    inner = {'schema': 'imre-four-feature-evidence-v1', 'source_commit': COMMIT,
             'members': package.members}
    manifest_data = (json.dumps(inner, indent=2) + '\n').encode()
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode='w:', format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted({**package.data, 'manifest.json': manifest_data}.items()):
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mode = 0o644
            item.uid = item.gid = item.mtime = 0
            archive.addfile(item, io.BytesIO(data))
    STAGE.mkdir(exist_ok=True)
    companions = {}

    def publish(suffix, data, original=None):
        name = PREFIX + '-' + suffix
        (STAGE / name).write_bytes(data)
        companions[name] = info(data)
        if original is not None:
            companions[name]['uncompressed'] = info(original)

    publish('evidence.tar.gz', compressed(output.getvalue()))
    for suffix, path in (
        ('build.json', TOOLS / 'build-record.json'), ('session.json', RUNS / 'session.json'),
        ('audit.json', AUDIT / 'audit.json'), ('summary.json', HERE / 'summary.json'),
        ('validation.json', HERE / 'validation.json'),
    ):
        publish(suffix, path.read_bytes())
    for mode in ('normal', 'lto'):
        raw = (RUNS / (mode + '.json')).read_bytes()
        publish(mode + '.json.gz', compressed(raw), raw)
    report_name = PREFIX + '.md'
    report_data = (ROOT / 'benchmarks/results' / report_name).read_bytes()
    (STAGE / report_name).write_bytes(report_data)
    companions[report_name] = {
        **info(report_data),
        'provenance': 'Report generated after the measured commit; this is a separate content hash, not a claim that the report belonged to that source tree.',
    }
    outer = {**inner, 'archive_manifest': info(manifest_data), 'companions': companions}
    write(STAGE / (PREFIX + '-evidence-manifest.json'), outer)
    print(json.dumps({'stage': str(STAGE), 'members': len(package.members),
                      'companions': len(companions), 'archive_bytes': companions[PREFIX + '-evidence.tar.gz']['bytes'],
                      'validation_checks': validation['native_checks']}, indent=2))


if __name__ == '__main__':
    main()
