"""Print or execute unchanged-inventory comparisons after the final tool freeze."""

import argparse
import hashlib
import importlib.util
import json
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/dev-user/code/oss/imre')
HERE = Path(__file__).resolve().parent
MANIFEST = HERE / 'prepared-manifest.json'
SPEC = importlib.util.spec_from_file_location(
    'sequence_launcher', ROOT / 'benchmarks/local/sequence-access-final-launch.py'
)
PRIOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PRIOR)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def baseline_guard():
    prepared = json.loads(MANIFEST.read_text())
    sources = {
        str(path.relative_to(ROOT / 'examples')): sha(path)
        for path in sorted((ROOT / 'examples/inventory_reconciliation').rglob('*.py'))
    }
    identities = {}
    for mode in ('normal', 'lto'):
        value = prepared[mode]
        if sources != value['sources']:
            raise RuntimeError('inventory source changed from the preserved sequence milestone')
        paths = {
            **value['paths'],
            'comparison': value['comparison'],
            'published_record': value['published_record'],
            'rust_build_record': value['rust_build_record'],
        }
        expected = {
            **value['sha256'],
            'comparison': value['comparison_sha256'],
            'published_record': value['published_record_sha256'],
            'rust_build_record': value['rust_build_record_sha256'],
        }
        current = {key: sha(path) for key, path in paths.items()}
        if current != expected:
            raise RuntimeError('preserved comparison or tool changed: ' + mode)
        identities[mode] = current
    if sha(prepared['preserved_tools']['path']) != prepared['preserved_tools']['sha256']:
        raise RuntimeError('preserved sequence build record changed')
    return {'sources': sources, 'sha256': identities, 'manifest_sha256': sha(MANIFEST)}


def command_for(mode, tools, output_dir):
    prepared = json.loads(MANIFEST.read_text())[mode]
    paths = prepared['paths']
    command = [
        sys.executable, '-u', str(ROOT / 'benchmarks/inventory_benchmark.py'),
        '--compiler', str(tools / 'imre'),
        '--runtime', str(tools / ('libimre_runtime_lto.a' if mode == 'lto' else 'libimre_runtime.a')),
        '--imre-build-record', str(tools / 'build-record.json'),
        '--rust-bigint', paths['rust_bigint'],
        '--rust-build-record', prepared['rust_build_record'],
        '--inventory-baseline', paths['inventory_binary'],
        '--inventory-baseline-record', prepared['comparison'],
        '--python', paths['python'], '--clang', paths['clang'],
        '--target', 'x86_64-unknown-linux-gnu',
        '--samples', '48', '--warmups', '2', '--cpu', '0',
        '--output', str(output_dir / (mode + '.json')),
        '--artifact-dir', str(output_dir / mode),
    ]
    if mode == 'lto':
        command += ['--lto-linker', paths['lto_linker']]
    return command


def cache_state(python):
    return json.loads(subprocess.check_output([
        python, '-I', '-c', PRIOR.CACHE_PROBE,
        str(ROOT / 'examples/inventory_reconciliation'),
    ], cwd=ROOT, text=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tools', required=True, type=Path)
    parser.add_argument('--expected-head')
    parser.add_argument('--output-dir', type=Path,
                        default=ROOT / 'benchmarks/local/four-feature-inventory-regression')
    parser.add_argument('--execute', action='store_true',
                        help='run only after the parent confirms the tool freeze and heavy-work stop')
    args = parser.parse_args()
    tools, output_dir = args.tools.resolve(), args.output_dir.resolve()
    commands = {mode: command_for(mode, tools, output_dir) for mode in ('normal', 'lto')}
    if not args.execute:
        for mode, command in commands.items():
            print(mode + ':\n' + shlex.join(command) + '\n')
        return
    if args.expected_head is None or len(args.expected_head) != 40:
        parser.error('--execute requires the full --expected-head commit')
    if output_dir.exists():
        raise RuntimeError('output directory must be new; preserve all earlier evidence')
    before = PRIOR.clean_sources(tools, args.expected_head)
    baseline_before = baseline_guard()
    python = json.loads(MANIFEST.read_text())['normal']['paths']['python']
    preparation = [python, '-I', '-m', 'compileall', '-q',
                   str(ROOT / 'examples/inventory_reconciliation')]
    subprocess.run(preparation, cwd=ROOT, check=True)
    cache_before = cache_state(python)
    output_dir.mkdir(parents=True)
    session_path = output_dir / 'session.json'
    session = {
        'source_commit': args.expected_head,
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_guard_before': before,
        'baseline_guard_before': baseline_before,
        'launcher': {'path': str(Path(__file__)), 'sha256': sha(__file__),
                     'source': Path(__file__).read_text()},
        'prior_launcher': {'path': str(PRIOR.__file__), 'sha256': sha(PRIOR.__file__)},
        'cache_preparation': {'command': preparation, 'timed': False},
        'bytecode_before': cache_before,
        'runs': {},
    }

    def save():
        session_path.write_text(json.dumps(session, indent=2) + '\n')

    save()
    for mode, command in commands.items():
        if PRIOR.clean_sources(tools, args.expected_head) != before:
            raise RuntimeError('frozen sources changed before ' + mode)
        if baseline_guard() != baseline_before:
            raise RuntimeError('preserved inputs changed before ' + mode)
        log_path = output_dir / (mode + '.log')
        item = {'command': command, 'started_at_utc': datetime.now(timezone.utc).isoformat()}
        session['runs'][mode] = item
        save()
        print('Starting ' + mode, flush=True)
        with log_path.open('w') as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        item.update(returncode=result.returncode,
                    completed_at_utc=datetime.now(timezone.utc).isoformat(),
                    log_sha256=sha(log_path))
        record_path = output_dir / (mode + '.json')
        if record_path.exists():
            item['record_sha256'] = sha(record_path)
        save()
        print(log_path.read_text(), end='', flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
        if PRIOR.clean_sources(tools, args.expected_head) != before:
            raise RuntimeError('frozen sources changed during ' + mode)
        if baseline_guard() != baseline_before or cache_state(python) != cache_before:
            raise RuntimeError('preserved inputs or Python bytecode changed during ' + mode)
        old = json.loads(Path(json.loads(MANIFEST.read_text())[mode]['comparison']).read_text())
        old_command = old['method']['compile_commands']['inventory']
        old_ir = Path(old_command[old_command.index('--emit-llvm') + 1])
        current_ir = output_dir / mode / 'inventory_reconciliation.ll'
        item['generated_ir'] = {'baseline_sha256': sha(old_ir), 'current_sha256': sha(current_ir),
                                'byte_identical': old_ir.read_bytes() == current_ir.read_bytes()}
        save()
    session.update(completed_at_utc=datetime.now(timezone.utc).isoformat(),
                   source_guard_after=PRIOR.clean_sources(tools, args.expected_head),
                   baseline_guard_after=baseline_guard(), bytecode_after=cache_state(python))
    save()
    print('Saved ' + str(session_path), flush=True)


if __name__ == '__main__':
    main()
