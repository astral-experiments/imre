#!/bin/sh
export CARGO_BUILD_JOBS=4
export CARGO_HOME=/home/dev-user/.cache/relar/cargo-home
export CARGO_TARGET_DIR=/home/dev-user/.cache/relar-integrated-asan/target
export CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/shared-build
export CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST=all
export CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST=all
export RUST-Zsanitizer=address -Cforce-frame-pointers=yes='-Zsanitizer=address -Cforce-frame-pointers=yes'
unset CARGO_ENCODED_RUST-Zsanitizer=address -Cforce-frame-pointers=yes
export RUSTC_BOOTSTRAP=1
relar_command=$1
shift
exec cargo +ohm -Zohm-defaults=no "$relar_command" --profile relar-integrated-asan --config 'profile.relar-integrated-asan.inherits="release"' "$@"
