def unused() -> None:
    value: int = 0
    return
    value = "wrong"

print(0)
