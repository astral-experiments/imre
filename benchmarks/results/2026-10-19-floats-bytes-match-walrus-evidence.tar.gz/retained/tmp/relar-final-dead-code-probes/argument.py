def integer(value: int) -> int:
    return value

def unused() -> None:
    return
    integer("wrong")

print(0)
