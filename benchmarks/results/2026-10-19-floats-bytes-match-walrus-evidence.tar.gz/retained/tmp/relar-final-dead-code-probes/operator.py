def unused() -> None:
    return
    print("wrong" - 1)

print(0)
