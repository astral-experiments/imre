def unused() -> int:
    return 0
    return "wrong"

print(0)
