from .model import Fulfillment, Inventory, Report, Request, Stock


def fulfill(request: Request, *, inventory: Inventory) -> Fulfillment:
    filled = 0
    if request.sku in inventory.remaining:
        available = inventory.remaining[request.sku]
        quantity = request.quantity
        # min is outside the native subset.
        filled = available if available < quantity else quantity  # noqa: FURB136
        inventory.remaining[request.sku] = available - filled
    return Fulfillment(request, filled=filled, shortage=request.quantity - filled)


def reconcile(stocks: list[Stock], *, batches: list[list[Request]]) -> Report:
    remaining: dict[str, int] = {stock.sku: stock.quantity for stock in stocks}
    inventory = Inventory(remaining=remaining)
    positive: list[Request] = [
        request for batch in batches for request in batch if request.quantity > 0
    ]
    requested_skus: set[str] = {request.sku for request in positive}
    # A dict preserves first-request order while repeated values start at zero.
    requested: dict[str, int] = {request.sku: 0 for request in positive}
    for request in positive:
        requested[request.sku] += request.quantity
    # Eagerness and source order matter: every call mutates the same inventory.
    results: list[Fulfillment] = [
        fulfill(request, inventory=inventory) for request in positive
    ]
    request_rows = 0
    for batch in batches:
        request_rows += len(batch)
    return Report(
        stock_rows=len(stocks),
        batches=len(batches),
        request_rows=request_rows,
        results=results,
        requested=requested,
        requested_skus=requested_skus,
        remaining=remaining,
    )
