def main() -> None:
    n = float("nan")
    print(n is n)

main()
