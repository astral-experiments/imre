def main() -> None:
    n = float("nan")
    print((n,) != (n,))

main()
