def main() -> None:
    n = float("nan")
    print(n in [n])

main()
