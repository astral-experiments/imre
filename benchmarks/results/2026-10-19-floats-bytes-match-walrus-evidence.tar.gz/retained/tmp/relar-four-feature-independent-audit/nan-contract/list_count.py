def main() -> None:
    n = float("nan")
    print([n].count(n))

main()
