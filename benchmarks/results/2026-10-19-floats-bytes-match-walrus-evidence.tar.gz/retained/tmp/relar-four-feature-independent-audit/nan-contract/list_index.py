def main() -> None:
    n = float("nan")
    print([n].index(n))

main()
