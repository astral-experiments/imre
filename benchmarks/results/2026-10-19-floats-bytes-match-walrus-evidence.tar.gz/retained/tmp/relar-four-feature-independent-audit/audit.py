"""Independently audit saved four-feature inventory results without running benchmarks.

Generic oracle/outcome/Fraction-statistics functions are retained from the prior
sequence audit; milestone provenance and session checks are specific to this run.
"""
import argparse
import base64
import gzip
import hashlib
import itertools
import json
import math
import runpy
import stat
import struct
import subprocess
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

APPLICATION = "97cb1000565035162c31e6e455d207cf65b54993"
BASELINE = "006e24367b87ecc331f31605640a7e53d3bdeaa6"
COMPILER = "44bde4d0cf6b2056aff1f29643d84d285c56654a91470f941b31f99fb6db2e77"
ENGINES = {"inventory": ("cpython", "relar", "rust_bigint", "baseline")}
COUNTS = {"inventory": 6}
CHECKS = 0
FILES = {}
REUSED_HELPER_SHA256 = "7adb295db7fd4a739ab84ab783763d8e00bf299856df303c5bcf0f73f8a84ee7"


def require(condition, message):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise AssertionError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_info(path):
    path = Path(path).resolve(strict=True)
    stat = path.stat()
    signature = (stat.st_size, stat.st_mtime_ns)
    if path not in FILES:
        with path.open("rb") as stream:
            FILES[path] = signature, hashlib.file_digest(stream, "sha256").hexdigest()
    require(FILES[path][0] == signature, f"file changed during audit: {path}")
    return {"sha256": FILES[path][1], "bytes": signature[0]}


def verify_file(path, expected, size=None):
    result = file_info(path)
    require(result["sha256"] == expected, f"file hash differs: {path}")
    if size is not None:
        require(result["bytes"] == size, f"file size differs: {path}")
    return result


def verify_committed(root, revision, hashes):
    names = list(hashes)
    data = subprocess.run(
        ["git", "-C", str(root), "cat-file", "--batch"],
        input="".join(f"{revision}:{name}\n" for name in names).encode(),
        capture_output=True,
        check=True,
    ).stdout
    offset = 0
    for name in names:
        end = data.index(b"\n", offset)
        header = data[offset:end].split()
        require(
            len(header) == 3 and header[1] == b"blob",
            f"missing committed file: {revision}:{name}",
        )
        length = int(header[2])
        offset = end + 1
        require(
            digest(data[offset : offset + length]) == hashes[name],
            f"committed source differs: {revision}:{name}",
        )
        offset += length
        require(data[offset : offset + 1] == b"\n", "invalid Git batch delimiter")
        offset += 1
    require(offset == len(data), "unexpected Git batch remainder")


def decode_files(encoded):
    result = {}
    for name, spec in encoded.items():
        data = base64.b64decode(spec["base64"], validate=True)
        require(
            digest(data) == spec["sha256"] and len(data) == spec["bytes"],
            "encoded file differs: " + name,
        )
        result[name] = data
    return result


def inventory(files):
    return {
        name: {"sha256": digest(data), "bytes": len(data)}
        for name, data in sorted(files.items())
    }


def result_matches(result, expected, label):
    output = expected["stdout"].encode()
    require(result["returncode"] == expected["returncode"], label + ": status")
    require(
        result["stdout_sha256"] == digest(output)
        and result["stdout_bytes"] == len(output),
        label + ": full stdout identity",
    )
    if expected.get("error_category") is None:
        require(result["stderr"] == "", label + ": unexpected stderr")
    else:
        lines = result["stderr"].strip().splitlines()
        category = expected["error_category"]
        require(
            bool(lines)
            and (lines[-1] == category or lines[-1].startswith(category + ":")),
            label + ": error category",
        )
        if expected.get("error_message") is not None:
            require(
                lines[-1] == category + ": " + expected["error_message"],
                label + ": normalized error message",
            )
    if "files" in expected:
        require(
            result["files"] == inventory(expected["files"]),
            label + ": complete file inventory",
        )
        require(
            result["directories"] == expected["directories"],
            label + ": complete directory inventory",
        )


def quantile(values, numerator, denominator):
    ordered = sorted(values)
    position = Fraction((len(ordered) - 1) * numerator, denominator)
    left = position.numerator // position.denominator
    right = min(left + 1, len(ordered) - 1)
    return Fraction(ordered[left]) + (ordered[right] - ordered[left]) * (
        position - left
    )


def statistics(values):
    return {
        "median_ns": float(quantile(values, 1, 2)),
        "min_ns": min(values),
        "max_ns": max(values),
        "p25_ns": float(quantile(values, 1, 4)),
        "p75_ns": float(quantile(values, 3, 4)),
    }


def close(actual, expected, label):
    require(math.isclose(actual, expected, rel_tol=2e-13, abs_tol=1e-12), label)


def flag(command, name):
    return command[command.index(name) + 1]


def path_at(root, value):
    value = Path(value)
    return value if value.is_absolute() else root / value


def correctness(record, validator, engines=ENGINES["inventory"]):
    inv = record["validation"]["inventory"]
    expected_cases = validator["cases"]()
    require(
        inv["cases"] == len(inv["records"]) == len(expected_cases) == 204,
        "inventory oracle count",
    )
    require(inv["engines"] == list(engines), "inventory validation engines")
    success = 0
    for item, case in zip(inv["records"], expected_cases):
        require(
            item["case"] == validator["case_record"](case),
            "inventory oracle captured case",
        )
        expected = validator["oracle"](case)
        success += expected["returncode"] == 0
        require(
            item["expected"] == {k: v for k, v in expected.items() if k != "files"},
            "inventory expected status/output",
        )
        require(
            decode_files(item["expected_files"]) == expected["files"],
            "inventory oracle expected file bytes",
        )
        require(
            set(item["engines"]) == set(engines),
            "inventory oracle result coverage",
        )
        for engine, result in item["engines"].items():
            result_matches(
                result, expected, "inventory oracle/" + case.label + "/" + engine
            )
    require(
        success == inv["successful"] == 139 and inv["terminal_errors"] == 65,
        "inventory oracle totals",
    )
    device = inv["device_check"]
    require(
        device["case"] == "terminal-report-device-error"
        and set(device["engines"]) == set(engines),
        "device coverage",
    )
    device_case = validator["case"](
        "terminal-report-device-error", [("a", 4)], [[("a", 2)]]
    )
    expected = {
        "returncode": 1,
        "stdout": "",
        "error_category": "OSError",
        "error_message": "report: cannot write",
        "files": device_case.files,
        "directories": [],
    }
    for engine, result in device["engines"].items():
        result_matches(result, expected, "device/" + engine)
    return {
        "inventory": 204 * len(engines),
        "inventory_device": len(engines),
    }


def audit_workloads(
    record, original_inventory, validator, selected_engines, current_engine
):
    rows = []
    ordering = {}
    measured = warmups = gates = 0
    original_cases = {
        w["label"]: w for w in original_inventory["workloads"]["inventory"]
    }
    for group, engines in {"inventory": selected_engines}.items():
        workloads = record["workloads"][group]
        require(len(workloads) == COUNTS[group], "workload count: " + group)
        cycle = [list(order) for order in itertools.permutations(engines)]
        require(
            record["method"]["order_cycles"][group] == cycle,
            "complete permutation cycle: " + group,
        )
        for workload in workloads:
            label = group + "/" + workload["label"]
            expected = {"returncode": 0, "stdout": workload["expected_stdout"]}
            if group == "inventory":
                original = original_cases[workload["label"]]
                for key in (
                    "case",
                    "expected_stdout",
                    "expected_file_inventory",
                    "expected_changed_files",
                    "stock_rows",
                    "stock_skus",
                    "batches",
                    "request_rows",
                    "positive_requests",
                ):
                    require(
                        workload[key] == original[key],
                        label + ": original captured inventory differs: " + key,
                    )
                case = validator["case_from_record"](workload["case"])
                oracle = validator["oracle"](case)
                require(
                    oracle["returncode"] == 0
                    and oracle["stdout"] == workload["expected_stdout"],
                    label + ": independent oracle",
                )
                require(
                    workload["expected_file_inventory"] == inventory(oracle["files"]),
                    label + ": expected complete inventory",
                )
                changed = {
                    name: data
                    for name, data in oracle["files"].items()
                    if case.files.get(name) != data
                }
                require(
                    decode_files(workload["expected_changed_files"]) == changed,
                    label + ": complete changed bytes",
                )
                stocks = validator["parse"](case.files["stock.txt"].decode(), "stock")
                batches = validator["parse"](
                    case.files["orders.txt"].decode(), "orders"
                )
                require(
                    workload["stock_rows"] == len(stocks)
                    and workload["stock_skus"] == len(dict(stocks))
                    and workload["batches"] == len(batches),
                    label + ": shape metadata",
                )
                require(
                    workload["request_rows"] == sum(map(len, batches))
                    and workload["positive_requests"]
                    == sum(quantity > 0 for batch in batches for _, quantity in batch),
                    label + ": request metadata",
                )
                expected.update(
                    files=oracle["files"], directories=oracle["directories"]
                )
                require(
                    set(workload["gates"]) == set(engines),
                    label + ": correctness gates",
                )
                for engine, result in workload["gates"].items():
                    result_matches(result, expected, label + "/gate/" + engine)
                    gates += 1
            positions = Counter()
            adjacent = Counter()
            orders = Counter()
            for phase, count in (("warmups", 2), ("samples", 48)):
                require(
                    len(workload[phase]) == count,
                    label + ": missing/discarded saved round",
                )
                for index, sample in enumerate(workload[phase]):
                    require(
                        sample["index"] == index
                        and sample["order"] == cycle[index % len(cycle)],
                        label + ": round order/index",
                    )
                    require(
                        set(sample) == {*engines, "index", "order"},
                        label + ": round engine coverage",
                    )
                    for engine in engines:
                        require(
                            type(sample[engine]["elapsed_ns"]) is int
                            and sample[engine]["elapsed_ns"] > 0,
                            label + ": duration",
                        )
                        result_matches(
                            sample[engine], expected, label + "/" + phase + "/" + engine
                        )
                    if phase == "samples":
                        measured += len(engines)
                        positions.update(
                            (engine, position)
                            for position, engine in enumerate(sample["order"])
                        )
                        adjacent.update(zip(sample["order"], sample["order"][1:]))
                        orders[tuple(sample["order"])] += 1
                    else:
                        warmups += len(engines)
            require(
                set(positions) == set(itertools.product(engines, range(len(engines))))
                and set(positions.values()) == {48 // len(engines)},
                label + ": position balance",
            )
            require(
                set(adjacent) == set(itertools.permutations(engines, 2))
                and set(adjacent.values()) == {48 // len(engines)},
                label + ": within-round predecessor balance",
            )
            require(
                len(orders) == len(cycle)
                and set(orders.values()) == {48 // len(cycle)},
                label + ": permutation balance",
            )
            ordering[label] = {
                "positions": {f"{a}@{b}": n for (a, b), n in sorted(positions.items())},
                "within_round_predecessors": {
                    f"{a}->{b}": n for (a, b), n in sorted(adjacent.items())
                },
                "each_permutation_count": 48 // len(cycle),
            }
            computed = {
                engine: statistics(
                    [sample[engine]["elapsed_ns"] for sample in workload["samples"]]
                )
                for engine in engines
            }
            for engine, values in computed.items():
                for key, value in values.items():
                    close(
                        workload["summary"][engine][key.replace("_ns", "_seconds")],
                        value / 1e9,
                        label + ": statistic " + engine + "/" + key,
                    )
            medians = {
                engine: values["median_ns"] for engine, values in computed.items()
            }
            ratios = {
                a + "_over_" + b: medians[a] / medians[b]
                for a, b in itertools.permutations(engines, 2)
            }
            expected_ratios = set(ratios)
            require(
                set(workload["summary"]["ratios_of_medians"]) == expected_ratios,
                label + ": summary ratio coverage",
            )
            for name, reported in workload["summary"]["ratios_of_medians"].items():
                close(reported, ratios[name], label + ": ratio " + name)
            row = {
                "group": group,
                "workload": workload["label"],
                "statistics": computed,
                "median_ms": {name: value / 1e6 for name, value in medians.items()},
                "ratios_of_medians": ratios,
            }
            row["new_vs_baseline_time_change_percent"] = 100 * (
                medians[current_engine] / medians["baseline"] - 1
            )
            rows.append(row)
    require(
        measured == (6 * len(selected_engines)) * 48
        and warmups == (6 * len(selected_engines)) * 2
        and gates == 6 * len(selected_engines),
        "total process accounting",
    )
    return rows, ordering, measured, warmups, gates


def bytecode_session(root, session, records):
    require(
        session["source_commit"] == APPLICATION
        and not session["git_status_before"]
        and not session["git_status_after"],
        "session clean source identity",
    )
    before, after = session["bytecode_before"], session["bytecode_after"]
    require(before == after, "bytecode changed during timing")
    require(
        before["python"] == records[0]["tools"]["cpython"]["version"]
        and before["cache_tag"] == "cpython-314",
        "bytecode Python identity",
    )
    require(
        before["pycache_prefix"] is None and before["dont_write_bytecode"] is False,
        "bytecode policy",
    )
    require(
        len(before["files"]) == len(records[0]["sources"]) == 6,
        "bytecode source coverage",
    )
    for source, item in before["files"].items():
        path = Path(source)
        relative = str(path.relative_to(root / "examples"))
        require(
            item["source_sha256"] == records[0]["sources"][relative],
            "bytecode source identity",
        )
        verify_file(path, item["source_sha256"])
        require(
            path.stat().st_mtime_ns == item["source_mtime_ns"], "bytecode source mtime"
        )
        verify_file(item["cache_path"], item["cache_sha256"], item["cache_bytes"])
        data = Path(item["cache_path"]).read_bytes()
        require(data[:4].hex() == before["magic"], "bytecode magic")
        flags = int.from_bytes(data[4:8], "little")
        require(
            flags == item["flags"] == 0 and item["valid_header"] is True,
            "timestamp cache header mode",
        )
        timestamp, size = struct.unpack("<II", data[8:16])
        require(
            timestamp == ((item["source_mtime_ns"] // 1_000_000_000) & 0xFFFFFFFF)
            and size == (path.stat().st_size & 0xFFFFFFFF),
            "bytecode current source header",
        )
    require(
        session["started_at_utc"]
        <= session["runs"]["normal"]["started_at_utc"]
        <= session["runs"]["normal"]["completed_at_utc"]
        <= session["runs"]["lto"]["started_at_utc"]
        <= session["runs"]["lto"]["completed_at_utc"]
        <= session["completed_at_utc"],
        "session mode ordering",
    )
    return {
        "source_and_cache_files": 6,
        "before_after_identical": True,
        "timestamp_headers_match_sources": True,
        "python_version": before["python"],
        "cache_magic": before["magic"],
        "runner_source_sha256": digest(session["runner_source"].encode()),
    }


def artifact_identities(root, mode, record, session):
    run = session["runs"][mode]
    command = run["command"]
    paths = {
        name: path_at(root, flag(command, option))
        for name, option in (
            ("compiler", "--compiler"),
            ("runtime", "--runtime"),
            ("relar_build_record", "--relar-build-record"),
            ("rust_bigint", "--rust-bigint"),
            ("rust_record", "--rust-build-record"),
            ("python", "--python"),
            ("inventory_baseline", "--inventory-baseline"),
            ("inventory_baseline_record", "--inventory-baseline-record"),
        )
    }
    final_tools = root / "benchmarks/local/four-feature-tools-final"
    require(paths["compiler"] == final_tools / "relar", "final compiler path")
    require(
        paths["runtime"]
        == final_tools
        / ("librelar_runtime_lto.a" if mode == "lto" else "librelar_runtime.a"),
        "final runtime path",
    )
    require(
        paths["relar_build_record"] == final_tools / "build-record.json",
        "final build record path",
    )
    paths["rust_build_script"] = paths["tracked_rust_build_script"] = (
        root / "benchmarks/reference/inventory_reconciliation/build.py"
    )
    paths["guard_helpers"] = (
        root / "benchmarks/reference/dependency_planner/check_boundaries.py"
    )
    source_hashes = record["relar_build_provenance"]["source_sha256"]
    for group, compiler_command in record["method"]["compile_commands"].items():
        require(
            compiler_command[0] == str(paths["compiler"])
            and compiler_command[1] == "build",
            "compiler command identity",
        )
        paths[group + "_binary"] = Path(flag(compiler_command, "-o"))
        paths[group + "_ir"] = Path(flag(compiler_command, "--emit-llvm"))
        paths["clang"] = Path(flag(compiler_command, "--clang"))
        require(
            flag(compiler_command, "--runtime") == str(paths["runtime"]),
            "runtime pairing",
        )
        require(
            flag(compiler_command, "--opt-level") == "3"
            and flag(compiler_command, "--target") == "x86_64-unknown-linux-gnu",
            "application build mode",
        )
        require(
            "--sanitize" not in compiler_command, "sanitizer in measured application"
        )
        if mode == "lto":
            paths["lto_linker"] = Path(flag(compiler_command, "--lto-linker"))
            require(paths["lto_linker"].name == "ld.lld", "lexical linker flavor")
        else:
            require(
                "--lto-linker" not in compiler_command, "LTO in ordinary application"
            )
        require(
            record["compilation"][group]["returncode"] == 0
            and record["compilation"][group]["stderr"] == "",
            "application compilation failed",
        )
    committed = {}
    for name, expected in record["sha256"].items():
        if name.startswith("harness:"):
            paths[name] = root / "benchmarks" / name.split(":", 1)[1]
        if name.startswith("relar_source:"):
            relative = name.split(":", 1)[1]
            paths[name] = root / relative
            require(
                source_hashes[relative] == expected, "compiled source identity field"
            )
        require(name in paths, "unmapped artifact: " + name)
        verify_file(paths[name], expected)
        if name.startswith(("harness:", "relar_source:")) or name in (
            "guard_helpers",
            "tracked_rust_build_script",
        ):
            committed[str(paths[name].relative_to(root))] = expected
    verify_committed(root, APPLICATION, committed)
    for name, spec in record["artifacts"].items():
        require(
            file_info(paths[name])["bytes"] == spec["bytes"],
            "artifact recorded length: " + name,
        )
    for name, expected in record["sources"].items():
        verify_file(root / "examples" / name, expected)
    verify_committed(
        root,
        APPLICATION,
        {"examples/" + name: value for name, value in record["sources"].items()},
    )
    full_build = json.loads(paths["relar_build_record"].read_text())
    for key, value in record["relar_build_provenance"].items():
        require(full_build[key] == value, "embedded Relar build provenance: " + key)
    require(
        full_build["compiled_sources_match_commit"] is True,
        "compiler source commit guard",
    )
    verify_committed(root, APPLICATION, source_hashes)
    require(
        set(full_build["source_contents"]) == set(source_hashes),
        "compiler source snapshot coverage",
    )
    for name, content in full_build["source_contents"].items():
        require(
            digest(content.encode()) == source_hashes[name],
            "compiler source snapshot bytes",
        )
    for name, expected in full_build["sha256"].items():
        verify_file(root / name, expected)
    for name, build in full_build["commands"].items():
        require(build["returncode"] == 0, "runtime/compiler build failure")
        verify_file(
            paths["relar_build_record"].parent / (name + ".log"), build["log_sha256"]
        )
    require(
        full_build["runtime_lto_rustflags"] == "-Clinker-plugin-lto",
        "runtime ThinLTO flags",
    )
    original_inventory = json.loads(paths["inventory_baseline_record"].read_text())
    for key, value in record["inventory_baseline_provenance"].items():
        require(
            original_inventory[key] == value,
            "embedded inventory baseline provenance: " + key,
        )
    require(
        original_inventory["git"]["dirty"] is False,
        "original inventory timing checkout dirty",
    )
    require(
        original_inventory["sha256"]["inventory_binary"]
        == record["sha256"]["inventory_baseline"],
        "inventory baseline exact executable",
    )
    recorded_sources = {
        name: expected
        for name, expected in original_inventory["sources"].items()
        if name.startswith("inventory_reconciliation/")
    }
    current_sources = {
        name: expected
        for name, expected in record["sources"].items()
        if name.startswith("inventory_reconciliation/")
    }
    require(recorded_sources == current_sources and len(current_sources) == 6,
            "all six inventory sources are byte-identical to sequence baseline")
    require(record["inventory_baseline_source"] is None,
            "unchanged source requires no source-migration control")
    require(original_inventory["git"]["revision"] == BASELINE,
            "preserved sequence baseline commit")
    for key in ("lto", "llvm_budget", "target", "optimization_level"):
        require(
            original_inventory["options"][key] == record["options"][key],
            "inventory baseline build mode: " + key,
        )
    for key in ("clang", "lto_linker"):
        if key in record["sha256"]:
            require(
                original_inventory["sha256"][key] == record["sha256"][key],
                "inventory baseline tool mismatch: " + key,
            )
    old_command = original_inventory["method"]["compile_commands"]["inventory"]
    for key, path in (
        ("compiler", old_command[0]),
        ("runtime", flag(old_command, "--runtime")),
        ("inventory_ir", flag(old_command, "--emit-llvm")),
    ):
        verify_file(path_at(root, path), original_inventory["sha256"][key])
    old_sources = {
        "examples/" + name: value
        for name, value in original_inventory["sources"].items()
    }
    old_sources.update(
        {
            "benchmarks/" + name.split(":", 1)[1]: value
            for name, value in original_inventory["sha256"].items()
            if name.startswith("harness:")
        }
    )
    verify_committed(root, original_inventory["git"]["revision"], old_sources)
    rust = json.loads(paths["rust_record"].read_text())
    require(
        rust == record["rust_build_record"] and rust["entrypoint"] == "inventory",
        "Rust build identity",
    )
    require(
        rust["binaries"]["bigint"]["sha256"] == record["sha256"]["rust_bigint"],
        "Rust executable identity",
    )
    require(rust["sources"] == record["rust_sources"], "Rust source identity")
    previous_rust = original_inventory["rust_build_record"]
    require(
        set(rust["sources"])
        == set(previous_rust["sources"])
        == {"Cargo.toml", "Cargo.lock", "src/main.rs"},
        "complete Rust reference source set",
    )
    for name in ("Cargo.lock", "src/main.rs"):
        require(
            rust["sources"][name] == previous_rust["sources"][name],
            "Rust algorithm and dependency identity: " + name,
        )
    require(
        rust["sources"] == previous_rust["sources"]
        and rust["source_contents"] == previous_rust["source_contents"],
        "complete unchanged Rust source identity",
    )
    require(
        rust["binaries"]["bigint"]["sha256"]
        == previous_rust["binaries"]["bigint"]["sha256"],
        "preserved Rust reference binary identity",
    )
    for name in (
        "rustc_verbose",
        "cargo_version",
        "tool_sha256",
        "cargo_wrapper",
        "llvm_budget",
        "environment",
        "build_script_sha256",
    ):
        require(
            rust[name] == previous_rust[name], "Rust build controls unchanged: " + name
        )
    require(
        set(rust["source_contents"]) == set(rust["sources"]),
        "Rust source snapshot coverage",
    )
    for name, expected in rust["sources"].items():
        verify_file(
            root / "benchmarks/reference/inventory_reconciliation" / name, expected
        )
        require(
            digest(rust["source_contents"][name].encode()) == expected,
            "Rust source snapshot",
        )
    verify_committed(
        root,
        APPLICATION,
        {
            "benchmarks/reference/inventory_reconciliation/" + name: value
            for name, value in rust["sources"].items()
        },
    )
    require(
        digest(rust["build_script"].encode())
        == rust["build_script_sha256"]
        == record["sha256"]["rust_build_script"],
        "Rust build helper snapshot",
    )
    require(
        digest(rust["cargo_wrapper"]["source"].encode())
        == rust["cargo_wrapper"]["sha256"],
        "Rust wrapper snapshot",
    )
    env = rust["environment"]
    thin = mode == "lto"
    require(
        env.get("CARGO_PROFILE_RELEASE_OPT_LEVEL", "3") == "3",
        "Rust release optimization",
    )
    require(rust["llvm_budget"] == (1000 if thin else None), "Rust LLVM budget")
    require(
        env.get("CARGO_PROFILE_RELEASE_LTO") == ("thin" if thin else None),
        "Rust LTO mode",
    )
    require(
        env.get("CARGO_ENCODED_RUSTFLAGS") == (None if thin else ""),
        "Rust encoded flags",
    )
    require(
        env["RUSTFLAGS"]
        == (
            "-Cllvm-args=-import-instr-limit=1000 -Cllvm-args=-inline-threshold=1000"
            if thin
            else ""
        ),
        "Rust explicit flags",
    )
    require("host: x86_64-unknown-linux-gnu" in rust["rustc_verbose"], "Rust target")
    require(
        rust["sources"]["Cargo.toml"]
        == digest(
            (
                root / "benchmarks/reference/inventory_reconciliation/Cargo.toml"
            ).read_bytes()
        ),
        "Rust profile source",
    )
    for group, engines in ENGINES.items():
        commands = record["method"]["commands"][group]
        require(tuple(commands) == engines, "engine command ordering")
        require(
            commands["cpython"][0] == str(paths["python"])
            and commands["cpython"][1:3] == ["-I", "-c"],
            "CPython isolation command",
        )
        require(
            commands["relar"] == [str(paths[group + "_binary"])],
            "Relar executable command",
        )
        if group == "inventory":
            require(
                commands["rust_bigint"] == [str(paths["rust_bigint"])],
                "Rust executable command",
            )
            require(
                commands["baseline"] == [str(paths["inventory_baseline"])],
                "inventory baseline executable command",
            )
        else:
            require(
                commands["baseline"] == [str(paths["baseline"])],
                "control executable command",
            )
    return paths, original_inventory


def load_json(path):
    file_info(path)

    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result

    def invalid_constant(value):
        raise AssertionError("nonfinite JSON constant: " + value)

    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=invalid_constant)


def verify_build(root, path, revision):
    build = load_json(path)
    require(build["git_head"] == revision and build["git_status"] == "",
            "clean build source commit")
    require(build["compiled_sources_match_commit"] is True, "build source guard")
    require(set(build["source_contents"]) == set(build["source_sha256"]),
            "build source capture coverage")
    verify_committed(root, revision, build["source_sha256"])
    for name, content in build["source_contents"].items():
        require(digest(content.encode()) == build["source_sha256"][name],
                "build source snapshot: " + name)
    for name, expected in build["sha256"].items():
        verify_file(root / name, expected)
    for name, command in build["commands"].items():
        require(command["returncode"] == 0, "successful preserved build")
        verify_file(path.parent / (name + ".log"), command["log_sha256"])
    require(digest(build["build_script"].encode()) == build["build_script_sha256"],
            "freeze script captured bytes")
    wrapper = build["cargo_wrapper"]
    if isinstance(wrapper, dict):
        require(digest(wrapper["source"].encode()) == wrapper["sha256"],
                "freeze Cargo wrapper bytes")
    else:
        require(isinstance(wrapper, str) and wrapper.startswith("#!/bin/sh\n"),
                "legacy build captures complete Cargo wrapper source")
    return build


def final_provenance(root, records):
    directory = root / "benchmarks/local/four-feature-tools-final"
    build = verify_build(root, directory / "build-record.json", APPLICATION)
    require(file_info(directory / "build-record.json")["sha256"]
            == "71fa1c0c7ea27640a98bc9a6c71dda009803090d88b18b1ba01a6b2f2def6ef0",
            "final build record identity")
    require(file_info(directory / "relar")["sha256"] == COMPILER,
            "final integrated compiler identity")
    complete_sources = {"Cargo.toml", "Cargo.lock", "rust-toolchain.toml"}
    complete_sources.update(str(p.relative_to(root)) for p in (root / "crates").rglob("*.rs"))
    complete_sources.update(str(p.relative_to(root)) for p in (root / "crates").glob("*/Cargo.toml"))
    require(set(build["source_sha256"]) == complete_sources and len(complete_sources) == 33,
            "all 33 final compiler/runtime/Cargo inputs")
    proof = build["source_proof"]
    require(proof["final_committed_files_checked"] == 33
            and proof["all_current_files_match_git_blobs"] is True,
            "final source proof")
    copies = load_json(directory / "copies.json")
    require(copies["artifacts"] == build["artifacts"]
            and copies["git_head"] == APPLICATION
            and copies["normal_runtime_matches_final_live_build"] is True,
            "independent copy receipt")
    for name, item in build["artifacts"].items():
        path, source = Path(item["path"]), Path(item["source_path"])
        require(path == directory / name and stat.S_ISREG(path.lstat().st_mode)
                and item["regular_independent_copy"] is True and not path.samefile(source),
                "artifact is an independent regular copy: " + name)
        verify_file(path, item["sha256"], item["bytes"])
        verify_file(source, item["sha256"], item["bytes"])
    live_runtime = Path(build["artifacts"]["relar"]["source_path"]).with_name("librelar_runtime.a")
    verify_file(live_runtime, build["artifacts"]["librelar_runtime.a"]["sha256"])
    retained = build["retained_provenance"]
    for name, item in retained.items():
        require(Path(item["path"]) == directory / "provenance" / name,
                "retained provenance path")
        verify_file(item["path"], item["sha256"])
    original = load_json(Path(retained["ordinary-origin-build.json"]["path"]))
    combined = load_json(Path(retained["combined-runtime-build.json"]["path"]))
    runtime_sources = {name: value for name, value in build["source_sha256"].items()
                       if name in {"Cargo.toml", "Cargo.lock", "rust-toolchain.toml"}
                       or name.startswith("crates/relar-runtime/")}
    require(len(runtime_sources) == 15, "complete runtime build input closure")
    require({name: original["sources"][name] for name in runtime_sources} == runtime_sources,
            "ordinary runtime captured sources match final commit")
    require(original["artifacts"]["librelar_runtime.a"]
            == build["artifacts"]["librelar_runtime.a"]["sha256"],
            "ordinary runtime origin artifact")
    require(combined["source_sha256_before"] == combined["source_sha256_after"]
            == combined["source_sha256"] == runtime_sources,
            "runtime source closure unchanged across LTO/ASan builds")
    require(combined["runtime_and_cargo_sources_unchanged"] is True
            and proof["lto_asan_runtime_recorded_source_sha256"] == runtime_sources,
            "runtime proof reconciles with original capture")
    for name in ("lto", "asan"):
        entry = combined["builds"][name]
        require(entry["returncode"] == 0
                and entry["source_sha256_before"] == entry["source_sha256_after"] == runtime_sources,
                "per-build runtime source guard")
        require(entry["wrapper_sha256"] == retained[f"cargo-{name}.sh"]["sha256"],
                "runtime build wrapper identity")
        require(entry["log_sha256"] == build["commands"]["thinlto" if name == "lto" else name]["log_sha256"],
                "runtime build log identity")
    require(build["runtime_lto_rustflags"] == combined["runtime_lto_rustflags"] == "-Clinker-plugin-lto",
            "ThinLTO runtime flags")
    require(build["runtime_asan_rustflags"] == combined["runtime_asan_rustflags"]
            == "-Zsanitizer=address -Cforce-frame-pointers=yes", "sanitized runtime flags")
    for path, expected in combined["sha256"].items():
        verify_file(path, expected)
    for record in records:
        for key, value in record["relar_build_provenance"].items():
            require(build[key] == value, "full final provenance projection")
    return {"final_compiled_input_files": 33, "runtime_input_files": 15,
            "ordinary_runtime_matches_final_live_build": True,
            "runtime_before_after_captures_match_final_commit": True,
            "compiler_provenance_scope": proof["compiler"],
            "build_environment_scope": build["build_environment"]["scope"],
            "build_record_sha256": file_info(directory / "build-record.json")["sha256"]}


def benchmark_mode(root, mode, session, manifest, validator):
    path = root / "benchmarks/local/four-feature-inventory-regression" / (mode + ".json")
    record = load_json(path)
    run = session["runs"][mode]
    verify_file(path, run["record_sha256"])
    verify_file(path.with_suffix(".log"), run["log_sha256"])
    require(run["returncode"] == 0, "successful timing harness")
    require(run["started_at_utc"] <= record["started_at_utc"]
            <= record["completed_at_utc"] <= run["completed_at_utc"], "timing interval")
    require(record["schema_version"] == 1 and record["example"] == "inventory_reconciliation",
            "record schema and workload")
    require(record["git"] == {"revision": APPLICATION, "dirty": False}, "clean measured commit")
    require(record["baseline_provenance"] is None and record["workloads"]["control"] == [],
            "no unrelated or source-control benchmark arm")
    options = record["options"]
    require(options == manifest[mode]["options"], "comparison mode matches preserved baseline")
    require(options["samples"] == 48 and options["warmups"] == 2
            and options["validation_only"] is False and options["optimization_level"] == 3,
            "sample settings")
    require(options["target"] == options["requested_target"] == "x86_64-unknown-linux-gnu"
            and options["lto"] == ("thin" if mode == "lto" else None)
            and options["llvm_budget"] == (1000 if mode == "lto" else None), "build settings")
    contexts = record["execution"]
    require(set(contexts) == {"before", "before_samples", "after"}
            and contexts["before"] == contexts["before_samples"] == contexts["after"],
            "unchanged runtime context checkpoints")
    require(contexts["before"]["tracer_pid"] == 0, "untraced timing")
    for name in ("LD_PRELOAD", "ASAN_OPTIONS", "LSAN_OPTIONS", "UBSAN_OPTIONS"):
        require(contexts["before"]["inherited_environment"][name] is None,
                "uninstrumented timing environment")
    require(record["host"]["cpu"]["affinity"] == [0]
            and 0 in record["host"]["cpu"]["allowed_cpus_before_pinning"], "CPU 0 affinity")
    require(record["clock"]["monotonic"] is True and record["clock"]["adjustable"] is False
            and record["clock"]["resolution"] == 1e-9, "nanosecond clock")
    python = record["tools"]["cpython"]
    require(python["implementation"] == "cpython" and python["version_number"] == "3.14.5"
            and python["gil_enabled"] is True and python["free_threaded_build"] is False
            and python["jit_enabled"] is False and python["debug_build"] is False,
            "CPython execution configuration")
    require(python["pgo"]["configure_enable_optimizations"] is True
            and python["pgo"]["profile_use_flag_present"] is True
            and python["lto"]["lto_flag_present"] is True, "CPython PGO/LTO build")
    paths, previous = artifact_identities(root, mode, record, session)
    require(record["sha256"]["compiler"] == COMPILER, "final compiler in timing record")
    prepared = manifest[mode]
    for name, path_value in prepared["paths"].items():
        verify_file(path_value, prepared["sha256"][name])
        require(previous["sha256"][name] == prepared["sha256"][name],
                "preserved baseline artifact: " + name)
    for field in ("comparison", "published_record", "rust_build_record"):
        verify_file(prepared[field], prepared[field + "_sha256"])
    require(gzip.decompress(Path(prepared["published_record"]).read_bytes())
            == Path(prepared["comparison"]).read_bytes(), "published baseline raw byte identity")
    require(previous["git"]["revision"] == prepared["source_commit"] == BASELINE,
            "baseline source commit")
    require(prepared["sources"] == record["sources"] == previous["sources"],
            "unchanged six-file application")
    for key in ("cpython", "clang", "lto_linker"):
        require(record["tools"][key] == previous["tools"][key], "baseline tool metadata: " + key)
    require([w["label"] for w in record["workloads"]["inventory"]] == prepared["labels"],
            "all expected workload labels exactly once")
    for workload in record["workloads"]["inventory"]:
        require(digest(json.dumps(workload["case"], sort_keys=True).encode())
                == prepared["case_sha256"][workload["label"]], "prepared case bytes")
    for tool, expected in record["rust_build_record"]["tool_sha256"].items():
        actual = subprocess.check_output(["rustup", "which", tool, "--toolchain", "ohm"], text=True).strip()
        verify_file(actual, expected)
    validation = correctness(record, validator)
    rows, ordering, measured, warmups, gates = audit_workloads(
        record, previous, validator, ENGINES["inventory"], "relar")
    for row in rows:
        stats = row["statistics"]
        row["cpython_speedup"] = row["ratios_of_medians"]["cpython_over_relar"]
        row["rust_gap_percent"] = 100 * (row["ratios_of_medians"]["relar_over_rust_bigint"] - 1)
        row["iqr_overlap_vs_previous"] = max(stats["relar"]["p25_ns"], stats["baseline"]["p25_ns"]) <= min(stats["relar"]["p75_ns"], stats["baseline"]["p75_ns"])
        row["iqr_overlap_vs_rust"] = max(stats["relar"]["p25_ns"], stats["rust_bigint"]["p25_ns"]) <= min(stats["relar"]["p75_ns"], stats["rust_bigint"]["p75_ns"])
    ir = {"baseline_sha256": previous["sha256"]["inventory_ir"],
          "current_sha256": record["sha256"]["inventory_ir"],
          "byte_identical": previous["sha256"]["inventory_ir"] == record["sha256"]["inventory_ir"]}
    require(run["generated_ir"] == ir, "recorded generated-IR comparison")
    return {"mode": mode, "record_sha256": file_info(path)["sha256"],
            "measured_process_runs": measured, "warmup_process_runs": warmups,
            "inventory_gate_runs": gates, "validation_process_results": validation,
            "source_commit": APPLICATION, "baseline_source_commit": BASELINE,
            "unchanged_inventory_source_files": 6, "generated_ir": ir,
            "ordering": ordering, "rows": rows}, record, previous


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    started = datetime.now(timezone.utc).isoformat()
    session_path = root / "benchmarks/local/four-feature-inventory-regression/session.json"
    session = load_json(session_path)
    manifest_path = Path("/tmp/relar-four-feature-inventory/prepared-manifest.json")
    manifest = load_json(manifest_path)
    require(session["source_commit"] == APPLICATION and set(session["runs"]) == {"normal", "lto"},
            "final complete session")
    require(session["source_guard_before"] == session["source_guard_after"],
            "application/compiler sources unchanged across measurement")
    guard = session["source_guard_before"]
    require(guard["head"] == APPLICATION and guard["dirty"] is False
            and guard["all_compiled_sources_match_commit"] is True, "measured source guard")
    for name, expected in guard["application_source_sha256"].items():
        verify_file(root / name, expected)
    require(session["baseline_guard_before"] == session["baseline_guard_after"],
            "baseline unchanged across measurement")
    baseline_guard = session["baseline_guard_before"]
    verify_file(manifest_path, baseline_guard["manifest_sha256"])
    for mode in ("normal", "lto"):
        expected = dict(manifest[mode]["sha256"])
        expected.update({name: manifest[mode][name + "_sha256"]
                         for name in ("comparison", "published_record", "rust_build_record")})
        require(baseline_guard["sha256"][mode] == expected, "baseline guard artifacts")
        require(baseline_guard["sources"] == manifest[mode]["sources"], "baseline guard source bytes")
    launcher = session["launcher"]
    require(digest(launcher["source"].encode()) == launcher["sha256"], "launcher captured source")
    verify_file(launcher["path"], launcher["sha256"])
    verify_file(session["prior_launcher"]["path"], session["prior_launcher"]["sha256"])
    require(session["cache_preparation"]["timed"] is False, "cache preparation excluded from timings")
    normal = load_json(root / "benchmarks/local/four-feature-inventory-regression/normal.json")
    for name in ("inventory_validate.py", "manifest_validate.py", "batch_validate.py", "incremental_validate.py"):
        verify_file(root / "benchmarks" / name, normal["sha256"]["harness:" + name])
    validator = runpy.run_path(str(root / "benchmarks/inventory_validate.py"))
    modes, records, previous = zip(*(benchmark_mode(root, mode, session, manifest, validator)
                                    for mode in ("normal", "lto")))
    for key in ("sources", "rust_sources", "relar_build_provenance", "git", "tools", "execution"):
        if key == "tools":
            require(records[0][key]["cpython"] == records[1][key]["cpython"], "cross-mode CPython")
        else:
            require(records[0][key] == records[1][key], "cross-mode identity: " + key)
    for key in ("rustc_verbose", "cargo_version", "tool_sha256", "cargo_wrapper", "build_script_sha256"):
        require(records[0]["rust_build_record"][key] == records[1]["rust_build_record"][key],
                "cross-mode Rust tool identity")
    for left, right in zip(records[0]["workloads"]["inventory"], records[1]["workloads"]["inventory"]):
        excluded = {"gates", "warmups", "samples", "summary"}
        require({k:v for k,v in left.items() if k not in excluded}
                == {k:v for k,v in right.items() if k not in excluded}, "cross-mode captured workload")
    adapted_session = {**session, "git_status_before": guard["dirty"],
                       "git_status_after": session["source_guard_after"]["dirty"],
                       "runner_source": launcher["source"]}
    bytecode = bytecode_session(root, adapted_session, records)
    final_build = final_provenance(root, records)
    require(guard["build_record_sha256"] == final_build["build_record_sha256"], "session final build guard")
    prior_path = Path(manifest["preserved_tools"]["path"])
    verify_file(prior_path, manifest["preserved_tools"]["sha256"])
    prior_build = verify_build(root, prior_path, BASELINE)
    final_build_record = load_json(root / "benchmarks/local/four-feature-tools-final/build-record.json")
    require(prior_build["cargo_wrapper"] == final_build_record["cargo_wrapper"]["source"],
            "current and preserved Relar Cargo wrapper bytes")
    for name in ("rustc_verbose", "cargo_version", "runtime_lto_rustflags"):
        require(prior_build[name].rstrip("\n") == final_build_record[name].rstrip("\n"),
                "preserved/current Relar toolchain: " + name)
    for previous_record in previous:
        for key, value in previous_record["relar_build_provenance"].items():
            require(prior_build[key] == value, "preserved baseline build projection")
    require(records[0]["sha256"]["inventory_ir"] == records[1]["sha256"]["inventory_ir"],
            "current normal/LTO share emitted LLVM source")
    totals = {name: sum(mode[name] for mode in modes) for name in
              ("measured_process_runs", "warmup_process_runs", "inventory_gate_runs")}
    totals["oracle_process_results"] = sum(mode["validation_process_results"]["inventory"] for mode in modes)
    totals["device_process_results"] = sum(mode["validation_process_results"]["inventory_device"] for mode in modes)
    require(totals == {"measured_process_runs": 2304, "warmup_process_runs": 96,
                      "inventory_gate_runs": 48, "oracle_process_results": 1632,
                      "device_process_results": 8}, "complete process-result accounting")
    summary_path = Path("/tmp/relar-four-feature-inventory/summary.json")
    summary = load_json(summary_path)
    require(summary["source_commit"] == APPLICATION, "published summary source")
    verify_file(summary["session"]["path"], summary["session"]["sha256"])
    for mode in modes:
        reported = summary["modes"][mode["mode"]]
        require(len(reported["rows"]) == len(mode["rows"]), "summary row coverage")
        for row, stated in zip(mode["rows"], reported["rows"]):
            require(row["workload"] == stated["workload"], "summary row identity")
            for engine, value in row["median_ms"].items():
                close(stated["median_ms"][engine], value, "summary median")
            for key, value in {"cpython_over_relar": row["cpython_speedup"],
                               "relar_over_rust": row["ratios_of_medians"]["relar_over_rust_bigint"],
                               "relar_over_previous": row["ratios_of_medians"]["relar_over_baseline"],
                               "relar_change_percent": row["new_vs_baseline_time_change_percent"]}.items():
                close(stated[key], value, "summary ratio/change")
    # Rehash every input, including large binaries, after all calculations.
    for path, (signature, expected) in list(FILES.items()):
        with path.open("rb") as stream:
            require(hashlib.file_digest(stream, "sha256").hexdigest() == expected,
                    "input bytes changed during audit: " + str(path))
    report = {"passed": True, "source_commit": APPLICATION, "baseline_source_commit": BASELINE,
              "started_at_utc": started, "completed_at_utc": datetime.now(timezone.utc).isoformat(),
              "checks": CHECKS, "scope": "saved evidence; no timing, compiler, or native workload reruns",
              "statistical_method": "Exact Fraction interpolation on integer nanoseconds at p*(n-1), inclusive Q1/median/Q3; ratios of per-engine medians. IQR overlap is descriptive, not a significance test.",
              "reused_generic_helper_sha256": REUSED_HELPER_SHA256,
              "audit_script_sha256": digest(Path(__file__).read_bytes()),
              "source_control_run": None, "source_control_note": "All six application files are unchanged from sequence baseline, so no source-migration control is applicable.",
              "totals": totals, "bytecode": bytecode, "final_tool_provenance": final_build,
              "modes": {mode["mode"]: mode for mode in modes},
              "inputs": {str(path): {"sha256": value, "bytes": signature[0]}
                         for path, (signature, value) in sorted(FILES.items())}}
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": True, "checks": CHECKS, "totals": totals,
                      "output": str(args.output)}, indent=2))
    for mode in modes:
        for row in mode["rows"]:
            print(mode["mode"], row["workload"],
                  "CPython speedup", round(row["cpython_speedup"], 4),
                  "Rust gap %", round(row["rust_gap_percent"], 4),
                  "previous delta %", round(row["new_vs_baseline_time_change_percent"], 4),
                  "previous IQR overlap", row["iqr_overlap_vs_previous"],
                  "Rust IQR overlap", row["iqr_overlap_vs_rust"])


if __name__ == "__main__":
    main()
