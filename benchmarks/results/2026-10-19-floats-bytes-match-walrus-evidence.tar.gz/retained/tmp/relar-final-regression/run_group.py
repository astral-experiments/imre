import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--group', choices=['normal', 'asan'], required=True)
parser.add_argument('--workers', type=int, default=2)
args = parser.parse_args()
manifest = json.loads((ROOT / 'manifest.json').read_text())
tools = manifest['tools']
jobs = [job for job in manifest['jobs'] if job['group'] == args.group]
logs = ROOT / 'logs'
logs.mkdir(exist_ok=True)
expected = json.loads((ROOT / 'harness-manifest.json').read_text())

def sha(path):
    with open(path, 'rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()

def verify():
    for name, expected_hash in manifest['orchestration'].items():
        assert sha(ROOT / name) == expected_hash, f'Changed runner: {name}'
    for tool in tools.values():
        assert sha(tool['path']) == tool['sha256'], f"Changed tool: {tool['path']}"
    for relative, entry in expected.items():
        path = Path(manifest['snapshot']) / relative
        if 'sha256' in entry:
            assert sha(path) == entry['sha256'], f'Changed fixture: {relative}'
        elif 'link' in entry:
            assert os.readlink(path) == entry['link']
        else:
            assert path.is_dir(), relative

verify()
environment = {**os.environ, **manifest['environment']}

def execute(job):
    command = [tools['python']['path'], str(Path(manifest['snapshot']) / 'tests' / (job['suite'] + '.py')),
               '--compiler', tools['compiler']['path'],
               '--runtime', tools['asan_runtime' if job['group'] == 'asan' else 'runtime']['path'],
               '--python', tools['python']['path'], '--clang', tools['clang']['path'],
               '--opt-levels', *job['levels']]
    if job['group'] == 'asan':
        command.append('--sanitize')
    log = logs / (job['id'] + '.log')
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    with log.open('w') as output:
        process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT,
                                   cwd=manifest['snapshot'], env=environment, start_new_session=True)
        try:
            returncode = process.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            returncode = -124
    text = log.read_text()
    match = re.search(r'(?m)^Passed\s+(\d+)\b', text) or re.search(r'(?m)^(\d+)\s+import checks passed', text)
    checks = int(match.group(1)) if match else None
    result = {**job, 'command': command, 'started': started, 'seconds': round(time.monotonic()-clock, 3),
              'returncode': returncode, 'checks': checks, 'ok': returncode == 0 and checks is not None,
              'log': str(log), 'log_sha256': sha(log)}
    return result

results = []
with ThreadPoolExecutor(max_workers=args.workers) as pool:
    futures = {pool.submit(execute, job): job for job in jobs}
    for future in as_completed(futures):
        result = future.result()
        results.append(result)
        (ROOT / (args.group + '-results.json')).write_text(json.dumps(sorted(results, key=lambda item: item['id']), indent=2) + '\n')
        print(('PASS' if result['ok'] else 'FAIL'), result['id'], result['checks'], 'checks;', result['seconds'], 'seconds', flush=True)
        if not result['ok']:
            print(Path(result['log']).read_text()[-16000:], flush=True)
verify()
checks = sum(result['checks'] or 0 for result in results)
print(f'{args.group}: {sum(result["ok"] for result in results)}/{len(jobs)} suites; {checks} checks', flush=True)
if any(not result['ok'] for result in results):
    raise SystemExit(1)
