from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parent
repo=Path('/home/dev-user/code/oss/relar')
snapshot=root/'inputs'
assert not snapshot.exists(), 'Refuse to overwrite a frozen snapshot'
(snapshot/'.github'/'workflows').mkdir(parents=True)
shutil.copytree(repo/'tests',snapshot/'tests',symlinks=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copy2(repo/'.github'/'workflows'/'ci.yml',snapshot/'.github'/'workflows'/'ci.yml')
def sha(path):
    with path.open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()
harness={}
for path in sorted(snapshot.rglob('*')):
    name=str(path.relative_to(snapshot))
    if path.is_symlink():harness[name]={'link':os.readlink(path)}
    elif path.is_file():harness[name]={'sha256':sha(path),'bytes':path.stat().st_size}
    elif path.is_dir():harness[name]={'directory':True}
(root/'harness-manifest.json').write_text(json.dumps(harness,indent=2,sort_keys=True)+'\n')
names=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z','--','crates','.cargo','Cargo.toml','Cargo.lock','rust-toolchain.toml'],cwd=repo,text=True).split('\0')
source={name:{'sha256':sha(repo/name),'bytes':(repo/name).stat().st_size} for name in sorted(set(filter(None,names))) if (repo/name).is_file()}
(root/'source-manifest.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n')
metadata={'frozen_at':datetime.now(timezone.utc).isoformat(),'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'git_branch':subprocess.check_output(['git','branch','--show-current'],cwd=repo,text=True).strip(),'git_status':subprocess.check_output(['git','status','--short'],cwd=repo,text=True).strip(),'harness_manifest_sha256':sha(root/'harness-manifest.json'),'source_manifest_sha256':sha(root/'source-manifest.json')}
(root/'input-freeze.json').write_text(json.dumps(metadata,indent=2)+'\n')
for path in snapshot.rglob('*'):
    if not path.is_symlink():path.chmod(0o555 if path.is_dir() else 0o444)
snapshot.chmod(0o555)
print(json.dumps(metadata,indent=2))
print('Frozen',len(harness),'harness entries and',len(source),'compiler/runtime source files.')
