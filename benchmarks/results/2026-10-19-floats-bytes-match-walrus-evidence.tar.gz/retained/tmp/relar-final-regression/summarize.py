from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
results=[]
for group in ('normal','asan'):
    results.extend(json.loads((root/(group+'-results.json')).read_text()))
assert {result['id'] for result in results}=={job['id'] for job in manifest['jobs']}, 'Missing suite results'
receipt={
    'finished_at':datetime.now(timezone.utc).isoformat(),
    'git_head_at_freeze':manifest['git_head'],
    'git_branch_at_freeze':manifest['git_branch'],
    'compiler_sha256':manifest['tools']['compiler']['sha256'],
    'runtime_sha256':manifest['tools']['runtime']['sha256'],
    'asan_runtime_sha256':manifest['tools']['asan_runtime']['sha256'],
    'tool_and_job_manifest':str(root/'manifest.json'),
    'harness_manifest':str(root/'harness-manifest.json'),
    'source_manifest':str(root/'source-manifest.json'),
    'harness_manifest_sha256':manifest['harness_manifest_sha256'],
    'source_manifest_sha256':manifest['source_manifest_sha256'],
    'all_passed':all(result['ok'] for result in results),
    'groups':{},
    'suites':[{key:result[key] for key in ('id','levels','checks','ok','log','log_sha256')} for result in sorted(results,key=lambda item:item['id'])],
}
for group in ('normal','asan'):
    selected=[result for result in results if result['group']==group]
    receipt['groups'][group]={'invocations':len(selected),'passed':sum(result['ok'] for result in selected),'checks':sum(result['checks'] or 0 for result in selected)}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ('all_passed','groups','compiler_sha256')},indent=2))
print('Receipt:',root/'receipt.json')
if not receipt['all_passed']:
    raise SystemExit(1)
