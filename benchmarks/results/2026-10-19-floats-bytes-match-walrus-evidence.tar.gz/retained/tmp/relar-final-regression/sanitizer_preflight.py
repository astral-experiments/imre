import hashlib
import json
import os
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
source=root/'leak_preflight.c'
source.write_text('#include <stdlib.h>\n__attribute__((noinline)) static void leak(void) { char *value = malloc(37); value[0] = 42; }\nint main(void) { leak(); return 0; }\n')
binary=root/'leak_preflight'
command=[manifest['tools']['clang']['path'],'-O0','-g','-fsanitize=address',str(source),'-o',str(binary)]
subprocess.run(command,check=True,capture_output=True,text=True)
env={**os.environ,'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','LSAN_OPTIONS':'exitcode=23:abort_on_error=1'}
actual=subprocess.run([str(binary)],capture_output=True,text=True,env=env,timeout=20)
(root/'sanitizer-preflight.stderr').write_text(actual.stderr)
result={'command':command,'environment':{name:env[name] for name in ['ASAN_OPTIONS','LSAN_OPTIONS']},'returncode':actual.returncode,'leak_reported':'LeakSanitizer' in actual.stderr,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
(root/'sanitizer-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
assert actual.returncode==-6 and 'LeakSanitizer' in actual.stderr and 'ptrace' not in actual.stderr, actual
print('Sanitizer preflight: LeakSanitizer detects an intentional leak and aborts; legacy error-case assertions will reject leaks.',flush=True)
