from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
retries=[]
for group in ['normal','asan']:
    path=root/(group+'-results.json')
    original=root/(group+'-initial-results.json')
    if not original.exists():shutil.copy2(path,original)
    results=json.loads(original.read_text())
    merged=[]
    for result in results:
        retry_path=root/('retry-'+result['id']+'.json')
        if retry_path.exists():
            replacement=json.loads(retry_path.read_text())
            assert replacement['ok'],replacement['id']
            replacement['initial_attempt_log']=result['log']
            retries.append(replacement['id'])
            result=replacement
        assert result['ok'],result['id']
        with open(result['log'],'rb') as file:log_hash=hashlib.file_digest(file,'sha256').hexdigest()
        assert log_hash==result['log_sha256'],result['id']
        merged.append(result)
    path.write_text(json.dumps(merged,indent=2)+'\n')
subprocess.run([sys.executable,str(root/'summarize.py')],check=True)
path=root/'receipt.json'
receipt=json.loads(path.read_text())
receipt['sanitizer_preflight']=str(root/'sanitizer-preflight.json')
receipt['setup_correction']={'details':str(root/'permissions-restored.json'),'affected_invocations_retried':len(retries),'content_hashes_unchanged':True,'initial_results':[str(root/(group+'-initial-results.json')) for group in ['normal','asan']]}
receipt['retry_runner_sha256']=hashlib.sha256((root/'retry.py').read_bytes()).hexdigest()
path.write_text(json.dumps(receipt,indent=2)+'\n')
print('Preserved initial setup logs and merged',len(retries),'successful retries.')
