import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('ids',nargs='+')
args=parser.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
tools=manifest['tools']
selected=[job for job in manifest['jobs'] if job['id'] in args.ids]
assert len(selected)==len(set(args.ids))
selected.sort(key=lambda job: args.ids.index(job['id']))
logs=root/'retry-logs'
logs.mkdir(exist_ok=True)
def sha(path):
    with open(path,'rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()
def verify():
    for tool in tools.values():assert sha(tool['path'])==tool['sha256'],tool['path']
    for relative,entry in json.loads((root/'harness-manifest.json').read_text()).items():
        if 'sha256' in entry:assert sha(Path(manifest['snapshot'])/relative)==entry['sha256'],relative
verify()
def execute(job):
    command=[tools['python']['path'],str(Path(manifest['snapshot'])/'tests'/(job['suite']+'.py')),'--compiler',tools['compiler']['path'],'--runtime',tools['asan_runtime' if job['group']=='asan' else 'runtime']['path'],'--python',tools['python']['path'],'--clang',tools['clang']['path'],'--opt-levels',*job['levels']]
    if job['group']=='asan':command.append('--sanitize')
    log=logs/(job['id']+'.log')
    started=datetime.now(timezone.utc).isoformat()
    clock=time.monotonic()
    with log.open('w') as file:
        actual=subprocess.run(command,cwd=manifest['snapshot'],stdout=file,stderr=subprocess.STDOUT,env={**os.environ,**manifest['environment']},timeout=1800)
    text=log.read_text()
    match=re.search(r'(?m)^Passed\s+(\d+)\b',text) or re.search(r'(?m)^(\d+)\s+import checks passed',text)
    checks=int(match.group(1)) if match else None
    result={**job,'command':command,'started':started,'seconds':round(time.monotonic()-clock,3),'returncode':actual.returncode,'checks':checks,'ok':actual.returncode==0 and checks is not None,'log':str(log),'log_sha256':sha(log),'retry_reason':'writable temporary project permissions'}
    (root/('retry-'+job['id']+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result
results=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    for future in as_completed([pool.submit(execute,job) for job in selected]):
        result=future.result()
        results.append(result)
        print('PASS' if result['ok'] else 'FAIL',result['id'],result['checks'],flush=True)
        if not result['ok']:print(Path(result['log']).read_text(),flush=True)
verify()
if any(not result['ok'] for result in results):raise SystemExit(1)
