import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
from datetime import datetime, timezone

SUITES = 'differential imports classes containers comprehensions fstrings calls expressions floats bytes matching assignments exceptions io files'.split()
ASAN_ZERO = 'containers fstrings calls expressions floats bytes matching assignments files'.split()
PYTHON = '/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
REPO = Path('/home/dev-user/code/oss/relar')
ROOT = Path(__file__).resolve().parent

def sha(path):
    with open(path, 'rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()

def run(*command):
    return subprocess.check_output(command, cwd=REPO, text=True).strip()

def tree_manifest(root):
    result = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if '__pycache__' in relative.parts or path.suffix == '.pyc':
            continue
        if path.is_symlink():
            result[str(relative)] = {'link': os.readlink(path)}
        elif path.is_file():
            result[str(relative)] = {'sha256': sha(path), 'bytes': path.stat().st_size}
        elif path.is_dir():
            result[str(relative)] = {'directory': True}
    return result

parser = argparse.ArgumentParser()
parser.add_argument('--compiler', required=True, type=Path)
parser.add_argument('--compiler-sha', required=True)
parser.add_argument('--runtime', required=True, type=Path)
parser.add_argument('--asan-runtime', required=True, type=Path)
args = parser.parse_args()
assert sha(args.compiler) == args.compiler_sha, 'Final compiler checksum mismatch'
snapshot = ROOT / 'inputs'
assert snapshot.exists(), 'Freeze harness/source inputs before finalizing tools'
input_freeze = json.loads((ROOT / 'input-freeze.json').read_text())
assert sha(ROOT / 'harness-manifest.json') == input_freeze['harness_manifest_sha256']
assert sha(ROOT / 'source-manifest.json') == input_freeze['source_manifest_sha256']
harness = tree_manifest(snapshot)
assert tree_manifest(snapshot / 'tests') == tree_manifest(REPO / 'tests')
(ROOT / 'harness-manifest.json').write_text(json.dumps(harness, indent=2, sort_keys=True) + '\n')
source_names = run('git', 'ls-files', '-c', '-o', '--exclude-standard', '-z', '--',
                   'crates', '.cargo', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml').split('\0')
source = {}
for name in sorted(set(filter(None, source_names))):
    path = REPO / name
    if path.is_file():
        source[name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
assert source == json.loads((ROOT / 'source-manifest.json').read_text()), 'Compiler source changed since freeze'
artifacts = ROOT / 'artifacts'
artifacts.mkdir()
tools = {}
for label, original, name in [
    ('compiler', args.compiler, 'relar'),
    ('runtime', args.runtime, 'librelar_runtime.a'),
    ('asan_runtime', args.asan_runtime, 'librelar_runtime_asan.a'),
]:
    original = original.resolve()
    original_hash = sha(original)
    target = artifacts / name
    shutil.copy2(original, target)
    assert sha(target) == original_hash == sha(original), f'{label} changed while freezing'
    target.chmod(0o555 if label == 'compiler' else 0o444)
    tools[label] = {'path': str(target), 'original': str(original), 'sha256': original_hash}
clang = Path(shutil.which('clang-18')).resolve()
linker = Path(run(str(clang), '-print-prog-name=ld')).resolve()
for label, path in [('python', Path(PYTHON).resolve()), ('clang', clang), ('linker', linker)]:
    tools[label] = {'path': str(path), 'sha256': sha(path), 'version': run(str(path), '--version')}
for label in ('compiler', 'python', 'clang', 'linker'):
    dependencies = subprocess.run(['ldd', tools[label]['path']], capture_output=True, text=True, check=False)
    tools[label]['dynamic_dependencies'] = []
    for dependency in re.findall(r'(/[^\s]+)', dependencies.stdout):
        path = Path(dependency).resolve()
        if path.is_file():
            tools[label]['dynamic_dependencies'].append(str(path))
            tools.setdefault('shared_library:' + str(path), {'path': str(path), 'sha256': sha(path)})
resource = Path(run(str(clang), '-print-resource-dir'))
for path in sorted((resource / 'lib' / 'linux').glob('*asan*x86_64*')):
    if path.is_file():
        tools['clang_resource:' + path.name] = {'path': str(path.resolve()), 'sha256': sha(path.resolve())}
jobs = []
for suite in SUITES:
    jobs.append({'id': 'normal-' + suite, 'group': 'normal', 'suite': suite, 'levels': ['0', '3']})
for level, suites in [('1', SUITES), ('0', ASAN_ZERO)]:
    for suite in suites:
        jobs.append({'id': 'asan-O' + level + '-' + suite, 'group': 'asan', 'suite': suite, 'levels': [level]})
jobs.sort(key=lambda job: job['suite'] != 'assignments')
manifest = {
    'frozen_at': datetime.now(timezone.utc).isoformat(),
    'input_freeze': input_freeze,
    'repository': str(REPO.resolve()),
    'git_common_dir': run('git', 'rev-parse', '--path-format=absolute', '--git-common-dir'),
    'git_head': run('git', 'rev-parse', 'HEAD'),
    'git_branch': run('git', 'branch', '--show-current'),
    'git_status': run('git', 'status', '--short'),
    'snapshot': str(snapshot),
    'harness_manifest_sha256': sha(ROOT / 'harness-manifest.json'),
    'source_manifest_sha256': sha(ROOT / 'source-manifest.json'),
    'orchestration': {name: sha(ROOT / name) for name in ('prepare.py', 'run_group.py', 'summarize.py', 'freeze_inputs.py')},
    'tools': tools,
    'jobs': jobs,
    'environment': {
        'PYTHONDONTWRITEBYTECODE': '1',
        'PYTHONUNBUFFERED': '1',
        'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1:abort_on_error=1',
        'LSAN_OPTIONS': 'exitcode=23:abort_on_error=1',
    },
}
for path in snapshot.rglob('*'):
    if not path.is_symlink():
        path.chmod(0o555 if path.is_dir() else 0o444)
snapshot.chmod(0o555)
(ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(f'Frozen {len(harness)} harness entries and {len(source)} source files; prepared {len(jobs)} suite invocations.')
print('Compiler:', tools['compiler']['sha256'])
