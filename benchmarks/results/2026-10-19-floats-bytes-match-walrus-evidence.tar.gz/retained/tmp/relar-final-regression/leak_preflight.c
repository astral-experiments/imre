#include <stdlib.h>
__attribute__((noinline)) static void leak(void) { char *value = malloc(37); value[0] = 42; }
int main(void) { leak(); return 0; }
