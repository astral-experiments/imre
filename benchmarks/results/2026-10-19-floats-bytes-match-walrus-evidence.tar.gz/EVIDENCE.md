# Four-feature experiment evidence

Measurements use clean source commit 97cb1000565035162c31e6e455d207cf65b54993. Exact UTC timestamps are in the
records. `source/` is that Git tree, excluding historical benchmark results.
`retained/` contains current raw samples, captured baseline workload/source
manifests, generated LLVM, tool-build provenance, all validator source snapshots,
logs, setup-failure/retry receipts, and audit/packaging scripts.

All six inventory source files are unchanged from the sequence milestone. The
comparison uses the preserved sequence binary directly; there is no separate
source-migration/control experiment. Native binaries, runtime archives, Python,
toolchains, caches, and historical raw timing/result archives are excluded.
Original artifact paths/hashes and baseline publication references are retained.

The final compiler was built at the measured commit. Earlier runtime archives
were reconciled by actual runtime/Cargo/toolchain source hashes to that commit;
the ordinary archive also equals the final workspace build output. ASan covers
the application LLVM and custom runtime, with leak checking; the prebuilt Rust
standard library was not rebuilt with ASan. Initial fixture-permission setup
failures and successful retries are retained; no timed samples were repeated.

The portable audit verifies all archived bytes and recomputes sample statistics,
balanced orders, output/filesystem oracles and saved validation joins. It needs
only these text records and Python, not the original machine or native artifacts.
Report/packaging source is generated after the measured commit and kept separate
from its captured source tree. A live rerun would still need compatible external
compiler/runtime/interpreter/reference artifacts.
