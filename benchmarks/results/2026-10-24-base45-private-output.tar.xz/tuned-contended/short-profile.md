| Short input | First→second call, incremental instructions (base → candidate) | Second→eighth call, instructions per extra call (base → candidate) |
|---|---:|---:|
| encode-64 | 7,368 → 7,381 | 7,084.5 → 7,055.8 |
| decode-bytes-64 | 8,525 → 8,140 | 8,666.8 → 8,043.2 |
| decode-text-64 | 8,810 → 8,235 | 8,641.7 → 8,079.8 |
