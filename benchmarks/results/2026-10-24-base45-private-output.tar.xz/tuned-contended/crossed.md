## Crossing baseline LLVM with the candidate runtime

The hybrid executable uses the baseline application's emitted LLVM and the candidate release runtime under the same Clang invocation. Relinking the baseline LLVM with its own runtime reproduced its executable byte for byte. Each arm ran all six permutations four times after six warmups, with every complete CPython output checked.

| Operation | Base ms | Hybrid ms | Candidate ms | Runtime-only change (95% interval) | Code-selection change on shared runtime (95% interval) |
|---|---:|---:|---:|---:|---:|
| encode-0 | 2.170 | 2.166 | 2.154 | +0.76% [-1.68,+3.18] | +1.59% [-1.68,+3.28] |
| decode-bytes-64 | 25.947 | 27.783 | 22.880 | +7.00% [+6.53,+7.57] | -17.62% [-18.00,-17.07] |
| decode-text-64 | 25.773 | 27.022 | 23.119 | +4.95% [+4.10,+6.62] | -14.63% [-15.04,-14.15] |
| encode-64 | 22.250 | 21.765 | 21.437 | -1.99% [-3.37,-0.65] | -1.82% [-2.59,-0.28] |
| decode-bytes-1024 | 20.760 | 22.258 | 18.308 | +6.75% [+5.64,+7.38] | -17.88% [-18.53,-17.15] |
| decode-text-1024 | 20.581 | 22.195 | 18.226 | +7.69% [+6.76,+8.39] | -18.09% [-18.55,-17.19] |
| encode-1024 | 15.543 | 15.705 | 15.245 | +1.17% [-0.28,+1.87] | -3.01% [-3.52,-2.14] |
| decode-bytes-16384 | 20.964 | 22.557 | 18.051 | +6.87% [+6.66,+8.42] | -20.23% [-21.23,-19.46] |
| decode-text-16384 | 20.910 | 22.280 | 17.937 | +6.84% [+6.41,+7.17] | -19.59% [-19.93,-19.09] |
| encode-16384 | 14.418 | 14.632 | 14.289 | +1.07% [+0.07,+2.91] | -1.40% [-4.82,-1.00] |
