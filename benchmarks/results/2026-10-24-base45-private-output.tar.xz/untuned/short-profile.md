| Short input | First→second call, incremental instructions (base → candidate) | Second→eighth call, instructions per extra call (base → candidate) |
|---|---:|---:|
| encode-64 | 7,119 → 7,231 | 7,075.8 → 7,076.7 |
| decode-bytes-64 | 8,606 → 8,651 | 8,660.5 → 8,771.2 |
| decode-text-64 | 8,602 → 8,807 | 8,674.7 → 8,790.8 |
