## Crossing baseline LLVM with the candidate runtime

The hybrid executable uses the baseline application's emitted LLVM and the candidate release runtime under the same Clang invocation. Relinking the baseline LLVM with its own runtime reproduced its executable byte for byte. Each arm ran all six permutations four times after six warmups, with every complete CPython output checked.

| Operation | Base ms | Hybrid ms | Candidate ms | Runtime-only change (95% interval) | Code-selection change on shared runtime (95% interval) |
|---|---:|---:|---:|---:|---:|
| encode-0 | 2.160 | 2.160 | 2.153 | -0.82% [-3.98,+1.35] | +0.95% [-0.85,+2.76] |
| decode-bytes-64 | 25.993 | 27.190 | 26.782 | +4.85% [+3.89,+6.22] | -1.46% [-1.90,-0.78] |
| decode-text-64 | 25.712 | 26.989 | 27.997 | +4.94% [+4.62,+5.37] | +4.21% [+3.55,+4.40] |
| encode-64 | 22.275 | 21.648 | 21.536 | -2.69% [-3.10,-2.29] | -0.42% [-1.60,+0.14] |
| decode-bytes-1024 | 20.570 | 22.037 | 19.549 | +7.53% [+7.26,+7.83] | -11.35% [-11.64,-11.10] |
| decode-text-1024 | 20.460 | 21.990 | 19.531 | +7.51% [+6.90,+8.03] | -11.35% [-11.57,-11.10] |
| encode-1024 | 15.430 | 15.751 | 15.453 | +2.14% [+0.86,+2.56] | -1.20% [-2.77,-0.52] |
| decode-bytes-16384 | 20.782 | 22.323 | 19.031 | +7.32% [+6.23,+7.60] | -14.57% [-15.34,-14.22] |
| decode-text-16384 | 20.803 | 22.206 | 19.055 | +6.94% [+5.82,+7.28] | -14.51% [-14.71,-14.06] |
| encode-16384 | 14.491 | 14.854 | 14.568 | +3.26% [+1.22,+4.06] | -2.12% [-2.63,-0.97] |
