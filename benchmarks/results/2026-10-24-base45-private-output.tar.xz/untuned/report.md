# Private byte-output comparison on python-base45

Baseline `c198de1eae988e5c066a8dab33e772a518f25300` and candidate `precommit-activation` compiled the same upstream decoder and benchmark driver using Clang 18.1.3, whole-program LLVM, -O3, the explicit release runtime for each commit, and the system allocator. Each native process runs 2 MiB of raw data except the one-call empty startup control. Both executables ran on one pinned Linux CPU with the same tmpfs inputs, output paths, flags and warm OS file caches.

| Input, decoded size | Repetitions | Base median, ms | Candidate median, ms | Paired change (95% interval) |
|---|---:|---:|---:|---:|
| encode-64 | 32,768 | 22.435 | 21.705 | -3.67% [-4.31, -2.92] |
| decode-bytes-64 | 32,768 | 26.263 | 26.915 | +2.62% [+1.53, +3.26] |
| decode-text-64 | 32,768 | 25.916 | 28.165 | +8.76% [+8.50, +9.22] |
| encode-1024 | 2,048 | 15.507 | 15.602 | -0.21% [-0.57, +0.53] |
| decode-bytes-1024 | 2,048 | 20.866 | 19.725 | -4.77% [-5.76, -4.16] |
| decode-text-1024 | 2,048 | 20.587 | 19.578 | -5.08% [-5.36, -4.49] |
| encode-16384 | 128 | 14.397 | 14.609 | +1.97% [+0.73, +2.50] |
| decode-bytes-16384 | 128 | 20.961 | 19.252 | -8.22% [-9.06, -7.86] |
| decode-text-16384 | 128 | 20.882 | 19.136 | -8.37% [-8.90, -7.89] |
| encode-0 | 1 | 2.180 | 2.153 | -0.66% [-3.22, +0.70] |

36 measured AB/BA pairs after 6 warmups per operation and size. Each batch reproduced CPython’s entire output, checksum, exit code and stderr. The 95% intervals use 10,000 bootstrap samples stratified by pair order. The earlier three-case same-binary A/A run retains every calibration sample in meta/calibration.json.

The codec came from kirei/python-base45 at 5f49a519c3884a4fbc4c58c5c8f1fa25d7046020. Its upstream and vendored source SHA-256 was a22381be6391bd5b3aa9296fc3a2ba44e31ca19368bedb86f48f4f3bf8b42b9f.

## Heap and executed instructions

A separate Valgrind replay uses one call per process. Peak is simultaneously live requested heap at the global high-water mark. Extra allocations are the total block count for two calls minus one call on the same input. Callgrind instructions include all startup and file I/O.

| Operation, size | Peak heap B, base → candidate | Peak change | Extra-call allocation count, base → candidate | Callgrind instructions, base → candidate |
|---|---:|---:|---:|---:|
| encode-64 | 137,578 → 137,578 | +0.0% | 7 → 7 | 388,690 → 388,661 (-0.0%) |
| decode-bytes-64 | 140,024 → 139,464 | -0.4% | 2 → 6 | 394,954 → 394,283 (-0.2%) |
| decode-text-64 | 140,023 → 139,463 | -0.4% | 2 → 6 | 395,669 → 395,038 (-0.2%) |
| encode-1024 | 140,940 → 140,940 | +0.0% | 14 → 14 | 456,208 → 456,196 (-0.0%) |
| decode-bytes-1024 | 162,106 → 153,866 | -5.1% | 2 → 10 | 499,939 → 493,105 (-1.4%) |
| decode-text-1024 | 162,105 → 153,865 | -5.1% | 2 → 10 | 500,953 → 494,108 (-1.4%) |
| encode-16384 | 194,701 → 194,701 | +0.0% | 21 → 21 | 1,544,012 → 1,544,105 (+0.0%) |
| decode-bytes-16384 | 515,387 → 384,267 | -25.4% | 2 → 14 | 2,196,046 → 2,076,326 (-5.5%) |
| decode-text-16384 | 515,386 → 384,266 | -25.4% | 2 → 14 | 2,221,721 → 2,101,846 (-5.4%) |
| encode-0 | 137,353 → 137,353 | +0.0% | 1 → 1 | 380,911 → 380,733 (-0.0%) |
| decode-bytes-65 | 140,185 → 139,672 | -0.4% | 2 → 7 | 395,479 → 395,079 (-0.1%) |
| decode-text-65 | 140,184 → 139,671 | -0.4% | 2 → 7 | 396,336 → 395,715 (-0.2%) |

## Runtime calls

Counts came from executed Callgrind call edges on each actual application binary and input. The paired appends handle two output bytes and the 65-byte control reaches the scalar tail.

| Operation, size | Old list-pair appends | Old list→bytes | Candidate old list→bytes | New helper calls on candidate |
|---|---:|---:|---:|---|
| encode-64 | 0 | 0 | 0 | 0 |
| decode-bytes-64 | 32 | 1 | 0 | byte_output_append_pair=32, byte_output_finish=1, byte_output_new=1 |
| decode-text-64 | 32 | 1 | 0 | byte_output_append_pair=32, byte_output_finish=1, byte_output_new=1 |
| encode-1024 | 0 | 0 | 0 | 0 |
| decode-bytes-1024 | 512 | 1 | 0 | byte_output_append_pair=512, byte_output_finish=1, byte_output_new=1 |
| decode-text-1024 | 512 | 1 | 0 | byte_output_append_pair=512, byte_output_finish=1, byte_output_new=1 |
| encode-16384 | 0 | 0 | 0 | 0 |
| decode-bytes-16384 | 8,192 | 1 | 0 | byte_output_append_pair=8,192, byte_output_finish=1, byte_output_new=1 |
| decode-text-16384 | 8,192 | 1 | 0 | byte_output_append_pair=8,192, byte_output_finish=1, byte_output_new=1 |
| encode-0 | 0 | 0 | 0 | 0 |
| decode-bytes-65 | 32 | 1 | 0 | byte_output_append=1, byte_output_append_pair=32, byte_output_finish=1, byte_output_new=1 |
| decode-text-65 | 32 | 1 | 0 | byte_output_append=1, byte_output_append_pair=32, byte_output_finish=1, byte_output_new=1 |

## Correctness

- The base passed 5 upstream test methods, 323 native calls, 289 differential cases including exact exception class/message, suppression flag and cause class/message, and 2 compile-time type rejections.
- The candidate passed 5 upstream test methods, 323 native calls, 289 differential cases including exact exception class/message, suppression flag and cause class/message, and 2 compile-time type rejections.

The additional unmodified-codec scenarios injected −1, −256 and −2^65 through the exported mutable Base45 alphabet, checked errors that compete with out-of-range output, and restored the dictionary. Both native programs reproduced every line of the CPython replay, including all chained causes, and passed the repository’s shared-export, repeated-recovery and dictionary-deletion replay.

