# Matched Base45 native runs

Before timing, we required a reproducible end-to-end improvement for both 1 KiB and 16 KiB decode inputs, a measured 16 KiB peak heap, and no well-resolved slowdown above 2% at 64 B. Inspect instruction and allocation profiles if the untargeted encoding or process startup controls move. These criteria inform a recommendation; the experiment does not change a remote repository.

Use commit c198de1eae988e5c066a8dab33e772a518f25300 as the baseline. Build the candidate in a separate target with the same toolchain and release settings. The exact command is shown below. Each compiler links its own release runtime archive, with the default system allocator. The final application compile invokes /usr/bin/clang-18 -O3 on the entire program's LLVM and links that release archive with the default GNU linker. Explicit --no-cache, --whole-program, --emit-llvm, --runtime and --clang are recorded in base/manifest.json and candidate/manifest.json. No ThinLTO is used.

    cargo +ohm -Zohm-defaults=no build --release --locked --offline -j4 -p relar-compiler --bin relar -p relar-runtime --lib

Use the exact source for the pinned base's crates, stdlib, Cargo files, benchmark helpers and examples/base45_codec. The extra byte_output_cases.py under the temporary copy is a standalone mutated-alphabet driver; no upstream source changes. verify_source.py compares every tracked build/benchmark source file with its base Git blob and compares all four vendored upstream files with their pinned public downloads. CPython 3.14.5, Ubuntu Clang 18.1.3, GNU ld, and Valgrind 3.22.0 are used in this run. Set STUDY to the directory containing these drivers, source, inputs, base and candidate. The release artifacts and study live on Linux tmpfs with warm OS caches. Run these commands from the unpacked evidence directory.

    python3 verify_source.py --repo "$BASE_REPO" --revision "$BASE" --source "$STUDY/source" --out "$STUDY/meta/source.json"
    python3 compile_arm.py --study "$STUDY" --arm base --revision "$BASE" --compiler "$BASE_COMPILER" --runtime "$BASE_RUNTIME"
    python3 compile_arm.py --study "$STUDY" --arm candidate --revision "$HEAD" --compiler "$CANDIDATE_COMPILER" --runtime "$CANDIDATE_RUNTIME"
    python3 benchmark.py prepare --study "$STUDY" --cpu 8
    python3 calibrate.py "$STUDY"
    python3 benchmark.py timing --study "$STUDY" --cpu 8 --pairs 36 --warmups 6
    python3 profile.py dhat --arm base --study "$STUDY" --cpu 6
    python3 profile.py dhat --arm candidate --study "$STUDY" --cpu 6
    python3 profile.py callgrind --arm base --study "$STUDY" --cpu 7
    python3 profile.py callgrind --arm candidate --study "$STUDY" --cpu 7
    python3 report.py "$STUDY"

The wall timer starts immediately before spawning each exact native driver and ends after its process exits and output pipes are drained. It includes reading the input, all decode/encode repetitions, checking each result's length and endpoint digits, writing the last result, and process startup/teardown. Every timed sample checks the entire final output file, exact stdout checksum, empty stderr, success status, and input identity against a CPython CLI execution. No tracing or memory instrumentation is enabled in the wall timing. All arms see the same file paths, argv[0], and actual input bytes. The work generator is the existing benchmarks/base45_benchmark.py/workloads, using its exact seed 9285. For b45decode(str), the existing driver decodes the file to text once before the inner loop. An encoded Base45 string for 16 KiB of binary data is 24 KiB.

The two native releases run in equal numbers of AB and BA orders for each size. The order of workload sizes and bytes/text modes is shuffled each round. The final quiet run is reproduced with python3 quiet_replay.py "$STUDY" --cpu 8. It first calibrates the baseline against itself and records child CPU/wall for each arm. The time columns are absolute medians and the changes are medians of paired percentage differences with order-stratified, seeded 10,000-draw percentile bootstrap intervals. All samples are retained, including warmups. CPU 8 is pinned, and CPUs 6 and 7 are used for separate untimed profiles. The A/A control runs both labels on the exact same native binary and paths.

DHAT reports requested heap bytes alive simultaneously at its global high-water mark, plus the total requested bytes and allocation count over the whole process. It includes startup, base decoding, I/O, and final cleanup. One and two calls per process provide a difference for cumulative per-extra-call allocations without treating a sum of per-site high-water marks as simultaneous. Callgrind reports executed instructions and exact helper call-edge counts for one invocation on each size. The isolated odd 65-byte inputs exercise the single-byte append alongside the pair appends. Neither Valgrind mode contributes any wall sample. The runner captures the compiler's emitted LLVM and linker invocation for both arms.

