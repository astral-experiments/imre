# Private byte-output comparison on python-base45

Baseline `c198de1eae988e5c066a8dab33e772a518f25300` and candidate `ebe04843c252652469b71abebd62363e01a2a6d7` compiled the same upstream decoder and benchmark driver using Clang 18.1.3, whole-program LLVM, -O3, the explicit release runtime for each commit, and the system allocator. Each native process runs 2 MiB of raw data except the one-call empty startup control. Both executables ran on one pinned Linux CPU with the same tmpfs inputs, output paths, flags and warm OS file caches.

| Input, decoded size | Repetitions | Base median, ms | Candidate median, ms | Paired change (95% interval) |
|---|---:|---:|---:|---:|
| encode-64 | 32,768 | 22.388 | 21.522 | -4.14% [-4.89, -3.59] |
| decode-bytes-64 | 32,768 | 26.034 | 22.706 | -12.85% [-13.09, -12.61] |
| decode-text-64 | 32,768 | 25.793 | 22.784 | -12.00% [-12.13, -11.52] |
| encode-1024 | 2,048 | 15.470 | 15.319 | -1.48% [-2.05, -0.61] |
| decode-bytes-1024 | 2,048 | 20.576 | 18.201 | -11.69% [-12.17, -11.15] |
| decode-text-1024 | 2,048 | 20.658 | 18.334 | -11.77% [-11.92, -10.36] |
| encode-16384 | 128 | 14.385 | 14.398 | -0.04% [-0.59, +0.42] |
| decode-bytes-16384 | 128 | 20.970 | 18.005 | -13.88% [-14.11, -13.57] |
| decode-text-16384 | 128 | 20.833 | 17.977 | -13.68% [-13.97, -13.29] |
| encode-0 | 1 | 2.199 | 2.155 | -1.36% [-3.45, +0.56] |

36 measured AB/BA pairs after 6 warmups per operation and size. Each batch reproduced CPython’s entire output, checksum, exit code and stderr. The 95% intervals use 10,000 bootstrap samples stratified by pair order. The earlier three-case same-binary A/A run retains every calibration sample in meta/calibration.json.

The codec came from kirei/python-base45 at 5f49a519c3884a4fbc4c58c5c8f1fa25d7046020. Its upstream and vendored source SHA-256 was a22381be6391bd5b3aa9296fc3a2ba44e31ca19368bedb86f48f4f3bf8b42b9f.

## Heap and executed instructions

A separate Valgrind replay uses one call per process. Peak is simultaneously live requested heap at the global high-water mark. Extra allocations are the total block count for two calls minus one call on the same input. Callgrind instructions include all startup and file I/O.

| Operation, size | Peak heap B, base → candidate | Peak change | Extra-call allocation count, base → candidate | Callgrind instructions, base → candidate |
|---|---:|---:|---:|---:|
| encode-64 | 137,578 → 137,578 | +0.0% | 7 → 7 | 388,690 → 388,981 (+0.1%) |
| decode-bytes-64 | 140,024 → 139,464 | -0.4% | 2 → 3 | 394,954 → 394,043 (-0.2%) |
| decode-text-64 | 140,023 → 139,463 | -0.4% | 2 → 3 | 395,669 → 394,828 (-0.2%) |
| encode-1024 | 140,940 → 140,940 | +0.0% | 14 → 14 | 456,208 → 456,454 (+0.1%) |
| decode-bytes-1024 | 162,106 → 153,866 | -5.1% | 2 → 5 | 499,939 → 492,552 (-1.5%) |
| decode-text-1024 | 162,105 → 153,865 | -5.1% | 2 → 5 | 500,953 → 493,474 (-1.5%) |
| encode-16384 | 194,701 → 194,701 | +0.0% | 21 → 21 | 1,544,012 → 1,544,465 (+0.0%) |
| decode-bytes-16384 | 515,387 → 384,267 | -25.4% | 2 → 9 | 2,196,046 → 2,075,589 (-5.5%) |
| decode-text-16384 | 515,386 → 384,266 | -25.4% | 2 → 9 | 2,221,721 → 2,101,305 (-5.4%) |
| encode-0 | 137,353 → 137,353 | +0.0% | 1 → 1 | 380,911 → 381,168 (+0.1%) |
| decode-bytes-65 | 140,185 → 139,610 | -0.4% | 2 → 3 | 395,479 → 394,650 (-0.2%) |
| decode-text-65 | 140,184 → 139,609 | -0.4% | 2 → 3 | 396,336 → 395,445 (-0.2%) |

## Runtime calls

Counts came from executed Callgrind call edges on each actual application binary and input. The paired appends handle two output bytes and the 65-byte control reaches the scalar tail.

| Operation, size | Old list-pair appends | Old list→bytes | Candidate old list→bytes | New helper calls on candidate |
|---|---:|---:|---:|---|
| encode-64 | 0 | 0 | 0 | 0 |
| decode-bytes-64 | 32 | 1 | 0 | byte_output_append_pair=32, byte_output_finish=1, byte_output_new=1, byte_output_reserve_range=1 |
| decode-text-64 | 32 | 1 | 0 | byte_output_append_pair=32, byte_output_finish=1, byte_output_new=1, byte_output_reserve_range=1 |
| encode-1024 | 0 | 0 | 0 | 0 |
| decode-bytes-1024 | 512 | 1 | 0 | byte_output_append_pair=512, byte_output_finish=1, byte_output_new=1, byte_output_reserve_range=1 |
| decode-text-1024 | 512 | 1 | 0 | byte_output_append_pair=512, byte_output_finish=1, byte_output_new=1, byte_output_reserve_range=1 |
| encode-16384 | 0 | 0 | 0 | 0 |
| decode-bytes-16384 | 8,192 | 1 | 0 | byte_output_append_pair=8,192, byte_output_finish=1, byte_output_new=1, byte_output_reserve_range=1 |
| decode-text-16384 | 8,192 | 1 | 0 | byte_output_append_pair=8,192, byte_output_finish=1, byte_output_new=1, byte_output_reserve_range=1 |
| encode-0 | 0 | 0 | 0 | 0 |
| decode-bytes-65 | 32 | 1 | 0 | byte_output_append=1, byte_output_append_pair=32, byte_output_finish=1, byte_output_new=1, byte_output_reserve_range=1 |
| decode-text-65 | 32 | 1 | 0 | byte_output_append=1, byte_output_append_pair=32, byte_output_finish=1, byte_output_new=1, byte_output_reserve_range=1 |

## Correctness

- The base passed 5 upstream test methods, 323 native calls, 289 differential cases including exact exception class/message, suppression flag and cause class/message, and 2 compile-time type rejections.
- The candidate passed 5 upstream test methods, 323 native calls, 289 differential cases including exact exception class/message, suppression flag and cause class/message, and 2 compile-time type rejections.

The additional unmodified-codec scenarios injected −1, −256 and −2^65 through the exported mutable Base45 alphabet, checked errors that compete with out-of-range output, and restored the dictionary. Both native programs reproduced every line of the CPython replay, including all chained causes, and passed the repository’s shared-export, repeated-recovery and dictionary-deletion replay.

