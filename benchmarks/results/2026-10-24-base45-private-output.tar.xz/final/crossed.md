## Crossing baseline LLVM with the candidate runtime

The hybrid executable uses the baseline application's emitted LLVM and the candidate release runtime under the same Clang invocation. Relinking the baseline LLVM with its own runtime reproduced its executable byte for byte. Each arm ran all six permutations four times after six warmups, with every complete CPython output checked.

| Operation | Base ms | Hybrid ms | Candidate ms | Runtime-only change (95% interval) | Code-selection change on shared runtime (95% interval) |
|---|---:|---:|---:|---:|---:|
| encode-0 | 2.139 | 2.150 | 2.130 | +0.62% [-0.98,+2.88] | -0.87% [-2.37,+1.90] |
| decode-bytes-64 | 25.900 | 27.692 | 22.667 | +6.30% [+6.10,+7.07] | -18.24% [-18.50,-18.08] |
| decode-text-64 | 25.774 | 27.204 | 22.612 | +5.80% [+5.21,+6.19] | -17.00% [-17.27,-16.58] |
| encode-64 | 22.341 | 21.378 | 21.372 | -3.96% [-5.03,-3.10] | -0.42% [-0.91,+0.62] |
| decode-bytes-1024 | 20.552 | 22.078 | 18.055 | +7.27% [+6.90,+7.80] | -18.07% [-18.49,-17.79] |
| decode-text-1024 | 20.448 | 22.048 | 18.019 | +8.02% [+7.56,+8.27] | -18.12% [-18.39,-17.66] |
| encode-1024 | 15.440 | 15.240 | 15.224 | -1.19% [-1.61,-0.50] | -0.96% [-1.33,+0.15] |
| decode-bytes-16384 | 20.852 | 22.260 | 17.915 | +6.76% [+6.20,+7.75] | -19.65% [-19.98,-19.19] |
| decode-text-16384 | 20.762 | 22.226 | 17.848 | +7.10% [+6.63,+7.57] | -19.69% [-20.00,-19.44] |
| encode-16384 | 14.333 | 14.244 | 14.260 | -0.20% [-0.92,+0.68] | +0.09% [-0.46,+0.66] |
