| Short input | First→second call, incremental instructions (base → candidate) | Second→eighth call, instructions per extra call (base → candidate) |
|---|---:|---:|
| encode-64 | 7,396 → 7,274 | 7,058.5 → 7,072.0 |
| decode-bytes-64 | 8,715 → 8,261 | 8,627.5 → 8,043.8 |
| decode-text-64 | 8,541 → 7,977 | 8,679.3 → 8,085.3 |
