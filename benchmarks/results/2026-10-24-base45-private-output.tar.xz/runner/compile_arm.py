"""Build, record and validate the native codec and mutable-alphabet reproducer."""
import argparse, hashlib, json, os, platform, shutil, subprocess, sys
from pathlib import Path

p = argparse.ArgumentParser()
for opt in ("study", "compiler", "runtime"):
    p.add_argument("--" + opt, type=Path, required=True)
p.add_argument("--arm", choices=("base", "candidate"), required=True)
p.add_argument("--revision", required=True)
args = p.parse_args()
root = args.study.resolve()
out = root / args.arm
pkg = root / "source/examples/base45_codec"
out.mkdir(exist_ok=True)
env = {**os.environ, "TMPDIR": str(root/"scratch"), "RAYON_NUM_THREADS": "1", "LC_ALL":"C.UTF-8"}
for variable in ("RELARFLAGS", "RELAR_ENCODED_FLAGS", "LD_PRELOAD", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS"):
    env.pop(variable, None)
clang = "/usr/bin/clang-18"
def sha(path):
    with open(path, "rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()
def run(cmd):
    return subprocess.run(list(map(str,cmd)), cwd=root, env=env, capture_output=True, timeout=600)
def successful(cmd):
    result=run(cmd)
    if result.returncode:
        raise RuntimeError((cmd,result.returncode,result.stdout.decode(errors="replace"),result.stderr.decode(errors="replace")))
    return result
manifest={"revision":args.revision, "arm":args.arm, "release_compiler":str(args.compiler),"release_runtime":str(args.runtime),
          "compiler_sha256":sha(args.compiler),"runtime_sha256":sha(args.runtime),
          "clang_path":clang,"clang_sha256":sha(clang),"clang_version":successful([clang,"--version"]).stdout.decode().strip(),
          "linker":successful(["ld","--version"]).stdout.decode().splitlines()[0],
          "python":sys.version,"python_executable":sys.executable, "target":platform.machine(),"builds":{}}
for stem,entry in (("codec","driver.py"),("alphabet","byte_output_cases.py"),("recovery","checks.py")):
    target=out/stem
    llvm=out/(stem+".ll")
    cmd=[args.compiler,"build",pkg/entry,"--module-root",pkg,"--runtime",args.runtime,"--clang",clang,
         "--opt-level","3","--no-cache","--whole-program","--emit-llvm",llvm,"-o",target,"--verbose-link"]
    report=successful(cmd)
    (out/(stem+"-link.log")).write_bytes(report.stdout+report.stderr)
    manifest["builds"][stem]={"command":list(map(str,cmd)),"input_sha256":sha(pkg/entry),"binary_sha256":sha(target),"llvm_sha256":sha(llvm)}
    if stem=="codec":
        continue
    py=successful([sys.executable,"-I","-B","-c","import runpy, sys; sys.path.insert(0, sys.argv[1]); runpy.run_path(sys.argv[2],run_name='__main__')",pkg,pkg/entry])
    native=successful([target])
    (out/(stem+"-python.out")).write_bytes(py.stdout)
    (out/(stem+"-native.out")).write_bytes(native.stdout)
    if py.stderr or native.stderr or native.stdout!=py.stdout:
        raise AssertionError((stem,py.stderr,native.stderr,str(out/(stem+"-python.out")),str(out/(stem+"-native.out"))))
    manifest["builds"][stem]["verified_stdout_sha256"]=hashlib.sha256(native.stdout).hexdigest()
    manifest["builds"][stem]["verified_stdout_lines"]=len(native.stdout.splitlines())
validation=out/"validation.json"
cmd=[sys.executable,"-I","-B",root/"source/benchmarks/base45_validate.py","--binary",out/"codec","--compiler",args.compiler,"--output",validation]
v=successful(cmd)
assert not v.stderr,v.stderr
(out/"validate.log").write_bytes(v.stdout)
manifest["validation_command"]=list(map(str,cmd))
manifest["validation_sha256"]=sha(validation)
(out/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(v.stdout.decode(),flush=True)

