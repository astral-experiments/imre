"""Observe real published Base45 behavior with a temporarily modified exported alphabet."""
from base45 import BASE45_DICT, b45decode


def category(error: Exception) -> str:
    if isinstance(error, UnicodeDecodeError):
        return "UnicodeDecodeError"
    if isinstance(error, KeyError):
        return "KeyError"
    if isinstance(error, ValueError):
        return "ValueError"
    return "Exception"


def decode(value: bytes | str) -> None:
    try:
        output = b45decode(value)
    except ValueError as error:
        print(category(error))
        print(str(error))
        print(error.__suppress_context__)
        cause = error.__cause__
        if cause is None:
            print("None")
            print("")
        else:
            print(category(cause))
            print(str(cause))
    else:
        print("OK")
        print(output)


def run() -> None:
    for negative in [-1, -256, -(1 << 65)]:
        BASE45_DICT["0"] = negative
        for text in ["001", "000", "00", "ABC000", "000000", "000:::", "000::", "00000", "000a", "0000", "000\n"]:
            decode(text)
            decode(text.encode())
    BASE45_DICT["0"] = 0
    for text in ["00", "BB8", "BB8\n\n"]:
        decode(text)
        decode(text.encode())


run()

