"""A/A check of the timer and per-invocation output validation."""
import json
import os
from pathlib import Path
import random
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import benchmark as harness

root=Path(sys.argv[1]);os.sched_setaffinity(0,{int(sys.argv[2]) if len(sys.argv)>2 else 8})
cases={c["label"]:c for c in json.loads((root/"meta/inputs.json").read_bytes())}
chosen=("decode-bytes-16384","decode-text-64","encode-1024")
out=root/"scratch/calibration";out.mkdir(parents=True,exist_ok=True)
rows=[]
rng=random.Random(77531)
orders={}
for label in chosen:
    orders[label]=[]
    for _ in range(8):
        block=[["base","candidate"],["candidate","base"]]
        rng.shuffle(block);orders[label].extend(block)
for i in range(-4,12):
    labels=list(chosen);rng.shuffle(labels)
    for label in labels:
        c=cases[label];order=orders[label][i+4]
        for arm in order:
            obs=harness.cli(root,out,"base",c,c["repetitions"])
            rows.append({"label":label,"arm":arm,"pair":i,"order":order,**obs})
r={"binary_sha256":harness.digest(root/"base/codec"),"arms":"Both are the exact base binary","pairs":12,"warmups":4,"rows":rows,
   "summary":{k:harness.compare([r for r in rows if r["label"]==k]) for k in chosen}}
harness.dump(root/"meta/calibration.json",r)
print({k:round(v["paired_candidate_percent"],2) for k,v in r["summary"].items()})

