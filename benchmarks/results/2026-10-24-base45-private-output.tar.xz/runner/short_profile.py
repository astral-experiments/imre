"""Subtract matched one- and two-call instruction/allocator profiles for the short-input regression."""
import argparse,json,os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from benchmark import cli, digest, dump
from profile import callgraph
p=argparse.ArgumentParser(description=__doc__)
p.add_argument("root",type=Path);p.add_argument("--cpu",type=int,default=7)
a=p.parse_args();root=a.root;os.sched_setaffinity(0,{a.cpu})
cases=[c for c in json.loads((root/"meta/inputs.json").read_bytes()) if c["label"] in ("encode-64","decode-bytes-64","decode-text-64")]
wd=root/"scratch/short-control";wd.mkdir(parents=True,exist_ok=True)
out=root/"short-control";out.mkdir(exist_ok=True)
raw={}
for arm in ("base","candidate"):
    for case in cases:
        label=case["label"];series={}
        for n in (1,2,8):
            name=f"{arm}-{label}-{n}";trace=out/(name+".trace");log=out/(name+".log")
            prefix=["/usr/bin/valgrind","--tool=callgrind","--trace-children=no",f"--log-file={log}",f"--callgrind-out-file={trace}"]
            observation=cli(root,wd,arm,case,n,prefix)
            series[n]={**callgraph(trace),"trace_sha256":digest(trace),"expected_and_actual_sha256":observation["expected_and_actual_sha256"]}
        raw[f"{arm}-{label}"]=series
dump(root/"short-profile.json",raw)
lines=["| Short input | First→second call, incremental instructions (base → candidate) | Second→eighth call, instructions per extra call (base → candidate) |",
       "|---|---:|---:|"]
for c in cases:
    label=c["label"];v=[raw[f"{arm}-{label}"] for arm in ("base","candidate")]
    d1=[r[2]["instructions"]-r[1]["instructions"] for r in v]
    d6=[(r[8]["instructions"]-r[2]["instructions"])/6 for r in v]
    lines.append(f"| {label} | {d1[0]:,} → {d1[1]:,} | {d6[0]:,.1f} → {d6[1]:,.1f} |")
(root/"short-profile.md").write_text("\n".join([*lines,""]))

