"""Gate the final wall panel on A/A child-CPU residency; retain both schedules."""
import argparse,json,os
from pathlib import Path
import subprocess,sys,time
p=argparse.ArgumentParser(description=__doc__);p.add_argument("root",type=Path);p.add_argument("--cpu",type=int,default=8);p.add_argument("--archive-name",default="final")
a=p.parse_args();root=a.root;py=sys.executable
os.sched_setaffinity(0,{a.cpu})
def dump(path,data):
    path.write_text(json.dumps(data,indent=2)+"\n")
def cmd(script,args,out):
    with (root/out).open("wb") as f:
        subprocess.run([py,"-I","-B",str(root/script),*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=420)
def state():
    path=Path("/proc/stat")
    return {"monotonic_ns":time.monotonic_ns(),"time_ns":time.time_ns(),"loadavg":os.getloadavg(),
            "cpu_line":next(s for s in path.read_text().splitlines() if s.startswith("cpu"+str(a.cpu)+" ")),
            "cpu_affinity":sorted(os.sched_getaffinity(0)),"host":list(os.uname())}
def persisted(src,dst):
    (root/dst).write_bytes((root/src).read_bytes())
meta={"cpu":a.cpu,"policy":"Require >= 90% median child CPU/wall on each sustained decoder and >= 85% on each encoding control, which has a shorter process lifetime. The earlier quiet v1 encoder control observed 89.6%.","before_aa":state()}
cmd("calibrate.py",[root,a.cpu],"meta/"+a.archive_name+"-aa.log")
meta["after_aa"]=state()
persisted("meta/calibration.json","calibration.json")
cmd("sched_summary.py",["--source",root/"calibration.json","--out",root/"calibration-scheduler.json","--cpu",a.cpu],"meta/"+a.archive_name+"-aa-scheduler.log")
aa=json.loads((root/"calibration-scheduler.json").read_bytes())
aa_share=min(v["median_child_cpu_share"] for vals in aa["summary"].values() for v in vals.values())
meta["aa_min_median_cpu_share"]=aa_share
dump(root/("meta/"+a.archive_name+"-environment.json"),meta)
if aa_share < .90:
    raise RuntimeError(f"A/A residency too low ({aa_share:.2%}); preserve its samples and choose a quiet core.")
meta["before_primary"]=state()
cmd("benchmark.py",["timing","--study",root,"--cpu",a.cpu,"--pairs",36,"--warmups",6],"timings.log")
meta["after_primary"]=state()
cmd("sched_summary.py",["--source",root/"timings.json","--out",root/"scheduler.json","--cpu",a.cpu],"meta/"+a.archive_name+"-scheduler.log")
summary=json.loads((root/"scheduler.json").read_bytes())
shares=[v["median_child_cpu_share"] for key,vals in summary["summary"].items() if key!="encode-0" for v in vals.values()]
meta["primary_min_median_child_cpu_share"]=min(shares)
meta["primary_max_median_child_cpu_share"]=max(shares)
dump(root/("meta/"+a.archive_name+"-environment.json"),meta)
print("A/A minimum median",aa_share,"primary min/max medians",min(shares),max(shares))
for key,vals in summary["summary"].items():
    if key=="encode-0": continue
    cutoff=.90 if key.startswith("decode-") else .85
    for arm,row in vals.items():
        if row["median_child_cpu_share"]<cutoff:
            raise RuntimeError(f"Quiet confirmation has {key}/{arm} below its advance CPU-residency threshold {cutoff:.0%}.")

