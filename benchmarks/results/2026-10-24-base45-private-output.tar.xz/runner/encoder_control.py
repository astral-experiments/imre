"""Check LLVM, object instructions and executable addresses for the untargeted encoder."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root=Path(sys.argv[1]);records={}
def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()
def llvm_body(s):
    functions=re.findall(r"^define [^\n]+ \{\n.*?^\}$",s,re.MULTILINE|re.DOTALL)
    selected=[x for x in functions if "@imre_str_append_utf8_owned(" in x]
    assert len(selected)==1
    return selected[0]
def asm_body(binary, symbol):
    raw=subprocess.check_output(["objdump","-d","--no-show-raw-insn","--disassemble="+symbol,binary],text=True)
    target=[]
    elf=binary.read_bytes()
    ro=re.search(r"\.rodata\s+PROGBITS\s+([0-9a-f]+)\s+([0-9a-f]+)",subprocess.check_output(["readelf","-WS",binary],text=True))
    alphabet=b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"
    assert ro
    for row in raw.splitlines():
        m=re.match(r"^\s*[0-9a-f]+:\s+(.*)",row)
        if not m: continue
        s=m[1].strip()
        # Symbol annotations identify all relative calls/branches. Keep constants such as 45.
        ref=re.search(r"# ([0-9a-f]+) <_fini\+0x[0-9a-f]+>",s)
        if ref:
            offset=int(ref[1],16)-int(ro[1],16)+int(ro[2],16)
            if elf[offset:offset+len(alphabet)]==alphabet:
                s=s[:ref.start()]+"# <verified-45-byte-base45-alphabet>"
        s=re.sub(r"\b[0-9a-f]+ (<[^>]+>)",r"\1",s)
        if "#" in s and "<" in s:
            s=re.sub(r"-?0x[0-9a-f]+\(%rip\)","RIP(%rip)",s)
        target.append(s)
    assert target
    return "\n".join(target)
for arm in ("base","candidate"):
    body=llvm_body((root/arm/"codec.ll").read_text())
    symbol=re.search(r"@(\w+)\(",body).group(1)
    nm=subprocess.check_output(["nm","-an",root/arm/"codec"],text=True)
    address=next(l.split()[0] for l in nm.splitlines() if l.endswith(" "+symbol))
    asm=asm_body(root/arm/"codec",symbol)
    for label,value in (("encoder-llvm.txt",body),("encoder-disassembly.txt",asm)):
        (root/arm/label).write_text(value+"\n")
    records[arm]={"symbol":symbol,"llvm_sha256":sha(body),"normalized_assembly_sha256":sha(asm),"linked_address":address}
for field in ("llvm_sha256","normalized_assembly_sha256","linked_address"):
    records[field+"_matches"]=records["base"][field]==records["candidate"][field]
(root/"meta/encoder-control.json").write_text(json.dumps(records,indent=2)+"\n")
print(json.dumps(records))

