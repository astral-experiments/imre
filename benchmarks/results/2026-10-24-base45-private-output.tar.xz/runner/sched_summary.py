"""Summarize child CPU divided by wall time separately from the paired effect."""
import argparse,json,os
from pathlib import Path
import platform,statistics,subprocess,time
p=argparse.ArgumentParser(description=__doc__)
p.add_argument("--source",type=Path,required=True)
p.add_argument("--out",type=Path,required=True)
p.add_argument("--cpu",type=int,default=8)
a=p.parse_args()
r=json.loads(a.source.read_bytes())
arms=sorted({x["arm"] for x in r["rows"]})
labels=sorted({x["label"] for x in r["rows"]})
body={}
for label in labels:
    body[label]={}
    for arm in arms:
        vals=[x for x in r["rows"] if x["arm"]==arm and x["label"]==label and x["pair"]>=0]
        shares=[(v["user_ns"]+v["system_ns"])/v["wall_ns"] for v in vals]
        body[label][arm]={"samples":len(vals),"median_child_cpu_share":statistics.median(shares),
                          "p10_child_cpu_share":sorted(shares)[max(0,len(shares)//10-1)],
                          "median_child_cpu_ms":statistics.median((x["user_ns"]+x["system_ns"])/1e6 for x in vals),
                          "median_wall_ms":statistics.median(x["wall_ns"]/1e6 for x in vals),
                          "under_90_percent":sum(x<.90 for x in shares)}
def get(path):
    p=Path(path)
    try:return p.read_text().strip()
    except OSError:return None
cpu=f"/sys/devices/system/cpu/cpu{a.cpu}"
host={"model":next(l.split(":",1)[1].strip() for l in Path("/proc/cpuinfo").read_text().splitlines() if l.startswith("model name")),
      "uname":list(os.uname()),"logical_cpu":a.cpu,"thread_siblings":get(cpu+"/topology/thread_siblings_list"),
      "governor":get(cpu+"/cpufreq/scaling_governor"),"allowed_to_this_reader":sorted(os.sched_getaffinity(0)),
      "python":platform.python_version(),"clang":subprocess.check_output(["clang-18","--version"],text=True).splitlines()[0],
      "load_start":r.get("load_start"),"load_end":r.get("load_end"),
      "recorded_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
a.out.write_text(json.dumps({"host":host,"summary":body},indent=2)+"\n")
print([(label,round(min(s["median_child_cpu_share"] for s in vals.values()),3)) for label,vals in body.items()])

