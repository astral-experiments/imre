"""Cross the parent LLVM with the candidate runtime to separate code selection from runtime effects."""
import argparse
import itertools
import json
import os
from pathlib import Path
import random
import shlex
import shutil
import statistics
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from benchmark import cli, compare, digest, dump


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--study",type=Path,required=True)
    p.add_argument("--runtime",type=Path,required=True)
    p.add_argument("--base-runtime",type=Path,required=True)
    p.add_argument("--cpu",type=int,default=8)
    a=p.parse_args()
    root=a.study; os.sched_setaffinity(0,{a.cpu})
    wd=root/"scratch/crossed";wd.mkdir(parents=True,exist_ok=True)
    (root/"hybrid").mkdir(exist_ok=True)
    base=root/"base/codec";same=wd/"rebuilt-base";hybrid=root/"hybrid/codec"
    original_cmd=next(shlex.split(line) for line in (root/"base/codec-link.log").read_text().splitlines() if line.startswith('"'))
    ir_path=Path(next(arg for arg in original_cmd if arg.endswith(".ll")))
    if ir_path.exists():
        assert digest(ir_path)==digest(root/"base/codec.ll"),ir_path
    else:
        shutil.copyfile(root/"base/codec.ll",ir_path)
    def link(runtime,path):
        cmd=["/usr/bin/clang-18","-O3","-Wno-override-module",ir_path,runtime,
             "-ldl","-lpthread","-lm","-lrt","-lutil","-Wl,--gc-sections","-Wl,-z,relro,-z,now","-o",path]
        proc=subprocess.run(list(map(str,cmd)),capture_output=True)
        assert proc.returncode==0 and not proc.stderr and not proc.stdout,(cmd,proc)
        return list(map(str,cmd))
    base_link=link(a.base_runtime,same);hybrid_link=link(a.runtime,hybrid)
    assert digest(base)==digest(same),(digest(base),digest(same))
    arms=("base","hybrid","candidate")
    cases=[c for c in json.loads((root/"meta/inputs.json").read_bytes()) if c["subset"]!="odd-tail-mechanism"]
    rng=random.Random(923644)
    orders={}
    for case in cases:
        schedule=[]
        for i in range(5):
            block=list(itertools.permutations(arms));rng.shuffle(block);schedule.extend(block)
        orders[case["label"]]=schedule
    rows=[]
    record={"baseline_relink_cmd":base_link,"hybrid_link_cmd":hybrid_link,"identical_baseline_relink":True,"cpu":a.cpu,
            "warmups":6,"pairs":24,"binary_sha256":{k:digest(root/k/"codec") for k in arms},
            "baseline_runtime_sha256":digest(a.base_runtime),"candidate_runtime_sha256":digest(a.runtime),"rows":rows}
    for pair in range(-6,24):
        cases=list(cases);rng.shuffle(cases)
        for case in cases:
            order=orders[case["label"]][pair+6]
            for arm in order:
                r=cli(root,wd,arm,case,case["repetitions"])
                rows.append({"arm":arm,"label":case["label"],"pair":pair,"order":order,**r})
        dump(root/"crossed.json",record);print("crossed round",pair,flush=True)
    summaries={}
    lines=["## Crossing baseline LLVM with the candidate runtime","",
           "The hybrid executable uses the baseline application's emitted LLVM and the candidate release runtime under the same Clang invocation. "
           "Relinking the baseline LLVM with its own runtime reproduced its executable byte for byte. "
           "Each arm ran all six permutations four times after six warmups, with every complete CPython output checked.", "",
           "| Operation | Base ms | Hybrid ms | Candidate ms | Runtime-only change (95% interval) | Code-selection change on shared runtime (95% interval) |",
           "|---|---:|---:|---:|---:|---:|"]
    for case in sorted(cases,key=lambda c:(c["raw_bytes"],c["operation"])):
        label=case["label"]
        def summary(first,second):
            converted=[]
            for r in rows:
                if r["label"]!=label or r["arm"] not in (first,second):continue
                rename={first:"base",second:"candidate"}
                converted.append({**r,"arm":rename[r["arm"]],"order":[rename[k] for k in r["order"] if k in rename]})
            return compare(converted)
        results={k:summary(*v) for k,v in {"runtime":("base","hybrid"),"selection":("hybrid","candidate"),"combined":("base","candidate")}.items()}
        summaries[label]=results
        def delta(r):
            lo,hi=r["paired_percent_interval"]
            return f"{r['paired_candidate_percent']:+.2f}% [{lo:+.2f},{hi:+.2f}]"
        med=results["combined"]["median_ms"]; h=results["runtime"]["median_ms"]["candidate"]
        lines.append(f"| {label} | {med['base']:.3f} | {h:.3f} | {med['candidate']:.3f} | {delta(results['runtime'])} | {delta(results['selection'])} |")
    record["summary"]=summaries;dump(root/"crossed.json",record)
    (root/"crossed.md").write_text("\n".join([*lines,""]))


if __name__=="__main__":
    main()

