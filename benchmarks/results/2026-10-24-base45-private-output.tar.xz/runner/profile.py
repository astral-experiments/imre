"""Independent heap and instruction traces on the exact timed native binaries."""
import argparse
import collections
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from benchmark import artifact, cli, digest, dump


def callgraph(trace):
    lines=trace.read_text().splitlines()
    names={}
    for line in lines:
        m=re.match(r"c?fn=\((\d+)\) (.+)",line)
        if m: names[m[1]]=m[2]
    counts=collections.Counter()
    for i,line in enumerate(lines):
        m=re.match(r"cfn=\((\d+)\)(?: .+)?$",line)
        if m:
            nextrow=lines[i+1]
            assert nextrow.startswith("calls="),(line,nextrow)
            symbol=names.get(m[1],m[1])
            counts[symbol]+=int(nextrow.split()[0][6:])
    return {"instructions":int(next(l.split()[1] for l in lines if l.startswith("summary:"))),
            "runtime_calls":{n:c for n,c in sorted(counts.items()) if n.startswith("relar_")}}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode",choices=("dhat","callgrind"))
    p.add_argument("--arm",choices=("base","candidate"),required=True)
    p.add_argument("--study",type=Path,required=True)
    p.add_argument("--cpu",type=int,default=6)
    a=p.parse_args()
    os.sched_setaffinity(0,{a.cpu})
    root=a.study
    wd=root/"scratch"/(a.mode+"-active")
    wd.mkdir(parents=True,exist_ok=True)
    out=root/a.arm/a.mode;out.mkdir(exist_ok=True)
    cases=json.loads((root/"meta/inputs.json").read_bytes())
    record={"binary_sha256":digest(artifact(root,a.arm)),"input_manifest_sha256":digest(root/"meta/inputs.json"),
            "cpu":a.cpu,"valgrind":subprocess.check_output(["valgrind","--version"],text=True).strip(),"observations":[]}
    for case in cases:
        for reps in ((1,2) if a.mode=="dhat" else (1,)):
            key=f"{case['label']}-r{reps}"
            trace=out/(key+".trace")
            log=out/(key+".log")
            prefix=["/usr/bin/valgrind","--tool="+a.mode,"--trace-children=no",f"--log-file={log}"]
            if a.mode=="dhat":
                prefix+=["--mode=heap",f"--dhat-out-file={trace}"]
            else:
                prefix+=[f"--callgrind-out-file={trace}"]
            obs=cli(root,wd,a.arm,case,reps,prefix)
            row={"label":case["label"],"repetitions":reps,"stdout":obs["stdout"],
                 "expected_and_actual_sha256":obs["expected_and_actual_sha256"],"trace_sha256":digest(trace),"log_sha256":digest(log)}
            if a.mode=="dhat":
                raw=json.loads(trace.read_bytes())
                assert raw["mode"]=="heap"
                row.update({k:sum(pp[k] for pp in raw["pps"]) for k in ("tb","tbk","gb","gbk","eb","ebk")})
            else:
                row.update(callgraph(trace))
            record["observations"].append(row)
            dump(root/a.arm/(a.mode+".json"),record)
        print(a.arm,a.mode,case["label"],flush=True)


if __name__=="__main__":
    main()

