"""Paired native runtimes using the unchanged Relar Base45 inputs and CPython outcomes."""
import argparse
import base64
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import random
import resource
import runpy
import shutil
import statistics
import subprocess
import sys
import time


def digest(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def dump(path, data):
    path.write_text(json.dumps(data, indent=1) + "\n")


def prepare(root):
    src = root / "source"
    pkg = src / "examples/base45_codec"
    stock=runpy.run_path(str(src/"benchmarks/base45_benchmark.py"))
    validator=stock["validator"]
    codec,_=validator.load_upstream_tests()
    cases=stock["workloads"](codec, 2*1024*1024)
    rng=random.Random(9551)
    for length in (0,65):
        raw=rng.randbytes(length)
        encoded=codec.b45encode(raw)
        for op in (("encode",) if length==0 else ("decode-bytes","decode-text")):
            data=raw if op=="encode" else encoded
            n=1
            oracle=validator.oracle(codec,op,data,n)
            cases.append({"label":f"{op}-{length}","operation":op,"raw_bytes":length,"repetitions":n,
                          "input_base64":base64.b64encode(data).decode(),"expected_stdout":oracle["stdout"],
                          "expected_output_sha256":validator.digest(oracle["output"]),"expected_output_bytes":len(oracle["output"]),
                          "subset":"startup" if length==0 else "odd-tail-mechanism"})
    records=[]
    for case in cases:
        case=dict(case)
        label=case["label"]
        folder=root/"inputs"/label; folder.mkdir(parents=True,exist_ok=True)
        data=base64.b64decode(case.pop("input_base64"))
        (folder/"input").write_bytes(data)
        (folder/"expected").write_bytes(b"untouched by CPython")
        cmd=[*validator.python_command(sys.executable),case["operation"],str(folder/"input"),str(folder/"expected"),str(case["repetitions"])]
        healthy=subprocess.run(cmd,capture_output=True,timeout=60)
        assert healthy.returncode==0 and not healthy.stderr and healthy.stdout.decode()==case["expected_stdout"],(label,healthy)
        assert digest(folder/"expected")==case["expected_output_sha256"]
        case["input_sha256"]=digest(folder/"input");case["input_bytes"]=len(data)
        case["subset"]=case.get("subset","decode" if case["operation"]!="encode" else "encode control")
        case["one_call_stdout"]=validator.oracle(codec,case["operation"],data,1)["stdout"]
        records.append(case)
    dump(root/"meta/inputs.json",records)
    print("validated actual CPython process output for",len(records),"distinct operation/size workloads",flush=True)


def artifact(root, arm):
    return root / arm / "codec"


def cli(root, wd, arm, case, reps, prefix=()):
    link=wd/"codec"
    # Every arm sees the same executable name, argument lengths and file contents.
    if link.is_symlink(): link.unlink()
    link.symlink_to(artifact(root,arm).resolve())
    expected=root/"inputs"/case["label"]/"expected"
    infile=root/"inputs"/case["label"]/"input"
    outfile=wd/"output"
    outfile.write_bytes(b"untouched")
    cmd=[*prefix,str(link),case["operation"],str(infile),str(outfile),str(reps)]
    before=resource.getrusage(resource.RUSAGE_CHILDREN)
    start=time.perf_counter_ns()
    proc=subprocess.run(cmd,input=b"",capture_output=True,cwd=wd,timeout=120,env={**os.environ,"LC_ALL":"C.UTF-8"})
    elapsed=time.perf_counter_ns()-start
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    stdout="OK\n"+str(int(case["one_call_stdout"].splitlines()[1])*reps)+"\n"
    assert proc.returncode==0 and not proc.stderr and proc.stdout.decode()==stdout,(arm,case["label"],proc)
    assert outfile.read_bytes()==expected.read_bytes() and digest(infile)==case["input_sha256"]
    return {"wall_ns":elapsed,"user_ns":round(1e9*(after.ru_utime-before.ru_utime)),
            "system_ns":round(1e9*(after.ru_stime-before.ru_stime)),"minor_faults":after.ru_minflt-before.ru_minflt,
            "major_faults":after.ru_majflt-before.ru_majflt,"voluntary_switches":after.ru_nvcsw-before.ru_nvcsw,
            "involuntary_switches":after.ru_nivcsw-before.ru_nivcsw,
            "expected_and_actual_sha256":digest(outfile),"stdout":proc.stdout.decode(),"stderr":"","returncode":0}


def bootstrap(groups):
    rng=random.Random(9431)
    results=sorted(statistics.median(rng.choices(groups["base"],k=len(groups["base"]))
                                     +rng.choices(groups["candidate"],k=len(groups["candidate"]))) for _ in range(10000))
    return [results[249],results[9749]]


def compare(rows):
    phases=[r for r in rows if r["pair"]>=0]
    byarm={a:[r["wall_ns"]/1e6 for r in phases if r["arm"]==a] for a in ("base","candidate")}
    groups={a:[] for a in byarm}
    differences={a:[] for a in byarm}
    for i in range(len(phases)//2):
        pair={r["arm"]:r for r in phases if r["pair"]==i}
        first=pair["base"]["order"][0]
        base,can=pair["base"]["wall_ns"],pair["candidate"]["wall_ns"]
        groups[first].append((can/base-1)*100)
        differences[first].append((can-base)/1e6)
    assert len(groups["base"])==len(groups["candidate"]) and groups["base"]
    def p95(xs):
        return sorted(xs)[math.ceil(.95*len(xs))-1]
    return {"pairs":len(phases)//2,"median_ms":{a:statistics.median(v) for a,v in byarm.items()},
            "p95_ms":{a:p95(v) for a,v in byarm.items()},
            "paired_candidate_percent":statistics.median(groups["base"]+groups["candidate"]),
            "paired_percent_interval":bootstrap(groups),"paired_difference_ms":statistics.median(differences["base"]+differences["candidate"]),
            "paired_difference_interval_ms":bootstrap(differences)}


def timing(root, cpu, pairs, warmups):
    wd=root/"scratch/timing";wd.mkdir(parents=True,exist_ok=True)
    rows=[]
    cases=[x for x in json.loads((root/"meta/inputs.json").read_bytes()) if x["subset"]!="odd-tail-mechanism"]
    rng=random.Random(12819)
    schedules={}
    for case in cases:
        order=[]
        for _ in range((pairs+warmups)//2):
            pair_order=[["base","candidate"],["candidate","base"]]
            rng.shuffle(pair_order);order.extend(pair_order)
        schedules[case["label"]]=order
    data={"cpu":cpu,"pairs":pairs,"warmups":warmups,"input_manifest_sha256":digest(root/"meta/inputs.json"),
          "binary_sha256":{a:digest(artifact(root,a)) for a in ("base","candidate")},
          "host":os.uname()._asdict() if hasattr(os.uname(),"_asdict") else list(os.uname()),
          "cpu_model":next(l.split(":",1)[1].strip() for l in Path("/proc/cpuinfo").read_text().splitlines() if l.startswith("model name")),
          "python":sys.version,"load_start":os.getloadavg(),"rows":rows}
    for pair in range(-warmups,pairs):
        shuffled=list(cases);rng.shuffle(shuffled)
        for case in shuffled:
            order=schedules[case["label"]][pair+warmups]
            for arm in order:
                obs=cli(root,wd,arm,case,case["repetitions"])
                rows.append({"label":case["label"],"pair":pair,"arm":arm,"order":order,**obs})
        dump(root/"timings.json",data)
        print("complete round",pair,flush=True)
    data["load_end"]=os.getloadavg()
    data["summary"]={c["label"]:compare([r for r in rows if r["label"]==c["label"]]) for c in cases}
    dump(root/"timings.json",data)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode",choices=("prepare","timing"))
    parser.add_argument("--study",type=Path,required=True)
    parser.add_argument("--cpu",type=int,default=8)
    parser.add_argument("--pairs",type=int,default=36)
    parser.add_argument("--warmups",type=int,default=6)
    a=parser.parse_args()
    assert a.pairs>0 and a.warmups>=2 and a.pairs%2==a.warmups%2==0
    os.sched_setaffinity(0,{a.cpu})
    if a.mode=="prepare": prepare(a.study)
    else: timing(a.study,a.cpu,a.pairs,a.warmups)


if __name__=="__main__":
    main()

