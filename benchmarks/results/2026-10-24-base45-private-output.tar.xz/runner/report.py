"""Render the paired times, memory and dynamic paths from their separate raw observations."""
import json
import math
from pathlib import Path
import re
import statistics
import sys

root=Path(sys.argv[1])
def load(p):
    return json.loads((root/p).read_bytes())
def write(p,lines):
    (root/p).write_text("\n".join([*lines,""]))
tim=load("timings.json")
cases=load("meta/inputs.json")
manifest={a:load(f"{a}/manifest.json") for a in ("base","candidate")}
names=[c["label"] for c in cases if c["subset"]!="odd-tail-mechanism"]
assert len(tim["rows"])==(tim["pairs"]+tim["warmups"])*2*len(names)
lines=["# Private byte-output comparison on python-base45", "",
       f"Baseline `{manifest['base']['revision']}` and candidate `{manifest['candidate']['revision']}` "
       f"compiled the same upstream decoder and benchmark driver using Clang 18.1.3, whole-program LLVM, -O3, "
       "the explicit release runtime for each commit, and the system allocator. Each native process runs "
       "2 MiB of raw data except the one-call empty startup control. Both executables ran on one pinned Linux CPU "
       "with the same tmpfs inputs, output paths, flags and warm OS file caches.", "",
       "| Input, decoded size | Repetitions | Base median, ms | Candidate median, ms | Paired change (95% interval) |",
       "|---|---:|---:|---:|---:|"]
for name in names:
    c=next(c for c in cases if c["label"]==name);s=tim["summary"][name]
    b,k=s["median_ms"]["base"],s["median_ms"]["candidate"]
    lo,hi=s["paired_percent_interval"]
    lines.append(f"| {name} | {c['repetitions']:,} | {b:.3f} | {k:.3f} | {s['paired_candidate_percent']:+.2f}% [{lo:+.2f}, {hi:+.2f}] |")
lines+=["",f"{tim['pairs']} measured AB/BA pairs after {tim['warmups']} warmups per operation and size. "
        "Each batch reproduced CPython’s entire output, checksum, exit code and stderr. The 95% intervals "
        "use 10,000 bootstrap samples stratified by pair order. The earlier three-case same-binary A/A run "
        "retains every calibration sample in meta/calibration.json.", "",
        "The codec came from kirei/python-base45 at 5f49a519c3884a4fbc4c58c5c8f1fa25d7046020. "
        "Its upstream and vendored source SHA-256 was a22381be6391bd5b3aa9296fc3a2ba44e31ca19368bedb86f48f4f3bf8b42b9f.", ""]
dhat={a:{(r["label"],r["repetitions"]):r for r in load(f"{a}/dhat.json")["observations"]} for a in manifest}
cg={a:{r["label"]:r for r in load(f"{a}/callgrind.json")["observations"]} for a in manifest}
lines+=["## Heap and executed instructions", "",
        "A separate Valgrind replay uses one call per process. Peak is simultaneously live requested heap at "
        "the global high-water mark. Extra allocations are the total block count for two calls minus one "
        "call on the same input. Callgrind instructions include all startup and file I/O.", "",
        "| Operation, size | Peak heap B, base → candidate | Peak change | Extra-call allocation count, base → candidate | Callgrind instructions, base → candidate |",
        "|---|---:|---:|---:|---:|"]
for c in cases:
    name=c["label"];b,k=[dhat[a][name,1]["gb"] for a in manifest]
    bn,kn=[dhat[a][name,2]["tbk"]-dhat[a][name,1]["tbk"] for a in manifest]
    bi,ki=[cg[a][name]["instructions"] for a in manifest]
    lines.append(f"| {name} | {b:,} → {k:,} | {(k/b-1)*100:+.1f}% | {bn:,} → {kn:,} | {bi:,} → {ki:,} ({(ki/bi-1)*100:+.1f}%) |")
symbols={}
for arm in manifest:
    text=(root/arm/"codec.ll").read_text()
    symbols[arm]=set(re.findall(r"\b(?:call|invoke) \w+ @(imre_\w+)\(",text))
new=symbols["candidate"]-symbols["base"]
new_relevant=sorted(s for s in new if any(word in s for word in ("byte","builder","output")))
observed_new=sorted(s for s in new_relevant if any(cg["candidate"][c["label"]]["runtime_calls"].get(s,0) for c in cases))
lines+=["", "## Runtime calls", "",
        "Counts came from executed Callgrind call edges on each actual application binary and input. "
        "The paired appends handle two output bytes and the 65-byte control reaches the scalar tail.", "",
        "| Operation, size | Old list-pair appends | Old list→bytes | Candidate old list→bytes | New helper calls on candidate |",
        "|---|---:|---:|---:|---|"]
for c in cases:
    name=c["label"];b,k=[cg[a][name]["runtime_calls"] for a in manifest]
    descriptor=", ".join(f"{s.removeprefix('imre_')}={k[s]:,}" for s in observed_new if k.get(s)) or "0"
    lines.append(f"| {name} | {b.get('imre_list_append_pair',0):,} | {b.get('imre_bytes_list',0):,} | {k.get('imre_bytes_list',0):,} | {descriptor} |")
lines.extend(["", "## Correctness", ""])
for arm,m in manifest.items():
    v=load(f"{arm}/validation.json")
    lines.append(f"- The {arm} passed {v['upstream_cpython']['methods']} upstream test methods, "
                 f"{v['native_adapter_calls']} native calls, {len(v['differential_cases'])} differential cases including exact "
                 f"exception class/message, suppression flag and cause class/message, and {len(v['wrong_typed_compile_rejections'])} compile-time type rejections.")
assert manifest["base"]["builds"]["alphabet"]["verified_stdout_sha256"]==manifest["candidate"]["builds"]["alphabet"]["verified_stdout_sha256"]
lines.extend(["", "The additional unmodified-codec scenarios injected −1, −256 and −2^65 through the exported mutable "
              "Base45 alphabet, checked errors that compete with out-of-range output, and restored the dictionary. "
              "Both native programs reproduced every line of the CPython replay, including all chained causes, "
              "and passed the repository’s shared-export, repeated-recovery and dictionary-deletion replay.", ""])
write("report.md",lines)

