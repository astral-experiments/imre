# Portable native-tool evidence

Run `python3.14 -B native_tools_evidence.py replay . --output /tmp/replay.json`. Use CPython 3.14 or newer with assertions enabled. No network, checkout, Git, native compiler, or benchmark executable is needed.

The index maps original path identities to immutable content-addressed blobs. Reports, commands, manifests, and raw ty streams retain their original bytes. The replay reconstructs upstream outputs and checks every timing capture, balanced order, statistic, source binding, and shared-mode input.

Native binaries and toolchains under `external` were hashed by the live audit and package creation. They are deliberately excluded and are **not rehashed by portable replay**. This verifies retained evidence, not a new benchmark run. License texts are indexed under `licenses`; upstream revisions and copyright notices remain in the source/provenance blobs.
