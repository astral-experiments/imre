"""Build and freeze ordinary, ThinLTO, and ASan tools from one clean sequence-access commit."""

import argparse
import datetime
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('destination', type=Path)
parser.add_argument('--asan', action='store_true')
parser.add_argument('--require-committed', action='store_true')
parser.add_argument('--expected-head', required=True)
args = parser.parse_args()
root = Path('/home/dev-user/code/oss/relar')
out = args.destination.resolve()
out.mkdir(parents=True, exist_ok=False)
digest = lambda data: hashlib.sha256(data).hexdigest()
paths = [root / 'Cargo.toml', root / 'Cargo.lock']
paths += sorted((root / 'crates').rglob('Cargo.toml'))
paths += sorted((root / 'crates').rglob('*.rs'))
sources = {str(path.relative_to(root)): path.read_text() for path in paths}
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert revision == args.expected_head, 'Unexpected source commit'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root), 'Final freeze requires clean source'
committed = True
for name, contents in sources.items():
    result = subprocess.run(['git', 'show', revision + ':' + name], cwd=root, capture_output=True)
    committed &= result.returncode == 0 and result.stdout == contents.encode()
if args.require_committed:
    assert committed, 'Compile sources differ from committed HEAD'
record = {
    'stage': 'sequence_access',
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'git_head': revision,
    'git_status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True),
    'rustc_verbose': subprocess.check_output(['rustc', '+ohm', '-vV'], text=True),
    'cargo_version': subprocess.check_output(['sh', '/tmp/relar-cargo.sh', '--version'], text=True),
    'cargo_wrapper': Path('/tmp/relar-cargo.sh').read_text(),
    'compiled_sources_match_commit': committed,
    'source_sha256': {name: digest(contents.encode()) for name, contents in sources.items()},
    'source_contents': sources,
    'commands': {},
    'sha256': {},
    'build_script': Path(__file__).read_text(),
    'build_script_sha256': digest(Path(__file__).read_bytes()),
}
environment = os.environ.copy()
for key in list(environment):
    if key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS'} or key.startswith('CARGO_PROFILE_RELEASE_'):
        del environment[key]
record['build_environment'] = {
    key: environment.get(key)
    for key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_PROFILE_RELEASE_LTO', 'CARGO_PROFILE_RELEASE_OPT_LEVEL', 'CARGO_PROFILE_RELEASE_CODEGEN_UNITS')
}
base = ['sh', '/tmp/relar-cargo.sh']
normal = Path('/home/dev-user/.cache/relar/target')
lto = Path('/home/dev-user/.cache/relar/lto-target')
asan = Path('/home/dev-user/.cache/relar/asan-target')
steps = [
    ('ordinary', base + ['build', '--workspace', '--release', '--locked'], environment,
     [(normal / 'release/relar', 'relar'), (normal / 'release/librelar_runtime.a', 'librelar_runtime.a')]),
    ('thinlto', base + ['build', '-p', 'relar-runtime', '--release', '--locked', '--target-dir', str(lto)],
     dict(environment, RUSTFLAGS='-Clinker-plugin-lto'), [(lto / 'release/librelar_runtime.a', 'librelar_runtime_lto.a')]),
]
if args.asan:
    steps.append((
        'asan', base + ['build', '-p', 'relar-runtime', '--release', '--locked', '--target', 'x86_64-unknown-linux-gnu', '--target-dir', str(asan)],
        dict(environment, RUSTC_BOOTSTRAP='1', RUSTFLAGS='-Zsanitizer=address -Cforce-frame-pointers=yes'),
        [(asan / 'x86_64-unknown-linux-gnu/release/librelar_runtime.a', 'librelar_runtime_asan.a')],
    ))

def save():
    (out / 'build-record.json').write_text(json.dumps(record, indent=2) + '\n')

for name, command, env, artifacts in steps:
    print('Building ' + name, flush=True)
    result = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (out / (name + '.log')).write_text(result.stdout)
    print(result.stdout, end='', flush=True)
    record['commands'][name] = {
        'command': command,
        'environment': {key: env.get(key) for key in ('RUSTFLAGS', 'RUSTC_BOOTSTRAP')},
        'returncode': result.returncode,
        'log_sha256': digest(result.stdout.encode()),
    }
    save()
    result.check_returncode()
    assert sources == {str(path.relative_to(root)): path.read_text() for path in paths}, 'Sources changed during build'
    for source, name_out in artifacts:
        shutil.copy2(source, out / name_out)
        record['sha256'][str((out / name_out).relative_to(root))] = digest((out / name_out).read_bytes())
    if name == 'thinlto':
        record['runtime_lto_rustflags'] = '-Clinker-plugin-lto'
    save()
    print('Frozen ' + name, flush=True)
record['freshness'] = 'Cargo tracked source changes; source contents verified unchanged across all builds. Unchanged runtime sources retain their normal build cache.'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == revision, 'HEAD changed during build'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root), 'Source dirty after build'
record['completed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print(json.dumps({'artifacts': record['sha256'], 'build_record_sha256': digest((out / 'build-record.json').read_bytes())}), flush=True)
