"""Summarize the saved, independently audited conditional-expression and sequence-access measurements."""

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
audit_path = HERE / "sequence-access-final-audit.json"
audit = json.loads(audit_path.read_text())
assert audit["status"] == "passed"
rows = []
for mode in audit["modes"]:
    for row in mode["rows"]:
        stats = row["statistics"]
        rows.append(
            {
                "mode": mode["mode"],
                "workload": row["workload"],
                "median_ms": row["median_ms"],
                "statistics_ns": stats,
                "new_vs_baseline_percent": row["new_vs_baseline_time_change_percent"],
                "cpython_speedup": row["ratios_of_medians"]["cpython_over_imre"],
                "imre_over_rust": row["ratios_of_medians"]["imre_over_rust_bigint"],
                "baseline_current_iqrs_overlap": max(
                    stats["imre"]["p25_ns"], stats["baseline"]["p25_ns"]
                )
                <= min(stats["imre"]["p75_ns"], stats["baseline"]["p75_ns"]),
            }
        )
counts = {
    "assertions": audit["assertions_passed"],
    "distinct_files_hashed": audit["distinct_files_hashed"],
    "measured": sum(mode["measured_process_runs"] for mode in audit["modes"]),
    "warmups": sum(mode["warmup_process_runs"] for mode in audit["modes"]),
    "gates": sum(mode["inventory_gate_runs"] for mode in audit["modes"]),
    "oracle_cases": sum(
        mode["validation_process_results"]["inventory"] for mode in audit["modes"]
    ),
    "device_cases": sum(
        mode["validation_process_results"]["inventory_device"]
        for mode in audit["modes"]
    ),
}
summary = {
    "schema": "imre-sequence-access-comparison-summary-v1",
    "audit_sha256": hashlib.sha256(audit_path.read_bytes()).hexdigest(),
    "source_commit": audit["modes"][0]["source_commit"],
    "counts": counts,
    "rows": rows,
    "source_control_rows": [
        {
            "mode": mode["mode"],
            "workload": row["workload"],
            "median_ms": row["median_ms"],
            "statistics_ns": row["statistics"],
            "new_vs_baseline_percent": row["new_vs_baseline_time_change_percent"],
            "baseline_current_iqrs_overlap": max(
                row["statistics"]["baseline"]["p25_ns"],
                row["statistics"]["imre_old_source"]["p25_ns"],
            )
            <= min(
                row["statistics"]["baseline"]["p75_ns"],
                row["statistics"]["imre_old_source"]["p75_ns"],
            ),
        }
        for mode in audit["source_controls"]
        for row in mode["rows"]
    ],
    "source_control_counts": {
        "measured": sum(
            mode["measured_process_runs"] for mode in audit["source_controls"]
        ),
        "warmups": sum(
            mode["warmup_process_runs"] for mode in audit["source_controls"]
        ),
        "gates": sum(mode["inventory_gate_runs"] for mode in audit["source_controls"]),
        "oracle_cases": sum(
            mode["validation_process_results"]["inventory"]
            for mode in audit["source_controls"]
        ),
        "device_cases": sum(
            mode["validation_process_results"]["inventory_device"]
            for mode in audit["source_controls"]
        ),
    },
    "all_baseline_current_iqrs_overlap": all(
        row["baseline_current_iqrs_overlap"] for row in rows
    ),
    "interpretation": "This is a capability milestone with changed application source. Primary comparisons include both source and compiler/runtime changes; separate native controls preserve the old source. IQR describes sample spread, not confidence.",
    "summary_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(HERE / "sequence-access-comparison-summary.json").write_text(
    json.dumps(summary, indent=2) + "\n"
)
print(
    json.dumps(
        {
            "counts": counts,
            "all_iqrs_overlap": summary["all_baseline_current_iqrs_overlap"],
        },
        indent=2,
    )
)
