"""Join saved semantic, sanitizer, and migration evidence without rerunning programs."""

import hashlib
import importlib.util
import json
import re
import runpy
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
TESTS = Path("/tmp/imre-sequence-tests")
COMMIT = "006e24367b87ecc331f31605640a7e53d3bdeaa6"
FILES = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def retain(path, expected=None):
    data = path.read_bytes()
    actual = digest(data)
    assert expected is None or actual == expected, str(path)
    FILES[str(path)] = {"sha256": actual, "bytes": len(data)}
    return data


def load(path):
    return json.loads(retain(path))


def main():
    receipt = load(TESTS / "validation-receipt.json")
    assert receipt["source_commit"] == COMMIT
    assert receipt["source_matches_frozen_build"]
    assert receipt["frozen_artifacts_match_tested_artifacts"]
    build = load(LOCAL / "sequence-access-tools-final/build-record.json")
    assert build["git_head"] == COMMIT and not build["git_status"]
    inputs = load(TESTS / "regression-inputs.json")
    final = load(TESTS / "regression-final-hashes.json")
    artifacts = load(TESTS / "artifacts.json")
    assert {name: value["sha256"] for name, value in inputs.items()} == final
    assert {
        value["path"]: value["sha256"] for value in artifacts["artifacts"].values()
    } == final
    assert set(final.values()) == set(receipt["artifact_sha256"].values())
    for name, expected in receipt["artifact_sha256"].items():
        assert build["sha256"][name] == expected
        # Frozen native artifacts are verified but deliberately excluded from publication.
        assert digest((ROOT / name).read_bytes()) == expected

    summary = load(TESTS / "summary.json")
    regression = load(TESTS / "regression-results.json")
    totals = {"normal": 0, "lto": 0, "asan": 0}
    suites = []
    expected_counts = {}
    for name, count in summary["checks"].items():
        mode = name.rsplit("-", 1)[1]
        totals[mode] += count
        expected_counts[name + ".log"] = count
        suites.append({"name": name, "mode": mode, "checks": count})
    for result in regression:
        assert result["returncode"] == 0
        mode = "lto" if result["mode"] == "thinlto" else result["mode"]
        totals[mode] += result["count"]
        name = result["mode"] + "-" + result["suite"]
        assert load(TESTS / (name + ".json")) == result
        expected_counts[name + ".log"] = result["count"]
        suites.append({"name": name, "mode": mode, "checks": result["count"]})
    assert set(expected_counts) == set(receipt["log_sha256"])
    for name, expected in receipt["log_sha256"].items():
        lines = retain(TESTS / name, expected).decode().splitlines()
        match = re.fullmatch(
            r"(?:Passed (\d+) .*checks.*|(\d+) import checks passed)", lines[-1]
        )
        assert match and int(match[1] or match[2]) == expected_counts[name]
    assert (
        totals == receipt["native_checks"] == {"normal": 884, "lto": 673, "asan": 689}
    )
    assert sum(totals.values()) == receipt["total_native_checks"] == 2246
    assert sum(summary["checks"].values()) == summary["total"] == 1057
    assert sum(item["count"] for item in regression) == 1189

    failures = []
    failed_logs = sorted(
        {*TESTS.glob("*.sandbox.log"), *TESTS.glob("*-asan-sandbox.log")}
    )
    for path in failed_logs:
        content = retain(path).decode()
        assert "LeakSanitizer" in content and "ptrace" in content
        item = {"log": str(path), "reason": "LeakSanitizer cannot run under ptrace"}
        sidecar = path.with_suffix(".json")
        if sidecar.exists():
            metadata = load(sidecar)
            assert metadata["returncode"] != 0
            item["receipt"] = str(sidecar)
        failures.append(item)
    assert len(failures) == 11

    spec = importlib.util.spec_from_file_location(
        "sequence_timing_audit", LOCAL / "sequence-access-final-audit.py"
    )
    audit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(audit)
    validator = runpy.run_path(str(ROOT / "benchmarks/inventory_validate.py"))
    asan = load(LOCAL / "sequence-access-inventory-asan.json")
    assert asan["source_commit"] == COMMIT
    assert asan["source_guard_before"] == asan["source_guard_after"]
    assert asan["sha256_before"] == asan["sha256_after"]
    assert asan["execution"]["tracer_pid"] == 0
    environment = asan["execution"]["inherited_environment"]
    assert (
        environment["ASAN_OPTIONS"] == "detect_leaks=1:halt_on_error=1:abort_on_error=1"
    )
    assert environment["LSAN_OPTIONS"] == "exitcode=23"
    for name, path in asan["input_paths"].items():
        assert digest(Path(path).read_bytes()) == asan["sha256_before"][name]
    assert asan["compilation"]["returncode"] == 0
    asan_outcomes = audit.correctness(
        {"validation": {"inventory": asan["validation"]}}, validator, ("imre_asan",)
    )

    migration = load(LOCAL / "sequence-access-migration-oracle.json")
    assert migration["sha256_before"] == migration["sha256_after"]
    for name, path in migration["input_paths"].items():
        assert digest(Path(path).read_bytes()) == migration["sha256_before"][name]
    migration_outcomes = audit.correctness(
        {"validation": {"inventory": migration["validation"]}},
        validator,
        tuple(migration["commands"]),
    )
    count_parser = load(LOCAL / "sequence-access-count-parser-validation.json")
    assert count_parser["compared_outcomes"] == 32505
    assert [item["int_max_str_digits"] for item in count_parser["settings"]] == [
        640,
        4300,
        0,
    ]
    assert sum(item["count_cases"] for item in count_parser["settings"]) == 32505
    assert count_parser["current_load_sha256"] == digest(
        (ROOT / "examples/inventory_reconciliation/load.py").read_bytes()
    )
    assert count_parser["baseline_load_sha256"] == digest(
        (
            LOCAL
            / "conditional-sequences-baseline-source/inventory_reconciliation/load.py"
        ).read_bytes()
    )
    for prefix, record in (
        ("count-parser-validation", count_parser),
        ("validate-migration", migration),
    ):
        retain(LOCAL / ("sequence-access-" + prefix + ".py"), record["script_sha256"])

    tracked = subprocess.check_output(
        ["git", "-C", str(ROOT), "ls-tree", "-r", "--name-only", COMMIT], text=True
    ).splitlines()
    committed_sources = {}
    for name in tracked:
        if (
            name.startswith(("tests/", "examples/inventory_reconciliation/"))
            and name.endswith(".py")
            or name.startswith("benchmarks/")
            and Path(name).parent == Path("benchmarks")
            and name.endswith(".py")
        ):
            actual = (ROOT / name).read_bytes()
            committed = subprocess.check_output(
                ["git", "-C", str(ROOT), "show", COMMIT + ":" + name]
            )
            assert actual == committed, name
            committed_sources[name] = digest(actual)
    result = {
        "status": "passed",
        "source_commit": COMMIT,
        "receipt": receipt,
        "native_suites": suites,
        "native_checks": totals,
        "total_native_checks": 2246,
        "asan_inventory": asan_outcomes,
        "migration_oracle": migration_outcomes,
        "count_parser_compared_outcomes": 32505,
        "superseded_sanitizer_environment_failures": failures,
        "verified_committed_sources": committed_sources,
        "retained_evidence_files": FILES,
        "script_sha256": digest(Path(__file__).read_bytes()),
        "provenance_notes": [
            "Compiler/runtime hashes join the successful semantic-suite manifests to the frozen measured tools; current source bytes are reconciled with the measured commit.",
            "Rust unit-test, fmt, Clippy, and scoped Ruff successes are observed tool-result evidence from the parent receipt, not fabricated raw suite logs.",
            "Migration validation predates the feature commit; recorded application and harness hashes match the final committed sources.",
            "Saved initial sandbox sanitizer failures are superseded by successful runs outside ptrace; a failed sidecar's original log path can refer to the subsequently replaced successful log, so the explicit retained log mapping is authoritative.",
        ],
    }
    destination = LOCAL / "sequence-access-validation.json"
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": result["status"],
                "native_checks": totals,
                "asan_inventory": asan_outcomes,
                "retained_files": len(FILES),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
