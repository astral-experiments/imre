"""Package the saved sequence-access experiment without executing native work."""

import argparse
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
PREFIX = "2026-10-18-sequence-access"
COMMIT = "006e24367b87ecc331f31605640a7e53d3bdeaa6"


def info(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def compressed(data):
    output = io.BytesIO()
    with gzip.GzipFile(
        fileobj=output, mode="wb", filename="", mtime=0, compresslevel=9
    ) as stream:
        stream.write(data)
    return output.getvalue()


class Package:
    def __init__(self):
        self.data = {}
        self.members = {}

    def add(self, name, data, source):
        assert not Path(name).is_absolute() and ".." not in Path(name).parts
        assert not data.startswith((b"\x7fELF", b"!<arch>\n", b"BC\xc0\xde"))
        assert Path(name).suffix not in {
            ".a",
            ".o",
            ".so",
            ".rlib",
            ".bc",
            ".exe",
            ".pyc",
            ".text",
        }
        data.decode("utf-8")
        if name in self.data:
            assert self.data[name] == data
            return
        self.data[name] = data
        self.members[name] = {**info(data), "source": source}

    def file(self, path, expected=None):
        path = path.absolute()
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        if expected:
            assert info(data) == expected, str(path)
        if path.is_relative_to(ROOT):
            name = "retained/" + str(path.relative_to(ROOT))
        else:
            assert path.parent == Path("/tmp/imre-sequence-tests")
            name = "validation/" + path.name
        self.add(name, data, str(path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=LOCAL / "sequence-access-publication-stage"
    )
    args = parser.parse_args()
    destination = args.output.resolve()
    assert destination.is_relative_to(LOCAL) and not destination.exists()
    load = lambda name: json.loads((LOCAL / name).read_text())
    session = load("sequence-access-final-session.json")
    build = load("sequence-access-tools-final/build-record.json")
    audit = load("sequence-access-final-audit.json")
    summary = load("sequence-access-comparison-summary.json")
    validation = load("sequence-access-validation.json")
    assert (
        session["source_commit"]
        == build["git_head"]
        == validation["source_commit"]
        == summary["source_commit"]
        == COMMIT
    )
    assert (
        not session["git_status_before"]
        and not session["git_status_after"]
        and not build["git_status"]
    )
    assert audit["status"] == validation["status"] == "passed"
    assert (
        summary["audit_sha256"]
        == info((LOCAL / "sequence-access-final-audit.json").read_bytes())["sha256"]
    )
    assert summary["counts"]["measured"] == 2304
    assert summary["source_control_counts"]["measured"] == 1152
    package = Package()
    tracked = subprocess.check_output(
        ["git", "-C", str(ROOT), "ls-tree", "-r", "--name-only", COMMIT], text=True
    ).splitlines()
    selected = [name for name in tracked if not name.startswith("benchmarks/results/")]
    archived = subprocess.check_output(
        ["git", "-C", str(ROOT), "archive", "--format=tar", COMMIT, "--", *selected]
    )
    with tarfile.open(fileobj=io.BytesIO(archived), mode="r:") as archive:
        for member in archive:
            if member.isdir():
                continue
            assert member.isfile()
            package.add(
                "source/" + member.name,
                archive.extractfile(member).read(),
                f"git:{COMMIT}:{member.name}",
            )
    assert {name[7:] for name in package.data if name.startswith("source/")} == set(
        selected
    )
    for name, expected in build["source_sha256"].items():
        assert info(package.data["source/" + name])["sha256"] == expected
    for name, expected in validation["verified_committed_sources"].items():
        assert info(package.data["source/" + name])["sha256"] == expected
    for name, expected in validation["retained_evidence_files"].items():
        package.file(Path(name), expected)
    for path in sorted(LOCAL.glob("sequence-access-*.py")):
        package.file(path)
    for name in (
        "sequence-access-final-session.json",
        "sequence-access-final-audit.json",
        "sequence-access-comparison-summary.json",
        "sequence-access-validation.json",
        "sequence-access-inventory-asan.json",
        "sequence-access-migration-oracle.json",
        "sequence-access-count-parser-validation.json",
    ):
        package.file(LOCAL / name)
    tools = LOCAL / "sequence-access-tools-final"
    package.file(tools / "build-record.json")
    for name, entry in build["commands"].items():
        path = tools / (name + ".log")
        assert info(path.read_bytes())["sha256"] == entry["log_sha256"]
        package.file(path)
    snapshot = LOCAL / "conditional-sequences-baseline-source"
    manifest = json.loads((snapshot / "manifest.json").read_text())
    package.file(snapshot / "manifest.json")
    for name, expected in manifest["sources"].items():
        assert info((snapshot / name).read_bytes())["sha256"] == expected
        package.file(snapshot / name)
    old_tools_record = Path(manifest["frozen_tools"]["build_record_path"])
    package.file(old_tools_record)
    for phase, command in json.loads(old_tools_record.read_text())["commands"].items():
        path = old_tools_record.parent / (phase + ".log")
        assert info(path.read_bytes())["sha256"] == command["log_sha256"]
        package.file(path)
    for mode in ("normal", "lto"):
        primary = load(f"sequence-access-{mode}-final.json")
        control = load(f"sequence-access-{mode}-source-control.json")
        for suffix in (
            "final.json",
            "final.log",
            "source-control.json",
            "source-control.log",
        ):
            package.file(LOCAL / f"sequence-access-{mode}-{suffix}")
        command = primary["method"]["compile_commands"]["inventory"]
        package.file(Path(command[command.index("--emit-llvm") + 1]))
        package.file(Path(control["artifacts"]["llvm"]))
        baseline = manifest["baseline_records"][mode]
        package.file(Path(baseline["record_path"]))
        package.file(Path(baseline["ir_path"]))
        package.file(Path(manifest["rust_references"][mode]["record_path"]))
    asan = load("sequence-access-inventory-asan.json")
    package.file(Path(asan["artifacts"]["llvm"]["path"]))
    explanation = f"""# Sequence-access experiment evidence

Measurements and frozen tools use clean source commit {COMMIT}.
The report date is the client-local date; exact UTC times are in the records.
`source/` is the complete measured Git tree except historical benchmark results.
`retained/` preserves experiment sources, raw records, generated LLVM, and scripts.
`validation/` preserves successful suite logs/manifests and explicitly superseded
LeakSanitizer-under-ptrace failures. Rust fmt/test/Clippy success is observed tool
evidence recorded in the parent receipt; no raw logs are invented.

Every member is text and has a hash/size in manifest.json. Native executables,
runtime archives, interpreters, toolchains, bytecode caches, and historical result
files are excluded. Their original paths/hashes remain in records, so the full
timing audit requires those external artifacts. The publication audit can verify
archived bytes and recompute recorded statistics/oracle outcomes without them.
"""
    package.add("EVIDENCE.md", explanation.encode(), "generated evidence guide")
    inner = {
        "schema": "imre-sequence-access-evidence-v1",
        "source_commit": COMMIT,
        "members": package.members,
    }
    manifest_data = (json.dumps(inner, indent=2) + "\n").encode()
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload, mode="w:", format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(
            {**package.data, "manifest.json": manifest_data}.items()
        ):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            member.uid = member.gid = member.mtime = 0
            archive.addfile(member, io.BytesIO(data))
    destination.mkdir()
    companions = {}

    def publish(suffix, data, original=None):
        name = PREFIX + "-" + suffix
        (destination / name).write_bytes(data)
        companions[name] = info(data)
        if original is not None:
            companions[name]["uncompressed"] = info(original)

    publish("evidence.tar.gz", compressed(payload.getvalue()))
    for suffix, original in (
        ("build.json", tools / "build-record.json"),
        ("session.json", LOCAL / "sequence-access-final-session.json"),
        ("audit.json", LOCAL / "sequence-access-final-audit.json"),
        ("summary.json", LOCAL / "sequence-access-comparison-summary.json"),
        ("validation.json", LOCAL / "sequence-access-validation.json"),
    ):
        publish(suffix, original.read_bytes())
    for mode in ("normal", "lto"):
        for source_suffix, output_suffix in (
            ("final", mode),
            ("source-control", mode + "-source-control"),
        ):
            original = (
                LOCAL / f"sequence-access-{mode}-{source_suffix}.json"
            ).read_bytes()
            publish(output_suffix + ".json.gz", compressed(original), original)
    outer = {**inner, "archive_manifest": info(manifest_data), "companions": companions}
    (destination / (PREFIX + "-evidence-manifest.json")).write_text(
        json.dumps(outer, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "output": str(destination),
                "members": len(package.members),
                "companions": len(companions),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
