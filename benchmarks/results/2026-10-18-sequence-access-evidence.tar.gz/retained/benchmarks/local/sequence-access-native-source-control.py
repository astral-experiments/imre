"""Compare preserved and current native tools on one unchanged inventory package."""

import argparse
import hashlib
import importlib.util
import itertools
import json
import runpy
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
benchmark = SimpleNamespace(
    **runpy.run_path(str(ROOT / "benchmarks/inventory_benchmark.py"))
)
spec = importlib.util.spec_from_file_location(
    "sequence_launch", LOCAL / "sequence-access-final-launch.py"
)
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comparison", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--expected-head", required=True)
    args = parser.parse_args()
    comparison_path = args.comparison.resolve(strict=True)
    comparison = json.loads(comparison_path.read_text())
    output = args.output.resolve()
    artifacts = output.with_suffix("")
    if output.exists() or artifacts.exists():
        raise RuntimeError("native source control outputs must be new")
    command = comparison["method"]["compile_commands"]["inventory"][:]
    inputs = {
        "compiler": Path(command[0]),
        "primary_comparison": comparison_path,
        "script": Path(__file__),
    }
    tools = Path(command[0]).parent
    guard_before = launcher.clean_sources(tools, args.expected_head)
    snapshot_before = launcher.snapshot_identity()
    baseline_sources = comparison["inventory_baseline_source"]["recorded_sources"]
    snapshot = Path(comparison["inventory_baseline_source"]["snapshot_root"])
    if snapshot_before["recorded_sources"] != baseline_sources:
        raise RuntimeError(
            "source control does not identify the same preserved package"
        )
    if comparison["git"] != {"revision": args.expected_head, "dirty": False}:
        raise RuntimeError("primary comparison did not use this clean source commit")
    for flag, key in (
        ("--runtime", "runtime"),
        ("--clang", "clang"),
        ("--lto-linker", "lto_linker"),
    ):
        if (
            flag in command
            and sha(Path(command[command.index(flag) + 1])) != comparison["sha256"][key]
        ):
            raise RuntimeError("primary comparison tool changed: " + key)
        if flag in command:
            inputs[key] = Path(command[command.index(flag) + 1])
    if sha(Path(command[0])) != comparison["sha256"]["compiler"]:
        raise RuntimeError("primary comparison compiler changed")
    baseline = comparison["method"]["commands"]["inventory"]["baseline"]
    if sha(Path(baseline[0])) != comparison["sha256"]["inventory_baseline"]:
        raise RuntimeError("preserved native binary changed")
    input_hashes_before = {name: sha(path) for name, path in inputs.items()}
    artifacts.mkdir(parents=True)
    native = artifacts / "inventory_reconciliation"
    llvm = artifacts / "inventory_reconciliation.ll"
    command[command.index("build") + 1] = str(
        snapshot / "inventory_reconciliation/__main__.py"
    )
    command[command.index("--module-root") + 1] = str(snapshot)
    command[command.index("-o") + 1] = str(native)
    command[command.index("--emit-llvm") + 1] = str(llvm)
    started = datetime.now(timezone.utc).isoformat()
    compilation = benchmark.shared.run(command, b"", 120)
    native_before = {"binary": sha(native), "llvm": sha(llvm)}
    commands = {"baseline": baseline, "relar_old_source": [str(native)]}
    validation = benchmark.validator.validate_commands(commands, 120)
    cpu = benchmark.shared.pin_cpu(0)
    execution = {"before_samples": benchmark.prior.runtime_context()}
    settings = SimpleNamespace(
        artifact_dir=artifacts, samples=48, warmups=2, timeout=120, validate_only=False
    )
    workloads = [
        benchmark.measure(value, commands, settings)
        for value in benchmark.captured_workloads(comparison)
    ]
    execution["after_samples"] = benchmark.prior.runtime_context()
    guard_after = launcher.clean_sources(tools, args.expected_head)
    snapshot_after = launcher.snapshot_identity()
    native_after = {"binary": sha(native), "llvm": sha(llvm)}
    input_hashes_after = {name: sha(path) for name, path in inputs.items()}
    if (
        guard_after != guard_before
        or snapshot_after != snapshot_before
        or native_after != native_before
        or input_hashes_after != input_hashes_before
    ):
        raise RuntimeError("native source control inputs changed during measurement")
    old_compile = json.loads(
        Path(
            json.loads((snapshot / "manifest.json").read_text())["baseline_records"][
                "lto" if comparison["options"]["lto"] else "normal"
            ]["record_path"]
        ).read_text()
    )["method"]["compile_commands"]["inventory"]
    old_ir = Path(old_compile[old_compile.index("--emit-llvm") + 1])
    record = {
        "schema_version": 1,
        "example": "inventory_reconciliation_unchanged_source",
        "started_at_utc": started,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "git": comparison["git"],
        "sources": baseline_sources,
        "primary_comparison": {
            "path": str(comparison_path),
            "sha256": sha(comparison_path),
        },
        "source_guard_before": guard_before,
        "source_guard_after": guard_after,
        "snapshot_before": snapshot_before,
        "snapshot_after": snapshot_after,
        "script": {
            "path": str(Path(__file__)),
            "sha256": sha(Path(__file__)),
            "source": Path(__file__).read_text(),
        },
        "tools": comparison["tools"],
        "options": {
            **comparison["options"],
            "samples": settings.samples,
            "warmups": settings.warmups,
        },
        "host": {**comparison["host"], "cpu": cpu},
        "execution": execution,
        "compilation": compilation,
        "compile_command": command,
        "commands": commands,
        "artifacts": {"binary": str(native), "llvm": str(llvm)},
        "sha256_before": native_before,
        "sha256_after": native_after,
        "input_paths": {name: str(path) for name, path in inputs.items()},
        "input_hashes_before": input_hashes_before,
        "input_hashes_after": input_hashes_after,
        "generated_ir": {
            "old_path": str(old_ir),
            "old_sha256": sha(old_ir),
            "new_path": str(llvm),
            "new_sha256": sha(llvm),
            "byte_identical": old_ir.read_bytes() == llvm.read_bytes(),
        },
        "validation": validation,
        "workloads": {"inventory": workloads},
        "method": {
            "scope": "same preserved Python source and captured inputs; preserved executable versus current compiler/runtime",
            "timer": "whole-process timer and exact output/filesystem checks from inventory_benchmark.measure",
            "ordering": "48 alternating two-engine orders, two warmups; measured positions and within-round predecessors balanced",
            "order_cycles": {"inventory": list(itertools.permutations(commands))},
        },
    }
    output.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n")
    print("Saved " + str(output), flush=True)


if __name__ == "__main__":
    main()
