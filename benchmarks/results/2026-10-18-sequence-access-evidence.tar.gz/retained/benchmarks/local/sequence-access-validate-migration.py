"""Validate the inventory source migration against preserved sources and executables."""

import hashlib
import json
import runpy
import sys
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
SNAPSHOT = LOCAL / "conditional-sequences-baseline-source"
OUTPUT = LOCAL / "sequence-access-migration-oracle.json"
validator = SimpleNamespace(**runpy.run_path(str(ROOT / "benchmarks/inventory_validate.py")))
manifest = json.loads((SNAPSHOT / "manifest.json").read_text())
old_record = json.loads(Path(manifest["baseline_records"]["normal"]["record_path"]).read_text())
python = old_record["method"]["commands"]["inventory"]["cpython"][0]
current_python = validator.python_command(python)
previous_python = [*current_python[:-1], str(SNAPSHOT)]
commands = {
    "cpython_current": current_python,
    "cpython_previous": previous_python,
    "relar_previous": [manifest["baseline_records"]["normal"]["binary_path"]],
    "rust_bigint": [manifest["rust_references"]["normal"]["binary_path"]],
}
paths = {
    **{"source:" + str(path.relative_to(ROOT)): path for path in validator.package_sources()},
    **{"harness:" + path.name: path for path in sorted((ROOT / "benchmarks").glob("*.py"))},
    "snapshot_manifest": SNAPSHOT / "manifest.json",
    "python": Path(python).resolve(),
    "baseline_binary": Path(commands["relar_previous"][0]),
    "rust_binary": Path(commands["rust_bigint"][0]),
}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before = {name: sha(path) for name, path in paths.items()}
started = datetime.now(timezone.utc).isoformat()
validation = validator.validate_commands(commands, 120)
after = {name: sha(path) for name, path in paths.items()}
assert before == after, "source/tool inputs changed during validation"
result = {
    "command": [sys.executable, *sys.argv],
    "script_sha256": sha(Path(__file__)),
    "started_at_utc": started,
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "commands": commands,
    "input_paths": {name: str(path) for name, path in paths.items()},
    "sha256_before": before,
    "sha256_after": after,
    "validation": validation,
}
OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"cases": validation["cases"], "engines": validation["engines"], "device": validation["device_check"]["case"], "output": str(OUTPUT)}, indent=2))
