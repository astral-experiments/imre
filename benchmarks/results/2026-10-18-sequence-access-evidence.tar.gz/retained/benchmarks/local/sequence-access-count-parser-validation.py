"""Compare the bounded count scanner with its preserved predecessor under CPython."""

import hashlib
import importlib
import itertools
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SNAPSHOT = ROOT / "benchmarks/local/conditional-sequences-baseline-source"
OUTPUT = ROOT / "benchmarks/local/sequence-access-count-parser-validation.json"
sys.path.insert(0, str(ROOT / "examples"))
current = importlib.import_module("inventory_reconciliation.load")
old_path = SNAPSHOT / "inventory_reconciliation/load.py"
old_namespace = {"__name__": "inventory_reconciliation.old_load", "__package__": "inventory_reconciliation"}
exec(compile(old_path.read_text(), str(old_path), "exec"), old_namespace)
old_reader = old_namespace["Reader"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def result(reader, text):
    try:
        return ("value", hex(reader([text], label="stock").count()))
    except Exception as error:
        return (type(error).__name__, str(error))


explicit = [
    "", " ", "+", "-", "_", "__", "+_0", "-_0", "0_", "0__0",
    "+-1", "--1", "++1", "-+1", "0", "-0", "+0", "-0_0", "+0_0",
    "-1", "+1", "1_0", "0_1", "0x10", "1.0", "True", "1 2", "  +0\t",
    "٠", "١", "-٠", "-١", "+１", "𝟘_𝟙", "²", "1_٠", "٠__1", "\0",
    "0" * 18, "0" * 19, "9" * 18, "9" * 19,
    "-" + "0" * 17, "-" + "0" * 18,
    "1" * 640, "1" * 641, "1" * 4300, "1" * 4301,
    "0" * 640, "0" * 641, "0" * 4300, "0" * 4301,
    "_".join("1" * 641), "+" + "1" * 641, "-" + "1" * 641,
]
short = ["".join(value) for size in range(1, 5) for value in itertools.product("01_+-", repeat=size)]
rng = random.Random(20261018)
alphabet = "01289_+-x٠１𝟘² .\t\0"
random_tokens = ["".join(rng.choices(alphabet, k=rng.randrange(25))) for _ in range(10000)]
initial_limit = sys.get_int_max_str_digits()
settings = [sys.int_info.str_digits_check_threshold, initial_limit, 0]
records = []
comparisons = 0
try:
    for setting in settings:
        sys.set_int_max_str_digits(setting)
        tested = 0
        for token in [*explicit, *short, *random_tokens]:
            previous, updated = result(old_reader, token), result(current.Reader, token)
            assert previous == updated, (setting, repr(token), previous, updated)
            tested += 1
        comparisons += tested
        records.append({"int_max_str_digits": setting, "count_cases": tested, "explicit": [{"text": value, "result": result(current.Reader, value)} for value in explicit]})
finally:
    sys.set_int_max_str_digits(initial_limit)
output = {
    "checked_at_utc": datetime.now(timezone.utc).isoformat(),
    "python": sys.version,
    "python_executable": sys.executable,
    "script_sha256": digest(Path(__file__)),
    "baseline_load_sha256": digest(old_path),
    "current_load_sha256": digest(Path(current.__file__)),
    "minimum_nonzero_digit_limit": sys.int_info.str_digits_check_threshold,
    "compared_outcomes": comparisons,
    "settings": records,
    "scope": "old/new Reader.count results match; Unicode decimal digits check CPython-only compatibility outside the shared ASCII domain; long tokens retain int() limits",
}
OUTPUT.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"compared_outcomes": comparisons, "settings": settings, "output": str(OUTPUT)}, indent=2))
