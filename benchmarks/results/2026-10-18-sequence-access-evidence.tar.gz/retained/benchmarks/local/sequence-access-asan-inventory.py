"""Validate the final inventory source with the frozen ASan runtime and LSan."""

import argparse
import importlib.util
import json
import os
import runpy
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"


def load_module(path):
    spec = importlib.util.spec_from_file_location("sequence_final_guard", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-head", required=True)
    args = parser.parse_args()
    guard = load_module(LOCAL / "sequence-access-final-launch.py")
    tools = LOCAL / "sequence-access-tools-final"
    before = guard.clean_sources(tools, args.expected_head)
    primary_path = LOCAL / "sequence-access-normal-final.json"
    primary = json.loads(primary_path.read_text())
    build = json.loads((tools / "build-record.json").read_text())
    output = LOCAL / "sequence-access-inventory-asan"
    output.mkdir(exist_ok=False)
    binary = output / "inventory_reconciliation"
    llvm = output / "inventory_reconciliation.ll"
    command = list(primary["method"]["compile_commands"]["inventory"])
    for flag, value in (
        ("--runtime", tools / "librelar_runtime_asan.a"),
        ("-o", binary),
        ("--emit-llvm", llvm),
    ):
        command[command.index(flag) + 1] = str(value)
    command.append("--sanitize")
    inputs = {
        "compiler": tools / "relar",
        "runtime": tools / "librelar_runtime_asan.a",
        "build_record": tools / "build-record.json",
        "primary_comparison": primary_path,
        "script": Path(__file__),
        "validator": ROOT / "benchmarks/inventory_validate.py",
    }
    hashes = {name: guard.sha(path) for name, path in inputs.items()}
    for name in ("compiler", "runtime"):
        assert hashes[name] == build["sha256"][str(inputs[name].relative_to(ROOT))]
    os.environ["ASAN_OPTIONS"] = "detect_leaks=1:halt_on_error=1:abort_on_error=1"
    os.environ["LSAN_OPTIONS"] = "exitcode=23"
    layout = runpy.run_path(str(ROOT / "benchmarks/layout_benchmark.py"))
    context = layout["runtime_context"]()
    assert context["tracer_pid"] == 0, "sanitizer validation must run outside ptrace"
    started = datetime.now(timezone.utc).isoformat()
    start = time.perf_counter_ns()
    compilation = subprocess.run(command, capture_output=True, text=True, check=True)
    compilation_elapsed = time.perf_counter_ns() - start
    assert not compilation.stdout and not compilation.stderr
    validator = runpy.run_path(str(ROOT / "benchmarks/inventory_validate.py"))
    validation = validator["validate_commands"]({"relar_asan": [str(binary)]}, 120)
    after = guard.clean_sources(tools, args.expected_head)
    hashes_after = {name: guard.sha(path) for name, path in inputs.items()}
    assert before == after and hashes == hashes_after
    assert context == layout["runtime_context"]()
    result = {
        "source_commit": args.expected_head,
        "started_at_utc": started,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_guard_before": before,
        "source_guard_after": after,
        "execution": context,
        "input_paths": {name: str(path) for name, path in inputs.items()},
        "sha256_before": hashes,
        "sha256_after": hashes_after,
        "script_source": Path(__file__).read_text(),
        "compile_command": command,
        "compilation": {
            "returncode": compilation.returncode,
            "stdout": compilation.stdout,
            "stderr": compilation.stderr,
            "elapsed_ns": compilation_elapsed,
        },
        "artifacts": {
            "binary": {"path": str(binary), "sha256": guard.sha(binary)},
            "llvm": {"path": str(llvm), "sha256": guard.sha(llvm)},
        },
        "validation": validation,
    }
    destination = LOCAL / "sequence-access-inventory-asan.json"
    destination.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(
        json.dumps(
            {
                "cases": validation["cases"],
                "device": validation["device_check"]["case"],
                "output": str(destination),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
