"""Verify the published text archive and recompute saved comparisons without native artifacts."""

import argparse
import gzip
import hashlib
import io
import json
import runpy
import tarfile
import tempfile
from pathlib import Path

PREFIX = "2026-10-18-sequence-access"
COMMIT = "006e24367b87ecc331f31605640a7e53d3bdeaa6"


def info(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    directory = args.directory.resolve()
    manifest = json.loads(
        (directory / (PREFIX + "-evidence-manifest.json")).read_text()
    )
    assert manifest["source_commit"] == COMMIT
    for name, expected in manifest["companions"].items():
        data = (directory / name).read_bytes()
        assert info(data) == {key: expected[key] for key in ("sha256", "bytes")}, name
        if "uncompressed" in expected:
            assert info(gzip.decompress(data)) == expected["uncompressed"], name
    archive_data = (directory / (PREFIX + "-evidence.tar.gz")).read_bytes()
    members = {}
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode="r:gz") as archive:
        for member in archive:
            assert member.isfile() and not Path(member.name).is_absolute()
            assert ".." not in Path(member.name).parts and member.name not in members
            data = archive.extractfile(member).read()
            data.decode("utf-8")
            assert not data.startswith((b"\x7fELF", b"!<arch>\n", b"BC\xc0\xde"))
            members[member.name] = data
    assert set(members) == {*manifest["members"], "manifest.json"}
    assert info(members["manifest.json"]) == manifest["archive_manifest"]
    inner = json.loads(members["manifest.json"])
    assert inner["source_commit"] == COMMIT and inner["members"] == manifest["members"]
    for name, expected in manifest["members"].items():
        assert info(members[name]) == {
            key: expected[key] for key in ("sha256", "bytes")
        }
    retained = "retained/benchmarks/local/"
    published = lambda suffix: json.loads(
        (directory / (PREFIX + "-" + suffix)).read_text()
    )
    summary = published("summary.json")
    saved_audit = published("audit.json")
    validation = published("validation.json")
    build = published("build.json")
    session = published("session.json")
    assert (
        summary["source_commit"]
        == validation["source_commit"]
        == build["git_head"]
        == session["source_commit"]
        == COMMIT
    )
    assert (
        not session["git_status_before"]
        and not session["git_status_after"]
        and not build["git_status"]
    )
    assert (
        summary["audit_sha256"]
        == info((directory / (PREFIX + "-audit.json")).read_bytes())["sha256"]
    )
    for name, expected in build["source_sha256"].items():
        assert info(members["source/" + name])["sha256"] == expected
    for name, expected in validation["verified_committed_sources"].items():
        assert info(members["source/" + name])["sha256"] == expected
    recomputed = {}
    with tempfile.TemporaryDirectory(
        prefix="imre-sequence-evidence-audit-"
    ) as temporary:
        root = Path(temporary)
        for name, data in members.items():
            if name.startswith("source/"):
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        audit_path = root / "timing-audit.py"
        audit_path.write_bytes(members[retained + "sequence-access-final-audit.py"])
        audit = runpy.run_path(str(audit_path))
        validator = runpy.run_path(
            str(root / "source/benchmarks/inventory_validate.py")
        )
        measured = warmups = gates = oracle = devices = 0
        for mode in ("normal", "lto"):
            original = json.loads(
                members[
                    retained
                    + f"conditional-sequences-baseline-source/keyword-arguments-{mode}.json"
                ]
            )
            for kind, engines, current in (
                ("primary", ("cpython", "imre", "rust_bigint", "baseline"), "imre"),
                ("control", ("baseline", "imre_old_source"), "imre_old_source"),
            ):
                suffix = mode if kind == "primary" else mode + "-source-control"
                original_bytes = gzip.decompress(
                    (directory / (PREFIX + "-" + suffix + ".json.gz")).read_bytes()
                )
                retained_suffix = "final" if kind == "primary" else "source-control"
                assert (
                    original_bytes
                    == members[
                        retained + f"sequence-access-{mode}-{retained_suffix}.json"
                    ]
                )
                record = json.loads(original_bytes)
                if kind == "primary":
                    outcome = audit["correctness"](record, validator, engines)
                else:
                    outcome = audit["correctness"](
                        {"validation": {"inventory": record["validation"]}},
                        validator,
                        engines,
                    )
                rows, order, count, warmed, gated = audit["audit_workloads"](
                    record, original, validator, engines, current
                )
                saved = next(
                    value
                    for value in saved_audit[
                        "modes" if kind == "primary" else "source_controls"
                    ]
                    if value["mode"] == mode
                )
                assert rows == saved["rows"] and order == saved["ordering"]
                assert (
                    count == saved["measured_process_runs"]
                    and warmed == saved["warmup_process_runs"]
                    and gated == saved["inventory_gate_runs"]
                )
                measured += count
                warmups += warmed
                gates += gated
                oracle += outcome["inventory"]
                devices += outcome["inventory_device"]
                recomputed[mode + "_" + kind] = {
                    "workloads": len(rows),
                    "measured": count,
                    "oracle_outcomes": outcome,
                }
        for name, engines in (
            ("sequence-access-inventory-asan.json", ("imre_asan",)),
            (
                "sequence-access-migration-oracle.json",
                ("cpython_current", "cpython_previous", "imre_previous", "rust_bigint"),
            ),
        ):
            record = json.loads(members[retained + name])
            audit["correctness"](
                {"validation": {"inventory": record["validation"]}}, validator, engines
            )
    assert (measured, warmups, gates, oracle, devices) == (3456, 144, 72, 2448, 12)
    result = {
        "status": "passed",
        "source_commit": COMMIT,
        "archive_members": len(members),
        "companions": len(manifest["companions"]),
        "measured_process_runs_recomputed": measured,
        "warmup_process_runs_recomputed": warmups,
        "workload_gates_recomputed": gates,
        "timing_oracle_outcomes_recomputed": oracle,
        "timing_device_outcomes_recomputed": devices,
        "recomputed": recomputed,
        "archive_sha256": info(archive_data)["sha256"],
        "manifest_sha256": info(
            (directory / (PREFIX + "-evidence-manifest.json")).read_bytes()
        )["sha256"],
        "script_sha256": info(Path(__file__).read_bytes())["sha256"],
        "note": "This audit uses the published source, samples, and expected outcomes; native executables and the original devbox are not required.",
    }
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {key: value for key, value in result.items() if key != "recomputed"},
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
