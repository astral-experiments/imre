# Sequence-access experiment evidence

Measurements and frozen tools use clean source commit 006e24367b87ecc331f31605640a7e53d3bdeaa6.
The report date is the client-local date; exact UTC times are in the records.
`source/` is the complete measured Git tree except historical benchmark results.
`retained/` preserves experiment sources, raw records, generated LLVM, and scripts.
`validation/` preserves successful suite logs/manifests and explicitly superseded
LeakSanitizer-under-ptrace failures. Rust fmt/test/Clippy success is observed tool
evidence recorded in the parent receipt; no raw logs are invented.

Every member is text and has a hash/size in manifest.json. Native executables,
runtime archives, interpreters, toolchains, bytecode caches, and historical result
files are excluded. Their original paths/hashes remain in records, so the full
timing audit requires those external artifacts. The publication audit can verify
archived bytes and recompute recorded statistics/oracle outcomes without them.
