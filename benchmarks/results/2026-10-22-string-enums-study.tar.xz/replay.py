"""Independently verify the sealed measurement, correction, and compiler-attribution studies."""

from collections import Counter
from pathlib import Path
from statistics import median
import hashlib, json, subprocess, sys, tarfile, tempfile

if sys.flags.optimize:
    raise RuntimeError("replay needs Python assertions")
top = Path(__file__).resolve().parent


def load(p):
    return json.loads(p.read_bytes())


def sha(b):
    return hashlib.sha256(b).hexdigest()


def check_index(root, idx):
    paths = {
        str(p.relative_to(root))
        for p in root.rglob("*")
        if p.is_file() and p != idx and "__pycache__" not in p.parts
    }
    index = load(idx)
    assert paths == set(index)
    for k, v in index.items():
        p = root / k
        assert p.stat().st_size == v["bytes"] and sha(p.read_bytes()) == v["sha256"], k


check_index(top, top / "index.json")
with tempfile.TemporaryDirectory() as td:
    temp = Path(td)
    m = temp / "measured"
    fix = temp / "corrected"
    m.mkdir()
    fix.mkdir()
    for b, d in [("measurements.tar.xz", m), ("correction.tar.xz", fix)]:
        with tarfile.open(top / b) as t:
            t.extractall(d, filter="data")
    check_index(fix, fix / "index.json")
    primary = json.loads(subprocess.check_output([sys.executable, "-B", m / "replay.py"]))
    assert (
        primary == load(top / "measurement-audit.json")
        and primary["specified_rust_time_target_met"]
    )
    eq = load(fix / "artifact-equivalence.json")
    assert (
        eq["measured_revision"] == primary["revision"] == "d5d48a88cd5b4a0af26080caf09d4d11b7eec599"
        and eq["candidate_revision"] == "9778ef24b8e504da5402f4d8adef39e5b60e54a4"
        and eq["status"] == "passed"
        and sha((fix / "corrected.bundle").read_bytes()) == eq["bundle"]["sha256"]
    )
    kbuild = load(m / "builds/kernel-builds.json")
    cores = [load(fix / ("core-" + v + ".json")) for v in ["measured", "corrected"]]
    assert [v["revision"] for v in cores] == [
        eq["measured_revision"],
        eq["candidate_revision"],
    ] and all(v["input_guards_passed"] and v["source_matches_revision"] for v in cores)
    for field in ["toolchain", "cargo", "target", "tool_sha256", "tool_paths", "driver_sha256"]:
        assert cores[0][field] == cores[1][field]
    regular_loads = {}
    canonical = {}
    direct_sections = {}
    for mode, roles in eq["programs"].items():
        assert set(roles) == {"report", "compute", "classification"}
        regular_loads[mode] = {}
        canonical[mode] = {}
        direct_sections[mode] = {}
        app = load(m / "builds" / ("after-" + mode) / "build-record.json")
        for role, row in roles.items():
            ids = {
                key: sha((fix / "ir" / (mode + "-" + role + "-" + key + ".ll")).read_bytes())
                for key in ["old_ir", "candidate_ir", "canonical_ir"]
            }
            assert all(ids[k] == row[k]["sha256"] for k in ids) and row["ir_identical"] == (
                len(set(ids.values())) == 1
            )
            name = {
                "report": "conformance_report",
                "compute": "conformance_report-compute",
                "classification": "classification",
            }[role]
            a, b = (
                (kbuild["after-" + mode]["llvm"], kbuild["after-" + mode]["executable"])
                if role == "classification"
                else (app["llvm"][name], app["binaries"][name])
            )
            assert (
                a["sha256"] == ids["old_ir"]
                and b["sha256"] == row["measured"]["sha256"]
                and row["whole_canonical_elf_identical"]
                and row["canonical"]["sha256"] == row["measured"]["sha256"]
            )
            assert (
                row["regular_executable_sections_identical"]
                and row["executable_sections"][0]
                == row["executable_sections"][1]
                == row["executable_sections"][2]
                and ".text" in row["executable_sections"][0]
            )
            assert (
                row["measured_runtime"]["sha256"] == cores[0]["sha256"][mode + "_runtime"]
                and row["candidate_runtime"]["sha256"] == cores[1]["sha256"][mode + "_runtime"]
            )
            link = load(fix / "links" / (mode + "-" + role + "-canonical-link.json"))
            cfg = load(fix / "links" / (mode + "-" + role + "-canonical-config.json"))
            assert (
                link == row["canonical_link_command"]
                and link["llvm_sha256"] == ids["canonical_ir"]
                and "/tmp/" + cfg["original_basename"] in link["command"]
                and row["measured_runtime"]["path"] in link["command"]
            )
            regular_loads[mode][role] = row["regular_elf"]["loadable_segments_byte_identical"]
            canonical[mode][role] = row["whole_canonical_elf_identical"]
            direct_sections[mode][role] = row["regular_executable_sections_identical"]
    assert (
        set(eq["programs"]) == {"normal", "thinlto", "asan"}
        and sum(map(len, canonical.values())) == 9
    )
    captures = (m / "inputs/corpus.captures").read_bytes()
    transcript = sha(captures)
    assert len(eq["complete_outputs"]) == 90
    for mode in eq["programs"]:
        for variant in ["regular", "canonical"]:
            expected = {
                "classification-dump": (captures, None),
                "classification-preload": (b"1269 0\n", None),
                "classification-checksum": (b"1269 7342784\n", None),
            }
            for panel in ["unchanged-github", "changed-github", "changed-diff"]:
                report = (m / "inputs" / (panel + ".md")).read_bytes()
                for label, stdout, body in [
                    ("report", b"", report),
                    ("live", b"", report),
                    ("compute-four", f"{4*len(report.decode())}\n".encode(), report),
                    ("compute-zero", b"0\n", b""),
                ]:
                    expected[panel + "-" + label] = (stdout, body)
            for label, (stdout, body) in expected.items():
                key = mode + "-" + variant + "-" + label
                q = eq["complete_outputs"][key]
                path = fix / "outputs" / (key + ".stdout")
                assert path.read_bytes() == stdout and sha(stdout) == q["stdout"]["sha256"]
                if body is not None:
                    assert (fix / "outputs" / (key + ".md")).read_bytes() == body and sha(
                        body
                    ) == q["file"]["sha256"]
    att = load(fix / "attribution.json")
    assert (
        att["completed"]
        and att["transcript_sha256"] == transcript
        and att["corrected_revision"] == eq["candidate_revision"]
        and att["baseline_revision"] == primary["baseline_revision"]
        and att["measured_revision"] == primary["revision"]
        and att["rounds"] == 2048
        and att["samples"] == 12
        and att["cpu"] == 31
    )
    for p, h in att["inputs"].items():
        assert sha((m / "inputs/changed-github" / Path(p).name).read_bytes()) == h
    labels = set(att["commands"])
    orders = att["orders"]
    assert (
        len(labels) == len(orders) == 6
        and all(set(row) == labels and len(row) == 6 for row in orders)
        and all({row[i] for row in orders} == labels for i in range(6))
        and Counter(p for r in orders for p in zip(r, r[1:]))
        == {(a, b): 1 for a in labels for b in labels if a != b}
    )
    assert [cell["engine"] for cell in att["warmup"]] == orders[0][::-1] and [
        [cell["engine"] for cell in row] for row in att["runs"]
    ] == orders * 2
    for k, probe in att["per_engine_dump"].items():
        assert k in labels and probe["stdout_sha256"] == transcript
    for i, row in enumerate([att["warmup"], *att["runs"]], start=-1):
        for j, cell in enumerate(row):
            ns = [x["rounds"] for x in cell["processes"]]
            assert ns == ([0, 2048] if (i + j) % 2 == 0 else [2048, 0])
            duration = {x["rounds"]: x["elapsed_ns"] for x in cell["processes"]}
            assert (duration[2048] - duration[0]) / 2048 == cell["net_ns"]
            for x in cell["processes"]:
                assert x["elapsed_ns"] > 0 and x["stdout_sha256"] == sha(
                    f'1269 {114731*x["rounds"]}\n'.encode()
                )
    med = {
        k: median(cell["net_ns"] for row in att["runs"] for cell in row if cell["engine"] == k)
        for k in labels
    }
    assert med == att["median_ns"] and min(med.values()) > 0
    for mode in ["normal", "thinlto"]:
        b = kbuild["before-" + mode]
        n = eq["programs"][mode]["classification"]
        h = att["modes"][mode]
        assert (
            h["old_string_source_hashes"] == b["source_hashes"]
            and h["old_compiler_sha256"] == b["compiler"]["sha256"]
            and h["old_runtime_sha256"] == b["runtime"]["sha256"]
            and h["new_runtime_sha256"] == n["candidate_runtime"]["sha256"]
            and h["new_compiler_sha256"] == cores[1]["sha256"]["compiler"]
        )
        assert (
            sha((fix / "strings" / (mode + ".ll")).read_bytes()) == h["new_string_ir"]
            and h["new_enum_ir"] == n["candidate_ir"]["sha256"]
            and h["old_string_ir"] == b["llvm"]["sha256"]
        )
        assert (
            att["binaries"]["old-strings-" + mode] == b["executable"]["sha256"]
            and att["binaries"]["new-enums-" + mode] == n["regular"]["sha256"]
        )
        assert (
            att["generic_speedup"][mode] == med["old-strings-" + mode] / med["new-strings-" + mode]
            and att["source_speedup"][mode] == med["new-strings-" + mode] / med["new-enums-" + mode]
            and att["combined_speedup"][mode]
            == med["old-strings-" + mode] / med["new-enums-" + mode]
        )
    with tarfile.open(top / "sanitizers-measured.tar.gz") as t:
        qa = json.load(t.extractfile("receipt.json"))
        freeze = json.load(t.extractfile("freeze.json"))
        assert freeze["revision"] == primary["revision"] and qa["source_suite_count"] == 37
    with tarfile.open(top / "sanitizers-corrected.tar.gz") as t:
        qb = json.load(t.extractfile("receipt.json"))
        freeze = json.load(t.extractfile("freeze.json"))
        assert (
            freeze["revision"] == eq["candidate_revision"]
            and qb["asan"]
            and qb["lsan"]
            and set(qb["suites"]) == {"classes", "callables"}
        )
    cbr = load(top / "callback-validation.json")
    assert len(cbr["semantics"]) == 8 and all(v["bytes"] > 0 for v in cbr["semantics"])
    uv = (top / "uv-variant.log").read_text()
    assert (
        "6110 downloads, ranks {0: 2222, 1: 1059, 2: 929, 3: 1900}" in uv
        and "7ee31ec51f968ed117c875f4dc536ab53e42d703107a5dc678209cea98281661" in uv
    )
    print(
        json.dumps(
            {
                **primary,
                "shipping_revision": eq["candidate_revision"],
                "post_fix_llvm_identities": sum(
                    q["ir_identical"] for group in eq["programs"].values() for q in group.values()
                ),
                "post_fix_canonical_elf_identities": canonical,
                "post_fix_natural_executable_section_identities": direct_sections,
                "post_fix_natural_pt_load_identities": regular_loads,
                "post_fix_complete_output_observations": len(eq["complete_outputs"]),
                "attribution_timed_processes": 144,
                "attribution_warmup_processes": 12,
                "attribution_ns": med,
                "generic_compiler_speedup": att["generic_speedup"],
                "string_to_enum_speedup": att["source_speedup"],
                "combined_paired_speedup": att["combined_speedup"],
                "uv_downloads": 6110,
                "frozen_sanitized_suites": 37,
                "focused_callback_comparisons": 8,
            },
            indent=2,
        )
    )
