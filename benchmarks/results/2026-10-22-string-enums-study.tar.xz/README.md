# Ruff string-enum and diagnostic classification study

Run `python3.14 -B replay.py` inside this extracted directory. The replay validates and extracts the sealed measurement and correction archives in a temporary directory, reconstructs the 1,269 groups and three full reports from the retained corpus, checks the observed outputs and timings, verifies all nine corrected executable receipts, and recalculates the paired compiler/source attribution.

The core measurement archives the original 28 six-engine panels at d5d48a8, the one-item and one/two-item Rust controls, a separate changed-diff comparison and native profiles. It includes the exact suite, source snapshot, independent Rust and Codon source, command and build records, generated LLVM and full native profiles.

The correction archive compares independently rebuilt 9778ef2 against the measured reporter, repeated computation and classification binaries for ordinary, ThinLTO and ASan. Each natural link has an executable-section comparison. Each canonical link preserves the input basename and measured runtime archive. The record retains the natural ELF differences and the hashes of whole matching canonical binaries. It also records complete corrected executable outputs, the bounded Git bundle, and a source-swap control on the corrected compiler/runtime.

The companion sanitizer archives retain the 37-suite timed-source campaign and focused corrected bound-method tests. The uv output receipt and regression fixture are in the corresponding source snapshot. Host-local paths in original commands describe the measurement environment. To reproduce the native builds, install the recorded toolchains and use the supplied source revisions and link recipes.
