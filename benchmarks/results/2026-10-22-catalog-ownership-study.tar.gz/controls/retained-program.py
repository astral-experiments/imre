from dataclasses import dataclass
from sys import argv

from relar.json import decode


@dataclass
class Row:
    name: str
    payload: str
    index: int


def main() -> None:
    records: list[Row] = []
    strings: list[str] = []
    batches = 0
    mode = argv[2]
    with open(argv[1], "r", encoding="utf-8") as stream:
        for line in stream:
            siblings = decode(line, list[Row])
            selected = siblings[batches % len(siblings)]
            if mode == "records":
                records.append(selected)
            elif mode == "strings":
                strings.append(selected.name)
            batches += 1
    checksum = batches
    for row in records:
        checksum += len(row.name) + len(row.payload) + row.index
    for text in strings:
        checksum += len(text) + int(text.endswith("0"))
    print(checksum)


main()
