"""Count real constructor and decode entries using CPython's local monitoring."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).parent
REPO = Path("/home/dev-user/code/oss/imre-catalog-ownership")
INPUTS = Path("/home/dev-user/.cache/imre/catalog-gap-local-20261022/inputs")
sys.path[:0] = [str(REPO / "examples"), str(REPO / "stdlib")]
from python_catalog import catalog
from imre.json import encode

functions = {catalog.unquote.__code__: "unquote", catalog.Download.__init__.__code__: "download"}
counts = dict.fromkeys(functions.values(), 0)


def call(code, offset):
    counts[functions[code]] += 1


monitor = sys.monitoring
monitor.use_tool_id(4, "catalog-counts")
monitor.register_callback(4, monitor.events.PY_START, call)
for code in functions:
    monitor.set_local_events(4, code, monitor.events.PY_START)
selection = catalog.Selection({}, {})
result = {}
expected = (INPUTS / "expected.json").read_bytes()
for batch in range(1, 11):
    with (INPUTS / "1x.ndjson").open() as stream:
        for physical in stream:
            for line in physical.splitlines():
                catalog.select_line(selection, line)
    if batch in (1, 10):
        value = (encode(catalog.finish_catalog(selection), indent=2) + "\n").encode()
        assert value == expected
        result[str(batch)] = dict(counts, sha256=hashlib.sha256(value).hexdigest())
        print(batch, counts, flush=True)
monitor.free_tool_id(4)
(ROOT / "winner-counts.json").write_text(json.dumps(result, indent=2) + "\n")
