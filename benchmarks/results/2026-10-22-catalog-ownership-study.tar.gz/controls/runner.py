"""Check long-lived records, generic JSON schemas and Base45 outside the catalog."""
import argparse
import hashlib
import json
import os
import platform
import random
import statistics
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path("/home/dev-user/code/oss/imre-catalog-ownership")
PREVIOUS = Path("/home/dev-user/.cache/imre/conformance-gap-corrected-20261022/generic-inputs")
SOURCES = {
    "retention": ROOT / "retention.py",
    "tiny": PREVIOUS / "tiny/tiny.py",
    "medium": PREVIOUS / "medium/tiny.py",
    "base45": REPO / "examples/base45_codec/driver.py",
}
ENV = dict(os.environ, PYTHONPATH=str(REPO / "stdlib"), PYTHONHASHSEED="0", LC_ALL="C.UTF-8", TZ="UTC")


def identity(path):
    with path.open("rb") as stream:
        return {"sha256": hashlib.file_digest(stream, "sha256").hexdigest(), "bytes": stream.tell()}


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


def prepare():
    sibling_file = ROOT / "siblings.ndjson"
    with sibling_file.open("w") as stream:
        for batch in range(1024):
            rows = []
            for index in range(64):
                name = f"https://downloads.example/long-retained-name/{batch}/{index}"
                rows.append({"name": name, "payload": f"{batch}:{index}:" + "x" * 512, "index": index})
            stream.write(json.dumps(rows, separators=(",", ":")) + "\n")
    data = random.Random(4531).randbytes(65_536)
    (ROOT / "raw.dat").write_bytes(data)
    sys.path.insert(0, str(REPO / "examples/base45_codec"))
    from base45 import b45encode
    (ROOT / "encoded.dat").write_bytes(b45encode(data))
    subprocess.run(["cc", "-O2", REPO / "benchmarks/catalog_process_usage.c", "-o", ROOT / "usage"], check=True)


def build(tag, compiler, runtime, revision):
    out = ROOT / tag
    out.mkdir(exist_ok=True)
    receipt = {"revision": revision, "compiler": identity(compiler), "runtime": identity(runtime), "programs": {}}
    for name, source in SOURCES.items():
        binary = out / name
        ir = out / (name + ".ll")
        cmd = [compiler, "build", source, "--module-root", source.parent, "--clang", "clang-18",
               "--runtime", runtime, "--opt-level", "3", "--emit-llvm", ir, "-o", binary]
        result = subprocess.run(cmd, check=True, capture_output=True)
        assert result.stdout == result.stderr == b""
        receipt["programs"][name] = {"source": identity(source), "binary": identity(binary), "llvm": identity(ir)}
    save(out / "control-builds.json", receipt)


def cases():
    for op in ("discard", "records", "strings"):
        yield "retention-" + op, "retention", [ROOT / "siblings.ndjson", op], None
    for group, count, names in (
        ("tiny", 1500, ("events", "labels", "repeated", "configs")),
        ("medium", 350, ("counters", "labels", "tagged")),
    ):
        for name in names:
            yield f"{group}-{name}", group, [name, PREVIOUS / group / (name + ".ndjson"), str(count)], None
    for op in ("encode", "decode-bytes", "decode-text"):
        encoded = op.startswith("decode")
        source = ROOT / ("encoded.dat" if encoded else "raw.dat")
        output = ROOT / ("raw.dat" if encoded else "encoded.dat")
        yield "base45-" + op, "base45", [op, source, ROOT / "control-output.tmp", "32"], output


def reference(family, args, file):
    if family in ("tiny", "medium"):
        def once(rounds):
            return subprocess.check_output([sys.executable, SOURCES[family], *args[:-1], str(rounds)], env=ENV)
        score, rest = once(1).split(b"\n", 1)
        assert once(2) == str(2 * int(score)).encode() + b"\n" + rest
        return str(int(args[-1]) * int(score)).encode() + b"\n" + rest
    command = [sys.executable, SOURCES[family]]
    if family == "base45":
        from runpy import run_path
        command = run_path(str(REPO / "benchmarks/base45_validate.py"))["python_command"](sys.executable)
    result = subprocess.run([*command, *args], env=ENV, capture_output=True, check=True)
    assert result.stderr == b""
    if file:
        assert (ROOT / "control-output.tmp").read_bytes() == file.read_bytes()
    return result.stdout


def measure(tags, case_filter, cpu, samples, target):
    os.sched_setaffinity(0, {cpu})
    data = {"host": platform.node(), "affinity": [cpu], "source": identity(Path(__file__)), "monitor": identity(ROOT / "usage"),
            "builds": {tag: json.loads((ROOT / tag / "control-builds.json").read_bytes()) for tag in tags}, "cases": {}}
    for name, family, args, file in cases():
        if case_filter and not any(name.startswith(item) for item in case_filter):
            continue
        expected = reference(family, args, file)
        input_file = next(x for x in args if isinstance(x, Path) and x.name != "control-output.tmp")
        runs = []
        for index in range(samples + 1):
            order = tags if index % 4 in (0, 1) else list(reversed(tags))
            for tag in order:
                metric = ROOT / "control-usage.tmp"
                if file:
                    (ROOT / "control-output.tmp").unlink(missing_ok=True)
                command = [ROOT / "usage", metric, ROOT / tag / family, *args]
                child = subprocess.run(command, env=ENV, capture_output=True, check=True)
                assert child.stderr == b"" and child.stdout == expected, (tag, name, child.stderr)
                if file:
                    assert (ROOT / "control-output.tmp").read_bytes() == file.read_bytes()
                elapsed, rss = map(int, metric.read_text().split())
                runs.append({"round": index, "engine": tag, "elapsed_ns": elapsed, "rss_kib": rss})
        medians = {tag: {key: statistics.median(x[key] for x in runs if x["round"] and x["engine"] == tag)
                         for key in ("elapsed_ns", "rss_kib")} for tag in tags}
        data["cases"][name] = {"input": identity(input_file), "observations": runs, "medians": medians,
                               "stdout": hashlib.sha256(expected).hexdigest(), "output": identity(file) if file else None}
        print(name, medians, flush=True)
        save(target, data)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("prepare")
    compiler = sub.add_parser("build")
    compiler.add_argument("tag")
    compiler.add_argument("compiler", type=Path)
    compiler.add_argument("runtime", type=Path)
    compiler.add_argument("revision")
    study = sub.add_parser("measure")
    study.add_argument("tags", nargs="+")
    study.add_argument("--case", action="append")
    study.add_argument("--samples", type=int, default=8)
    study.add_argument("--cpu", type=int, default=29)
    study.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.action == "prepare":
        prepare()
    elif args.action == "build":
        build(args.tag, args.compiler, args.runtime, args.revision)
    else:
        measure(args.tags, args.case, args.cpu, args.samples, args.output)
