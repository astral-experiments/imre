#!/usr/bin/python3
"""Link compiler-supplied bytes under the original filename retained in the measured ELF."""
import hashlib,json,os,re,subprocess,sys
from pathlib import Path
cfg=json.loads(Path(os.environ['RELAR_IDENTITY_REPLAY_CONFIG']).read_bytes())
args=sys.argv[1:]
inputs=[i for i,v in enumerate(args) if re.fullmatch(r'/tmp/relar-[a-zA-Z0-9_-]+\.ll',v)]
assert len(inputs)==1 and re.fullmatch(r'relar-[a-zA-Z0-9_-]+\.ll',cfg['original_basename'])
i=inputs[0]; ir=Path(args[i]).read_bytes()
assert hashlib.sha256(ir).hexdigest()==cfg['expected_ir_sha256']
canonical=Path('/tmp')/cfg['original_basename']
if Path(args[i])==canonical:
 canonical_owned=False
else:
 with canonical.open('xb') as f:f.write(ir)
 canonical_owned=True
try:
 args[i]=str(canonical)
 cmd=[cfg['real_clang'],*args]
 Path(cfg['link_command_log']).write_text(json.dumps({'command':cmd,'original_compiler_temporary':sys.argv[1+i],'environment':cfg['environment'],'llvm_sha256':cfg['expected_ir_sha256']},indent=2)+'\n')
 result=subprocess.run(cmd,env=cfg['environment'])
finally:
 if canonical_owned:canonical.unlink()
sys.exit(result.returncode)
