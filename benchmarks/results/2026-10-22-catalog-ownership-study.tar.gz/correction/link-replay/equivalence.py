"""Verify whether a newly source-locked compiler produces the exact measured catalog executables."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,re,runpy,shutil,subprocess,sys
cache=Path('/home/dev-user/.cache/relar/catalog-ownership-20261022')
old='db44bcc2e9d0f3dca291ed141d7b742227ab44b4'
rev,root=sys.argv[1],Path(sys.argv[2]).resolve()
assert re.fullmatch('[0-9a-f]{40}',rev) and rev!=old
py='/home/dev-user/.local/bin/python3.14';original=cache/'candidates'/old[:7];candidate=cache/'candidates'/rev[:7]
out=cache/('equivalence-'+rev[:7]);out.mkdir(exist_ok=False)
now=lambda: datetime.now(timezone.utc).isoformat()
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def identity(p):return {'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
def read(path):return json.loads(path.read_bytes())
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==rev and not git('status','--porcelain')
assert subprocess.run(['git','merge-base','--is-ancestor',old,rev],cwd=root).returncode==0
inputs=['crates/relar-runtime','Cargo.toml','Cargo.lock','examples/python_catalog','stdlib','benchmarks/catalog_validate.py','benchmarks/stream_catalog_benchmark.py','benchmarks/stream_catalog_audit.py','benchmarks/live_conformance_build.py','benchmarks/native_tools_build.py','benchmarks/native_tools_profile.py','benchmarks/reference/python_catalog','benchmarks/codon_native']
assert git('diff','--name-only',old,rev,'--',*inputs)==''
assert (cache/('final-'+old[:7])/'finished').exists() and (candidate/'finished').exists()
lock=(cache/'cpu31.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
frozen_root=Path(read(original/'programs/normal/build-record.json')['steps'][0]['cwd'])
benches={d:runpy.run_path(str(w/'benchmarks/live_conformance_benchmark.py')) for d,w in [(original,frozen_root),(candidate,root)]}
guard={}
verify=lambda p:next(v for d,v in benches.items() if p.is_relative_to(d))['verify_build_record'](p,guard)
elf_diff=runpy.run_path(str(Path(__file__).with_name('elf-diff.py')))['diff']
cores=[verify(d/'core/build-record.json') for d in (original,candidate)]
assert [c['revision'] for c in cores]==[old,rev] and all(c['input_guards_passed'] and c['source_matches_revision'] for c in cores)
assert all(cores[0][k]==cores[1][k] for k in ('toolchain','cargo','target','tool_paths','tool_sha256','driver_sha256'))
oldstage=cache/('final-'+old[:7]);matrix=read(oldstage/'measurements/results.json');assert matrix['completed'] and matrix['revision']==old
wrapper=Path(__file__).with_name('clang-replay.py'); assert os.access(wrapper,os.X_OK)
record={'measured_revision':old,'candidate_revision':rev,'started':now(),'kind':'canonical-link-artifact-equivalence','status':'running','source_changes':git('diff','--name-status',old,rev).splitlines(),'unchanged_git_trees':{k:git('rev-parse',rev+':'+k) for k in inputs},'core_build_records':[identity(d/'core/build-record.json') for d in (original,candidate)],'matrix':identity(oldstage/'measurements/results.json'),'link_adapter':identity(wrapper),'modes':{}}
programs=out/'programs'
try:
 for mode in ('normal','thinlto','asan'):
  oldprog=original/'programs'/mode;newprog=candidate/'programs'/mode;modeout=programs/mode;modeout.mkdir(parents=True)
  oldrecord=verify(oldprog/'build-record.json');newrecord=verify(newprog/'build-record.json')
  assert oldrecord['revision']==old and newrecord['revision']==rev
  assert oldrecord['tools']==newrecord['tools'] and oldrecord['tool_versions']==newrecord['tool_versions'] and oldrecord['environment']==newrecord['environment']
  assert {f:item['sha256'] for f,item in oldrecord['retained_sources'].items()}=={f:item['sha256'] for f,item in newrecord['retained_sources'].items()}
  runtime=original/'core'/(mode+'_runtime.a')
  mode_info=record['modes'][mode]={'measured_program_record':identity(oldprog/'build-record.json'),'ordinary_candidate_program_record':identity(newprog/'build-record.json'),'unchanged_runtime_source':git('rev-parse',rev+':crates/relar-runtime'),'canonical_archive':identity(runtime),'new_build_archive':identity(candidate/'core'/(mode+'_runtime.a')),'programs':{}}
  assert cores[0]['sha256'][mode+'_runtime']==sha(runtime) and cores[1]['sha256'][mode+'_runtime']==mode_info['new_build_archive']['sha256']
  for suffix in ('','-compute'):
   name='python_catalog'+suffix; oldbin=oldprog/name; newbin=newprog/name; target=modeout/name
   ir=oldrecord['llvm'][name]['sha256'];assert ir==newrecord['llvm'][name]['sha256']==sha(oldprog/(name+'.ll'))==sha(newprog/(name+'.ll'))
   files=set(re.findall(r'relar-[a-zA-Z0-9_-]+\.ll',subprocess.check_output(['readelf','-Ws',oldbin],text=True)))
   assert len(files)==1,(mode,name,files)
   config=modeout/(name+'-config.json');log=modeout/(name+'-link-command.json')
   write(config,{'original_basename':files.pop(),'expected_ir_sha256':ir,'real_clang':oldrecord['tools']['clang']['path'],'link_command_log':str(log),'environment':oldrecord['environment']})
   cmd=list(next(s['command'] for s in newrecord['steps'] if s['name']==name))
   cmd[cmd.index('--runtime')+1]=str(runtime);cmd[cmd.index('--clang')+1]=str(wrapper);cmd[cmd.index('-o')+1]=str(target);cmd[cmd.index('--emit-llvm')+1]=str(target)+'.ll'
   cp=subprocess.run(cmd,cwd=root,env={**newrecord['environment'],'RELAR_IDENTITY_REPLAY_CONFIG':str(config)},capture_output=True)
   (modeout/(name+'.stderr')).write_bytes(cp.stderr);assert cp.returncode==0,(mode,name,cp.stderr[-1500:])
   assert sha(str(target)+'.ll')==ir
   info=mode_info['programs'][name]={'llvm_sha256':ir,'measured_binary':identity(oldbin),'regular_candidate_binary':identity(newbin),'canonical_candidate_binary':identity(target),'compiler_command':cmd,'link_command':read(log),'exact_bytes':oldbin.read_bytes()==target.read_bytes(),'regular_binary_elf_diff':elf_diff(oldbin,newbin),'measured_temporary_basename':read(config)['original_basename'],'as_built_candidate_temporary_basenames':sorted(set(re.findall(r'relar-[a-zA-Z0-9_-]+\.ll',subprocess.check_output(['readelf','-Ws',newbin],text=True))))}
   if name=='python_catalog' and mode in ('normal','thinlto'):assert info['measured_binary']['sha256']==matrix['hashes']['relar' if mode=='normal' else 'relar_thin']['sha256']
   assert info['exact_bytes'],(mode,name,'canonical linked binary differs',info['measured_binary']['sha256'],info['canonical_candidate_binary']['sha256'])
 validation=out/'validation';validation.mkdir();cli=[py,str(root/'benchmarks/catalog_validate.py'),'--python',py]
 jobs=[('edge-five',4,cli+['--binary',programs/'normal/python_catalog','--rust',matrix['hashes']['rust']['path'],'--codon',matrix['hashes']['codon']['path'],'--output',validation/'edge-five.json'],{}),('edge-thin',5,cli+['--binary',programs/'thinlto/python_catalog','--output',validation/'edge-thin.json'],{}),('asan-catalog',6,cli+['--binary',programs/'asan/python_catalog','--output',validation/'asan-catalog.json'],{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1'}),('asan-compute',7,cli+['--binary',programs/'asan/python_catalog-compute','--compute','--output',validation/'asan-compute.json'],{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1'}),('ownership-stress',8,[py,cache/'recipes/ownership-boundary-stress.py',root,programs,validation/'owners'],{})]
 def run(job):
  label,cpu,cmd,add=job
  with (validation/(label+'.log')).open('wb') as f:subprocess.run(['taskset','-c',str(cpu),*map(str,cmd)],cwd=root,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,**add},check=True)
 with ThreadPoolExecutor(5) as pool:list(pool.map(run,jobs))
 checks={}
 for variant,prog in [('as_built',candidate/'programs'),('canonical',programs)]:
  for mode in ('normal','thinlto','asan'):
   for case in ('1x-plain','1x-gzip','10x-plain','10x-gzip'):
    inp=Path(matrix['inputs']['inputs'][case]['path']);assert sha(inp)==matrix['inputs']['inputs'][case]['sha256']
    label=variant+'-'+mode+'-'+case;path=validation/(label+'.json');cmd=[prog/mode/'python_catalog',inp,path]
    cp=subprocess.run(cmd,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1'});assert cp.returncode==0 and not cp.stdout and not cp.stderr
    checks[label]=identity(path);assert checks[label]['sha256']==matrix['inputs']['expected']['sha256']
 record['complete_output_checks']=checks;record['validation']={str(p.relative_to(out)):identity(p) for p in sorted(validation.rglob('*.json')) if p.name in ('edge-five.json','edge-thin.json','asan-compute.json','asan-catalog.json','results.json')}
 assert git('rev-parse','HEAD')==rev and not git('status','--porcelain')
 record['status']='passed'
except BaseException as e:
 record['status']='failed';record['error']=repr(e);raise
finally:
 record['finished']=now();write(out/'artifact-equivalence.json',record)
print(out/'artifact-equivalence.json',sha(out/'artifact-equivalence.json'))
