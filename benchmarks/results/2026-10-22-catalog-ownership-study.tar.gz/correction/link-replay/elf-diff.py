"""Locate true byte differences, including non-loadable filename metadata."""
import hashlib,struct
def segments(b):
 h=struct.unpack_from('<16sHHIQQQIHHHHHH',b);assert h[0][:6]==b'\x7fELF\x02\x01'
 sh=[struct.unpack_from('<IIQQQQIIQQ',b,h[6]+i*h[11]) for i in range(h[12])]
 ns=sh[h[13]]
 table=b[ns[4]:ns[4]+ns[5]]
 entries={}
 for s in sh:
  if s[1]==8 or not s[5]:continue
  name=table[s[0]:table.index(b'\0',s[0])].decode()
  entries[name]=[s[4],s[5],bool(s[2]&2)]
 ph=[struct.unpack_from('<IIQQQQQQ',b,h[5]+i*h[9]) for i in range(h[10])]
 return entries,[(p[1],p[2],p[3],p[5],hashlib.sha256(b[p[2]:p[2]+p[5]]).hexdigest()) for p in ph if p[0]==1]
def diff(a,b):
 a,b=a.read_bytes(),b.read_bytes()
 aa,pa=segments(a);bb,pb=segments(b);ds={}
 for k in sorted(set(aa)|set(bb)):
  if k not in aa or k not in bb:ds[k]={'membership_differs':True};continue
  i,n,alloc=aa[k];j,m,alloc2=bb[k];x,y=a[i:i+n],b[j:j+m]
  if x==y:continue
  differing=[z for z,(u,v) in enumerate(zip(x,y)) if u!=v]
  ds[k]={'allocated':alloc or alloc2,'before_bytes':n,'after_bytes':m,'differing_bytes_including_size':len(differing)+abs(n-m),'first_16_changed_section_bytes':[{'offset':z,'before':x[z],'after':y[z]} for z in differing[:16]]}
 return {'before_size':len(a),'after_size':len(b),'identical':a==b,'differing_bytes_whole_file':sum(u!=v for u,v in zip(a,b))+abs(len(a)-len(b)),'loadable_segments_byte_identical':pa==pb,'differing_sections':ds}
