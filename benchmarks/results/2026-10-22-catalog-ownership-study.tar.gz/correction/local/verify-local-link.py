import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
local = out.parents[1]
repo = Path('/home/dev-user/code/oss/relar-catalog-ownership')
compiler = out / 'relar'
runtime = out / 'runtime.a'
assert (out / 'revision').read_text().strip() == 'db2a6f876e94fa136450ad3efe56c110e376b17d'


def digest(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


evidence = {'revision': (out / 'revision').read_text().strip(), 'compiler': digest(compiler), 'runtime': digest(runtime), 'programs': {}}
definitions = [('catalog', repo/'examples/python_catalog/__main__.py', ['--module-root', str(repo/'examples')], local/'final/catalog.ll', local/'final/catalog'),
               ('guard-control', local/'stable-local/selectivity/guarded-filenames.py', [], local/'stable-local/selectivity/final.ll', local/'stable-local/selectivity/final-bin')]
for name, source, roots, reference_ir, reference_binary in definitions:
    work = out / name
    work.mkdir(exist_ok=True)
    ir, binary = work/'new.ll', work/'new'
    subprocess.run([compiler, 'build', source, *roots, '--runtime', runtime, '--clang', 'clang-18', '--opt-level', '3', '--emit-llvm', ir, '-o', binary], check=True)
    assert ir.read_bytes() == reference_ir.read_bytes()
    expected = reference_binary.read_bytes()
    fresh = binary.read_bytes()
    matches = re.findall(rb'(?<=\x00)relar-[A-Za-z0-9]{6}\.ll(?=\x00)', expected)
    assert len(matches) == 1 and len(fresh) == len(expected)
    begin = expected.index(matches[0]) + len(b'relar-')
    differences = [n for n, (a, b) in enumerate(zip(expected, fresh)) if a != b]
    assert set(differences) <= set(range(begin, begin + 6))
    same_basename = work / matches[0].decode()
    shutil.copy2(ir, same_basename)
    relinked = work/'canonical'
    subprocess.run(['clang-18', '-O3', '-Wno-override-module', same_basename, runtime, '-ldl', '-lpthread', '-lm', '-lrt', '-lutil', '-o', relinked], check=True)
    assert relinked.read_bytes() == expected
    evidence['programs'][name] = {'reference': digest(reference_binary), 'fresh_cli': digest(binary), 'canonical_link': digest(relinked), 'llvm': digest(ir), 'original_llvm_basename': matches[0].decode(), 'differing_cli_bytes': differences, 'artifact_bytes': len(expected)}
(out/'link-equivalence.json').write_text(json.dumps(evidence, sort_keys=True, indent=2) + '\n')
print(json.dumps(evidence['programs'], indent=2))
