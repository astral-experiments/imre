"""Exercise escaping catalog fields across row teardown, string lengths and record batch sizes."""
from pathlib import Path
import gzip,hashlib,json,os,runpy,subprocess,sys
root,programs,out=map(Path,sys.argv[1:]);out.mkdir()
before=Path('/home/dev-user/.cache/relar-catalog-gap-20261022/final-34abb56/measurements/results.json')
prior=json.loads(before.read_bytes()); py=Path(prior['hashes']['python']['path'])
def sha(data):return hashlib.sha256(data).hexdigest()
os.chdir(root)
catalog=runpy.run_path(str(root/'benchmarks/catalog_validate.py'))
commands={'original':catalog['original_command'](py),'port':catalog['python_command'](py)}
for e in ('codon','rust','rust_thin'):commands[e]=[prior['hashes'][e]['path']]
for e,mode in [('relar','normal'),('relar_thin','thinlto'),('asan','asan')]:commands[e]=[str(programs/mode/'python_catalog')]
env=catalog['environment']();env['ASAN_OPTIONS']='detect_leaks=1:halt_on_error=1'
widths=(1,7,15,16,22,23,24,25,31,32,63,64,65,127,128,129,255,256,511,512,513,1023,1024,1025,2048,33)
counts=(1,2,3,7,8,15,16,23,24,31,32,63,64,65,127,128,129,255,256,257,511,513,2,17,33,34)
early=[];late=[];expected={}
for i,(width,count) in enumerate(zip(widths,counts,strict=True)):
 patch=100+i
 version=f'3.14.{patch}+20261020'
 # Every designated winner is distinct, crosses a raw string boundary and survives subsequent row destruction.
 name='a'*width
 if i%4==0 and width>=9:name='a'*(width-9)+'%C3%A9%25'
 elif i%4==1 and width>=3:name='a'*(width-3)+'%2B'
 elif i%4==2 and width>=2:name='a'*(width-2)+'é'
 if i%6==4 and width>=3:name="a"*(width-3)+"%00"
 elif i%6==5:name="a"*(width-1)+"\0"
 assert len(name.encode())==width
 checksum=hashlib.sha256(f'preserved-{i}'.encode()).hexdigest()
 early.append(catalog['release']([catalog['artifact']('replaced-'+str(i),variant='full')],version))
 winner={**catalog['artifact'](), 'url':name,'sha256':checksum}
 others=[catalog['artifact']('z-'+str(i)+'-'+str(j)+'-'+'x'*width,sha256=hashlib.sha256(f'loser-{i}-{j}'.encode()).hexdigest()) for j in range(count-1)]
 late.append(catalog['release'](others+[winner],version))
 expected[patch]=(name,checksum)
# Early storage outlives every transient decoded row. Replacements happen in reverse key order.
rows=[catalog['ndjson']([r]) for r in early+late[::-1]]
files={'plain':out/'owners.ndjson','gzip':out/'owners.ndjson.gz'}
files['plain'].write_bytes(b''.join(rows));files['gzip'].write_bytes(b''.join(gzip.compress(row,mtime=0) for row in rows))
receipt={'record_batch_counts':list(counts),'string_utf8_byte_lengths':list(widths),'rows':len(rows),'input':{},'observations':[]}
expected_bytes=None
for kind,source in files.items():
 receipt['input'][kind]={'bytes':source.stat().st_size,'sha256':sha(source.read_bytes())}
 for engine,command in commands.items():
  target=out/(kind+'-'+engine+'.json')
  proc=subprocess.run([*map(str,command),str(source),str(target)],stdin=subprocess.DEVNULL,capture_output=True,cwd=out,env=env,timeout=120)
  assert not proc.returncode and not proc.stderr and not proc.stdout,(engine,kind,proc.returncode,proc.stderr[:300],proc.stdout[:150])
  data=target.read_bytes();actual=json.loads(data)
  if expected_bytes is None:
   assert engine=='original' and kind=='plain'
   got={int(v['patch']):(v['url'],v['sha256']) for v in actual.values()}
   assert got==expected,(len(got),len(expected),list(got.items())[:1])
   expected_bytes=data
  assert data==expected_bytes,(kind,engine)
  receipt['observations'].append({'engine':engine,'format':kind,'sha256':sha(data),'bytes':len(data)})
receipt['entries']=len(expected);receipt['oracle_sha256']=sha(expected_bytes)
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('pass',len(receipt['observations']),len(expected),sha(expected_bytes))
