#!/usr/bin/env python3
"""Replay the catalog ownership study using its source checkout and standard library."""
import argparse
import gzip
import hashlib
import json
import re
import statistics
import subprocess
import tarfile
import sys
from pathlib import Path

if not __debug__:
    raise SystemExit("Run with Python assertions enabled.")
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("measurements", type=Path)
parser.add_argument("previous_measurements", type=Path)
parser.add_argument("--source-root", type=Path, required=True,
                    help="checkout or git archive of the measured revision")
args = parser.parse_args()
study = Path(__file__).resolve().parent
load = lambda file: json.loads(file.read_bytes())
digest = lambda raw: hashlib.sha256(raw).hexdigest()
def identity(path):
    with path.open("rb") as file:
        return {"sha256": hashlib.file_digest(file, "sha256").hexdigest(), "bytes": path.stat().st_size}

# Check every archived payload, including this script, before using it.
members = {}
for line in (study / "SHA256SUMS").read_text().splitlines():
    checksum, relative = line.split("  ", 1)
    assert relative not in members and not Path(relative).is_absolute() and ".." not in Path(relative).parts
    assert identity(study / relative)["sha256"] == checksum, relative
    members[relative] = checksum
manifest = load(study / "manifest.json")
assert set(members) == set(manifest["members"]) | {"manifest.json"}
assert all(identity(study / name)["bytes"] == length for name, length in manifest["members"].items())
matrix_file = args.measurements
prior_file = args.previous_measurements
audit_file = matrix_file.with_name(manifest["audit_file"])
for path, key in [(matrix_file, "measurements"), (prior_file, "previous_measurements"), (audit_file, "audit")]:
    assert identity(path) == manifest["external"][key], key
raw = gzip.decompress(matrix_file.read_bytes())
prior_raw = gzip.decompress(prior_file.read_bytes())
matrix, previous = json.loads(raw), json.loads(prior_raw)
audit = load(audit_file)
assert matrix["revision"] == manifest["revision"] and matrix["completed"] and not matrix["pilot"]
assert audit["record_sha256"] == identity(matrix_file)["sha256"] and audit["json_sha256"] == digest(raw)
portable = json.loads(subprocess.check_output([
    sys.executable, str(args.source_root / "benchmarks/stream_catalog_audit.py"), str(matrix_file),
    "--source-root", str(args.source_root), "--sha256", audit["record_sha256"],
]))
assert portable == load(study / "audits/portable.json") and portable["measured"] == 392 and portable["warmups"] == 28
assert audit["portable"] == {"record_sha256": identity(matrix_file)["sha256"], "statistics_match_strict": True}
strict = load(study / "audits/strict.json")
assert strict["record_sha256"] == audit["strict_measuring_host"]["record_sha256"] == digest(raw)
assert strict["strict_files_checked"] == audit["strict_measuring_host"]["retained_files_rehashed"] > 0
for key in ["measured", "warmups", "medians", "peak_rss_10x_over_1x", "elapsed_10x_over_1x", "imre_over_rust"]:
    assert strict[key] == portable[key] == audit[key]
build=load(study/"build-identity.json")
assert build["revision"]==matrix["revision"] and build["baseline_program_revision"]==previous["revision"]
assert identity(study/"builds/bound-builds.json")==build["files"]["bound-builds.json"]
for mode, label in [("normal","imre"),("thinlto","imre_thin")]:
    for stage, matrix_doc in [("optimized",matrix),("baseline",previous)]:
        program=build["programs"][stage+"-"+mode]["binary"]
        assert all(program[k]==matrix_doc["hashes"][label][k] for k in ["bytes","sha256"])
paired = load(study / "paired.json")
paired_audit = load(study / "paired-host-audit.json")
assert paired["baseline_sha256"] == paired_audit["baseline_matrix_sha256"] == digest(prior_raw)
assert paired_audit["final_matrix_sha256"] == digest(raw)
assert paired_audit["source_sha256"] == identity(study / "paired.json")["sha256"]
assert paired_audit["pilot_driver_sha256"] == identity(study / "native-paired-runner.py")["sha256"]
assert paired["paths"]["oracle"]["sha256"] == matrix["inputs"]["expected"]["sha256"]
assert all(paired["paths"][label]["sha256"] == f["sha256"] for label,f in matrix["inputs"]["inputs"].items())
assert paired["paths"]["monitor"]["sha256"] == previous["hashes"]["monitor"]["sha256"]
summary = json.loads(subprocess.check_output([
    sys.executable, str(study / "verify-paired.py"), str(study / "paired.json"), str(prior_file), str(matrix_file),
]))
measured = warmups = 0
for label, case in paired["cases"].items():
    assert [row["engine"] for row in case["warmup"]] == paired["orders"][0][::-1]
    warmups += len(case["warmup"])
    measured += sum(map(len, case["samples"]))
    for mode, suffix in [("ordinary",""),("thinlto","_thin")]:
        host = paired_audit["cases"][label][mode]
        for key in ["elapsed_reduction","after_over_rust"]:
            assert host[key] == summary[label][mode][key]
        native = [{x["engine"]: x["elapsed_ns"] for x in row} for row in case["samples"]]
        ratios = [r["after"+suffix] / r["before"+suffix] for r in native]
        assert host["median_same_round_after_over_before"] == statistics.median(ratios)
        assert (host["same_round_after_over_before_min"], host["same_round_after_over_before_max"]) == (min(ratios),max(ratios))
        assert host["rounds_faster_than_before"] == sum(v < 1 for v in ratios)
assert (measured, warmups) == (144, 24)

profiles = load(study / "profiles/index.json")
assert set(profiles) == {"1x","10x"}
for scale, engines in profiles.items():
    assert set(engines) == {"baseline","optimized","rust"}
    for engine, tools in engines.items():
        assert set(tools) == {"dhat","callgrind"}
        for tool, p in tools.items():
            folder = study / "profiles" / scale / engine / tool
            trace = folder / "trace"
            assert identity(trace) == p["trace"] and identity(folder / "log") == p["log"]
            assert p["input"]["sha256"] == matrix["inputs"]["inputs"][scale+"-plain"]["sha256"]
            assert p["full_output"]["sha256"] == matrix["inputs"]["expected"]["sha256"]
            if tool == "dhat":
                points = load(trace)["pps"]
                counts = {key: sum(row[key] for row in points) for key in ("tbk","tb","gb","gbk")}
            else:
                text = trace.read_text()
                assert re.search(r"(?m)^events: Ir$",text)
                totals = re.findall(r"(?m)^totals: (\d+)$", text)
                assert len(totals) == 1
                counts = {"instructions": int(totals[0])}
            assert counts == p["metrics"], (scale,engine,tool)
            if scale == "10x":
                binary = previous["hashes"]["imre"] if engine == "baseline" else matrix["hashes"]["imre" if engine=="optimized" else "rust"]
                assert p["binary"] == {k:binary[k] for k in ["bytes","sha256"]}
controls = load(study / "controls/measurements.json")
assert set(controls["builds"]) == {"baseline","final"} and len(controls["cases"]) == 13
control_count = control_warmups = 0
for name, case in controls["cases"].items():
    rows = case["observations"]
    assert {(v["round"], v["engine"]) for v in rows} == {(n,e) for n in range(9) for e in controls["builds"]}
    assert len(rows) == 18 and len(case["stdout"])==64
    for e,r in case["medians"].items():
        assert all(r[k] == statistics.median(x[k] for x in rows if x["round"] and x["engine"]==e) for k in ("elapsed_ns","rss_kib"))
    assert all(x["elapsed_ns"]>0 and x["rss_kib"]>0 for x in rows)
    control_count += sum(bool(r["round"]) for r in rows)
    control_warmups += sum(not r["round"] for r in rows)
assert (control_count,control_warmups) == (208,26)
v=load(study/"validation.json")
assert v["revision"] == matrix["revision"]
assert v["full_catalog"] == {k:matrix["inputs"]["expected"][k] for k in ("bytes","sha256")}
assert all(x["engine_executions"]==sum(x["executions_by_engine"].values()) for x in v["catalogs"].values())
assert [(v["catalogs"][k]["cases"],v["catalogs"][k]["engine_executions"]) for k in ["edge-five","edge-thin","asan-catalog","asan-compute"]] == [(66,321),(66,193),(66,193),(14,41)]
stress=load(study/"validation/ownership-boundaries.json")
assert len(stress["observations"])==16 and stress["rows"]==52 and stress["entries"]==26
assert {row["format"] for row in stress["observations"]}=={"plain","gzip"}
assert len({(row["engine"],row["format"]) for row in stress["observations"]})==16
assert all(row["sha256"]==stress["oracle_sha256"] and row["bytes"]>0 for row in stress["observations"])
units=(study/"validation/local/unit.log").read_text()
assert sum(map(int,re.findall(r"^test result: ok\. (\d+) passed; 0 failed;",units,re.M)))==v["local"]["unit_tests"]["total"]==301
for mode in ["ordinary","asan-lsan"]:
    assert len(v["local"][mode])==12
    for suite, proof in v["local"][mode].items():
        log=study / "validation/local" / mode / (suite+".log")
        assert identity(log)==proof["log"]
        rawlog=log.read_text()
        if suite=="base45":
            assert all(f"O{level}: Passed 323 upstream native calls, 289 differential cases, and 2 compile-time type rejections" in rawlog for level in [0,3])
        else:
            assert f'Passed {proof["reported_suite_checks"]} ' in rawlog and f'ASan={mode=="asan-lsan"}' in rawlog
probes=load(study/"validation/semantics/receipt.json")
archive=study/"validation/semantics/probes.tar.gz"
assert probes["revision"] == matrix["revision"] and identity(archive) == probes["reproduction"]["probes.tar.gz"]
with tarfile.open(archive) as packed:
    assert set(packed.getnames()) == set(probes["archive_members"])
    for member in packed.getmembers():
        payload = packed.extractfile(member).read()
        assert {"bytes":len(payload),"sha256":digest(payload)} == probes["archive_members"][member.name]
    live=json.loads(packed.extractfile("retention.json").read())
    assert live["final_revision"]==matrix["revision"]
    for n, observations in live["cases"]["integrated"]["observations"].items():
        joined=[run["after_thread_join_bytes"] for run in observations.values()]
        idle=[run["saturated_idle_bytes"] for run in observations.values()]
        winner=observations["one_winner"]
        result=probes["retention"][n]
        assert result["closed_thread_bytes"]==sorted(set(joined))==[0]
        assert result["saturated_idle_range"]==[min(idle),max(idle)]
        assert result["escaped_with_saturated_cache"]==winner["before_winner_drop_with_full_cache_bytes"]-winner["saturated_idle_bytes"]==winner["isolated_winner_bytes"]==712
    differential=json.loads(packed.extractfile("differential.json").read())
    for label,case in differential["cases"].items():
        output=gzip.decompress(packed.extractfile(label+"-cpython.txt.gz").read())
        assert digest(output)==case["cpython_stdout_sha256"]
        native=output if label=="guard" else gzip.decompress(packed.extractfile(label+"-main.txt.gz").read())
        assert digest(native)==case["main_stdout_sha256"]
        assert len(case["variants"])==4 and all(v["stdout_sha256"]==digest(native) and v["exit_code"]==v["stderr_bytes"]==0 for v in case["variants"].values())
assert probes["native_differential_variants"]==12 and probes["native_retention_observations"]==36
if correction_revision := manifest.get("post_measurement_revision"):
    info=load(study/"correction/index.json")
    exact=load(study/"correction/artifact-equivalence.json")
    assert info["corrected_source_revision"]==correction_revision==exact["candidate_revision"]
    assert exact["status"]=="passed" and exact["measured_revision"]==matrix["revision"]
    assert exact["matrix"]["sha256"]==digest(raw)
    for mode, original in [("normal","optimized-normal"),("thinlto","optimized-thinlto"),("asan","optimized-asan")]:
        programs=exact["modes"][mode]["programs"]
        assert set(programs)=={"python_catalog","python_catalog-compute"}
        for name,program in programs.items():
            assert program["exact_bytes"] and all(program["measured_binary"][k]==program["canonical_candidate_binary"][k] for k in ("sha256","bytes"))
            if name=="python_catalog":
                assert program["measured_binary"]["sha256"]==build["programs"][original]["binary"]["sha256"]
                assert program["llvm_sha256"]==build["programs"][original]["ir"]["sha256"]
    assert len(exact["complete_output_checks"])==24 and all(c["sha256"]==matrix["inputs"]["expected"]["sha256"] and c["bytes"]==matrix["inputs"]["expected"]["bytes"] for c in exact["complete_output_checks"].values())
    supplemental_audit=load(study/"correction/remote-build-audit.json")
    assert supplemental_audit["record_sha256"]==identity(study/"correction/artifact-equivalence.json")["sha256"] and supplemental_audit["matrix_sha256"]==digest(raw)
    repaired=load(study/"correction/remote-validation.json")
    assert repaired["total"]==sum(q["engine_executions"] for q in repaired["catalogs"].values())+repaired["ownership_observations"]==764
    for name,result in repaired["catalogs"].items():
        assert result["raw_receipt"]["sha256"]==exact["validation"]["validation/"+name+".json"]["sha256"]
        assert result["complete_file_effects_stdout_and_category_manifest_sha256"]==v["catalogs"][name]["complete_file_effects_stdout_and_category_manifest_sha256"]
    local_links=load(study/"correction/local/link-equivalence.json")
    assert local_links["revision"]==correction_revision and local_links["compiler"]==info["exact_local_compiler"]["sha256"]
    assert all(prog["canonical_link"]==prog["reference"] for prog in local_links["programs"].values())
    local_differential=load(study/"correction/local/differential.json")
    assert local_differential["revision"]==correction_revision and local_differential["compiler"]==info["exact_local_compiler"]
    assert sum(c.get("rows",0) for c in local_differential["cases"].values())==1006
    for result in local_differential["cases"].values():
        assert len(result["variants"])==4 and all(q["stdout_sha256"]==result["main_stdout_sha256"] and q["exit_code"]==q["stderr_bytes"]==0 for q in result["variants"].values())
    assert sum(map(int,re.findall(r"^test result: ok\. (\d+) passed; 0 failed;",(study/"correction/suites/unit.log").read_text(),re.M)))==sum(info["units"].values())==302
    for mode, reports in info["ordinary_and_asan_workspace_suites"].items():
        assert len(reports)==12 and all(identity(study/f"correction/suites/{mode}/{name}.log")==value for name,value in reports.items())
    selective=load(study/"correction/selectivity.json")
    artifact=study/"correction/selectivity.tar.gz"
    assert selective["revision"]==correction_revision and identity(artifact)==selective["bundle"]
    with tarfile.open(artifact) as packed:
        assert set(packed.getnames())==set(selective["files"])
        for member in packed.getmembers():
            b=packed.extractfile(member).read()
            assert {"bytes":len(b),"sha256":digest(b)}==selective["files"][member.name]
        timings=json.load(packed.extractfile("timing.json"))
        assert len(timings["samples"])*2==selective["timing_processes"]==192
        for keep in ["0","1","16","32"]:
            rows=[r for r in timings["samples"] if r["keep_out_of_32"]==int(keep)]
            assert len(rows)==24 and all(r["engines"]["main"]["output_sha256"]==r["engines"]["final"]["output_sha256"] for r in rows)
            def median_time(label):return statistics.median(r["engines"][label]["elapsed_ns"] for r in rows)
            assert median_time("final")/median_time("main")==selective["summaries"][keep]["ratio_of_medians"]
            assert statistics.median(r["engines"]["final"]["elapsed_ns"]/r["engines"]["main"]["elapsed_ns"] for r in rows)==selective["summaries"][keep]["paired_ratio_median"]
        crossed=json.load(packed.extractfile("crossed.json"))
        assert len(crossed["samples"])*4==selective["all_kept_crossed_processes"]==64
        assert all(len({r["output_sha256"] for r in row["engines"].values()})==1 for row in crossed["samples"])
        def crossover(key):return statistics.median(row["engines"][key]["elapsed_ns"] for row in crossed["samples"])
        for name,a,b in [("integrated_over_main","final","main"),("guard_on_old_runtime","delayed-old","main"),("guard_on_new_runtime","final","eager-new"),("runtime_on_delayed_compiler","final","delayed-old"),("runtime_on_eager_compiler","eager-new","main")]:
            assert crossover(a)/crossover(b)==selective["all_kept_crossed_ratios"][name]
        bounds=json.load(packed.extractfile("bounded.json"))
        assert len(bounds["oracles"])==24 and sum(map(len,bounds["cases"].values()))==selective["bounded_cases"]==72
        for engine,cases in bounds["cases"].items():
            for case,observed in cases.items():
                assert observed["exit_code"]==0 and observed["stdout_sha256"]==bounds["oracles"][case]
                if engine=="asan":assert observed["sanitizer_stderr_bytes"]==0
                else:assert observed["closed"]==0
print(json.dumps({"revision":matrix["revision"],"corrected_revision":manifest.get("post_measurement_revision"),"matrix_measured":392,"matrix_warmups":28,"paired_measured":measured,"paired_warmups":warmups,"controls_measured":control_count,"controls_warmups":control_warmups,"raw_profiles":12,"portable_audit":"passed","compared_engines":summary},indent=2,sort_keys=True))
