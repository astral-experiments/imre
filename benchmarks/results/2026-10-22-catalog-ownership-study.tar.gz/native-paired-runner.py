from pathlib import Path
import argparse
from collections import Counter
import datetime
import hashlib
import json
import os
import runpy
import statistics
import subprocess

p = argparse.ArgumentParser()
p.add_argument("--after", type=Path, required=True)
p.add_argument("--after-thin", type=Path)
p.add_argument("--rust", type=Path)
p.add_argument("--rust-thin", type=Path)
p.add_argument("--output", type=Path, required=True)
p.add_argument("--cases", nargs="+", default=["10x-plain", "10x-gzip", "1x-plain", "1x-gzip"])
p.add_argument("--source", type=Path, default=Path("/home/dev-user/code/oss/imre-catalog-gap-corrected-20261022"))
args = p.parse_args()
if not __debug__:
    raise SystemExit("requires assertions")
frozen = Path("/home/dev-user/.cache/imre-catalog-gap-20261022/final-34abb56/measurements/results.json")
assert hashlib.sha256(frozen.read_bytes()).hexdigest() == "0f2cedec5550e3a16ffd42d7fd2e8fa8fb7533832feedb655a3e635a45067012"
baseline = json.loads(frozen.read_bytes())
files = baseline["inputs"]
assert set(args.cases) <= set(files["inputs"]) and len(set(args.cases)) == len(args.cases)
out = args.output.absolute()
out.mkdir()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def identify(path):
    with path.open("rb") as f:
        return {"path": str(path.resolve()), "sha256": hashlib.file_digest(f, "sha256").hexdigest(), "bytes": path.stat().st_size}
def orig(k):
    x = baseline["hashes"][k]
    assert x == identify(Path(x["path"]))
    return Path(x["path"])
engines = {"before": orig("imre"), "after": args.after.resolve(strict=True), "rust": args.rust.resolve(strict=True) if args.rust else orig("rust")}
if args.after_thin:
    engines.update(before_thin=orig("imre_thin"), after_thin=args.after_thin.resolve(strict=True), rust_thin=args.rust_thin.resolve(strict=True) if args.rust_thin else orig("rust_thin"))
monitor = orig("monitor")
labels = list(engines)
n = len(labels)
seq = [0,1,5,2,4,3] if n == 6 else [0,1,2]
orders = [[labels[(v+i) % n] for v in seq] for i in range(n)]
if n == 3:
    orders += [row[::-1] for row in orders]
assert all(len(set(row)) == n for row in orders)
neighbors=Counter((a,b) for row in orders for a,b in zip(row,row[1:]))
assert len(set(neighbors.values()))==1 and len(neighbors)==n*(n-1)
assert all(len(set(Counter(row[i] for row in orders).values()))==1 for i in range(n))
oracle = Path(files["expected"]["path"])
assert identify(oracle) == files["expected"]
expected = oracle.read_bytes()
inputs = {key: Path(files["inputs"][key]["path"]) for key in args.cases}
paths = {**engines, "monitor":monitor, "oracle":oracle, **inputs}
ids = {k: identify(v) for k,v in paths.items()}
assert all(ids[k] == files["inputs"][k] for k in inputs)
result={"kind":"catalog-ownership-matched-native","started":now(),"cpu":31,"baseline_sha256":hashlib.sha256(frozen.read_bytes()).hexdigest(),"paths":ids,"orders":orders,"cases":{}}
native = runpy.run_path(str(args.source / "benchmarks/stream_catalog_benchmark.py"))["native"]
env = native.environment(out)
os.sched_setaffinity(0, {31})
for label, source in inputs.items():
    work=out/label
    work.mkdir()
    output=work/"catalog.json"
    def observe(key):
        output.write_bytes(native.SENTINEL)
        command=[str(monitor),str(work/"usage"),str(engines[key]),str(source),str(output)]
        proc=subprocess.run(command,cwd=work,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=120)
        assert not proc.returncode and not proc.stderr and not proc.stdout, (key, proc.returncode,proc.stderr)
        raw=output.read_bytes()
        assert raw==expected,(label,key)
        elapsed,rss=map(int,(work/"usage").read_text().split())
        return {"engine":key,"elapsed_ns":elapsed,"peak_rss_kib":rss,"output_sha256":hashlib.sha256(raw).hexdigest()}
    warmup=[observe(engine) for engine in reversed(orders[0])]
    samples=[[observe(engine) for engine in order] for order in orders]
    med={key:{field:statistics.median(s[field] for row in samples for s in row if s["engine"]==key) for field in ("elapsed_ns","peak_rss_kib")} for key in engines}
    result["cases"][label]={"warmup":warmup,"samples":samples,"medians":med}
    print(label,{k:round(v["elapsed_ns"]/1e6,2) for k,v in med.items()},flush=True)
    (out/"results.json").write_text(json.dumps(result,indent=2)+"\n")
assert ids=={k:identify(v) for k,v in paths.items()}
result["completed"]=now()
(out/"results.json").write_text(json.dumps(result,indent=2)+"\n")
