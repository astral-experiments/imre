# Replay the catalog ownership study

Run these commands from the Imre checkout containing the published results. Python 3.14 uses only its standard library. The source snapshot authenticates the benchmark runners and reference program.

```sh
frozen_checkout=$(mktemp -d)
study_dir=$(mktemp -d)
git archive db44bcc2e9d0f3dca291ed141d7b742227ab44b4 | tar -x -C "$frozen_checkout"
tar -xzf benchmarks/results/2026-10-22-catalog-ownership-study.tar.gz -C "$study_dir"
python3.14 "$study_dir/verify-study.py" \
  benchmarks/results/2026-10-22-catalog-ownership-measurements.json.gz \
  benchmarks/results/2026-10-22-catalog-hot-paths-measurements.json.gz \
  --source-root "$frozen_checkout"
```

The verifier checks 392 measured matrix processes and 28 warmups, then recomputes the ordinary and ThinLTO comparisons from 144 paired measurements and 24 warmups. It also verifies every archived file, checks all 234 control observations, and recomputes the instruction and allocation totals from 12 raw Callgrind and DHAT traces. The ordinary-build 1× profiles came from the local host. The official 10× profiles came from the timing host.

The process validation summary preserves input, output, and error-category digests for the frozen ordinary, ThinLTO, and ASan builds. The ownership probe archive contains runnable sources, compressed oracle outputs and inputs, and raw retention observations.

The corrected compiler source is db2a6f876e94fa136450ad3efe56c110e376b17d. The timing matrix records db44bcc. The correction receipt binds six byte-identical canonical links, 24 complete-output comparisons and 764 additional validation executions. The independent replay checks the four-rate selectivity control, the all-kept crossover, and 72 bounded-retention runs.
