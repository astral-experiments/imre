"""Independently audit final Base45 timing, correctness, and provenance records.

Run with pinned CPython 3.14.5. This never builds or executes benchmark binaries.
Pass --check-retained to hash current tools/artifacts and inspect retained outputs.
"""

import argparse
import ast
import base64
import hashlib
import itertools
import json
import math
import random
import runpy
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

FROZEN_REVISION = "7c1e378625d6760b30e68025fe2299b29287cedc"
UPSTREAM_COMMIT = "5f49a519c3884a4fbc4c58c5c8f1fa25d7046020"
UPSTREAM_HASHES = {
    "base45/__init__.py": "a22381be6391bd5b3aa9296fc3a2ba44e31ca19368bedb86f48f4f3bf8b42b9f",
    "base45/py.typed": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "upstream/LICENSE": "0a6f4da891e538d63ce6852350d2317e9720fb6f18d37704f80c09db97d485b8",
    "upstream/test_base45.py": "994a7cd4277317f211dffab8eb9cf1a322d6a2e4f41f375fd226ee5ff25c20b3",
}
OPERATIONS = ["encode", "decode-bytes", "decode-text"]
SIZES = [64, 1024, 16384]
BOUNDARIES = {
    f"unicode-repr-boundary-{operation}-{index}": quoted
    for index, quoted in enumerate(["'\\u0301'", "'\\U000e0100'"])
    for operation in ["decode-bytes", "decode-text"]
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    raw = path.read_bytes()
    return json.loads(raw), digest(raw)


def close(actual, expected, label):
    require(
        type(actual) in (int, float)
        and math.isfinite(actual)
        and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12),
        f"{label}: recorded {actual!r}, recomputed {expected!r}",
    )


def percentile(values, fraction):
    position = (len(values) - 1) * fraction
    low, high = math.floor(position), math.ceil(position)
    return values[low] + (values[high] - values[low]) * (position - low)


def recompute(samples, engine):
    values = sorted(sample[engine]["elapsed_ns"] for sample in samples)
    return {
        "median_seconds": percentile(values, 0.5) / 1e9,
        "min_seconds": values[0] / 1e9,
        "max_seconds": values[-1] / 1e9,
        "p25_seconds": percentile(values, 0.25) / 1e9,
        "p75_seconds": percentile(values, 0.75) / 1e9,
    }


def effective_target(record):
    target = record["requested_target"]
    if target is None:
        target = next(
            line.removeprefix("Target: ").strip()
            for line in record["clang_version"].splitlines()
            if line.startswith("Target: ")
        )
    parts = target.split("-")
    require(len(parts) >= 4, "unrecognized target triple")
    # Native Clang reports the pc vendor; explicit Rust/LLVM triples use unknown.
    # Architecture, OS, and ABI must still match across the build families.
    return "-".join([parts[0], "<vendor>", *parts[2:]])


class Files:
    def __init__(self):
        self.checked = {}

    def verify(self, path, expected):
        path = path.resolve(strict=True)
        key = str(path)
        if key not in self.checked:
            before = path.stat()
            with path.open("rb") as stream:
                actual = hashlib.file_digest(stream, "sha256").hexdigest()
            after = path.stat()
            require(
                (before.st_size, before.st_mtime_ns)
                == (after.st_size, after.st_mtime_ns),
                f"file changed while hashing: {path}",
            )
            self.checked[key] = {
                "sha256": actual,
                "bytes": after.st_size,
                "mtime_ns": after.st_mtime_ns,
            }
        require(self.checked[key]["sha256"] == expected, f"hash mismatch: {path}")

    def unchanged(self):
        for path, metadata in self.checked.items():
            stat = Path(path).stat()
            require(
                (stat.st_size, stat.st_mtime_ns)
                == (metadata["bytes"], metadata["mtime_ns"]),
                f"file changed during audit: {path}",
            )


def oracle(codec, operation, payload, repetitions=1):
    try:
        if operation == "encode":
            result = codec["b45encode"](payload)
        elif operation == "decode-bytes":
            result = codec["b45decode"](payload)
        elif operation == "decode-text":
            result = codec["b45decode"](payload.decode())
        else:
            raise AssertionError(operation)
    except (ValueError, KeyError, TypeError, AttributeError) as error:
        cause = error.__cause__
        lines = [
            "ERROR",
            type(error).__name__,
            str(error),
            str(error.__suppress_context__),
            "None" if cause is None else type(cause).__name__,
            "" if cause is None else str(cause),
        ]
        return "\n".join(lines) + "\n", None
    checksum = len(result) + (result[0] + result[-1] if result else 0)
    return f"OK\n{checksum * repetitions}\n", result


def independent_corpus(codec, test_source):
    # Read only the pinned test vectors, without importing its test runner or the
    # benchmark validator. Corpus generation and all oracle checks live here.
    vectors = {}
    for statement in ast.parse(test_source).body:
        if (
            isinstance(statement, ast.Assign)
            and len(statement.targets) == 1
            and isinstance(statement.targets[0], ast.Name)
            and statement.targets[0].id in {"GOOD_DATA", "BAD_BASE45_STRINGS"}
        ):
            expression = ast.Expression(statement.value)
            vectors[statement.targets[0].id] = eval(
                compile(expression, "<pinned upstream vectors>", "eval"),
                {"__builtins__": {"bytes": bytes}},
            )
    require(set(vectors) == {"GOOD_DATA", "BAD_BASE45_STRINGS"}, "missing vectors")
    cases = []

    def triple(prefix, index, raw, encoded):
        cases.extend(
            [
                (f"{prefix}-encode-{index}", "encode", raw, 1),
                (f"{prefix}-bytes-{index}", "decode-bytes", encoded, 1),
                (f"{prefix}-text-{index}", "decode-text", encoded, 1),
            ]
        )

    for index, (raw, encoded) in enumerate(vectors["GOOD_DATA"]):
        require(codec["b45encode"](raw) == encoded, "pinned upstream vector mismatch")
        triple("upstream", index, raw, encoded)
    malformed = [
        *vectors["BAD_BASE45_STRINGS"],
        b"\xff",
        b"\xc2",
        b"\xe0\x80\x80",
        b"\xf0\x90",
        b"BB8\n",
        b"BB8\n\n",
        b"BB8\r\n",
        b"bb8",
        b"\x00",
        "é".encode(),
        "🦀".encode(),
        b"   ",
        b"  ",
        b"GGWa",
        b"0000a",
        b"a\xff",
        b"BB8\xed\xa0\x80",
        b"BB8\xf4\x90\x80\x80",
        b"'",
        b'"',
        b"\\",
    ]
    for index, payload in enumerate(malformed):
        for operation in OPERATIONS[1:]:
            cases.append((f"malformed-{operation}-{index}", operation, payload, 1))
    for index, character in enumerate(["\u0301", "\U000e0100"]):
        for operation in OPERATIONS[1:]:
            cases.append(
                (
                    f"unicode-repr-boundary-{operation}-{index}",
                    operation,
                    character.encode(),
                    1,
                )
            )
    generator = random.Random(9285)
    sizes = [0, 1, 2, 3, 22, 23, 24, 25, 255, 256, 257, 4096]
    sizes.extend(generator.randrange(512) for _ in range(48))
    for index, size in enumerate(sizes):
        raw = generator.randbytes(size)
        triple("random", index, raw, codec["b45encode"](raw))
    cases.append(("all-byte-values", "encode", bytes(range(256)), 1))
    require(len(cases) == 289, "independent corpus count")
    return cases


def check_cases(recorded, expected, codec, rust=False):
    require(len(recorded) == len(expected), "differential case count")
    boundaries = []
    for case, (label, operation, payload, repetitions) in zip(
        recorded, expected, strict=True
    ):
        require(
            case["label"] == label and case["operation"] == operation,
            f"case order: {label}",
        )
        require(
            base64.b64decode(case["input_base64"], validate=True) == payload,
            f"payload: {label}",
        )
        require(case.get("repetitions", 1) == repetitions, f"repetitions: {label}")
        stdout, result = oracle(codec, operation, payload, repetitions)
        require(
            case["output_sha256"] == (None if result is None else digest(result)),
            f"output hash: {label}",
        )
        if rust and label in BOUNDARIES:
            require(result is None, f"expected error: {label}")
            expected_rust = (
                "\n".join([*stdout.splitlines()[:5], BOUNDARIES[label]]) + "\n"
            )
            require(
                case["stdout"] == expected_rust, f"unexpected Rust boundary: {label}"
            )
            boundaries.append(
                {"label": label, "cpython": stdout, "rust": expected_rust}
            )
        else:
            require(case["stdout"] == stdout, f"exact stdout/error mismatch: {label}")
    return boundaries


def check_validation(record, manifest, corpus, codec):
    validation = record["validation"]
    hashes = record["source_and_tool_sha256"]
    require(validation["upstream"] == manifest, "validation upstream")
    require(
        validation["binary_sha256"] == record["binary_sha256"], "validated Imre binary"
    )
    require(validation["compiler_sha256"] == hashes["compiler"], "validated compiler")
    require(validation["implementation"] == "CPython", "validation implementation")
    require(
        validation["python"] == record["python"]["version"] == sys.version,
        "oracle Python version",
    )
    for name in ["upstream_cpython", "upstream_native_adapter"]:
        suite = validation[name]
        require(
            suite["methods"] == 5 and suite["log"].endswith("\nOK\n"),
            f"upstream suite: {name}",
        )
        require(
            suite["log"].count(" ... ok\n") == 5,
            f"upstream suite method results: {name}",
        )
    require(validation["native_adapter_calls"] == 323, "native upstream call count")
    rejected = validation["wrong_typed_compile_rejections"]
    require(
        len(rejected) == 2
        and {case["operation"] for case in rejected} == {"encode", "decode"},
        "wrong-typed rejection count",
    )
    for case in rejected:
        wanted = "bytes" if case["operation"] == "encode" else "str | bytes"
        suffix = f":2:11: Imre: expected {wanted}, got int; annotations are enforced contracts\n"
        require(case["diagnostic"].endswith(suffix), "wrong-typed rejection diagnostic")
    check_cases(validation["differential_cases"], corpus, codec)
    rust_cases = list(corpus)
    for operation, payload in [
        ("encode", b""),
        ("encode", bytes(range(256))),
        ("decode-bytes", b"BB8"),
        ("decode-text", b"BB8\n\n"),
        ("decode-bytes", b"GGWa"),
        ("decode-text", b"\xff"),
    ]:
        rust_cases.append(
            (f"repeated-{operation}-{len(rust_cases)}", operation, payload, 7)
        )
    rust = validation["rust"]
    require(rust["binary_sha256"] == hashes["rust"], "validated Rust binary")
    boundaries = check_cases(rust["differential_cases"], rust_cases, codec, rust=True)
    require(
        len(rust_cases) == 295 and rust["exact_message_cases"] == 291,
        "Rust correctness counts",
    )
    require(
        rust["diagnostic_boundaries"] == boundaries and len(boundaries) == 4,
        "Rust boundary record",
    )
    return boundaries


def check_rust(record, family, args, files):
    build = record["rust_build_record"]
    hashes = record["source_and_tool_sha256"]
    require(
        digest((json.dumps(build, indent=2) + "\n").encode())
        == hashes["rust_build_record"],
        "embedded Rust build-record hash",
    )
    require(build["entrypoint"] == "base45", "Rust entrypoint")
    require(
        set(build["sources"]) == set(build["source_contents"]), "Rust source inventory"
    )
    require(
        {"Cargo.toml", "Cargo.lock", "src/main.rs"} <= set(build["sources"]),
        "Rust required source files",
    )
    for name, expected in build["sources"].items():
        require(
            digest(build["source_contents"][name].encode()) == expected,
            f"embedded Rust source: {name}",
        )
        require(
            hashes[f"rust_source_{name}"]
            == hashes[f"tracked_rust_source_{name}"]
            == expected,
            f"Rust source provenance: {name}",
        )
    script_hash = digest(build["build_script"].encode())
    require(
        script_hash
        == build["build_script_sha256"]
        == hashes["rust_build_script"]
        == hashes["tracked_rust_build_script"],
        "Rust build script provenance",
    )
    binary = build["binaries"]["reference"]
    require(
        binary["sha256"] == hashes["rust"]
        and binary["bytes"] > 0
        and binary["build_seconds"] > 0,
        "Rust build artifact",
    )
    command = binary["command"]
    require(
        all(
            flag in command
            for flag in ["build", "--release", "--locked", "--target-dir"]
        ),
        "Rust build command",
    )
    require(
        build["rustc_verbose"]
        and build["cargo_version"]
        and set(build["tool_sha256"]) == {"cargo", "rustc"},
        "Rust tool provenance",
    )
    for value in build["tool_sha256"].values():
        require(
            len(value) == 64 and all(c in "0123456789abcdef" for c in value),
            "Rust tool hash",
        )
    wrapper = build["cargo_wrapper"]
    if wrapper:
        require(
            digest(wrapper["source"].encode()) == wrapper["sha256"],
            "Rust Cargo wrapper source",
        )
    environment = build["environment"]
    require(
        environment["CARGO_TARGET_DIR"].startswith("<target-dir"),
        "Rust explicit build directory",
    )
    if family == "normal":
        require(build["llvm_budget"] is None, "normal Rust LLVM budget")
        require(
            environment.get("CARGO_PROFILE_RELEASE_LTO") in (None, "false", "off"),
            "normal Rust LTO mode",
        )
        require(
            environment["RUSTFLAGS"] == environment["CARGO_ENCODED_RUSTFLAGS"] == "",
            "normal Rust flags",
        )
    else:
        require(
            build["llvm_budget"] == 1000
            and environment.get("CARGO_PROFILE_RELEASE_LTO") == "thin",
            "ThinLTO Rust matching policy",
        )
        require(
            environment["RUSTFLAGS"]
            == "-Cllvm-args=-import-instr-limit=1000 -Cllvm-args=-inline-threshold=1000",
            "ThinLTO Rust LLVM flags",
        )
        require(
            environment["CARGO_ENCODED_RUSTFLAGS"] is None, "ThinLTO Rust encoded flags"
        )
    if args.check_retained:
        reference = args.root / "benchmarks/reference/base45_codec"
        source_root = args.rust_source_root or reference
        source_names = {"Cargo.toml", "Cargo.lock"} | {
            str(path.relative_to(source_root))
            for path in (source_root / "src").rglob("*.rs")
        }
        require(source_names == set(build["sources"]), "retained Rust source inventory")
        for name, expected in build["sources"].items():
            files.verify(source_root / name, expected)
            files.verify(reference / name, expected)
        files.verify(source_root / "build.py", script_hash)
        files.verify(reference / "build.py", script_hash)
        rust = args.rust_normal if family == "normal" else args.rust_thinlto
        if family == "sustained" and args.rust_sustained:
            rust = args.rust_sustained
        require(rust is not None, f"provide retained Rust binary for {family}")
        files.verify(rust, hashes["rust"])
        require(rust.stat().st_size == binary["bytes"], "retained Rust binary size")
        override = getattr(args, f"rust_build_record_{family}")
        record_path = override or rust.parent / "build-record.json"
        files.verify(record_path, hashes["rust_build_record"])
        actual, _ = read_json(record_path)
        require(
            actual == build, "embedded Rust build record differs from retained record"
        )
        if wrapper and command[:1] == ["sh"]:
            files.verify(Path(command[1]), wrapper["sha256"])
        for tool, expected in build["tool_sha256"].items():
            selected = subprocess.check_output(
                ["rustup", "which", tool, "--toolchain", args.rust_toolchain],
                text=True,
            ).strip()
            files.verify(Path(selected), expected)
    return {
        "binary_sha256": binary["sha256"],
        "source_files": len(build["sources"]),
        "rustc": build["rustc_verbose"].splitlines()[0],
        "lto": environment.get("CARGO_PROFILE_RELEASE_LTO"),
        "llvm_budget": build["llvm_budget"],
    }


def check_record(record, family, args, manifest, corpus, codec, files, build):
    native = family == "sustained"
    engines = ["imre", "rust"] if native else ["imre", "cpython", "rust"]
    samples, warmups = (20, 2) if native else (24, 6)
    batch_bytes = (64 if native else 2) * 1024 * 1024
    operations = OPERATIONS
    require(
        record["schema"] == 2 and record.get("input_guards_passed") is True,
        f"{family}: incomplete record",
    )
    require(record["dirty"] is False, f"{family}: dirty benchmark")
    require(record["revision"] == FROZEN_REVISION, f"{family}: measured revision")
    require(
        record["samples"] == samples and record["warmups"] == warmups,
        f"{family}: phase counts",
    )
    require(
        record["batch_bytes"] == batch_bytes and record["operations"] == operations,
        f"{family}: workload policy",
    )
    require(record["thinlto"] == (family != "normal"), f"{family}: linking mode")
    require(record["measured_engines"] == engines, f"{family}: engine inventory")
    orders = list(itertools.permutations(engines))
    require(
        record["engine_orders"] == [list(order) for order in orders],
        f"{family}: permutation inventory",
    )
    require(record["upstream"] == manifest, f"{family}: upstream identity")
    require(record["cpu"]["affinity"] == [0], f"{family}: CPU pinning")
    python = record["python"]
    require(
        python["implementation"] == "cpython" and python["version_number"] == "3.14.5",
        "baseline Python",
    )
    require(
        python["jit_enabled"] is False and python["debug_build"] is False,
        "baseline Python mode",
    )
    require(
        python["pgo"]["configure_enable_optimizations"] is True
        and python["lto"]["configure_option"] == "--with-lto",
        "baseline Python PGO/LTO",
    )
    boundaries = check_validation(record, manifest, corpus, codec)
    rust = check_rust(record, family, args, files)
    command = record["compile_command"]
    flag = lambda name: command[command.index(name) + 1]
    package = args.root / "examples/base45_codec"
    require(command[1:3] == ["build", str(package / "driver.py")], "Imre compile entry")
    require(
        flag("--module-root") == str(package) and flag("--opt-level") == "3",
        "Imre compile policy",
    )
    require(
        (flag("--target") if "--target" in command else None)
        == record["requested_target"],
        "Imre target",
    )
    require(("--lto-linker" in command) == record["thinlto"], "Imre LTO flag")
    require(
        type(record["build_ns"]) is int and record["build_ns"] > 0, "Imre build timing"
    )
    binary, llvm = Path(flag("-o")), Path(flag("--emit-llvm"))
    hashes = record["source_and_tool_sha256"]
    inputs = {
        "compiler": Path(command[0]),
        "runtime": Path(flag("--runtime")),
        "python": Path(sys.executable),
        "clang": Path(flag("--clang")),
        "codec": package / "base45/__init__.py",
        "driver": package / "driver.py",
        "harness": args.root / "benchmarks/base45_benchmark.py",
        "validator": args.root / "benchmarks/base45_validate.py",
        "shared_harness": args.root / "benchmarks/benchmark.py",
        "upstream_manifest": package / "UPSTREAM.json",
    }
    inputs.update(
        {
            f"upstream_{index}": package / name
            for index, name in enumerate(manifest["files"])
        }
    )
    if record["thinlto"]:
        inputs["lto_linker"] = Path(flag("--lto-linker"))
    rust_hashes = {
        "rust",
        "rust_build_record",
        "rust_build_script",
        "tracked_rust_build_script",
    }
    for name in record["rust_build_record"]["sources"]:
        rust_hashes.update([f"rust_source_{name}", f"tracked_rust_source_{name}"])
    require(set(hashes) == set(inputs) | rust_hashes, "source/tool hash inventory")
    require(
        hashes["compiler"] == build["artifacts"]["compiler"]["sha256"],
        "frozen compiler identity",
    )
    runtime_name = "normal_runtime" if family == "normal" else "thinlto_runtime"
    require(
        hashes["runtime"] == build["artifacts"][runtime_name]["sha256"],
        "frozen runtime identity",
    )
    if args.check_retained:
        for name, path in inputs.items():
            files.verify(path, hashes[name])
        files.verify(binary, record["binary_sha256"])
        files.verify(llvm, record["llvm_sha256"])
        require(
            next(
                (
                    line
                    for line in llvm.read_text().splitlines()
                    if line.startswith("target triple")
                ),
                None,
            )
            == record["llvm_target"],
            "retained LLVM target",
        )
        actual_validation, _ = read_json(binary.parent / "validation.json")
        require(
            actual_validation == record["validation"], "retained validation differs"
        )
    generator = random.Random(9285)
    expected_workloads = []
    for size in SIZES:
        raw = generator.randbytes(size)
        for operation in operations:
            payload = raw if operation == "encode" else codec["b45encode"](raw)
            expected_workloads.append((f"{operation}-{size}", operation, size, payload))
    require(
        len(record["workloads"]) == len(expected_workloads), f"{family}: workload count"
    )
    rows, checked_runs = [], 0
    for workload, (label, operation, size, payload) in zip(
        record["workloads"], expected_workloads, strict=True
    ):
        require(
            (workload["label"], workload["operation"], workload["raw_bytes"])
            == (label, operation, size),
            f"workload identity: {label}",
        )
        require(
            base64.b64decode(workload["input_base64"], validate=True) == payload,
            f"workload input: {label}",
        )
        require(
            workload["repetitions"] == batch_bytes // size,
            f"workload repetitions: {label}",
        )
        stdout, result = oracle(codec, operation, payload, workload["repetitions"])
        expected_hash = digest(result)
        require(
            workload["expected_stdout"] == stdout
            and workload["expected_output_sha256"] == expected_hash
            and workload["expected_output_bytes"] == len(result),
            f"workload oracle: {label}",
        )
        require(set(workload["gates"]) == set(engines), "gate inventory")
        phase_orders = {}
        for phase, count in [("warmups", warmups), ("samples", samples)]:
            phase_rows = workload[phase]
            require(len(phase_rows) == count, f"phase count: {label}/{phase}")
            counts = Counter()
            for index, row in enumerate(phase_rows):
                require(
                    row["index"] == index
                    and row["order"] == list(orders[index % len(orders)]),
                    f"order sequence: {label}/{phase}/{index}",
                )
                require(
                    set(row) == {"index", "order", *engines}, "sample engine inventory"
                )
                counts[tuple(row["order"])] += 1
            require(
                counts == Counter({order: count // len(orders) for order in orders}),
                f"unbalanced permutations: {label}/{phase}",
            )
            phase_orders[phase] = {
                "/".join(order): count for order, count in counts.items()
            }
        summaries = {}
        require(set(workload["summary"]) == set(engines), "summary inventory")
        for engine in engines:
            runs = [
                workload["gates"][engine],
                *(row[engine] for row in workload["warmups"]),
                *(row[engine] for row in workload["samples"]),
            ]
            for run in runs:
                require(
                    type(run["elapsed_ns"]) is int and run["elapsed_ns"] > 0,
                    f"positive timing: {label}/{engine}",
                )
                require(
                    run["returncode"] == 0
                    and run["stderr"] == ""
                    and run["stdout"] == stdout
                    and run["output_sha256"] == expected_hash,
                    f"run validation: {label}/{engine}",
                )
                checked_runs += 1
            summary = recompute(workload["samples"], engine)
            require(
                set(workload["summary"][engine]) == set(summary),
                "summary field inventory",
            )
            for key, value in summary.items():
                close(
                    workload["summary"][engine][key], value, f"{label}/{engine}/{key}"
                )
            summaries[engine] = summary
            if args.check_retained:
                directory = binary.parent / label / engine
                require(
                    (directory / "input.bin").read_bytes() == payload,
                    f"retained input: {label}/{engine}",
                )
                require(
                    (directory / "output.bin").read_bytes() == result,
                    f"retained output: {label}/{engine}",
                )
        ratios = {}
        for left, right in [("cpython", "imre"), ("imre", "rust"), ("cpython", "rust")]:
            if left in summaries and right in summaries:
                key = f"{left}_over_{right}"
                ratios[key] = (
                    summaries[left]["median_seconds"]
                    / summaries[right]["median_seconds"]
                )
                close(workload[key], ratios[key], f"{label}/{key}")
        require(
            {key for key in workload if "_over_" in key} == set(ratios),
            "ratio inventory",
        )
        rows.append(
            {
                "label": label,
                "repetitions": workload["repetitions"],
                "summary_seconds": summaries,
                **ratios,
            }
        )
    require(
        checked_runs
        == len(expected_workloads) * len(engines) * (1 + warmups + samples),
        "checked run count",
    )
    return {
        "passed": True,
        "revision": record["revision"],
        "binary_sha256": record["binary_sha256"],
        "llvm_sha256": record["llvm_sha256"],
        "requested_target": record["requested_target"],
        "effective_target": effective_target(record),
        "engines": engines,
        "samples": samples,
        "warmups": warmups,
        "batch_bytes": batch_bytes,
        "process_results_checked": checked_runs,
        "balanced_orders_per_workload": phase_orders,
        "correctness": {
            "imre_upstream_calls": 323,
            "imre_exact_cases": 289,
            "compile_rejections": 2,
            "rust_cases": 295,
            "rust_exact_cases": 291,
            "rust_unicode_repr_boundaries": 4,
        },
        "rust_build": rust,
        "table": rows,
    }, boundaries


def check_before_after(path, current, args, codec, files):
    control, control_hash = read_json(path)
    require(
        control["schema"] == 1
        and control["input_guards_passed"] is True
        and control["dirty"] is False,
        "before/after incomplete or dirty",
    )
    require(control["revision"] == current["revision"], "before/after revision")
    require(
        control["cpu"]["affinity"] == current["cpu"]["affinity"] == [0]
        and control["cpu"]["model"] == current["cpu"]["model"]
        and 0 in control["cpu"]["allowed_cpus_before_pinning"],
        "before/after CPU metadata",
    )
    require(
        (control["samples"], control["warmups"], control["batch_bytes"])
        == (20, 2, 2 * 1024 * 1024),
        "before/after measurement policy",
    )
    engines = ["previous", "imre"]
    orders = list(itertools.permutations(engines))
    require(control["measured_engines"] == engines, "before/after engines")
    require(
        control["engine_orders"] == [list(order) for order in orders],
        "before/after permutations",
    )
    require(
        set(control["benchmark_records"]) == set(engines),
        "before/after record inventory",
    )
    sources = {}
    protected = {}
    for engine, metadata in control["benchmark_records"].items():
        source_path = Path(metadata["path"])
        source, source_hash = read_json(source_path)
        require(
            source_hash == metadata["sha256"], f"before/after source record: {engine}"
        )
        require(
            source["input_guards_passed"] is True
            and source["thinlto"] is True
            and source["dirty"] is False,
            f"before/after source guards: {engine}",
        )
        require(
            metadata["revision"] == source["revision"]
            and metadata["binary_sha256"] == source["binary_sha256"],
            f"before/after source metadata: {engine}",
        )
        command = source["compile_command"]
        binary = command[command.index("-o") + 1]
        require(metadata["binary"] == binary, f"before/after binary path: {engine}")
        protected[str(source_path)] = source_hash
        protected[binary] = source["binary_sha256"]
        sources[engine] = source
    require(
        sources["imre"] == current,
        "before/after current record differs from audited ThinLTO",
    )
    previous = sources["previous"]
    require(
        previous["upstream"] == current["upstream"], "before/after upstream identity"
    )
    require(
        previous["python"] == current["python"], "before/after CPython build identity"
    )
    for name in ["codec", "driver", "python"]:
        require(
            previous["source_and_tool_sha256"][name]
            == current["source_and_tool_sha256"][name],
            f"before/after {name} identity",
        )
    for filename, key in [
        ("base45_benchmark.py", "harness"),
        ("base45_validate.py", "validator"),
        ("benchmark.py", "shared_harness"),
    ]:
        protected[str(args.root / "benchmarks" / filename)] = current[
            "source_and_tool_sha256"
        ][key]
    protected[str(path.with_suffix(".py"))] = hashlib.sha256(
        path.with_suffix(".py").read_bytes()
    ).hexdigest()
    protected[str(Path(sys.executable).resolve())] = current["source_and_tool_sha256"][
        "python"
    ]
    require(
        control["protected_sha256"] == protected,
        "before/after protected hash inventory",
    )
    if args.check_retained:
        files.verify(path, control_hash)
        for filename, expected in protected.items():
            files.verify(Path(filename), expected)
    workloads = current["workloads"]
    require(
        len(control["workloads"]) == len(workloads) == len(OPERATIONS) * len(SIZES),
        "before/after workload count",
    )
    metadata_keys = [
        "label",
        "operation",
        "raw_bytes",
        "repetitions",
        "input_base64",
        "expected_stdout",
        "expected_output_sha256",
        "expected_output_bytes",
    ]
    rows = []
    checked = 0
    for workload, current_workload in zip(control["workloads"], workloads, strict=True):
        label = workload["label"]
        previous_workload = next(
            item for item in previous["workloads"] if item["label"] == label
        )
        for key in metadata_keys:
            require(
                workload[key] == current_workload[key] == previous_workload[key],
                f"before/after workload identity: {label}/{key}",
            )
        payload = base64.b64decode(workload["input_base64"], validate=True)
        stdout, result = oracle(
            codec, workload["operation"], payload, workload["repetitions"]
        )
        expected_hash = digest(result)
        require(
            workload["expected_stdout"] == stdout
            and workload["expected_output_sha256"] == expected_hash
            and workload["expected_output_bytes"] == len(result),
            f"before/after oracle: {label}",
        )
        require(
            set(workload["gates"]) == set(workload["summary"]) == set(engines),
            "before/after engine result inventory",
        )
        for phase, count in [("warmups", 2), ("samples", 20)]:
            require(
                len(workload[phase]) == count,
                f"before/after phase count: {label}/{phase}",
            )
            actual_orders = Counter()
            for index, sample in enumerate(workload[phase]):
                require(
                    sample["index"] == index
                    and sample["order"] == list(orders[index % 2]),
                    f"before/after order: {label}/{phase}/{index}",
                )
                require(
                    set(sample) == {"index", "order", *engines},
                    "before/after sample engine inventory",
                )
                actual_orders[tuple(sample["order"])] += 1
            require(
                actual_orders == Counter({order: count // 2 for order in orders}),
                "before/after balanced order",
            )
        summaries = {}
        for engine in engines:
            runs = [
                workload["gates"][engine],
                *(sample[engine] for sample in workload["warmups"]),
                *(sample[engine] for sample in workload["samples"]),
            ]
            for run in runs:
                require(
                    type(run["elapsed_ns"]) is int and run["elapsed_ns"] > 0,
                    "before/after positive timing",
                )
                require(
                    run["returncode"] == 0
                    and run["stderr"] == ""
                    and run["stdout"] == stdout
                    and run["output_sha256"] == expected_hash,
                    f"before/after run guards: {label}/{engine}",
                )
                checked += 1
            summary = recompute(workload["samples"], engine)
            require(
                set(workload["summary"][engine]) == set(summary),
                "before/after summary inventory",
            )
            for key, value in summary.items():
                close(
                    workload["summary"][engine][key],
                    value,
                    f"before/after {label}/{engine}/{key}",
                )
            summaries[engine] = summary
            if args.check_retained:
                directory = path.with_suffix("") / label / engine
                require(
                    (directory / "input.bin").read_bytes() == payload,
                    f"before/after retained input: {label}/{engine}",
                )
                require(
                    (directory / "output.bin").read_bytes() == result,
                    f"before/after retained output: {label}/{engine}",
                )
        ratio = (
            summaries["previous"]["median_seconds"]
            / summaries["imre"]["median_seconds"]
        )
        require(
            {key for key in workload if "_over_" in key} == {"previous_over_imre"},
            "before/after ratio inventory",
        )
        close(workload["previous_over_imre"], ratio, f"before/after {label}/ratio")
        rows.append(
            {
                "label": label,
                "input_sha256": digest(payload),
                "summary_seconds": summaries,
                "previous_over_imre": ratio,
            }
        )
    require(
        checked == len(OPERATIONS) * len(SIZES) * len(engines) * (1 + 2 + 20),
        "before/after process-result count",
    )
    return {
        "passed": True,
        "path": str(path.resolve()),
        "sha256": control_hash,
        "process_results_checked": checked,
        "samples": 20,
        "warmups": 2,
        "batch_bytes": 2 * 1024 * 1024,
        "previous_revision": previous["revision"],
        "current_revision": current["revision"],
        "old_new_codec_driver_python_identical": True,
        "binary_provenance": control["benchmark_records"],
        "table": rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path("/home/dev-user/code/oss/imre")
    )
    for family in ["normal", "thinlto", "sustained"]:
        parser.add_argument(
            f"--{family}", type=Path, default=Path(f"/tmp/imre-decoder-{family}.json")
        )
        parser.add_argument(f"--rust-{family}", type=Path)
        parser.add_argument(f"--rust-build-record-{family}", type=Path)
    parser.add_argument("--rust-source-root", type=Path)
    parser.add_argument("--rust-toolchain", default="ohm")
    parser.add_argument("--before-after", type=Path)
    parser.add_argument(
        "--build", type=Path, default=Path("/tmp/imre-decoder-frozen/build.json")
    )
    parser.add_argument("--check-retained", action="store_true")
    parser.add_argument(
        "--output", type=Path, default=Path("/tmp/imre-decoder-audit.json")
    )
    args = parser.parse_args()
    protected = [args.normal, args.thinlto, args.sustained, args.build, Path(__file__)]
    if args.before_after:
        protected.append(args.before_after)
    require(
        args.output.resolve() not in {path.resolve() for path in protected},
        "audit output would overwrite an input",
    )
    require(
        sys.version_info[:3] == (3, 14, 5), "run this audit with pinned CPython 3.14.5"
    )
    args.root = args.root.resolve()
    files = Files()
    records = {}
    for family in ["normal", "thinlto", "sustained"]:
        record, sha256 = read_json(getattr(args, family))
        require(record.get("input_guards_passed") is True, f"{family} is not complete")
        if args.check_retained:
            files.verify(getattr(args, family), sha256)
        records[family] = (record, sha256)
    build, build_hash = read_json(args.build)
    require(
        build["revision"] == FROZEN_REVISION
        and build["source_matches_revision"] is True
        and build["input_guards_passed"] is True
        and build["input_sha256_before"] == build["input_sha256_after"]
        and build["worktree_status_at_capture"] == "",
        "frozen source/revision/input guards",
    )
    build_log = build["build_logs"]["index.json"]
    history, history_hash = read_json(Path(build_log["path"]))
    require(history_hash == build_log["sha256"], "retained build-history hash")
    require(
        history["revision"] == FROZEN_REVISION
        and history["dirty"] is False
        and history["input_guards_passed"] is True
        and history["source_sha256"] == build["source_sha256"]
        and history["wrapper_sha256"] == build["cargo_wrapper"]["sha256"],
        "build history matches the frozen source and wrapper",
    )
    require(
        {command["label"] for command in history["commands"]}
        == {"format", "clippy", "unit", "integrated", "thinlto", "asan"}
        and all(command["returncode"] == 0 for command in history["commands"]),
        "build and required check results",
    )
    require(
        set(history["artifacts"]) == set(build["artifacts"])
        and all(
            artifact["sha256"] == build["artifacts"][name]["sha256"]
            for name, artifact in history["artifacts"].items()
        ),
        "build-history and frozen artifact identity",
    )
    if args.check_retained:
        files.verify(args.build, build_hash)
        for log in build["build_logs"].values():
            files.verify(Path(log["path"]), log["sha256"])
    require(
        digest(build["cargo_wrapper"]["contents"].encode())
        == build["cargo_wrapper"]["sha256"],
        "frozen Cargo wrapper provenance",
    )
    package = args.root / "examples/base45_codec"
    manifest, _ = read_json(package / "UPSTREAM.json")
    require(
        manifest["repository"] == "https://github.com/kirei/python-base45"
        and manifest["commit"] == UPSTREAM_COMMIT
        and manifest["license"] == "BSD-2-Clause",
        "pinned upstream identity",
    )
    require(
        {name: value["sha256"] for name, value in manifest["files"].items()}
        == UPSTREAM_HASHES,
        "pinned upstream file inventory",
    )
    for name, sha256 in UPSTREAM_HASHES.items():
        files.verify(package / name, sha256)
    codec = runpy.run_path(str(package / "base45/__init__.py"))
    corpus = independent_corpus(
        codec, (package / "upstream/test_base45.py").read_text()
    )
    if args.check_retained:
        source_names = {
            str(path.relative_to(args.root))
            for path in (args.root / "crates").rglob("*.rs")
        }
        source_names.update(
            str(path.relative_to(args.root))
            for path in (args.root / "crates").rglob("Cargo.toml")
        )
        source_names.update(["Cargo.toml", "Cargo.lock", "rust-toolchain.toml"])
        require(
            source_names == set(build["source_sha256"]),
            "frozen compiler source inventory",
        )
        for name, sha256 in build["source_sha256"].items():
            files.verify(args.root / name, sha256)
        for artifact in build["artifacts"].values():
            files.verify(Path(artifact["path"]), artifact["sha256"])
            require(
                Path(artifact["path"]).stat().st_size == artifact["bytes"],
                "frozen artifact size",
            )
        for tool in build["tools"].values():
            files.verify(Path(tool["path"]), tool["sha256"])
        files.verify(
            Path(build["cargo_wrapper"]["path"]), build["cargo_wrapper"]["sha256"]
        )
    output = {
        "schema": 1,
        "audited_at": datetime.now(timezone.utc).isoformat(),
        "script_sha256": digest(Path(__file__).read_bytes()),
        "audit_python": sys.version,
        "build_manifest": {
            "path": str(args.build.resolve()),
            "sha256": build_hash,
            "revision": build["revision"],
        },
        "upstream_commit": UPSTREAM_COMMIT,
        "records": {},
    }
    for family, (record, sha256) in records.items():
        audited, boundaries = check_record(
            record, family, args, manifest, corpus, codec, files, build
        )
        audited.update({"path": str(getattr(args, family).resolve()), "sha256": sha256})
        output["records"][family] = audited
        output["rust_unicode_repr_boundaries"] = boundaries
        if args.check_retained:
            subprocess.run(
                [
                    "git",
                    "-C",
                    str(args.root),
                    "merge-base",
                    "--is-ancestor",
                    build["revision"],
                    record["revision"],
                ],
                check=True,
                capture_output=True,
            )
            changed = subprocess.check_output(
                [
                    "git",
                    "-C",
                    str(args.root),
                    "diff",
                    "--name-only",
                    build["revision"],
                    record["revision"],
                    "--",
                    *build["source_sha256"],
                ],
                text=True,
            )
            require(not changed, f"compiler sources changed after freeze: {changed}")
    normal, thinlto, sustained = [
        records[name][0] for name in ["normal", "thinlto", "sustained"]
    ]
    for record in [thinlto, sustained]:
        for key in [
            "revision",
            "python",
            "cpu",
            "compiler_version",
            "clang_version",
            "llvm_sha256",
            "llvm_target",
            "upstream",
        ]:
            require(record[key] == normal[key], f"cross-record mismatch: {key}")
        require(
            effective_target(record) == effective_target(normal),
            "cross-record architecture/OS/ABI target mismatch",
        )
        for key, value in normal["source_and_tool_sha256"].items():
            if key not in {"runtime", "rust", "rust_build_record", "lto_linker"}:
                require(
                    record["source_and_tool_sha256"][key] == value,
                    f"cross-record source/tool mismatch: {key}",
                )
    require(
        thinlto["source_and_tool_sha256"] == sustained["source_and_tool_sha256"],
        "sustained and ThinLTO input provenance",
    )
    if args.before_after:
        output["before_after"] = check_before_after(
            args.before_after, thinlto, args, codec, files
        )
    files.unchanged()
    output["checks"] = {
        "raw_statistics_and_ratios": True,
        "balanced_orders_and_counts": True,
        "positive_timings_and_all_run_guards": True,
        "exact_upstream_files": True,
        "imre_exact_errors_all_289_cases": True,
        "rust_291_exact_and_4_explicit_repr_boundaries": True,
        "rust_build_source_binary_provenance": True,
        "frozen_build_history_and_input_guards": True,
        "cross_record_consistency": True,
        "current_retained_files_verified": args.check_retained,
        "before_after_control_verified": bool(args.before_after),
    }
    output["verified_file_count"] = len(files.checked)
    output["caveats"] = [
        "Ratios compare medians of fresh-process wall time, including startup and one input/output file operation; they are not isolated codec-call timings.",
        "Normal and ThinLTO each use balanced three-engine 2 MiB raw-data batches; sustained uses balanced two-engine 64 MiB raw-data batches. All families cover encode, decode-bytes, and decode-text at all three sizes.",
        "Record validation and retained hashes are audited; binaries are not rebuilt or rerun by this script.",
        "Two wrong-typed upstream calls are compile-time rejections, not runtime TypeError equivalence.",
        "Rust deliberately differs at four explicit Unicode repr boundaries; all Imre errors and all other Rust cases are exact.",
        "File hashes cover recorded artifacts and tools, not every transitive system library.",
    ]
    output["passed"] = True
    require(
        str(args.output.resolve()) not in files.checked,
        "audit output would overwrite a verified file",
    )
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(
        json.dumps(
            {
                "passed": True,
                "audit": str(args.output),
                "records": 3 + bool(args.before_after),
                "process_results_checked": sum(
                    record["process_results_checked"]
                    for record in output["records"].values()
                )
                + (
                    output["before_after"]["process_results_checked"]
                    if args.before_after
                    else 0
                ),
                "verified_files": len(files.checked),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
