"""Independently audit and compare final/baseline decoder profiles, without target execution."""

import argparse
import ast
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from collections import Counter
from pathlib import Path

LABELS = [f"{operation}-{size}" for operation in ("decode-bytes", "decode-text") for size in (64, 1024, 16384)]


def require(value, label):
    if not value:
        raise ValueError(label)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def file_identity(path):
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"sha256": checksum, "bytes": path.stat().st_size}


class Verifier:
    """Hash each distinct input before analysis and again before publication."""
    def __init__(self):
        self.files = {}

    def verify(self, path, expected):
        path = path.resolve(strict=True)
        if path not in self.files:
            self.files[path] = file_identity(path)
        require(self.files[path] == expected, f"file identity: {path}")

    def sha(self, path, expected):
        self.verify(path, {"sha256": expected, "bytes": path.stat().st_size})

    def finish(self):
        for path, expected in self.files.items():
            require(file_identity(path) == expected, f"input changed during audit: {path}")


def compile_argument(timing, flag):
    command = timing["compile_command"]
    require(command.count(flag) == 1, f"ambiguous compile flag {flag}")
    return Path(command[command.index(flag) + 1]).resolve(strict=True)


def utc(value):
    parsed = datetime.fromisoformat(value)
    require(parsed.utcoffset() == timezone.utc.utcoffset(parsed), "timestamp is not UTC")
    return parsed


def source_symbol(source, llvm, function_name="b45decode"):
    """Require an unambiguous source-message-to-LLVM correspondence."""
    module = ast.parse(source.read_bytes())
    targets = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == function_name]
    require(len(targets) == 1, "named Python decoder is missing or ambiguous")
    target = targets[0]
    outside = {part.value for node in module.body if node is not target for part in ast.walk(node) if isinstance(part, ast.Constant) and isinstance(part.value, str)}
    messages = {argument.value for node in ast.walk(target) if isinstance(node, ast.Raise) and isinstance(node.exc, ast.Call) for argument in node.exc.args if isinstance(argument, ast.Constant) and isinstance(argument.value, str) and len(argument.value) >= 8 and argument.value not in outside}
    constants, functions = {}, {}
    active, body = None, []
    for line in llvm.read_text().splitlines(keepends=True):
        if active is not None:
            if line.startswith("}"):
                functions[active] = "".join(body)
                active, body = None, []
            else:
                body.append(line)
            continue
        if line.startswith("define"):
            match = re.search(r" @([^ (]+)\(", line)
            require(match is not None, "unrecognized LLVM function definition")
            active = match[1]
        elif line.startswith("@str_"):
            match = re.fullmatch(r'@(str_\d+) = private unnamed_addr constant \[\d+ x i8\] c"((?:\\[a-fA-F0-9]{2})*)"\n?', line)
            if match:
                try:
                    literal = bytes.fromhex(match[2].replace("\\", "")).decode()
                except UnicodeDecodeError:
                    continue
                constants.setdefault(literal, []).append(match[1])
    evidence, symbols = [], set()
    for message in sorted(messages):
        globals_ = constants.get(message, [])
        matches = [name for name, body in functions.items() if set(re.findall(r"@(str_\d+)\b", body)) & set(globals_)]
        if globals_ and len(matches) == 1:
            symbols.update(matches)
            evidence.append({"literal": message, "llvm_globals": globals_, "symbols": matches})
    require(len(symbols) == 1 and evidence, "source-to-LLVM decoder attribution is ambiguous")
    symbol = symbols.pop()
    return {"source_path": str(source), "source_sha256": file_identity(source)["sha256"], "source_function": function_name, "source_line": target.lineno, "llvm_symbol": symbol, "llvm_body_sha256": digest(functions[symbol].encode()), "evidence": evidence}


def native_instructions(binary, identity, summary, root, verifier, current):
    """Re-disassemble the exact timed executable and retain command identities."""
    commands, asm_text, assembly = [], [], {}
    native_tools = {}
    for name in ("nm", "objdump"):
        path = Path(shutil.which(name)).resolve(strict=True)
        verifier.verify(path, file_identity(path))
        if current:
            require(str(path) == summary["guarded_inputs"][f"tool_{name}"]["path"], f"audit/profile {name} mismatch")
        native_tools[name] = path
    env = {**os.environ, **summary["environment"]}
    command = [str(native_tools["nm"]), "--defined-only", str(binary)]
    result = subprocess.run(command, capture_output=True, input=b"", cwd=root, env=env, timeout=30, check=True)
    require(not result.stderr, "nm stderr")
    commands.append({"command": command, "returncode": result.returncode, "stdout_sha256": digest(result.stdout)})
    symbol = identity["llvm_symbol"]
    names = [line.split()[2] for line in result.stdout.decode().splitlines() if len(line.split()) == 3 and line.split()[1] in ("t", "T") and re.fullmatch(re.escape(symbol) + r"(?:\..+)?", line.split()[2])]
    require(names, "decoder native symbol is missing")
    if current:
        require(result.stdout == (root / "native-symbols.txt").read_bytes(), "retained native symbols differ")
        require(names == summary["decoder_identity"]["binary_symbols"], "decoder symbol list differs")
        require(command == summary["decoder_identity"]["symbol_command"], "native symbol command differs")
    for name in names:
        command = [str(native_tools["objdump"]), "-d", "--no-show-raw-insn", f"--disassemble={name}", str(binary)]
        result = subprocess.run(command, capture_output=True, input=b"", cwd=root, env=env, timeout=30, check=True)
        require(not result.stderr, "objdump stderr")
        commands.append({"command": command, "returncode": result.returncode, "stdout_sha256": digest(result.stdout)})
        asm_text.append(result.stdout)
        for line in result.stdout.decode().splitlines():
            match = re.fullmatch(r"\s*([0-9a-f]+):\s+(.+)", line)
            if match:
                address = int(match[1], 16)
                require(address not in assembly, "overlapping decoder assembly")
                assembly[address] = match[2]
    require(assembly, "decoder disassembly is empty")
    if current:
        require(b"\n".join(asm_text) == (root / "decoder.asm").read_bytes(), "retained decoder disassembly differs")
        require(commands[1:] == summary["decoder_identity"]["disassembly_commands"], "retained disassembly commands differ")
    return assembly, commands


def raw_instruction_costs(raw, symbol, binary):
    """Independently sum all raw self costs, excluding each call-arc cost record."""
    lines = raw.splitlines()
    require("positions: instr line" in lines and "events: Ir" in lines, "unsupported Callgrind position/event layout")
    dictionaries = {"fn": {}, "ob": {}}
    for line in lines:
        match = re.fullmatch(r"c?(fn|ob)=\((\d+)\) (.+)", line)
        if match:
            known = dictionaries[match[1]].setdefault(match[2], match[3])
            require(known == match[3], "Callgrind name ID changed")
    selected = {key: value for key, value in dictionaries["fn"].items() if symbol is not None and re.fullmatch(re.escape(symbol) + r"(?:\..+)?", value)}
    require(symbol is None or selected, "decoder Callgrind symbol is missing")
    total, addresses, calls = 0, Counter(), []
    active, obj, callee, address, call_cost = None, None, None, 0, False
    for line in lines:
        name = re.fullmatch(r"(c?)(fn|ob)=\((\d+)\)(?: .+)?", line)
        if name:
            if name[1] == "" and name[2] == "fn":
                active, address, call_cost = name[3], 0, False
                if active in selected:
                    require(dictionaries["ob"].get(obj) == str(binary), "decoder attributed to a different executable")
            elif name[1] == "" and name[2] == "ob":
                obj = name[3]
            elif name[1] == "c" and name[2] == "fn":
                callee = dictionaries["fn"].get(name[3])
            continue
        if line.startswith("calls="):
            call_cost = True
            continue
        fields = line.split()
        if len(fields) not in (2, 3) or not re.fullmatch(r"(?:0x[0-9a-f]+|[+-]?\d+|\*)", fields[0]) or not re.fullmatch(r"[+-]?\d+|\*", fields[1]):
            continue
        position = fields[0]
        if position.startswith(("+", "-")):
            address += int(position)
        elif position != "*":
            address = int(position, 16 if position.startswith("0x") else 10)
        cost = int(fields[2]) if len(fields) == 3 else 0
        if call_cost:
            if active in selected and len(fields) == 3:
                calls.append({"address": hex(address), "callee": callee, "inclusive_instructions": cost})
            call_cost = False
        else:
            total += cost
            if active in selected and len(fields) == 3:
                addresses[address] += cost
    return {"total": total, "functions": selected, "costs": addresses, "calls": sorted(calls, key=lambda value: value["inclusive_instructions"], reverse=True)}


def audit_profile(root, timing_path, repository, timed_python, verifier, current):
    verify = verifier.verify
    summary = read_json(root / "summary.json")
    manifest = read_json(root / "manifest.json")
    timing = read_json(timing_path)
    verifier.sha(timing_path, summary["benchmark_record_sha256"])
    require(
        summary["schema"] == 1
        and summary["complete"] is True
        and summary["guards_passed"] is True,
        "profile incomplete",
    )
    require(
        summary["source_dirty"] is False
        and summary["source_revision"] == timing["revision"],
        "profile source identity",
    )
    require(
        summary["timed_source_and_tool_sha256"] == timing["source_and_tool_sha256"],
        "timed source/tool hashes",
    )
    require(
        summary["timed_binary_sha256"]
        == {
            "relar": timing["binary_sha256"],
            "rust": timing["source_and_tool_sha256"]["rust"],
        },
        "timed executable hashes",
    )
    require(
        summary["timed_cpu"] == timing["cpu"]
        and summary["cpu_affinity"] == timing["cpu"]["affinity"],
        "CPU identity",
    )
    require(summary["raw_bytes_per_process"] == 65536, "profile batch size")
    require(timing["input_guards_passed"] is True and timing["dirty"] is False, "incomplete or exploratory timing")
    require(utc(summary["started_at_utc"]) <= utc(summary["completed_at_utc"]), "profile UTC chronology")
    require(summary["cpu_affinity"] == [timing["cpu"]["affinity"][0]], "one pinned CPU is required")
    if current:
        require(summary["status"] == "complete" and summary["thinlto"] == timing["thinlto"], "final completion or linkage mode")
        require(summary["runner_tracer_pid"] == 0, "final profiler was traced")
    require(
        digest(timing_path.read_bytes()) == summary["benchmark_record_sha256"],
        "profile benchmark record hash",
    )
    require(
        (root / "benchmark-record.json").read_bytes() == timing_path.read_bytes(),
        "retained benchmark bytes",
    )
    require(
        read_json(root / "rust-build-record.json") == timing["rust_build_record"],
        "Rust build record",
    )
    require(
        read_json(root / "tool-versions.json") == summary["tool_versions"],
        "tool versions",
    )

    actual_files = {
        str(path.relative_to(root))
        for path in root.rglob("*")
        if path.is_file() and path != root / "manifest.json"
    }
    require(set(manifest["files"]) == actual_files, "manifest file inventory")
    for relative, identity in manifest["files"].items():
        path = root / relative
        require(
            path.resolve().is_relative_to(root),
            "manifest path escaped profile directory",
        )
        verify(path, identity)
    verify(root / "manifest.json", file_identity(root / "manifest.json"))
    for name, value in summary["guarded_inputs"].items():
        verify(Path(value["path"]), {key: value[key] for key in ["sha256", "bytes"]})
        if name in ["binary_relar", "binary_rust"]:
            require(
                value["sha256"]
                == summary["timed_binary_sha256"][name.removeprefix("binary_")],
                "guarded binary differs from timing",
            )
    profiler_path = Path(summary["guarded_inputs"]["profiler"]["path"])
    require((root / profiler_path.name).read_bytes() == profiler_path.read_bytes(), "retained profiler differs from executed helper")
    for name, version in summary["tool_versions"].items():
        tool_name = "valgrind_launcher" if name == "valgrind" else name
        require(version["command"] == [summary["guarded_inputs"][f"tool_{tool_name}"]["path"], "--version"], "version command does not identify guarded tool")
        fresh = subprocess.run(version["command"], capture_output=True, input=b"", cwd=root, env={**os.environ, **summary["environment"]}, timeout=30, check=False)
        require(fresh.returncode == version["returncode"] and fresh.stdout.decode() == version["stdout"] and fresh.stderr.decode() == version["stderr"], "guarded tool version output differs")
    require(
        read_json(Path(summary["guarded_inputs"]["validation"]["path"]))
        == timing["validation"],
        "exact timed binary validation",
    )
    require(
        summary["guarded_inputs"]["llvm"]["sha256"] == timing["llvm_sha256"],
        "timed LLVM identity",
    )
    package = compile_argument(timing, "--module-root")
    binary = compile_argument(timing, "-o")
    require(str(binary) == summary["guarded_inputs"]["binary_relar"]["path"], "compile/profile executable differs")
    llvm = compile_argument(timing, "--emit-llvm")
    require(str(llvm) == summary["guarded_inputs"]["llvm"]["path"], "compile/profile LLVM differs")
    inputs = {
        "compiler": Path(timing["compile_command"][0]),
        "driver": Path(timing["compile_command"][2]),
        "runtime": compile_argument(timing, "--runtime"),
        "clang": compile_argument(timing, "--clang"),
        "python": timed_python,
        "codec": package / "base45/__init__.py",
        "upstream_manifest": package / "UPSTREAM.json",
        "harness": repository / "benchmarks/base45_benchmark.py",
        "validator": repository / "benchmarks/base45_validate.py",
        "shared_harness": repository / "benchmarks/benchmark.py",
        "tracked_rust_build_script": repository / "benchmarks/reference/base45_codec/build.py",
    }
    if timing["thinlto"]:
        inputs["lto_linker"] = compile_argument(timing, "--lto-linker")
    for index, name in enumerate(timing["upstream"]["files"]):
        inputs[f"upstream_{index}"] = package / name
    rust_record = timing["rust_build_record"]
    require(rust_record["binaries"]["reference"]["sha256"] == timing["source_and_tool_sha256"]["rust"] == timing["validation"]["rust"]["binary_sha256"], "Rust build/profile/validation differs")
    require(timing["binary_sha256"] == timing["validation"]["binary_sha256"], "Relar validated binary differs")
    require(timing["source_and_tool_sha256"]["compiler"] == timing["validation"]["compiler_sha256"], "validated compiler differs")
    verifier.sha(root / "rust-build-record.json", timing["source_and_tool_sha256"]["rust_build_record"])
    require(digest(rust_record["build_script"].encode()) == timing["source_and_tool_sha256"]["rust_build_script"], "Rust embedded build script differs")
    for name, checksum in rust_record["sources"].items():
        require(digest(rust_record["source_contents"][name].encode()) == checksum == timing["source_and_tool_sha256"][f"rust_source_{name}"], "Rust embedded source differs")
        inputs[f"tracked_rust_source_{name}"] = repository / "benchmarks/reference/base45_codec" / name
    for name, path in inputs.items():
        verifier.sha(path, timing["source_and_tool_sha256"][name])
        if current:
            require(summary["guarded_inputs"][f"timed_{name}"]["sha256"] == timing["source_and_tool_sha256"][name], f"source/tool guard mismatch: {name}")
            if name not in {"compiler", "runtime", "clang", "python", "lto_linker"}:
                require((root / "sources" / (name.replace("/", "_") + ".txt")).read_bytes() == path.read_bytes(), f"source snapshot differs: {name}")
    if current:
        for name, identity in summary["setup_artifacts"].items():
            require(identity == manifest["files"][name], "setup artifact changed during profiling")
        require(set(summary["source_snapshots"]) == {name for name in manifest["files"] if name.startswith("sources/")}, "source snapshot inventory differs")
        for name, identity in summary["source_snapshots"].items():
            require(identity == manifest["files"][name], "source snapshot identity differs")
    decoder = source_symbol(inputs["codec"], llvm)
    if current:
        retained_identity = read_json(root / "decoder-identity.json")
        require(retained_identity == summary["decoder_identity"], "decoder identity file differs")
        for name, value in decoder.items():
            require(retained_identity[name] == value, f"decoder source proof differs: {name}")
    assembly, disassembly_commands = native_instructions(binary, decoder, summary, root, verifier, current)

    labels = LABELS
    expected_matrix = {
        (label, engine, tool)
        for label in labels
        for engine in ["relar", "rust"]
        for tool in ["dhat", "callgrind"]
    }
    require(
        Counter(
            (entry["label"], entry["engine"], entry["tool"])
            for entry in summary["profiles"]
        )
        == Counter(expected_matrix),
        "profile matrix",
    )
    rows = {label: {} for label in labels}
    annotation_count = 0
    for entry in summary["profiles"]:
        label, engine, tool = entry["label"], entry["engine"], entry["tool"]
        directory = root / f"{label}-{engine}-{tool}"
        workload = next(item for item in timing["workloads"] if item["label"] == label)
        payload = base64.b64decode(workload["input_base64"], validate=True)
        output = (directory / "output.bin").read_bytes()
        repetitions = 65536 // workload["raw_bytes"]
        require(
            entry["repetitions"] == repetitions
            and entry["raw_bytes_per_process"] == 65536,
            "profile repetition count",
        )
        require(
            entry["input_bytes_per_process"] == len(payload) * repetitions,
            "profile input throughput unit",
        )
        require(
            (directory / "input.bin").read_bytes() == payload
            and entry["input_sha256"] == digest(payload),
            "profile input identity",
        )
        require(
            entry["output_sha256"]
            == digest(output)
            == workload["expected_output_sha256"],
            "full profile output identity",
        )
        require(
            entry["output_bytes"] == len(output) == workload["expected_output_bytes"],
            "profile output length",
        )
        require(len(output) == workload["raw_bytes"] == int(label.rsplit("-", 1)[1]), "decoder raw/output size differs")
        require(workload["operation"] == label.rsplit("-", 1)[0], "decoder operation label differs")
        timed_directory = binary.parent / label / engine
        require((timed_directory / "input.bin").read_bytes() == payload and (timed_directory / "output.bin").read_bytes() == output, "profile/timing complete bytes differ")
        expected_timed_stdout = f"OK\n{(len(output) + output[0] + output[-1]) * workload['repetitions']}\n"
        require(workload["expected_stdout"] == expected_timed_stdout, "timed checksum protocol differs")
        measurements = [workload["gates"][engine], *[sample[engine] for sample in workload["samples"]], *[sample[engine] for sample in workload["warmups"]]]
        require(len(workload["samples"]) > 0 and len(workload["warmups"]) > 0, "timing has no samples or warmups")
        for measurement in measurements:
            require(measurement["returncode"] == 0 and measurement["stderr"] == "" and measurement["stdout"] == expected_timed_stdout and measurement["output_sha256"] == digest(output), "timed sample output/status differs")
        expected_stdout = (
            f"OK\n{(len(output) + output[0] + output[-1]) * repetitions}\n"
        )
        require(
            entry["stdout"]
            == (directory / "stdout.txt").read_text()
            == expected_stdout,
            "profile output checksum",
        )
        require(
            entry["stdout_sha256"] == digest(expected_stdout.encode()), "stdout hash"
        )
        require(
            entry["returncode"] == 0
            and (directory / "process-stderr.txt").read_bytes() == b"",
            "profile process status",
        )
        require(entry["initial_output_sha256"] == digest(b"unchanged output"), "output sentinel identity differs")
        command_record = read_json(directory / "command.json")
        require(
            command_record["command"] == entry["command"]
            and command_record["cwd"] == str(directory)
            and command_record["environment"] == summary["environment"],
            "profile command record",
        )
        if current:
            require(command_record["cpu_affinity"] == summary["cpu_affinity"], "process CPU affinity differs")
            require(command_record["returncode"] == 0 and command_record["status"] == entry["status"] == "validated", "process validation status differs")
            require(command_record["started_at_utc"] == entry["started_at_utc"] and command_record["completed_at_utc"] == entry["completed_at_utc"], "process UTC metadata differs")
            require(utc(summary["started_at_utc"]) <= utc(entry["started_at_utc"]) <= utc(entry["completed_at_utc"]) <= utc(summary["completed_at_utc"]), "process UTC chronology differs")
        expected_program = [
            summary["guarded_inputs"][f"binary_{engine}"]["path"],
            workload["operation"],
            str(directory / "input.bin"),
            str(directory / "output.bin"),
            str(repetitions),
        ]
        require(
            entry["command"][-5:] == expected_program
            and f"--tool={tool}" in entry["command"]
            and "--error-exitcode=97" in entry["command"],
            "profile executable or arguments",
        )
        expected_command = [summary["guarded_inputs"]["tool_valgrind_launcher"]["path"], f"--tool={tool}", "--command-line-only=yes", "--num-callers=32", "--error-exitcode=97", f"--log-file={directory / 'valgrind.log'}"]
        if tool == "dhat":
            expected_command.append(f"--dhat-out-file={directory / 'profile.json'}")
        else:
            expected_command.extend([f"--callgrind-out-file={directory / 'profile.callgrind'}", "--dump-instr=yes", "--collect-jumps=yes"])
        require(entry["command"] == expected_command + expected_program, "exact profiler command differs")
        require(
            set(entry["files"])
            == {
                str(path.relative_to(root))
                for path in directory.iterdir()
                if path.is_file()
            },
            "per-profile file inventory",
        )
        for relative, identity in entry["files"].items():
            require(
                identity == manifest["files"][relative], "per-profile manifest identity"
            )
        raw_path = directory / (
            "profile.json" if tool == "dhat" else "profile.callgrind"
        )
        require(
            entry["profile_sha256"] == digest(raw_path.read_bytes()), "raw profile hash"
        )
        log = (directory / "valgrind.log").read_text()
        require(entry["log_sha256"] == digest(log.encode()), "profile log hash")
        row = rows[label].setdefault(engine, {})
        if tool == "dhat":
            raw = read_json(raw_path)
            require(
                raw["dhatFileVersion"] == 2
                and raw["mode"] == "heap"
                and raw["tu"] == "instrs",
                "DHAT schema",
            )
            require(
                raw["cmd"] == " ".join(expected_program), "DHAT executable/arguments"
            )
            for field, metric in [
                ("tb", "total_allocated_bytes"),
                ("tbk", "total_allocated_blocks"),
                ("gb", "peak_live_bytes"),
                ("gbk", "peak_live_blocks"),
                ("eb", "exit_live_bytes"),
                ("ebk", "exit_live_blocks"),
            ]:
                value = sum(point[field] for point in raw["pps"])
                require(value == entry[metric], f"DHAT recomputed {metric}")
                row[metric] = value
            for log_name, metric_bytes, metric_blocks in [
                ("Total", "total_allocated_bytes", "total_allocated_blocks"),
                ("At t-gmax", "peak_live_bytes", "peak_live_blocks"),
                ("At t-end", "exit_live_bytes", "exit_live_blocks"),
            ]:
                matches = re.findall(
                    re.escape(log_name) + r":\s+([\d,]+) bytes in ([\d,]+) blocks", log
                )
                require(len(matches) == 1, "DHAT log totals missing/duplicated")
                require(
                    tuple(int(value.replace(",", "")) for value in matches[0])
                    == (row[metric_bytes], row[metric_blocks]),
                    "DHAT raw/log totals disagree",
                )
            top = [
                {
                    "bytes": point["tb"],
                    "blocks": point["tbk"],
                    "frames": [raw["ftbl"][index] for index in point["fs"]],
                }
                for point in sorted(
                    raw["pps"], key=lambda point: point["tb"], reverse=True
                )[:8]
            ]
            require(top == entry["top_allocation_stacks"], "DHAT top allocation stacks")
            row["top_allocation_stacks"] = top[:3]
        else:
            raw = raw_path.read_text()
            require(
                re.findall(r"^cmd:\s*(.*)$", raw, re.MULTILINE)
                == [" ".join(expected_program)],
                "Callgrind executable/arguments",
            )
            require(
                re.findall(r"^events:\s*(.*)$", raw, re.MULTILINE) == ["Ir"],
                "Callgrind event inventory",
            )
            values = re.findall(r"^(?:summary|totals):\s*(\d+)$", raw, re.MULTILINE)
            require(
                len(values) == 2 and values[0] == values[1],
                "Callgrind raw summary/totals differ",
            )
            instructions = int(values[0])
            require(
                instructions > 0
                and entry["instructions"] == instructions
                and entry["events"] == {"Ir": instructions},
                "Callgrind instructions",
            )
            log_counts = re.findall(r"Collected\s*:\s*([\d,]+)", log)
            require(
                len(log_counts) == 1
                and int(log_counts[0].replace(",", "")) == instructions,
                "Callgrind log total",
            )
            row["instructions"] = instructions
            raw_costs = raw_instruction_costs(raw, decoder["llvm_symbol"] if engine == "relar" else None, binary if engine == "relar" else Path(summary["guarded_inputs"]["binary_rust"]["path"]))
            require(raw_costs["total"] == instructions, "sum of raw instruction self costs differs from summary/log")
            if engine == "relar":
                costs = raw_costs["costs"]
                exclusive = sum(costs.values())
                require(costs and set(costs) <= set(assembly), "decoder instruction addresses do not map to timed executable")
                row["decoder_attribution"] = {"source_function": decoder["source_function"], "llvm_symbol": decoder["llvm_symbol"], "callgrind_functions": raw_costs["functions"], "exclusive_instructions": exclusive, "fraction_of_process": exclusive / instructions, "mapped_instruction_addresses": len(costs), "top_calls_by_inclusive_instructions": raw_costs["calls"][:10]}
                if current:
                    retained = read_json(directory / "decoder-instructions.json")
                    require(retained["llvm_symbol"] == decoder["llvm_symbol"] and retained["callgrind_functions"] == raw_costs["functions"], "retained decoder symbol attribution differs")
                    require(retained["exclusive_instructions"] == retained["mapped_exclusive_instructions"] == entry["decoder_exclusive_instructions"] == exclusive, "decoder self-cost totals differ")
                    require(retained["instruction_costs"] == {hex(address): cost for address, cost in sorted(costs.items())}, "per-address decoder costs differ")
                    require(retained["calls"] == raw_costs["calls"], "decoder call costs differ")
                    require(retained["fraction_of_process_instructions"] == exclusive / instructions, "decoder fraction differs")
                    annotated = "".join(f"{address:08x} {costs.get(address, 0):10,d} {instruction}\n" for address, instruction in sorted(assembly.items()))
                    require((directory / "decoder-instructions.asm").read_text() == annotated, "instruction-annotated decoder assembly differs")
            require(
                {annotation["inclusive"] for annotation in entry["annotations"]}
                == {"no", "yes"},
                "annotation inventory",
            )
            for annotation in entry["annotations"]:
                inclusive = annotation["inclusive"]
                command = [
                    summary["guarded_inputs"]["tool_callgrind_annotate"]["path"],
                    "--auto=no",
                    f"--inclusive={inclusive}",
                    "--threshold=100",
                    str(raw_path),
                ]
                require(
                    annotation["command"] == command and annotation["returncode"] == 0,
                    "annotation command/status",
                )
                completed = subprocess.run(
                    command,
                    capture_output=True,
                    input=b"",
                    cwd=directory,
                    env={**os.environ, **summary["environment"]},
                    timeout=30,
                    check=True,
                )
                require(
                    completed.stdout
                    == (
                        directory / f"functions-inclusive-{inclusive}.txt"
                    ).read_bytes(),
                    "fresh annotation differs from retained output",
                )
                require(
                    completed.stderr
                    == (
                        directory / f"functions-inclusive-{inclusive}-stderr.txt"
                    ).read_bytes()
                    == b"",
                    "annotation stderr",
                )
                require(
                    digest(completed.stdout) == annotation["stdout_sha256"]
                    and digest(completed.stderr) == annotation["stderr_sha256"],
                    "annotation hashes",
                )
                annotation_count += 1
                if inclusive == "no":
                    hotspots = re.findall(
                        r"^\s*([\d,]+)\s+\(\s*([\d.]+)%\)\s+(.*)$",
                        completed.stdout.decode(),
                        re.MULTILINE,
                    )
                    row["top_exclusive_functions"] = [
                        {
                            "instructions": int(count.replace(",", "")),
                            "percent": float(percent),
                            "function": name,
                        }
                        for count, percent, name in hotspots
                        if name != "PROGRAM TOTALS"
                    ][:5]
                    if engine == "relar":
                        selected_costs = [int(count.replace(",", "")) for count, _, name in hotspots if re.search(r":" + re.escape(decoder["llvm_symbol"]) + r"(?:\.[^ ]+)? \[" + re.escape(str(binary)) + r"\]$", name)]
                        require(sum(selected_costs) == exclusive, "independent annotation/decoder self costs differ")

    return {
        "passed": True,
        "profile_directory": str(root),
        "timing_record": str(timing_path),
        "timing_sha256": digest(timing_path.read_bytes()),
        "summary_sha256": digest((root / "summary.json").read_bytes()),
        "manifest_sha256": digest((root / "manifest.json").read_bytes()),
        "source_revision": summary["source_revision"],
        "source_and_tool_sha256": summary["timed_source_and_tool_sha256"],
        "timed_binary_sha256": summary["timed_binary_sha256"],
        "cpu_affinity": summary["cpu_affinity"],
        "decoder_identity": decoder,
        "decoder_disassembly_commands": disassembly_commands,
        "profiles_checked": len(summary["profiles"]),
        "annotations_recomputed": annotation_count,
        "raw_bytes_per_profiled_process": 65536,
        "allocation_unit": "DHAT requested heap bytes/blocks, whole process; gb/gbk give global peak contributions",
        "instruction_unit": "Callgrind instrumented guest instructions, whole process; not timing or CPU cycles",
        "tables": rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", type=Path, default=Path("/tmp/relar-decoder-baseline-profile"))
    parser.add_argument("--current", type=Path, default=Path("/tmp/relar-decoder-final-profile"))
    parser.add_argument("--before-timing", type=Path, default=Path("/tmp/relar-string-reuse-thinlto.json"))
    parser.add_argument("--current-timing", type=Path, default=Path("/tmp/relar-decoder-thinlto.json"))
    parser.add_argument("--repo", type=Path, default=Path("/home/dev-user/code/oss/relar"))
    parser.add_argument("--timed-python", type=Path, default=Path("/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14"))
    parser.add_argument("--output", type=Path, default=Path("/tmp/relar-decoder-profile-audit.json"))
    parser.add_argument("--comparison-output", type=Path, default=Path("/tmp/relar-decoder-profile-comparison.json"))
    args = parser.parse_args()
    started = datetime.now(timezone.utc).isoformat()
    tracer = int(next(line.split(":", 1)[1] for line in Path("/proc/self/status").read_text().splitlines() if line.startswith("TracerPid:")))
    require(tracer == 0, "final audit must run outside the managed ptrace sandbox")
    before_root, current_root = args.before.resolve(strict=True), args.current.resolve(strict=True)
    require(not args.output.resolve().is_relative_to(before_root) and not args.output.resolve().is_relative_to(current_root), "audit output must not alter profile artifacts")
    require(not args.comparison_output.resolve().is_relative_to(before_root) and not args.comparison_output.resolve().is_relative_to(current_root), "comparison output must not alter profile artifacts")
    require(args.output.resolve() != args.comparison_output.resolve(), "audit and comparison outputs must differ")
    verifier = Verifier()
    verifier.verify(Path(__file__), file_identity(Path(__file__)))
    before_timing, current_timing = read_json(args.before_timing), read_json(args.current_timing)
    require(before_timing["thinlto"] == current_timing["thinlto"], "before/current linkage modes differ")
    require(before_timing["cpu"] == current_timing["cpu"], "before/current CPU identity differs")
    require(before_timing["rust_build_record"] == current_timing["rust_build_record"], "before/current Rust reference changed")
    for key in before_timing["source_and_tool_sha256"]:
        if key in {"codec", "driver", "harness", "validator", "shared_harness", "upstream_manifest", "python", "rust", "rust_build_record", "rust_build_script"} or key.startswith(("rust_source_", "tracked_rust_", "upstream_")):
            require(before_timing["source_and_tool_sha256"][key] == current_timing["source_and_tool_sha256"][key], f"comparison source changed: {key}")
    for label in LABELS:
        left = next(row for row in before_timing["workloads"] if row["label"] == label)
        right = next(row for row in current_timing["workloads"] if row["label"] == label)
        require(all(left[key] == right[key] for key in ("operation", "raw_bytes", "input_base64", "expected_output_sha256", "expected_output_bytes")), "before/current input or expected output changed")
    before = audit_profile(before_root, args.before_timing, args.repo, args.timed_python, verifier, False)
    current = audit_profile(current_root, args.current_timing, args.repo, args.timed_python, verifier, True)
    tables = {}
    metrics = ("instructions", "total_allocated_bytes", "total_allocated_blocks", "peak_live_bytes", "peak_live_blocks", "exit_live_bytes", "exit_live_blocks")
    for label in LABELS:
        old, new = before["tables"][label], current["tables"][label]
        tables[label] = {
            "before": {key: old["relar"][key] for key in metrics},
            "current": {key: new["relar"][key] for key in metrics},
            "rust": {"before": {key: old["rust"][key] for key in metrics}, "current": {key: new["rust"][key] for key in metrics}},
            "current_over_before": {key: new["relar"][key] / old["relar"][key] if old["relar"][key] else None for key in metrics},
            "current_over_rust": {key: new["relar"][key] / new["rust"][key] if new["rust"][key] else None for key in metrics},
            "before_over_rust": {key: old["relar"][key] / old["rust"][key] if old["rust"][key] else None for key in metrics},
        }
    verifier.finish()
    for profile_root in (before_root, current_root):
        require(set(read_json(profile_root / "manifest.json")["files"]) == {str(path.relative_to(profile_root)) for path in profile_root.rglob("*") if path.is_file() and path != profile_root / "manifest.json"}, "profile file inventory changed during audit")
    result = {"schema": 1, "passed": True, "started_at_utc": started, "completed_at_utc": datetime.now(timezone.utc).isoformat(), "script_sha256": digest(Path(__file__).read_bytes()), "invocation": {"command": [sys.executable, *sys.argv], "cwd": str(Path.cwd())}, "runner_tracer_pid": tracer, "profiles_checked": before["profiles_checked"] + current["profiles_checked"], "annotations_recomputed": before["annotations_recomputed"] + current["annotations_recomputed"], "verified_files": len(verifier.files), "raw_bytes_per_profiled_process": 65536, "before": before, "current": current, "comparison": tables, "allocation_unit": "DHAT requested heap bytes/blocks; global peak uses allocation-point gb/gbk contributions, not their independent maxima; whole process including startup and I/O, not RSS.", "instruction_unit": "Callgrind executed guest instructions; whole process including startup, validation, checksum and I/O; not wall time or CPU cycles.", "rust_note": "The exact same Rust executable and sources are required. Both raw Rust runs are retained separately: process arguments and profile-directory lengths can change startup instruction/allocation counts."}
    audit_bytes = (json.dumps(result, indent=2) + "\n").encode()
    args.output.write_bytes(audit_bytes)
    comparison = {
        "schema": 1,
        "passed": True,
        "audit_path": str(args.output.resolve()),
        "audit_sha256": digest(audit_bytes),
        "audit_script_sha256": result["script_sha256"],
        "before_summary_sha256": before["summary_sha256"],
        "current_summary_sha256": current["summary_sha256"],
        "before_manifest_sha256": before["manifest_sha256"],
        "current_manifest_sha256": current["manifest_sha256"],
        "before_timing_sha256": before["timing_sha256"],
        "current_timing_sha256": current["timing_sha256"],
        "raw_bytes_per_profiled_process": result["raw_bytes_per_profiled_process"],
        "allocation_unit": result["allocation_unit"],
        "instruction_unit": result["instruction_unit"],
        "rust_note": result["rust_note"],
        "comparison": tables,
    }
    require(digest(args.output.read_bytes()) == comparison["audit_sha256"], "published audit bytes differ")
    args.comparison_output.write_text(json.dumps(comparison, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("passed", "profiles_checked", "annotations_recomputed", "verified_files")}))


if __name__ == "__main__":
    main()
