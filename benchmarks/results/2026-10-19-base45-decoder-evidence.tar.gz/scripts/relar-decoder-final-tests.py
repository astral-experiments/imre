"""Validate frozen decoder artifacts, language suites, and application oracles.

No Cargo builds or benchmark timings run here. The suite/app commands, their
outputs, reviewed Rust-reference provenance, and run-wide input hash guards are
retained under --output. Internal subprocess behavior is defined by the guarded
test/validator sources; the recorded commands are their exact entrypoints.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import time
import traceback


SUITES = """
differential imports classes containers comprehensions fstrings calls expressions
floats bytes matching assignments truthiness loop_else unpacking primitives
string_reuse decoder_optimizations unions module_values exceptions io files base45
""".split()

APPLICATIONS = {
    "route": ("route_planner.py", "validate.py", None, None),
    "dependency": (
        "dependency_planner/__main__.py", "dependency_validate.py",
        "dependency_planner", "dependency-reference-tuned-lto",
    ),
    "incremental": (
        "incremental_planner/__main__.py", "incremental_validate.py",
        "incremental_planner", "incremental-reference-normal-final",
    ),
    "batch": (
        "batch_planner/__main__.py", "batch_validate.py",
        "incremental_planner", "batch-reference-normal-final",
    ),
    "manifest": (
        "manifest_planner/__main__.py", "manifest_validate.py",
        "incremental_planner", "manifest-reference-normal-final",
    ),
    "inventory": (
        "inventory_reconciliation/__main__.py", "inventory_validate.py",
        "inventory_reconciliation", "keyword-arguments-reference-final-normal",
    ),
}


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def executable(value):
    # Preserve argv[0], notably the gcc-ld/ld.lld wrapper's name.
    path = Path(value) if "/" in value else Path(shutil.which(value) or value)
    path = path.absolute()
    if not path.is_file() or not os.access(path, os.X_OK):
        raise ValueError(f"not an executable file: {path}")
    return path


def reference_sources(directory):
    return [directory / "Cargo.toml", directory / "Cargo.lock", *sorted((directory / "src").rglob("*.rs"))]


class Validation:
    def __init__(self, args):
        self.args = args
        self.root = args.root.resolve(strict=True)
        self.output = args.output.absolute()
        if (self.output / "index.json").exists():
            raise ValueError(f"refusing to overwrite prior validation: {self.output}")
        self.output.mkdir(parents=True, exist_ok=True)
        saved_runner = self.output / "run-tests.py"
        shutil.copy2(Path(__file__), saved_runner)
        assert digest(saved_runner) == digest(Path(__file__))
        self.tools = {
            name: executable(str(getattr(args, name)))
            for name in ("compiler", "python", "clang", "lto_linker", "rust_lld", "ruff")
        }
        self.tools["runner_python"] = executable(os.sys.executable)
        self.tools["git"] = executable("git")
        self.runtimes = {
            "ordinary": args.runtime.resolve(strict=True),
            "thinlto": args.thinlto_runtime.resolve(strict=True),
            "asan": args.asan_runtime.resolve(strict=True),
        }
        self.flags = {
            "ordinary": ["--opt-levels", "0", "3"],
            "thinlto": ["--target", args.target, "--lto-linker", str(self.tools["lto_linker"]), "--opt-levels", "3"],
            "asan": ["--sanitize", "--opt-levels", "0", "1"],
        }
        self.environment = {
            **os.environ,
            "PYTHONDONTWRITEBYTECODE": "1",
            "ASAN_OPTIONS": "detect_leaks=1:halt_on_error=1",
            "GIT_OPTIONAL_LOCKS": "0",
        }
        self.extra_inputs = set()
        self.references = {}
        self.provenance = {}
        self.prepare_references()
        self.frozen_build = self.verify_frozen_build()
        self.before = self.input_hashes()
        manifest = self.output / "input-sha256.json"
        write_json(manifest, self.before)
        self.manifest_sha256 = digest(manifest)
        self.index = {
            "started_at": now(),
            "status": "running",
            "scope": "24 suites: ordinary O0/O3, ThinLTO O3, ASan O0/O1; explicit LTO checks; six ordinary O3 application oracles; both retained Rust Base45 references; fixture Ruff checks. No Cargo builds or timings.",
            "invocation": os.sys.orig_argv,
            "max_parallel_jobs": args.workers,
            "input_manifest": str(manifest),
            "input_manifest_sha256": self.manifest_sha256,
            "hash_guard_scope": "Every selected tool/archive/reference and source input is hashed before and after the whole run; added or deleted selected source files also fail the guard.",
            "runtime_sha256": {name: digest(path) for name, path in self.runtimes.items()},
            "tool_sha256": {name: digest(path) for name, path in self.tools.items()},
            "retained_references": self.provenance,
            "frozen_build": self.frozen_build,
            "commands": [],
            "jobs": {},
        }

    def verify_frozen_build(self):
        path = self.args.build_record.resolve(strict=True)
        record = json.loads(path.read_text())
        assert record["source_matches_revision"] and record["input_guards_passed"]
        assert record["target"] == self.args.target
        selected = {"compiler": self.tools["compiler"], "normal_runtime": self.runtimes["ordinary"], "thinlto_runtime": self.runtimes["thinlto"], "asan_runtime": self.runtimes["asan"]}
        for name, selected_path in selected.items():
            assert digest(selected_path) == record["artifacts"][name]["sha256"], f"frozen artifact mismatch: {name}"
        verified_tools = ("clang", "lto_linker", "rust_lld", "python", "ruff", "git")
        for name in verified_tools:
            assert digest(self.tools[name]) == record["tools"][name]["sha256"], f"frozen tool mismatch: {name}"
        source_paths = [*(self.root / name for name in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml")), *(self.root / "crates").rglob("*.rs"), *(self.root / "crates").rglob("Cargo.toml")]
        actual_sources = {str(source.relative_to(self.root)): digest(source) for source in source_paths}
        assert actual_sources == record["source_sha256"], "compiler/runtime sources differ from the frozen revision"
        assert record["archive_probes"]["normal_runtime"]["expected_format"] == "elf"
        assert record["archive_probes"]["thinlto_runtime"]["expected_format"] == "llvm-bitcode"
        assert record["archive_probes"]["asan_runtime"]["references_asan_init"]
        saved = self.output / "frozen-build.json"
        shutil.copy2(path, saved)
        assert digest(saved) == digest(path)
        return {"path": str(path), "saved_record": str(saved), "sha256": digest(path), "revision": record["revision"], "artifact_labels_verified": list(selected), "source_matches_frozen_revision": True, "tools_verified": list(verified_tools)}

    def prepare_references(self):
        overrides = {}
        if self.args.reference_directories:
            self.extra_inputs.add(self.args.reference_directories.resolve(strict=True))
            overrides = json.loads(self.args.reference_directories.read_text())
        specs = {
            name: (package, self.root / "benchmarks/local" / folder)
            for name, (_, _, package, folder) in APPLICATIONS.items() if package
        }
        specs["base45-normal"] = ("base45_codec", self.args.base45_reference_dir)
        specs["base45-thinlto"] = ("base45_codec", self.args.base45_thinlto_reference_dir)
        for name, (package, default_directory) in specs.items():
            directory = Path(overrides.get(name, default_directory)).resolve(strict=True)
            record_path = directory / "build-record.json"
            record = json.loads(record_path.read_text())
            source = self.root / "benchmarks/reference" / package
            actual = {str(path.relative_to(source)): digest(path) for path in reference_sources(source)}
            differences = {}
            for filename in sorted(actual.keys() | record["sources"].keys()):
                old = record["source_contents"].get(filename, "")
                if filename in record["sources"]:
                    assert hashlib.sha256(old.encode()).hexdigest() == record["sources"][filename], filename
                current = (source / filename).read_text() if filename in actual else ""
                if old != current:
                    differences[filename] = "".join(difflib.unified_diff(old.splitlines(True), current.splitlines(True), fromfile="retained/" + filename, tofile="current/" + filename))
            review = None
            if differences:
                # Reuse the previous milestone's review only when both reviewed
                # source inputs and the retained build record remain identical.
                review_path = self.args.reference_review_root / name / "reference-provenance.json"
                review = json.loads(review_path.read_text())
                assert review["current_sources"] == actual, f"new unreviewed reference changes: {name}"
                assert review["build_record_sha256"] == digest(record_path), f"changed reviewed reference: {name}"
                self.extra_inputs.add(review_path.resolve(strict=True))
            binaries = {}
            for mode, metadata in record["binaries"].items():
                binary = directory / metadata["name"]
                assert digest(binary) == metadata["sha256"], binary
                binaries[mode] = binary
            saved = self.output / "references" / name / "build-record.json"
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(record_path, saved)
            provenance = {
                "directory": str(directory),
                "build_record_sha256": digest(record_path),
                "saved_build_record": str(saved),
                "binaries": {mode: {"path": str(binary), "sha256": digest(binary)} for mode, binary in binaries.items()},
                "current_sources": actual,
                "source_hashes_identical": record["sources"] == actual,
                "compatibility_review": review["compatibility_review"] if review else "Exact current source and Cargo.lock hashes.",
                "source_differences": differences,
            }
            write_json(saved.with_name("provenance.json"), provenance)
            self.references[name] = binaries
            self.provenance[name] = provenance
            self.extra_inputs.update([record_path, *binaries.values(), *reference_sources(source)])

    def input_hashes(self):
        paths = {Path(__file__).absolute(), *self.tools.values(), *self.runtimes.values(), *self.extra_inputs}
        for name in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml", "ruff.toml", ".github/workflows/ci.yml"):
            path = self.root / name
            if path.is_file():
                paths.add(path)
        for directory in ("tests", "examples"):
            paths.update(path for path in (self.root / directory).rglob("*") if path.is_file() and "__pycache__" not in path.parts)
        paths.update((self.root / "crates").rglob("*.rs"))
        paths.update((self.root / "crates").rglob("Cargo.toml"))
        paths.update((self.root / "benchmarks").glob("*.py"))
        paths.update((self.root / "benchmarks/reference").rglob("*.py"))
        if self.args.build_record:
            paths.add(self.args.build_record.resolve())
        return {str(path): digest(path) if path.is_file() else None for path in sorted(paths)}

    def command(self, directory, label, command):
        directory.mkdir(parents=True, exist_ok=True)
        command = [str(part) for part in command]
        record = {
            "command": command,
            "shell_display": shlex.join(command),
            "cwd": str(self.root),
            "started_at": now(),
            "input_manifest_sha256": self.manifest_sha256,
            "environment_overrides": {key: self.environment[key] for key in ("ASAN_OPTIONS", "PYTHONDONTWRITEBYTECODE", "GIT_OPTIONAL_LOCKS")},
        }
        start = time.monotonic()
        process = subprocess.Popen(command, cwd=self.root, env=self.environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        try:
            stdout, stderr = process.communicate(timeout=self.args.timeout)
        except subprocess.TimeoutExpired:
            record["timed_out"] = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                stdout, stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                stdout, stderr = process.communicate()
        stdout_path = directory / f"{label}.stdout"
        stderr_path = directory / f"{label}.stderr"
        stdout_path.write_bytes(stdout)
        stderr_path.write_bytes(stderr)
        record.update(
            finished_at=now(), seconds=time.monotonic() - start,
            returncode=process.returncode, stdout=str(stdout_path), stderr=str(stderr_path),
            stdout_sha256=digest(stdout_path), stderr_sha256=digest(stderr_path),
        )
        write_json(directory / f"{label}.command.json", record)
        if process.returncode or record.get("timed_out"):
            raise RuntimeError(f"command failed: {label}; see {directory}")
        return record, stdout.decode("utf-8", "replace")

    def python_command(self, source):
        return [self.tools["python"], "-I", "-B", source]

    def suite(self, name, mode):
        directory = self.output / "suites" / mode / name
        command = self.python_command(self.root / "tests" / f"{name}.py") + [
            "--compiler", self.tools["compiler"], "--runtime", self.runtimes[mode],
            "--clang", self.tools["clang"], "--python", self.tools["python"], *self.flags[mode],
        ]
        if name == "base45":
            command += ["--output", directory / "validation.json"]
        executed, stdout = self.command(directory, "suite", command)
        result = {"command": executed, "summary": stdout.strip()}
        if name == "base45":
            records = json.loads((directory / "validation.json").read_text())
            expected_levels = {"ordinary": ["0", "3"], "thinlto": ["3"], "asan": ["0", "1"]}[mode]
            assert [record["opt_level"] for record in records] == expected_levels
            for record in records:
                assert record["native_adapter_calls"] == 323
                assert len(record["differential_cases"]) == 289
                assert len(record["wrong_typed_compile_rejections"]) == 2
                assert record["compiler_sha256"] == self.index["tool_sha256"]["compiler"]
                assert record["shared_exports_recovery"] == "passed"
                assert record["sanitize"] == (mode == "asan")
            result["base45_variants"] = len(records)
            result["each_variant"] = {"upstream_native_calls": 323, "differential_cases": 289, "compile_rejections": 2}
        else:
            match = re.search(r"^Passed (\d+) .*checks", stdout, re.MULTILINE) or re.search(r"^(\d+) import checks passed$", stdout, re.MULTILINE)
            assert match is not None, stdout
            result["checks"] = int(match.group(1))
        return result

    def lto(self):
        command = self.python_command(self.root / "tests/lto.py") + [
            "--compiler", self.tools["compiler"], "--runtime", self.runtimes["thinlto"],
            "--clang", self.tools["clang"], "--target", self.args.target,
            "--rust-lld", self.tools["rust_lld"], "--python", self.tools["python"],
        ]
        record, stdout = self.command(self.output / "lto", "suite", command)
        return {"command": record, "summary": stdout.strip()}

    def rust_base45(self, name):
        directory = self.output / "rust" / name
        output = directory / "validation.json"
        command = self.python_command(self.root / "benchmarks/base45_validate.py") + [
            "--rust", self.references[name]["reference"], "--output", output,
        ]
        executed, stdout = self.command(directory, "validate", command)
        result = json.loads(output.read_text())
        assert len(result["rust"]["differential_cases"]) == 295
        return {"command": executed, "summary": stdout.strip(), "cases": len(result["rust"]["differential_cases"]), "diagnostic_boundaries": result["rust"]["diagnostic_boundaries"]}

    def application(self, name):
        source, validator, _, _ = APPLICATIONS[name]
        directory = self.output / "applications" / name
        binary = directory / name
        llvm = directory / f"{name}.ll"
        commands = []
        command = [
            self.tools["compiler"], "build", self.root / "examples" / source,
            "--module-root", self.root / "examples", "--runtime", self.runtimes["ordinary"],
            "--clang", self.tools["clang"], "--opt-level", "3", "--emit-llvm", llvm, "-o", binary,
        ]
        executed, _ = self.command(directory, "compile", command)
        commands.append(executed)
        compiled_hashes = {"binary_sha256": digest(binary), "llvm_sha256": digest(llvm)}
        output = directory / "validation.json"
        command = self.python_command(self.root / "benchmarks" / validator) + ["--python", self.tools["python"], "--binary", binary]
        references = self.references.get(name, {})
        if name not in ("route", "dependency"):
            command += ["--rust-bigint", references["bigint"], "--output", output]
            if name == "incremental":
                command += ["--rust-i64", references["i64"]]
        executed, stdout = self.command(directory, "validate", command)
        commands.append(executed)
        if name in ("route", "dependency"):
            write_json(output, json.loads(stdout))
        validation = json.loads(output.read_text())
        result = {"commands": commands, "validation": str(output), "counts": {key: value for key, value in validation.items() if key not in ("checks", "parser_checks", "records")}}
        if name == "dependency":
            output = directory / "boundaries.json"
            command = self.python_command(self.root / "benchmarks/reference/dependency_planner/check_boundaries.py") + [
                "--python", self.tools["python"], "--relar", binary,
                "--rust-bigint", references["bigint"], "--rust-i64", references["i64"], "--output", output,
            ]
            executed, _ = self.command(directory, "boundaries", command)
            commands.append(executed)
            boundaries = json.loads(output.read_text())
            result["boundaries"] = {"path": str(output), "cases": boundaries["cases"], "i64_overflow_rejections": boundaries["i64_overflow_rejections"]}
        assert compiled_hashes == {"binary_sha256": digest(binary), "llvm_sha256": digest(llvm)}, "application artifacts changed during validation"
        result.update(compiled_hashes)
        return result

    def job(self, name, function, *arguments):
        record = {"job": name, "started_at": now()}
        try:
            record.update(function(*arguments), status="passed")
        except Exception:
            record.update(status="failed", error=traceback.format_exc())
        record["finished_at"] = now()
        write_json(self.output / "jobs" / f"{name}.json", record)
        return record

    def run(self):
        preflight = self.output / "preflight"
        fixtures = [self.root / "tests/decoder_optimizations.py", self.root / "tests/fixtures/decoder_optimizations"]
        commands = {
            "runner-python-version": [self.tools["runner_python"], "--version"],
            "python-version": [self.tools["python"], "--version"],
            "python-build": [self.tools["python"], "-I", "-B", "-c", "import json,sysconfig;print(json.dumps({k:sysconfig.get_config_var(k) for k in ['CONFIG_ARGS','PY_CFLAGS','PY_LDFLAGS']}))"],
            "clang-version": [self.tools["clang"], "--version"],
            "lto-linker-version": [self.tools["lto_linker"], "--version"],
            "rust-lld-version": [self.tools["rust_lld"], "-flavor", "gnu", "--version"],
            "ruff-version": [self.tools["ruff"], "--version"],
            "git-head": [self.tools["git"], "rev-parse", "HEAD"],
            "git-status": [self.tools["git"], "status", "--short"],
            "ruff-check": [self.tools["ruff"], "check", "--no-cache", *fixtures],
            "ruff-format": [self.tools["ruff"], "format", "--check", "--no-cache", *fixtures],
        }
        write_json(self.output / "index.json", self.index)
        for label, command in commands.items():
            try:
                executed, _ = self.command(preflight, label, command)
            except Exception:
                self.index.update(status="failed", finished_at=now(), error=traceback.format_exc())
                write_json(self.output / "index.json", self.index)
                raise
            self.index["commands"].append(executed)
        work = [(f"{mode}-{suite}", self.suite, suite, mode) for mode in self.runtimes for suite in SUITES]
        work += [("thinlto-linker", self.lto)]
        work += [(name, self.rust_base45, name) for name in ("base45-normal", "base45-thinlto")]
        work += [("application-" + name, self.application, name) for name in APPLICATIONS]
        self.index["expected_jobs"] = len(work)
        with ThreadPoolExecutor(max_workers=self.args.workers) as executor:
            futures = [executor.submit(self.job, *job) for job in work]
            for future in as_completed(futures):
                record = future.result()
                self.index["jobs"][record["job"]] = record
                write_json(self.output / "index.json", self.index)
                print(json.dumps({"job": record["job"], "status": record["status"], "checks": record.get("checks"), "error": record.get("error")}), flush=True)
        after = self.input_hashes()
        changed = {name: {"before": self.before.get(name), "after": after.get(name)} for name in sorted(self.before.keys() | after.keys()) if self.before.get(name) != after.get(name)}
        self.index["input_guards_passed"] = not changed
        self.index["changed_inputs"] = changed
        self.index["language_checks"] = {mode: sum(record.get("checks", 0) for name, record in self.index["jobs"].items() if name.startswith(mode + "-")) for mode in self.runtimes}
        self.index["base45_native_variants"] = sum(record.get("base45_variants", 0) for record in self.index["jobs"].values())
        self.index["status"] = "passed" if not changed and all(record["status"] == "passed" for record in self.index["jobs"].values()) else "failed"
        self.index["finished_at"] = now()
        self.index["artifact_sha256"] = {str(path.relative_to(self.output)): digest(path) for path in sorted(self.output.rglob("*")) if path.is_file() and path.name != "index.json"}
        write_json(self.output / "index.json", self.index)
        print(json.dumps({"status": self.index["status"], "language_checks": self.index["language_checks"], "base45_native_variants": self.index["base45_native_variants"], "input_guards_passed": not changed, "index": str(self.output / "index.json")}), flush=True)
        if self.index["status"] != "passed":
            raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/relar"))
    parser.add_argument("--compiler", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--thinlto-runtime", type=Path, required=True)
    parser.add_argument("--asan-runtime", type=Path, required=True)
    parser.add_argument("--python", required=True)
    parser.add_argument("--clang", default="clang-18")
    parser.add_argument("--target", required=True)
    parser.add_argument("--lto-linker", type=Path, required=True)
    parser.add_argument("--rust-lld", type=Path, required=True)
    parser.add_argument("--ruff", type=Path, default=Path("/tmp/ohm-stream-cgu-more-20261015/checkpoints/ruff-dev/0/debug/ruff"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=1200)
    parser.add_argument("--build-record", type=Path, required=True)
    parser.add_argument("--reference-directories", type=Path, help="optional JSON object mapping application/base45 reference names to retained directories")
    parser.add_argument("--reference-review-root", type=Path, default=Path("/tmp/relar-string-reuse-validation/applications"))
    parser.add_argument("--base45-reference-dir", type=Path, default=Path("/home/dev-user/code/oss/relar/benchmarks/local/base45-reference-dev"))
    parser.add_argument("--base45-thinlto-reference-dir", type=Path, default=Path("/home/dev-user/code/oss/relar/benchmarks/local/base45-reference-thinlto-dev"))
    args = parser.parse_args()
    if args.workers < 1 or args.timeout < 1:
        parser.error("workers and timeout must be positive")
    Validation(args).run()


if __name__ == "__main__":
    main()
