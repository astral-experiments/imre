"""Record clean-source checks/builds used by the final decoder evidence."""
import hashlib,json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('/home/dev-user/code/oss/imre')
OUT=Path('/tmp/imre-decoder-build-validation')
OUT.mkdir(exist_ok=False)
WRAPPER='/tmp/imre-cargo.sh'
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def sources():
    paths=[*(ROOT/n for n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml')),*sorted((ROOT/'crates').rglob('*.rs')),*sorted((ROOT/'crates').rglob('Cargo.toml'))]
    return {str(p.relative_to(ROOT)):sha(p) for p in paths}
def now(): return datetime.now(timezone.utc).isoformat()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
before=sources()
commands=[
 ('format',['sh',WRAPPER,'fmt','--all','--check']),
 ('clippy',['sh',WRAPPER,'clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
 ('unit',['sh',WRAPPER,'test','--workspace','--locked']),
 ('integrated',['sh',WRAPPER,'build','--workspace','--profile','imre-integrated','--config','profile.imre-integrated.inherits="release"','--locked']),
 ('thinlto',['env','RUSTFLAGS=-Clinker-plugin-lto','sh',WRAPPER,'build','-p','imre-runtime','--profile','imre-truthiness-lto','--config','profile.imre-truthiness-lto.inherits="release"','--locked']),
 ('asan',['env','RUSTC_BOOTSTRAP=1','RUSTFLAGS=-Zsanitizer=address -Cforce-frame-pointers=yes','sh',WRAPPER,'build','-p','imre-runtime','--target','x86_64-unknown-linux-gnu','--profile','imre-truthiness-asan','--config','profile.imre-truthiness-asan.inherits="release"','--locked'])]
record={'revision':revision,'dirty':False,'started_at':now(),'source_sha256':before,'wrapper_sha256':sha(Path(WRAPPER)),'wrapper_contents':Path(WRAPPER).read_text(),'commands':[]}
for label,command in commands:
    print('Starting '+label,flush=True)
    item={'label':label,'command':command,'started_at':now()}
    start=time.monotonic()
    with (OUT/(label+'.stdout')).open('wb') as out,(OUT/(label+'.stderr')).open('wb') as err:
        result=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,timeout=1200)
    item.update(finished_at=now(),seconds=time.monotonic()-start,returncode=result.returncode)
    for stream in ('stdout','stderr'):
        path=OUT/(label+'.'+stream);item[stream]={'path':str(path),'sha256':sha(path)}
    record['commands'].append(item)
    (OUT/'index.json').write_text(json.dumps(record,indent=2)+'\n')
    assert result.returncode==0,(label,str(OUT/(label+'.stderr')))
    assert sources()==before,'source changed during checks/builds'
    print('Passed '+label,flush=True)
artifacts={
 'compiler':Path('/home/dev-user/.cache/imre/target/imre-integrated/imre'),
 'normal_runtime':Path('/home/dev-user/.cache/imre/target/imre-integrated/libimre_runtime.a'),
 'thinlto_runtime':Path('/home/dev-user/.cache/imre/target/imre-truthiness-lto/libimre_runtime.a'),
 'asan_runtime':Path('/home/dev-user/.cache/imre/target/x86_64-unknown-linux-gnu/imre-truthiness-asan/libimre_runtime.a')}
record.update(completed_at=now(),input_guards_passed=sources()==before,artifacts={name:{'path':str(path),'sha256':sha(path)}for name,path in artifacts.items()})
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
(OUT/'index.json').write_text(json.dumps(record,indent=2)+'\n')
print(OUT/'index.json',flush=True)
