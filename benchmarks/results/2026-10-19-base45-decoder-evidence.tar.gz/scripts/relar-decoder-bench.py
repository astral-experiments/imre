"""Run the final comparison families sequentially on a quiet pinned CPU."""

import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dev-user/code/oss/relar')
PYTHON = '/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
FROZEN = Path('/tmp/relar-decoder-frozen')
LLD = '/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT).strip()
for mode in ('normal', 'thinlto', 'sustained'):
    thin = mode != 'normal'
    reference = ROOT / 'benchmarks/local' / ('base45-reference-thinlto-dev' if thin else 'base45-reference-dev')
    output = Path('/tmp/relar-decoder-' + mode + '.json')
    assert not output.exists()
    command = [PYTHON, '-I', '-B', str(ROOT / 'benchmarks/base45_benchmark.py'),
               '--compiler', str(FROZEN / 'relar'),
               '--runtime', str(FROZEN / ('thinlto_runtime.a' if thin else 'normal_runtime.a')),
               '--clang', 'clang-18', '--python', PYTHON,
               '--rust', str(reference / 'base45-reference'),
               '--artifact-dir', str(ROOT / 'benchmarks/local' / ('base45-decoder-' + mode)),
               '--output', str(output), '--cpu', '0',
               '--samples', '20' if mode == 'sustained' else '24',
               '--warmups', '2' if mode == 'sustained' else '6']
    if thin:
        command += ['--target', 'x86_64-unknown-linux-gnu', '--lto-linker', LLD]
    if mode == 'sustained':
        command += ['--native-only', '--operations', 'encode', 'decode-bytes', 'decode-text', '--batch-bytes', '67108864']
    print('Starting ' + mode, flush=True)
    with output.with_suffix('.log').open('w') as log:
        log.write(json.dumps(command) + '\n')
        with subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True) as process:
            for line in process.stdout:
                log.write(line)
                log.flush()
                print(line, end='', flush=True)
            assert process.wait() == 0, mode
    record = json.loads(output.read_text())
    assert record['input_guards_passed'] and not record['dirty']
    print('Completed ' + mode + ': ' + str(output), flush=True)
