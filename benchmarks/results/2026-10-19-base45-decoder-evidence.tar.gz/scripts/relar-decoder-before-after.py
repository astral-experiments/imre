"""Balanced same-session comparison of the previous and optimized ThinLTO codecs."""

import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone
from types import SimpleNamespace

ROOT = Path('/home/dev-user/code/oss/relar')
sys.path.insert(0, str(ROOT / 'benchmarks'))
from base45_benchmark import measure, shared


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


paths = {
    'previous': Path('/tmp/relar-string-reuse-thinlto.json'),
    'relar': Path('/tmp/relar-decoder-thinlto.json'),
}
records = {name: json.loads(path.read_text()) for name, path in paths.items()}
binaries = {}
protected = {str(path): sha(path) for path in paths.values()}
for path in (Path(__file__), Path(sys.executable).resolve()):
    protected[str(path)] = sha(path)
for name, record in records.items():
    assert record['input_guards_passed'] and record['thinlto'] and not record['dirty']
    command = record['compile_command']
    binary = Path(command[command.index('-o') + 1])
    assert sha(binary) == record['binary_sha256']
    binaries[name] = binary
    protected[str(binary)] = sha(binary)
assert records['previous']['upstream'] == records['relar']['upstream']
for name in ('codec', 'driver', 'python'):
    assert records['previous']['source_and_tool_sha256'][name] == records['relar']['source_and_tool_sha256'][name], name
for name in ('base45_benchmark.py', 'base45_validate.py', 'benchmark.py'):
    path = ROOT / 'benchmarks' / name
    protected[str(path)] = sha(path)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT).strip()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert revision == records['relar']['revision']
directory = Path('/tmp/relar-decoder-before-after')
directory.mkdir(exist_ok=False)
output = Path('/tmp/relar-decoder-before-after.json')
assert not output.exists()
commands = {name: [str(path)] for name, path in binaries.items()}
cpu = shared.pin_cpu(0)
assert cpu['affinity'] == [0], cpu
result = {
    'schema': 1,
    'at': datetime.now(timezone.utc).isoformat(),
    'revision': revision,
    'dirty': False,
    'method': 'Same-session whole-process timing with the shared Base45 harness, CPU0, 2MiBraw/process, 20balancedAB/BA samples and2warmups. Sources, validated inputs, checksum and full outputs are identical; only the retained native executable changes. Preparation and verification are outside the clock.',
    'cpu': cpu,
    'samples': 20,
    'warmups': 2,
    'batch_bytes': 2097152,
    'engine_orders': list(itertools.permutations(commands)),
    'measured_engines': list(commands),
    'benchmark_records': {name: {'path': str(paths[name]), 'sha256': sha(paths[name]), 'revision': record['revision'], 'binary': str(binaries[name]), 'binary_sha256': record['binary_sha256']} for name, record in records.items()},
    'protected_sha256': protected,
    'workloads': [],
}
for workload in records['relar']['workloads']:
    prior = next(item for item in records['previous']['workloads'] if item['label'] == workload['label'])
    for name in ('input_base64', 'expected_stdout', 'expected_output_sha256', 'expected_output_bytes', 'repetitions'):
        assert workload[name] == prior[name], (workload['label'], name)
    measured = measure(workload, commands, directory / workload['label'], SimpleNamespace(samples=20, warmups=2, cpu=0, timeout=60))
    # The input workload already contains the three-engine family's measurements.
    # measure replaces gates/phases/summaries; retain only ratios for this control.
    for key in list(measured):
        if '_over_' in key:
            del measured[key]
    measured['previous_over_relar'] = measured['summary']['previous']['median_seconds'] / measured['summary']['relar']['median_seconds']
    result['workloads'].append(measured)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(workload['label'], measured['previous_over_relar'], flush=True)
assert all(sha(Path(path)) == digest for path, digest in protected.items())
result['input_guards_passed'] = True
result['completed_at'] = datetime.now(timezone.utc).isoformat()
output.write_text(json.dumps(result, indent=2) + '\n')
