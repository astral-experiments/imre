"""Refresh the Base45 guides from audited final records after evidence packaging."""
import json
import statistics
from pathlib import Path

ROOT = Path('/home/dev-user/code/oss/imre')
record = json.loads(Path('/tmp/imre-decoder-sustained.json').read_text())
control = json.loads(Path('/tmp/imre-decoder-before-after.json').read_text())
assert json.loads(Path('/tmp/imre-decoder-audit.json').read_text())['passed']
assert json.loads(Path('/tmp/imre-decoder-packaging-verification.json').read_text())['passed']

def ratios(data, numerator, denominator):
    return [statistics.median(row[numerator]['elapsed_ns'] for row in work['samples']) / statistics.median(row[denominator]['elapsed_ns'] for row in work['samples']) for work in data['workloads'] if work['operation'].startswith('decode')]

gaps = ratios(record, 'imre', 'rust')
speedups = ratios(control, 'previous', 'imre')
summary = f"In sustained 64 MiB batches, ThinLTO decoding takes {min(gaps):.2f}–{max(gaps):.2f}× Rust's time. A separate same-session comparison using 2 MiB batches measures a {min(speedups):.2f}–{max(speedups):.2f}× speedup over the previous Imre executable. The upstream codec and Rust reference remain unchanged. Bulk dictionary gathers, guarded integer loops, and bounded list-buffer reuse remove the largest measured allocation and CPU costs; intermediate Python containers still leave a gap with Rust. The report retains all samples, correctness checks, CPU/allocation profiles, and independent audits."
example = ROOT / 'examples/base45_codec/README.md'
s = example.read_text()
old = "The [owned string append report](../../benchmarks/results/2026-10-19-base45-string-reuse.md) compares"
assert old in s
s = s.replace(old, "The [decoder optimization report](../../benchmarks/results/2026-10-19-base45-decoder.md) records the latest native comparison. " + summary + "\n\nThe earlier [owned string append report](../../benchmarks/results/2026-10-19-base45-string-reuse.md) compares", 1)
s = s.replace("ThinLTO decoding still takes 27–32× Rust's time.", "At that milestone, ThinLTO decoding took 27–32× Rust's time.")
s = s.replace('For sustained encoder comparisons, increase the repeated work and time only the native engines:', 'For sustained native comparisons, increase the repeated work and time only the native engines:')
s = s.replace('--native-only --operations encode --batch-bytes 67108864', '--native-only --operations encode decode-bytes decode-text --batch-bytes 67108864 \\\n  --samples 20 --warmups 2')
s = s.replace('benchmarks/local/base45-native-encode', 'benchmarks/local/base45-native')
example.write_text(s)
index = ROOT / 'benchmarks/README.md'
s = index.read_text()
heading = '## Unchanged Base45 codec\n\n'
assert heading in s
s = s.replace(heading, heading + 'The [decoder optimization report](results/2026-10-19-base45-decoder.md) records the latest comparison. ' + summary + '\n\n', 1)
s = s.replace("Decoding remains 27–32× Rust's time.", "At that milestone, decoding took 27–32× Rust's time.")
s = s.replace('Use `--native-only --operations encode` with `--rust` for an encoder-only Imre/Rust comparison that retains CPython validation.', 'Use `--native-only --operations encode decode-bytes decode-text` with `--rust` for a native comparison that retains CPython validation; select fewer operations when only one path is relevant.')
index.write_text(s)
print('Updated the Base45 example and benchmark guides')
