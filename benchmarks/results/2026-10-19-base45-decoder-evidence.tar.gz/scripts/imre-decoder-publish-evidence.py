"""Package frozen Base45 evidence without running builds, programs, or profilers."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


ROOT = Path('/home/dev-user/code/oss/imre')
RESULTS = ROOT / 'benchmarks/results'
PREFIX = '2026-10-19-base45-decoder'
MEASURED = '7c1e378625d6760b30e68025fe2299b29287cedc'
TMP = Path('/tmp')
VALIDATION = TMP / 'imre-decoder-final-validation-v3'
FILES = {}
MODES = {}
ORIGINALS = {}
EXTERNAL = {}
PUBLIC = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'sha256': value, 'bytes': path.stat().st_size}


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def read(path):
    return json.loads(path.read_text())


def add(name, data, mode=0o644):
    assert name not in FILES, name
    assert not name.startswith('/') and '..' not in Path(name).parts, name
    assert not data.startswith((b'\x7fELF', b'!<arch>\n', b'!<thin>\n')), name
    FILES[name] = data
    MODES[name] = mode


def external(path, reason, expected=None):
    path = path.resolve(strict=True)
    actual = identity(path)
    if expected is not None:
        assert actual['sha256'] == expected, path
    item = EXTERNAL.setdefault(str(path), {**actual, 'reasons': []})
    assert {key: item[key] for key in actual} == actual
    if reason not in item['reasons']:
        item['reasons'].append(reason)


def retain(name, path):
    path = path.resolve(strict=True)
    with path.open('rb') as stream:
        magic = stream.read(8)
    if magic.startswith((b'\x7fELF', b'!<arch>\n', b'!<thin>\n')):
        external(path, f'Native artifact excluded from archive member {name}')
        return
    data = path.read_bytes()
    ORIGINALS[str(path)] = {'sha256': digest(data), 'bytes': len(data)}
    add(name, data)


def tree(prefix, directory):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            retain(f'{prefix}/{path.relative_to(directory)}', path)


def snapshot(revision, paths, prefix):
    archive = subprocess.run(
        ['git', 'archive', '--format=tar', revision, '--', *paths],
        cwd=ROOT, capture_output=True, check=True,
    ).stdout
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for member in tar:
            if member.isdir():
                continue
            assert member.isfile(), member.name
            add(f'{prefix}/{member.name}', tar.extractfile(member).read(), member.mode)


def public(name, data):
    target = f'{PREFIX}-{name}'
    assert target not in PUBLIC
    PUBLIC[target] = data


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--validation', type=Path, default=VALIDATION)
    args = parser.parse_args()
    validation_directory = args.validation.resolve(strict=True)
    assert ROOT.resolve() == ROOT
    common = subprocess.run(['git', 'rev-parse', '--git-common-dir'], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
    build_path = TMP / 'imre-decoder-frozen/build.json'
    build = read(build_path)
    assert build['source_matches_revision'] and build['input_guards_passed']
    assert build['revision'] == MEASURED and not build['worktree_status_at_capture']
    records = {}
    for name in ('normal', 'thinlto', 'sustained', 'before-after'):
        path = TMP / f'imre-decoder-{name}.json'
        retain(f'records/{name}.json', path)
        value = records[name] = read(path)
        assert value['input_guards_passed'] and value['revision'] == MEASURED and value['dirty'] is False
        raw = FILES[f'records/{name}.json']
        compressed = gzip.compress(raw, mtime=0)
        assert gzip.decompress(compressed) == raw
        public(f'{name}.json.gz', compressed)
    for name, path in (
        ('build', build_path),
        ('build-validation', TMP / 'imre-decoder-build-validation/index.json'),
        ('audit', TMP / 'imre-decoder-audit.json'),
        ('profile', TMP / 'imre-decoder-final-profile/summary.json'),
        ('profile-comparison', TMP / 'imre-decoder-profile-comparison.json'),
        ('profile-hotspots', TMP / 'imre-decoder-final-hotspots.json'),
        ('profile-audit', TMP / 'imre-decoder-profile-audit.json'),
        ('validation', validation_directory / 'index.json'),
    ):
        retain(f'records/{name}.json', path)
        public(f'{name}.json', FILES[f'records/{name}.json'])
    audit = read(TMP / 'imre-decoder-audit.json')
    profile_audit = read(TMP / 'imre-decoder-profile-audit.json')
    assert audit['passed'] and profile_audit['passed']
    assert audit['build_manifest']['sha256'] == digest(FILES['records/build.json'])
    assert audit['script_sha256'] == identity(TMP / 'imre-decoder-audit.py')['sha256']
    assert profile_audit['script_sha256'] == identity(TMP / 'imre-decoder-profile-audit.py')['sha256']
    for name in ('normal', 'thinlto', 'sustained'):
        assert audit['records'][name]['sha256'] == digest(FILES[f'records/{name}.json'])
    assert audit['before_after']['sha256'] == digest(FILES['records/before-after.json'])
    hotspots = json.loads(FILES['records/profile-hotspots.json'])
    assert hotspots['audit_sha256'] == digest(FILES['records/profile-audit.json'])
    assert hotspots['current_summary_sha256'] == digest(FILES['records/profile.json'])
    assert hotspots['timed_binary_sha256'] == records['thinlto']['binary_sha256']
    assert hotspots['decoder_exclusive_instructions'] == sum(region['exclusive_instructions'] for region in hotspots['regions']) + hotspots['remaining_decoder_exclusive_instructions']
    assert sum(region['exclusive_instructions'] for region in hotspots['native_loop_subregions']) == hotspots['regions'][0]['exclusive_instructions']
    for region in hotspots['regions'] + hotspots['native_loop_subregions']:
        assert region['fraction_of_process'] == region['exclusive_instructions'] / hotspots['total_process_instructions']
    current_profile_manifest = read(TMP / 'imre-decoder-final-profile/manifest.json')
    profile_hashes = {item['sha256'] for item in current_profile_manifest['files'].values()}
    assert hotspots['decoder_attribution_sha256'] in profile_hashes
    assert hotspots['decoder_assembly_sha256'] in profile_hashes
    comparison = json.loads(FILES['records/profile-comparison.json'])
    assert comparison['passed']
    assert comparison['audit_sha256'] == digest(FILES['records/profile-audit.json'])
    assert comparison['audit_script_sha256'] == profile_audit['script_sha256']
    assert comparison['comparison'] == profile_audit['comparison']
    for name, directory, timing in (
        ('before', TMP / 'imre-decoder-baseline-profile', TMP / 'imre-string-reuse-thinlto.json'),
        ('current', TMP / 'imre-decoder-final-profile', TMP / 'imre-decoder-thinlto.json'),
    ):
        assert profile_audit[name]['passed']
        assert profile_audit[name]['timing_sha256'] == identity(timing)['sha256']
        assert comparison[f'{name}_timing_sha256'] == profile_audit[name]['timing_sha256']
        for item in ('summary', 'manifest'):
            expected = identity(directory / f'{item}.json')['sha256']
            assert profile_audit[name][f'{item}_sha256'] == expected
            assert comparison[f'{name}_{item}_sha256'] == expected

    names = subprocess.run(['git', 'ls-tree', '-r', '--name-only', MEASURED], cwd=ROOT, capture_output=True, text=True, check=True).stdout.splitlines()
    names = [name for name in names if not name.startswith('benchmarks/results/')]
    snapshot(MEASURED, names, 'source')
    for name, expected in build['source_sha256'].items():
        assert digest(FILES[f'source/{name}']) == expected, name
    add('source-provenance.json', encoded({
        'measured_source_revision': MEASURED, 'compiler_source_revision': MEASURED,
        'source_files': len(names), 'compiler_source_files': len(build['source_sha256']),
        'compiler_source_matches_measured_snapshot': True,
        'selection': 'Every file tracked at the clean measured commit except benchmarks/results historical evidence; complete source, tests, fixtures, manifests and licenses are included.',
        'checkout': str(ROOT), 'git_common_directory': str((ROOT / common).resolve()),
    }))
    for group in ('artifacts', 'tools'):
        for item in build[group].values():
            external(Path(item['path']), f'Frozen build {group} dependency', item['sha256'])
    build_validation = read(TMP / 'imre-decoder-build-validation/index.json')
    assert build_validation['revision'] == MEASURED and build_validation['input_guards_passed']
    assert [item['label'] for item in build_validation['commands']] == ['format', 'clippy', 'unit', 'integrated', 'thinlto', 'asan']
    for command in build_validation['commands']:
        assert command['returncode'] == 0
        for stream in ('stdout', 'stderr'):
            assert identity(Path(command[stream]['path']))['sha256'] == command[stream]['sha256']
    unit = next(command for command in build_validation['commands'] if command['label'] == 'unit')
    unit_counts = [int(value) for value in re.findall(r'test result: ok\. (\d+) passed', Path(unit['stdout']['path']).read_text())]
    assert sum(unit_counts) == 143 and 58 in unit_counts and 85 in unit_counts
    tree('build-validation', TMP / 'imre-decoder-build-validation')

    for name in ('normal', 'thinlto', 'sustained'):
        record = records[name]
        command = record['compile_command']
        binary = Path(command[command.index('-o') + 1])
        llvm = Path(command[command.index('--emit-llvm') + 1])
        external(binary, f'Exact timed {name} Imre executable', record['binary_sha256'])
        assert identity(llvm)['sha256'] == record['llvm_sha256']
        tree(f'timing/{name}', binary.parent)
        assert read(binary.parent / 'validation.json') == record['validation']
        retain(f'timing/{name}.log', TMP / f'imre-decoder-{name}.log')
    tree('timing/before-after', TMP / 'imre-decoder-before-after')
    tree('audit-attempts', TMP / 'imre-decoder-audit-attempts')
    retain('timing/before-after.log', TMP / 'imre-decoder-before-after.log')

    validation = read(validation_directory / 'index.json')
    assert validation['status'] == 'passed' and validation['input_guards_passed']
    assert validation['expected_jobs'] == len(validation['jobs']) == 81
    assert all(job['status'] == 'passed' for job in validation['jobs'].values())
    assert validation['base45_native_variants'] == 5
    assert validation['frozen_build']['revision'] == MEASURED
    assert validation['frozen_build']['sha256'] == digest(FILES['records/build.json'])
    for name, expected in validation['artifact_sha256'].items():
        assert identity(validation_directory / name)['sha256'] == expected, name
    for path, expected in read(Path(validation['input_manifest'])).items():
        assert identity(Path(path))['sha256'] == expected, path
    tree('validation', validation_directory)
    tree('validation-attempts/initial', TMP / 'imre-decoder-final-validation')
    tree('validation-attempts/ptrace-restricted', TMP / 'imre-decoder-final-validation-v2')
    for name in ('imre-decoder-final-matrix-launch', 'imre-decoder-final-matrix-launch-v2', 'imre-decoder-final-matrix-launch-v3'):
        directory = TMP / name
        if directory.is_dir():
            tree(f'validation-attempts/{name}', directory)
    add('validation-attempts/README.json', encoded({
        'initial_attempt': 'Interrupted after the runner rejected the successful imports harness summary wording. The imports child exited 0. The corrected runner accepts both verified summary forms; all jobs were then rerun from the same frozen binaries.',
        'ptrace_restricted_attempt': 'The second complete matrix passed every ordinary, ThinLTO, reference and application job, but all 24 ASan jobs hit LeakSanitizer\'s documented ptrace restriction. The complete successful matrix reran untraced with leak detection enabled.',
        'effective_run': str(validation_directory),
        'scope': 'Initial attempt logs are retained for transparency and excluded from final test counts.',
    }))
    add('records/validation-summary.json', encoded({
        'revision': MEASURED,
        'unit_tests': {'compiler': 58, 'runtime': 85, 'total': 143},
        'language_checks': validation['language_checks'],
        'language_checks_total': sum(validation['language_checks'].values()),
        'matrix_jobs': 81,
        'base45_variants': 5,
        'base45_per_variant': {'upstream_native_calls': 323, 'differential_cases': 289, 'compile_rejections': 2},
        'application_jobs': {name: job for name, job in validation['jobs'].items() if name.startswith('application-')},
        'application_configuration': 'ordinary O3',
        'caveats': [
            'Language counts include compile-time rejections and combine optimization levels; they are not all distinct programs.',
            'Sanitizers cover generated native code and the custom runtime; the prebuilt Rust standard library is not instrumented.',
            'The Rust reference has four recorded Unicode repr-message boundaries; Imre is checked against exact CPython messages.',
        ],
    }))
    public('validation-summary.json', FILES['records/validation-summary.json'])

    for flavor, directory, timing in (
        ('current', TMP / 'imre-decoder-final-profile', TMP / 'imre-decoder-thinlto.json'),
        ('previous', TMP / 'imre-decoder-baseline-profile', TMP / 'imre-string-reuse-thinlto.json'),
    ):
        profile = read(directory / 'summary.json')
        assert profile['complete'] and profile['guards_passed'] and len(profile['profiles']) == 24
        assert profile['benchmark_record_sha256'] == identity(timing)['sha256']
        for name, item in profile['guarded_inputs'].items():
            assert identity(Path(item['path'])) == {key: item[key] for key in ('sha256', 'bytes')}, name
            if name.startswith(('binary_', 'tool_')):
                external(Path(item['path']), f'{flavor} profile dependency {name}', item['sha256'])
        manifest = read(directory / 'manifest.json')
        actual_members = {str(path.relative_to(directory)) for path in directory.rglob('*') if path.is_file() and path != directory / 'manifest.json'}
        assert set(manifest['files']) == actual_members
        for name, expected in manifest['files'].items():
            assert identity(directory / name) == {key: expected[key] for key in ('sha256', 'bytes')}, name
        tree(f'profiles/{flavor}', directory)
    retain('profiles/hardware-perf-attempt.json', TMP / 'imre-decoder-hardware-perf-attempt.json')
    for flavor, dirname in (('normal', 'base45-reference-dev'), ('thinlto', 'base45-reference-thinlto-dev')):
        directory = ROOT / 'benchmarks/local' / dirname
        assert read(directory / 'build-record.json') == records[flavor]['rust_build_record']
        external(directory / 'base45-reference', f'Timed {flavor} Rust reference', records[flavor]['source_and_tool_sha256']['rust'])
        retain(f'rust/{flavor}-build-record.json', directory / 'build-record.json')

    script_names = ('bench', 'freeze', 'before-after', 'final-profile', 'audit', 'profile-audit', 'final-tests', 'build-validation', 'publish-evidence', 'report', 'update-guides')
    for suffix in script_names:
        path = TMP / f'imre-decoder-{suffix}.py'
        retain(f'scripts/{path.name}', path)
    retain('scripts/imre-cargo.sh', TMP / 'imre-cargo.sh')
    assert digest(FILES['scripts/imre-cargo.sh']) == build['cargo_wrapper']['sha256']
    for name, path in (
        ('thinlto.json', TMP / 'imre-string-reuse-thinlto.json'),
        ('build.json', TMP / 'imre-string-reuse-frozen/build.json'),
        ('evidence-manifest.json', RESULTS / '2026-10-19-base45-string-reuse-evidence-manifest.json'),
    ):
        retain(f'historical/{name}', path)
    historical = json.loads(FILES['historical/evidence-manifest.json'])
    assert identity(RESULTS / historical['archive'])['sha256'] == historical['archive_sha256']
    add('historical/archive-reference.json', encoded({
        'repository_path': f'benchmarks/results/{historical["archive"]}',
        'sha256': historical['archive_sha256'],
        'scope': 'The previous measured compiler/runtime source, build and correctness evidence remain in this committed archive. Fresh baseline CPU/allocation profiles are included in profiles/previous/.',
    }))
    add('external-artifacts.json', encoded({
        'policy': 'Native binaries, runtime archives, interpreters and toolchains remain external and hash-identified. Original absolute paths identify the measured environment.',
        'artifacts': EXTERNAL,
    }))
    add('original-inputs.json', encoded(ORIGINALS))
    add('PACKAGING.json', encoded({
        'script': 'scripts/imre-decoder-publish-evidence.py',
        'measured_source_revision': MEASURED, 'compiler_source_revision': MEASURED,
        'determinism': 'Sorted members, zero ownership and timestamps, zero gzip timestamp.',
        'scope': 'Clean measured source; exact build commands and logs; raw timing/correctness records; full final validation and interrupted runner attempt; generated LLVM; fresh previous/current CPU/allocation profiles; audits; Rust build provenance; reproduction scripts.',
        'reproduction': 'Original commands retain host paths. Recreate the pinned source and hash-identified tools or relocate paths to rerun. Retained binaries are excluded; build commands and flags are preserved.',
    }))
    for path, expected in ORIGINALS.items():
        assert identity(Path(path)) == expected, path
    for path, expected in EXTERNAL.items():
        assert identity(Path(path)) == {key: expected[key] for key in ('sha256', 'bytes')}, path
    tar_bytes = io.BytesIO()
    with tarfile.open(fileobj=tar_bytes, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, data in sorted(FILES.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(data), MODES[name]
            member.mtime = member.uid = member.gid = 0
            tar.addfile(member, io.BytesIO(data))
    compressed = gzip.compress(tar_bytes.getvalue(), mtime=0)
    archive_name = f'{PREFIX}-evidence.tar.gz'
    PUBLIC[archive_name] = compressed
    manifest = {
        'archive': archive_name, 'archive_sha256': digest(compressed), 'archive_bytes': len(compressed),
        'member_count': len(FILES), 'uncompressed_member_bytes': sum(map(len, FILES.values())),
        'measured_source_revision': MEASURED, 'compiler_source_revision': MEASURED,
        'files': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(FILES.items())},
        'public_artifacts': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(PUBLIC.items())},
    }
    PUBLIC[f'{PREFIX}-evidence-manifest.json'] = encoded(manifest)
    with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(FILES) and len({member.name for member in members}) == len(FILES)
        for member in members:
            assert member.isfile()
            data = tar.extractfile(member).read()
            assert data == FILES[member.name]
            assert manifest['files'][member.name] == {'bytes': len(data), 'sha256': digest(data)}
    for name, data in PUBLIC.items():
        target = RESULTS / name
        assert not target.exists() or target.read_bytes() == data, f'Refusing to replace evidence: {target}'
        target.write_bytes(data)
        assert target.read_bytes() == data
    summary = {
        'passed': True, 'archive': str(RESULTS / archive_name), 'archive_bytes': len(compressed),
        'archive_sha256': digest(compressed), 'member_count': len(FILES),
        'uncompressed_member_bytes': manifest['uncompressed_member_bytes'],
        'external_artifacts': len(EXTERNAL), 'original_files_verified': len(ORIGINALS),
        'generated_paths': [str(RESULTS / name) for name in PUBLIC],
    }
    (TMP / 'imre-decoder-packaging-verification.json').write_bytes(encoded(summary))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()


