import json
import hashlib
import statistics
from pathlib import Path

ROOT = Path('/home/dev-user/code/oss/relar')
PREFIX = '2026-10-19-base45-decoder'
records = {name: json.loads(Path(f'/tmp/relar-decoder-{name}.json').read_text()) for name in ('normal', 'thinlto', 'sustained', 'before-after')}

def stats(workload, engine):
    values = [sample[engine]['elapsed_ns'] / 1_000_000 for sample in workload['samples']]
    q1, _, q3 = statistics.quantiles(values, n=4, method='inclusive')
    return statistics.median(values), q1, q3

def cell(workload, engine):
    median, q1, q3 = stats(workload, engine)
    return f'{median:.3f} [{q1:.3f}–{q3:.3f}]'

def native_table():
    lines = ['| Operation / raw bytes per call | Relar ms [Q1–Q3] | Rust ms [Q1–Q3] | Relar / Rust |', '|---|---:|---:|---:|']
    for w in records['sustained']['workloads']:
        lines.append(f"| {w['label']} | {cell(w, 'relar')} | {cell(w, 'rust')} | {stats(w, 'relar')[0] / stats(w, 'rust')[0]:.3f}× |")
    return '\n'.join(lines)

def three_engine_table(name):
    lines = ['| Operation / raw bytes per call | Relar ms [Q1–Q3] | Rust ms [Q1–Q3] | CPython ms [Q1–Q3] | Relar / Rust | CPython / Relar |', '|---|---:|---:|---:|---:|---:|']
    for w in records[name]['workloads']:
        relar, rust, cpython = (stats(w, engine)[0] for engine in ('relar', 'rust', 'cpython'))
        lines.append(f"| {w['label']} | {cell(w, 'relar')} | {cell(w, 'rust')} | {cell(w, 'cpython')} | {relar / rust:.3f}× | {cpython / relar:.3f}× |")
    return '\n'.join(lines)

def control_table():
    lines = ['| Operation / raw bytes per call | Previous Relar ms [Q1–Q3] | Current Relar ms [Q1–Q3] | Previous / current |', '|---|---:|---:|---:|']
    for w in records['before-after']['workloads']:
        lines.append(f"| {w['label']} | {cell(w, 'previous')} | {cell(w, 'relar')} | {stats(w, 'previous')[0] / stats(w, 'relar')[0]:.3f}× |")
    return '\n'.join(lines)


def selected(record, operation=None):
    return [workload for workload in record['workloads'] if operation is None or workload['operation'] == operation]


def ratio_range(workloads, numerator, denominator):
    values = [stats(workload, numerator)[0] / stats(workload, denominator)[0] for workload in workloads]
    return f'{min(values):.2f}–{max(values):.2f}×'


def find(record, label):
    return next(workload for workload in record['workloads'] if workload['label'] == label)


def profile_metrics(record, label, engine):
    entries = [entry for entry in record['profiles'] if entry['label'] == label and entry['engine'] == engine]
    assert len(entries) == 2 and {entry['tool'] for entry in entries} == {'dhat', 'callgrind'}
    return {key: entry[key] for entry in entries for key in ('total_allocated_bytes', 'total_allocated_blocks', 'peak_live_bytes', 'instructions', 'decoder_exclusive_instructions') if key in entry}


profile = json.loads(Path('/tmp/relar-decoder-final-profile/summary.json').read_text())
baseline = json.loads(Path('/tmp/relar-decoder-baseline-profile/summary.json').read_text())
validation = json.loads(Path('/tmp/relar-decoder-final-validation-v3/index.json').read_text())
audit = json.loads(Path('/tmp/relar-decoder-audit.json').read_text())
profile_audit = json.loads(Path('/tmp/relar-decoder-profile-audit.json').read_text())
hotspots = json.loads(Path('/tmp/relar-decoder-final-hotspots.json').read_text())
build = json.loads(Path('/tmp/relar-decoder-frozen/build.json').read_text())
assert profile['complete'] and baseline['complete'] and audit['passed'] and profile_audit['passed']
assert validation['status'] == 'passed' and validation['input_guards_passed']
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

for name in ('normal', 'thinlto', 'sustained'):
    assert audit['records'][name]['sha256'] == sha(f'/tmp/relar-decoder-{name}.json')
assert audit['before_after']['sha256'] == sha('/tmp/relar-decoder-before-after.json')
assert audit['build_manifest']['sha256'] == sha('/tmp/relar-decoder-frozen/build.json')
assert audit['script_sha256'] == sha('/tmp/relar-decoder-audit.py')
assert profile_audit['script_sha256'] == sha('/tmp/relar-decoder-profile-audit.py')
for name, directory, timing in (
    ('before', '/tmp/relar-decoder-baseline-profile', '/tmp/relar-string-reuse-thinlto.json'),
    ('current', '/tmp/relar-decoder-final-profile', '/tmp/relar-decoder-thinlto.json'),
):
    assert profile_audit[name]['passed']
    assert profile_audit[name]['timing_sha256'] == sha(timing)
    for item in ('summary', 'manifest'):
        assert profile_audit[name][f'{item}_sha256'] == sha(Path(directory) / f'{item}.json')
assert validation['frozen_build']['sha256'] == sha('/tmp/relar-decoder-frozen/build.json')
assert hotspots['audit_sha256'] == sha('/tmp/relar-decoder-profile-audit.json')
assert hotspots['current_summary_sha256'] == sha('/tmp/relar-decoder-final-profile/summary.json')
assert hotspots['timed_binary_sha256'] == records['thinlto']['binary_sha256']
hotspot_rows = [(region['region'], region['exclusive_instructions'], 'Exclusive decoder region') for region in hotspots['regions']]
helpers = hotspots['top_called_helpers']
hotspot_rows.append(('Gather mapped integers', sum(row['inclusive_instructions'] for row in helpers if 'gather_str_int' in row['callee']), 'Inclusive helper'))
hotspot_rows.append(('Release both integer lists', sum(row['inclusive_instructions'] for row in helpers if 'Rc<relar_runtime::List>' in row['callee']), 'Inclusive helper calls'))
hotspot_rows.sort(key=lambda row: row[1], reverse=True)
hotspot_table = '\n'.join(['| Remaining work | Process instructions | Attribution |', '|---|---:|---|'] + [f'| {name} | {count / hotspots["total_process_instructions"]:.2%} | {scope} |' for name, count, scope in hotspot_rows])
source_load_share = hotspots['native_loop_subregions'][0]['fraction_of_process']
decode_sustained = [w for w in records['sustained']['workloads'] if w['operation'].startswith('decode')]
decode_control = [w for w in records['before-after']['workloads'] if w['operation'].startswith('decode')]
decode_thin = [w for w in records['thinlto']['workloads'] if w['operation'].startswith('decode')]
native_gap = ratio_range(decode_sustained, 'relar', 'rust')
before_after_speedup = ratio_range(decode_control, 'previous', 'relar')
python_speedup = ratio_range(decode_thin, 'cpython', 'relar')
large = find(records['sustained'], 'decode-bytes-16384')
large_gap = stats(large, 'relar')[0] / stats(large, 'rust')[0]
old_profile = profile_metrics(baseline, 'decode-bytes-16384', 'relar')
new_profile = profile_metrics(profile, 'decode-bytes-16384', 'relar')
rust_profile = profile_metrics(profile, 'decode-bytes-16384', 'rust')
profile_lines = ['| Operation / raw bytes per call / engine | Allocated bytes | Allocation blocks | Peak live bytes | Instructions |', '|---|---:|---:|---:|---:|']
for operation in ('decode-bytes', 'decode-text'):
    for size in (64, 1024, 16384):
        label = f'{operation}-{size}'
        for record, engine, display in ((baseline, 'relar', 'previous Relar'), (profile, 'relar', 'current Relar'), (profile, 'rust', 'Rust')):
            p = profile_metrics(record, label, engine)
            profile_lines.append(f"| {label} / {display} | {p['total_allocated_bytes']:,} | {p['total_allocated_blocks']:,} | {p['peak_live_bytes']:,} | {p['instructions']:,} |")
profile_table = '\n'.join(profile_lines)
phase_counts = {phase: sum(len(row['order']) for record in records.values() for workload in record['workloads'] for row in workload[phase]) for phase in ('samples', 'warmups')}
gates = sum(len(workload['gates']) for record in records.values() for workload in record['workloads'])
language_checks = sum(validation['language_checks'].values())
peak_change = (new_profile['peak_live_bytes'] / old_profile['peak_live_bytes'] - 1) * 100
decoder_fraction = new_profile['decoder_exclusive_instructions'] / new_profile['instructions'] * 100
report = f'''# Reducing the native Base45 decoding gap

With python-base45 unchanged, decoding is **{before_after_speedup} faster than the previous Relar executable** in a same-session comparison. Sustained decoding now takes **{native_gap} Rust's time**; the 16 KiB bytes case takes **{large_gap:.2f}×**. This substantially narrows the gap, but does not establish Rust parity. ThinLTO decoding is **{python_speedup} faster than CPython** in the shorter three-engine comparisons.

The [compiler/runtime change](https://github.com/viarius-experiments/relar/pull/51) follows PR #50 in GitHub Stack 4. The current compiler and runtime were built from clean commit **{build['revision']}**. Application, harness, and Rust reference source bytes match that revision; the unchanged Rust binaries were retained from their recorded earlier builds. The [previous encoder report](2026-10-19-base45-string-reuse.md) and its evidence remain intact.

## Sustained comparison with Rust

Each process handles **64 MiB of raw data** through repeated calls on the indicated payload. Values are median milliseconds with inclusive quartiles in brackets. **Relar / Rust is a time ratio: lower is better.** Both native executables use ThinLTO, with matched LLVM import and inline budgets of 1,000. Twenty balanced AB/BA measured rounds follow two balanced warmup rounds.

{native_table()}

Encoding is included as a regression control. These longer native batches reduce startup's share of each sample and are the primary assessment of the remaining Rust gap. The [Rust reference](../reference/base45_codec/README.md) is unchanged: a fixed lookup table, preallocated output, direct arithmetic, complete output and checksum checks, and black-box barriers around repeated work. Both implementations handle identical inputs and repetition counts. Their storage strategies differ: the unchanged Python decoder materializes integer lists, while Rust streams lookup and output production and defers range errors to preserve lookup-error priority.

## Same-session comparison with previous Relar

Retained previous and current ThinLTO executables were interleaved on CPU 0 with identical inputs and **2 MiB of raw data per process**. Twenty balanced AB/BA measured rounds follow two warmup rounds. The codec and driver hashes match; every complete result and checksum is checked. Only the native executable changes within this control.

{control_table()}

This is the direct before/after measurement. Comparing separately collected historical medians would mix the compiler change with host conditions. The new Rust comparisons independently establish the remaining native gap.

## Ordinary linking: Relar, Rust, and CPython

Each process handles **2 MiB of raw data**. Six balanced warmup rounds precede 24 measured rounds covering all six engine orders four times. **CPython / Relar is a speedup ratio: higher is better.**

{three_engine_table('normal')}

## ThinLTO: Relar, Rust, and CPython

{three_engine_table('thinlto')}

Ordinary and ThinLTO families ran separately, each with interleaved baselines. They compare engines within each family; they are not a randomized measurement of ThinLTO's isolated effect. Quartiles describe observed spread, not confidence intervals.

## Bottlenecks and changes

The previous CPU and allocation profiles showed repeated character-object allocation, dictionary hashing, dynamic integer work, and temporary-list storage dominating decoding. The optimizations are general compiler/runtime transformations; there is no Base45 intrinsic or source rewrite.

- Exact string-to-integer-dictionary comprehensions become bulk gathers. A lazy ASCII cache stays synchronized with dictionary insertion, replacement, and deletion. Unicode keys and arbitrary-precision values retain the general path. Direct bytes decoding validates the entire UTF-8 input at the original evaluation point, then gathers without allocating an intermediate string.
- Eligible leaf range loops get a guarded native-integer version. The compiler checks actual list contents and excludes input/output aliases at runtime. It preserves the original checked loop as fallback, including BigInt values, exceptions, loop targets, break, continue, and else. Proven power-of-two division and modulo become shifts and masks.
- Known-size list producers reserve bounded capacity, and a thread-local pool reuses at most two empty integer-list buffers, retaining at most **512 KiB per thread**. Immediate-integer cleanup and conversion to bytes use vectorizable checks. Adjacent appends share a capacity check only when both values and the common list receiver are already evaluated locals.

The guards establish the facts used by LLVM. They do not assume type annotations or apparently constant dictionaries prevent mutation. Fast paths preserve error ordering: malformed UTF-8 still wins before character lookup, and missing characters are detected before numeric range failures.

## Allocation and CPU-work profiles

Fresh, separate DHAT and Callgrind runs compare the previous executable, current executable, and unchanged Rust reference. Each process handles **64 KiB of raw data**: 1,024 calls at 64 bytes, 64 calls at 1 KiB, or four calls at 16 KiB. Every profile checks the complete output and checksum and records exact input, source, binary, tool, and command identities.

{profile_table}

For 16 KiB bytes decoding, cumulative allocated bytes fall from **{old_profile['total_allocated_bytes']:,} to {new_profile['total_allocated_bytes']:,}** ({old_profile['total_allocated_bytes'] / new_profile['total_allocated_bytes']:.1f}× lower), allocation blocks fall from **{old_profile['total_allocated_blocks']:,} to {new_profile['total_allocated_blocks']:,}**, and instrumented instructions fall from **{old_profile['instructions']:,} to {new_profile['instructions']:,}** ({old_profile['instructions'] / new_profile['instructions']:.1f}× lower). Peak live allocation changes from **{old_profile['peak_live_bytes']:,} to {new_profile['peak_live_bytes']:,} bytes** ({peak_change:+.1f}%). Cumulative allocation is not peak memory or RSS; bounded buffer retention trades some idle memory for fewer allocations across calls.

The remaining gap is principally the work still expressed by the Python algorithm: gather an integer list, prove its element range, build another integer list, validate/copy it into bytes, and manage those objects. Rust produces output directly. The named decoder accounts for **{decoder_fraction:.1f}% of current process instructions** in the large-bytes profile; current Relar still executes **{new_profile['instructions'] / rust_profile['instructions']:.2f}× Rust's instructions** and requests **{new_profile['total_allocated_bytes'] / rust_profile['total_allocated_bytes']:.2f}× its cumulative allocation**. The next large opportunity appears to be eliminating intermediate containers or fusing their consumers while preserving eager evaluation and error priority.

The [reviewed assembly breakdown]({PREFIX}-profile-hotspots.json) identifies the largest remaining regions in the 16 KiB bytes case:

{hotspot_table}

The checked source loads and three-read branch account for **{source_load_share:.2%} of process instructions**, as a subset of the native loop above. Decoder regions are disjoint self-cost ranges; helper rows include their callees. These are instruction shares, not CPU-time percentages.

Hardware perf events were unavailable on this host. Callgrind reports instrumented guest instructions, not hardware cycles or CPU-time percentages. Profiles include startup, imports, file I/O, and checksum work and ran separately from wall-clock timing. Decoder attribution resolves the named Python function through its LLVM body and native symbols, then checks every recorded instruction address against retained disassembly.

## Semantics and validation

The codec, py.typed, upstream tests, and BSD-2-Clause license match all four hashes in the [upstream manifest](../../examples/base45_codec/UPSTREAM.json), pinned to [python-base45 commit 5f49a519](https://github.com/kirei/python-base45/tree/5f49a519c3884a4fbc4c58c5c8f1fa25d7046020). The separate upstream argparse application is outside this example.

At each of five configurations—ordinary O0/O3, ThinLTO O3, and AddressSanitizer/LeakSanitizer O0/O1—the unchanged upstream methods cover **323 native calls**, followed by **289 CPython differential cases** and **two compile-time type rejections**. Those last two reject upstream calls passing integer 42 to typed APIs; they are not runtime TypeError tests. Checks cover full values, exact error messages, causes, suppression, unchanged output on failure, malformed/odd/empty inputs, Unicode, all bytes, alias mutation, and recovery.

All **143 Rust unit tests**, strict workspace Clippy, formatting, and focused Ruff checks pass. The full matrix passes **81 jobs**, including **{language_checks:,} non-Base45 language checks** across the five configurations. All six existing application oracle suites pass at ordinary O3. Each retained Rust Base45 reference passes **295 checks**. Four recorded Unicode repr boundaries permit different character quoting in Rust while still checking error category, cause, suppression and unchanged output; Relar retains exact CPython message checking. Sanitizers cover generated code and the custom runtime; the prebuilt Rust standard library is uninstrumented.

The first matrix attempt was interrupted after its temporary runner misparsed the successful imports-suite summary; that child exited zero. The second attempt passed all ordinary, ThinLTO, reference and application jobs, but LeakSanitizer could not inspect processes under the sandbox's ptrace tracing. The complete successful matrix reran outside tracing with leak detection enabled and the same frozen binaries. Both earlier attempts are retained and excluded from final counts. The [validation index]({PREFIX}-validation.json), [summary]({PREFIX}-validation-summary.json), and [build/check record]({PREFIX}-build-validation.json) retain exact commands, statuses and provenance.

## Measurement and evidence

Timing ran on October 19, 2026, on an AMD EPYC-Milan host pinned to CPU 0, outside tracing. CPython 3.14.5 has PGO and LTO enabled, the GIL enabled, and JIT disabled. Relar uses Clang 18 at O3; the Rust reference uses Ohm 1.98.1 and LLVM 22.1.8. ThinLTO uses LLVM 22 LLD and linker-plugin runtime bitcode. The [frozen build record]({PREFIX}-build.json) identifies exact tools, source, commands, archives and executables. Source was committed before the recorded builds.

Timing includes startup, imports, one input read, all repeated codec calls, checksum work, one complete final output write, and exit. Compilation, preparation, hashing and verification are outside the clock. OS caches are warm, output is not fsynced, and task-owned builds, tests and profiles were stopped during timing. Host frequency and unrelated shared-host activity remain uncontrolled. Timed inputs have valid even lengths; separate correctness checks cover other cases.

Across the four records, **{phase_counts['samples']:,} measured executions, {phase_counts['warmups']:,} warmups, and {gates} gates** retain exit status, stdout/checksum, stderr, and complete output hashes. The [independent benchmark audit]({PREFIX}-audit.json) recomputes all statistics and verifies balanced orders, oracle results, and source/tool/binary identities. The [profile audit]({PREFIX}-profile-audit.json) independently checks all **{len(profile['profiles']) + len(baseline['profiles'])} profiles**, raw allocation/instruction totals, full outputs, manifests and decoder attribution.

Raw records: [ordinary linking]({PREFIX}-normal.json.gz), [ThinLTO]({PREFIX}-thinlto.json.gz), [sustained native comparisons]({PREFIX}-sustained.json.gz), and [previous/current control]({PREFIX}-before-after.json.gz). The [profile summary]({PREFIX}-profile.json) and [comparison]({PREFIX}-profile-comparison.json) retain detailed results.

The [evidence archive]({PREFIX}-evidence.tar.gz) and [manifest]({PREFIX}-evidence-manifest.json) contain measured source and fixtures, generated LLVM, exact build/check logs, raw timing and correctness records, previous/current profiles, disassembly, independent audits, and reproduction scripts. Native binaries, runtime archives, interpreters and toolchains remain external and hash-identified. Original commands retain host-specific paths; the [example guide](../../examples/base45_codec/README.md) and [Rust reference guide](../reference/base45_codec/README.md) provide portable entrypoints.
'''
(ROOT / 'benchmarks/results' / f'{PREFIX}.md').write_text(report)
print(f'Wrote {len(report.split())} words to {PREFIX}.md')

