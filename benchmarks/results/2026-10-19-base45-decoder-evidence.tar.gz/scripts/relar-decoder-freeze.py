"""Capture pre-existing compiler/runtime artifacts and their verified source identity.

This script does not build anything or infer when an artifact was built. Optional
build logs are retained verbatim; their own recorded source/artifact guards are
the evidence for any build-history claim.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time


ROOT = Path("/home/dev-user/code/oss/relar")
TARGET = Path("/home/dev-user/.cache/relar/target")
PYTHON = Path("/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14")
RUFF = Path("/tmp/ohm-stream-cgu-more-20261015/checkpoints/ruff-dev/0/debug/ruff")
SOURCE_FILES = {"Cargo.toml", "Cargo.lock", "rust-toolchain.toml"}


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def executable(value):
    path = Path(value) if "/" in value else Path(shutil.which(value) or value)
    path = path.absolute()
    if not path.is_file() or not os.access(path, os.X_OK):
        raise ValueError(f"not executable: {path}")
    return path


def source_paths(root):
    return sorted({*(root / name for name in SOURCE_FILES), *(root / "crates").rglob("*.rs"), *(root / "crates").rglob("Cargo.toml")})


class Capture:
    def __init__(self, args):
        self.args = args
        self.root = args.root.resolve(strict=True)
        self.destination = args.destination.absolute()
        self.commands = []
        self.environment = {**os.environ, "GIT_OPTIONAL_LOCKS": "0"}

    def command(self, label, command, *, binary=False):
        command = [str(part) for part in command]
        started = now()
        start = time.monotonic()
        result = subprocess.run(command, cwd=self.root, env=self.environment, capture_output=True, timeout=120)
        record = {
            "label": label, "command": command, "shell_display": shlex.join(command),
            "cwd": str(self.root), "started_at": started, "finished_at": now(),
            "seconds": time.monotonic() - start, "returncode": result.returncode,
            "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
            "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
            "stdout_bytes": len(result.stdout), "stderr_bytes": len(result.stderr),
            "stderr": result.stderr.decode("utf-8", "replace"),
        }
        if binary:
            record["stdout_prefix_hex"] = result.stdout[:16].hex()
            record["stdout_scope"] = "Binary output is recoverable from the guarded Git object/archive; its digest and prefix are retained instead of a duplicate copy."
        else:
            record["stdout"] = result.stdout.decode("utf-8", "replace")
        self.commands.append(record)
        if result.returncode:
            raise RuntimeError(f"{label} failed: {record['stderr']}")
        return result.stdout if binary else record["stdout"].strip()

    def selected_rust_tools(self):
        return {
            name: Path(self.command("select-" + name, ["rustup", "which", "--toolchain", "ohm", name])).resolve(strict=True)
            for name in ("cargo", "rustc")
        }

    def logs(self):
        if self.args.build_log_directory is None:
            return []
        directory = self.args.build_log_directory.resolve(strict=True)
        if self.destination.resolve().is_relative_to(directory):
            raise ValueError("capture destination cannot be inside the build-log directory")
        return sorted(path for path in directory.rglob("*") if path.is_file())

    def guard_paths(self, tools, artifacts):
        return sorted({Path(__file__).absolute(), self.args.cargo_wrapper.resolve(strict=True), *source_paths(self.root), *tools.values(), *artifacts.values(), *self.logs()})

    def archive_probe(self, name, archive, tools):
        members = self.command(name + "-members", [tools["ar"], "t", archive]).splitlines()
        runtime_members = [member for member in members if member.startswith("relar_runtime") and member.endswith(".o")]
        assert runtime_members, f"no relar_runtime members in {archive}"
        formats = []
        for index, member in enumerate(runtime_members):
            data = self.command(f"{name}-member-{index}", [tools["ar"], "p", archive, member], binary=True)
            magic = data[:4]
            kind = "elf" if magic == b"\x7fELF" else "llvm-bitcode" if magic in (b"BC\xc0\xde", b"\xde\xc0\x17\x0b") else "unknown"
            formats.append({"member": member, "format": kind, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
        expected = "llvm-bitcode" if name == "thinlto_runtime" else "elf"
        assert all(item["format"] == expected for item in formats), (name, formats)
        result = {"runtime_members": formats, "expected_format": expected}
        if name != "thinlto_runtime":
            symbols = self.command(name + "-undefined-symbols", [tools["nm"], "-u", archive])
            has_asan_init = any(line.split()[-1:] == ["__asan_init"] for line in symbols.splitlines())
            assert has_asan_init == (name == "asan_runtime"), (name, has_asan_init)
            result["references_asan_init"] = has_asan_init
        return result

    def run(self):
        started = now()
        if self.destination.exists():
            raise ValueError(f"refusing to overwrite existing capture: {self.destination}")
        revision = self.command("revision", ["git", "rev-parse", self.args.revision + "^{commit}"])
        hashes = {str(path.relative_to(self.root)): sha(path) for path in source_paths(self.root)}
        committed_paths = self.command("source-tree", ["git", "ls-tree", "-r", "--name-only", revision, "--", "crates", *sorted(SOURCE_FILES)]).splitlines()
        committed_paths = {name for name in committed_paths if name in SOURCE_FILES or name.endswith(".rs") or name.endswith("/Cargo.toml")}
        assert committed_paths == hashes.keys(), "selected source-file membership differs from revision"
        for index, (name, digest) in enumerate(hashes.items()):
            content = self.command(f"source-{index}", ["git", "show", revision + ":" + name], binary=True)
            assert hashlib.sha256(content).hexdigest() == digest, name
        tools = self.selected_rust_tools()
        sysroot = Path(self.command("rust-sysroot", ["rustc", "+ohm", "--print", "sysroot"]))
        lld_directory = sysroot / "lib/rustlib" / self.args.target / "bin"
        tools.update({
            "clang": executable(self.args.clang),
            "lto_linker": executable(str(self.args.lto_linker or lld_directory / "gcc-ld/ld.lld")),
            "rust_lld": executable(str(self.args.rust_lld or lld_directory / "rust-lld")),
            "python": executable(str(self.args.python)),
            "runner_python": executable(sys.executable),
            "ruff": executable(str(self.args.ruff)),
            "git": executable("git"),
            "rustup": executable("rustup"),
            "ar": executable("ar"),
            "nm": executable("nm"),
        })
        inputs = {
            "compiler": self.args.compiler.resolve(strict=True),
            "normal_runtime": self.args.normal_runtime.resolve(strict=True),
            "thinlto_runtime": self.args.thinlto_runtime.resolve(strict=True),
            "asan_runtime": self.args.asan_runtime.resolve(strict=True),
        }
        before = {str(path): sha(path) for path in self.guard_paths(tools, inputs)}
        assert all(before[str(self.root / name)] == digest for name, digest in hashes.items()), "selected source changed while checking its Git identity"
        self.destination.mkdir()
        artifacts = {}
        for name, source in inputs.items():
            filename = "relar" if name == "compiler" else name + ".a"
            destination = self.destination / filename
            shutil.copy2(source, destination)
            assert before[str(source)] == sha(source) == sha(destination), name
            artifacts[name] = {"path": str(destination), "input_path": str(source), "sha256": sha(destination), "bytes": destination.stat().st_size}
        versions = {
            "rustc": self.command("rustc-version", ["rustc", "+ohm", "--version", "--verbose"]),
            "cargo": self.command("cargo-version", ["sh", self.args.cargo_wrapper, "--version"]),
            "clang": self.command("clang-version", [tools["clang"], "--version"]),
            "lto_linker": self.command("lto-linker-version", [tools["lto_linker"], "--version"]),
            "rust_lld": self.command("rust-lld-version", [tools["rust_lld"], "-flavor", "gnu", "--version"]),
            "python": self.command("python-version", [tools["python"], "--version"]),
            "ruff": self.command("ruff-version", [tools["ruff"], "--version"]),
        }
        probes = {name: self.archive_probe(name, Path(metadata["path"]), tools) for name, metadata in artifacts.items() if name != "compiler"}
        build_logs = {}
        for source in self.logs():
            relative = source.relative_to(self.args.build_log_directory.resolve(strict=True))
            destination = self.destination / "build-logs" / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            assert sha(source) == before[str(source)] == sha(destination), source
            build_logs[str(relative)] = {"input_path": str(source), "path": str(destination), "sha256": sha(destination), "bytes": destination.stat().st_size}
        script_copy = self.destination / "freeze.py"
        shutil.copy2(Path(__file__), script_copy)
        assert sha(script_copy) == before[str(Path(__file__).absolute())]
        status = self.command("worktree-status", [tools["git"], "status", "--short"])
        wrapper = self.args.cargo_wrapper.resolve(strict=True)
        wrapper_contents = wrapper.read_bytes().decode("utf-8")
        tool_records = {name: {"path": str(path), "resolved_path": str(path.resolve(strict=True)), "sha256": before[str(path)]} for name, path in tools.items()}
        rust_tools_after = self.selected_rust_tools()
        assert all(rust_tools_after[name] == tools[name] for name in rust_tools_after)
        after = {str(path): sha(path) for path in self.guard_paths(tools, inputs)}
        assert before == after, "a selected source, tool, artifact, wrapper, or build log changed during capture"
        assert all(sha(Path(record["path"])) == record["sha256"] for record in artifacts.values())
        record = {
            "started_at_utc": started, "captured_at_utc": now(), "invocation": sys.orig_argv,
            "revision": revision, "revision_input": self.args.revision, "source_matches_revision": True,
            "source_scope": "Workspace Cargo.toml, Cargo.lock, rust-toolchain.toml, every crate Cargo.toml, and every Rust source under crates; both file membership and content match the named commit.",
            "source_sha256": hashes, "worktree_status_at_capture": status,
            "build_note": "This capture fingerprints pre-existing artifacts and verifies the current selected source bytes against the named revision. It does not run builds or establish whether they happened before or after that commit. Consult retained build logs and their actual guards for build provenance.",
            "artifacts": artifacts, "archive_probes": probes,
            "tools": tool_records,
            "tool_versions": versions, "target": self.args.target,
            "cargo_wrapper": {"path": str(wrapper), "sha256": before[str(wrapper)], "contents": wrapper_contents},
            "build_log_directory": str(self.args.build_log_directory.resolve()) if self.args.build_log_directory else None,
            "build_logs": build_logs,
            "build_log_scope": "Supplied files retained verbatim and guarded during capture; no unrecorded build command, result, or chronology is inferred.",
            "input_sha256_before": before, "input_sha256_after": after, "input_guards_passed": True,
            "commands": self.commands,
        }
        (self.destination / "build.json").write_text(json.dumps(record, indent=2) + "\n")
        print(self.destination / "build.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--destination", type=Path, default=Path("/tmp/relar-decoder-frozen"))
    parser.add_argument("--compiler", type=Path, default=TARGET / "relar-integrated/relar")
    parser.add_argument("--normal-runtime", type=Path, default=TARGET / "relar-integrated/librelar_runtime.a")
    parser.add_argument("--thinlto-runtime", type=Path, default=TARGET / "relar-truthiness-lto/librelar_runtime.a")
    parser.add_argument("--asan-runtime", type=Path, default=TARGET / "x86_64-unknown-linux-gnu/relar-truthiness-asan/librelar_runtime.a")
    parser.add_argument("--target", default="x86_64-unknown-linux-gnu")
    parser.add_argument("--clang", default="clang-18")
    parser.add_argument("--lto-linker", type=Path)
    parser.add_argument("--rust-lld", type=Path)
    parser.add_argument("--python", type=Path, default=PYTHON)
    parser.add_argument("--ruff", type=Path, default=RUFF)
    parser.add_argument("--cargo-wrapper", type=Path, default=Path("/tmp/relar-cargo.sh"))
    parser.add_argument("--build-log-directory", type=Path)
    Capture(parser.parse_args()).run()


if __name__ == "__main__":
    main()
