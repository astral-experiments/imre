#!/bin/sh
exec /home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14 -I -B /tmp/relar-decoder-final-tests.py \
  --compiler /tmp/relar-decoder-frozen/relar \
  --runtime /tmp/relar-decoder-frozen/normal_runtime.a \
  --thinlto-runtime /tmp/relar-decoder-frozen/thinlto_runtime.a \
  --asan-runtime /tmp/relar-decoder-frozen/asan_runtime.a \
  --build-record /tmp/relar-decoder-frozen/build.json \
  --python /home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14 \
  --clang /usr/bin/clang-18 \
  --target x86_64-unknown-linux-gnu \
  --lto-linker /home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld \
  --rust-lld /home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld \
  --ruff /tmp/ohm-stream-cgu-more-20261015/checkpoints/ruff-dev/0/debug/ruff \
  --base45-reference-dir /home/dev-user/code/oss/relar/benchmarks/local/base45-reference-dev \
  --base45-thinlto-reference-dir /home/dev-user/code/oss/relar/benchmarks/local/base45-reference-thinlto-dev \
  --reference-review-root /tmp/relar-string-reuse-validation/applications \
  --workers 4 \
  --timeout 1200 \
  --output /tmp/relar-decoder-final-validation-v3
