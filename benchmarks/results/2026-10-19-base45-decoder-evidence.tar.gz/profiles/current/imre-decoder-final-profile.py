"""Guarded final decoder instruction/allocation evidence, separate from timings."""

import argparse
import ast
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tomllib


RAW_BATCH = 64 * 1024
LABELS = tuple(f"{operation}-{size}" for operation in ("decode-bytes", "decode-text") for size in (64, 1024, 16384))
CACHE_TOOLS = Path("/home/dev-user/.cache/imre/profiling-tools/root/usr")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def identity(path):
    return {"sha256": sha(path), "bytes": path.stat().st_size}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def argument(command, flag):
    require(command.count(flag) == 1, f"expected one {flag} in compile command")
    return Path(command[command.index(flag) + 1]).resolve(strict=True)


def dhat_metrics(path):
    heap = json.loads(path.read_text())
    require(heap["mode"] == "heap", "expected a DHAT heap profile")
    require(heap["tu"] == "instrs", "unexpected DHAT lifetime unit")
    points = heap["pps"]
    return {
        "total_allocated_bytes": sum(point["tb"] for point in points),
        "total_allocated_blocks": sum(point["tbk"] for point in points),
        # gb/gbk are each allocation point's contribution at the global peak,
        # whereas summing independent per-point maxima would overstate the peak.
        "peak_live_bytes": sum(point["gb"] for point in points),
        "peak_live_blocks": sum(point["gbk"] for point in points),
        "exit_live_bytes": sum(point["eb"] for point in points),
        "exit_live_blocks": sum(point["ebk"] for point in points),
        "top_allocation_stacks": [
            {
                "bytes": point["tb"],
                "blocks": point["tbk"],
                "frames": [heap["ftbl"][index] for index in point["fs"]],
            }
            for point in sorted(points, key=lambda item: item["tb"], reverse=True)[:8]
        ],
    }


def callgrind_metrics(path):
    lines = path.read_text().splitlines()
    events = [line.split()[1:] for line in lines if line.startswith("events:")]
    summaries = [
        [int(value) for value in line.split()[1:]]
        for line in lines
        if line.startswith("summary:")
    ]
    require(len(events) == len(summaries) == 1, "expected one complete Callgrind part")
    require(len(events[0]) == len(summaries[0]), "Callgrind event/summary mismatch")
    counts = dict(zip(events[0], summaries[0], strict=True))
    require(counts.get("Ir", 0) > 0, "Callgrind did not record instructions")
    return {"instructions": counts["Ir"], "events": counts}


def decoder_identity(source, llvm, name):
    """Resolve the named source definition through unique emitted string uses.

    Imre currently erases source names before LLVM emission. This proof does not
    depend on function order, string numbering, or Callgrind's compressed IDs.
    Ambiguous or absent evidence fails instead of guessing an attribution.
    """
    tree = ast.parse(source.read_bytes(), filename=str(source))
    definitions = [
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name
    ]
    require(len(definitions) == 1, f"expected one source function {name}")
    target = definitions[0]
    other_strings = {
        child.value
        for node in tree.body if node is not target
        for child in ast.walk(node)
        if isinstance(child, ast.Constant) and isinstance(child.value, str)
    }
    literals = {
        argument.value
        for node in ast.walk(target)
        if isinstance(node, ast.Raise) and isinstance(node.exc, ast.Call)
        for argument in node.exc.args
        if isinstance(argument, ast.Constant) and isinstance(argument.value, str)
        and len(argument.value) >= 8 and argument.value not in other_strings
    }
    llvm_text = llvm.read_text()
    globals_by_value = {}
    for match in re.finditer(
        r'^@(str_\d+) = private unnamed_addr constant \[\d+ x i8\] c"((?:\\[0-9A-Fa-f]{2})*)"$',
        llvm_text, re.MULTILINE,
    ):
        try:
            value = bytes.fromhex(match[2].replace("\\", "")).decode("utf-8")
        except UnicodeDecodeError:
            continue
        globals_by_value.setdefault(value, []).append(match[1])
    functions = dict(re.findall(
        r'^define[^\n]* @([^ (]+)\([^\n]*\)[^\n]*\{\n(.*?)^\}',
        llvm_text, re.MULTILINE | re.DOTALL,
    ))
    evidence = []
    symbols = set()
    for literal in sorted(literals):
        globals_ = globals_by_value.get(literal, [])
        matches = {
            symbol for symbol, body in functions.items()
            if any(re.search(r"@" + re.escape(global_) + r"\b", body) for global_ in globals_)
        }
        if globals_ and len(matches) == 1:
            symbols.update(matches)
            evidence.append({"literal": literal, "llvm_globals": globals_, "symbols": sorted(matches)})
    require(len(symbols) == 1 and evidence, "cannot unambiguously map the named decoder to LLVM")
    symbol = symbols.pop()
    return {
        "source_path": str(source), "source_sha256": sha(source),
        "source_function": name, "source_line": target.lineno,
        "llvm_symbol": symbol, "llvm_body_sha256": digest(functions[symbol].encode()),
        "method": "Named source AST definition, unique directly raised exception-message literals, and unique referencing LLVM function; no assumed function number.",
        "evidence": evidence,
    }


def decoder_instruction_attribution(path, symbol):
    """Resolve compressed Callgrind names and sum only self instruction costs."""
    lines = path.read_text().splitlines()
    require("positions: instr line" in lines and "events: Ir" in lines, "unexpected attribution position/event layout")
    names = {}
    for line in lines:
        match = re.fullmatch(r"c?fn=\((\d+)\) (.+)", line)
        if match:
            require(match[1] not in names or names[match[1]] == match[2], "Callgrind function ID changed identity")
            names[match[1]] = match[2]
    selected = {
        identifier for identifier, name in names.items()
        if re.fullmatch(re.escape(symbol) + r"(?:\..+)?", name)
    }
    require(selected, f"decoder symbol absent from Callgrind: {symbol}")
    active = False
    skip_call = False
    position = 0
    cost = Counter()
    calls = []
    callee = None
    for line in lines:
        function = re.fullmatch(r"fn=\((\d+)\)(?: .+)?", line)
        if function:
            active = function[1] in selected
            position = 0
            skip_call = False
            continue
        if not active:
            continue
        called = re.fullmatch(r"cfn=\((\d+)\)(?: (.+))?", line)
        if called:
            callee = names.get(called[1], called[2] or f"unresolved-id:{called[1]}")
            continue
        if line.startswith("calls="):
            skip_call = True
            continue
        match = re.fullmatch(r"(0x[0-9a-f]+|[+-]\d+|\*|\d+)\s+(?:[+-]?\d+|\*)\s*(\d*)", line)
        if not match:
            continue
        raw_position = match[1]
        if raw_position.startswith("0x"):
            position = int(raw_position, 16)
        elif raw_position.startswith(("+", "-")):
            position += int(raw_position)
        elif raw_position != "*":
            position = int(raw_position)
        if skip_call:
            if match[2]:
                calls.append({"address": hex(position), "callee": callee, "inclusive_instructions": int(match[2])})
            skip_call = False
        elif match[2]:
            cost[position] += int(match[2])
    require(cost and sum(cost.values()) > 0, "decoder self costs were not recovered")
    return {
        "llvm_symbol": symbol,
        "callgrind_functions": {identifier: names[identifier] for identifier in sorted(selected)},
        "exclusive_instructions": sum(cost.values()),
        "instruction_costs": {hex(address): value for address, value in sorted(cost.items())},
        "calls": sorted(calls, key=lambda item: item["inclusive_instructions"], reverse=True),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--record", type=Path, required=True)
    parser.add_argument("--rust", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--timed-python", type=Path)
    parser.add_argument("--source-function", default="b45decode")
    parser.add_argument("--valgrind", type=Path, default=CACHE_TOOLS / "bin/valgrind")
    parser.add_argument(
        "--valgrind-lib", type=Path, default=CACHE_TOOLS / "libexec/valgrind"
    )
    parser.add_argument(
        "--annotate", type=Path, default=CACHE_TOOLS / "bin/callgrind_annotate"
    )
    parser.add_argument("--timeout", type=float, default=600)
    args = parser.parse_args()
    require(args.timeout > 0, "timeout must be positive")
    require(platform.machine() == "x86_64", "this evidence setup uses amd64 Valgrind")
    tracer = int(next(line.split(":", 1)[1] for line in Path("/proc/self/status").read_text().splitlines() if line.startswith("TracerPid:")))
    require(tracer == 0, "final profiling must run outside the managed ptrace sandbox")

    record_path = args.record.resolve(strict=True)
    record_bytes = record_path.read_bytes()
    record = json.loads(record_bytes)
    require(record.get("input_guards_passed") is True, "benchmark is incomplete")
    require(type(record.get("thinlto")) is bool, "linkage mode is not recorded")
    require(record.get("dirty") is False, "expected committed benchmark sources")
    require(
        {"imre", "rust"} <= set(record["measured_engines"]),
        "benchmark must have timed both native engines",
    )
    binaries = {
        "imre": argument(record["compile_command"], "-o"),
        "rust": args.rust.resolve(strict=True),
    }
    llvm = argument(record["compile_command"], "--emit-llvm")
    rust_record_path = binaries["rust"].parent / "build-record.json"
    rust_record_bytes = rust_record_path.read_bytes()
    rust_record = json.loads(rust_record_bytes)
    hashes = record["source_and_tool_sha256"]
    require(sha(binaries["imre"]) == record["binary_sha256"], "Imre binary changed")
    require(sha(llvm) == record["llvm_sha256"], "timed LLVM changed")
    require(sha(binaries["rust"]) == hashes["rust"], "Rust binary differs from timing")
    require(
        digest(rust_record_bytes) == hashes["rust_build_record"],
        "adjacent Rust build record differs from timing",
    )
    require(rust_record == record["rust_build_record"], "Rust build provenance mismatch")
    rust_manifest = tomllib.loads(rust_record["source_contents"]["Cargo.toml"])
    rust_lto = rust_record["environment"].get(
        "CARGO_PROFILE_RELEASE_LTO", rust_manifest.get("profile", {}).get("release", {}).get("lto")
    )
    if record["thinlto"]:
        require(rust_lto == "thin", "ThinLTO Imre requires the timed ThinLTO Rust reference")
    else:
        require(rust_lto in (None, False, "false", "off"), "ordinary Imre requires the timed ordinary Rust reference")
    require(
        rust_record["binaries"]["reference"]["sha256"] == hashes["rust"],
        "Rust executable does not match its build record",
    )
    validation_path = binaries["imre"].parent / "validation.json"
    require(
        json.loads(validation_path.read_text()) == record["validation"],
        "retained exact-binary validation differs from the benchmark",
    )
    require(
        record["validation"]["binary_sha256"] == record["binary_sha256"]
        and record["validation"]["rust"]["binary_sha256"] == hashes["rust"],
        "validation does not identify the timed binaries",
    )

    valgrind = args.valgrind.resolve(strict=True)
    annotate = args.annotate.resolve(strict=True)
    library = args.valgrind_lib.resolve(strict=True)
    tools = {
        "valgrind_launcher": valgrind,
        "valgrind_binary": valgrind.parent / "valgrind.bin",
        "callgrind_annotate": annotate,
        "dhat": library / "dhat-amd64-linux",
        "callgrind": library / "callgrind-amd64-linux",
        "core_preload": library / "vgpreload_core-amd64-linux.so",
        "dhat_preload": library / "vgpreload_dhat-amd64-linux.so",
        "shell": Path("/bin/sh").resolve(strict=True),
        "perl": Path("/usr/bin/perl").resolve(strict=True),
        "python": Path(sys.executable).resolve(strict=True),
        "objdump": Path(shutil.which("objdump")).resolve(strict=True),
        "nm": Path(shutil.which("nm")).resolve(strict=True),
    }
    script = Path(__file__).resolve(strict=True)
    repository = args.repo.resolve(strict=True)
    package = argument(record["compile_command"], "--module-root")
    reference = repository / "benchmarks/reference/base45_codec"
    timed_inputs = {
        "compiler": Path(record["compile_command"][0]).resolve(strict=True),
        "runtime": argument(record["compile_command"], "--runtime"),
        "clang": argument(record["compile_command"], "--clang"),
        "driver": Path(record["compile_command"][2]).resolve(strict=True),
        "codec": package / "base45/__init__.py",
        "harness": repository / "benchmarks/base45_benchmark.py",
        "validator": repository / "benchmarks/base45_validate.py",
        "shared_harness": repository / "benchmarks/benchmark.py",
        "upstream_manifest": package / "UPSTREAM.json",
        "tracked_rust_build_script": reference / "build.py",
    }
    if record["thinlto"]:
        timed_inputs["lto_linker"] = argument(record["compile_command"], "--lto-linker")
    if args.timed_python:
        timed_inputs["python"] = args.timed_python.resolve(strict=True)
    for index, name in enumerate(record["upstream"]["files"]):
        timed_inputs[f"upstream_{index}"] = package / name
    for name, source_hash in rust_record["sources"].items():
        require(digest(rust_record["source_contents"][name].encode()) == source_hash, f"Rust embedded source changed: {name}")
        require(hashes[f"rust_source_{name}"] == source_hash, f"timed Rust source differs: {name}")
        timed_inputs[f"tracked_rust_source_{name}"] = reference / name
    require(
        digest(rust_record["build_script"].encode()) == hashes["rust_build_script"],
        "Rust embedded build script differs from timing",
    )
    for name, path in timed_inputs.items():
        require(sha(path) == hashes[name], f"timed source/tool changed: {name}")
    decoder = decoder_identity(timed_inputs["codec"], llvm, args.source_function)
    guard_paths = {
        "benchmark_record": record_path,
        "rust_build_record": rust_record_path,
        "validation": validation_path,
        "llvm": llvm,
        "profiler": script,
        **{f"binary_{name}": path for name, path in binaries.items()},
        **{f"tool_{name}": path for name, path in tools.items()},
        **{f"timed_{name}": path for name, path in timed_inputs.items()},
    }
    cases = []
    for label in LABELS:
        matching = [item for item in record["workloads"] if item["label"] == label]
        require(len(matching) == 1, f"missing or duplicated timed workload: {label}")
        workload = matching[0]
        raw_bytes = workload["raw_bytes"]
        require(raw_bytes > 0 and RAW_BATCH % raw_bytes == 0, "invalid raw batch size")
        require(workload["repetitions"] > 0, "timed repetition count must be positive")
        require(label == f"{workload['operation']}-{raw_bytes}", "inconsistent workload label")
        payload = base64.b64decode(workload["input_base64"], validate=True)
        expected = None
        for engine in binaries:
            timed_directory = binaries["imre"].parent / label / engine
            source, output = timed_directory / "input.bin", timed_directory / "output.bin"
            require(source.read_bytes() == payload, f"timed {engine} input changed")
            output_bytes = output.read_bytes()
            require(
                digest(output_bytes) == workload["expected_output_sha256"]
                and len(output_bytes) == workload["expected_output_bytes"],
                f"timed {engine} output changed",
            )
            if expected is not None:
                require(output_bytes == expected, "native timed outputs differ")
            expected = output_bytes
            guard_paths[f"timed_{label}_{engine}_input"] = source
            guard_paths[f"timed_{label}_{engine}_output"] = output
            for phase, count in (("samples", record["samples"]), ("warmups", record["warmups"])):
                require(len(workload[phase]) == count, f"incomplete {label} {phase}")
                for sample in workload[phase]:
                    observed = sample[engine]
                    require(
                        observed["returncode"] == 0
                        and observed["stderr"] == ""
                        and observed["stdout"] == workload["expected_stdout"]
                        and observed["output_sha256"] == workload["expected_output_sha256"],
                        f"unvalidated timed {engine} sample in {label}",
                    )
        require(len(payload if workload["operation"] == "encode" else expected) == raw_bytes, "raw batch size does not match the complete input/output")
        per_call = len(expected) + (expected[0] + expected[-1] if expected else 0)
        require(
            workload["expected_stdout"] == f"OK\n{per_call * workload['repetitions']}\n",
            f"timed checksum does not match complete output for {label}",
        )
        repetitions = RAW_BATCH // raw_bytes
        stdout = f"OK\n{per_call * repetitions}\n".encode()
        cases.append((workload, payload, expected, repetitions, stdout))

    guarded = {
        name: {"path": str(path), **identity(path)} for name, path in guard_paths.items()
    }

    def verify_guards():
        for name, path in guard_paths.items():
            require(identity(path) == {key: guarded[name][key] for key in ("sha256", "bytes")}, f"guarded input changed: {name}")

    require(len(record["cpu"]["affinity"]) == 1, "timing did not use one CPU")
    cpu = record["cpu"]["affinity"][0]
    require(cpu in os.sched_getaffinity(0), "recorded CPU is unavailable")
    os.sched_setaffinity(0, {cpu})
    environment = {"VALGRIND_LIB": str(library), "VALGRIND_OPTS": "", "LC_ALL": "C"}
    env = {**os.environ, **environment}
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    (root / "benchmark-record.json").write_bytes(record_bytes)
    (root / "rust-build-record.json").write_bytes(rust_record_bytes)
    (root / script.name).write_bytes(script.read_bytes())
    source_snapshots = {}
    (root / "sources").mkdir()
    for name, path in timed_inputs.items():
        if name in {"compiler", "runtime", "clang", "lto_linker", "python"}:
            continue
        snapshot = root / "sources" / (name.replace("/", "_") + ".txt")
        snapshot.write_bytes(path.read_bytes())
        source_snapshots[str(snapshot.relative_to(root))] = identity(snapshot)
    versions = {}
    for name, command in (
        ("valgrind", [str(valgrind), "--version"]),
        ("callgrind_annotate", [str(annotate), "--version"]),
        ("perl", [str(tools["perl"]), "--version"]),
        ("objdump", [str(tools["objdump"]), "--version"]),
        ("nm", [str(tools["nm"]), "--version"]),
    ):
        completed = subprocess.run(command, input=b"", capture_output=True, env=env, cwd=root, timeout=30, check=False)
        if name == "callgrind_annotate":
            # This Perl tool reports --version via die(), hence a nonzero exit.
            version_text = (completed.stdout + completed.stderr).decode().strip()
            require(re.fullmatch(r"callgrind_annotate-\d+(?:\.\d+)+", version_text), "cannot identify annotation tool")
        else:
            require(completed.returncode == 0, f"cannot identify tool: {name}")
        versions[name] = {
            "command": command,
            "returncode": completed.returncode,
            "stdout": completed.stdout.decode(),
            "stderr": completed.stderr.decode(),
        }
    write_json(root / "tool-versions.json", versions)
    assembly = {}
    disassembly_commands = []
    command = [str(tools["nm"]), "--defined-only", str(binaries["imre"])]
    names = subprocess.run(command, input=b"", capture_output=True, env=env, cwd=root, timeout=30, check=False)
    require(names.returncode == 0 and not names.stderr, "cannot resolve decoder native symbols")
    (root / "native-symbols.txt").write_bytes(names.stdout)
    decoder["symbol_command"] = command
    decoder["binary_symbols"] = re.findall(
        r"^[0-9a-fA-F]+ [tT] (" + re.escape(decoder["llvm_symbol"]) + r"(?:\..+)?)$",
        names.stdout.decode(), re.MULTILINE,
    )
    require(decoder["binary_symbols"], "resolved decoder was not retained as a native function")
    native_assembly = []
    for symbol in decoder["binary_symbols"]:
        command = [str(tools["objdump"]), "-d", "--no-show-raw-insn", f"--disassemble={symbol}", str(binaries["imre"])]
        process = subprocess.run(command, input=b"", capture_output=True, env=env, cwd=root, timeout=30, check=False)
        require(process.returncode == 0 and not process.stderr, "decoder disassembly failed")
        disassembly_commands.append({"command": command, "returncode": process.returncode, "stdout_sha256": digest(process.stdout)})
        native_assembly.append(process.stdout)
        for line in process.stdout.decode().splitlines():
            match = re.fullmatch(r"\s*([0-9a-f]+):\s+(.+)", line)
            if match:
                address = int(match[1], 16)
                require(address not in assembly, "native decoder disassemblies overlap")
                assembly[address] = match[2]
    require(assembly, "decoder disassembly contains no instructions")
    (root / "decoder.asm").write_bytes(b"\n".join(native_assembly))
    decoder["disassembly_commands"] = disassembly_commands
    write_json(root / "decoder-identity.json", decoder)
    verify_guards()
    setup_artifacts = {
        str(path.relative_to(root)): identity(path)
        for path in sorted(root.rglob("*")) if path.is_file()
    }
    result = {
        "schema": 1,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "running",
        "complete": False,
        "guards_passed": False,
        "method": "Separate whole-process DHAT and Callgrind profiles of the exact timed Imre and Rust binaries in the recorded linkage mode. Every process handles 64 KiB of raw data using repeated codec calls, including startup, checksum and file I/O. Full output, checksum, sources, inputs, binaries, records, profiling tools and retained artifacts are verified before/after execution.",
        "instruction_measurement": "Instrumented Callgrind guest instruction counts (Ir), not CPU cycles, CPU time, or wall-time performance. Inclusive and exclusive annotations are retained separately.",
        "allocation_measurement": "DHAT requested heap bytes/blocks over the whole process, including runtime and I/O allocations; not RSS. Global peak uses gb/gbk contributions, not independent allocation-point maxima. Exit-live totals alone are not a leak diagnosis.",
        "benchmark_record_sha256": digest(record_bytes),
        "source_revision": record["revision"],
        "source_dirty": record["dirty"],
        "thinlto": record["thinlto"],
        "invocation": {"command": [sys.executable, *sys.argv], "cwd": str(Path.cwd())},
        "timed_source_and_tool_sha256": hashes,
        "timed_binary_sha256": {"imre": record["binary_sha256"], "rust": hashes["rust"]},
        "guarded_inputs": guarded,
        "tool_versions": versions,
        "decoder_identity": decoder,
        "source_snapshots": source_snapshots,
        "setup_artifacts": setup_artifacts,
        "environment": environment,
        "python_version": sys.version,
        "platform": platform.platform(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "runner_tracer_pid": tracer,
        "timed_cpu": record["cpu"],
        "raw_bytes_per_process": RAW_BATCH,
        "profiles": [],
    }
    write_json(root / "summary.json", result)
    try:
        for workload, payload, expected, repetitions, stdout in cases:
            label = workload["label"]
            for engine, binary in binaries.items():
                for tool in ("dhat", "callgrind"):
                    verify_guards()
                    directory = root / f"{label}-{engine}-{tool}"
                    directory.mkdir()
                    source, output = directory / "input.bin", directory / "output.bin"
                    source.write_bytes(payload)
                    sentinel = b"unchanged output"
                    output.write_bytes(sentinel)
                    profile = directory / ("profile.json" if tool == "dhat" else "profile.callgrind")
                    log = directory / "valgrind.log"
                    command = [
                        str(valgrind), f"--tool={tool}", "--command-line-only=yes",
                        "--num-callers=32", "--error-exitcode=97",
                        f"--log-file={log}", f"--{tool}-out-file={profile}",
                    ]
                    if tool == "callgrind":
                        command.extend(["--dump-instr=yes", "--collect-jumps=yes"])
                    command.extend([str(binary), workload["operation"], str(source), str(output), str(repetitions)])
                    command_record = {
                        "command": command, "environment": environment, "cwd": str(directory),
                        "cpu_affinity": sorted(os.sched_getaffinity(0)), "status": "running",
                        "started_at_utc": datetime.now(timezone.utc).isoformat(),
                    }
                    write_json(directory / "command.json", command_record)
                    require(source.read_bytes() == payload and output.read_bytes() == sentinel, "profile setup changed")
                    try:
                        completed = subprocess.run(command, input=b"", capture_output=True, cwd=directory, env=env, timeout=args.timeout, check=False)
                    except subprocess.TimeoutExpired as error:
                        command_record.update(status="timeout", completed_at_utc=datetime.now(timezone.utc).isoformat())
                        write_json(directory / "command.json", command_record)
                        (directory / "stdout.txt").write_bytes(error.stdout or b"")
                        (directory / "process-stderr.txt").write_bytes(error.stderr or b"")
                        raise
                    command_record.update(
                        status="exited", returncode=completed.returncode,
                        completed_at_utc=datetime.now(timezone.utc).isoformat(),
                    )
                    write_json(directory / "command.json", command_record)
                    (directory / "stdout.txt").write_bytes(completed.stdout)
                    (directory / "process-stderr.txt").write_bytes(completed.stderr)
                    require(completed.returncode == 0 and not completed.stderr, f"profile process failed: {label}/{engine}/{tool}")
                    require(completed.stdout == stdout, "profile checksum/protocol mismatch")
                    require(output.read_bytes() == expected, "profile complete output mismatch")
                    require(source.read_bytes() == payload, "profile input changed")
                    verify_guards()
                    command_record["status"] = "validated"
                    write_json(directory / "command.json", command_record)
                    entry = {
                        "label": label, "engine": engine, "tool": tool,
                        "command": command, "returncode": completed.returncode,
                        "started_at_utc": command_record["started_at_utc"],
                        "completed_at_utc": command_record["completed_at_utc"],
                        "status": "validated",
                        "repetitions": repetitions, "raw_bytes_per_process": RAW_BATCH,
                        "input_bytes_per_process": len(payload) * repetitions,
                        "input_sha256": digest(payload),
                        "output_sha256": digest(expected), "output_bytes": len(expected),
                        "initial_output_sha256": digest(sentinel),
                        "stdout": stdout.decode(), "stdout_sha256": digest(stdout),
                        "profile_sha256": sha(profile), "log_sha256": sha(log),
                    }
                    if tool == "dhat":
                        entry.update(dhat_metrics(profile))
                    else:
                        entry.update(callgrind_metrics(profile))
                        if engine == "imre":
                            attribution = decoder_instruction_attribution(profile, decoder["llvm_symbol"])
                            costs = {int(address, 16): value for address, value in attribution["instruction_costs"].items()}
                            attribution["mapped_exclusive_instructions"] = sum(value for address, value in costs.items() if address in assembly)
                            require(
                                attribution["mapped_exclusive_instructions"] == attribution["exclusive_instructions"],
                                "decoder instruction attribution does not match retained assembly",
                            )
                            attribution["fraction_of_process_instructions"] = attribution["exclusive_instructions"] / entry["instructions"]
                            write_json(directory / "decoder-instructions.json", attribution)
                            (directory / "decoder-instructions.asm").write_text("".join(
                                f"{address:08x} {costs.get(address, 0):10,d} {instruction}\n"
                                for address, instruction in sorted(assembly.items())
                            ))
                            entry["decoder_exclusive_instructions"] = attribution["exclusive_instructions"]
                        entry["annotations"] = []
                        for inclusive in ("no", "yes"):
                            command = [str(annotate), "--auto=no", f"--inclusive={inclusive}", "--threshold=100", str(profile)]
                            annotation = subprocess.run(command, input=b"", capture_output=True, cwd=directory, env=env, timeout=args.timeout, check=False)
                            name = f"functions-inclusive-{inclusive}"
                            (directory / f"{name}.txt").write_bytes(annotation.stdout)
                            (directory / f"{name}-stderr.txt").write_bytes(annotation.stderr)
                            require(annotation.returncode == 0, "Callgrind annotation failed")
                            entry["annotations"].append({"inclusive": inclusive, "command": command, "returncode": annotation.returncode, "stdout_sha256": digest(annotation.stdout), "stderr_sha256": digest(annotation.stderr)})
                    entry["files"] = {str(path.relative_to(root)): identity(path) for path in sorted(directory.iterdir()) if path.is_file()}
                    result["profiles"].append(entry)
                    write_json(root / "summary.json", result)
                    metrics = {name: entry[name] for name in ("total_allocated_bytes", "total_allocated_blocks", "peak_live_bytes", "instructions") if name in entry}
                    print(label, engine, tool, metrics, flush=True)
        verify_guards()
        for relative, expected_identity in setup_artifacts.items():
            require(identity(root / relative) == expected_identity, f"setup artifact changed: {relative}")
        for entry in result["profiles"]:
            for relative, expected_identity in entry["files"].items():
                require(identity(root / relative) == expected_identity, f"retained artifact changed: {relative}")
        require(len(result["profiles"]) == len(LABELS) * len(binaries) * 2, "incomplete profile matrix")
        require(sha(root / "benchmark-record.json") == digest(record_bytes), "retained benchmark changed")
        require(sha(root / "rust-build-record.json") == digest(rust_record_bytes), "retained Rust provenance changed")
        require(sha(root / script.name) == guarded["profiler"]["sha256"], "retained profiler changed")
        require(json.loads((root / "tool-versions.json").read_text()) == versions, "retained tool versions changed")
        result["complete"] = result["guards_passed"] = True
        result["status"] = "complete"
        result["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
        write_json(root / "summary.json", result)
        manifest = {str(path.relative_to(root)): identity(path) for path in sorted(root.rglob("*")) if path.is_file()}
        write_json(root / "manifest.json", {"scope": "Every retained file except this manifest itself", "files": manifest})
    except BaseException as error:
        result["status"] = "failed"
        result["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
        result["failure"] = f"{type(error).__name__}: {error}"
        write_json(root / "summary.json", result)
        raise
    print(f"Saved complete profiles and manifest to {root}", flush=True)


if __name__ == "__main__":
    main()
