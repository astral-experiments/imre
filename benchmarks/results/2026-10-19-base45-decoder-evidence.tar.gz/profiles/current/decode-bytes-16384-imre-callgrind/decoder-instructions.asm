00108580          4 push   %rbp
00108581          4 push   %r15
00108583          4 push   %r14
00108585          4 push   %r13
00108587          4 push   %r12
00108589          4 push   %rbx
0010858a          4 sub    $0x98,%rsp
00108591          4 test   %rdi,%rdi
00108594          4 je     1085ae <fn_4+0x2e>
00108596          4 mov    %rdi,%r14
00108599          4 test   $0x1,%r14b
0010859d          4 jne    108640 <fn_4+0xc0>
001085a3          0 incq   -0x10(%r14)
001085a7          0 jne    1085b1 <fn_4+0x31>
001085a9          0 jmp    10ae1e <fn_4+0x289e>
001085ae          0 xor    %r14d,%r14d
001085b1          0 lea    -0xddd25(%rip),%rsi        # 2a893 <_RNvNtNtNtNtNtCs6SLOTazmNXq_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xfd7>
001085b8          0 mov    %rsp,%rdi
001085bb          0 mov    $0x1,%edx
001085c0          0 addr32 call edea0 <_RNvNtNtCs6SLOTazmNXq_4core3str8converts9from_utf8>
001085c6          0 cmpl   $0x1,(%rsp)
001085ca          0 je     10ae7e <fn_4+0x28fe>
001085d0          0 mov    0x8(%rsp),%rdi
001085d5          0 mov    0x10(%rsp),%r12
001085da          0 cmp    $0x19,%r12
001085de          0 jae    10ae9b <fn_4+0x291b>
001085e4          0 mov    %r12,%r15
001085e7          0 shl    $0x38,%r15
001085eb          0 movabs $0xc000000000000000,%rax
001085f5          0 or     %rax,%r15
001085f8          0 cmp    $0xf,%r12
001085fc          0 jbe    10860f <fn_4+0x8f>
001085fe          0 cmp    $0x10,%r12
00108602          0 jne    10873b <fn_4+0x1bb>
00108608          0 xor    %eax,%eax
0010860a          0 jmp    10874b <fn_4+0x1cb>
0010860f          0 cmp    $0x7,%r12
00108613          0 jbe    108764 <fn_4+0x1e4>
00108619          0 mov    (%rdi),%r13
0010861c          0 cmp    $0x8,%r12
00108620          0 je     10884b <fn_4+0x2cb>
00108626          0 mov    -0x8(%rdi,%r12,1),%rax
0010862b          0 shl    $0x3,%r12d
0010862f          0 neg    %r12b
00108632          0 mov    %r12d,%ecx
00108635          0 shr    %cl,%rax
00108638          0 mov    %rax,%r12
0010863b          0 jmp    10884e <fn_4+0x2ce>
00108640          4 and    $0xfffffffffffffffe,%r14
00108644          4 mov    -0x10(%r14),%rax
00108648          4 inc    %rax
0010864b          4 mov    %rax,-0x10(%r14)
0010864f          4 je     10ae1e <fn_4+0x289e>
00108655          4 lea    -0x10(%r14),%rbx
00108659          4 test   %r14,%r14
0010865c          4 je     108673 <fn_4+0xf3>
0010865e          4 mov    %rbx,(%rsp)
00108662          4 decq   (%rbx)
00108665          4 jne    108670 <fn_4+0xf0>
00108667          0 mov    %rsp,%rdi
0010866a          0 addr32 call 133b60 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcINtNtB7_3vec3VechEE9drop_slowCs3V9firECmdE_12imre_runtime>
00108670          4 mov    (%rbx),%rax
00108673          4 inc    %rax
00108676          4 mov    %rax,(%rbx)
00108679          4 je     10ae1e <fn_4+0x289e>
0010867f          4 mov    0x8(%r14),%rsi
00108683          4 mov    0x10(%r14),%rdx
00108687          4 lea    0x60(%rsp),%rdi
0010868c          4 addr32 call edea0 <_RNvNtNtCs6SLOTazmNXq_4core3str8converts9from_utf8>
00108692          4 cmpl   $0x1,0x60(%rsp)
00108697          4 je     10b0ec <fn_4+0x2b6c>
0010869d          4 incq   -0x10(%r14)
001086a1          4 je     10ae1e <fn_4+0x289e>
001086a7          4 xor    %edi,%edi
001086a9          4 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
001086ae          4 mov    %rax,%r12
001086b1          4 movzbl (%rax),%ebp
001086b4          4 mov    %rbx,(%rsp)
001086b8          4 decq   (%rbx)
001086bb          4 jne    1086c6 <fn_4+0x146>
001086bd          0 mov    %rsp,%rdi
001086c0          0 addr32 call 133b60 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcINtNtB7_3vec3VechEE9drop_slowCs3V9firECmdE_12imre_runtime>
001086c6          4 mov    $0x1,%ebx
001086cb          4 test   %bpl,%bpl
001086ce          4 jne    10b113 <fn_4+0x2b93>
001086d4          4 mov    0x10(%r14),%rsi
001086d8          4 test   %rsi,%rsi
001086db          4 je     108788 <fn_4+0x208>
001086e1          4 mov    0x60498(%rip),%r13        # 168b80 <module_value_1>
001086e8          4 test   %r13,%r13
001086eb          4 je     1086fb <fn_4+0x17b>
001086ed          4 incq   -0x10(%r13)
001086f1          4 je     10ae1e <fn_4+0x289e>
001086f7          4 mov    0x10(%r14),%rsi
001086fb          4 mov    0x8(%r14),%rdi
001086ff          4 mov    %r13,%rdx
00108702          4 call   119f90 <_RNvNtNtCs3V9firECmdE_12imre_runtime7objects8mappings14gather_str_int.llvm.9568189375700981541>
00108707          4 mov    %rax,%r15
0010870a          4 movzbl (%r12),%ebx
0010870f          4 test   %r13,%r13
00108712          4 je     10872b <fn_4+0x1ab>
00108714          4 lea    -0x10(%r13),%rax
00108718          4 mov    %rax,(%rsp)
0010871c          4 decq   -0x10(%r13)
00108720          4 jne    10872b <fn_4+0x1ab>
00108722          0 mov    %rsp,%rdi
00108725          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010872b          4 test   %bl,%bl
0010872d          4 jne    10b1b2 <fn_4+0x2c32>
00108733          4 mov    %r15,%r13
00108736          4 jmp    1087f3 <fn_4+0x273>
0010873b          0 mov    -0x8(%rdi,%r12,1),%rax
00108740          0 mov    %r12d,%ecx
00108743          0 neg    %cl
00108745          0 shl    $0x3,%cl
00108748          0 shr    %cl,%rax
0010874b          0 mov    (%rdi),%r13
0010874e          0 xor    %ecx,%ecx
00108750          0 cmp    $0x18,%r12
00108754          0 mov    0x8(%rdi),%r12
00108758          0 cmove  %rcx,%r15
0010875c          0 or     %rax,%r15
0010875f          0 jmp    10884e <fn_4+0x2ce>
00108764          0 cmp    $0x3,%r12
00108768          0 jbe    108827 <fn_4+0x2a7>
0010876e          0 mov    -0x4(%rdi,%r12,1),%r13d
00108773          0 add    $0xfffffffffffffffc,%r12
00108777          0 shl    $0x3,%r12d
0010877b          0 mov    %r12d,%ecx
0010877e          0 shl    %cl,%r13
00108781          0 mov    (%rdi),%eax
00108783          0 jmp    108848 <fn_4+0x2c8>
00108788          0 movq   $0x1,(%rsp)
00108790          0 movq   $0x1,0x8(%rsp)
00108799          0 movq   $0x0,0x10(%rsp)
001087a2          0 movq   $0x8,0x18(%rsp)
001087ab          0 movq   $0x0,0x20(%rsp)
001087b4          0 mov    $0x28,%edi
001087b9          0 mov    $0x8,%esi
001087be          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
001087c3          0 test   %rax,%rax
001087c6          0 je     10b1ca <fn_4+0x2c4a>
001087cc          0 mov    %rax,%r13
001087cf          0 mov    0x20(%rsp),%rax
001087d4          0 mov    %rax,0x20(%r13)
001087d8          0 movdqu (%rsp),%xmm0
001087dd          0 movdqu 0x10(%rsp),%xmm1
001087e3          0 movdqu %xmm1,0x10(%r13)
001087e9          0 movdqu %xmm0,0x0(%r13)
001087ef          0 add    $0x10,%r13
001087f3          4 movzbl (%r12),%ebx
001087f8          4 lea    -0x10(%r14),%rax
001087fc          4 mov    %rax,(%rsp)
00108800          4 decq   -0x10(%r14)
00108804          4 jne    10880f <fn_4+0x28f>
00108806          0 mov    %rsp,%rdi
00108809          0 addr32 call 133b60 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcINtNtB7_3vec3VechEE9drop_slowCs3V9firECmdE_12imre_runtime>
0010880f          4 test   %bl,%bl
00108811          4 je     108b7f <fn_4+0x5ff>
00108817          0 xor    %r13d,%r13d
0010881a          0 xor    %r12d,%r12d
0010881d          0 mov    $0x1,%ebx
00108822          0 jmp    1091b6 <fn_4+0xc36>
00108827          0 cmp    $0x1,%r12
0010882b          0 jbe    1089a6 <fn_4+0x426>
00108831          0 movzwl -0x2(%rdi,%r12,1),%r13d
00108837          0 add    $0xfffffffffffffffe,%r12
0010883b          0 shl    $0x3,%r12d
0010883f          0 mov    %r12d,%ecx
00108842          0 shl    %cl,%r13
00108845          0 movzwl (%rdi),%eax
00108848          0 or     %rax,%r13
0010884b          0 xor    %r12d,%r12d
0010884e          0 mov    $0x28,%edi
00108853          0 mov    $0x8,%esi
00108858          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010885d          0 test   %rax,%rax
00108860          0 je     10aeb8 <fn_4+0x2938>
00108866          0 mov    %rax,%rbx
00108869          0 movq   $0x1,(%rax)
00108870          0 movq   $0x1,0x8(%rax)
00108878          0 add    $0x10,%rax
0010887c          0 mov    %r13,0x10(%rbx)
00108880          0 mov    %r12,0x18(%rbx)
00108884          0 mov    %r15,0x20(%rbx)
00108888          0 mov    %rax,(%rsp)
0010888c          0 movzbl 0x17(%r14),%eax
00108891          0 lea    0x40(%rax),%ecx
00108894          0 movzbl %cl,%ecx
00108897          0 cmp    $0x18,%cl
0010889a          0 mov    $0x18,%edx
0010889f          0 cmovb  %ecx,%edx
001088a2          0 cmp    $0xd8,%al
001088a4          0 mov    (%r14),%rdi
001088a7          0 cmovb  %r14,%rdi
001088ab          0 movzbl %dl,%esi
001088ae          0 cmovae 0x8(%r14),%rsi
001088b3          0 mov    %rsp,%rdx
001088b6          0 call   12b170 <_RINvMNtCs6SLOTazmNXq_4core3stre16trim_end_matchesNCNvNtCs3V9firECmdE_12imre_runtime7objects15imre_str_rstrip0EBR_>
001088bb          0 mov    %rdx,%r13
001088be          0 mov    0x8(%r14),%rcx
001088c2          0 movzbl 0x17(%r14),%edx
001088c7          0 lea    -0xc0(%rdx),%rsi
001088ce          0 cmp    $0x18,%rsi
001088d2          0 mov    $0x18,%edi
001088d7          0 cmovb  %rsi,%rdi
001088db          0 cmp    $0xd8,%rdx
001088e2          0 cmovae %rcx,%rdi
001088e6          0 cmp    %rdi,%r13
001088e9          0 jne    10890f <fn_4+0x38f>
001088eb          0 incq   -0x10(%r14)
001088ef          0 mov    %r14,%r12
001088f2          0 je     10ae1e <fn_4+0x289e>
001088f8          0 lea    -0x10(%r14),%rax
001088fc          0 mov    %rax,(%rsp)
00108900          0 decq   -0x10(%r14)
00108904          0 jne    108a2b <fn_4+0x4ab>
0010890a          0 jmp    108a22 <fn_4+0x4a2>
0010890f          0 cmp    $0x19,%r13
00108913          0 jae    10afdf <fn_4+0x2a5f>
00108919          0 mov    %r13,%r15
0010891c          0 shl    $0x38,%r15
00108920          0 movabs $0xc000000000000000,%rcx
0010892a          0 or     %rcx,%r15
0010892d          0 cmp    $0xf,%r13
00108931          0 jbe    10893d <fn_4+0x3bd>
00108933          0 cmp    $0x10,%r13
00108937          0 jne    108967 <fn_4+0x3e7>
00108939          0 xor    %edx,%edx
0010893b          0 jmp    108977 <fn_4+0x3f7>
0010893d          0 cmp    $0x7,%r13
00108941          0 jbe    10898d <fn_4+0x40d>
00108943          0 mov    (%rax),%rbp
00108946          0 cmp    $0x8,%r13
0010894a          0 je     1089d5 <fn_4+0x455>
00108950          0 mov    -0x8(%rax,%r13,1),%rax
00108955          0 shl    $0x3,%r13d
00108959          0 neg    %r13b
0010895c          0 mov    %r13d,%ecx
0010895f          0 shr    %cl,%rax
00108962          0 mov    %rax,%r13
00108965          0 jmp    1089d8 <fn_4+0x458>
00108967          0 mov    -0x8(%rax,%r13,1),%rdx
0010896c          0 mov    %r13d,%ecx
0010896f          0 neg    %cl
00108971          0 shl    $0x3,%cl
00108974          0 shr    %cl,%rdx
00108977          0 mov    (%rax),%rbp
0010897a          0 xor    %ecx,%ecx
0010897c          0 cmp    $0x18,%r13
00108980          0 mov    0x8(%rax),%r13
00108984          0 cmove  %rcx,%r15
00108988          0 or     %rdx,%r15
0010898b          0 jmp    1089d8 <fn_4+0x458>
0010898d          0 cmp    $0x3,%r13
00108991          0 jbe    1089b5 <fn_4+0x435>
00108993          0 lea    -0x4(%r13),%rcx
00108997          0 mov    -0x4(%rax,%r13,1),%ebp
0010899c          0 shl    $0x3,%ecx
0010899f          0 shl    %cl,%rbp
001089a2          0 mov    (%rax),%eax
001089a4          0 jmp    1089d2 <fn_4+0x452>
001089a6          0 jne    10a478 <fn_4+0x1ef8>
001089ac          0 movzbl (%rdi),%r13d
001089b0          0 jmp    10884b <fn_4+0x2cb>
001089b5          0 cmp    $0x1,%r13
001089b9          0 jbe    10a483 <fn_4+0x1f03>
001089bf          0 lea    -0x2(%r13),%rcx
001089c3          0 movzwl -0x2(%rax,%r13,1),%ebp
001089c9          0 shl    $0x3,%ecx
001089cc          0 shl    %cl,%rbp
001089cf          0 movzwl (%rax),%eax
001089d2          0 or     %rax,%rbp
001089d5          0 xor    %r13d,%r13d
001089d8          0 mov    $0x28,%edi
001089dd          0 mov    $0x8,%esi
001089e2          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
001089e7          0 test   %rax,%rax
001089ea          0 je     10afff <fn_4+0x2a7f>
001089f0          0 mov    %rax,%r12
001089f3          0 movq   $0x1,(%r12)
001089fb          0 movq   $0x1,0x8(%r12)
00108a04          0 add    $0x10,%r12
00108a08          0 mov    %rbp,0x10(%rax)
00108a0c          0 mov    %r13,0x18(%rax)
00108a10          0 mov    %r15,0x20(%rax)
00108a14          0 lea    -0x10(%r14),%rax
00108a18          0 mov    %rax,(%rsp)
00108a1c          0 decq   -0x10(%r14)
00108a20          0 jne    108a2b <fn_4+0x4ab>
00108a22          0 mov    %rsp,%rdi
00108a25          0 addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12imre_runtime>
00108a2b          0 mov    %rbx,(%rsp)
00108a2f          0 decq   (%rbx)
00108a32          0 jne    108a3d <fn_4+0x4bd>
00108a34          0 mov    %rsp,%rdi
00108a37          0 addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12imre_runtime>
00108a3d          0 mov    0x8(%r12),%rax
00108a42          0 movzbl 0x17(%r12),%ecx
00108a48          0 lea    -0xc0(%rcx),%rdx
00108a4f          0 cmp    $0xd8,%rcx
00108a56          0 cmovae %rax,%rdx
00108a5a          0 test   %rdx,%rdx
00108a5d          0 je     108ae5 <fn_4+0x565>
00108a63          0 mov    0x60116(%rip),%r14        # 168b80 <module_value_1>
00108a6a          0 test   %r14,%r14
00108a6d          0 je     108a84 <fn_4+0x504>
00108a6f          0 incq   -0x10(%r14)
00108a73          0 je     10ae1e <fn_4+0x289e>
00108a79          0 movzbl 0x17(%r12),%ecx
00108a7f          0 mov    0x8(%r12),%rax
00108a84          0 lea    0x40(%rcx),%edx
00108a87          0 movzbl %dl,%edx
00108a8a          0 cmp    $0x18,%dl
00108a8d          0 mov    $0x18,%esi
00108a92          0 cmovb  %edx,%esi
00108a95          0 cmp    $0xd8,%cl
00108a98          0 mov    (%r12),%rdi
00108a9c          0 cmovb  %r12,%rdi
00108aa0          0 movzbl %sil,%esi
00108aa4          0 cmovae %rax,%rsi
00108aa8          0 mov    %r14,%rdx
00108aab          0 call   119f90 <_RNvNtNtCs3V9firECmdE_12imre_runtime7objects8mappings14gather_str_int.llvm.9568189375700981541>
00108ab0          0 mov    %rax,%r13
00108ab3          0 xor    %edi,%edi
00108ab5          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
00108aba          0 mov    %rax,%r15
00108abd          0 movzbl (%rax),%ebx
00108ac0          0 test   %r14,%r14
00108ac3          0 je     108adc <fn_4+0x55c>
00108ac5          0 lea    -0x10(%r14),%rax
00108ac9          0 mov    %rax,(%rsp)
00108acd          0 decq   -0x10(%r14)
00108ad1          0 jne    108adc <fn_4+0x55c>
00108ad3          0 mov    %rsp,%rdi
00108ad6          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
00108adc          0 test   %bl,%bl
00108ade          0 je     108b5a <fn_4+0x5da>
00108ae0          0 xor    %r13d,%r13d
00108ae3          0 jmp    108b5a <fn_4+0x5da>
00108ae5          0 movq   $0x1,(%rsp)
00108aed          0 movq   $0x1,0x8(%rsp)
00108af6          0 movq   $0x0,0x10(%rsp)
00108aff          0 movq   $0x8,0x18(%rsp)
00108b08          0 movq   $0x0,0x20(%rsp)
00108b11          0 mov    $0x28,%edi
00108b16          0 mov    $0x8,%esi
00108b1b          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
00108b20          0 test   %rax,%rax
00108b23          0 je     10b16e <fn_4+0x2bee>
00108b29          0 mov    %rax,%r13
00108b2c          0 mov    0x20(%rsp),%rax
00108b31          0 mov    %rax,0x20(%r13)
00108b35          0 movdqu (%rsp),%xmm0
00108b3a          0 movdqu 0x10(%rsp),%xmm1
00108b40          0 movdqu %xmm1,0x10(%r13)
00108b46          0 movdqu %xmm0,0x0(%r13)
00108b4c          0 add    $0x10,%r13
00108b50          0 xor    %edi,%edi
00108b52          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
00108b57          0 mov    %rax,%r15
00108b5a          0 movzbl (%r15),%ebx
00108b5e          0 lea    -0x10(%r12),%rax
00108b63          0 mov    %rax,(%rsp)
00108b67          0 decq   -0x10(%r12)
00108b6c          0 jne    108b77 <fn_4+0x5f7>
00108b6e          0 mov    %rsp,%rdi
00108b71          0 addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12imre_runtime>
00108b77          0 test   %bl,%bl
00108b79          0 jne    10aec8 <fn_4+0x2948>
00108b7f          4 mov    0x10(%r13),%rbp
00108b83          4 movabs $0xaaaaaaaaaaaaaaab,%rbx
00108b8d          4 mov    %rbp,%rax
00108b90          4 imul   %rbx,%rax
00108b94          4 movabs $0x5555555555555555,%rcx
00108b9e          4 add    %rax,%rcx
00108ba1          4 movabs $0x5555555555555554,%rax
00108bab          4 cmp    %rax,%rcx
00108bae          4 mov    %r13,0x48(%rsp)
00108bb3          4 ja     108c17 <fn_4+0x697>
00108bb5          0 lea    -0xde31c(%rip),%rsi        # 2a8a0 <_RNvNtNtNtNtNtCs6SLOTazmNXq_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xfe4>
00108bbc          0 mov    %rsp,%rdi
00108bbf          0 mov    $0x15,%edx
00108bc4          0 addr32 call edea0 <_RNvNtNtCs6SLOTazmNXq_4core3str8converts9from_utf8>
00108bca          0 cmpl   $0x1,(%rsp)
00108bce          0 je     10af24 <fn_4+0x29a4>
00108bd4          0 mov    0x8(%rsp),%rdi
00108bd9          0 mov    0x10(%rsp),%r15
00108bde          0 cmp    $0x19,%r15
00108be2          0 jae    10af4b <fn_4+0x29cb>
00108be8          0 mov    %r15,%r14
00108beb          0 shl    $0x38,%r14
00108bef          0 movabs $0xc000000000000000,%rax
00108bf9          0 or     %rax,%r14
00108bfc          0 cmp    $0xf,%r15
00108c00          0 jbe    108ceb <fn_4+0x76b>
00108c06          0 cmp    $0x10,%r15
00108c0a          0 jne    108f77 <fn_4+0x9f7>
00108c10          0 xor    %eax,%eax
00108c12          0 jmp    108f87 <fn_4+0xa07>
00108c17          4 movq   $0x1,(%rsp)
00108c1f          4 movq   $0x1,0x8(%rsp)
00108c28          4 movq   $0x0,0x10(%rsp)
00108c31          4 movq   $0x8,0x18(%rsp)
00108c3a          4 movq   $0x0,0x20(%rsp)
00108c43          4 mov    $0x28,%edi
00108c48          4 mov    $0x8,%esi
00108c4d          4 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
00108c52          4 test   %rax,%rax
00108c55          4 je     10af14 <fn_4+0x2994>
00108c5b          4 mov    %rax,%r11
00108c5e          4 lea    0x0(,%rbp,2),%rax
00108c66          4 mov    %rax,0x90(%rsp)
00108c6e          4 mov    %r11,%r14
00108c71          4 mov    0x20(%rsp),%rax
00108c76          4 mov    %rax,0x20(%r11)
00108c7a          4 movdqu (%rsp),%xmm0
00108c7f          4 movdqu 0x10(%rsp),%xmm1
00108c85          4 movdqu %xmm1,0x10(%r11)
00108c8b          4 movdqu %xmm0,(%r11)
00108c90          4 add    $0x10,%r11
00108c94          4 cmp    %r11,%r13
00108c97          4 mov    %r14,0x50(%rsp)
00108c9c          4 mov    %r11,0x40(%rsp)
00108ca1          4 je     108d1c <fn_4+0x79c>
00108ca3          4 test   %rbp,%rbp
00108ca6          4 je     108d25 <fn_4+0x7a5>
00108ca8          4 lea    -0x1(%rbp),%rax
00108cac          4 mul    %rbx
00108caf          4 shr    $1,%rdx
00108cb2          4 lea    0x1(%rdx),%rcx
00108cb6          4 mov    0x10(%r13),%rax
00108cba          4 lea    0x3(%rax),%rsi
00108cbe          4 shr    $0x2,%rsi
00108cc2          4 cmp    %rcx,%rsi
00108cc5          4 ja     10984e <fn_4+0x12ce>
00108ccb          4 test   %rax,%rax
00108cce          4 je     10a352 <fn_4+0x1dd2>
00108cd4          4 mov    0x8(%r13),%rcx
00108cd8          4 cmp    $0x4,%rax
00108cdc          4 jae    109776 <fn_4+0x11f6>
00108ce2          0 xor    %esi,%esi
00108ce4          0 xor    %edi,%edi
00108ce6          0 jmp    10980f <fn_4+0x128f>
00108ceb          0 cmp    $0x7,%r15
00108cef          0 jbe    108fa0 <fn_4+0xa20>
00108cf5          0 mov    (%rdi),%r12
00108cf8          0 cmp    $0x8,%r15
00108cfc          0 je     109074 <fn_4+0xaf4>
00108d02          0 mov    -0x8(%rdi,%r15,1),%rax
00108d07          0 shl    $0x3,%r15d
00108d0b          0 neg    %r15b
00108d0e          0 mov    %r15d,%ecx
00108d11          0 shr    %cl,%rax
00108d14          0 mov    %rax,%r15
00108d17          0 jmp    109077 <fn_4+0xaf7>
00108d1c          0 test   %rbp,%rbp
00108d1f          0 jne    10984e <fn_4+0x12ce>
00108d25          0 mov    $0x1,%ebx
00108d2a          4 mov    0x50(%rsp),%rax
00108d2f          4 mov    0x20(%rax),%r12
00108d33          4 test   %r12,%r12
00108d36          4 je     108fc4 <fn_4+0xa44>
00108d3c          4 mov    0x18(%rax),%rbp
00108d40          4 mov    $0x1,%esi
00108d45          4 mov    %r12,%rdi
00108d48          4 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
00108d4d          4 test   %rax,%rax
00108d50          4 mov    %rbx,0x58(%rsp)
00108d55          4 je     1093c4 <fn_4+0xe44>
00108d5b          4 mov    %r12,0x60(%rsp)
00108d60          4 mov    %rax,0x68(%rsp)
00108d65          4 movq   $0x0,0x70(%rsp)
00108d6e          4 lea    0x3f(%r12),%r9
00108d73          4 shr    $0x6,%r9
00108d77          4 lea    0x10(%rbp),%rdx
00108d7b          4 lea    0x2(%rax),%rsi
00108d7f          4 lea    0x1(%rax),%rdi
00108d83          4 xor    %r8d,%r8d
00108d86          4 movdqa -0xf768e(%rip),%xmm0        # 11700 <anon.dd6a8a796c10bf5c67fa0e87de5edd21.24.llvm.9568189375700981541+0x900>
00108d8e          4 movdqa -0xf7cf6(%rip),%xmm1        # 110a0 <anon.dd6a8a796c10bf5c67fa0e87de5edd21.24.llvm.9568189375700981541+0x2a0>
00108d96          4 mov    %rbp,%r10
00108d99          4 mov    %r12,%r11
00108d9c          4 mov    %rbp,0x78(%rsp)
00108da1          4 mov    %rax,0x90(%rsp)
00108da9          4 mov    %r9,0x80(%rsp)
00108db1          4 jmp    108e0d <fn_4+0x88d>
00108db3          0 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
00108dc0      1,024 test   $0xfffffffffffffe01,%rbx
00108dc7      1,024 mov    0x58(%rsp),%rbx
00108dcc      1,024 mov    0x78(%rsp),%rbp
00108dd1      1,024 mov    0x90(%rsp),%rax
00108dd9      1,024 mov    0x80(%rsp),%r9
00108de1      1,024 jne    10ae20 <fn_4+0x28a0>
00108de7      1,024 inc    %r8
00108dea      1,024 add    $0xffffffffffffffc0,%r11
00108dee      1,024 add    $0x200,%rdx
00108df5      1,024 add    $0x40,%rsi
00108df9      1,024 add    $0x200,%r10
00108e00      1,024 add    $0x40,%rdi
00108e04      1,024 cmp    %r9,%r8
00108e07      1,024 je     108fd6 <fn_4+0xa56>
00108e0d      1,024 cmp    $0x40,%r11
00108e11      1,024 mov    $0x40,%r14d
00108e17      1,024 cmovb  %r11,%r14
00108e1b      1,024 mov    %r8,%r13
00108e1e      1,024 shl    $0x6,%r13
00108e22      1,024 mov    %r12,%r15
00108e25      1,024 sub    %r13,%r15
00108e28      1,024 cmp    $0x40,%r15
00108e2c      1,024 mov    $0x40,%ecx
00108e31      1,024 cmovae %rcx,%r15
00108e35      1,024 mov    %r12,%rcx
00108e38      1,024 sub    %r13,%rcx
00108e3b      1,024 je     108de7 <fn_4+0x867>
00108e3d      1,024 add    %rax,%r13
00108e40      1,024 mov    %r8,%r9
00108e43      1,024 shl    $0x9,%r9
00108e47      1,024 add    %rbp,%r9
00108e4a      1,024 cmp    $0x4,%rcx
00108e4e      1,024 jb     108e65 <fn_4+0x8e5>
00108e50      1,024 mov    %r15d,%ecx
00108e53      1,024 lea    (%r9,%rcx,8),%rcx
00108e57      1,024 cmp    %rcx,%r13
00108e5a      1,024 jae    108ed6 <fn_4+0x956>
00108e5c      1,024 lea    (%r15,%r13,1),%rcx
00108e60      1,024 cmp    %rcx,%r9
00108e63      1,024 jae    108ed6 <fn_4+0x956>
00108e65          0 xor    %ebx,%ebx
00108e67          0 xor    %ebp,%ebp
00108e69          0 mov    %rbp,%rcx
00108e6c          0 or     $0x1,%rcx
00108e70          0 test   $0x1,%r15b
00108e74          0 je     108e8e <fn_4+0x90e>
00108e76          0 mov    (%r9,%rbp,8),%rax
00108e7a          0 mov    %rax,%r9
00108e7d          0 xor    $0x1,%r9
00108e81          0 or     %r9,%rbx
00108e84          0 shr    $1,%eax
00108e86          0 mov    %al,0x0(%r13,%rbp,1)
00108e8b          0 mov    %rcx,%rbp
00108e8e          0 cmp    %rcx,%r15
00108e91          0 je     108dc0 <fn_4+0x840>
00108e97          0 nopw   0x0(%rax,%rax,1)
00108ea0          0 mov    (%r10,%rbp,8),%rax
00108ea4          0 mov    %rax,%rcx
00108ea7          0 xor    $0x1,%rcx
00108eab          0 or     %rbx,%rcx
00108eae          0 shr    $1,%eax
00108eb0          0 mov    %al,-0x1(%rdi,%rbp,1)
00108eb4          0 mov    0x8(%r10,%rbp,8),%rax
00108eb9          0 mov    %rax,%rbx
00108ebc          0 shr    $1,%eax
00108ebe          0 mov    %al,(%rdi,%rbp,1)
00108ec1          0 add    $0x2,%rbp
00108ec5          0 xor    $0x1,%rbx
00108ec9          0 or     %rcx,%rbx
00108ecc          0 cmp    %rbp,%r14
00108ecf          0 jne    108ea0 <fn_4+0x920>
00108ed1          0 jmp    108dc0 <fn_4+0x840>
00108ed6      1,024 mov    %r14d,%ebx
00108ed9      1,024 and    $0x7c,%ebx
00108edc      1,024 mov    %r15d,%ebp
00108edf      1,024 and    $0x7c,%ebp
00108ee2      1,024 pxor   %xmm2,%xmm2
00108ee6      1,024 xor    %ecx,%ecx
00108ee8      1,024 pxor   %xmm3,%xmm3
00108eec      1,024 nopl   0x0(%rax)
00108ef0     16,384 movdqu -0x10(%rdx,%rcx,8),%xmm4
00108ef6     16,384 movdqu (%rdx,%rcx,8),%xmm5
00108efb     16,384 movdqa %xmm4,%xmm6
00108eff     16,384 pxor   %xmm0,%xmm6
00108f03     16,384 por    %xmm6,%xmm3
00108f07     16,384 movdqa %xmm5,%xmm6
00108f0b     16,384 pxor   %xmm0,%xmm6
00108f0f     16,384 por    %xmm6,%xmm2
00108f13     16,384 psrlq  $0x1,%xmm4
00108f18     16,384 psrlq  $0x1,%xmm5
00108f1d     16,384 pand   %xmm1,%xmm4
00108f21     16,384 packuswb %xmm4,%xmm4
00108f25     16,384 packuswb %xmm4,%xmm4
00108f29     16,384 packuswb %xmm4,%xmm4
00108f2d     16,384 pand   %xmm1,%xmm5
00108f31     16,384 packuswb %xmm5,%xmm5
00108f35     16,384 packuswb %xmm5,%xmm5
00108f39     16,384 packuswb %xmm5,%xmm5
00108f3d     16,384 movd   %xmm4,%eax
00108f41     16,384 mov    %ax,-0x2(%rsi,%rcx,1)
00108f46     16,384 movd   %xmm5,%eax
00108f4a     16,384 mov    %ax,(%rsi,%rcx,1)
00108f4e     16,384 add    $0x4,%rcx
00108f52     16,384 cmp    %rcx,%rbx
00108f55     16,384 jne    108ef0 <fn_4+0x970>
00108f57      1,024 por    %xmm3,%xmm2
00108f5b      1,024 pshufd $0xee,%xmm2,%xmm3
00108f60      1,024 por    %xmm2,%xmm3
00108f64      1,024 movq   %xmm3,%rbx
00108f69      1,024 cmp    %rbp,%r15
00108f6c      1,024 je     108dc0 <fn_4+0x840>
00108f72          0 jmp    108e69 <fn_4+0x8e9>
00108f77          0 mov    -0x8(%rdi,%r15,1),%rax
00108f7c          0 mov    %r15d,%ecx
00108f7f          0 neg    %cl
00108f81          0 shl    $0x3,%cl
00108f84          0 shr    %cl,%rax
00108f87          0 mov    (%rdi),%r12
00108f8a          0 xor    %ecx,%ecx
00108f8c          0 cmp    $0x18,%r15
00108f90          0 mov    0x8(%rdi),%r15
00108f94          0 cmove  %rcx,%r14
00108f98          0 or     %rax,%r14
00108f9b          0 jmp    109077 <fn_4+0xaf7>
00108fa0          0 cmp    $0x3,%r15
00108fa4          0 jbe    109050 <fn_4+0xad0>
00108faa          0 mov    -0x4(%rdi,%r15,1),%r12d
00108faf          0 add    $0xfffffffffffffffc,%r15
00108fb3          0 shl    $0x3,%r15d
00108fb7          0 mov    %r15d,%ecx
00108fba          0 shl    %cl,%r12
00108fbd          0 mov    (%rdi),%eax
00108fbf          0 jmp    109071 <fn_4+0xaf1>
00108fc4          0 movq   $0x0,0x60(%rsp)
00108fcd          0 movq   $0x1,0x68(%rsp)
00108fd6          4 mov    %r12,0x70(%rsp)
00108fdb          4 mov    %r12,0x20(%rsp)
00108fe0          4 mov    0x60(%rsp),%rax
00108fe5          4 mov    %rax,0x10(%rsp)
00108fea          4 mov    0x68(%rsp),%rax
00108fef          4 mov    %rax,0x18(%rsp)
00108ff4          4 movq   $0x1,(%rsp)
00108ffc          4 movq   $0x1,0x8(%rsp)
00109005          4 mov    $0x28,%edi
0010900a          4 mov    $0x8,%esi
0010900f          4 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
00109014          4 test   %rax,%rax
00109017          4 je     10b1ba <fn_4+0x2c3a>
0010901d          4 mov    %rax,%r12
00109020          4 mov    0x20(%rsp),%rax
00109025          4 mov    %rax,0x20(%r12)
0010902a          4 movdqu (%rsp),%xmm0
0010902f          4 movdqu 0x10(%rsp),%xmm1
00109035          4 movdqu %xmm1,0x10(%r12)
0010903c          4 movdqu %xmm0,(%r12)
00109042          4 add    $0x10,%r12
00109046          4 mov    0x48(%rsp),%r13
0010904b          4 jmp    109410 <fn_4+0xe90>
00109050          0 cmp    $0x1,%r15
00109054          0 jbe    109767 <fn_4+0x11e7>
0010905a          0 movzwl -0x2(%rdi,%r15,1),%r12d
00109060          0 add    $0xfffffffffffffffe,%r15
00109064          0 shl    $0x3,%r15d
00109068          0 mov    %r15d,%ecx
0010906b          0 shl    %cl,%r12
0010906e          0 movzwl (%rdi),%eax
00109071          0 or     %rax,%r12
00109074          0 xor    %r15d,%r15d
00109077          0 mov    $0x28,%edi
0010907c          0 mov    $0x8,%esi
00109081          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
00109086          0 test   %rax,%rax
00109089          0 je     10af68 <fn_4+0x29e8>
0010908f          0 mov    %rax,%r13
00109092          0 movq   $0x1,0x8(%rax)
0010909a          0 mov    %r12,0x10(%rax)
0010909e          0 mov    %r15,0x18(%rax)
001090a2          0 mov    %r14,0x20(%rax)
001090a6          0 movq   $0x2,(%rax)
001090ad          0 movq   $0x1,(%rsp)
001090b5          0 movq   $0x1,0x8(%rsp)
001090be          0 mov    %rax,0x10(%rsp)
001090c3          0 movq   $0x0,0x18(%rsp)
001090cc          0 movl   $0x8,0x20(%rsp)
001090d4          0 movb   $0x0,0x24(%rsp)
001090d9          0 movb   $0x8,0x39(%rsp)
001090de          0 mov    $0x40,%edi
001090e3          0 mov    $0x8,%esi
001090e8          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
001090ed          0 test   %rax,%rax
001090f0          0 je     10af78 <fn_4+0x29f8>
001090f6          0 mov    %rax,%r14
001090f9          0 movdqu (%rsp),%xmm0
001090fe          0 movdqu 0x10(%rsp),%xmm1
00109104          0 movdqu 0x20(%rsp),%xmm2
0010910a          0 movdqu 0x30(%rsp),%xmm3
00109110          0 movdqu %xmm3,0x30(%rax)
00109115          0 movdqu %xmm2,0x20(%rax)
0010911a          0 movdqu %xmm1,0x10(%rax)
0010911f          0 movdqu %xmm0,(%rax)
00109123          0 mov    %r13,(%rsp)
00109127          0 decq   0x0(%r13)
0010912b          0 jne    109136 <fn_4+0xbb6>
0010912d          0 mov    %rsp,%rdi
00109130          0 addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12imre_runtime>
00109136          0 cmpb   $0x8,0x39(%r14)
0010913b          0 mov    0x48(%rsp),%r13
00109140          0 jne    10af8d <fn_4+0x2a0d>
00109146          0 incq   (%r14)
00109149          0 je     10ae1e <fn_4+0x289e>
0010914f          0 mov    %r14,0x60(%rsp)
00109154          0 xor    %edi,%edi
00109156          0 call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
0010915b          0 test   %rax,%rax
0010915e          0 je     10b467 <fn_4+0x2ee7>
00109164          0 mov    %r14,(%rsp)
00109168          0 cmpq   $0x0,(%rax)
0010916c          0 jne    10afaa <fn_4+0x2a2a>
00109172          0 mov    0x8(%rax),%rbx
00109176          0 mov    %r14,0x8(%rax)
0010917a          0 mov    %rsp,%rdi
0010917d          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
00109182          0 movb   $0x1,(%rax)
00109185          0 mov    %rbx,(%rsp)
00109189          0 test   %rbx,%rbx
0010918c          0 je     10919c <fn_4+0xc1c>
0010918e          0 decq   (%rbx)
00109191          0 jne    10919c <fn_4+0xc1c>
00109193          0 mov    %rsp,%rdi
00109196          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010919c          0 mov    %r14,(%rsp)
001091a0          0 decq   (%r14)
001091a3          0 jne    1091ae <fn_4+0xc2e>
001091a5          0 mov    %rsp,%rdi
001091a8          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
001091ae          0 mov    $0x1,%ebx
001091b3          0 xor    %r12d,%r12d
001091b6          0 xor    %edi,%edi
001091b8          0 call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
001091bd          0 test   %rax,%rax
001091c0          0 je     10b45a <fn_4+0x2eda>
001091c6          0 cmpq   $0x0,(%rax)
001091ca          0 jne    10aed0 <fn_4+0x2950>
001091d0          0 mov    %rbx,0x58(%rsp)
001091d5          0 mov    0x8(%rax),%rbx
001091d9          0 pxor   %xmm0,%xmm0
001091dd          0 movdqu %xmm0,(%rax)
001091e1          0 mov    %rsp,%rdi
001091e4          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
001091e9          0 movb   $0x0,(%rax)
001091ec          0 test   %rbx,%rbx
001091ef          0 je     10aedd <fn_4+0x295d>
001091f5          0 cmpb   $0x8,0x39(%rbx)
001091f9          0 jne    10aef7 <fn_4+0x2977>
001091ff          0 mov    0x20(%rbx),%ecx
00109202          0 xor    %eax,%eax
00109204          0 cmp    $0x13,%ecx
00109207          0 ja     109215 <fn_4+0xc95>
00109209          0 mov    $0xe0100,%edx
0010920e          0 bt     %ecx,%edx
00109211          0 jae    109215 <fn_4+0xc95>
00109213          0 mov    $0x1,%al
00109215          0 cmp    $0x7,%ecx
00109218          0 sete   %dl
0010921b          0 cmp    $0xe,%ecx
0010921e          0 sete   %sil
00109222          0 or     %dl,%sil
00109225          0 mov    (%rbx),%rcx
00109228          0 inc    %rcx
0010922b          0 or     %al,%sil
0010922e          0 mov    %rcx,(%rbx)
00109231          0 je     1092e3 <fn_4+0xd63>
00109237          0 test   %rcx,%rcx
0010923a          0 je     10ae1e <fn_4+0x289e>
00109240          0 mov    %rbx,0x60(%rsp)
00109245          0 xor    %edi,%edi
00109247          0 call   12e3a0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions6ACTIVE00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1e_6option6OptionQIB1T_INtNtB1e_4cell7RefCellIB1T_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
0010924c          0 test   %rax,%rax
0010924f          0 je     10b484 <fn_4+0x2f04>
00109255          0 mov    %rbx,(%rsp)
00109259          0 cmpq   $0x0,(%rax)
0010925d          0 jne    10b00f <fn_4+0x2a8f>
00109263          0 mov    0x8(%rax),%r15
00109267          0 mov    %rbx,0x8(%rax)
0010926b          0 lea    0x10(%r15),%rax
0010926f          0 test   %r15,%r15
00109272          0 cmove  %r15,%rax
00109276          0 mov    %rax,0x50(%rsp)
0010927b          0 lea    -0xde9e2(%rip),%rsi        # 2a8a0 <_RNvNtNtNtNtNtCs6SLOTazmNXq_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xfe4>
00109282          0 mov    %rsp,%rdi
00109285          0 mov    $0x15,%edx
0010928a          0 addr32 call edea0 <_RNvNtNtCs6SLOTazmNXq_4core3str8converts9from_utf8>
00109290          0 cmpl   $0x1,(%rsp)
00109294          0 je     10b01c <fn_4+0x2a9c>
0010929a          0 mov    %r12,0x40(%rsp)
0010929f          0 mov    %r13,0x48(%rsp)
001092a4          0 mov    0x8(%rsp),%rdi
001092a9          0 mov    0x10(%rsp),%r13
001092ae          0 cmp    $0x19,%r13
001092b2          0 jae    10b039 <fn_4+0x2ab9>
001092b8          0 mov    %r13,%r12
001092bb          0 shl    $0x38,%r12
001092bf          0 movabs $0xc000000000000000,%rax
001092c9          0 or     %rax,%r12
001092cc          0 cmp    $0xf,%r13
001092d0          0 jbe    10934a <fn_4+0xdca>
001092d2          0 cmp    $0x10,%r13
001092d6          0 jne    109377 <fn_4+0xdf7>
001092dc          0 xor    %eax,%eax
001092de          0 jmp    109387 <fn_4+0xe07>
001092e3          0 test   %rcx,%rcx
001092e6          0 je     10ae1e <fn_4+0x289e>
001092ec          0 mov    %rbx,0x60(%rsp)
001092f1          0 xor    %edi,%edi
001092f3          0 call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
001092f8          0 test   %rax,%rax
001092fb          0 je     10b4e1 <fn_4+0x2f61>
00109301          0 mov    %rbx,(%rsp)
00109305          0 cmpq   $0x0,(%rax)
00109309          0 jne    10b1a5 <fn_4+0x2c25>
0010930f          0 mov    0x8(%rax),%r14
00109313          0 mov    %rbx,0x8(%rax)
00109317          0 mov    %rsp,%rdi
0010931a          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
0010931f          0 movb   $0x1,(%rax)
00109322          0 mov    %r14,(%rsp)
00109326          0 test   %r14,%r14
00109329          0 je     109339 <fn_4+0xdb9>
0010932b          0 decq   (%r14)
0010932e          0 jne    109339 <fn_4+0xdb9>
00109330          0 mov    %rsp,%rdi
00109333          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
00109339          0 add    $0x10,%rbx
0010933d          0 mov    %rbx,%rcx
00109340          0 mov    0x58(%rsp),%rbx
00109345          0 jmp    1096d6 <fn_4+0x1156>
0010934a          0 cmp    $0x7,%r13
0010934e          0 jbe    1093a0 <fn_4+0xe20>
00109350          0 mov    (%rdi),%rbp
00109353          0 cmp    $0x8,%r13
00109357          0 je     10948c <fn_4+0xf0c>
0010935d          0 mov    -0x8(%rdi,%r13,1),%rax
00109362          0 shl    $0x3,%r13d
00109366          0 neg    %r13b
00109369          0 mov    %r13d,%ecx
0010936c          0 shr    %cl,%rax
0010936f          0 mov    %rax,%r13
00109372          0 jmp    10948f <fn_4+0xf0f>
00109377          0 mov    -0x8(%rdi,%r13,1),%rax
0010937c          0 mov    %r13d,%ecx
0010937f          0 neg    %cl
00109381          0 shl    $0x3,%cl
00109384          0 shr    %cl,%rax
00109387          0 mov    (%rdi),%rbp
0010938a          0 xor    %ecx,%ecx
0010938c          0 cmp    $0x18,%r13
00109390          0 mov    0x8(%rdi),%r13
00109394          0 cmove  %rcx,%r12
00109398          0 or     %rax,%r12
0010939b          0 jmp    10948f <fn_4+0xf0f>
001093a0          0 cmp    $0x3,%r13
001093a4          0 jbe    109468 <fn_4+0xee8>
001093aa          0 mov    -0x4(%rdi,%r13,1),%ebp
001093af          0 add    $0xfffffffffffffffc,%r13
001093b3          0 shl    $0x3,%r13d
001093b7          0 mov    %r13d,%ecx
001093ba          0 shl    %cl,%rbp
001093bd          0 mov    (%rdi),%eax
001093bf          0 jmp    109489 <fn_4+0xf09>
001093c4          0 movabs $0x6c61207365747962,%r14
001093ce          0 movabs $0x6e6f697461636f6c,%rbx
001093d8          0 movabs $0xd764656c69616620,%r13
001093e2          0 mov    $0xf,%eax
001093e7          0 mov    %r14,(%rsp)
001093eb          0 mov    %rbx,0x8(%rsp)
001093f0          0 mov    %r13,0x10(%rsp)
001093f5          0 mov    %eax,0x18(%rsp)
001093f9          0 mov    %rsp,%rdi
001093fc          0 xor    %esi,%esi
001093fe          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
00109403          0 mov    %rax,%r12
00109406          0 mov    0x48(%rsp),%r13
0010940b          0 mov    0x58(%rsp),%rbx
00109410          4 mov    0x50(%rsp),%r14
00109415          4 xor    %edi,%edi
00109417          4 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
0010941c          4 cmpb   $0x0,(%rax)
0010941f          4 jne    10b17e <fn_4+0x2bfe>
00109425          4 test   %r13,%r13
00109428          4 je     109441 <fn_4+0xec1>
0010942a          4 lea    -0x10(%r13),%rax
0010942e          4 mov    %rax,(%rsp)
00109432          4 decq   -0x10(%r13)
00109436          4 jne    109441 <fn_4+0xec1>
00109438          4 mov    %rsp,%rdi
0010943b          4 addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12imre_runtime4ListE9drop_slowBF_>
00109441          4 mov    %r14,(%rsp)
00109445          4 decq   (%r14)
00109448          4 jne    109453 <fn_4+0xed3>
0010944a          4 mov    %rsp,%rdi
0010944d          4 addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12imre_runtime4ListE9drop_slowBF_>
00109453          4 test   %rbx,%rbx
00109456          4 sete   %al
00109459          4 or     %bl,%al
0010945b          4 test   $0x1,%al
0010945d          4 je     109736 <fn_4+0x11b6>
00109463          4 jmp    109752 <fn_4+0x11d2>
00109468          0 cmp    $0x1,%r13
0010946c          0 jbe    10a491 <fn_4+0x1f11>
00109472          0 movzwl -0x2(%rdi,%r13,1),%ebp
00109478          0 add    $0xfffffffffffffffe,%r13
0010947c          0 shl    $0x3,%r13d
00109480          0 mov    %r13d,%ecx
00109483          0 shl    %cl,%rbp
00109486          0 movzwl (%rdi),%eax
00109489          0 or     %rax,%rbp
0010948c          0 xor    %r13d,%r13d
0010948f          0 mov    $0x28,%edi
00109494          0 mov    $0x8,%esi
00109499          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010949e          0 test   %rax,%rax
001094a1          0 je     10b056 <fn_4+0x2ad6>
001094a7          0 mov    %rax,%r14
001094aa          0 movq   $0x1,0x8(%rax)
001094b2          0 mov    %rbp,0x10(%rax)
001094b6          0 mov    %r13,0x18(%rax)
001094ba          0 mov    %r12,0x20(%rax)
001094be          0 movq   $0x2,(%rax)
001094c5          0 movq   $0x1,(%rsp)
001094cd          0 movq   $0x1,0x8(%rsp)
001094d6          0 mov    %rax,0x10(%rsp)
001094db          0 movq   $0x0,0x18(%rsp)
001094e4          0 movl   $0x8,0x20(%rsp)
001094ec          0 movb   $0x0,0x24(%rsp)
001094f1          0 movb   $0x8,0x39(%rsp)
001094f6          0 mov    $0x40,%edi
001094fb          0 mov    $0x8,%esi
00109500          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
00109505          0 test   %rax,%rax
00109508          0 je     10b066 <fn_4+0x2ae6>
0010950e          0 mov    %rax,%r12
00109511          0 movdqu (%rsp),%xmm0
00109516          0 movdqu 0x10(%rsp),%xmm1
0010951c          0 movdqu 0x20(%rsp),%xmm2
00109522          0 movdqu 0x30(%rsp),%xmm3
00109528          0 movdqu %xmm3,0x30(%rax)
0010952d          0 movdqu %xmm2,0x20(%rax)
00109532          0 movdqu %xmm1,0x10(%rax)
00109537          0 movdqu %xmm0,(%rax)
0010953b          0 mov    %r14,(%rsp)
0010953f          0 decq   (%r14)
00109542          0 jne    10954d <fn_4+0xfcd>
00109544          0 mov    %rsp,%rdi
00109547          0 addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12imre_runtime>
0010954d          0 mov    (%rbx),%rax
00109550          0 mov    %rax,%rcx
00109553          0 inc    %rcx
00109556          0 mov    %rcx,(%rbx)
00109559          0 mov    0x48(%rsp),%r13
0010955e          0 je     10ae1e <fn_4+0x289e>
00109564          0 cmpb   $0x8,0x39(%rbx)
00109568          0 jne    10b07b <fn_4+0x2afb>
0010956e          0 add    $0x2,%rax
00109572          0 mov    %rax,(%rbx)
00109575          0 je     10ae1e <fn_4+0x289e>
0010957b          0 mov    %rbx,(%rsp)
0010957f          0 cmpb   $0x8,0x39(%r12)
00109585          0 jne    10b098 <fn_4+0x2b18>
0010958b          0 mov    0x18(%r12),%rax
00109590          0 test   %rax,%rax
00109593          0 je     1095aa <fn_4+0x102a>
00109595          0 decq   (%rax)
00109598          0 jne    1095aa <fn_4+0x102a>
0010959a          0 mov    %r12,%r14
0010959d          0 add    $0x18,%r14
001095a1          0 mov    %r14,%rdi
001095a4          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
001095aa          0 mov    %rbx,0x18(%r12)
001095af          0 movb   $0x1,0x24(%r12)
001095b5          0 mov    (%r12),%rax
001095b9          0 mov    %rax,%rcx
001095bc          0 inc    %rcx
001095bf          0 mov    %rcx,(%r12)
001095c3          0 je     10ae1e <fn_4+0x289e>
001095c9          0 mov    %rax,(%r12)
001095cd          0 mov    %rbx,(%rsp)
001095d1          0 decq   (%rbx)
001095d4          0 jne    1095df <fn_4+0x105f>
001095d6          0 mov    %rsp,%rdi
001095d9          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
001095df          0 cmpb   $0x8,0x39(%r12)
001095e5          0 jne    10b0b5 <fn_4+0x2b35>
001095eb          0 incq   (%r12)
001095ef          0 je     10ae1e <fn_4+0x289e>
001095f5          0 mov    %r12,0x60(%rsp)
001095fa          0 xor    %edi,%edi
001095fc          0 call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
00109601          0 test   %rax,%rax
00109604          0 je     10b4a1 <fn_4+0x2f21>
0010960a          0 mov    %r12,(%rsp)
0010960e          0 cmpq   $0x0,(%rax)
00109612          0 jne    10b0d2 <fn_4+0x2b52>
00109618          0 mov    0x8(%rax),%r14
0010961c          0 mov    %r12,0x8(%rax)
00109620          0 mov    %rsp,%rdi
00109623          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
00109628          0 movb   $0x1,(%rax)
0010962b          0 mov    %r14,(%rsp)
0010962f          0 test   %r14,%r14
00109632          0 je     109642 <fn_4+0x10c2>
00109634          0 decq   (%r14)
00109637          0 jne    109642 <fn_4+0x10c2>
00109639          0 mov    %rsp,%rdi
0010963c          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
00109642          0 mov    %r12,(%rsp)
00109646          0 decq   (%r12)
0010964a          0 jne    109655 <fn_4+0x10d5>
0010964c          0 mov    %rsp,%rdi
0010964f          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
00109655          0 mov    %rbx,(%rsp)
00109659          0 decq   (%rbx)
0010965c          0 mov    0x40(%rsp),%r12
00109661          0 jne    10966c <fn_4+0x10ec>
00109663          0 mov    %rsp,%rdi
00109666          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010966c          0 test   %r15,%r15
0010966f          0 mov    0x58(%rsp),%rbx
00109674          0 je     10968a <fn_4+0x110a>
00109676          0 cmpb   $0x8,0x39(%r15)
0010967b          0 jne    10b188 <fn_4+0x2c08>
00109681          0 incq   (%r15)
00109684          0 je     10ae1e <fn_4+0x289e>
0010968a          0 mov    %r15,0x60(%rsp)
0010968f          0 xor    %edi,%edi
00109691          0 call   12e3a0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions6ACTIVE00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1e_6option6OptionQIB1T_INtNtB1e_4cell7RefCellIB1T_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
00109696          0 test   %rax,%rax
00109699          0 je     10b4bf <fn_4+0x2f3f>
0010969f          0 mov    %r15,(%rsp)
001096a3          0 cmpq   $0x0,(%rax)
001096a7          0 jne    10b0df <fn_4+0x2b5f>
001096ad          0 mov    0x8(%rax),%rcx
001096b1          0 mov    %r15,0x8(%rax)
001096b5          0 test   %rcx,%rcx
001096b8          0 je     1096cc <fn_4+0x114c>
001096ba          0 mov    %rcx,(%rsp)
001096be          0 decq   (%rcx)
001096c1          0 jne    1096cc <fn_4+0x114c>
001096c3          0 mov    %rsp,%rdi
001096c6          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
001096cc          0 test   %r15,%r15
001096cf          0 mov    0x50(%rsp),%rcx
001096d4          0 je     1096ed <fn_4+0x116d>
001096d6          0 lea    -0x10(%rcx),%rax
001096da          0 mov    %rax,(%rsp)
001096de          0 decq   -0x10(%rcx)
001096e2          0 jne    1096ed <fn_4+0x116d>
001096e4          0 mov    %rsp,%rdi
001096e7          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
001096ed          0 test   %r13,%r13
001096f0          0 je     109709 <fn_4+0x1189>
001096f2          0 lea    -0x10(%r13),%rax
001096f6          0 mov    %rax,(%rsp)
001096fa          0 decq   -0x10(%r13)
001096fe          0 jne    109709 <fn_4+0x1189>
00109700          0 mov    %rsp,%rdi
00109703          0 addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12imre_runtime4ListE9drop_slowBF_>
00109709          0 test   %r12,%r12
0010970c          0 je     109727 <fn_4+0x11a7>
0010970e          0 lea    -0x10(%r12),%rax
00109713          0 mov    %rax,(%rsp)
00109717          0 decq   -0x10(%r12)
0010971c          0 jne    109727 <fn_4+0x11a7>
0010971e          0 mov    %rsp,%rdi
00109721          0 addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12imre_runtime4ListE9drop_slowBF_>
00109727          0 test   %rbx,%rbx
0010972a          0 sete   %al
0010972d          0 or     %bl,%al
0010972f          0 xor    %r12d,%r12d
00109732          0 test   $0x1,%al
00109734          0 jne    109752 <fn_4+0x11d2>
00109736          0 test   $0x1,%bl
00109739          0 jne    109752 <fn_4+0x11d2>
0010973b          0 lea    -0x10(%rbx),%rax
0010973f          0 mov    %rax,(%rsp)
00109743          0 decq   -0x10(%rbx)
00109747          0 jne    109752 <fn_4+0x11d2>
00109749          0 mov    %rsp,%rdi
0010974c          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109752          4 mov    %r12,%rax
00109755          4 add    $0x98,%rsp
0010975c          4 pop    %rbx
0010975d          4 pop    %r12
0010975f          4 pop    %r13
00109761          4 pop    %r14
00109763          4 pop    %r15
00109765          4 pop    %rbp
00109766          4 ret
00109767          0 jne    10a49f <fn_4+0x1f1f>
0010976d          0 movzbl (%rdi),%r12d
00109771          0 jmp    109074 <fn_4+0xaf4>
00109776          4 movabs $0x1000000000000000,%rsi
00109780          4 add    $0xfffffffffffffffc,%rsi
00109784          4 and    %rax,%rsi
00109787          4 lea    0x0(,%rax,8),%rdi
0010978f          4 and    $0xffffffffffffffe0,%rdi
00109793          4 pxor   %xmm0,%xmm0
00109797          4 xor    %r8d,%r8d
0010979a          4 movdqa -0xf8982(%rip),%xmm1        # 10e20 <anon.dd6a8a796c10bf5c67fa0e87de5edd21.24.llvm.9568189375700981541+0x20>
001097a2          4 movdqa -0xf80aa(%rip),%xmm3        # 11700 <anon.dd6a8a796c10bf5c67fa0e87de5edd21.24.llvm.9568189375700981541+0x900>
001097aa          4 pxor   %xmm2,%xmm2
001097ae          4 xchg   %ax,%ax
001097b0     24,576 movdqu (%rcx,%r8,1),%xmm4
001097b6     24,576 movdqu 0x10(%rcx,%r8,1),%xmm5
001097bd     24,576 movdqa %xmm4,%xmm6
001097c1     24,576 paddq  %xmm1,%xmm6
001097c5     24,576 movdqa %xmm5,%xmm7
001097c9     24,576 paddq  %xmm1,%xmm7
001097cd     24,576 psrlq  $0x21,%xmm6
001097d2     24,576 psrlq  $0x21,%xmm7
001097d7     24,576 pandn  %xmm3,%xmm4
001097db     24,576 por    %xmm4,%xmm2
001097df     24,576 por    %xmm6,%xmm2
001097e3     24,576 pandn  %xmm3,%xmm5
001097e7     24,576 por    %xmm5,%xmm0
001097eb     24,576 por    %xmm7,%xmm0
001097ef     24,576 add    $0x20,%r8
001097f3     24,576 cmp    %r8,%rdi
001097f6     24,576 jne    1097b0 <fn_4+0x1230>
001097f8          4 por    %xmm2,%xmm0
001097fc          4 pshufd $0xee,%xmm0,%xmm1
00109801          4 por    %xmm0,%xmm1
00109805          4 movq   %xmm1,%rdi
0010980a          4 cmp    %rsi,%rax
0010980d          4 je     109845 <fn_4+0x12c5>
0010980f          0 mov    $0xffffffff,%r8d
00109815          0 mov    %rdi,%r9
00109818          0 nopl   0x0(%rax,%rax,1)
00109820          0 mov    (%rcx,%rsi,8),%rdi
00109824          0 lea    (%r8,%rdi,1),%r10
00109828          0 inc    %r10
0010982b          0 not    %edi
0010982d          0 shr    $0x21,%r10
00109831          0 or     %r9,%r10
00109834          0 and    $0x1,%edi
00109837          0 or     %r10,%rdi
0010983a          0 inc    %rsi
0010983d          0 mov    %rdi,%r9
00109840          0 cmp    %rsi,%rax
00109843          0 jne    109820 <fn_4+0x12a0>
00109845          4 test   %rdi,%rdi
00109848          4 je     10a352 <fn_4+0x1dd2>
0010984e          0 add    $0xfffffffffffffffe,%rbp
00109852          0 mov    $0x1,%r14d
00109858          0 mov    %rsp,%rax
0010985b          0 mov    %rax,0x88(%rsp)
00109863          0 mov    $0x1,%r12d
00109869          0 mov    $0x1,%r15d
0010986f          0 mov    %rbp,0x80(%rsp)
00109877          0 jmp    1098b5 <fn_4+0x1335>
00109879          0 nopl   0x0(%rax)
00109880          0 mov    0x18(%r14),%rax
00109884          0 mov    0x58(%rsp),%rcx
00109889          0 mov    %rcx,(%rax,%rbx,8)
0010988d          0 inc    %rbx
00109890          0 mov    %rbx,0x20(%r14)
00109894          0 mov    %rcx,%rbx
00109897          0 mov    0x78(%rsp),%r15
0010989c          0 add    $0x6,%r15
001098a0          0 add    $0x3,%r12
001098a4          0 mov    %rbx,%r14
001098a7          0 cmp    0x90(%rsp),%r15
001098af          0 ja     108d2a <fn_4+0x7aa>
001098b5          0 mov    %r15,0x78(%rsp)
001098ba          0 lea    -0x1(%r12),%r15
001098bf          0 cmp    0x10(%r13),%r15
001098c3          0 jae    109920 <fn_4+0x13a0>
001098c5          0 mov    0x8(%r13),%rax
001098c9          0 mov    -0x8(%rax,%r12,8),%rbx
001098ce          0 test   $0x1,%bl
001098d1          0 jne    1098dd <fn_4+0x135d>
001098d3          0 incq   -0x10(%rbx)
001098d7          0 je     10ae1e <fn_4+0x289e>
001098dd          0 cmp    %rbp,%r15
001098e0          0 jge    10996a <fn_4+0x13ea>
001098e6          0 test   %rbx,%rbx
001098e9          0 je     10ae71 <fn_4+0x28f1>
001098ef          0 cmp    0x10(%r13),%r12
001098f3          0 jae    1099a0 <fn_4+0x1420>
001098f9          0 mov    0x8(%r13),%rax
001098fd          0 mov    (%rax,%r12,8),%rbp
00109901          0 test   $0x1,%bpl
00109905          0 jne    1099ea <fn_4+0x146a>
0010990b          0 incq   -0x10(%rbp)
0010990f          0 jne    1099e1 <fn_4+0x1461>
00109915          0 jmp    10ae1e <fn_4+0x289e>
0010991a          0 nopw   0x0(%rax,%rax,1)
00109920          0 movabs $0x6f2074756f207865,%rax
0010992a          0 mov    %rax,0x8(%rsp)
0010992f          0 movabs $0xd765676e61722066,%rax
00109939          0 mov    %rax,0x10(%rsp)
0010993e          0 movabs $0x646e69207473696c,%rax
00109948          0 mov    %rax,(%rsp)
0010994c          0 movl   $0x6,0x18(%rsp)
00109954          0 mov    %rsp,%rdi
00109957          0 xor    %esi,%esi
00109959          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
0010995e          0 mov    %rax,%rbx
00109961          0 cmp    %rbp,%r15
00109964          0 jl     1098e6 <fn_4+0x1366>
0010996a          0 test   %rbx,%rbx
0010996d          0 je     10ae71 <fn_4+0x28f1>
00109973          0 cmp    0x10(%r13),%r12
00109977          0 jae    109a30 <fn_4+0x14b0>
0010997d          0 mov    0x8(%r13),%rax
00109981          0 mov    (%rax,%r12,8),%r15
00109985          0 test   $0x1,%r15b
00109989          0 jne    109a7a <fn_4+0x14fa>
0010998f          0 incq   -0x10(%r15)
00109993          0 jne    109a71 <fn_4+0x14f1>
00109999          0 jmp    10ae1e <fn_4+0x289e>
0010999e          0 xchg   %ax,%ax
001099a0          0 movabs $0x6f2074756f207865,%rax
001099aa          0 mov    %rax,0x8(%rsp)
001099af          0 movabs $0xd765676e61722066,%rax
001099b9          0 mov    %rax,0x10(%rsp)
001099be          0 movabs $0x646e69207473696c,%rax
001099c8          0 mov    %rax,(%rsp)
001099cc          0 movl   $0x6,0x18(%rsp)
001099d4          0 mov    %rsp,%rdi
001099d7          0 xor    %esi,%esi
001099d9          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
001099de          0 mov    %rax,%rbp
001099e1          0 test   %rbp,%rbp
001099e4          0 je     10ae63 <fn_4+0x28e3>
001099ea          0 test   $0x1,%bpl
001099ee          0 jne    109ac0 <fn_4+0x1540>
001099f4          0 mov    $0x5b,%esi
001099f9          0 mov    %rbp,%rdi
001099fc          0 mov    $0x2,%edx
00109a01          0 call   110e30 <imre_int_binary>
00109a06          0 mov    %rax,%r15
00109a09          0 lea    -0x10(%rbp),%rax
00109a0d          0 mov    %rax,(%rsp)
00109a11          0 decq   -0x10(%rbp)
00109a15          0 jne    109afb <fn_4+0x157b>
00109a1b          0 mov    %rsp,%rdi
00109a1e          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109a24          0 jmp    109afb <fn_4+0x157b>
00109a29          0 nopl   0x0(%rax)
00109a30          0 movabs $0x6f2074756f207865,%rax
00109a3a          0 mov    %rax,0x8(%rsp)
00109a3f          0 movabs $0xd765676e61722066,%rax
00109a49          0 mov    %rax,0x10(%rsp)
00109a4e          0 movabs $0x646e69207473696c,%rax
00109a58          0 mov    %rax,(%rsp)
00109a5c          0 movl   $0x6,0x18(%rsp)
00109a64          0 mov    %rsp,%rdi
00109a67          0 xor    %esi,%esi
00109a69          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
00109a6e          0 mov    %rax,%r15
00109a71          0 test   %r15,%r15
00109a74          0 je     10ae63 <fn_4+0x28e3>
00109a7a          0 test   $0x1,%r15b
00109a7e          0 jne    109b10 <fn_4+0x1590>
00109a84          0 mov    $0x5b,%esi
00109a89          0 mov    %r15,%rdi
00109a8c          0 mov    $0x2,%edx
00109a91          0 call   110e30 <imre_int_binary>
00109a96          0 mov    %rax,%rbp
00109a99          0 lea    -0x10(%r15),%rax
00109a9d          0 mov    %rax,(%rsp)
00109aa1          0 decq   -0x10(%r15)
00109aa5          0 jne    109b4b <fn_4+0x15cb>
00109aab          0 mov    %rsp,%rdi
00109aae          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109ab4          0 jmp    109b4b <fn_4+0x15cb>
00109ab9          0 nopl   0x0(%rax)
00109ac0          0 mov    %rbp,%rax
00109ac3          0 sar    $1,%rax
00109ac6          0 imul   $0x2d,%rax,%rax
00109aca          0 seto   %cl
00109acd          0 not    %cl
00109acf          0 mov    %rax,%rdx
00109ad2          0 movabs $0xc000000000000000,%rsi
00109adc          0 add    %rsi,%rdx
00109adf          0 sets   %dl
00109ae2          0 test   %dl,%cl
00109ae4          0 jne    109b5c <fn_4+0x15dc>
00109ae6          0 mov    $0x5b,%esi
00109aeb          0 mov    %rbp,%rdi
00109aee          0 mov    $0x2,%edx
00109af3          0 call   110e30 <imre_int_binary>
00109af8          0 mov    %rax,%r15
00109afb          0 mov    %ebx,%r13d
00109afe          0 and    $0x1,%r13d
00109b02          0 test   %r13d,%r15d
00109b05          0 jne    109b70 <fn_4+0x15f0>
00109b07          0 jmp    109b91 <fn_4+0x1611>
00109b0c          0 nopl   0x0(%rax)
00109b10          0 mov    %r15,%rax
00109b13          0 sar    $1,%rax
00109b16          0 imul   $0x2d,%rax,%rax
00109b1a          0 seto   %cl
00109b1d          0 not    %cl
00109b1f          0 mov    %rax,%rdx
00109b22          0 movabs $0xc000000000000000,%rsi
00109b2c          0 add    %rsi,%rdx
00109b2f          0 sets   %dl
00109b32          0 test   %dl,%cl
00109b34          0 jne    109bb0 <fn_4+0x1630>
00109b36          0 mov    $0x5b,%esi
00109b3b          0 mov    %r15,%rdi
00109b3e          0 mov    $0x2,%edx
00109b43          0 call   110e30 <imre_int_binary>
00109b48          0 mov    %rax,%rbp
00109b4b          0 mov    %ebx,%r15d
00109b4e          0 and    $0x1,%r15d
00109b52          0 test   %r15d,%ebp
00109b55          0 jne    109bc4 <fn_4+0x1644>
00109b57          0 jmp    109be9 <fn_4+0x1669>
00109b5c          0 lea    0x1(,%rax,2),%r15
00109b64          0 mov    %ebx,%r13d
00109b67          0 and    $0x1,%r13d
00109b6b          0 test   %r13d,%r15d
00109b6e          0 je     109b91 <fn_4+0x1611>
00109b70          0 mov    %rbx,%rcx
00109b73          0 sar    $1,%rcx
00109b76          0 mov    %r15,%rax
00109b79          0 sar    $1,%rax
00109b7c          0 add    %rcx,%rax
00109b7f          0 mov    %rax,%rcx
00109b82          0 movabs $0xc000000000000000,%rdx
00109b8c          0 add    %rdx,%rcx
00109b8f          0 js     109c09 <fn_4+0x1689>
00109b91          0 mov    %rbx,%rdi
00109b94          0 mov    %r15,%rsi
00109b97          0 xor    %edx,%edx
00109b99          0 call   110e30 <imre_int_binary>
00109b9e          0 mov    %rax,%rbp
00109ba1          0 test   %r13,%r13
00109ba4          0 mov    0x48(%rsp),%r13
00109ba9          0 je     109c1b <fn_4+0x169b>
00109bab          0 jmp    109c40 <fn_4+0x16c0>
00109bb0          0 lea    0x1(,%rax,2),%rbp
00109bb8          0 mov    %ebx,%r15d
00109bbb          0 and    $0x1,%r15d
00109bbf          0 test   %r15d,%ebp
00109bc2          0 je     109be9 <fn_4+0x1669>
00109bc4          0 mov    %rbx,%rcx
00109bc7          0 sar    $1,%rcx
00109bca          0 mov    %rbp,%rax
00109bcd          0 sar    $1,%rax
00109bd0          0 add    %rcx,%rax
00109bd3          0 mov    %rax,%rcx
00109bd6          0 movabs $0xc000000000000000,%rdx
00109be0          0 add    %rdx,%rcx
00109be3          0 js     109e4b <fn_4+0x18cb>
00109be9          0 mov    %rbx,%rdi
00109bec          0 mov    %rbp,%rsi
00109bef          0 xor    %edx,%edx
00109bf1          0 call   110e30 <imre_int_binary>
00109bf6          0 mov    %rax,0x58(%rsp)
00109bfb          0 test   %r15,%r15
00109bfe          0 je     109e5d <fn_4+0x18dd>
00109c04          0 jmp    109e80 <fn_4+0x1900>
00109c09          0 lea    0x1(,%rax,2),%rbp
00109c11          0 test   %r13,%r13
00109c14          0 mov    0x48(%rsp),%r13
00109c19          0 jne    109c40 <fn_4+0x16c0>
00109c1b          0 lea    -0x10(%rbx),%rax
00109c1f          0 mov    %rax,(%rsp)
00109c23          0 decq   -0x10(%rbx)
00109c27          0 jne    109c40 <fn_4+0x16c0>
00109c29          0 mov    %rsp,%rdi
00109c2c          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109c32          0 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
00109c40          0 test   %r15,%r15
00109c43          0 sete   %al
00109c46          0 or     %r15b,%al
00109c49          0 test   $0x1,%al
00109c4b          0 jne    109c70 <fn_4+0x16f0>
00109c4d          0 lea    -0x10(%r15),%rax
00109c51          0 mov    %rax,(%rsp)
00109c55          0 decq   -0x10(%r15)
00109c59          0 jne    109c70 <fn_4+0x16f0>
00109c5b          0 mov    %rsp,%rdi
00109c5e          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109c64          0 data16 data16 cs nopw 0x0(%rax,%rax,1)
00109c70          0 lea    0x1(%r12),%rax
00109c75          0 cmp    0x10(%r13),%rax
00109c79          0 jae    109ca0 <fn_4+0x1720>
00109c7b          0 mov    0x8(%r13),%rax
00109c7f          0 mov    0x8(%rax,%r12,8),%r13
00109c84          0 test   $0x1,%r13b
00109c88          0 jne    109cea <fn_4+0x176a>
00109c8a          0 incq   -0x10(%r13)
00109c8e          0 jne    109ce1 <fn_4+0x1761>
00109c90          0 jmp    10ae1e <fn_4+0x289e>
00109c95          0 data16 cs nopw 0x0(%rax,%rax,1)
00109ca0          0 movabs $0x6f2074756f207865,%rax
00109caa          0 mov    %rax,0x8(%rsp)
00109caf          0 movabs $0xd765676e61722066,%rax
00109cb9          0 mov    %rax,0x10(%rsp)
00109cbe          0 movabs $0x646e69207473696c,%rax
00109cc8          0 mov    %rax,(%rsp)
00109ccc          0 movl   $0x6,0x18(%rsp)
00109cd4          0 mov    %rsp,%rdi
00109cd7          0 xor    %esi,%esi
00109cd9          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
00109cde          0 mov    %rax,%r13
00109ce1          0 test   %r13,%r13
00109ce4          0 je     10afb7 <fn_4+0x2a37>
00109cea          0 test   $0x1,%r13b
00109cee          0 jne    109d30 <fn_4+0x17b0>
00109cf0          0 mov    $0x5b,%esi
00109cf5          0 mov    %r13,%rdi
00109cf8          0 mov    $0x2,%edx
00109cfd          0 call   110e30 <imre_int_binary>
00109d02          0 mov    %rax,%r15
00109d05          0 lea    -0x10(%r13),%rax
00109d09          0 mov    %rax,(%rsp)
00109d0d          0 decq   -0x10(%r13)
00109d11          0 jne    109d20 <fn_4+0x17a0>
00109d13          0 mov    %rsp,%rdi
00109d16          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109d1c          0 nopl   0x0(%rax)
00109d20          0 test   $0x1,%r15b
00109d24          0 jne    109d81 <fn_4+0x1801>
00109d26          0 jmp    109da5 <fn_4+0x1825>
00109d28          0 nopl   0x0(%rax,%rax,1)
00109d30          0 mov    %r13,%rax
00109d33          0 sar    $1,%rax
00109d36          0 imul   $0x2d,%rax,%rax
00109d3a          0 seto   %cl
00109d3d          0 not    %cl
00109d3f          0 mov    %rax,%rdx
00109d42          0 movabs $0xc000000000000000,%rsi
00109d4c          0 add    %rsi,%rdx
00109d4f          0 sets   %dl
00109d52          0 test   %dl,%cl
00109d54          0 jne    109d73 <fn_4+0x17f3>
00109d56          0 mov    $0x5b,%esi
00109d5b          0 mov    %r13,%rdi
00109d5e          0 mov    $0x2,%edx
00109d63          0 call   110e30 <imre_int_binary>
00109d68          0 mov    %rax,%r15
00109d6b          0 test   $0x1,%r15b
00109d6f          0 jne    109d81 <fn_4+0x1801>
00109d71          0 jmp    109da5 <fn_4+0x1825>
00109d73          0 lea    0x1(,%rax,2),%r15
00109d7b          0 test   $0x1,%r15b
00109d7f          0 je     109da5 <fn_4+0x1825>
00109d81          0 mov    %r15,%rax
00109d84          0 sar    $1,%rax
00109d87          0 imul   $0x2d,%rax,%rax
00109d8b          0 seto   %cl
00109d8e          0 mov    %rax,%rdx
00109d91          0 movabs $0xc000000000000000,%rsi
00109d9b          0 add    %rsi,%rdx
00109d9e          0 setns  %dl
00109da1          0 or     %cl,%dl
00109da3          0 je     109dee <fn_4+0x186e>
00109da5          0 mov    $0x5b,%esi
00109daa          0 mov    %r15,%rdi
00109dad          0 mov    $0x2,%edx
00109db2          0 call   110e30 <imre_int_binary>
00109db7          0 mov    %rax,%r13
00109dba          0 test   %r15,%r15
00109dbd          0 sete   %al
00109dc0          0 or     %r15b,%al
00109dc3          0 test   $0x1,%al
00109dc5          0 jne    109de0 <fn_4+0x1860>
00109dc7          0 lea    -0x10(%r15),%rax
00109dcb          0 mov    %rax,(%rsp)
00109dcf          0 decq   -0x10(%r15)
00109dd3          0 jne    109de0 <fn_4+0x1860>
00109dd5          0 mov    %rsp,%rdi
00109dd8          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109dde          0 xchg   %ax,%ax
00109de0          0 mov    %ebp,%r15d
00109de3          0 and    $0x1,%r15d
00109de7          0 test   %r15d,%r13d
00109dea          0 jne    109e02 <fn_4+0x1882>
00109dec          0 jmp    109e27 <fn_4+0x18a7>
00109dee          0 lea    0x1(,%rax,2),%r13
00109df6          0 mov    %ebp,%r15d
00109df9          0 and    $0x1,%r15d
00109dfd          0 test   %r15d,%r13d
00109e00          0 je     109e27 <fn_4+0x18a7>
00109e02          0 mov    %rbp,%rcx
00109e05          0 sar    $1,%rcx
00109e08          0 mov    %r13,%rax
00109e0b          0 sar    $1,%rax
00109e0e          0 add    %rcx,%rax
00109e11          0 mov    %rax,%rcx
00109e14          0 movabs $0xc000000000000000,%rdx
00109e1e          0 add    %rdx,%rcx
00109e21          0 js     109f98 <fn_4+0x1a18>
00109e27          0 mov    %rbp,%rdi
00109e2a          0 mov    %r13,%rsi
00109e2d          0 xor    %edx,%edx
00109e2f          0 call   110e30 <imre_int_binary>
00109e34          0 mov    %rax,%rbx
00109e37          0 test   %rbp,%rbp
00109e3a          0 sete   %al
00109e3d          0 or     %r15b,%al
00109e40          0 je     109fab <fn_4+0x1a2b>
00109e46          0 jmp    109fd0 <fn_4+0x1a50>
00109e4b          0 lea    0x1(,%rax,2),%rax
00109e53          0 mov    %rax,0x58(%rsp)
00109e58          0 test   %r15,%r15
00109e5b          0 jne    109e80 <fn_4+0x1900>
00109e5d          0 lea    -0x10(%rbx),%rax
00109e61          0 mov    %rax,(%rsp)
00109e65          0 decq   -0x10(%rbx)
00109e69          0 jne    109e80 <fn_4+0x1900>
00109e6b          0 mov    %rsp,%rdi
00109e6e          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109e74          0 data16 data16 cs nopw 0x0(%rax,%rax,1)
00109e80          0 test   %rbp,%rbp
00109e83          0 sete   %al
00109e86          0 or     %bpl,%al
00109e89          0 test   $0x1,%al
00109e8b          0 mov    0x58(%rsp),%rbx
00109e90          0 jne    109eb0 <fn_4+0x1930>
00109e92          0 lea    -0x10(%rbp),%rax
00109e96          0 mov    %rax,(%rsp)
00109e9a          0 decq   -0x10(%rbp)
00109e9e          0 jne    109eb0 <fn_4+0x1930>
00109ea0          0 mov    %rsp,%rdi
00109ea3          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109ea9          0 nopl   0x0(%rax)
00109eb0          0 test   %r14,%r14
00109eb3          0 sete   %al
00109eb6          0 or     %r14b,%al
00109eb9          0 test   $0x1,%al
00109ebb          0 mov    0x80(%rsp),%rbp
00109ec3          0 jne    109ee0 <fn_4+0x1960>
00109ec5          0 lea    -0x10(%r14),%rax
00109ec9          0 mov    %rax,(%rsp)
00109ecd          0 decq   -0x10(%r14)
00109ed1          0 jne    109ee0 <fn_4+0x1960>
00109ed3          0 mov    %rsp,%rdi
00109ed6          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109edc          0 nopl   0x0(%rax)
00109ee0          0 test   $0x1,%bl
00109ee3          0 jne    109f00 <fn_4+0x1980>
00109ee5          0 mov    $0x1ff,%esi
00109eea          0 mov    %rbx,%rdi
00109eed          0 call   1148a0 <imre_int_compare>
00109ef2          0 test   %eax,%eax
00109ef4          0 mov    0x50(%rsp),%r14
00109ef9          0 jle    109f12 <fn_4+0x1992>
00109efb          0 jmp    10a4aa <fn_4+0x1f2a>
00109f00          0 cmp    $0x200,%rbx
00109f07          0 mov    0x50(%rsp),%r14
00109f0c          0 jge    10a4aa <fn_4+0x1f2a>
00109f12          0 mov    0x10(%r14),%r15
00109f16          0 mov    0x20(%r14),%rsi
00109f1a          0 cmp    %rsi,%r15
00109f1d          0 jne    10a216 <fn_4+0x1c96>
00109f23          0 lea    (%rsi,%rsi,1),%r15
00109f27          0 cmp    $0x5,%r15
00109f2b          0 mov    $0x4,%eax
00109f30          0 cmovb  %rax,%r15
00109f34          0 lea    0x0(,%r15,8),%r14
00109f3c          0 movabs $0x1000000000000000,%rax
00109f46          0 dec    %rax
00109f49          0 cmp    %rax,%rsi
00109f4c          0 seta   %al
00109f4f          0 movabs $0x7ffffffffffffff8,%rcx
00109f59          0 cmp    %rcx,%r14
00109f5c          0 seta   %cl
00109f5f          0 or     %al,%cl
00109f61          0 jne    10a2fc <fn_4+0x1d7c>
00109f67          0 test   %rsi,%rsi
00109f6a          0 je     10a1f3 <fn_4+0x1c73>
00109f70          0 mov    0x50(%rsp),%rax
00109f75          0 mov    0x18(%rax),%rdi
00109f79          0 shl    $0x3,%rsi
00109f7d          0 mov    $0x8,%edx
00109f82          0 mov    %r14,%rcx
00109f85          0 call   77540 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_realloc>
00109f8a          0 test   %rax,%rax
00109f8d          0 jne    10a209 <fn_4+0x1c89>
00109f93          0 jmp    10b518 <fn_4+0x2f98>
00109f98          0 lea    0x1(,%rax,2),%rbx
00109fa0          0 test   %rbp,%rbp
00109fa3          0 sete   %al
00109fa6          0 or     %r15b,%al
00109fa9          0 jne    109fd0 <fn_4+0x1a50>
00109fab          0 lea    -0x10(%rbp),%rax
00109faf          0 mov    %rax,(%rsp)
00109fb3          0 decq   -0x10(%rbp)
00109fb7          0 jne    109fd0 <fn_4+0x1a50>
00109fb9          0 mov    %rsp,%rdi
00109fbc          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109fc2          0 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
00109fd0          0 test   %r13,%r13
00109fd3          0 sete   %al
00109fd6          0 or     %r13b,%al
00109fd9          0 test   $0x1,%al
00109fdb          0 jne    10a000 <fn_4+0x1a80>
00109fdd          0 lea    -0x10(%r13),%rax
00109fe1          0 mov    %rax,(%rsp)
00109fe5          0 decq   -0x10(%r13)
00109fe9          0 jne    10a000 <fn_4+0x1a80>
00109feb          0 mov    %rsp,%rdi
00109fee          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
00109ff4          0 data16 data16 cs nopw 0x0(%rax,%rax,1)
0010a000          0 test   %r14,%r14
0010a003          0 sete   %al
0010a006          0 or     %r14b,%al
0010a009          0 test   $0x1,%al
0010a00b          0 mov    0x48(%rsp),%r13
0010a010          0 jne    10a030 <fn_4+0x1ab0>
0010a012          0 lea    -0x10(%r14),%rax
0010a016          0 mov    %rax,(%rsp)
0010a01a          0 decq   -0x10(%r14)
0010a01e          0 jne    10a030 <fn_4+0x1ab0>
0010a020          0 mov    %rsp,%rdi
0010a023          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
0010a029          0 nopl   0x0(%rax)
0010a030          0 test   $0x1,%bl
0010a033          0 jne    10a050 <fn_4+0x1ad0>
0010a035          0 mov    $0x1ffff,%esi
0010a03a          0 mov    %rbx,%rdi
0010a03d          0 call   1148a0 <imre_int_compare>
0010a042          0 test   %eax,%eax
0010a044          0 mov    0x50(%rsp),%r14
0010a049          0 jle    10a062 <fn_4+0x1ae2>
0010a04b          0 jmp    10a5e1 <fn_4+0x2061>
0010a050          0 cmp    $0x20000,%rbx
0010a057          0 mov    0x50(%rsp),%r14
0010a05c          0 jge    10a5e1 <fn_4+0x2061>
0010a062          0 incq   (%r14)
0010a065          0 je     10ae1e <fn_4+0x289e>
0010a06b          0 test   %rbx,%rbx
0010a06e          0 sete   %r15b
0010a072          0 or     %bl,%r15b
0010a075          0 test   $0x1,%r15b
0010a079          0 je     10a0b0 <fn_4+0x1b30>
0010a07b          0 test   $0x1,%bl
0010a07e          0 je     10a0ba <fn_4+0x1b3a>
0010a080          0 xor    %edi,%edi
0010a082          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
0010a087          0 cmpb   $0x0,(%rax)
0010a08a          0 jne    10b12a <fn_4+0x2baa>
0010a090          0 mov    %rbx,%r13
0010a093          0 sar    $0x8,%r13
0010a097          0 or     $0x1,%r13
0010a09b          0 mov    %ebx,%ebp
0010a09d          0 and    $0x1ff,%ebp
0010a0a3          0 mov    0x78(%rsp),%r15
0010a0a8          0 jmp    10a140 <fn_4+0x1bc0>
0010a0ad          0 nopl   (%rax)
0010a0b0          0 incq   -0x10(%rbx)
0010a0b4          0 je     10ae1e <fn_4+0x289e>
0010a0ba          0 mov    $0x201,%esi
0010a0bf          0 mov    %rbx,%rdi
0010a0c2          0 mov    $0x3,%edx
0010a0c7          0 call   110e30 <imre_int_binary>
0010a0cc          0 mov    %rax,%r13
0010a0cf          0 xor    %edi,%edi
0010a0d1          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
0010a0d6          0 cmpb   $0x0,(%rax)
0010a0d9          0 jne    10b11b <fn_4+0x2b9b>
0010a0df          0 mov    %rax,%r14
0010a0e2          0 mov    $0x201,%esi
0010a0e7          0 mov    %rbx,%rdi
0010a0ea          0 mov    $0x4,%edx
0010a0ef          0 call   110e30 <imre_int_binary>
0010a0f4          0 cmpb   $0x0,(%r14)
0010a0f8          0 jne    10b131 <fn_4+0x2bb1>
0010a0fe          0 mov    %rax,%rbp
0010a101          0 test   $0x1,%r15b
0010a105          0 je     10a113 <fn_4+0x1b93>
0010a107          0 mov    0x50(%rsp),%r14
0010a10c          0 mov    0x78(%rsp),%r15
0010a111          0 jmp    10a140 <fn_4+0x1bc0>
0010a113          0 lea    -0x10(%rbx),%rax
0010a117          0 mov    %rax,(%rsp)
0010a11b          0 decq   -0x10(%rbx)
0010a11f          0 mov    0x50(%rsp),%r14
0010a124          0 mov    0x78(%rsp),%r15
0010a129          0 jne    10a140 <fn_4+0x1bc0>
0010a12b          0 mov    %rsp,%rdi
0010a12e          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
0010a134          0 data16 data16 cs nopw 0x0(%rax,%rax,1)
0010a140          0 mov    0x10(%r14),%rsi
0010a144          0 mov    0x20(%r14),%rcx
0010a148          0 mov    %rsi,%rax
0010a14b          0 sub    %rcx,%rax
0010a14e          0 cmp    $0x2,%rax
0010a152          0 jae    10a1e0 <fn_4+0x1c60>
0010a158          0 cmp    $0xfffffffffffffffd,%rcx
0010a15c          0 ja     10a335 <fn_4+0x1db5>
0010a162          0 add    $0x2,%rcx
0010a166          0 lea    (%rsi,%rsi,1),%rax
0010a16a          0 cmp    %rax,%rcx
0010a16d          0 cmovbe %rax,%rcx
0010a171          0 cmp    $0x5,%rcx
0010a175          0 mov    $0x4,%r15d
0010a17b          0 cmovae %rcx,%r15
0010a17f          0 lea    0x0(,%r15,8),%r14
0010a187          0 shr    $0x3d,%rcx
0010a18b          0 setne  %al
0010a18e          0 movabs $0x7ffffffffffffff8,%rcx
0010a198          0 cmp    %rcx,%r14
0010a19b          0 seta   %cl
0010a19e          0 or     %al,%cl
0010a1a0          0 jne    10a327 <fn_4+0x1da7>
0010a1a6          0 test   %rsi,%rsi
0010a1a9          0 je     10a24a <fn_4+0x1cca>
0010a1af          0 mov    0x50(%rsp),%rax
0010a1b4          0 mov    0x18(%rax),%rdi
0010a1b8          0 shl    $0x3,%rsi
0010a1bc          0 mov    $0x8,%edx
0010a1c1          0 mov    %r14,%rcx
0010a1c4          0 call   77540 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_realloc>
0010a1c9          0 test   %rax,%rax
0010a1cc          0 jne    10a260 <fn_4+0x1ce0>
0010a1d2          0 jmp    10b52a <fn_4+0x2faa>
0010a1d7          0 nopw   0x0(%rax,%rax,1)
0010a1e0          0 mov    0x18(%r14),%rax
0010a1e4          0 test   $0x1,%r13b
0010a1e8          0 je     10a27c <fn_4+0x1cfc>
0010a1ee          0 jmp    10a286 <fn_4+0x1d06>
0010a1f3          0 mov    $0x8,%esi
0010a1f8          0 mov    %r14,%rdi
0010a1fb          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010a200          0 test   %rax,%rax
0010a203          0 je     10b518 <fn_4+0x2f98>
0010a209          0 mov    0x50(%rsp),%r14
0010a20e          0 mov    %rax,0x18(%r14)
0010a212          0 mov    %r15,0x10(%r14)
0010a216          0 test   $0x1,%bl
0010a219          0 jne    10a22d <fn_4+0x1cad>
0010a21b          0 incq   -0x10(%rbx)
0010a21f          0 je     10ae1e <fn_4+0x289e>
0010a225          0 mov    0x40(%rsp),%rax
0010a22a          0 mov    (%rax),%r15
0010a22d          0 mov    0x20(%r14),%rbx
0010a231          0 cmp    %r15,%rbx
0010a234          0 jne    109880 <fn_4+0x1300>
0010a23a          0 mov    0x40(%rsp),%rdi
0010a23f          0 addr32 call 12ffb0 <_RNvMs4_NtCscJq9HK9IcCJ_5alloc7raw_vecINtB5_6RawVecINtNtCs6SLOTazmNXq_4core6option6OptionINtNtNtCs3V9firECmdE_12imre_runtime7objects8mappings5EntryINtNtB7_2rc2RcINtNtB7_3vec3VechEEuEEE8grow_oneB1v_>
0010a245          0 jmp    109880 <fn_4+0x1300>
0010a24a          0 mov    $0x8,%esi
0010a24f          0 mov    %r14,%rdi
0010a252          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010a257          0 test   %rax,%rax
0010a25a          0 je     10b52a <fn_4+0x2faa>
0010a260          0 mov    0x50(%rsp),%r14
0010a265          0 mov    %rax,0x18(%r14)
0010a269          0 mov    %r15,0x10(%r14)
0010a26d          0 mov    0x20(%r14),%rcx
0010a271          0 mov    0x78(%rsp),%r15
0010a276          0 test   $0x1,%r13b
0010a27a          0 jne    10a286 <fn_4+0x1d06>
0010a27c          0 incq   -0x10(%r13)
0010a280          0 je     10ae1e <fn_4+0x289e>
0010a286          0 mov    %r13,(%rax,%rcx,8)
0010a28a          0 test   $0x1,%bpl
0010a28e          0 jne    10a29a <fn_4+0x1d1a>
0010a290          0 incq   -0x10(%rbp)
0010a294          0 je     10ae1e <fn_4+0x289e>
0010a29a          0 mov    %rbp,0x8(%rax,%rcx,8)
0010a29f          0 add    $0x2,%rcx
0010a2a3          0 mov    %rcx,0x20(%r14)
0010a2a7          0 test   %r13,%r13
0010a2aa          0 sete   %al
0010a2ad          0 or     %r13b,%al
0010a2b0          0 test   $0x1,%al
0010a2b2          0 mov    0x80(%rsp),%rbp
0010a2ba          0 jne    10a2e0 <fn_4+0x1d60>
0010a2bc          0 lea    -0x10(%r13),%rax
0010a2c0          0 mov    %rax,(%rsp)
0010a2c4          0 decq   -0x10(%r13)
0010a2c8          0 jne    10a2e0 <fn_4+0x1d60>
0010a2ca          0 mov    %rsp,%rdi
0010a2cd          0 addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
0010a2d3          0 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
0010a2e0          0 mov    %r14,(%rsp)
0010a2e4          0 decq   (%r14)
0010a2e7          0 jne    10a2f2 <fn_4+0x1d72>
0010a2e9          0 mov    %rsp,%rdi
0010a2ec          0 addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12imre_runtime4ListE9drop_slowBF_>
0010a2f2          0 mov    0x48(%rsp),%r13
0010a2f7          0 jmp    10989c <fn_4+0x131c>
0010a2fc          0 xor    %r14d,%r14d
0010a2ff          0 mov    0x88(%rsp),%rax
0010a307          0 mov    %r14,(%rax)
0010a30a          0 lea    -0xdf7a9(%rip),%rdi        # 2ab68 <anon.07dd289d6752232cc34d2640517a38ff.14.llvm.14548151582184166452>
0010a311          0 lea    -0xdf7a5(%rip),%rdx        # 2ab73 <anon.07dd289d6752232cc34d2640517a38ff.15.llvm.14548151582184166452>
0010a318          0 mov    $0xb,%esi
0010a31d          0 mov    $0x16,%ecx
0010a322          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010a327          0 xor    %r14d,%r14d
0010a32a          0 mov    0x88(%rsp),%rax
0010a332          0 mov    %r14,(%rax)
0010a335          0 lea    -0xdf7d4(%rip),%rdi        # 2ab68 <anon.07dd289d6752232cc34d2640517a38ff.14.llvm.14548151582184166452>
0010a33c          0 lea    -0xdf7d0(%rip),%rdx        # 2ab73 <anon.07dd289d6752232cc34d2640517a38ff.15.llvm.14548151582184166452>
0010a343          0 mov    $0xb,%esi
0010a348          0 mov    $0x16,%ecx
0010a34d          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010a352          4 add    %rdx,%rdx
0010a355          4 cmp    $0x7ffe,%rdx
0010a35c          4 mov    $0x7ffe,%r12d
0010a362          4 cmovb  %rdx,%r12
0010a366          4 cmpq   $0x0,0x20(%r14)
0010a36b          4 jne    10a449 <fn_4+0x1ec9>
0010a371          4 add    $0x2,%r12
0010a375          4 cmp    %r12,0x10(%r14)
0010a379          4 jae    10a449 <fn_4+0x1ec9>
0010a37f          4 mov    %rbp,0x80(%rsp)
0010a387          4 data16 data16 data16 data16 mov %fs:0x0,%rax
0010a394          4 lea    -0xf0(%rax),%rbp
0010a39b          4 movzbl -0xb8(%rax),%eax
0010a3a2          4 mov    $0x8,%r15d
0010a3a8          4 test   %eax,%eax
0010a3aa          4 jne    10b1da <fn_4+0x2c5a>
0010a3b0          4 cmpq   $0x0,0x0(%rbp)
0010a3b5          4 je     10b207 <fn_4+0x2c87>
0010a3bb          1 xor    %ebx,%ebx
0010a3bd          1 xor    %r13d,%r13d
0010a3c0          1 mov    $0x8,%ecx
0010a3c5          1 mov    $0x8,%r8d
0010a3cb          1 mov    0x40(%rsp),%rdi
0010a3d0          1 xor    %esi,%esi
0010a3d2          1 mov    %r12,%rdx
0010a3d5          1 call   12fe60 <_RNvMs2_NtCscJq9HK9IcCJ_5alloc7raw_vecNtB5_11RawVecInner17try_reserve_exactCs3V9firECmdE_12imre_runtime>
0010a3da          4 mov    %r13,(%rsp)
0010a3de          4 mov    %r15,0x8(%rsp)
0010a3e3          4 mov    %rbx,0x10(%rsp)
0010a3e8          4 test   %rbx,%rbx
0010a3eb          4 je     10a428 <fn_4+0x1ea8>
0010a3ed          0 lea    0x8(%r15),%r12
0010a3f1          0 lea    0x60(%rsp),%r14
0010a3f6          0 lea    0x2a473(%rip),%rbp        # 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12imre_runtime>
0010a3fd          0 jmp    10a409 <fn_4+0x1e89>
0010a3ff          0 nop
0010a400          0 add    $0x8,%r12
0010a404          0 dec    %rbx
0010a407          0 je     10a428 <fn_4+0x1ea8>
0010a409          0 mov    -0x8(%r12),%rax
0010a40e          0 test   $0x1,%al
0010a410          0 jne    10a400 <fn_4+0x1e80>
0010a412          0 lea    -0x10(%rax),%rcx
0010a416          0 mov    %rcx,0x60(%rsp)
0010a41b          0 decq   -0x10(%rax)
0010a41f          0 jne    10a400 <fn_4+0x1e80>
0010a421          0 mov    %r14,%rdi
0010a424          0 call   *%rbp
0010a426          0 jmp    10a400 <fn_4+0x1e80>
0010a428          4 test   %r13,%r13
0010a42b          4 mov    0x80(%rsp),%rbp
0010a433          4 je     10a449 <fn_4+0x1ec9>
0010a435          0 shl    $0x3,%r13
0010a439          0 mov    $0x8,%edx
0010a43e          0 mov    %r15,%rdi
0010a441          0 mov    %r13,%rsi
0010a444          0 call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
0010a449          4 add    $0xfffffffffffffffe,%rbp
0010a44d          4 mov    $0x1,%ebx
0010a452          4 mov    %rsp,%rax
0010a455          4 mov    %rax,0x78(%rsp)
0010a45a          4 mov    $0x1,%r15d
0010a460          4 mov    $0x1,%r14d
0010a466          4 mov    0x48(%rsp),%r13
0010a46b          4 mov    %rbp,0x80(%rsp)
0010a473          4 jmp    10a74f <fn_4+0x21cf>
0010a478          0 xor    %r12d,%r12d
0010a47b          0 xor    %r13d,%r13d
0010a47e          0 jmp    10884e <fn_4+0x2ce>
0010a483          0 jne    10aba0 <fn_4+0x2620>
0010a489          0 movzbl (%rax),%ebp
0010a48c          0 jmp    1089d5 <fn_4+0x455>
0010a491          0 jne    10abaa <fn_4+0x262a>
0010a497          0 movzbl (%rdi),%ebp
0010a49a          0 jmp    10948c <fn_4+0xf0c>
0010a49f          0 xor    %r15d,%r15d
0010a4a2          0 xor    %r12d,%r12d
0010a4a5          0 jmp    109077 <fn_4+0xaf7>
0010a4aa          0 mov    $0x28,%edi
0010a4af          0 mov    $0x8,%esi
0010a4b4          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010a4b9          0 test   %rax,%rax
0010a4bc          0 je     10b311 <fn_4+0x2d91>
0010a4c2          0 movq   $0x1,(%rax)
0010a4c9          0 movq   $0x1,0x8(%rax)
0010a4d1          0 pxor   %xmm0,%xmm0
0010a4d5          0 movdqu %xmm0,0x10(%rax)
0010a4da          0 movabs $0xc000000000000000,%rcx
0010a4e4          0 mov    %rcx,0x20(%rax)
0010a4e8          0 movq   $0x1,(%rsp)
0010a4f0          0 movq   $0x1,0x8(%rsp)
0010a4f9          0 mov    %rax,0x10(%rsp)
0010a4fe          0 movq   $0x0,0x18(%rsp)
0010a507          0 movl   $0x8,0x20(%rsp)
0010a50f          0 movb   $0x0,0x24(%rsp)
0010a514          0 movb   $0x8,0x39(%rsp)
0010a519          0 mov    $0x40,%edi
0010a51e          0 mov    $0x8,%esi
0010a523          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010a528          0 test   %rax,%rax
0010a52b          0 je     10b321 <fn_4+0x2da1>
0010a531          0 mov    %rax,%r12
0010a534          0 movdqu (%rsp),%xmm0
0010a539          0 movdqu 0x10(%rsp),%xmm1
0010a53f          0 movdqu 0x20(%rsp),%xmm2
0010a545          0 movdqu 0x30(%rsp),%xmm3
0010a54b          0 movdqu %xmm3,0x30(%rax)
0010a550          0 movdqu %xmm2,0x20(%rax)
0010a555          0 movdqu %xmm1,0x10(%rax)
0010a55a          0 movdqu %xmm0,(%rax)
0010a55e          0 cmpb   $0x8,0x39(%rax)
0010a562          0 jne    10b346 <fn_4+0x2dc6>
0010a568          0 incq   (%r12)
0010a56c          0 je     10ae1e <fn_4+0x289e>
0010a572          0 mov    %r12,0x60(%rsp)
0010a577          0 xor    %edi,%edi
0010a579          0 call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
0010a57e          0 test   %rax,%rax
0010a581          0 je     10b574 <fn_4+0x2ff4>
0010a587          0 mov    %r12,(%rsp)
0010a58b          0 cmpq   $0x0,(%rax)
0010a58f          0 jne    10b395 <fn_4+0x2e15>
0010a595          0 mov    0x8(%rax),%rbx
0010a599          0 mov    %r12,0x8(%rax)
0010a59d          0 mov    %rsp,%rdi
0010a5a0          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
0010a5a5          0 movb   $0x1,(%rax)
0010a5a8          0 mov    %rbx,(%rsp)
0010a5ac          0 test   %rbx,%rbx
0010a5af          0 je     10a5bf <fn_4+0x203f>
0010a5b1          0 decq   (%rbx)
0010a5b4          0 jne    10a5bf <fn_4+0x203f>
0010a5b6          0 mov    %rsp,%rdi
0010a5b9          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010a5bf          0 mov    %r12,(%rsp)
0010a5c3          0 decq   (%r12)
0010a5c7          0 jne    10a5d2 <fn_4+0x2052>
0010a5c9          0 mov    %rsp,%rdi
0010a5cc          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010a5d2          0 mov    0x40(%rsp),%r12
0010a5d7          0 mov    0x58(%rsp),%rbx
0010a5dc          0 jmp    1091b6 <fn_4+0xc36>
0010a5e1          0 mov    $0x28,%edi
0010a5e6          0 mov    $0x8,%esi
0010a5eb          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010a5f0          0 test   %rax,%rax
0010a5f3          0 je     10b336 <fn_4+0x2db6>
0010a5f9          0 movq   $0x1,(%rax)
0010a600          0 movq   $0x1,0x8(%rax)
0010a608          0 pxor   %xmm0,%xmm0
0010a60c          0 movdqu %xmm0,0x10(%rax)
0010a611          0 movabs $0xc000000000000000,%rcx
0010a61b          0 mov    %rcx,0x20(%rax)
0010a61f          0 movq   $0x1,(%rsp)
0010a627          0 movq   $0x1,0x8(%rsp)
0010a630          0 mov    %rax,0x10(%rsp)
0010a635          0 movq   $0x0,0x18(%rsp)
0010a63e          0 movl   $0x8,0x20(%rsp)
0010a646          0 movb   $0x0,0x24(%rsp)
0010a64b          0 movb   $0x8,0x39(%rsp)
0010a650          0 mov    $0x40,%edi
0010a655          0 mov    $0x8,%esi
0010a65a          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010a65f          0 test   %rax,%rax
0010a662          0 je     10b363 <fn_4+0x2de3>
0010a668          0 mov    %rax,%r12
0010a66b          0 movdqu (%rsp),%xmm0
0010a670          0 movdqu 0x10(%rsp),%xmm1
0010a676          0 movdqu 0x20(%rsp),%xmm2
0010a67c          0 movdqu 0x30(%rsp),%xmm3
0010a682          0 movdqu %xmm3,0x30(%rax)
0010a687          0 movdqu %xmm2,0x20(%rax)
0010a68c          0 movdqu %xmm1,0x10(%rax)
0010a691          0 movdqu %xmm0,(%rax)
0010a695          0 cmpb   $0x8,0x39(%rax)
0010a699          0 jne    10b378 <fn_4+0x2df8>
0010a69f          0 incq   (%r12)
0010a6a3          0 je     10ae1e <fn_4+0x289e>
0010a6a9          0 mov    %r12,0x60(%rsp)
0010a6ae          0 xor    %edi,%edi
0010a6b0          0 call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
0010a6b5          0 test   %rax,%rax
0010a6b8          0 je     10b592 <fn_4+0x3012>
0010a6be          0 mov    %r12,(%rsp)
0010a6c2          0 cmpq   $0x0,(%rax)
0010a6c6          0 jne    10b3a2 <fn_4+0x2e22>
0010a6cc          0 mov    %rbx,%r14
0010a6cf          0 mov    0x8(%rax),%rbx
0010a6d3          0 mov    %r12,0x8(%rax)
0010a6d7          0 mov    %rsp,%rdi
0010a6da          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
0010a6df          0 movb   $0x1,(%rax)
0010a6e2          0 mov    %rbx,(%rsp)
0010a6e6          0 test   %rbx,%rbx
0010a6e9          0 je     10a6f9 <fn_4+0x2179>
0010a6eb          0 decq   (%rbx)
0010a6ee          0 jne    10a6f9 <fn_4+0x2179>
0010a6f0          0 mov    %rsp,%rdi
0010a6f3          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010a6f9          0 mov    %r12,(%rsp)
0010a6fd          0 decq   (%r12)
0010a701          0 jne    10ae11 <fn_4+0x2891>
0010a707          0 mov    %rsp,%rdi
0010a70a          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010a710          0 jmp    10ae11 <fn_4+0x2891>
0010a715          0 mov    %r12,%rbx
0010a718          0 mov    0x80(%rsp),%rbp
0010a720          0 mov    0x50(%rsp),%rcx
0010a725          0 mov    0x18(%rcx),%rax
0010a729          0 mov    %rbx,(%rax,%r13,8)
0010a72d          0 inc    %r13
0010a730          0 mov    %r13,0x20(%rcx)
0010a734          0 mov    0x48(%rsp),%r13
0010a739          0 add    $0x6,%r14
0010a73d          0 add    $0x3,%r15
0010a741          0 cmp    0x90(%rsp),%r14
0010a749          0 ja     108d2a <fn_4+0x7aa>
0010a74f     32,768 mov    %rbx,0x58(%rsp)
0010a754     32,768 lea    -0x1(%r15),%rbx
0010a758     32,768 cmp    0x10(%r13),%rbx
0010a75c     32,768 jae    10a919 <fn_4+0x2399>
0010a762     32,768 mov    0x8(%r13),%rax
0010a766     32,768 mov    -0x8(%rax,%r15,8),%r13
0010a76b     32,768 cmp    %rbp,%rbx
0010a76e     32,768 jge    10a963 <fn_4+0x23e3>
0010a774     32,768 test   %r13,%r13
0010a777     32,768 je     10af41 <fn_4+0x29c1>
0010a77d     32,768 mov    0x48(%rsp),%rax
0010a782     32,768 cmp    0x10(%rax),%r15
0010a786     32,768 jae    10aa7c <fn_4+0x24fc>
0010a78c     32,768 mov    0x8(%rax),%rax
0010a790     32,768 mov    (%rax,%r15,8),%rbp
0010a794     32,768 test   %rbp,%rbp
0010a797     32,768 je     10af41 <fn_4+0x29c1>
0010a79d     32,768 lea    0x1(%r15),%rax
0010a7a1     32,768 mov    0x48(%rsp),%rcx
0010a7a6     32,768 cmp    0x10(%rcx),%rax
0010a7aa     32,768 jae    10ab0e <fn_4+0x258e>
0010a7b0     32,768 mov    0x8(%rcx),%rax
0010a7b4     32,768 mov    0x8(%rax,%r15,8),%rax
0010a7b9     32,768 test   %rax,%rax
0010a7bc     32,768 je     10af41 <fn_4+0x29c1>
0010a7c2     32,768 shr    $1,%rbp
0010a7c5     32,768 and    $0xfffffffffffffffe,%r13
0010a7c9     32,768 shr    $1,%rax
0010a7cc     32,768 imul   $0x5a,%rax,%rax
0010a7d0     32,768 shr    $1,%rax
0010a7d3     32,768 add    %rbp,%rax
0010a7d6     32,768 imul   $0x5a,%rax,%rax
0010a7da     32,768 lea    (%rax,%r13,1),%rbp
0010a7de     32,768 lea    (%rax,%r13,1),%rbx
0010a7e2     32,768 inc    %rbx
0010a7e5     32,768 cmp    $0x1ffff,%rbp
0010a7ec     32,768 jge    10ace5 <fn_4+0x2765>
0010a7f2     32,768 mov    0x50(%rsp),%rdi
0010a7f7     32,768 incq   (%rdi)
0010a7fa     32,768 mov    0x48(%rsp),%r13
0010a7ff     32,768 je     10ae1e <fn_4+0x289e>
0010a805     32,768 mov    0x10(%rdi),%rsi
0010a809     32,768 mov    0x20(%rdi),%rcx
0010a80d     32,768 mov    %rsi,%rax
0010a810     32,768 sub    %rcx,%rax
0010a813     32,768 cmp    $0x2,%rax
0010a817     32,768 jae    10a88a <fn_4+0x230a>
0010a819          0 cmp    $0xfffffffffffffffd,%rcx
0010a81d          0 ja     10ab83 <fn_4+0x2603>
0010a823          0 mov    %rbx,%r12
0010a826          0 add    $0x2,%rcx
0010a82a          0 lea    (%rsi,%rsi,1),%rax
0010a82e          0 cmp    %rax,%rcx
0010a831          0 cmovbe %rax,%rcx
0010a835          0 cmp    $0x5,%rcx
0010a839          0 mov    $0x4,%ebx
0010a83e          0 cmovae %rcx,%rbx
0010a842          0 lea    0x0(,%rbx,8),%r13
0010a84a          0 shr    $0x3d,%rcx
0010a84e          0 setne  %al
0010a851          0 movabs $0x7ffffffffffffff8,%rcx
0010a85b          0 cmp    %rcx,%r13
0010a85e          0 seta   %cl
0010a861          0 or     %al,%cl
0010a863          0 jne    10ab78 <fn_4+0x25f8>
0010a869          0 test   %rsi,%rsi
0010a86c          0 je     10a890 <fn_4+0x2310>
0010a86e          0 mov    0x50(%rsp),%rax
0010a873          0 mov    0x18(%rax),%rdi
0010a877          0 shl    $0x3,%rsi
0010a87b          0 mov    $0x8,%edx
0010a880          0 mov    %r13,%rcx
0010a883          0 call   77540 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_realloc>
0010a888          0 jmp    10a89d <fn_4+0x231d>
0010a88a     32,768 mov    0x18(%rdi),%rax
0010a88e     32,768 jmp    10a8bf <fn_4+0x233f>
0010a890          0 mov    $0x8,%esi
0010a895          0 mov    %r13,%rdi
0010a898          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010a89d          0 test   %rax,%rax
0010a8a0          0 je     10b556 <fn_4+0x2fd6>
0010a8a6          0 mov    0x50(%rsp),%rdi
0010a8ab          0 mov    %rax,0x18(%rdi)
0010a8af          0 mov    %rbx,0x10(%rdi)
0010a8b3          0 mov    0x20(%rdi),%rcx
0010a8b7          0 mov    0x48(%rsp),%r13
0010a8bc          0 mov    %r12,%rbx
0010a8bf     32,768 mov    %rbp,%rdx
0010a8c2     32,768 sar    $0x8,%rdx
0010a8c6     32,768 or     $0x1,%rdx
0010a8ca     32,768 and    $0x1fe,%ebp
0010a8d0     32,768 inc    %rbp
0010a8d3     32,768 mov    %rdx,(%rax,%rcx,8)
0010a8d7     32,768 mov    %rbp,0x8(%rax,%rcx,8)
0010a8dc     32,768 add    $0x2,%rcx
0010a8e0     32,768 mov    %rcx,0x20(%rdi)
0010a8e4     32,768 mov    %rdi,(%rsp)
0010a8e8     32,768 decq   (%rdi)
0010a8eb     32,768 jne    10a8f6 <fn_4+0x2376>
0010a8ed          0 mov    %rsp,%rdi
0010a8f0          0 addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12imre_runtime4ListE9drop_slowBF_>
0010a8f6     32,768 mov    0x80(%rsp),%rbp
0010a8fe     32,768 add    $0x6,%r14
0010a902     32,768 add    $0x3,%r15
0010a906     32,768 cmp    0x90(%rsp),%r14
0010a90e     32,768 jbe    10a74f <fn_4+0x21cf>
0010a914          4 jmp    108d2a <fn_4+0x7aa>
0010a919          0 movabs $0x6f2074756f207865,%rax
0010a923          0 mov    %rax,0x8(%rsp)
0010a928          0 movabs $0xd765676e61722066,%rax
0010a932          0 mov    %rax,0x10(%rsp)
0010a937          0 movabs $0x646e69207473696c,%rax
0010a941          0 mov    %rax,(%rsp)
0010a945          0 movl   $0x6,0x18(%rsp)
0010a94d          0 mov    %rsp,%rdi
0010a950          0 xor    %esi,%esi
0010a952          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
0010a957          0 mov    %rax,%r13
0010a95a          0 cmp    %rbp,%rbx
0010a95d          0 jl     10a774 <fn_4+0x21f4>
0010a963          0 test   %r13,%r13
0010a966          0 je     10af41 <fn_4+0x29c1>
0010a96c          0 mov    0x48(%rsp),%rax
0010a971          0 cmp    0x10(%rax),%r15
0010a975          0 jae    10aacb <fn_4+0x254b>
0010a97b          0 mov    0x8(%rax),%rax
0010a97f          0 mov    (%rax,%r15,8),%rax
0010a983          0 test   %rax,%rax
0010a986          0 je     10af41 <fn_4+0x29c1>
0010a98c          0 shr    $1,%rax
0010a98f          0 imul   $0x5a,%rax,%rax
0010a993          0 and    $0xfffffffffffffffe,%r13
0010a997          0 lea    (%rax,%r13,1),%rcx
0010a99b          0 lea    (%rax,%r13,1),%rbx
0010a99f          0 inc    %rbx
0010a9a2          0 cmp    $0x1ff,%rcx
0010a9a9          0 jge    10abb4 <fn_4+0x2634>
0010a9af          0 mov    0x50(%rsp),%rax
0010a9b4          0 mov    0x20(%rax),%r13
0010a9b8          0 cmp    %r13,0x10(%rax)
0010a9bc          0 jne    10a720 <fn_4+0x21a0>
0010a9c2          0 mov    %rbx,%r12
0010a9c5          0 lea    0x0(,%r13,2),%rbx
0010a9cd          0 cmp    $0x5,%rbx
0010a9d1          0 mov    $0x4,%eax
0010a9d6          0 cmovb  %rax,%rbx
0010a9da          0 lea    0x0(,%rbx,8),%rbp
0010a9e2          0 movabs $0x1000000000000000,%rax
0010a9ec          0 dec    %rax
0010a9ef          0 cmp    %rax,%r13
0010a9f2          0 seta   %al
0010a9f5          0 movabs $0x7ffffffffffffff8,%rcx
0010a9ff          0 cmp    %rcx,%rbp
0010aa02          0 seta   %cl
0010aa05          0 or     %al,%cl
0010aa07          0 jne    10ab51 <fn_4+0x25d1>
0010aa0d          0 test   %r13,%r13
0010aa10          0 je     10aa31 <fn_4+0x24b1>
0010aa12          0 mov    0x50(%rsp),%rax
0010aa17          0 mov    0x18(%rax),%rdi
0010aa1b          0 shl    $0x3,%r13
0010aa1f          0 mov    $0x8,%edx
0010aa24          0 mov    %r13,%rsi
0010aa27          0 mov    %rbp,%rcx
0010aa2a          0 call   77540 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_realloc>
0010aa2f          0 jmp    10aa3e <fn_4+0x24be>
0010aa31          0 mov    $0x8,%esi
0010aa36          0 mov    %rbp,%rdi
0010aa39          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010aa3e          0 test   %rax,%rax
0010aa41          0 je     10b565 <fn_4+0x2fe5>
0010aa47          0 mov    0x50(%rsp),%rcx
0010aa4c          0 mov    %rax,0x18(%rcx)
0010aa50          0 mov    %rbx,0x10(%rcx)
0010aa54          0 mov    0x20(%rcx),%r13
0010aa58          0 cmp    %rbx,%r13
0010aa5b          0 jne    10a715 <fn_4+0x2195>
0010aa61          0 mov    0x40(%rsp),%rdi
0010aa66          0 mov    %r12,%rbx
0010aa69          0 addr32 call 12ffb0 <_RNvMs4_NtCscJq9HK9IcCJ_5alloc7raw_vecINtB5_6RawVecINtNtCs6SLOTazmNXq_4core6option6OptionINtNtNtCs3V9firECmdE_12imre_runtime7objects8mappings5EntryINtNtB7_2rc2RcINtNtB7_3vec3VechEEuEEE8grow_oneB1v_>
0010aa6f          0 mov    0x80(%rsp),%rbp
0010aa77          0 jmp    10a720 <fn_4+0x21a0>
0010aa7c          0 movabs $0x6f2074756f207865,%rax
0010aa86          0 mov    %rax,0x8(%rsp)
0010aa8b          0 movabs $0xd765676e61722066,%rax
0010aa95          0 mov    %rax,0x10(%rsp)
0010aa9a          0 movabs $0x646e69207473696c,%rax
0010aaa4          0 mov    %rax,(%rsp)
0010aaa8          0 movl   $0x6,0x18(%rsp)
0010aab0          0 mov    %rsp,%rdi
0010aab3          0 xor    %esi,%esi
0010aab5          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
0010aaba          0 mov    %rax,%rbp
0010aabd          0 test   %rbp,%rbp
0010aac0          0 jne    10a79d <fn_4+0x221d>
0010aac6          0 jmp    10af41 <fn_4+0x29c1>
0010aacb          0 movabs $0x6f2074756f207865,%rax
0010aad5          0 mov    %rax,0x8(%rsp)
0010aada          0 movabs $0xd765676e61722066,%rax
0010aae4          0 mov    %rax,0x10(%rsp)
0010aae9          0 movabs $0x646e69207473696c,%rax
0010aaf3          0 mov    %rax,(%rsp)
0010aaf7          0 movl   $0x6,0x18(%rsp)
0010aaff          0 mov    %rsp,%rdi
0010ab02          0 xor    %esi,%esi
0010ab04          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
0010ab09          0 jmp    10a983 <fn_4+0x2403>
0010ab0e          0 movabs $0x6f2074756f207865,%rax
0010ab18          0 mov    %rax,0x8(%rsp)
0010ab1d          0 movabs $0xd765676e61722066,%rax
0010ab27          0 mov    %rax,0x10(%rsp)
0010ab2c          0 movabs $0x646e69207473696c,%rax
0010ab36          0 mov    %rax,(%rsp)
0010ab3a          0 movl   $0x6,0x18(%rsp)
0010ab42          0 mov    %rsp,%rdi
0010ab45          0 xor    %esi,%esi
0010ab47          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
0010ab4c          0 jmp    10a7b9 <fn_4+0x2239>
0010ab51          0 xor    %ebp,%ebp
0010ab53          0 mov    0x78(%rsp),%rax
0010ab58          0 mov    %rbp,(%rax)
0010ab5b          0 lea    -0xdfffa(%rip),%rdi        # 2ab68 <anon.07dd289d6752232cc34d2640517a38ff.14.llvm.14548151582184166452>
0010ab62          0 lea    -0xdfff6(%rip),%rdx        # 2ab73 <anon.07dd289d6752232cc34d2640517a38ff.15.llvm.14548151582184166452>
0010ab69          0 mov    $0xb,%esi
0010ab6e          0 mov    $0x16,%ecx
0010ab73          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010ab78          0 xor    %r13d,%r13d
0010ab7b          0 mov    0x78(%rsp),%rax
0010ab80          0 mov    %r13,(%rax)
0010ab83          0 lea    -0xe0022(%rip),%rdi        # 2ab68 <anon.07dd289d6752232cc34d2640517a38ff.14.llvm.14548151582184166452>
0010ab8a          0 lea    -0xe001e(%rip),%rdx        # 2ab73 <anon.07dd289d6752232cc34d2640517a38ff.15.llvm.14548151582184166452>
0010ab91          0 mov    $0xb,%esi
0010ab96          0 mov    $0x16,%ecx
0010ab9b          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010aba0          0 xor    %r13d,%r13d
0010aba3          0 xor    %ebp,%ebp
0010aba5          0 jmp    1089d8 <fn_4+0x458>
0010abaa          0 xor    %r13d,%r13d
0010abad          0 xor    %ebp,%ebp
0010abaf          0 jmp    10948f <fn_4+0xf0f>
0010abb4          0 mov    $0x28,%edi
0010abb9          0 mov    $0x8,%esi
0010abbe          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010abc3          0 test   %rax,%rax
0010abc6          0 je     10b3af <fn_4+0x2e2f>
0010abcc          0 movq   $0x1,(%rax)
0010abd3          0 movq   $0x1,0x8(%rax)
0010abdb          0 pxor   %xmm0,%xmm0
0010abdf          0 movdqu %xmm0,0x10(%rax)
0010abe4          0 movabs $0xc000000000000000,%rcx
0010abee          0 mov    %rcx,0x20(%rax)
0010abf2          0 movq   $0x1,(%rsp)
0010abfa          0 movq   $0x1,0x8(%rsp)
0010ac03          0 mov    %rax,0x10(%rsp)
0010ac08          0 movq   $0x0,0x18(%rsp)
0010ac11          0 movl   $0x8,0x20(%rsp)
0010ac19          0 movb   $0x0,0x24(%rsp)
0010ac1e          0 movb   $0x8,0x39(%rsp)
0010ac23          0 mov    $0x40,%edi
0010ac28          0 mov    $0x8,%esi
0010ac2d          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010ac32          0 test   %rax,%rax
0010ac35          0 mov    0x48(%rsp),%r13
0010ac3a          0 je     10b3cf <fn_4+0x2e4f>
0010ac40          0 mov    %rax,%r12
0010ac43          0 movups (%rsp),%xmm0
0010ac47          0 movups 0x10(%rsp),%xmm1
0010ac4c          0 movups 0x20(%rsp),%xmm2
0010ac51          0 movups 0x30(%rsp),%xmm3
0010ac56          0 movups %xmm3,0x30(%rax)
0010ac5a          0 movups %xmm2,0x20(%rax)
0010ac5e          0 movups %xmm1,0x10(%rax)
0010ac62          0 movups %xmm0,(%rax)
0010ac65          0 cmpb   $0x8,0x39(%rax)
0010ac69          0 jne    10b3f9 <fn_4+0x2e79>
0010ac6f          0 incq   (%r12)
0010ac73          0 je     10ae1e <fn_4+0x289e>
0010ac79          0 mov    %r12,0x60(%rsp)
0010ac7e          0 xor    %edi,%edi
0010ac80          0 call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
0010ac85          0 test   %rax,%rax
0010ac88          0 je     10b5b0 <fn_4+0x3030>
0010ac8e          0 mov    %r12,(%rsp)
0010ac92          0 cmpq   $0x0,(%rax)
0010ac96          0 jne    10b433 <fn_4+0x2eb3>
0010ac9c          0 mov    %rbx,%r14
0010ac9f          0 mov    0x8(%rax),%rbx
0010aca3          0 mov    %r12,0x8(%rax)
0010aca7          0 mov    %rsp,%rdi
0010acaa          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
0010acaf          0 movb   $0x1,(%rax)
0010acb2          0 mov    %rbx,(%rsp)
0010acb6          0 test   %rbx,%rbx
0010acb9          0 je     10acc9 <fn_4+0x2749>
0010acbb          0 decq   (%rbx)
0010acbe          0 jne    10acc9 <fn_4+0x2749>
0010acc0          0 mov    %rsp,%rdi
0010acc3          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010acc9          0 mov    %r12,(%rsp)
0010accd          0 decq   (%r12)
0010acd1          0 jne    10ae11 <fn_4+0x2891>
0010acd7          0 mov    %rsp,%rdi
0010acda          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010ace0          0 jmp    10ae11 <fn_4+0x2891>
0010ace5          0 mov    $0x28,%edi
0010acea          0 mov    $0x8,%esi
0010acef          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010acf4          0 test   %rax,%rax
0010acf7          0 mov    0x48(%rsp),%r13
0010acfc          0 je     10b3bf <fn_4+0x2e3f>
0010ad02          0 movq   $0x1,(%rax)
0010ad09          0 movq   $0x1,0x8(%rax)
0010ad11          0 pxor   %xmm0,%xmm0
0010ad15          0 movdqu %xmm0,0x10(%rax)
0010ad1a          0 movabs $0xc000000000000000,%rcx
0010ad24          0 mov    %rcx,0x20(%rax)
0010ad28          0 movq   $0x1,(%rsp)
0010ad30          0 movq   $0x1,0x8(%rsp)
0010ad39          0 mov    %rax,0x10(%rsp)
0010ad3e          0 movq   $0x0,0x18(%rsp)
0010ad47          0 movl   $0x8,0x20(%rsp)
0010ad4f          0 movb   $0x0,0x24(%rsp)
0010ad54          0 movb   $0x8,0x39(%rsp)
0010ad59          0 mov    $0x40,%edi
0010ad5e          0 mov    $0x8,%esi
0010ad63          0 call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
0010ad68          0 test   %rax,%rax
0010ad6b          0 je     10b3e4 <fn_4+0x2e64>
0010ad71          0 mov    %rax,%r12
0010ad74          0 movdqu (%rsp),%xmm0
0010ad79          0 movdqu 0x10(%rsp),%xmm1
0010ad7f          0 movdqu 0x20(%rsp),%xmm2
0010ad85          0 movdqu 0x30(%rsp),%xmm3
0010ad8b          0 movdqu %xmm3,0x30(%rax)
0010ad90          0 movdqu %xmm2,0x20(%rax)
0010ad95          0 movdqu %xmm1,0x10(%rax)
0010ad9a          0 movdqu %xmm0,(%rax)
0010ad9e          0 cmpb   $0x8,0x39(%rax)
0010ada2          0 jne    10b416 <fn_4+0x2e96>
0010ada8          0 incq   (%r12)
0010adac          0 je     10ae1e <fn_4+0x289e>
0010adae          0 mov    %r12,0x60(%rsp)
0010adb3          0 xor    %edi,%edi
0010adb5          0 call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
0010adba          0 test   %rax,%rax
0010adbd          0 je     10b5ce <fn_4+0x304e>
0010adc3          0 mov    %r12,(%rsp)
0010adc7          0 cmpq   $0x0,(%rax)
0010adcb          0 jne    10b440 <fn_4+0x2ec0>
0010add1          0 mov    %rbx,%r14
0010add4          0 mov    0x8(%rax),%rbx
0010add8          0 mov    %r12,0x8(%rax)
0010addc          0 mov    %rsp,%rdi
0010addf          0 call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12imre_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
0010ade4          0 movb   $0x1,(%rax)
0010ade7          0 mov    %rbx,(%rsp)
0010adeb          0 test   %rbx,%rbx
0010adee          0 je     10adfe <fn_4+0x287e>
0010adf0          0 decq   (%rbx)
0010adf3          0 jne    10adfe <fn_4+0x287e>
0010adf5          0 mov    %rsp,%rdi
0010adf8          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010adfe          0 mov    %r12,(%rsp)
0010ae02          0 decq   (%r12)
0010ae06          0 jne    10ae11 <fn_4+0x2891>
0010ae08          0 mov    %rsp,%rdi
0010ae0b          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010ae11          0 mov    0x40(%rsp),%r12
0010ae16          0 mov    %r14,%rbx
0010ae19          0 jmp    1091b6 <fn_4+0xc36>
0010ae1e          0 ud2
0010ae20          0 mov    %rax,%rbp
0010ae23          0 lea    -0xdf922(%rip),%rdi        # 2b508 <anon.a32fe9f9f6555f50d5f367eaf6585c5b.3.llvm.12851202843824566656>
0010ae2a          0 mov    $0x1e,%ebx
0010ae2f          0 mov    $0x1e,%esi
0010ae34          0 addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
0010ae3a          0 test   %rax,%rax
0010ae3d          0 je     10b44d <fn_4+0x2ecd>
0010ae43          0 mov    %rax,%r14
0010ae46          0 mov    %rdx,%r13
0010ae49          0 mov    $0x1,%edx
0010ae4e          0 mov    %rbp,%rdi
0010ae51          0 mov    %r12,%rsi
0010ae54          0 call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
0010ae59          0 mov    $0x8,%eax
0010ae5e          0 jmp    1093e7 <fn_4+0xe67>
0010ae63          0 test   $0x1,%bl
0010ae66          0 jne    10ae71 <fn_4+0x28f1>
0010ae68          0 mov    %rbx,%rdi
0010ae6b          0 addr32 call 115940 <imre_int_release>
0010ae71          0 mov    %r14,%rbx
0010ae74          0 mov    0x40(%rsp),%r12
0010ae79          0 jmp    1091b6 <fn_4+0xc36>
0010ae7e          0 lea    -0xe02e2(%rip),%rdi        # 2aba3 <anon.07dd289d6752232cc34d2640517a38ff.20.llvm.14548151582184166452>
0010ae85          0 lea    -0xe02df(%rip),%rdx        # 2abad <anon.07dd289d6752232cc34d2640517a38ff.21.llvm.14548151582184166452>
0010ae8c          0 mov    $0xa,%esi
0010ae91          0 mov    $0xd,%ecx
0010ae96          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010ae9b          0 mov    %r12,%rsi
0010ae9e          0 addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
0010aea4          0 test   %rax,%rax
0010aea7          0 je     10b4fe <fn_4+0x2f7e>
0010aead          0 mov    %rax,%r13
0010aeb0          0 mov    %rdx,%r15
0010aeb3          0 jmp    10884e <fn_4+0x2ce>
0010aeb8          0 mov    $0x8,%edi
0010aebd          0 mov    $0x28,%esi
0010aec2          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010aec8          0 xor    %r13d,%r13d
0010aecb          0 jmp    1091ae <fn_4+0xc2e>
0010aed0          0 lea    0x5a1d1(%rip),%rdi        # 1650a8 <anon.b5c5b1d202edf6079cbd4240259d7569.9.llvm.9011365425941023334>
0010aed7          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010aedd          0 mov    $0x26,%ecx
0010aee2          0 lea    -0xdff16(%rip),%rdx        # 2afd3 <anon.5a426941b95332e7deb832e37db0b8d7.19.llvm.13056261042975510615>
0010aee9          0 mov    $0x9,%esi
0010aeee          0 lea    -0xe0029(%rip),%rdi        # 2aecc <anon.5a426941b95332e7deb832e37db0b8d7.0.llvm.13056261042975510615>
0010aef5          0 jmp    10af0f <fn_4+0x298f>
0010aef7          0 mov    $0x1c,%ecx
0010aefc          0 lea    -0xdffcd(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010af03          0 mov    $0xb,%esi
0010af08          0 lea    -0xdfffe(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010af0f          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010af14          0 mov    $0x8,%edi
0010af19          0 mov    $0x28,%esi
0010af1e          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010af24          0 lea    -0xe0388(%rip),%rdi        # 2aba3 <anon.07dd289d6752232cc34d2640517a38ff.20.llvm.14548151582184166452>
0010af2b          0 lea    -0xe0385(%rip),%rdx        # 2abad <anon.07dd289d6752232cc34d2640517a38ff.21.llvm.14548151582184166452>
0010af32          0 mov    $0xa,%esi
0010af37          0 mov    $0xd,%ecx
0010af3c          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010af41          0 mov    0x48(%rsp),%r13
0010af46          0 jmp    10a5d2 <fn_4+0x2052>
0010af4b          0 mov    %r15,%rsi
0010af4e          0 addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
0010af54          0 test   %rax,%rax
0010af57          0 je     10b50b <fn_4+0x2f8b>
0010af5d          0 mov    %rax,%r12
0010af60          0 mov    %rdx,%r14
0010af63          0 jmp    109077 <fn_4+0xaf7>
0010af68          0 mov    $0x8,%edi
0010af6d          0 mov    $0x28,%esi
0010af72          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010af78          0 lea    0x10(%rsp),%rbx
0010af7d          0 mov    $0x8,%edi
0010af82          0 mov    $0x40,%esi
0010af87          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010af8d          0 lea    -0xe0083(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010af94          0 lea    -0xe0065(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010af9b          0 mov    $0xb,%esi
0010afa0          0 mov    $0x1c,%ecx
0010afa5          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010afaa          0 lea    0x5a25f(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
0010afb1          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010afb7          0 test   %rbp,%rbp
0010afba          0 sete   %al
0010afbd          0 or     %bpl,%al
0010afc0          0 test   $0x1,%al
0010afc2          0 jne    10afcd <fn_4+0x2a4d>
0010afc4          0 mov    %rbp,%rdi
0010afc7          0 addr32 call 115940 <imre_int_release>
0010afcd          0 mov    %r14,%rbx
0010afd0          0 mov    0x48(%rsp),%r13
0010afd5          0 mov    0x40(%rsp),%r12
0010afda          0 jmp    1091b6 <fn_4+0xc36>
0010afdf          0 mov    %rax,%rdi
0010afe2          0 mov    %r13,%rsi
0010afe5          0 addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
0010afeb          0 test   %rax,%rax
0010afee          0 je     10b53c <fn_4+0x2fbc>
0010aff4          0 mov    %rax,%rbp
0010aff7          0 mov    %rdx,%r15
0010affa          0 jmp    1089d8 <fn_4+0x458>
0010afff          0 mov    $0x8,%edi
0010b004          0 mov    $0x28,%esi
0010b009          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b00f          0 lea    0x5a212(%rip),%rdi        # 165228 <anon.e35a9af1f69509cfdb48e0a540415976.9.llvm.14158413026871995055>
0010b016          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010b01c          0 lea    -0xe0480(%rip),%rdi        # 2aba3 <anon.07dd289d6752232cc34d2640517a38ff.20.llvm.14548151582184166452>
0010b023          0 lea    -0xe047d(%rip),%rdx        # 2abad <anon.07dd289d6752232cc34d2640517a38ff.21.llvm.14548151582184166452>
0010b02a          0 mov    $0xa,%esi
0010b02f          0 mov    $0xd,%ecx
0010b034          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b039          0 mov    %r13,%rsi
0010b03c          0 addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
0010b042          0 test   %rax,%rax
0010b045          0 je     10b549 <fn_4+0x2fc9>
0010b04b          0 mov    %rax,%rbp
0010b04e          0 mov    %rdx,%r12
0010b051          0 jmp    10948f <fn_4+0xf0f>
0010b056          0 mov    $0x8,%edi
0010b05b          0 mov    $0x28,%esi
0010b060          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b066          0 lea    0x10(%rsp),%rbx
0010b06b          0 mov    $0x8,%edi
0010b070          0 mov    $0x40,%esi
0010b075          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b07b          0 lea    -0xe0171(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010b082          0 lea    -0xe0153(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010b089          0 mov    $0xb,%esi
0010b08e          0 mov    $0x1c,%ecx
0010b093          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b098          0 lea    -0xdf9bb(%rip),%rdi        # 2b6e4 <anon.a6314b0dfcd62d2058f2b6595a6854b4.0.llvm.7526630615700072279>
0010b09f          0 lea    -0xdf9b7(%rip),%rdx        # 2b6ef <anon.a6314b0dfcd62d2058f2b6595a6854b4.1.llvm.7526630615700072279>
0010b0a6          0 mov    $0xb,%esi
0010b0ab          0 mov    $0x1c,%ecx
0010b0b0          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b0b5          0 lea    -0xe01ab(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010b0bc          0 lea    -0xe018d(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010b0c3          0 mov    $0xb,%esi
0010b0c8          0 mov    $0x1c,%ecx
0010b0cd          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b0d2          0 lea    0x5a137(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
0010b0d9          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010b0df          0 lea    0x5a142(%rip),%rdi        # 165228 <anon.e35a9af1f69509cfdb48e0a540415976.9.llvm.14158413026871995055>
0010b0e6          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010b0ec          0 lea    0x68(%rsp),%rcx
0010b0f1          0 mov    0x8(%r14),%rsi
0010b0f5          0 mov    0x10(%r14),%rdx
0010b0f9          0 mov    %rsp,%rdi
0010b0fc          0 call   1255a0 <_RNvNtNtCs3V9firECmdE_12imre_runtime7objects5bytes12decode_error.llvm.12851202843824566656>
0010b101          0 mov    %rsp,%rdi
0010b104          0 xor    %esi,%esi
0010b106          0 call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12imre_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
0010b10b          0 mov    %rax,%r14
0010b10e          0 jmp    1086a7 <fn_4+0x127>
0010b113          0 xor    %r13d,%r13d
0010b116          0 jmp    1091b3 <fn_4+0xc33>
0010b11b          0 test   $0x1,%r15b
0010b11f          0 jne    10b12a <fn_4+0x2baa>
0010b121          0 mov    %rbx,%rdi
0010b124          0 addr32 call 115940 <imre_int_release>
0010b12a          0 mov    0x40(%rsp),%r12
0010b12f          0 jmp    10b15b <fn_4+0x2bdb>
0010b131          0 test   %r13,%r13
0010b134          0 sete   %al
0010b137          0 or     %r13b,%al
0010b13a          0 test   $0x1,%al
0010b13c          0 mov    0x40(%rsp),%r12
0010b141          0 jne    10b14c <fn_4+0x2bcc>
0010b143          0 mov    %r13,%rdi
0010b146          0 addr32 call 115940 <imre_int_release>
0010b14c          0 test   $0x1,%r15b
0010b150          0 jne    10b15b <fn_4+0x2bdb>
0010b152          0 mov    %rbx,%rdi
0010b155          0 addr32 call 115940 <imre_int_release>
0010b15b          0 mov    %r12,%rdi
0010b15e          0 addr32 call 1167e0 <imre_list_release>
0010b164          0 mov    0x48(%rsp),%r13
0010b169          0 jmp    1091b6 <fn_4+0xc36>
0010b16e          0 mov    $0x8,%edi
0010b173          0 mov    $0x28,%esi
0010b178          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b17e          0 mov    0x40(%rsp),%r12
0010b183          0 jmp    1091b6 <fn_4+0xc36>
0010b188          0 lea    -0xe027e(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010b18f          0 lea    -0xe0260(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010b196          0 mov    $0xb,%esi
0010b19b          0 mov    $0x1c,%ecx
0010b1a0          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b1a5          0 lea    0x5a064(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
0010b1ac          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010b1b2          0 xor    %r15d,%r15d
0010b1b5          0 jmp    108733 <fn_4+0x1b3>
0010b1ba          0 mov    $0x8,%edi
0010b1bf          0 mov    $0x28,%esi
0010b1c4          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b1ca          0 mov    $0x8,%edi
0010b1cf          0 mov    $0x28,%esi
0010b1d4          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b1da          0 cmp    $0x1,%eax
0010b1dd          0 jne    10a3bb <fn_4+0x1e3b>
0010b1e3          0 lea    0x29cb6(%rip),%rsi        # 134ea0 <_RINvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local6native5eager7destroyINtNtCs6SLOTazmNXq_4core4cell7RefCellAINtNtCscJq9HK9IcCJ_5alloc3vec3VecNtCs3V9firECmdE_12imre_runtime3IntEj2_EEB2g_.llvm.6207308902554770856>
0010b1ea          0 mov    %rbp,%rdi
0010b1ed          0 addr32 call a2320 <_RNvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local11destructors10linux_like8register>
0010b1f3          0 movb   $0x0,0x38(%rbp)
0010b1f7          0 mov    0x50(%rsp),%r14
0010b1fc          0 cmpq   $0x0,0x0(%rbp)
0010b201          0 jne    10a3bb <fn_4+0x1e3b>
0010b207          4 lea    (%r12,%r12,1),%rcx
0010b20b          4 mov    0x8(%rbp),%rdx
0010b20f          4 mov    0x20(%rbp),%rax
0010b213          4 cmp    %rdx,%r12
0010b216          4 seta   %sil
0010b21a          4 cmp    %rcx,%rdx
0010b21d          4 seta   %dil
0010b221          4 or     %sil,%dil
0010b224          4 je     10b248 <fn_4+0x2cc8>
0010b226          1 cmp    %rax,%r12
0010b229          1 seta   %dl
0010b22c          1 cmp    %rcx,%rax
0010b22f          1 seta   %al
0010b232          1 or     %dl,%al
0010b234          1 mov    $0x1,%ecx
0010b239          1 je     10b266 <fn_4+0x2ce6>
0010b23b          1 movq   $0x0,0x0(%rbp)
0010b243          1 jmp    10a3bb <fn_4+0x1e3b>
0010b248          3 cmp    %rax,%r12
0010b24b          3 setbe  %sil
0010b24f          3 cmp    %rcx,%rax
0010b252          3 setbe  %cl
0010b255          3 test   %cl,%sil
0010b258          3 je     10b264 <fn_4+0x2ce4>
0010b25a          0 xor    %ecx,%ecx
0010b25c          0 cmp    %rax,%rdx
0010b25f          0 seta   %cl
0010b262          0 jmp    10b266 <fn_4+0x2ce6>
0010b264          3 xor    %ecx,%ecx
0010b266          3 lea    0x8(%rbp),%rdx
0010b26a          3 lea    (%rcx,%rcx,2),%rsi
0010b26e          3 mov    (%rdx,%rsi,8),%r13
0010b272          3 mov    0x8(%rdx,%rsi,8),%rax
0010b277          3 mov    0x10(%rdx,%rsi,8),%rbx
0010b27c          3 movq   $0x0,(%rdx,%rsi,8)
0010b284          3 movq   $0x8,0x8(%rdx,%rsi,8)
0010b28d          3 movq   $0x0,0x10(%rdx,%rsi,8)
0010b296          3 test   %rcx,%rcx
0010b299          3 jne    10b2cf <fn_4+0x2d4f>
0010b29b          3 lea    0x20(%rbp),%rcx
0010b29f          3 mov    0x10(%rdx),%rsi
0010b2a3          3 mov    %rsi,0x10(%rsp)
0010b2a8          3 movups (%rdx),%xmm0
0010b2ab          3 movaps %xmm0,(%rsp)
0010b2af          3 mov    0x10(%rcx),%rsi
0010b2b3          3 mov    %rsi,0x10(%rdx)
0010b2b7          3 movups (%rcx),%xmm0
0010b2ba          3 movups %xmm0,(%rdx)
0010b2bd          3 mov    0x10(%rsp),%rdx
0010b2c2          3 mov    %rdx,0x10(%rcx)
0010b2c6          3 movdqa (%rsp),%xmm0
0010b2cb          3 movdqu %xmm0,(%rcx)
0010b2cf          3 movq   $0x0,0x0(%rbp)
0010b2d7          3 cmp    $0xffffffffffffffff,%r13
0010b2db          3 je     10a3bb <fn_4+0x1e3b>
0010b2e1          3 cmp    %r12,%r13
0010b2e4          3 jae    10b2ee <fn_4+0x2d6e>
0010b2e6          0 mov    %rax,%r15
0010b2e9          0 jmp    10a3c0 <fn_4+0x1e40>
0010b2ee          3 mov    0x10(%r14),%rcx
0010b2f2          3 mov    0x18(%r14),%r15
0010b2f6          3 mov    0x20(%r14),%rdx
0010b2fa          3 mov    %r13,0x10(%r14)
0010b2fe          3 mov    %rax,0x18(%r14)
0010b302          3 mov    %rbx,0x20(%r14)
0010b306          3 mov    %rcx,%r13
0010b309          3 mov    %rdx,%rbx
0010b30c          3 jmp    10a3da <fn_4+0x1e5a>
0010b311          0 mov    $0x8,%edi
0010b316          0 mov    $0x28,%esi
0010b31b          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b321          0 lea    0x10(%rsp),%rbx
0010b326          0 mov    $0x8,%edi
0010b32b          0 mov    $0x40,%esi
0010b330          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b336          0 mov    $0x8,%edi
0010b33b          0 mov    $0x28,%esi
0010b340          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b346          0 lea    -0xe043c(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010b34d          0 lea    -0xe041e(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010b354          0 mov    $0xb,%esi
0010b359          0 mov    $0x1c,%ecx
0010b35e          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b363          0 lea    0x10(%rsp),%rbx
0010b368          0 mov    $0x8,%edi
0010b36d          0 mov    $0x40,%esi
0010b372          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b378          0 lea    -0xe046e(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010b37f          0 lea    -0xe0450(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010b386          0 mov    $0xb,%esi
0010b38b          0 mov    $0x1c,%ecx
0010b390          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b395          0 lea    0x59e74(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
0010b39c          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010b3a2          0 lea    0x59e67(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
0010b3a9          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010b3af          0 mov    $0x8,%edi
0010b3b4          0 mov    $0x28,%esi
0010b3b9          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b3bf          0 mov    $0x8,%edi
0010b3c4          0 mov    $0x28,%esi
0010b3c9          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b3cf          0 lea    0x10(%rsp),%rbx
0010b3d4          0 mov    $0x8,%edi
0010b3d9          0 mov    $0x40,%esi
0010b3de          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b3e4          0 lea    0x10(%rsp),%rbx
0010b3e9          0 mov    $0x8,%edi
0010b3ee          0 mov    $0x40,%esi
0010b3f3          0 addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
0010b3f9          0 lea    -0xe04ef(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010b400          0 lea    -0xe04d1(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010b407          0 mov    $0xb,%esi
0010b40c          0 mov    $0x1c,%ecx
0010b411          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b416          0 lea    -0xe050c(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
0010b41d          0 lea    -0xe04ee(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
0010b424          0 mov    $0xb,%esi
0010b429          0 mov    $0x1c,%ecx
0010b42e          0 call   10e100 <_RNvCs3V9firECmdE_12imre_runtime4fail>
0010b433          0 lea    0x59dd6(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
0010b43a          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010b440          0 lea    0x59dc9(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
0010b447          0 addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
0010b44d          0 lea    0x599a4(%rip),%rdi        # 164df8 <anon.a32fe9f9f6555f50d5f367eaf6585c5b.2.llvm.12851202843824566656>
0010b454          0 addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
0010b45a          0 lea    0x59d7f(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b461          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b467          0 decq   (%r14)
0010b46a          0 jne    10b477 <fn_4+0x2ef7>
0010b46c          0 lea    0x60(%rsp),%rdi
0010b471          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b477          0 lea    0x59d62(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b47e          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b484          0 decq   (%rbx)
0010b487          0 jne    10b494 <fn_4+0x2f14>
0010b489          0 lea    0x60(%rsp),%rdi
0010b48e          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b494          0 lea    0x59d45(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b49b          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b4a1          0 decq   (%r12)
0010b4a5          0 jne    10b4b2 <fn_4+0x2f32>
0010b4a7          0 lea    0x60(%rsp),%rdi
0010b4ac          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b4b2          0 lea    0x59d27(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b4b9          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b4bf          0 test   %r15,%r15
0010b4c2          0 je     10b4d4 <fn_4+0x2f54>
0010b4c4          0 decq   (%r15)
0010b4c7          0 jne    10b4d4 <fn_4+0x2f54>
0010b4c9          0 lea    0x60(%rsp),%rdi
0010b4ce          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b4d4          0 lea    0x59d05(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b4db          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b4e1          0 decq   (%rbx)
0010b4e4          0 jne    10b4f1 <fn_4+0x2f71>
0010b4e6          0 lea    0x60(%rsp),%rdi
0010b4eb          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b4f1          0 lea    0x59ce8(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b4f8          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b4fe          0 lea    0x596fb(%rip),%rdi        # 164c00 <anon.07dd289d6752232cc34d2640517a38ff.59.llvm.14548151582184166452>
0010b505          0 addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
0010b50b          0 lea    0x596ee(%rip),%rdi        # 164c00 <anon.07dd289d6752232cc34d2640517a38ff.59.llvm.14548151582184166452>
0010b512          0 addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
0010b518          0 lea    0x60(%rsp),%rax
0010b51d          0 mov    %rax,0x88(%rsp)
0010b525          0 jmp    10a2ff <fn_4+0x1d7f>
0010b52a          0 lea    0x60(%rsp),%rax
0010b52f          0 mov    %rax,0x88(%rsp)
0010b537          0 jmp    10a32a <fn_4+0x1daa>
0010b53c          0 lea    0x597ed(%rip),%rdi        # 164d30 <anon.5a426941b95332e7deb832e37db0b8d7.23.llvm.13056261042975510615>
0010b543          0 addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
0010b549          0 lea    0x596b0(%rip),%rdi        # 164c00 <anon.07dd289d6752232cc34d2640517a38ff.59.llvm.14548151582184166452>
0010b550          0 addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
0010b556          0 lea    0x60(%rsp),%rax
0010b55b          0 mov    %rax,0x78(%rsp)
0010b560          0 jmp    10ab7b <fn_4+0x25fb>
0010b565          0 lea    0x60(%rsp),%rax
0010b56a          0 mov    %rax,0x78(%rsp)
0010b56f          0 jmp    10ab53 <fn_4+0x25d3>
0010b574          0 decq   (%r12)
0010b578          0 jne    10b585 <fn_4+0x3005>
0010b57a          0 lea    0x60(%rsp),%rdi
0010b57f          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b585          0 lea    0x59c54(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b58c          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b592          0 decq   (%r12)
0010b596          0 jne    10b5a3 <fn_4+0x3023>
0010b598          0 lea    0x60(%rsp),%rdi
0010b59d          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b5a3          0 lea    0x59c36(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b5aa          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b5b0          0 decq   (%r12)
0010b5b4          0 jne    10b5c1 <fn_4+0x3041>
0010b5b6          0 lea    0x60(%rsp),%rdi
0010b5bb          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b5c1          0 lea    0x59c18(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b5c8          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b5ce          0 decq   (%r12)
0010b5d2          0 jne    10b5df <fn_4+0x305f>
0010b5d4          0 lea    0x60(%rsp),%rdi
0010b5d9          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b5df          0 lea    0x59bfa(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
0010b5e6          0 addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
0010b5ec          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b5f2          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b5f8          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b5fe          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b604          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b60a          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b610          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b616          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b61c          0 decq   (%r12)
0010b620          0 jne    10bc40 <fn_4+0x36c0>
0010b626          0 lea    0x60(%rsp),%rdi
0010b62b          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b631          0 jmp    10bc40 <fn_4+0x36c0>
0010b636          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b63c          0 decq   (%r12)
0010b640          0 jne    10bc40 <fn_4+0x36c0>
0010b646          0 lea    0x60(%rsp),%rdi
0010b64b          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b651          0 jmp    10bc40 <fn_4+0x36c0>
0010b656          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b65c          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b662          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b668          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b66e          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b674          0 mov    %rbx,%rdi
0010b677          0 call   10d190 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtCs3V9firECmdE_12imre_runtime3IntEBD_.llvm.14548151582184166452>
0010b67c          0 jmp    10bc40 <fn_4+0x36c0>
0010b681          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b687          0 decq   (%r12)
0010b68b          0 jne    10bc40 <fn_4+0x36c0>
0010b691          0 lea    0x60(%rsp),%rdi
0010b696          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b69c          0 jmp    10bc40 <fn_4+0x36c0>
0010b6a1          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b6a7          0 decq   (%r12)
0010b6ab          0 jne    10bc40 <fn_4+0x36c0>
0010b6b1          0 lea    0x60(%rsp),%rdi
0010b6b6          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b6bc          0 jmp    10bc40 <fn_4+0x36c0>
0010b6c1          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b6c7          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6cd          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6d3          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6d9          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6df          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6e5          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6eb          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6f1          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6f7          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b6fd          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b703          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b709          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b70f          0 mov    %rbx,(%r14)
0010b712          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b718          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b71e          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b724          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b72a          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b730          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b736          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b73c          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b742          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b748          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b74e          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b754          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b75a          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b760          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b766          0 lea    0x33a3(%rip),%r14        # 10eb10 <_RNvXs0_Cs3V9firECmdE_12imre_runtimeNtB5_3IntNtNtNtCs6SLOTazmNXq_4core3ops4drop4Drop4drop>
0010b76d          0 dec    %rbx
0010b770          0 je     10b782 <fn_4+0x3202>
0010b772          0 lea    0x8(%r12),%r15
0010b777          0 mov    %r12,%rdi
0010b77a          0 call   *%r14
0010b77d          0 mov    %r15,%r12
0010b780          0 jmp    10b76d <fn_4+0x31ed>
0010b782          0 mov    %rsp,%rdi
0010b785          0 call   130340 <_RNvXs1_NtCscJq9HK9IcCJ_5alloc7raw_vecINtB5_6RawVecINtNtCs6SLOTazmNXq_4core6option6OptionINtNtNtCs3V9firECmdE_12imre_runtime7objects8mappings5EntryINtNtB7_2rc2RcINtNtB7_3vec3VechEEuEEENtNtNtBR_3ops4drop4Drop4dropB1v_>
0010b78a          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b790          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b796          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b79c          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7a2          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7a8          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7ae          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7b4          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7ba          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7c0          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7c6          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7cc          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7d2          0 mov    0x58(%rsp),%rdi
0010b7d7          0 call   10d190 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtCs3V9firECmdE_12imre_runtime3IntEBD_.llvm.14548151582184166452>
0010b7dc          0 jmp    10bc40 <fn_4+0x36c0>
0010b7e1          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b7e7          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7ed          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7f3          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b7f9          0 decq   (%rbx)
0010b7fc          0 jne    10bc40 <fn_4+0x36c0>
0010b802          0 lea    0x60(%rsp),%rdi
0010b807          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b80d          0 jmp    10bc40 <fn_4+0x36c0>
0010b812          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b818          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b81e          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b824          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b82a          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b830          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b836          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b83c          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b842          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b848          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b84e          0 test   %r15,%r15
0010b851          0 je     10bc40 <fn_4+0x36c0>
0010b857          0 decq   (%r15)
0010b85a          0 jne    10bc40 <fn_4+0x36c0>
0010b860          0 lea    0x60(%rsp),%rdi
0010b865          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b86b          0 jmp    10bc40 <fn_4+0x36c0>
0010b870          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b876          0 decq   (%r12)
0010b87a          0 jne    10bc40 <fn_4+0x36c0>
0010b880          0 lea    0x60(%rsp),%rdi
0010b885          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b88b          0 jmp    10bc40 <fn_4+0x36c0>
0010b890          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b896          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b89c          0 decq   (%rbx)
0010b89f          0 jne    10bc40 <fn_4+0x36c0>
0010b8a5          0 lea    0x60(%rsp),%rdi
0010b8aa          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b8b0          0 jmp    10bc40 <fn_4+0x36c0>
0010b8b5          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b8bb          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b8c1          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b8c7          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b8cd          0 decq   (%r14)
0010b8d0          0 jne    10bc40 <fn_4+0x36c0>
0010b8d6          0 lea    0x60(%rsp),%rdi
0010b8db          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b8e1          0 jmp    10bc40 <fn_4+0x36c0>
0010b8e6          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b8ec          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b8f2          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b8f8          0 lea    0x60(%rsp),%rdi
0010b8fd          0 call   1253a0 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc3vec3VechEECs3V9firECmdE_12imre_runtime.llvm.12851202843824566656>
0010b902          0 jmp    10bc40 <fn_4+0x36c0>
0010b907          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b90d          0 decq   (%r12)
0010b911          0 jne    10bc40 <fn_4+0x36c0>
0010b917          0 mov    %rsp,%rdi
0010b91a          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b920          0 jmp    10bc40 <fn_4+0x36c0>
0010b925          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b92b          0 decq   (%r12)
0010b92f          0 jne    10bc40 <fn_4+0x36c0>
0010b935          0 mov    %rsp,%rdi
0010b938          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b93e          0 jmp    10bc40 <fn_4+0x36c0>
0010b943          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b949          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b94f          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b955          0 mov    %rbx,%rdi
0010b958          0 call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12imre_runtime7objects7StorageEBF_.llvm.7526630615700072279>
0010b95d          0 jmp    10bc40 <fn_4+0x36c0>
0010b962          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b968          0 mov    %rbx,%rdi
0010b96b          0 call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12imre_runtime7objects7StorageEBF_.llvm.7526630615700072279>
0010b970          0 jmp    10bc40 <fn_4+0x36c0>
0010b975          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b97b          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b981          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b987          0 decq   (%r12)
0010b98b          0 jne    10bc40 <fn_4+0x36c0>
0010b991          0 mov    %rsp,%rdi
0010b994          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b99a          0 jmp    10bc40 <fn_4+0x36c0>
0010b99f          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b9a5          0 decq   (%r12)
0010b9a9          0 jne    10bc40 <fn_4+0x36c0>
0010b9af          0 mov    %rsp,%rdi
0010b9b2          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010b9b8          0 jmp    10bc40 <fn_4+0x36c0>
0010b9bd          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b9c3          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b9c9          0 mov    %rbx,%rdi
0010b9cc          0 call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12imre_runtime7objects7StorageEBF_.llvm.7526630615700072279>
0010b9d1          0 jmp    10bc40 <fn_4+0x36c0>
0010b9d6          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b9dc          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b9e2          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010b9e8          0 mov    %rbx,%rdi
0010b9eb          0 call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12imre_runtime7objects7StorageEBF_.llvm.7526630615700072279>
0010b9f0          0 jmp    10bc40 <fn_4+0x36c0>
0010b9f5          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010b9fb          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010ba01          0 mov    %rsp,%rdi
0010ba04          0 call   10cc70 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerNtCs3V9firECmdE_12imre_runtime4ListEEB1d_.llvm.14548151582184166452>
0010ba09          0 jmp    10bc40 <fn_4+0x36c0>
0010ba0e          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010ba14          0 mov    %rsp,%rdi
0010ba17          0 call   125380 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerINtNtBG_3vec3VechEEECs3V9firECmdE_12imre_runtime.llvm.12851202843824566656>
0010ba1c          0 jmp    10bc40 <fn_4+0x36c0>
0010ba21          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010ba27          0 decq   (%rbx)
0010ba2a          0 jne    10bc40 <fn_4+0x36c0>
0010ba30          0 mov    %rsp,%rdi
0010ba33          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010ba39          0 jmp    10bc40 <fn_4+0x36c0>
0010ba3e          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010ba44          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010ba4a          0 mov    %rsp,%rdi
0010ba4d          0 call   10cc70 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerNtCs3V9firECmdE_12imre_runtime4ListEEB1d_.llvm.14548151582184166452>
0010ba52          0 jmp    10bc40 <fn_4+0x36c0>
0010ba57          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010ba5d          0 test   %r15,%r15
0010ba60          0 je     10bc40 <fn_4+0x36c0>
0010ba66          0 decq   (%r15)
0010ba69          0 jne    10bc40 <fn_4+0x36c0>
0010ba6f          0 mov    %rsp,%rdi
0010ba72          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010ba78          0 jmp    10bc40 <fn_4+0x36c0>
0010ba7d          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010ba83          0 decq   (%r12)
0010ba87          0 jne    10bc40 <fn_4+0x36c0>
0010ba8d          0 mov    %rsp,%rdi
0010ba90          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010ba96          0 jmp    10bc40 <fn_4+0x36c0>
0010ba9b          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010baa1          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010baa7          0 decq   (%rbx)
0010baaa          0 jne    10bc40 <fn_4+0x36c0>
0010bab0          0 mov    %rsp,%rdi
0010bab3          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010bab9          0 jmp    10bc40 <fn_4+0x36c0>
0010babe          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010bac4          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010baca          0 mov    %rbx,%rdi
0010bacd          0 call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12imre_runtime7objects7StorageEBF_.llvm.7526630615700072279>
0010bad2          0 jmp    10bc40 <fn_4+0x36c0>
0010bad7          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010badd          0 mov    %r12,%rax
0010bae0          0 shr    $0x38,%rax
0010bae4          0 cmp    $0xd8,%eax
0010bae9          0 jne    10bc40 <fn_4+0x36c0>
0010baef          0 movabs $0xffffffffffffff,%rax
0010baf9          0 and    %rax,%r12
0010bafc          0 mov    $0x1,%edx
0010bb01          0 mov    %rbp,%rdi
0010bb04          0 mov    %r12,%rsi
0010bb07          0 call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
0010bb0c          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bb12          0 decq   (%rbx)
0010bb15          0 jne    10bc40 <fn_4+0x36c0>
0010bb1b          0 mov    %rsp,%rdi
0010bb1e          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010bb24          0 jmp    10bc40 <fn_4+0x36c0>
0010bb29          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010bb2f          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bb35          0 mov    %r15,%rax
0010bb38          0 shr    $0x38,%rax
0010bb3c          0 cmp    $0xd8,%eax
0010bb41          0 jne    10bc40 <fn_4+0x36c0>
0010bb47          0 movabs $0xffffffffffffff,%rax
0010bb51          0 and    %rax,%r15
0010bb54          0 mov    $0x1,%edx
0010bb59          0 mov    %rbp,%rdi
0010bb5c          0 mov    %r15,%rsi
0010bb5f          0 call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
0010bb64          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bb6a          0 decq   (%r14)
0010bb6d          0 jne    10bc40 <fn_4+0x36c0>
0010bb73          0 mov    %rsp,%rdi
0010bb76          0 addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12imre_runtime7objects6ObjectE9drop_slowBH_>
0010bb7c          0 jmp    10bc40 <fn_4+0x36c0>
0010bb81          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010bb87          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bb8d          0 mov    %rbx,%rdi
0010bb90          0 call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12imre_runtime7objects7StorageEBF_.llvm.7526630615700072279>
0010bb95          0 jmp    10bc40 <fn_4+0x36c0>
0010bb9a          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010bba0          0 mov    %r14,%rax
0010bba3          0 shr    $0x38,%rax
0010bba7          0 cmp    $0xd8,%eax
0010bbac          0 jne    10bc40 <fn_4+0x36c0>
0010bbb2          0 movabs $0xffffffffffffff,%rax
0010bbbc          0 and    %rax,%r14
0010bbbf          0 mov    $0x1,%edx
0010bbc4          0 mov    %r12,%rdi
0010bbc7          0 mov    %r14,%rsi
0010bbca          0 call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
0010bbcf          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bbd5          0 mov    %rsp,%rdi
0010bbd8          0 call   10cc70 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerNtCs3V9firECmdE_12imre_runtime4ListEEB1d_.llvm.14548151582184166452>
0010bbdd          0 jmp    10bc40 <fn_4+0x36c0>
0010bbdf          0 addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
0010bbe5          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bbeb          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bbf1          0 mov    %r15,%rax
0010bbf4          0 shr    $0x38,%rax
0010bbf8          0 cmp    $0xd8,%eax
0010bbfd          0 jne    10bc40 <fn_4+0x36c0>
0010bbff          0 movabs $0xffffffffffffff,%rax
0010bc09          0 and    %rax,%r15
0010bc0c          0 mov    $0x1,%edx
0010bc11          0 mov    %r13,%rdi
0010bc14          0 mov    %r15,%rsi
0010bc17          0 call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
0010bc1c          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bc22          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bc28          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bc2e          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bc34          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bc3a          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
0010bc40          0 addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
