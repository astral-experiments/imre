
/home/dev-user/code/oss/relar/benchmarks/local/base45-decoder-thinlto/base45:     file format elf64-x86-64


Disassembly of section .text:

0000000000108580 <fn_4>:
  108580:	push   %rbp
  108581:	push   %r15
  108583:	push   %r14
  108585:	push   %r13
  108587:	push   %r12
  108589:	push   %rbx
  10858a:	sub    $0x98,%rsp
  108591:	test   %rdi,%rdi
  108594:	je     1085ae <fn_4+0x2e>
  108596:	mov    %rdi,%r14
  108599:	test   $0x1,%r14b
  10859d:	jne    108640 <fn_4+0xc0>
  1085a3:	incq   -0x10(%r14)
  1085a7:	jne    1085b1 <fn_4+0x31>
  1085a9:	jmp    10ae1e <fn_4+0x289e>
  1085ae:	xor    %r14d,%r14d
  1085b1:	lea    -0xddd25(%rip),%rsi        # 2a893 <_RNvNtNtNtNtNtCs6SLOTazmNXq_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xfd7>
  1085b8:	mov    %rsp,%rdi
  1085bb:	mov    $0x1,%edx
  1085c0:	addr32 call edea0 <_RNvNtNtCs6SLOTazmNXq_4core3str8converts9from_utf8>
  1085c6:	cmpl   $0x1,(%rsp)
  1085ca:	je     10ae7e <fn_4+0x28fe>
  1085d0:	mov    0x8(%rsp),%rdi
  1085d5:	mov    0x10(%rsp),%r12
  1085da:	cmp    $0x19,%r12
  1085de:	jae    10ae9b <fn_4+0x291b>
  1085e4:	mov    %r12,%r15
  1085e7:	shl    $0x38,%r15
  1085eb:	movabs $0xc000000000000000,%rax
  1085f5:	or     %rax,%r15
  1085f8:	cmp    $0xf,%r12
  1085fc:	jbe    10860f <fn_4+0x8f>
  1085fe:	cmp    $0x10,%r12
  108602:	jne    10873b <fn_4+0x1bb>
  108608:	xor    %eax,%eax
  10860a:	jmp    10874b <fn_4+0x1cb>
  10860f:	cmp    $0x7,%r12
  108613:	jbe    108764 <fn_4+0x1e4>
  108619:	mov    (%rdi),%r13
  10861c:	cmp    $0x8,%r12
  108620:	je     10884b <fn_4+0x2cb>
  108626:	mov    -0x8(%rdi,%r12,1),%rax
  10862b:	shl    $0x3,%r12d
  10862f:	neg    %r12b
  108632:	mov    %r12d,%ecx
  108635:	shr    %cl,%rax
  108638:	mov    %rax,%r12
  10863b:	jmp    10884e <fn_4+0x2ce>
  108640:	and    $0xfffffffffffffffe,%r14
  108644:	mov    -0x10(%r14),%rax
  108648:	inc    %rax
  10864b:	mov    %rax,-0x10(%r14)
  10864f:	je     10ae1e <fn_4+0x289e>
  108655:	lea    -0x10(%r14),%rbx
  108659:	test   %r14,%r14
  10865c:	je     108673 <fn_4+0xf3>
  10865e:	mov    %rbx,(%rsp)
  108662:	decq   (%rbx)
  108665:	jne    108670 <fn_4+0xf0>
  108667:	mov    %rsp,%rdi
  10866a:	addr32 call 133b60 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcINtNtB7_3vec3VechEE9drop_slowCs3V9firECmdE_12relar_runtime>
  108670:	mov    (%rbx),%rax
  108673:	inc    %rax
  108676:	mov    %rax,(%rbx)
  108679:	je     10ae1e <fn_4+0x289e>
  10867f:	mov    0x8(%r14),%rsi
  108683:	mov    0x10(%r14),%rdx
  108687:	lea    0x60(%rsp),%rdi
  10868c:	addr32 call edea0 <_RNvNtNtCs6SLOTazmNXq_4core3str8converts9from_utf8>
  108692:	cmpl   $0x1,0x60(%rsp)
  108697:	je     10b0ec <fn_4+0x2b6c>
  10869d:	incq   -0x10(%r14)
  1086a1:	je     10ae1e <fn_4+0x289e>
  1086a7:	xor    %edi,%edi
  1086a9:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  1086ae:	mov    %rax,%r12
  1086b1:	movzbl (%rax),%ebp
  1086b4:	mov    %rbx,(%rsp)
  1086b8:	decq   (%rbx)
  1086bb:	jne    1086c6 <fn_4+0x146>
  1086bd:	mov    %rsp,%rdi
  1086c0:	addr32 call 133b60 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcINtNtB7_3vec3VechEE9drop_slowCs3V9firECmdE_12relar_runtime>
  1086c6:	mov    $0x1,%ebx
  1086cb:	test   %bpl,%bpl
  1086ce:	jne    10b113 <fn_4+0x2b93>
  1086d4:	mov    0x10(%r14),%rsi
  1086d8:	test   %rsi,%rsi
  1086db:	je     108788 <fn_4+0x208>
  1086e1:	mov    0x60498(%rip),%r13        # 168b80 <module_value_1>
  1086e8:	test   %r13,%r13
  1086eb:	je     1086fb <fn_4+0x17b>
  1086ed:	incq   -0x10(%r13)
  1086f1:	je     10ae1e <fn_4+0x289e>
  1086f7:	mov    0x10(%r14),%rsi
  1086fb:	mov    0x8(%r14),%rdi
  1086ff:	mov    %r13,%rdx
  108702:	call   119f90 <_RNvNtNtCs3V9firECmdE_12relar_runtime7objects8mappings14gather_str_int.llvm.9568189375700981541>
  108707:	mov    %rax,%r15
  10870a:	movzbl (%r12),%ebx
  10870f:	test   %r13,%r13
  108712:	je     10872b <fn_4+0x1ab>
  108714:	lea    -0x10(%r13),%rax
  108718:	mov    %rax,(%rsp)
  10871c:	decq   -0x10(%r13)
  108720:	jne    10872b <fn_4+0x1ab>
  108722:	mov    %rsp,%rdi
  108725:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10872b:	test   %bl,%bl
  10872d:	jne    10b1b2 <fn_4+0x2c32>
  108733:	mov    %r15,%r13
  108736:	jmp    1087f3 <fn_4+0x273>
  10873b:	mov    -0x8(%rdi,%r12,1),%rax
  108740:	mov    %r12d,%ecx
  108743:	neg    %cl
  108745:	shl    $0x3,%cl
  108748:	shr    %cl,%rax
  10874b:	mov    (%rdi),%r13
  10874e:	xor    %ecx,%ecx
  108750:	cmp    $0x18,%r12
  108754:	mov    0x8(%rdi),%r12
  108758:	cmove  %rcx,%r15
  10875c:	or     %rax,%r15
  10875f:	jmp    10884e <fn_4+0x2ce>
  108764:	cmp    $0x3,%r12
  108768:	jbe    108827 <fn_4+0x2a7>
  10876e:	mov    -0x4(%rdi,%r12,1),%r13d
  108773:	add    $0xfffffffffffffffc,%r12
  108777:	shl    $0x3,%r12d
  10877b:	mov    %r12d,%ecx
  10877e:	shl    %cl,%r13
  108781:	mov    (%rdi),%eax
  108783:	jmp    108848 <fn_4+0x2c8>
  108788:	movq   $0x1,(%rsp)
  108790:	movq   $0x1,0x8(%rsp)
  108799:	movq   $0x0,0x10(%rsp)
  1087a2:	movq   $0x8,0x18(%rsp)
  1087ab:	movq   $0x0,0x20(%rsp)
  1087b4:	mov    $0x28,%edi
  1087b9:	mov    $0x8,%esi
  1087be:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  1087c3:	test   %rax,%rax
  1087c6:	je     10b1ca <fn_4+0x2c4a>
  1087cc:	mov    %rax,%r13
  1087cf:	mov    0x20(%rsp),%rax
  1087d4:	mov    %rax,0x20(%r13)
  1087d8:	movdqu (%rsp),%xmm0
  1087dd:	movdqu 0x10(%rsp),%xmm1
  1087e3:	movdqu %xmm1,0x10(%r13)
  1087e9:	movdqu %xmm0,0x0(%r13)
  1087ef:	add    $0x10,%r13
  1087f3:	movzbl (%r12),%ebx
  1087f8:	lea    -0x10(%r14),%rax
  1087fc:	mov    %rax,(%rsp)
  108800:	decq   -0x10(%r14)
  108804:	jne    10880f <fn_4+0x28f>
  108806:	mov    %rsp,%rdi
  108809:	addr32 call 133b60 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcINtNtB7_3vec3VechEE9drop_slowCs3V9firECmdE_12relar_runtime>
  10880f:	test   %bl,%bl
  108811:	je     108b7f <fn_4+0x5ff>
  108817:	xor    %r13d,%r13d
  10881a:	xor    %r12d,%r12d
  10881d:	mov    $0x1,%ebx
  108822:	jmp    1091b6 <fn_4+0xc36>
  108827:	cmp    $0x1,%r12
  10882b:	jbe    1089a6 <fn_4+0x426>
  108831:	movzwl -0x2(%rdi,%r12,1),%r13d
  108837:	add    $0xfffffffffffffffe,%r12
  10883b:	shl    $0x3,%r12d
  10883f:	mov    %r12d,%ecx
  108842:	shl    %cl,%r13
  108845:	movzwl (%rdi),%eax
  108848:	or     %rax,%r13
  10884b:	xor    %r12d,%r12d
  10884e:	mov    $0x28,%edi
  108853:	mov    $0x8,%esi
  108858:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10885d:	test   %rax,%rax
  108860:	je     10aeb8 <fn_4+0x2938>
  108866:	mov    %rax,%rbx
  108869:	movq   $0x1,(%rax)
  108870:	movq   $0x1,0x8(%rax)
  108878:	add    $0x10,%rax
  10887c:	mov    %r13,0x10(%rbx)
  108880:	mov    %r12,0x18(%rbx)
  108884:	mov    %r15,0x20(%rbx)
  108888:	mov    %rax,(%rsp)
  10888c:	movzbl 0x17(%r14),%eax
  108891:	lea    0x40(%rax),%ecx
  108894:	movzbl %cl,%ecx
  108897:	cmp    $0x18,%cl
  10889a:	mov    $0x18,%edx
  10889f:	cmovb  %ecx,%edx
  1088a2:	cmp    $0xd8,%al
  1088a4:	mov    (%r14),%rdi
  1088a7:	cmovb  %r14,%rdi
  1088ab:	movzbl %dl,%esi
  1088ae:	cmovae 0x8(%r14),%rsi
  1088b3:	mov    %rsp,%rdx
  1088b6:	call   12b170 <_RINvMNtCs6SLOTazmNXq_4core3stre16trim_end_matchesNCNvNtCs3V9firECmdE_12relar_runtime7objects15relar_str_rstrip0EBR_>
  1088bb:	mov    %rdx,%r13
  1088be:	mov    0x8(%r14),%rcx
  1088c2:	movzbl 0x17(%r14),%edx
  1088c7:	lea    -0xc0(%rdx),%rsi
  1088ce:	cmp    $0x18,%rsi
  1088d2:	mov    $0x18,%edi
  1088d7:	cmovb  %rsi,%rdi
  1088db:	cmp    $0xd8,%rdx
  1088e2:	cmovae %rcx,%rdi
  1088e6:	cmp    %rdi,%r13
  1088e9:	jne    10890f <fn_4+0x38f>
  1088eb:	incq   -0x10(%r14)
  1088ef:	mov    %r14,%r12
  1088f2:	je     10ae1e <fn_4+0x289e>
  1088f8:	lea    -0x10(%r14),%rax
  1088fc:	mov    %rax,(%rsp)
  108900:	decq   -0x10(%r14)
  108904:	jne    108a2b <fn_4+0x4ab>
  10890a:	jmp    108a22 <fn_4+0x4a2>
  10890f:	cmp    $0x19,%r13
  108913:	jae    10afdf <fn_4+0x2a5f>
  108919:	mov    %r13,%r15
  10891c:	shl    $0x38,%r15
  108920:	movabs $0xc000000000000000,%rcx
  10892a:	or     %rcx,%r15
  10892d:	cmp    $0xf,%r13
  108931:	jbe    10893d <fn_4+0x3bd>
  108933:	cmp    $0x10,%r13
  108937:	jne    108967 <fn_4+0x3e7>
  108939:	xor    %edx,%edx
  10893b:	jmp    108977 <fn_4+0x3f7>
  10893d:	cmp    $0x7,%r13
  108941:	jbe    10898d <fn_4+0x40d>
  108943:	mov    (%rax),%rbp
  108946:	cmp    $0x8,%r13
  10894a:	je     1089d5 <fn_4+0x455>
  108950:	mov    -0x8(%rax,%r13,1),%rax
  108955:	shl    $0x3,%r13d
  108959:	neg    %r13b
  10895c:	mov    %r13d,%ecx
  10895f:	shr    %cl,%rax
  108962:	mov    %rax,%r13
  108965:	jmp    1089d8 <fn_4+0x458>
  108967:	mov    -0x8(%rax,%r13,1),%rdx
  10896c:	mov    %r13d,%ecx
  10896f:	neg    %cl
  108971:	shl    $0x3,%cl
  108974:	shr    %cl,%rdx
  108977:	mov    (%rax),%rbp
  10897a:	xor    %ecx,%ecx
  10897c:	cmp    $0x18,%r13
  108980:	mov    0x8(%rax),%r13
  108984:	cmove  %rcx,%r15
  108988:	or     %rdx,%r15
  10898b:	jmp    1089d8 <fn_4+0x458>
  10898d:	cmp    $0x3,%r13
  108991:	jbe    1089b5 <fn_4+0x435>
  108993:	lea    -0x4(%r13),%rcx
  108997:	mov    -0x4(%rax,%r13,1),%ebp
  10899c:	shl    $0x3,%ecx
  10899f:	shl    %cl,%rbp
  1089a2:	mov    (%rax),%eax
  1089a4:	jmp    1089d2 <fn_4+0x452>
  1089a6:	jne    10a478 <fn_4+0x1ef8>
  1089ac:	movzbl (%rdi),%r13d
  1089b0:	jmp    10884b <fn_4+0x2cb>
  1089b5:	cmp    $0x1,%r13
  1089b9:	jbe    10a483 <fn_4+0x1f03>
  1089bf:	lea    -0x2(%r13),%rcx
  1089c3:	movzwl -0x2(%rax,%r13,1),%ebp
  1089c9:	shl    $0x3,%ecx
  1089cc:	shl    %cl,%rbp
  1089cf:	movzwl (%rax),%eax
  1089d2:	or     %rax,%rbp
  1089d5:	xor    %r13d,%r13d
  1089d8:	mov    $0x28,%edi
  1089dd:	mov    $0x8,%esi
  1089e2:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  1089e7:	test   %rax,%rax
  1089ea:	je     10afff <fn_4+0x2a7f>
  1089f0:	mov    %rax,%r12
  1089f3:	movq   $0x1,(%r12)
  1089fb:	movq   $0x1,0x8(%r12)
  108a04:	add    $0x10,%r12
  108a08:	mov    %rbp,0x10(%rax)
  108a0c:	mov    %r13,0x18(%rax)
  108a10:	mov    %r15,0x20(%rax)
  108a14:	lea    -0x10(%r14),%rax
  108a18:	mov    %rax,(%rsp)
  108a1c:	decq   -0x10(%r14)
  108a20:	jne    108a2b <fn_4+0x4ab>
  108a22:	mov    %rsp,%rdi
  108a25:	addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12relar_runtime>
  108a2b:	mov    %rbx,(%rsp)
  108a2f:	decq   (%rbx)
  108a32:	jne    108a3d <fn_4+0x4bd>
  108a34:	mov    %rsp,%rdi
  108a37:	addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12relar_runtime>
  108a3d:	mov    0x8(%r12),%rax
  108a42:	movzbl 0x17(%r12),%ecx
  108a48:	lea    -0xc0(%rcx),%rdx
  108a4f:	cmp    $0xd8,%rcx
  108a56:	cmovae %rax,%rdx
  108a5a:	test   %rdx,%rdx
  108a5d:	je     108ae5 <fn_4+0x565>
  108a63:	mov    0x60116(%rip),%r14        # 168b80 <module_value_1>
  108a6a:	test   %r14,%r14
  108a6d:	je     108a84 <fn_4+0x504>
  108a6f:	incq   -0x10(%r14)
  108a73:	je     10ae1e <fn_4+0x289e>
  108a79:	movzbl 0x17(%r12),%ecx
  108a7f:	mov    0x8(%r12),%rax
  108a84:	lea    0x40(%rcx),%edx
  108a87:	movzbl %dl,%edx
  108a8a:	cmp    $0x18,%dl
  108a8d:	mov    $0x18,%esi
  108a92:	cmovb  %edx,%esi
  108a95:	cmp    $0xd8,%cl
  108a98:	mov    (%r12),%rdi
  108a9c:	cmovb  %r12,%rdi
  108aa0:	movzbl %sil,%esi
  108aa4:	cmovae %rax,%rsi
  108aa8:	mov    %r14,%rdx
  108aab:	call   119f90 <_RNvNtNtCs3V9firECmdE_12relar_runtime7objects8mappings14gather_str_int.llvm.9568189375700981541>
  108ab0:	mov    %rax,%r13
  108ab3:	xor    %edi,%edi
  108ab5:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  108aba:	mov    %rax,%r15
  108abd:	movzbl (%rax),%ebx
  108ac0:	test   %r14,%r14
  108ac3:	je     108adc <fn_4+0x55c>
  108ac5:	lea    -0x10(%r14),%rax
  108ac9:	mov    %rax,(%rsp)
  108acd:	decq   -0x10(%r14)
  108ad1:	jne    108adc <fn_4+0x55c>
  108ad3:	mov    %rsp,%rdi
  108ad6:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  108adc:	test   %bl,%bl
  108ade:	je     108b5a <fn_4+0x5da>
  108ae0:	xor    %r13d,%r13d
  108ae3:	jmp    108b5a <fn_4+0x5da>
  108ae5:	movq   $0x1,(%rsp)
  108aed:	movq   $0x1,0x8(%rsp)
  108af6:	movq   $0x0,0x10(%rsp)
  108aff:	movq   $0x8,0x18(%rsp)
  108b08:	movq   $0x0,0x20(%rsp)
  108b11:	mov    $0x28,%edi
  108b16:	mov    $0x8,%esi
  108b1b:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  108b20:	test   %rax,%rax
  108b23:	je     10b16e <fn_4+0x2bee>
  108b29:	mov    %rax,%r13
  108b2c:	mov    0x20(%rsp),%rax
  108b31:	mov    %rax,0x20(%r13)
  108b35:	movdqu (%rsp),%xmm0
  108b3a:	movdqu 0x10(%rsp),%xmm1
  108b40:	movdqu %xmm1,0x10(%r13)
  108b46:	movdqu %xmm0,0x0(%r13)
  108b4c:	add    $0x10,%r13
  108b50:	xor    %edi,%edi
  108b52:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  108b57:	mov    %rax,%r15
  108b5a:	movzbl (%r15),%ebx
  108b5e:	lea    -0x10(%r12),%rax
  108b63:	mov    %rax,(%rsp)
  108b67:	decq   -0x10(%r12)
  108b6c:	jne    108b77 <fn_4+0x5f7>
  108b6e:	mov    %rsp,%rdi
  108b71:	addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12relar_runtime>
  108b77:	test   %bl,%bl
  108b79:	jne    10aec8 <fn_4+0x2948>
  108b7f:	mov    0x10(%r13),%rbp
  108b83:	movabs $0xaaaaaaaaaaaaaaab,%rbx
  108b8d:	mov    %rbp,%rax
  108b90:	imul   %rbx,%rax
  108b94:	movabs $0x5555555555555555,%rcx
  108b9e:	add    %rax,%rcx
  108ba1:	movabs $0x5555555555555554,%rax
  108bab:	cmp    %rax,%rcx
  108bae:	mov    %r13,0x48(%rsp)
  108bb3:	ja     108c17 <fn_4+0x697>
  108bb5:	lea    -0xde31c(%rip),%rsi        # 2a8a0 <_RNvNtNtNtNtNtCs6SLOTazmNXq_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xfe4>
  108bbc:	mov    %rsp,%rdi
  108bbf:	mov    $0x15,%edx
  108bc4:	addr32 call edea0 <_RNvNtNtCs6SLOTazmNXq_4core3str8converts9from_utf8>
  108bca:	cmpl   $0x1,(%rsp)
  108bce:	je     10af24 <fn_4+0x29a4>
  108bd4:	mov    0x8(%rsp),%rdi
  108bd9:	mov    0x10(%rsp),%r15
  108bde:	cmp    $0x19,%r15
  108be2:	jae    10af4b <fn_4+0x29cb>
  108be8:	mov    %r15,%r14
  108beb:	shl    $0x38,%r14
  108bef:	movabs $0xc000000000000000,%rax
  108bf9:	or     %rax,%r14
  108bfc:	cmp    $0xf,%r15
  108c00:	jbe    108ceb <fn_4+0x76b>
  108c06:	cmp    $0x10,%r15
  108c0a:	jne    108f77 <fn_4+0x9f7>
  108c10:	xor    %eax,%eax
  108c12:	jmp    108f87 <fn_4+0xa07>
  108c17:	movq   $0x1,(%rsp)
  108c1f:	movq   $0x1,0x8(%rsp)
  108c28:	movq   $0x0,0x10(%rsp)
  108c31:	movq   $0x8,0x18(%rsp)
  108c3a:	movq   $0x0,0x20(%rsp)
  108c43:	mov    $0x28,%edi
  108c48:	mov    $0x8,%esi
  108c4d:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  108c52:	test   %rax,%rax
  108c55:	je     10af14 <fn_4+0x2994>
  108c5b:	mov    %rax,%r11
  108c5e:	lea    0x0(,%rbp,2),%rax
  108c66:	mov    %rax,0x90(%rsp)
  108c6e:	mov    %r11,%r14
  108c71:	mov    0x20(%rsp),%rax
  108c76:	mov    %rax,0x20(%r11)
  108c7a:	movdqu (%rsp),%xmm0
  108c7f:	movdqu 0x10(%rsp),%xmm1
  108c85:	movdqu %xmm1,0x10(%r11)
  108c8b:	movdqu %xmm0,(%r11)
  108c90:	add    $0x10,%r11
  108c94:	cmp    %r11,%r13
  108c97:	mov    %r14,0x50(%rsp)
  108c9c:	mov    %r11,0x40(%rsp)
  108ca1:	je     108d1c <fn_4+0x79c>
  108ca3:	test   %rbp,%rbp
  108ca6:	je     108d25 <fn_4+0x7a5>
  108ca8:	lea    -0x1(%rbp),%rax
  108cac:	mul    %rbx
  108caf:	shr    $1,%rdx
  108cb2:	lea    0x1(%rdx),%rcx
  108cb6:	mov    0x10(%r13),%rax
  108cba:	lea    0x3(%rax),%rsi
  108cbe:	shr    $0x2,%rsi
  108cc2:	cmp    %rcx,%rsi
  108cc5:	ja     10984e <fn_4+0x12ce>
  108ccb:	test   %rax,%rax
  108cce:	je     10a352 <fn_4+0x1dd2>
  108cd4:	mov    0x8(%r13),%rcx
  108cd8:	cmp    $0x4,%rax
  108cdc:	jae    109776 <fn_4+0x11f6>
  108ce2:	xor    %esi,%esi
  108ce4:	xor    %edi,%edi
  108ce6:	jmp    10980f <fn_4+0x128f>
  108ceb:	cmp    $0x7,%r15
  108cef:	jbe    108fa0 <fn_4+0xa20>
  108cf5:	mov    (%rdi),%r12
  108cf8:	cmp    $0x8,%r15
  108cfc:	je     109074 <fn_4+0xaf4>
  108d02:	mov    -0x8(%rdi,%r15,1),%rax
  108d07:	shl    $0x3,%r15d
  108d0b:	neg    %r15b
  108d0e:	mov    %r15d,%ecx
  108d11:	shr    %cl,%rax
  108d14:	mov    %rax,%r15
  108d17:	jmp    109077 <fn_4+0xaf7>
  108d1c:	test   %rbp,%rbp
  108d1f:	jne    10984e <fn_4+0x12ce>
  108d25:	mov    $0x1,%ebx
  108d2a:	mov    0x50(%rsp),%rax
  108d2f:	mov    0x20(%rax),%r12
  108d33:	test   %r12,%r12
  108d36:	je     108fc4 <fn_4+0xa44>
  108d3c:	mov    0x18(%rax),%rbp
  108d40:	mov    $0x1,%esi
  108d45:	mov    %r12,%rdi
  108d48:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  108d4d:	test   %rax,%rax
  108d50:	mov    %rbx,0x58(%rsp)
  108d55:	je     1093c4 <fn_4+0xe44>
  108d5b:	mov    %r12,0x60(%rsp)
  108d60:	mov    %rax,0x68(%rsp)
  108d65:	movq   $0x0,0x70(%rsp)
  108d6e:	lea    0x3f(%r12),%r9
  108d73:	shr    $0x6,%r9
  108d77:	lea    0x10(%rbp),%rdx
  108d7b:	lea    0x2(%rax),%rsi
  108d7f:	lea    0x1(%rax),%rdi
  108d83:	xor    %r8d,%r8d
  108d86:	movdqa -0xf768e(%rip),%xmm0        # 11700 <anon.dd6a8a796c10bf5c67fa0e87de5edd21.24.llvm.9568189375700981541+0x900>
  108d8e:	movdqa -0xf7cf6(%rip),%xmm1        # 110a0 <anon.dd6a8a796c10bf5c67fa0e87de5edd21.24.llvm.9568189375700981541+0x2a0>
  108d96:	mov    %rbp,%r10
  108d99:	mov    %r12,%r11
  108d9c:	mov    %rbp,0x78(%rsp)
  108da1:	mov    %rax,0x90(%rsp)
  108da9:	mov    %r9,0x80(%rsp)
  108db1:	jmp    108e0d <fn_4+0x88d>
  108db3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  108dc0:	test   $0xfffffffffffffe01,%rbx
  108dc7:	mov    0x58(%rsp),%rbx
  108dcc:	mov    0x78(%rsp),%rbp
  108dd1:	mov    0x90(%rsp),%rax
  108dd9:	mov    0x80(%rsp),%r9
  108de1:	jne    10ae20 <fn_4+0x28a0>
  108de7:	inc    %r8
  108dea:	add    $0xffffffffffffffc0,%r11
  108dee:	add    $0x200,%rdx
  108df5:	add    $0x40,%rsi
  108df9:	add    $0x200,%r10
  108e00:	add    $0x40,%rdi
  108e04:	cmp    %r9,%r8
  108e07:	je     108fd6 <fn_4+0xa56>
  108e0d:	cmp    $0x40,%r11
  108e11:	mov    $0x40,%r14d
  108e17:	cmovb  %r11,%r14
  108e1b:	mov    %r8,%r13
  108e1e:	shl    $0x6,%r13
  108e22:	mov    %r12,%r15
  108e25:	sub    %r13,%r15
  108e28:	cmp    $0x40,%r15
  108e2c:	mov    $0x40,%ecx
  108e31:	cmovae %rcx,%r15
  108e35:	mov    %r12,%rcx
  108e38:	sub    %r13,%rcx
  108e3b:	je     108de7 <fn_4+0x867>
  108e3d:	add    %rax,%r13
  108e40:	mov    %r8,%r9
  108e43:	shl    $0x9,%r9
  108e47:	add    %rbp,%r9
  108e4a:	cmp    $0x4,%rcx
  108e4e:	jb     108e65 <fn_4+0x8e5>
  108e50:	mov    %r15d,%ecx
  108e53:	lea    (%r9,%rcx,8),%rcx
  108e57:	cmp    %rcx,%r13
  108e5a:	jae    108ed6 <fn_4+0x956>
  108e5c:	lea    (%r15,%r13,1),%rcx
  108e60:	cmp    %rcx,%r9
  108e63:	jae    108ed6 <fn_4+0x956>
  108e65:	xor    %ebx,%ebx
  108e67:	xor    %ebp,%ebp
  108e69:	mov    %rbp,%rcx
  108e6c:	or     $0x1,%rcx
  108e70:	test   $0x1,%r15b
  108e74:	je     108e8e <fn_4+0x90e>
  108e76:	mov    (%r9,%rbp,8),%rax
  108e7a:	mov    %rax,%r9
  108e7d:	xor    $0x1,%r9
  108e81:	or     %r9,%rbx
  108e84:	shr    $1,%eax
  108e86:	mov    %al,0x0(%r13,%rbp,1)
  108e8b:	mov    %rcx,%rbp
  108e8e:	cmp    %rcx,%r15
  108e91:	je     108dc0 <fn_4+0x840>
  108e97:	nopw   0x0(%rax,%rax,1)
  108ea0:	mov    (%r10,%rbp,8),%rax
  108ea4:	mov    %rax,%rcx
  108ea7:	xor    $0x1,%rcx
  108eab:	or     %rbx,%rcx
  108eae:	shr    $1,%eax
  108eb0:	mov    %al,-0x1(%rdi,%rbp,1)
  108eb4:	mov    0x8(%r10,%rbp,8),%rax
  108eb9:	mov    %rax,%rbx
  108ebc:	shr    $1,%eax
  108ebe:	mov    %al,(%rdi,%rbp,1)
  108ec1:	add    $0x2,%rbp
  108ec5:	xor    $0x1,%rbx
  108ec9:	or     %rcx,%rbx
  108ecc:	cmp    %rbp,%r14
  108ecf:	jne    108ea0 <fn_4+0x920>
  108ed1:	jmp    108dc0 <fn_4+0x840>
  108ed6:	mov    %r14d,%ebx
  108ed9:	and    $0x7c,%ebx
  108edc:	mov    %r15d,%ebp
  108edf:	and    $0x7c,%ebp
  108ee2:	pxor   %xmm2,%xmm2
  108ee6:	xor    %ecx,%ecx
  108ee8:	pxor   %xmm3,%xmm3
  108eec:	nopl   0x0(%rax)
  108ef0:	movdqu -0x10(%rdx,%rcx,8),%xmm4
  108ef6:	movdqu (%rdx,%rcx,8),%xmm5
  108efb:	movdqa %xmm4,%xmm6
  108eff:	pxor   %xmm0,%xmm6
  108f03:	por    %xmm6,%xmm3
  108f07:	movdqa %xmm5,%xmm6
  108f0b:	pxor   %xmm0,%xmm6
  108f0f:	por    %xmm6,%xmm2
  108f13:	psrlq  $0x1,%xmm4
  108f18:	psrlq  $0x1,%xmm5
  108f1d:	pand   %xmm1,%xmm4
  108f21:	packuswb %xmm4,%xmm4
  108f25:	packuswb %xmm4,%xmm4
  108f29:	packuswb %xmm4,%xmm4
  108f2d:	pand   %xmm1,%xmm5
  108f31:	packuswb %xmm5,%xmm5
  108f35:	packuswb %xmm5,%xmm5
  108f39:	packuswb %xmm5,%xmm5
  108f3d:	movd   %xmm4,%eax
  108f41:	mov    %ax,-0x2(%rsi,%rcx,1)
  108f46:	movd   %xmm5,%eax
  108f4a:	mov    %ax,(%rsi,%rcx,1)
  108f4e:	add    $0x4,%rcx
  108f52:	cmp    %rcx,%rbx
  108f55:	jne    108ef0 <fn_4+0x970>
  108f57:	por    %xmm3,%xmm2
  108f5b:	pshufd $0xee,%xmm2,%xmm3
  108f60:	por    %xmm2,%xmm3
  108f64:	movq   %xmm3,%rbx
  108f69:	cmp    %rbp,%r15
  108f6c:	je     108dc0 <fn_4+0x840>
  108f72:	jmp    108e69 <fn_4+0x8e9>
  108f77:	mov    -0x8(%rdi,%r15,1),%rax
  108f7c:	mov    %r15d,%ecx
  108f7f:	neg    %cl
  108f81:	shl    $0x3,%cl
  108f84:	shr    %cl,%rax
  108f87:	mov    (%rdi),%r12
  108f8a:	xor    %ecx,%ecx
  108f8c:	cmp    $0x18,%r15
  108f90:	mov    0x8(%rdi),%r15
  108f94:	cmove  %rcx,%r14
  108f98:	or     %rax,%r14
  108f9b:	jmp    109077 <fn_4+0xaf7>
  108fa0:	cmp    $0x3,%r15
  108fa4:	jbe    109050 <fn_4+0xad0>
  108faa:	mov    -0x4(%rdi,%r15,1),%r12d
  108faf:	add    $0xfffffffffffffffc,%r15
  108fb3:	shl    $0x3,%r15d
  108fb7:	mov    %r15d,%ecx
  108fba:	shl    %cl,%r12
  108fbd:	mov    (%rdi),%eax
  108fbf:	jmp    109071 <fn_4+0xaf1>
  108fc4:	movq   $0x0,0x60(%rsp)
  108fcd:	movq   $0x1,0x68(%rsp)
  108fd6:	mov    %r12,0x70(%rsp)
  108fdb:	mov    %r12,0x20(%rsp)
  108fe0:	mov    0x60(%rsp),%rax
  108fe5:	mov    %rax,0x10(%rsp)
  108fea:	mov    0x68(%rsp),%rax
  108fef:	mov    %rax,0x18(%rsp)
  108ff4:	movq   $0x1,(%rsp)
  108ffc:	movq   $0x1,0x8(%rsp)
  109005:	mov    $0x28,%edi
  10900a:	mov    $0x8,%esi
  10900f:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  109014:	test   %rax,%rax
  109017:	je     10b1ba <fn_4+0x2c3a>
  10901d:	mov    %rax,%r12
  109020:	mov    0x20(%rsp),%rax
  109025:	mov    %rax,0x20(%r12)
  10902a:	movdqu (%rsp),%xmm0
  10902f:	movdqu 0x10(%rsp),%xmm1
  109035:	movdqu %xmm1,0x10(%r12)
  10903c:	movdqu %xmm0,(%r12)
  109042:	add    $0x10,%r12
  109046:	mov    0x48(%rsp),%r13
  10904b:	jmp    109410 <fn_4+0xe90>
  109050:	cmp    $0x1,%r15
  109054:	jbe    109767 <fn_4+0x11e7>
  10905a:	movzwl -0x2(%rdi,%r15,1),%r12d
  109060:	add    $0xfffffffffffffffe,%r15
  109064:	shl    $0x3,%r15d
  109068:	mov    %r15d,%ecx
  10906b:	shl    %cl,%r12
  10906e:	movzwl (%rdi),%eax
  109071:	or     %rax,%r12
  109074:	xor    %r15d,%r15d
  109077:	mov    $0x28,%edi
  10907c:	mov    $0x8,%esi
  109081:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  109086:	test   %rax,%rax
  109089:	je     10af68 <fn_4+0x29e8>
  10908f:	mov    %rax,%r13
  109092:	movq   $0x1,0x8(%rax)
  10909a:	mov    %r12,0x10(%rax)
  10909e:	mov    %r15,0x18(%rax)
  1090a2:	mov    %r14,0x20(%rax)
  1090a6:	movq   $0x2,(%rax)
  1090ad:	movq   $0x1,(%rsp)
  1090b5:	movq   $0x1,0x8(%rsp)
  1090be:	mov    %rax,0x10(%rsp)
  1090c3:	movq   $0x0,0x18(%rsp)
  1090cc:	movl   $0x8,0x20(%rsp)
  1090d4:	movb   $0x0,0x24(%rsp)
  1090d9:	movb   $0x8,0x39(%rsp)
  1090de:	mov    $0x40,%edi
  1090e3:	mov    $0x8,%esi
  1090e8:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  1090ed:	test   %rax,%rax
  1090f0:	je     10af78 <fn_4+0x29f8>
  1090f6:	mov    %rax,%r14
  1090f9:	movdqu (%rsp),%xmm0
  1090fe:	movdqu 0x10(%rsp),%xmm1
  109104:	movdqu 0x20(%rsp),%xmm2
  10910a:	movdqu 0x30(%rsp),%xmm3
  109110:	movdqu %xmm3,0x30(%rax)
  109115:	movdqu %xmm2,0x20(%rax)
  10911a:	movdqu %xmm1,0x10(%rax)
  10911f:	movdqu %xmm0,(%rax)
  109123:	mov    %r13,(%rsp)
  109127:	decq   0x0(%r13)
  10912b:	jne    109136 <fn_4+0xbb6>
  10912d:	mov    %rsp,%rdi
  109130:	addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12relar_runtime>
  109136:	cmpb   $0x8,0x39(%r14)
  10913b:	mov    0x48(%rsp),%r13
  109140:	jne    10af8d <fn_4+0x2a0d>
  109146:	incq   (%r14)
  109149:	je     10ae1e <fn_4+0x289e>
  10914f:	mov    %r14,0x60(%rsp)
  109154:	xor    %edi,%edi
  109156:	call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  10915b:	test   %rax,%rax
  10915e:	je     10b467 <fn_4+0x2ee7>
  109164:	mov    %r14,(%rsp)
  109168:	cmpq   $0x0,(%rax)
  10916c:	jne    10afaa <fn_4+0x2a2a>
  109172:	mov    0x8(%rax),%rbx
  109176:	mov    %r14,0x8(%rax)
  10917a:	mov    %rsp,%rdi
  10917d:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  109182:	movb   $0x1,(%rax)
  109185:	mov    %rbx,(%rsp)
  109189:	test   %rbx,%rbx
  10918c:	je     10919c <fn_4+0xc1c>
  10918e:	decq   (%rbx)
  109191:	jne    10919c <fn_4+0xc1c>
  109193:	mov    %rsp,%rdi
  109196:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10919c:	mov    %r14,(%rsp)
  1091a0:	decq   (%r14)
  1091a3:	jne    1091ae <fn_4+0xc2e>
  1091a5:	mov    %rsp,%rdi
  1091a8:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  1091ae:	mov    $0x1,%ebx
  1091b3:	xor    %r12d,%r12d
  1091b6:	xor    %edi,%edi
  1091b8:	call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  1091bd:	test   %rax,%rax
  1091c0:	je     10b45a <fn_4+0x2eda>
  1091c6:	cmpq   $0x0,(%rax)
  1091ca:	jne    10aed0 <fn_4+0x2950>
  1091d0:	mov    %rbx,0x58(%rsp)
  1091d5:	mov    0x8(%rax),%rbx
  1091d9:	pxor   %xmm0,%xmm0
  1091dd:	movdqu %xmm0,(%rax)
  1091e1:	mov    %rsp,%rdi
  1091e4:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  1091e9:	movb   $0x0,(%rax)
  1091ec:	test   %rbx,%rbx
  1091ef:	je     10aedd <fn_4+0x295d>
  1091f5:	cmpb   $0x8,0x39(%rbx)
  1091f9:	jne    10aef7 <fn_4+0x2977>
  1091ff:	mov    0x20(%rbx),%ecx
  109202:	xor    %eax,%eax
  109204:	cmp    $0x13,%ecx
  109207:	ja     109215 <fn_4+0xc95>
  109209:	mov    $0xe0100,%edx
  10920e:	bt     %ecx,%edx
  109211:	jae    109215 <fn_4+0xc95>
  109213:	mov    $0x1,%al
  109215:	cmp    $0x7,%ecx
  109218:	sete   %dl
  10921b:	cmp    $0xe,%ecx
  10921e:	sete   %sil
  109222:	or     %dl,%sil
  109225:	mov    (%rbx),%rcx
  109228:	inc    %rcx
  10922b:	or     %al,%sil
  10922e:	mov    %rcx,(%rbx)
  109231:	je     1092e3 <fn_4+0xd63>
  109237:	test   %rcx,%rcx
  10923a:	je     10ae1e <fn_4+0x289e>
  109240:	mov    %rbx,0x60(%rsp)
  109245:	xor    %edi,%edi
  109247:	call   12e3a0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions6ACTIVE00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1e_6option6OptionQIB1T_INtNtB1e_4cell7RefCellIB1T_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  10924c:	test   %rax,%rax
  10924f:	je     10b484 <fn_4+0x2f04>
  109255:	mov    %rbx,(%rsp)
  109259:	cmpq   $0x0,(%rax)
  10925d:	jne    10b00f <fn_4+0x2a8f>
  109263:	mov    0x8(%rax),%r15
  109267:	mov    %rbx,0x8(%rax)
  10926b:	lea    0x10(%r15),%rax
  10926f:	test   %r15,%r15
  109272:	cmove  %r15,%rax
  109276:	mov    %rax,0x50(%rsp)
  10927b:	lea    -0xde9e2(%rip),%rsi        # 2a8a0 <_RNvNtNtNtNtNtCs6SLOTazmNXq_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xfe4>
  109282:	mov    %rsp,%rdi
  109285:	mov    $0x15,%edx
  10928a:	addr32 call edea0 <_RNvNtNtCs6SLOTazmNXq_4core3str8converts9from_utf8>
  109290:	cmpl   $0x1,(%rsp)
  109294:	je     10b01c <fn_4+0x2a9c>
  10929a:	mov    %r12,0x40(%rsp)
  10929f:	mov    %r13,0x48(%rsp)
  1092a4:	mov    0x8(%rsp),%rdi
  1092a9:	mov    0x10(%rsp),%r13
  1092ae:	cmp    $0x19,%r13
  1092b2:	jae    10b039 <fn_4+0x2ab9>
  1092b8:	mov    %r13,%r12
  1092bb:	shl    $0x38,%r12
  1092bf:	movabs $0xc000000000000000,%rax
  1092c9:	or     %rax,%r12
  1092cc:	cmp    $0xf,%r13
  1092d0:	jbe    10934a <fn_4+0xdca>
  1092d2:	cmp    $0x10,%r13
  1092d6:	jne    109377 <fn_4+0xdf7>
  1092dc:	xor    %eax,%eax
  1092de:	jmp    109387 <fn_4+0xe07>
  1092e3:	test   %rcx,%rcx
  1092e6:	je     10ae1e <fn_4+0x289e>
  1092ec:	mov    %rbx,0x60(%rsp)
  1092f1:	xor    %edi,%edi
  1092f3:	call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  1092f8:	test   %rax,%rax
  1092fb:	je     10b4e1 <fn_4+0x2f61>
  109301:	mov    %rbx,(%rsp)
  109305:	cmpq   $0x0,(%rax)
  109309:	jne    10b1a5 <fn_4+0x2c25>
  10930f:	mov    0x8(%rax),%r14
  109313:	mov    %rbx,0x8(%rax)
  109317:	mov    %rsp,%rdi
  10931a:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  10931f:	movb   $0x1,(%rax)
  109322:	mov    %r14,(%rsp)
  109326:	test   %r14,%r14
  109329:	je     109339 <fn_4+0xdb9>
  10932b:	decq   (%r14)
  10932e:	jne    109339 <fn_4+0xdb9>
  109330:	mov    %rsp,%rdi
  109333:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  109339:	add    $0x10,%rbx
  10933d:	mov    %rbx,%rcx
  109340:	mov    0x58(%rsp),%rbx
  109345:	jmp    1096d6 <fn_4+0x1156>
  10934a:	cmp    $0x7,%r13
  10934e:	jbe    1093a0 <fn_4+0xe20>
  109350:	mov    (%rdi),%rbp
  109353:	cmp    $0x8,%r13
  109357:	je     10948c <fn_4+0xf0c>
  10935d:	mov    -0x8(%rdi,%r13,1),%rax
  109362:	shl    $0x3,%r13d
  109366:	neg    %r13b
  109369:	mov    %r13d,%ecx
  10936c:	shr    %cl,%rax
  10936f:	mov    %rax,%r13
  109372:	jmp    10948f <fn_4+0xf0f>
  109377:	mov    -0x8(%rdi,%r13,1),%rax
  10937c:	mov    %r13d,%ecx
  10937f:	neg    %cl
  109381:	shl    $0x3,%cl
  109384:	shr    %cl,%rax
  109387:	mov    (%rdi),%rbp
  10938a:	xor    %ecx,%ecx
  10938c:	cmp    $0x18,%r13
  109390:	mov    0x8(%rdi),%r13
  109394:	cmove  %rcx,%r12
  109398:	or     %rax,%r12
  10939b:	jmp    10948f <fn_4+0xf0f>
  1093a0:	cmp    $0x3,%r13
  1093a4:	jbe    109468 <fn_4+0xee8>
  1093aa:	mov    -0x4(%rdi,%r13,1),%ebp
  1093af:	add    $0xfffffffffffffffc,%r13
  1093b3:	shl    $0x3,%r13d
  1093b7:	mov    %r13d,%ecx
  1093ba:	shl    %cl,%rbp
  1093bd:	mov    (%rdi),%eax
  1093bf:	jmp    109489 <fn_4+0xf09>
  1093c4:	movabs $0x6c61207365747962,%r14
  1093ce:	movabs $0x6e6f697461636f6c,%rbx
  1093d8:	movabs $0xd764656c69616620,%r13
  1093e2:	mov    $0xf,%eax
  1093e7:	mov    %r14,(%rsp)
  1093eb:	mov    %rbx,0x8(%rsp)
  1093f0:	mov    %r13,0x10(%rsp)
  1093f5:	mov    %eax,0x18(%rsp)
  1093f9:	mov    %rsp,%rdi
  1093fc:	xor    %esi,%esi
  1093fe:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  109403:	mov    %rax,%r12
  109406:	mov    0x48(%rsp),%r13
  10940b:	mov    0x58(%rsp),%rbx
  109410:	mov    0x50(%rsp),%r14
  109415:	xor    %edi,%edi
  109417:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  10941c:	cmpb   $0x0,(%rax)
  10941f:	jne    10b17e <fn_4+0x2bfe>
  109425:	test   %r13,%r13
  109428:	je     109441 <fn_4+0xec1>
  10942a:	lea    -0x10(%r13),%rax
  10942e:	mov    %rax,(%rsp)
  109432:	decq   -0x10(%r13)
  109436:	jne    109441 <fn_4+0xec1>
  109438:	mov    %rsp,%rdi
  10943b:	addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12relar_runtime4ListE9drop_slowBF_>
  109441:	mov    %r14,(%rsp)
  109445:	decq   (%r14)
  109448:	jne    109453 <fn_4+0xed3>
  10944a:	mov    %rsp,%rdi
  10944d:	addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12relar_runtime4ListE9drop_slowBF_>
  109453:	test   %rbx,%rbx
  109456:	sete   %al
  109459:	or     %bl,%al
  10945b:	test   $0x1,%al
  10945d:	je     109736 <fn_4+0x11b6>
  109463:	jmp    109752 <fn_4+0x11d2>
  109468:	cmp    $0x1,%r13
  10946c:	jbe    10a491 <fn_4+0x1f11>
  109472:	movzwl -0x2(%rdi,%r13,1),%ebp
  109478:	add    $0xfffffffffffffffe,%r13
  10947c:	shl    $0x3,%r13d
  109480:	mov    %r13d,%ecx
  109483:	shl    %cl,%rbp
  109486:	movzwl (%rdi),%eax
  109489:	or     %rax,%rbp
  10948c:	xor    %r13d,%r13d
  10948f:	mov    $0x28,%edi
  109494:	mov    $0x8,%esi
  109499:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10949e:	test   %rax,%rax
  1094a1:	je     10b056 <fn_4+0x2ad6>
  1094a7:	mov    %rax,%r14
  1094aa:	movq   $0x1,0x8(%rax)
  1094b2:	mov    %rbp,0x10(%rax)
  1094b6:	mov    %r13,0x18(%rax)
  1094ba:	mov    %r12,0x20(%rax)
  1094be:	movq   $0x2,(%rax)
  1094c5:	movq   $0x1,(%rsp)
  1094cd:	movq   $0x1,0x8(%rsp)
  1094d6:	mov    %rax,0x10(%rsp)
  1094db:	movq   $0x0,0x18(%rsp)
  1094e4:	movl   $0x8,0x20(%rsp)
  1094ec:	movb   $0x0,0x24(%rsp)
  1094f1:	movb   $0x8,0x39(%rsp)
  1094f6:	mov    $0x40,%edi
  1094fb:	mov    $0x8,%esi
  109500:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  109505:	test   %rax,%rax
  109508:	je     10b066 <fn_4+0x2ae6>
  10950e:	mov    %rax,%r12
  109511:	movdqu (%rsp),%xmm0
  109516:	movdqu 0x10(%rsp),%xmm1
  10951c:	movdqu 0x20(%rsp),%xmm2
  109522:	movdqu 0x30(%rsp),%xmm3
  109528:	movdqu %xmm3,0x30(%rax)
  10952d:	movdqu %xmm2,0x20(%rax)
  109532:	movdqu %xmm1,0x10(%rax)
  109537:	movdqu %xmm0,(%rax)
  10953b:	mov    %r14,(%rsp)
  10953f:	decq   (%r14)
  109542:	jne    10954d <fn_4+0xfcd>
  109544:	mov    %rsp,%rdi
  109547:	addr32 call 133ba0 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs1AOPbhp2p9e_11compact_str13CompactStringE9drop_slowCs3V9firECmdE_12relar_runtime>
  10954d:	mov    (%rbx),%rax
  109550:	mov    %rax,%rcx
  109553:	inc    %rcx
  109556:	mov    %rcx,(%rbx)
  109559:	mov    0x48(%rsp),%r13
  10955e:	je     10ae1e <fn_4+0x289e>
  109564:	cmpb   $0x8,0x39(%rbx)
  109568:	jne    10b07b <fn_4+0x2afb>
  10956e:	add    $0x2,%rax
  109572:	mov    %rax,(%rbx)
  109575:	je     10ae1e <fn_4+0x289e>
  10957b:	mov    %rbx,(%rsp)
  10957f:	cmpb   $0x8,0x39(%r12)
  109585:	jne    10b098 <fn_4+0x2b18>
  10958b:	mov    0x18(%r12),%rax
  109590:	test   %rax,%rax
  109593:	je     1095aa <fn_4+0x102a>
  109595:	decq   (%rax)
  109598:	jne    1095aa <fn_4+0x102a>
  10959a:	mov    %r12,%r14
  10959d:	add    $0x18,%r14
  1095a1:	mov    %r14,%rdi
  1095a4:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  1095aa:	mov    %rbx,0x18(%r12)
  1095af:	movb   $0x1,0x24(%r12)
  1095b5:	mov    (%r12),%rax
  1095b9:	mov    %rax,%rcx
  1095bc:	inc    %rcx
  1095bf:	mov    %rcx,(%r12)
  1095c3:	je     10ae1e <fn_4+0x289e>
  1095c9:	mov    %rax,(%r12)
  1095cd:	mov    %rbx,(%rsp)
  1095d1:	decq   (%rbx)
  1095d4:	jne    1095df <fn_4+0x105f>
  1095d6:	mov    %rsp,%rdi
  1095d9:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  1095df:	cmpb   $0x8,0x39(%r12)
  1095e5:	jne    10b0b5 <fn_4+0x2b35>
  1095eb:	incq   (%r12)
  1095ef:	je     10ae1e <fn_4+0x289e>
  1095f5:	mov    %r12,0x60(%rsp)
  1095fa:	xor    %edi,%edi
  1095fc:	call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  109601:	test   %rax,%rax
  109604:	je     10b4a1 <fn_4+0x2f21>
  10960a:	mov    %r12,(%rsp)
  10960e:	cmpq   $0x0,(%rax)
  109612:	jne    10b0d2 <fn_4+0x2b52>
  109618:	mov    0x8(%rax),%r14
  10961c:	mov    %r12,0x8(%rax)
  109620:	mov    %rsp,%rdi
  109623:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  109628:	movb   $0x1,(%rax)
  10962b:	mov    %r14,(%rsp)
  10962f:	test   %r14,%r14
  109632:	je     109642 <fn_4+0x10c2>
  109634:	decq   (%r14)
  109637:	jne    109642 <fn_4+0x10c2>
  109639:	mov    %rsp,%rdi
  10963c:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  109642:	mov    %r12,(%rsp)
  109646:	decq   (%r12)
  10964a:	jne    109655 <fn_4+0x10d5>
  10964c:	mov    %rsp,%rdi
  10964f:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  109655:	mov    %rbx,(%rsp)
  109659:	decq   (%rbx)
  10965c:	mov    0x40(%rsp),%r12
  109661:	jne    10966c <fn_4+0x10ec>
  109663:	mov    %rsp,%rdi
  109666:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10966c:	test   %r15,%r15
  10966f:	mov    0x58(%rsp),%rbx
  109674:	je     10968a <fn_4+0x110a>
  109676:	cmpb   $0x8,0x39(%r15)
  10967b:	jne    10b188 <fn_4+0x2c08>
  109681:	incq   (%r15)
  109684:	je     10ae1e <fn_4+0x289e>
  10968a:	mov    %r15,0x60(%rsp)
  10968f:	xor    %edi,%edi
  109691:	call   12e3a0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions6ACTIVE00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1e_6option6OptionQIB1T_INtNtB1e_4cell7RefCellIB1T_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  109696:	test   %rax,%rax
  109699:	je     10b4bf <fn_4+0x2f3f>
  10969f:	mov    %r15,(%rsp)
  1096a3:	cmpq   $0x0,(%rax)
  1096a7:	jne    10b0df <fn_4+0x2b5f>
  1096ad:	mov    0x8(%rax),%rcx
  1096b1:	mov    %r15,0x8(%rax)
  1096b5:	test   %rcx,%rcx
  1096b8:	je     1096cc <fn_4+0x114c>
  1096ba:	mov    %rcx,(%rsp)
  1096be:	decq   (%rcx)
  1096c1:	jne    1096cc <fn_4+0x114c>
  1096c3:	mov    %rsp,%rdi
  1096c6:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  1096cc:	test   %r15,%r15
  1096cf:	mov    0x50(%rsp),%rcx
  1096d4:	je     1096ed <fn_4+0x116d>
  1096d6:	lea    -0x10(%rcx),%rax
  1096da:	mov    %rax,(%rsp)
  1096de:	decq   -0x10(%rcx)
  1096e2:	jne    1096ed <fn_4+0x116d>
  1096e4:	mov    %rsp,%rdi
  1096e7:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  1096ed:	test   %r13,%r13
  1096f0:	je     109709 <fn_4+0x1189>
  1096f2:	lea    -0x10(%r13),%rax
  1096f6:	mov    %rax,(%rsp)
  1096fa:	decq   -0x10(%r13)
  1096fe:	jne    109709 <fn_4+0x1189>
  109700:	mov    %rsp,%rdi
  109703:	addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12relar_runtime4ListE9drop_slowBF_>
  109709:	test   %r12,%r12
  10970c:	je     109727 <fn_4+0x11a7>
  10970e:	lea    -0x10(%r12),%rax
  109713:	mov    %rax,(%rsp)
  109717:	decq   -0x10(%r12)
  10971c:	jne    109727 <fn_4+0x11a7>
  10971e:	mov    %rsp,%rdi
  109721:	addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12relar_runtime4ListE9drop_slowBF_>
  109727:	test   %rbx,%rbx
  10972a:	sete   %al
  10972d:	or     %bl,%al
  10972f:	xor    %r12d,%r12d
  109732:	test   $0x1,%al
  109734:	jne    109752 <fn_4+0x11d2>
  109736:	test   $0x1,%bl
  109739:	jne    109752 <fn_4+0x11d2>
  10973b:	lea    -0x10(%rbx),%rax
  10973f:	mov    %rax,(%rsp)
  109743:	decq   -0x10(%rbx)
  109747:	jne    109752 <fn_4+0x11d2>
  109749:	mov    %rsp,%rdi
  10974c:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109752:	mov    %r12,%rax
  109755:	add    $0x98,%rsp
  10975c:	pop    %rbx
  10975d:	pop    %r12
  10975f:	pop    %r13
  109761:	pop    %r14
  109763:	pop    %r15
  109765:	pop    %rbp
  109766:	ret
  109767:	jne    10a49f <fn_4+0x1f1f>
  10976d:	movzbl (%rdi),%r12d
  109771:	jmp    109074 <fn_4+0xaf4>
  109776:	movabs $0x1000000000000000,%rsi
  109780:	add    $0xfffffffffffffffc,%rsi
  109784:	and    %rax,%rsi
  109787:	lea    0x0(,%rax,8),%rdi
  10978f:	and    $0xffffffffffffffe0,%rdi
  109793:	pxor   %xmm0,%xmm0
  109797:	xor    %r8d,%r8d
  10979a:	movdqa -0xf8982(%rip),%xmm1        # 10e20 <anon.dd6a8a796c10bf5c67fa0e87de5edd21.24.llvm.9568189375700981541+0x20>
  1097a2:	movdqa -0xf80aa(%rip),%xmm3        # 11700 <anon.dd6a8a796c10bf5c67fa0e87de5edd21.24.llvm.9568189375700981541+0x900>
  1097aa:	pxor   %xmm2,%xmm2
  1097ae:	xchg   %ax,%ax
  1097b0:	movdqu (%rcx,%r8,1),%xmm4
  1097b6:	movdqu 0x10(%rcx,%r8,1),%xmm5
  1097bd:	movdqa %xmm4,%xmm6
  1097c1:	paddq  %xmm1,%xmm6
  1097c5:	movdqa %xmm5,%xmm7
  1097c9:	paddq  %xmm1,%xmm7
  1097cd:	psrlq  $0x21,%xmm6
  1097d2:	psrlq  $0x21,%xmm7
  1097d7:	pandn  %xmm3,%xmm4
  1097db:	por    %xmm4,%xmm2
  1097df:	por    %xmm6,%xmm2
  1097e3:	pandn  %xmm3,%xmm5
  1097e7:	por    %xmm5,%xmm0
  1097eb:	por    %xmm7,%xmm0
  1097ef:	add    $0x20,%r8
  1097f3:	cmp    %r8,%rdi
  1097f6:	jne    1097b0 <fn_4+0x1230>
  1097f8:	por    %xmm2,%xmm0
  1097fc:	pshufd $0xee,%xmm0,%xmm1
  109801:	por    %xmm0,%xmm1
  109805:	movq   %xmm1,%rdi
  10980a:	cmp    %rsi,%rax
  10980d:	je     109845 <fn_4+0x12c5>
  10980f:	mov    $0xffffffff,%r8d
  109815:	mov    %rdi,%r9
  109818:	nopl   0x0(%rax,%rax,1)
  109820:	mov    (%rcx,%rsi,8),%rdi
  109824:	lea    (%r8,%rdi,1),%r10
  109828:	inc    %r10
  10982b:	not    %edi
  10982d:	shr    $0x21,%r10
  109831:	or     %r9,%r10
  109834:	and    $0x1,%edi
  109837:	or     %r10,%rdi
  10983a:	inc    %rsi
  10983d:	mov    %rdi,%r9
  109840:	cmp    %rsi,%rax
  109843:	jne    109820 <fn_4+0x12a0>
  109845:	test   %rdi,%rdi
  109848:	je     10a352 <fn_4+0x1dd2>
  10984e:	add    $0xfffffffffffffffe,%rbp
  109852:	mov    $0x1,%r14d
  109858:	mov    %rsp,%rax
  10985b:	mov    %rax,0x88(%rsp)
  109863:	mov    $0x1,%r12d
  109869:	mov    $0x1,%r15d
  10986f:	mov    %rbp,0x80(%rsp)
  109877:	jmp    1098b5 <fn_4+0x1335>
  109879:	nopl   0x0(%rax)
  109880:	mov    0x18(%r14),%rax
  109884:	mov    0x58(%rsp),%rcx
  109889:	mov    %rcx,(%rax,%rbx,8)
  10988d:	inc    %rbx
  109890:	mov    %rbx,0x20(%r14)
  109894:	mov    %rcx,%rbx
  109897:	mov    0x78(%rsp),%r15
  10989c:	add    $0x6,%r15
  1098a0:	add    $0x3,%r12
  1098a4:	mov    %rbx,%r14
  1098a7:	cmp    0x90(%rsp),%r15
  1098af:	ja     108d2a <fn_4+0x7aa>
  1098b5:	mov    %r15,0x78(%rsp)
  1098ba:	lea    -0x1(%r12),%r15
  1098bf:	cmp    0x10(%r13),%r15
  1098c3:	jae    109920 <fn_4+0x13a0>
  1098c5:	mov    0x8(%r13),%rax
  1098c9:	mov    -0x8(%rax,%r12,8),%rbx
  1098ce:	test   $0x1,%bl
  1098d1:	jne    1098dd <fn_4+0x135d>
  1098d3:	incq   -0x10(%rbx)
  1098d7:	je     10ae1e <fn_4+0x289e>
  1098dd:	cmp    %rbp,%r15
  1098e0:	jge    10996a <fn_4+0x13ea>
  1098e6:	test   %rbx,%rbx
  1098e9:	je     10ae71 <fn_4+0x28f1>
  1098ef:	cmp    0x10(%r13),%r12
  1098f3:	jae    1099a0 <fn_4+0x1420>
  1098f9:	mov    0x8(%r13),%rax
  1098fd:	mov    (%rax,%r12,8),%rbp
  109901:	test   $0x1,%bpl
  109905:	jne    1099ea <fn_4+0x146a>
  10990b:	incq   -0x10(%rbp)
  10990f:	jne    1099e1 <fn_4+0x1461>
  109915:	jmp    10ae1e <fn_4+0x289e>
  10991a:	nopw   0x0(%rax,%rax,1)
  109920:	movabs $0x6f2074756f207865,%rax
  10992a:	mov    %rax,0x8(%rsp)
  10992f:	movabs $0xd765676e61722066,%rax
  109939:	mov    %rax,0x10(%rsp)
  10993e:	movabs $0x646e69207473696c,%rax
  109948:	mov    %rax,(%rsp)
  10994c:	movl   $0x6,0x18(%rsp)
  109954:	mov    %rsp,%rdi
  109957:	xor    %esi,%esi
  109959:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  10995e:	mov    %rax,%rbx
  109961:	cmp    %rbp,%r15
  109964:	jl     1098e6 <fn_4+0x1366>
  10996a:	test   %rbx,%rbx
  10996d:	je     10ae71 <fn_4+0x28f1>
  109973:	cmp    0x10(%r13),%r12
  109977:	jae    109a30 <fn_4+0x14b0>
  10997d:	mov    0x8(%r13),%rax
  109981:	mov    (%rax,%r12,8),%r15
  109985:	test   $0x1,%r15b
  109989:	jne    109a7a <fn_4+0x14fa>
  10998f:	incq   -0x10(%r15)
  109993:	jne    109a71 <fn_4+0x14f1>
  109999:	jmp    10ae1e <fn_4+0x289e>
  10999e:	xchg   %ax,%ax
  1099a0:	movabs $0x6f2074756f207865,%rax
  1099aa:	mov    %rax,0x8(%rsp)
  1099af:	movabs $0xd765676e61722066,%rax
  1099b9:	mov    %rax,0x10(%rsp)
  1099be:	movabs $0x646e69207473696c,%rax
  1099c8:	mov    %rax,(%rsp)
  1099cc:	movl   $0x6,0x18(%rsp)
  1099d4:	mov    %rsp,%rdi
  1099d7:	xor    %esi,%esi
  1099d9:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  1099de:	mov    %rax,%rbp
  1099e1:	test   %rbp,%rbp
  1099e4:	je     10ae63 <fn_4+0x28e3>
  1099ea:	test   $0x1,%bpl
  1099ee:	jne    109ac0 <fn_4+0x1540>
  1099f4:	mov    $0x5b,%esi
  1099f9:	mov    %rbp,%rdi
  1099fc:	mov    $0x2,%edx
  109a01:	call   110e30 <relar_int_binary>
  109a06:	mov    %rax,%r15
  109a09:	lea    -0x10(%rbp),%rax
  109a0d:	mov    %rax,(%rsp)
  109a11:	decq   -0x10(%rbp)
  109a15:	jne    109afb <fn_4+0x157b>
  109a1b:	mov    %rsp,%rdi
  109a1e:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109a24:	jmp    109afb <fn_4+0x157b>
  109a29:	nopl   0x0(%rax)
  109a30:	movabs $0x6f2074756f207865,%rax
  109a3a:	mov    %rax,0x8(%rsp)
  109a3f:	movabs $0xd765676e61722066,%rax
  109a49:	mov    %rax,0x10(%rsp)
  109a4e:	movabs $0x646e69207473696c,%rax
  109a58:	mov    %rax,(%rsp)
  109a5c:	movl   $0x6,0x18(%rsp)
  109a64:	mov    %rsp,%rdi
  109a67:	xor    %esi,%esi
  109a69:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  109a6e:	mov    %rax,%r15
  109a71:	test   %r15,%r15
  109a74:	je     10ae63 <fn_4+0x28e3>
  109a7a:	test   $0x1,%r15b
  109a7e:	jne    109b10 <fn_4+0x1590>
  109a84:	mov    $0x5b,%esi
  109a89:	mov    %r15,%rdi
  109a8c:	mov    $0x2,%edx
  109a91:	call   110e30 <relar_int_binary>
  109a96:	mov    %rax,%rbp
  109a99:	lea    -0x10(%r15),%rax
  109a9d:	mov    %rax,(%rsp)
  109aa1:	decq   -0x10(%r15)
  109aa5:	jne    109b4b <fn_4+0x15cb>
  109aab:	mov    %rsp,%rdi
  109aae:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109ab4:	jmp    109b4b <fn_4+0x15cb>
  109ab9:	nopl   0x0(%rax)
  109ac0:	mov    %rbp,%rax
  109ac3:	sar    $1,%rax
  109ac6:	imul   $0x2d,%rax,%rax
  109aca:	seto   %cl
  109acd:	not    %cl
  109acf:	mov    %rax,%rdx
  109ad2:	movabs $0xc000000000000000,%rsi
  109adc:	add    %rsi,%rdx
  109adf:	sets   %dl
  109ae2:	test   %dl,%cl
  109ae4:	jne    109b5c <fn_4+0x15dc>
  109ae6:	mov    $0x5b,%esi
  109aeb:	mov    %rbp,%rdi
  109aee:	mov    $0x2,%edx
  109af3:	call   110e30 <relar_int_binary>
  109af8:	mov    %rax,%r15
  109afb:	mov    %ebx,%r13d
  109afe:	and    $0x1,%r13d
  109b02:	test   %r13d,%r15d
  109b05:	jne    109b70 <fn_4+0x15f0>
  109b07:	jmp    109b91 <fn_4+0x1611>
  109b0c:	nopl   0x0(%rax)
  109b10:	mov    %r15,%rax
  109b13:	sar    $1,%rax
  109b16:	imul   $0x2d,%rax,%rax
  109b1a:	seto   %cl
  109b1d:	not    %cl
  109b1f:	mov    %rax,%rdx
  109b22:	movabs $0xc000000000000000,%rsi
  109b2c:	add    %rsi,%rdx
  109b2f:	sets   %dl
  109b32:	test   %dl,%cl
  109b34:	jne    109bb0 <fn_4+0x1630>
  109b36:	mov    $0x5b,%esi
  109b3b:	mov    %r15,%rdi
  109b3e:	mov    $0x2,%edx
  109b43:	call   110e30 <relar_int_binary>
  109b48:	mov    %rax,%rbp
  109b4b:	mov    %ebx,%r15d
  109b4e:	and    $0x1,%r15d
  109b52:	test   %r15d,%ebp
  109b55:	jne    109bc4 <fn_4+0x1644>
  109b57:	jmp    109be9 <fn_4+0x1669>
  109b5c:	lea    0x1(,%rax,2),%r15
  109b64:	mov    %ebx,%r13d
  109b67:	and    $0x1,%r13d
  109b6b:	test   %r13d,%r15d
  109b6e:	je     109b91 <fn_4+0x1611>
  109b70:	mov    %rbx,%rcx
  109b73:	sar    $1,%rcx
  109b76:	mov    %r15,%rax
  109b79:	sar    $1,%rax
  109b7c:	add    %rcx,%rax
  109b7f:	mov    %rax,%rcx
  109b82:	movabs $0xc000000000000000,%rdx
  109b8c:	add    %rdx,%rcx
  109b8f:	js     109c09 <fn_4+0x1689>
  109b91:	mov    %rbx,%rdi
  109b94:	mov    %r15,%rsi
  109b97:	xor    %edx,%edx
  109b99:	call   110e30 <relar_int_binary>
  109b9e:	mov    %rax,%rbp
  109ba1:	test   %r13,%r13
  109ba4:	mov    0x48(%rsp),%r13
  109ba9:	je     109c1b <fn_4+0x169b>
  109bab:	jmp    109c40 <fn_4+0x16c0>
  109bb0:	lea    0x1(,%rax,2),%rbp
  109bb8:	mov    %ebx,%r15d
  109bbb:	and    $0x1,%r15d
  109bbf:	test   %r15d,%ebp
  109bc2:	je     109be9 <fn_4+0x1669>
  109bc4:	mov    %rbx,%rcx
  109bc7:	sar    $1,%rcx
  109bca:	mov    %rbp,%rax
  109bcd:	sar    $1,%rax
  109bd0:	add    %rcx,%rax
  109bd3:	mov    %rax,%rcx
  109bd6:	movabs $0xc000000000000000,%rdx
  109be0:	add    %rdx,%rcx
  109be3:	js     109e4b <fn_4+0x18cb>
  109be9:	mov    %rbx,%rdi
  109bec:	mov    %rbp,%rsi
  109bef:	xor    %edx,%edx
  109bf1:	call   110e30 <relar_int_binary>
  109bf6:	mov    %rax,0x58(%rsp)
  109bfb:	test   %r15,%r15
  109bfe:	je     109e5d <fn_4+0x18dd>
  109c04:	jmp    109e80 <fn_4+0x1900>
  109c09:	lea    0x1(,%rax,2),%rbp
  109c11:	test   %r13,%r13
  109c14:	mov    0x48(%rsp),%r13
  109c19:	jne    109c40 <fn_4+0x16c0>
  109c1b:	lea    -0x10(%rbx),%rax
  109c1f:	mov    %rax,(%rsp)
  109c23:	decq   -0x10(%rbx)
  109c27:	jne    109c40 <fn_4+0x16c0>
  109c29:	mov    %rsp,%rdi
  109c2c:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109c32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  109c40:	test   %r15,%r15
  109c43:	sete   %al
  109c46:	or     %r15b,%al
  109c49:	test   $0x1,%al
  109c4b:	jne    109c70 <fn_4+0x16f0>
  109c4d:	lea    -0x10(%r15),%rax
  109c51:	mov    %rax,(%rsp)
  109c55:	decq   -0x10(%r15)
  109c59:	jne    109c70 <fn_4+0x16f0>
  109c5b:	mov    %rsp,%rdi
  109c5e:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109c64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  109c70:	lea    0x1(%r12),%rax
  109c75:	cmp    0x10(%r13),%rax
  109c79:	jae    109ca0 <fn_4+0x1720>
  109c7b:	mov    0x8(%r13),%rax
  109c7f:	mov    0x8(%rax,%r12,8),%r13
  109c84:	test   $0x1,%r13b
  109c88:	jne    109cea <fn_4+0x176a>
  109c8a:	incq   -0x10(%r13)
  109c8e:	jne    109ce1 <fn_4+0x1761>
  109c90:	jmp    10ae1e <fn_4+0x289e>
  109c95:	data16 cs nopw 0x0(%rax,%rax,1)
  109ca0:	movabs $0x6f2074756f207865,%rax
  109caa:	mov    %rax,0x8(%rsp)
  109caf:	movabs $0xd765676e61722066,%rax
  109cb9:	mov    %rax,0x10(%rsp)
  109cbe:	movabs $0x646e69207473696c,%rax
  109cc8:	mov    %rax,(%rsp)
  109ccc:	movl   $0x6,0x18(%rsp)
  109cd4:	mov    %rsp,%rdi
  109cd7:	xor    %esi,%esi
  109cd9:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  109cde:	mov    %rax,%r13
  109ce1:	test   %r13,%r13
  109ce4:	je     10afb7 <fn_4+0x2a37>
  109cea:	test   $0x1,%r13b
  109cee:	jne    109d30 <fn_4+0x17b0>
  109cf0:	mov    $0x5b,%esi
  109cf5:	mov    %r13,%rdi
  109cf8:	mov    $0x2,%edx
  109cfd:	call   110e30 <relar_int_binary>
  109d02:	mov    %rax,%r15
  109d05:	lea    -0x10(%r13),%rax
  109d09:	mov    %rax,(%rsp)
  109d0d:	decq   -0x10(%r13)
  109d11:	jne    109d20 <fn_4+0x17a0>
  109d13:	mov    %rsp,%rdi
  109d16:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109d1c:	nopl   0x0(%rax)
  109d20:	test   $0x1,%r15b
  109d24:	jne    109d81 <fn_4+0x1801>
  109d26:	jmp    109da5 <fn_4+0x1825>
  109d28:	nopl   0x0(%rax,%rax,1)
  109d30:	mov    %r13,%rax
  109d33:	sar    $1,%rax
  109d36:	imul   $0x2d,%rax,%rax
  109d3a:	seto   %cl
  109d3d:	not    %cl
  109d3f:	mov    %rax,%rdx
  109d42:	movabs $0xc000000000000000,%rsi
  109d4c:	add    %rsi,%rdx
  109d4f:	sets   %dl
  109d52:	test   %dl,%cl
  109d54:	jne    109d73 <fn_4+0x17f3>
  109d56:	mov    $0x5b,%esi
  109d5b:	mov    %r13,%rdi
  109d5e:	mov    $0x2,%edx
  109d63:	call   110e30 <relar_int_binary>
  109d68:	mov    %rax,%r15
  109d6b:	test   $0x1,%r15b
  109d6f:	jne    109d81 <fn_4+0x1801>
  109d71:	jmp    109da5 <fn_4+0x1825>
  109d73:	lea    0x1(,%rax,2),%r15
  109d7b:	test   $0x1,%r15b
  109d7f:	je     109da5 <fn_4+0x1825>
  109d81:	mov    %r15,%rax
  109d84:	sar    $1,%rax
  109d87:	imul   $0x2d,%rax,%rax
  109d8b:	seto   %cl
  109d8e:	mov    %rax,%rdx
  109d91:	movabs $0xc000000000000000,%rsi
  109d9b:	add    %rsi,%rdx
  109d9e:	setns  %dl
  109da1:	or     %cl,%dl
  109da3:	je     109dee <fn_4+0x186e>
  109da5:	mov    $0x5b,%esi
  109daa:	mov    %r15,%rdi
  109dad:	mov    $0x2,%edx
  109db2:	call   110e30 <relar_int_binary>
  109db7:	mov    %rax,%r13
  109dba:	test   %r15,%r15
  109dbd:	sete   %al
  109dc0:	or     %r15b,%al
  109dc3:	test   $0x1,%al
  109dc5:	jne    109de0 <fn_4+0x1860>
  109dc7:	lea    -0x10(%r15),%rax
  109dcb:	mov    %rax,(%rsp)
  109dcf:	decq   -0x10(%r15)
  109dd3:	jne    109de0 <fn_4+0x1860>
  109dd5:	mov    %rsp,%rdi
  109dd8:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109dde:	xchg   %ax,%ax
  109de0:	mov    %ebp,%r15d
  109de3:	and    $0x1,%r15d
  109de7:	test   %r15d,%r13d
  109dea:	jne    109e02 <fn_4+0x1882>
  109dec:	jmp    109e27 <fn_4+0x18a7>
  109dee:	lea    0x1(,%rax,2),%r13
  109df6:	mov    %ebp,%r15d
  109df9:	and    $0x1,%r15d
  109dfd:	test   %r15d,%r13d
  109e00:	je     109e27 <fn_4+0x18a7>
  109e02:	mov    %rbp,%rcx
  109e05:	sar    $1,%rcx
  109e08:	mov    %r13,%rax
  109e0b:	sar    $1,%rax
  109e0e:	add    %rcx,%rax
  109e11:	mov    %rax,%rcx
  109e14:	movabs $0xc000000000000000,%rdx
  109e1e:	add    %rdx,%rcx
  109e21:	js     109f98 <fn_4+0x1a18>
  109e27:	mov    %rbp,%rdi
  109e2a:	mov    %r13,%rsi
  109e2d:	xor    %edx,%edx
  109e2f:	call   110e30 <relar_int_binary>
  109e34:	mov    %rax,%rbx
  109e37:	test   %rbp,%rbp
  109e3a:	sete   %al
  109e3d:	or     %r15b,%al
  109e40:	je     109fab <fn_4+0x1a2b>
  109e46:	jmp    109fd0 <fn_4+0x1a50>
  109e4b:	lea    0x1(,%rax,2),%rax
  109e53:	mov    %rax,0x58(%rsp)
  109e58:	test   %r15,%r15
  109e5b:	jne    109e80 <fn_4+0x1900>
  109e5d:	lea    -0x10(%rbx),%rax
  109e61:	mov    %rax,(%rsp)
  109e65:	decq   -0x10(%rbx)
  109e69:	jne    109e80 <fn_4+0x1900>
  109e6b:	mov    %rsp,%rdi
  109e6e:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109e74:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  109e80:	test   %rbp,%rbp
  109e83:	sete   %al
  109e86:	or     %bpl,%al
  109e89:	test   $0x1,%al
  109e8b:	mov    0x58(%rsp),%rbx
  109e90:	jne    109eb0 <fn_4+0x1930>
  109e92:	lea    -0x10(%rbp),%rax
  109e96:	mov    %rax,(%rsp)
  109e9a:	decq   -0x10(%rbp)
  109e9e:	jne    109eb0 <fn_4+0x1930>
  109ea0:	mov    %rsp,%rdi
  109ea3:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109ea9:	nopl   0x0(%rax)
  109eb0:	test   %r14,%r14
  109eb3:	sete   %al
  109eb6:	or     %r14b,%al
  109eb9:	test   $0x1,%al
  109ebb:	mov    0x80(%rsp),%rbp
  109ec3:	jne    109ee0 <fn_4+0x1960>
  109ec5:	lea    -0x10(%r14),%rax
  109ec9:	mov    %rax,(%rsp)
  109ecd:	decq   -0x10(%r14)
  109ed1:	jne    109ee0 <fn_4+0x1960>
  109ed3:	mov    %rsp,%rdi
  109ed6:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109edc:	nopl   0x0(%rax)
  109ee0:	test   $0x1,%bl
  109ee3:	jne    109f00 <fn_4+0x1980>
  109ee5:	mov    $0x1ff,%esi
  109eea:	mov    %rbx,%rdi
  109eed:	call   1148a0 <relar_int_compare>
  109ef2:	test   %eax,%eax
  109ef4:	mov    0x50(%rsp),%r14
  109ef9:	jle    109f12 <fn_4+0x1992>
  109efb:	jmp    10a4aa <fn_4+0x1f2a>
  109f00:	cmp    $0x200,%rbx
  109f07:	mov    0x50(%rsp),%r14
  109f0c:	jge    10a4aa <fn_4+0x1f2a>
  109f12:	mov    0x10(%r14),%r15
  109f16:	mov    0x20(%r14),%rsi
  109f1a:	cmp    %rsi,%r15
  109f1d:	jne    10a216 <fn_4+0x1c96>
  109f23:	lea    (%rsi,%rsi,1),%r15
  109f27:	cmp    $0x5,%r15
  109f2b:	mov    $0x4,%eax
  109f30:	cmovb  %rax,%r15
  109f34:	lea    0x0(,%r15,8),%r14
  109f3c:	movabs $0x1000000000000000,%rax
  109f46:	dec    %rax
  109f49:	cmp    %rax,%rsi
  109f4c:	seta   %al
  109f4f:	movabs $0x7ffffffffffffff8,%rcx
  109f59:	cmp    %rcx,%r14
  109f5c:	seta   %cl
  109f5f:	or     %al,%cl
  109f61:	jne    10a2fc <fn_4+0x1d7c>
  109f67:	test   %rsi,%rsi
  109f6a:	je     10a1f3 <fn_4+0x1c73>
  109f70:	mov    0x50(%rsp),%rax
  109f75:	mov    0x18(%rax),%rdi
  109f79:	shl    $0x3,%rsi
  109f7d:	mov    $0x8,%edx
  109f82:	mov    %r14,%rcx
  109f85:	call   77540 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_realloc>
  109f8a:	test   %rax,%rax
  109f8d:	jne    10a209 <fn_4+0x1c89>
  109f93:	jmp    10b518 <fn_4+0x2f98>
  109f98:	lea    0x1(,%rax,2),%rbx
  109fa0:	test   %rbp,%rbp
  109fa3:	sete   %al
  109fa6:	or     %r15b,%al
  109fa9:	jne    109fd0 <fn_4+0x1a50>
  109fab:	lea    -0x10(%rbp),%rax
  109faf:	mov    %rax,(%rsp)
  109fb3:	decq   -0x10(%rbp)
  109fb7:	jne    109fd0 <fn_4+0x1a50>
  109fb9:	mov    %rsp,%rdi
  109fbc:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109fc2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  109fd0:	test   %r13,%r13
  109fd3:	sete   %al
  109fd6:	or     %r13b,%al
  109fd9:	test   $0x1,%al
  109fdb:	jne    10a000 <fn_4+0x1a80>
  109fdd:	lea    -0x10(%r13),%rax
  109fe1:	mov    %rax,(%rsp)
  109fe5:	decq   -0x10(%r13)
  109fe9:	jne    10a000 <fn_4+0x1a80>
  109feb:	mov    %rsp,%rdi
  109fee:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  109ff4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  10a000:	test   %r14,%r14
  10a003:	sete   %al
  10a006:	or     %r14b,%al
  10a009:	test   $0x1,%al
  10a00b:	mov    0x48(%rsp),%r13
  10a010:	jne    10a030 <fn_4+0x1ab0>
  10a012:	lea    -0x10(%r14),%rax
  10a016:	mov    %rax,(%rsp)
  10a01a:	decq   -0x10(%r14)
  10a01e:	jne    10a030 <fn_4+0x1ab0>
  10a020:	mov    %rsp,%rdi
  10a023:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  10a029:	nopl   0x0(%rax)
  10a030:	test   $0x1,%bl
  10a033:	jne    10a050 <fn_4+0x1ad0>
  10a035:	mov    $0x1ffff,%esi
  10a03a:	mov    %rbx,%rdi
  10a03d:	call   1148a0 <relar_int_compare>
  10a042:	test   %eax,%eax
  10a044:	mov    0x50(%rsp),%r14
  10a049:	jle    10a062 <fn_4+0x1ae2>
  10a04b:	jmp    10a5e1 <fn_4+0x2061>
  10a050:	cmp    $0x20000,%rbx
  10a057:	mov    0x50(%rsp),%r14
  10a05c:	jge    10a5e1 <fn_4+0x2061>
  10a062:	incq   (%r14)
  10a065:	je     10ae1e <fn_4+0x289e>
  10a06b:	test   %rbx,%rbx
  10a06e:	sete   %r15b
  10a072:	or     %bl,%r15b
  10a075:	test   $0x1,%r15b
  10a079:	je     10a0b0 <fn_4+0x1b30>
  10a07b:	test   $0x1,%bl
  10a07e:	je     10a0ba <fn_4+0x1b3a>
  10a080:	xor    %edi,%edi
  10a082:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  10a087:	cmpb   $0x0,(%rax)
  10a08a:	jne    10b12a <fn_4+0x2baa>
  10a090:	mov    %rbx,%r13
  10a093:	sar    $0x8,%r13
  10a097:	or     $0x1,%r13
  10a09b:	mov    %ebx,%ebp
  10a09d:	and    $0x1ff,%ebp
  10a0a3:	mov    0x78(%rsp),%r15
  10a0a8:	jmp    10a140 <fn_4+0x1bc0>
  10a0ad:	nopl   (%rax)
  10a0b0:	incq   -0x10(%rbx)
  10a0b4:	je     10ae1e <fn_4+0x289e>
  10a0ba:	mov    $0x201,%esi
  10a0bf:	mov    %rbx,%rdi
  10a0c2:	mov    $0x3,%edx
  10a0c7:	call   110e30 <relar_int_binary>
  10a0cc:	mov    %rax,%r13
  10a0cf:	xor    %edi,%edi
  10a0d1:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  10a0d6:	cmpb   $0x0,(%rax)
  10a0d9:	jne    10b11b <fn_4+0x2b9b>
  10a0df:	mov    %rax,%r14
  10a0e2:	mov    $0x201,%esi
  10a0e7:	mov    %rbx,%rdi
  10a0ea:	mov    $0x4,%edx
  10a0ef:	call   110e30 <relar_int_binary>
  10a0f4:	cmpb   $0x0,(%r14)
  10a0f8:	jne    10b131 <fn_4+0x2bb1>
  10a0fe:	mov    %rax,%rbp
  10a101:	test   $0x1,%r15b
  10a105:	je     10a113 <fn_4+0x1b93>
  10a107:	mov    0x50(%rsp),%r14
  10a10c:	mov    0x78(%rsp),%r15
  10a111:	jmp    10a140 <fn_4+0x1bc0>
  10a113:	lea    -0x10(%rbx),%rax
  10a117:	mov    %rax,(%rsp)
  10a11b:	decq   -0x10(%rbx)
  10a11f:	mov    0x50(%rsp),%r14
  10a124:	mov    0x78(%rsp),%r15
  10a129:	jne    10a140 <fn_4+0x1bc0>
  10a12b:	mov    %rsp,%rdi
  10a12e:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  10a134:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  10a140:	mov    0x10(%r14),%rsi
  10a144:	mov    0x20(%r14),%rcx
  10a148:	mov    %rsi,%rax
  10a14b:	sub    %rcx,%rax
  10a14e:	cmp    $0x2,%rax
  10a152:	jae    10a1e0 <fn_4+0x1c60>
  10a158:	cmp    $0xfffffffffffffffd,%rcx
  10a15c:	ja     10a335 <fn_4+0x1db5>
  10a162:	add    $0x2,%rcx
  10a166:	lea    (%rsi,%rsi,1),%rax
  10a16a:	cmp    %rax,%rcx
  10a16d:	cmovbe %rax,%rcx
  10a171:	cmp    $0x5,%rcx
  10a175:	mov    $0x4,%r15d
  10a17b:	cmovae %rcx,%r15
  10a17f:	lea    0x0(,%r15,8),%r14
  10a187:	shr    $0x3d,%rcx
  10a18b:	setne  %al
  10a18e:	movabs $0x7ffffffffffffff8,%rcx
  10a198:	cmp    %rcx,%r14
  10a19b:	seta   %cl
  10a19e:	or     %al,%cl
  10a1a0:	jne    10a327 <fn_4+0x1da7>
  10a1a6:	test   %rsi,%rsi
  10a1a9:	je     10a24a <fn_4+0x1cca>
  10a1af:	mov    0x50(%rsp),%rax
  10a1b4:	mov    0x18(%rax),%rdi
  10a1b8:	shl    $0x3,%rsi
  10a1bc:	mov    $0x8,%edx
  10a1c1:	mov    %r14,%rcx
  10a1c4:	call   77540 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_realloc>
  10a1c9:	test   %rax,%rax
  10a1cc:	jne    10a260 <fn_4+0x1ce0>
  10a1d2:	jmp    10b52a <fn_4+0x2faa>
  10a1d7:	nopw   0x0(%rax,%rax,1)
  10a1e0:	mov    0x18(%r14),%rax
  10a1e4:	test   $0x1,%r13b
  10a1e8:	je     10a27c <fn_4+0x1cfc>
  10a1ee:	jmp    10a286 <fn_4+0x1d06>
  10a1f3:	mov    $0x8,%esi
  10a1f8:	mov    %r14,%rdi
  10a1fb:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10a200:	test   %rax,%rax
  10a203:	je     10b518 <fn_4+0x2f98>
  10a209:	mov    0x50(%rsp),%r14
  10a20e:	mov    %rax,0x18(%r14)
  10a212:	mov    %r15,0x10(%r14)
  10a216:	test   $0x1,%bl
  10a219:	jne    10a22d <fn_4+0x1cad>
  10a21b:	incq   -0x10(%rbx)
  10a21f:	je     10ae1e <fn_4+0x289e>
  10a225:	mov    0x40(%rsp),%rax
  10a22a:	mov    (%rax),%r15
  10a22d:	mov    0x20(%r14),%rbx
  10a231:	cmp    %r15,%rbx
  10a234:	jne    109880 <fn_4+0x1300>
  10a23a:	mov    0x40(%rsp),%rdi
  10a23f:	addr32 call 12ffb0 <_RNvMs4_NtCscJq9HK9IcCJ_5alloc7raw_vecINtB5_6RawVecINtNtCs6SLOTazmNXq_4core6option6OptionINtNtNtCs3V9firECmdE_12relar_runtime7objects8mappings5EntryINtNtB7_2rc2RcINtNtB7_3vec3VechEEuEEE8grow_oneB1v_>
  10a245:	jmp    109880 <fn_4+0x1300>
  10a24a:	mov    $0x8,%esi
  10a24f:	mov    %r14,%rdi
  10a252:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10a257:	test   %rax,%rax
  10a25a:	je     10b52a <fn_4+0x2faa>
  10a260:	mov    0x50(%rsp),%r14
  10a265:	mov    %rax,0x18(%r14)
  10a269:	mov    %r15,0x10(%r14)
  10a26d:	mov    0x20(%r14),%rcx
  10a271:	mov    0x78(%rsp),%r15
  10a276:	test   $0x1,%r13b
  10a27a:	jne    10a286 <fn_4+0x1d06>
  10a27c:	incq   -0x10(%r13)
  10a280:	je     10ae1e <fn_4+0x289e>
  10a286:	mov    %r13,(%rax,%rcx,8)
  10a28a:	test   $0x1,%bpl
  10a28e:	jne    10a29a <fn_4+0x1d1a>
  10a290:	incq   -0x10(%rbp)
  10a294:	je     10ae1e <fn_4+0x289e>
  10a29a:	mov    %rbp,0x8(%rax,%rcx,8)
  10a29f:	add    $0x2,%rcx
  10a2a3:	mov    %rcx,0x20(%r14)
  10a2a7:	test   %r13,%r13
  10a2aa:	sete   %al
  10a2ad:	or     %r13b,%al
  10a2b0:	test   $0x1,%al
  10a2b2:	mov    0x80(%rsp),%rbp
  10a2ba:	jne    10a2e0 <fn_4+0x1d60>
  10a2bc:	lea    -0x10(%r13),%rax
  10a2c0:	mov    %rax,(%rsp)
  10a2c4:	decq   -0x10(%r13)
  10a2c8:	jne    10a2e0 <fn_4+0x1d60>
  10a2ca:	mov    %rsp,%rdi
  10a2cd:	addr32 call 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  10a2d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10a2e0:	mov    %r14,(%rsp)
  10a2e4:	decq   (%r14)
  10a2e7:	jne    10a2f2 <fn_4+0x1d72>
  10a2e9:	mov    %rsp,%rdi
  10a2ec:	addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12relar_runtime4ListE9drop_slowBF_>
  10a2f2:	mov    0x48(%rsp),%r13
  10a2f7:	jmp    10989c <fn_4+0x131c>
  10a2fc:	xor    %r14d,%r14d
  10a2ff:	mov    0x88(%rsp),%rax
  10a307:	mov    %r14,(%rax)
  10a30a:	lea    -0xdf7a9(%rip),%rdi        # 2ab68 <anon.07dd289d6752232cc34d2640517a38ff.14.llvm.14548151582184166452>
  10a311:	lea    -0xdf7a5(%rip),%rdx        # 2ab73 <anon.07dd289d6752232cc34d2640517a38ff.15.llvm.14548151582184166452>
  10a318:	mov    $0xb,%esi
  10a31d:	mov    $0x16,%ecx
  10a322:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10a327:	xor    %r14d,%r14d
  10a32a:	mov    0x88(%rsp),%rax
  10a332:	mov    %r14,(%rax)
  10a335:	lea    -0xdf7d4(%rip),%rdi        # 2ab68 <anon.07dd289d6752232cc34d2640517a38ff.14.llvm.14548151582184166452>
  10a33c:	lea    -0xdf7d0(%rip),%rdx        # 2ab73 <anon.07dd289d6752232cc34d2640517a38ff.15.llvm.14548151582184166452>
  10a343:	mov    $0xb,%esi
  10a348:	mov    $0x16,%ecx
  10a34d:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10a352:	add    %rdx,%rdx
  10a355:	cmp    $0x7ffe,%rdx
  10a35c:	mov    $0x7ffe,%r12d
  10a362:	cmovb  %rdx,%r12
  10a366:	cmpq   $0x0,0x20(%r14)
  10a36b:	jne    10a449 <fn_4+0x1ec9>
  10a371:	add    $0x2,%r12
  10a375:	cmp    %r12,0x10(%r14)
  10a379:	jae    10a449 <fn_4+0x1ec9>
  10a37f:	mov    %rbp,0x80(%rsp)
  10a387:	data16 data16 data16 data16 mov %fs:0x0,%rax
  10a394:	lea    -0xf0(%rax),%rbp
  10a39b:	movzbl -0xb8(%rax),%eax
  10a3a2:	mov    $0x8,%r15d
  10a3a8:	test   %eax,%eax
  10a3aa:	jne    10b1da <fn_4+0x2c5a>
  10a3b0:	cmpq   $0x0,0x0(%rbp)
  10a3b5:	je     10b207 <fn_4+0x2c87>
  10a3bb:	xor    %ebx,%ebx
  10a3bd:	xor    %r13d,%r13d
  10a3c0:	mov    $0x8,%ecx
  10a3c5:	mov    $0x8,%r8d
  10a3cb:	mov    0x40(%rsp),%rdi
  10a3d0:	xor    %esi,%esi
  10a3d2:	mov    %r12,%rdx
  10a3d5:	call   12fe60 <_RNvMs2_NtCscJq9HK9IcCJ_5alloc7raw_vecNtB5_11RawVecInner17try_reserve_exactCs3V9firECmdE_12relar_runtime>
  10a3da:	mov    %r13,(%rsp)
  10a3de:	mov    %r15,0x8(%rsp)
  10a3e3:	mov    %rbx,0x10(%rsp)
  10a3e8:	test   %rbx,%rbx
  10a3eb:	je     10a428 <fn_4+0x1ea8>
  10a3ed:	lea    0x8(%r15),%r12
  10a3f1:	lea    0x60(%rsp),%r14
  10a3f6:	lea    0x2a473(%rip),%rbp        # 134870 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCselzjCC5m5fm_10num_bigint6bigint6BigIntE9drop_slowCs3V9firECmdE_12relar_runtime>
  10a3fd:	jmp    10a409 <fn_4+0x1e89>
  10a3ff:	nop
  10a400:	add    $0x8,%r12
  10a404:	dec    %rbx
  10a407:	je     10a428 <fn_4+0x1ea8>
  10a409:	mov    -0x8(%r12),%rax
  10a40e:	test   $0x1,%al
  10a410:	jne    10a400 <fn_4+0x1e80>
  10a412:	lea    -0x10(%rax),%rcx
  10a416:	mov    %rcx,0x60(%rsp)
  10a41b:	decq   -0x10(%rax)
  10a41f:	jne    10a400 <fn_4+0x1e80>
  10a421:	mov    %r14,%rdi
  10a424:	call   *%rbp
  10a426:	jmp    10a400 <fn_4+0x1e80>
  10a428:	test   %r13,%r13
  10a42b:	mov    0x80(%rsp),%rbp
  10a433:	je     10a449 <fn_4+0x1ec9>
  10a435:	shl    $0x3,%r13
  10a439:	mov    $0x8,%edx
  10a43e:	mov    %r15,%rdi
  10a441:	mov    %r13,%rsi
  10a444:	call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  10a449:	add    $0xfffffffffffffffe,%rbp
  10a44d:	mov    $0x1,%ebx
  10a452:	mov    %rsp,%rax
  10a455:	mov    %rax,0x78(%rsp)
  10a45a:	mov    $0x1,%r15d
  10a460:	mov    $0x1,%r14d
  10a466:	mov    0x48(%rsp),%r13
  10a46b:	mov    %rbp,0x80(%rsp)
  10a473:	jmp    10a74f <fn_4+0x21cf>
  10a478:	xor    %r12d,%r12d
  10a47b:	xor    %r13d,%r13d
  10a47e:	jmp    10884e <fn_4+0x2ce>
  10a483:	jne    10aba0 <fn_4+0x2620>
  10a489:	movzbl (%rax),%ebp
  10a48c:	jmp    1089d5 <fn_4+0x455>
  10a491:	jne    10abaa <fn_4+0x262a>
  10a497:	movzbl (%rdi),%ebp
  10a49a:	jmp    10948c <fn_4+0xf0c>
  10a49f:	xor    %r15d,%r15d
  10a4a2:	xor    %r12d,%r12d
  10a4a5:	jmp    109077 <fn_4+0xaf7>
  10a4aa:	mov    $0x28,%edi
  10a4af:	mov    $0x8,%esi
  10a4b4:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10a4b9:	test   %rax,%rax
  10a4bc:	je     10b311 <fn_4+0x2d91>
  10a4c2:	movq   $0x1,(%rax)
  10a4c9:	movq   $0x1,0x8(%rax)
  10a4d1:	pxor   %xmm0,%xmm0
  10a4d5:	movdqu %xmm0,0x10(%rax)
  10a4da:	movabs $0xc000000000000000,%rcx
  10a4e4:	mov    %rcx,0x20(%rax)
  10a4e8:	movq   $0x1,(%rsp)
  10a4f0:	movq   $0x1,0x8(%rsp)
  10a4f9:	mov    %rax,0x10(%rsp)
  10a4fe:	movq   $0x0,0x18(%rsp)
  10a507:	movl   $0x8,0x20(%rsp)
  10a50f:	movb   $0x0,0x24(%rsp)
  10a514:	movb   $0x8,0x39(%rsp)
  10a519:	mov    $0x40,%edi
  10a51e:	mov    $0x8,%esi
  10a523:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10a528:	test   %rax,%rax
  10a52b:	je     10b321 <fn_4+0x2da1>
  10a531:	mov    %rax,%r12
  10a534:	movdqu (%rsp),%xmm0
  10a539:	movdqu 0x10(%rsp),%xmm1
  10a53f:	movdqu 0x20(%rsp),%xmm2
  10a545:	movdqu 0x30(%rsp),%xmm3
  10a54b:	movdqu %xmm3,0x30(%rax)
  10a550:	movdqu %xmm2,0x20(%rax)
  10a555:	movdqu %xmm1,0x10(%rax)
  10a55a:	movdqu %xmm0,(%rax)
  10a55e:	cmpb   $0x8,0x39(%rax)
  10a562:	jne    10b346 <fn_4+0x2dc6>
  10a568:	incq   (%r12)
  10a56c:	je     10ae1e <fn_4+0x289e>
  10a572:	mov    %r12,0x60(%rsp)
  10a577:	xor    %edi,%edi
  10a579:	call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  10a57e:	test   %rax,%rax
  10a581:	je     10b574 <fn_4+0x2ff4>
  10a587:	mov    %r12,(%rsp)
  10a58b:	cmpq   $0x0,(%rax)
  10a58f:	jne    10b395 <fn_4+0x2e15>
  10a595:	mov    0x8(%rax),%rbx
  10a599:	mov    %r12,0x8(%rax)
  10a59d:	mov    %rsp,%rdi
  10a5a0:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  10a5a5:	movb   $0x1,(%rax)
  10a5a8:	mov    %rbx,(%rsp)
  10a5ac:	test   %rbx,%rbx
  10a5af:	je     10a5bf <fn_4+0x203f>
  10a5b1:	decq   (%rbx)
  10a5b4:	jne    10a5bf <fn_4+0x203f>
  10a5b6:	mov    %rsp,%rdi
  10a5b9:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10a5bf:	mov    %r12,(%rsp)
  10a5c3:	decq   (%r12)
  10a5c7:	jne    10a5d2 <fn_4+0x2052>
  10a5c9:	mov    %rsp,%rdi
  10a5cc:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10a5d2:	mov    0x40(%rsp),%r12
  10a5d7:	mov    0x58(%rsp),%rbx
  10a5dc:	jmp    1091b6 <fn_4+0xc36>
  10a5e1:	mov    $0x28,%edi
  10a5e6:	mov    $0x8,%esi
  10a5eb:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10a5f0:	test   %rax,%rax
  10a5f3:	je     10b336 <fn_4+0x2db6>
  10a5f9:	movq   $0x1,(%rax)
  10a600:	movq   $0x1,0x8(%rax)
  10a608:	pxor   %xmm0,%xmm0
  10a60c:	movdqu %xmm0,0x10(%rax)
  10a611:	movabs $0xc000000000000000,%rcx
  10a61b:	mov    %rcx,0x20(%rax)
  10a61f:	movq   $0x1,(%rsp)
  10a627:	movq   $0x1,0x8(%rsp)
  10a630:	mov    %rax,0x10(%rsp)
  10a635:	movq   $0x0,0x18(%rsp)
  10a63e:	movl   $0x8,0x20(%rsp)
  10a646:	movb   $0x0,0x24(%rsp)
  10a64b:	movb   $0x8,0x39(%rsp)
  10a650:	mov    $0x40,%edi
  10a655:	mov    $0x8,%esi
  10a65a:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10a65f:	test   %rax,%rax
  10a662:	je     10b363 <fn_4+0x2de3>
  10a668:	mov    %rax,%r12
  10a66b:	movdqu (%rsp),%xmm0
  10a670:	movdqu 0x10(%rsp),%xmm1
  10a676:	movdqu 0x20(%rsp),%xmm2
  10a67c:	movdqu 0x30(%rsp),%xmm3
  10a682:	movdqu %xmm3,0x30(%rax)
  10a687:	movdqu %xmm2,0x20(%rax)
  10a68c:	movdqu %xmm1,0x10(%rax)
  10a691:	movdqu %xmm0,(%rax)
  10a695:	cmpb   $0x8,0x39(%rax)
  10a699:	jne    10b378 <fn_4+0x2df8>
  10a69f:	incq   (%r12)
  10a6a3:	je     10ae1e <fn_4+0x289e>
  10a6a9:	mov    %r12,0x60(%rsp)
  10a6ae:	xor    %edi,%edi
  10a6b0:	call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  10a6b5:	test   %rax,%rax
  10a6b8:	je     10b592 <fn_4+0x3012>
  10a6be:	mov    %r12,(%rsp)
  10a6c2:	cmpq   $0x0,(%rax)
  10a6c6:	jne    10b3a2 <fn_4+0x2e22>
  10a6cc:	mov    %rbx,%r14
  10a6cf:	mov    0x8(%rax),%rbx
  10a6d3:	mov    %r12,0x8(%rax)
  10a6d7:	mov    %rsp,%rdi
  10a6da:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  10a6df:	movb   $0x1,(%rax)
  10a6e2:	mov    %rbx,(%rsp)
  10a6e6:	test   %rbx,%rbx
  10a6e9:	je     10a6f9 <fn_4+0x2179>
  10a6eb:	decq   (%rbx)
  10a6ee:	jne    10a6f9 <fn_4+0x2179>
  10a6f0:	mov    %rsp,%rdi
  10a6f3:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10a6f9:	mov    %r12,(%rsp)
  10a6fd:	decq   (%r12)
  10a701:	jne    10ae11 <fn_4+0x2891>
  10a707:	mov    %rsp,%rdi
  10a70a:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10a710:	jmp    10ae11 <fn_4+0x2891>
  10a715:	mov    %r12,%rbx
  10a718:	mov    0x80(%rsp),%rbp
  10a720:	mov    0x50(%rsp),%rcx
  10a725:	mov    0x18(%rcx),%rax
  10a729:	mov    %rbx,(%rax,%r13,8)
  10a72d:	inc    %r13
  10a730:	mov    %r13,0x20(%rcx)
  10a734:	mov    0x48(%rsp),%r13
  10a739:	add    $0x6,%r14
  10a73d:	add    $0x3,%r15
  10a741:	cmp    0x90(%rsp),%r14
  10a749:	ja     108d2a <fn_4+0x7aa>
  10a74f:	mov    %rbx,0x58(%rsp)
  10a754:	lea    -0x1(%r15),%rbx
  10a758:	cmp    0x10(%r13),%rbx
  10a75c:	jae    10a919 <fn_4+0x2399>
  10a762:	mov    0x8(%r13),%rax
  10a766:	mov    -0x8(%rax,%r15,8),%r13
  10a76b:	cmp    %rbp,%rbx
  10a76e:	jge    10a963 <fn_4+0x23e3>
  10a774:	test   %r13,%r13
  10a777:	je     10af41 <fn_4+0x29c1>
  10a77d:	mov    0x48(%rsp),%rax
  10a782:	cmp    0x10(%rax),%r15
  10a786:	jae    10aa7c <fn_4+0x24fc>
  10a78c:	mov    0x8(%rax),%rax
  10a790:	mov    (%rax,%r15,8),%rbp
  10a794:	test   %rbp,%rbp
  10a797:	je     10af41 <fn_4+0x29c1>
  10a79d:	lea    0x1(%r15),%rax
  10a7a1:	mov    0x48(%rsp),%rcx
  10a7a6:	cmp    0x10(%rcx),%rax
  10a7aa:	jae    10ab0e <fn_4+0x258e>
  10a7b0:	mov    0x8(%rcx),%rax
  10a7b4:	mov    0x8(%rax,%r15,8),%rax
  10a7b9:	test   %rax,%rax
  10a7bc:	je     10af41 <fn_4+0x29c1>
  10a7c2:	shr    $1,%rbp
  10a7c5:	and    $0xfffffffffffffffe,%r13
  10a7c9:	shr    $1,%rax
  10a7cc:	imul   $0x5a,%rax,%rax
  10a7d0:	shr    $1,%rax
  10a7d3:	add    %rbp,%rax
  10a7d6:	imul   $0x5a,%rax,%rax
  10a7da:	lea    (%rax,%r13,1),%rbp
  10a7de:	lea    (%rax,%r13,1),%rbx
  10a7e2:	inc    %rbx
  10a7e5:	cmp    $0x1ffff,%rbp
  10a7ec:	jge    10ace5 <fn_4+0x2765>
  10a7f2:	mov    0x50(%rsp),%rdi
  10a7f7:	incq   (%rdi)
  10a7fa:	mov    0x48(%rsp),%r13
  10a7ff:	je     10ae1e <fn_4+0x289e>
  10a805:	mov    0x10(%rdi),%rsi
  10a809:	mov    0x20(%rdi),%rcx
  10a80d:	mov    %rsi,%rax
  10a810:	sub    %rcx,%rax
  10a813:	cmp    $0x2,%rax
  10a817:	jae    10a88a <fn_4+0x230a>
  10a819:	cmp    $0xfffffffffffffffd,%rcx
  10a81d:	ja     10ab83 <fn_4+0x2603>
  10a823:	mov    %rbx,%r12
  10a826:	add    $0x2,%rcx
  10a82a:	lea    (%rsi,%rsi,1),%rax
  10a82e:	cmp    %rax,%rcx
  10a831:	cmovbe %rax,%rcx
  10a835:	cmp    $0x5,%rcx
  10a839:	mov    $0x4,%ebx
  10a83e:	cmovae %rcx,%rbx
  10a842:	lea    0x0(,%rbx,8),%r13
  10a84a:	shr    $0x3d,%rcx
  10a84e:	setne  %al
  10a851:	movabs $0x7ffffffffffffff8,%rcx
  10a85b:	cmp    %rcx,%r13
  10a85e:	seta   %cl
  10a861:	or     %al,%cl
  10a863:	jne    10ab78 <fn_4+0x25f8>
  10a869:	test   %rsi,%rsi
  10a86c:	je     10a890 <fn_4+0x2310>
  10a86e:	mov    0x50(%rsp),%rax
  10a873:	mov    0x18(%rax),%rdi
  10a877:	shl    $0x3,%rsi
  10a87b:	mov    $0x8,%edx
  10a880:	mov    %r13,%rcx
  10a883:	call   77540 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_realloc>
  10a888:	jmp    10a89d <fn_4+0x231d>
  10a88a:	mov    0x18(%rdi),%rax
  10a88e:	jmp    10a8bf <fn_4+0x233f>
  10a890:	mov    $0x8,%esi
  10a895:	mov    %r13,%rdi
  10a898:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10a89d:	test   %rax,%rax
  10a8a0:	je     10b556 <fn_4+0x2fd6>
  10a8a6:	mov    0x50(%rsp),%rdi
  10a8ab:	mov    %rax,0x18(%rdi)
  10a8af:	mov    %rbx,0x10(%rdi)
  10a8b3:	mov    0x20(%rdi),%rcx
  10a8b7:	mov    0x48(%rsp),%r13
  10a8bc:	mov    %r12,%rbx
  10a8bf:	mov    %rbp,%rdx
  10a8c2:	sar    $0x8,%rdx
  10a8c6:	or     $0x1,%rdx
  10a8ca:	and    $0x1fe,%ebp
  10a8d0:	inc    %rbp
  10a8d3:	mov    %rdx,(%rax,%rcx,8)
  10a8d7:	mov    %rbp,0x8(%rax,%rcx,8)
  10a8dc:	add    $0x2,%rcx
  10a8e0:	mov    %rcx,0x20(%rdi)
  10a8e4:	mov    %rdi,(%rsp)
  10a8e8:	decq   (%rdi)
  10a8eb:	jne    10a8f6 <fn_4+0x2376>
  10a8ed:	mov    %rsp,%rdi
  10a8f0:	addr32 call 133c00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtCs3V9firECmdE_12relar_runtime4ListE9drop_slowBF_>
  10a8f6:	mov    0x80(%rsp),%rbp
  10a8fe:	add    $0x6,%r14
  10a902:	add    $0x3,%r15
  10a906:	cmp    0x90(%rsp),%r14
  10a90e:	jbe    10a74f <fn_4+0x21cf>
  10a914:	jmp    108d2a <fn_4+0x7aa>
  10a919:	movabs $0x6f2074756f207865,%rax
  10a923:	mov    %rax,0x8(%rsp)
  10a928:	movabs $0xd765676e61722066,%rax
  10a932:	mov    %rax,0x10(%rsp)
  10a937:	movabs $0x646e69207473696c,%rax
  10a941:	mov    %rax,(%rsp)
  10a945:	movl   $0x6,0x18(%rsp)
  10a94d:	mov    %rsp,%rdi
  10a950:	xor    %esi,%esi
  10a952:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  10a957:	mov    %rax,%r13
  10a95a:	cmp    %rbp,%rbx
  10a95d:	jl     10a774 <fn_4+0x21f4>
  10a963:	test   %r13,%r13
  10a966:	je     10af41 <fn_4+0x29c1>
  10a96c:	mov    0x48(%rsp),%rax
  10a971:	cmp    0x10(%rax),%r15
  10a975:	jae    10aacb <fn_4+0x254b>
  10a97b:	mov    0x8(%rax),%rax
  10a97f:	mov    (%rax,%r15,8),%rax
  10a983:	test   %rax,%rax
  10a986:	je     10af41 <fn_4+0x29c1>
  10a98c:	shr    $1,%rax
  10a98f:	imul   $0x5a,%rax,%rax
  10a993:	and    $0xfffffffffffffffe,%r13
  10a997:	lea    (%rax,%r13,1),%rcx
  10a99b:	lea    (%rax,%r13,1),%rbx
  10a99f:	inc    %rbx
  10a9a2:	cmp    $0x1ff,%rcx
  10a9a9:	jge    10abb4 <fn_4+0x2634>
  10a9af:	mov    0x50(%rsp),%rax
  10a9b4:	mov    0x20(%rax),%r13
  10a9b8:	cmp    %r13,0x10(%rax)
  10a9bc:	jne    10a720 <fn_4+0x21a0>
  10a9c2:	mov    %rbx,%r12
  10a9c5:	lea    0x0(,%r13,2),%rbx
  10a9cd:	cmp    $0x5,%rbx
  10a9d1:	mov    $0x4,%eax
  10a9d6:	cmovb  %rax,%rbx
  10a9da:	lea    0x0(,%rbx,8),%rbp
  10a9e2:	movabs $0x1000000000000000,%rax
  10a9ec:	dec    %rax
  10a9ef:	cmp    %rax,%r13
  10a9f2:	seta   %al
  10a9f5:	movabs $0x7ffffffffffffff8,%rcx
  10a9ff:	cmp    %rcx,%rbp
  10aa02:	seta   %cl
  10aa05:	or     %al,%cl
  10aa07:	jne    10ab51 <fn_4+0x25d1>
  10aa0d:	test   %r13,%r13
  10aa10:	je     10aa31 <fn_4+0x24b1>
  10aa12:	mov    0x50(%rsp),%rax
  10aa17:	mov    0x18(%rax),%rdi
  10aa1b:	shl    $0x3,%r13
  10aa1f:	mov    $0x8,%edx
  10aa24:	mov    %r13,%rsi
  10aa27:	mov    %rbp,%rcx
  10aa2a:	call   77540 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_realloc>
  10aa2f:	jmp    10aa3e <fn_4+0x24be>
  10aa31:	mov    $0x8,%esi
  10aa36:	mov    %rbp,%rdi
  10aa39:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10aa3e:	test   %rax,%rax
  10aa41:	je     10b565 <fn_4+0x2fe5>
  10aa47:	mov    0x50(%rsp),%rcx
  10aa4c:	mov    %rax,0x18(%rcx)
  10aa50:	mov    %rbx,0x10(%rcx)
  10aa54:	mov    0x20(%rcx),%r13
  10aa58:	cmp    %rbx,%r13
  10aa5b:	jne    10a715 <fn_4+0x2195>
  10aa61:	mov    0x40(%rsp),%rdi
  10aa66:	mov    %r12,%rbx
  10aa69:	addr32 call 12ffb0 <_RNvMs4_NtCscJq9HK9IcCJ_5alloc7raw_vecINtB5_6RawVecINtNtCs6SLOTazmNXq_4core6option6OptionINtNtNtCs3V9firECmdE_12relar_runtime7objects8mappings5EntryINtNtB7_2rc2RcINtNtB7_3vec3VechEEuEEE8grow_oneB1v_>
  10aa6f:	mov    0x80(%rsp),%rbp
  10aa77:	jmp    10a720 <fn_4+0x21a0>
  10aa7c:	movabs $0x6f2074756f207865,%rax
  10aa86:	mov    %rax,0x8(%rsp)
  10aa8b:	movabs $0xd765676e61722066,%rax
  10aa95:	mov    %rax,0x10(%rsp)
  10aa9a:	movabs $0x646e69207473696c,%rax
  10aaa4:	mov    %rax,(%rsp)
  10aaa8:	movl   $0x6,0x18(%rsp)
  10aab0:	mov    %rsp,%rdi
  10aab3:	xor    %esi,%esi
  10aab5:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  10aaba:	mov    %rax,%rbp
  10aabd:	test   %rbp,%rbp
  10aac0:	jne    10a79d <fn_4+0x221d>
  10aac6:	jmp    10af41 <fn_4+0x29c1>
  10aacb:	movabs $0x6f2074756f207865,%rax
  10aad5:	mov    %rax,0x8(%rsp)
  10aada:	movabs $0xd765676e61722066,%rax
  10aae4:	mov    %rax,0x10(%rsp)
  10aae9:	movabs $0x646e69207473696c,%rax
  10aaf3:	mov    %rax,(%rsp)
  10aaf7:	movl   $0x6,0x18(%rsp)
  10aaff:	mov    %rsp,%rdi
  10ab02:	xor    %esi,%esi
  10ab04:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  10ab09:	jmp    10a983 <fn_4+0x2403>
  10ab0e:	movabs $0x6f2074756f207865,%rax
  10ab18:	mov    %rax,0x8(%rsp)
  10ab1d:	movabs $0xd765676e61722066,%rax
  10ab27:	mov    %rax,0x10(%rsp)
  10ab2c:	movabs $0x646e69207473696c,%rax
  10ab36:	mov    %rax,(%rsp)
  10ab3a:	movl   $0x6,0x18(%rsp)
  10ab42:	mov    %rsp,%rdi
  10ab45:	xor    %esi,%esi
  10ab47:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  10ab4c:	jmp    10a7b9 <fn_4+0x2239>
  10ab51:	xor    %ebp,%ebp
  10ab53:	mov    0x78(%rsp),%rax
  10ab58:	mov    %rbp,(%rax)
  10ab5b:	lea    -0xdfffa(%rip),%rdi        # 2ab68 <anon.07dd289d6752232cc34d2640517a38ff.14.llvm.14548151582184166452>
  10ab62:	lea    -0xdfff6(%rip),%rdx        # 2ab73 <anon.07dd289d6752232cc34d2640517a38ff.15.llvm.14548151582184166452>
  10ab69:	mov    $0xb,%esi
  10ab6e:	mov    $0x16,%ecx
  10ab73:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10ab78:	xor    %r13d,%r13d
  10ab7b:	mov    0x78(%rsp),%rax
  10ab80:	mov    %r13,(%rax)
  10ab83:	lea    -0xe0022(%rip),%rdi        # 2ab68 <anon.07dd289d6752232cc34d2640517a38ff.14.llvm.14548151582184166452>
  10ab8a:	lea    -0xe001e(%rip),%rdx        # 2ab73 <anon.07dd289d6752232cc34d2640517a38ff.15.llvm.14548151582184166452>
  10ab91:	mov    $0xb,%esi
  10ab96:	mov    $0x16,%ecx
  10ab9b:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10aba0:	xor    %r13d,%r13d
  10aba3:	xor    %ebp,%ebp
  10aba5:	jmp    1089d8 <fn_4+0x458>
  10abaa:	xor    %r13d,%r13d
  10abad:	xor    %ebp,%ebp
  10abaf:	jmp    10948f <fn_4+0xf0f>
  10abb4:	mov    $0x28,%edi
  10abb9:	mov    $0x8,%esi
  10abbe:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10abc3:	test   %rax,%rax
  10abc6:	je     10b3af <fn_4+0x2e2f>
  10abcc:	movq   $0x1,(%rax)
  10abd3:	movq   $0x1,0x8(%rax)
  10abdb:	pxor   %xmm0,%xmm0
  10abdf:	movdqu %xmm0,0x10(%rax)
  10abe4:	movabs $0xc000000000000000,%rcx
  10abee:	mov    %rcx,0x20(%rax)
  10abf2:	movq   $0x1,(%rsp)
  10abfa:	movq   $0x1,0x8(%rsp)
  10ac03:	mov    %rax,0x10(%rsp)
  10ac08:	movq   $0x0,0x18(%rsp)
  10ac11:	movl   $0x8,0x20(%rsp)
  10ac19:	movb   $0x0,0x24(%rsp)
  10ac1e:	movb   $0x8,0x39(%rsp)
  10ac23:	mov    $0x40,%edi
  10ac28:	mov    $0x8,%esi
  10ac2d:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10ac32:	test   %rax,%rax
  10ac35:	mov    0x48(%rsp),%r13
  10ac3a:	je     10b3cf <fn_4+0x2e4f>
  10ac40:	mov    %rax,%r12
  10ac43:	movups (%rsp),%xmm0
  10ac47:	movups 0x10(%rsp),%xmm1
  10ac4c:	movups 0x20(%rsp),%xmm2
  10ac51:	movups 0x30(%rsp),%xmm3
  10ac56:	movups %xmm3,0x30(%rax)
  10ac5a:	movups %xmm2,0x20(%rax)
  10ac5e:	movups %xmm1,0x10(%rax)
  10ac62:	movups %xmm0,(%rax)
  10ac65:	cmpb   $0x8,0x39(%rax)
  10ac69:	jne    10b3f9 <fn_4+0x2e79>
  10ac6f:	incq   (%r12)
  10ac73:	je     10ae1e <fn_4+0x289e>
  10ac79:	mov    %r12,0x60(%rsp)
  10ac7e:	xor    %edi,%edi
  10ac80:	call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  10ac85:	test   %rax,%rax
  10ac88:	je     10b5b0 <fn_4+0x3030>
  10ac8e:	mov    %r12,(%rsp)
  10ac92:	cmpq   $0x0,(%rax)
  10ac96:	jne    10b433 <fn_4+0x2eb3>
  10ac9c:	mov    %rbx,%r14
  10ac9f:	mov    0x8(%rax),%rbx
  10aca3:	mov    %r12,0x8(%rax)
  10aca7:	mov    %rsp,%rdi
  10acaa:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  10acaf:	movb   $0x1,(%rax)
  10acb2:	mov    %rbx,(%rsp)
  10acb6:	test   %rbx,%rbx
  10acb9:	je     10acc9 <fn_4+0x2749>
  10acbb:	decq   (%rbx)
  10acbe:	jne    10acc9 <fn_4+0x2749>
  10acc0:	mov    %rsp,%rdi
  10acc3:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10acc9:	mov    %r12,(%rsp)
  10accd:	decq   (%r12)
  10acd1:	jne    10ae11 <fn_4+0x2891>
  10acd7:	mov    %rsp,%rdi
  10acda:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10ace0:	jmp    10ae11 <fn_4+0x2891>
  10ace5:	mov    $0x28,%edi
  10acea:	mov    $0x8,%esi
  10acef:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10acf4:	test   %rax,%rax
  10acf7:	mov    0x48(%rsp),%r13
  10acfc:	je     10b3bf <fn_4+0x2e3f>
  10ad02:	movq   $0x1,(%rax)
  10ad09:	movq   $0x1,0x8(%rax)
  10ad11:	pxor   %xmm0,%xmm0
  10ad15:	movdqu %xmm0,0x10(%rax)
  10ad1a:	movabs $0xc000000000000000,%rcx
  10ad24:	mov    %rcx,0x20(%rax)
  10ad28:	movq   $0x1,(%rsp)
  10ad30:	movq   $0x1,0x8(%rsp)
  10ad39:	mov    %rax,0x10(%rsp)
  10ad3e:	movq   $0x0,0x18(%rsp)
  10ad47:	movl   $0x8,0x20(%rsp)
  10ad4f:	movb   $0x0,0x24(%rsp)
  10ad54:	movb   $0x8,0x39(%rsp)
  10ad59:	mov    $0x40,%edi
  10ad5e:	mov    $0x8,%esi
  10ad63:	call   774c0 <_RNvCsdDBZ5SCsGGz_7___rustc11___rdl_alloc>
  10ad68:	test   %rax,%rax
  10ad6b:	je     10b3e4 <fn_4+0x2e64>
  10ad71:	mov    %rax,%r12
  10ad74:	movdqu (%rsp),%xmm0
  10ad79:	movdqu 0x10(%rsp),%xmm1
  10ad7f:	movdqu 0x20(%rsp),%xmm2
  10ad85:	movdqu 0x30(%rsp),%xmm3
  10ad8b:	movdqu %xmm3,0x30(%rax)
  10ad90:	movdqu %xmm2,0x20(%rax)
  10ad95:	movdqu %xmm1,0x10(%rax)
  10ad9a:	movdqu %xmm0,(%rax)
  10ad9e:	cmpb   $0x8,0x39(%rax)
  10ada2:	jne    10b416 <fn_4+0x2e96>
  10ada8:	incq   (%r12)
  10adac:	je     10ae1e <fn_4+0x289e>
  10adae:	mov    %r12,0x60(%rsp)
  10adb3:	xor    %edi,%edi
  10adb5:	call   12e3f0 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions7PENDING00INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1f_6option6OptionQIB1U_INtNtB1f_4cell7RefCellIB1U_INtNtCscJq9HK9IcCJ_5alloc2rc2RcNtBa_6ObjectEEEEEEE9call_onceBc_.llvm.7526630615700072279>
  10adba:	test   %rax,%rax
  10adbd:	je     10b5ce <fn_4+0x304e>
  10adc3:	mov    %r12,(%rsp)
  10adc7:	cmpq   $0x0,(%rax)
  10adcb:	jne    10b440 <fn_4+0x2ec0>
  10add1:	mov    %rbx,%r14
  10add4:	mov    0x8(%rax),%rbx
  10add8:	mov    %r12,0x8(%rax)
  10addc:	mov    %rsp,%rdi
  10addf:	call   12e380 <_RNvYNCNKNvNtNtCs3V9firECmdE_12relar_runtime7objects10exceptions15PENDING_PRESENT0s_0INtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTINtNtB1q_6option6OptionQIB25_INtNtB1q_4cell4CellbEEEEE9call_onceBc_.llvm.7526630615700072279>
  10ade4:	movb   $0x1,(%rax)
  10ade7:	mov    %rbx,(%rsp)
  10adeb:	test   %rbx,%rbx
  10adee:	je     10adfe <fn_4+0x287e>
  10adf0:	decq   (%rbx)
  10adf3:	jne    10adfe <fn_4+0x287e>
  10adf5:	mov    %rsp,%rdi
  10adf8:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10adfe:	mov    %r12,(%rsp)
  10ae02:	decq   (%r12)
  10ae06:	jne    10ae11 <fn_4+0x2891>
  10ae08:	mov    %rsp,%rdi
  10ae0b:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10ae11:	mov    0x40(%rsp),%r12
  10ae16:	mov    %r14,%rbx
  10ae19:	jmp    1091b6 <fn_4+0xc36>
  10ae1e:	ud2
  10ae20:	mov    %rax,%rbp
  10ae23:	lea    -0xdf922(%rip),%rdi        # 2b508 <anon.a32fe9f9f6555f50d5f367eaf6585c5b.3.llvm.12851202843824566656>
  10ae2a:	mov    $0x1e,%ebx
  10ae2f:	mov    $0x1e,%esi
  10ae34:	addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
  10ae3a:	test   %rax,%rax
  10ae3d:	je     10b44d <fn_4+0x2ecd>
  10ae43:	mov    %rax,%r14
  10ae46:	mov    %rdx,%r13
  10ae49:	mov    $0x1,%edx
  10ae4e:	mov    %rbp,%rdi
  10ae51:	mov    %r12,%rsi
  10ae54:	call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  10ae59:	mov    $0x8,%eax
  10ae5e:	jmp    1093e7 <fn_4+0xe67>
  10ae63:	test   $0x1,%bl
  10ae66:	jne    10ae71 <fn_4+0x28f1>
  10ae68:	mov    %rbx,%rdi
  10ae6b:	addr32 call 115940 <relar_int_release>
  10ae71:	mov    %r14,%rbx
  10ae74:	mov    0x40(%rsp),%r12
  10ae79:	jmp    1091b6 <fn_4+0xc36>
  10ae7e:	lea    -0xe02e2(%rip),%rdi        # 2aba3 <anon.07dd289d6752232cc34d2640517a38ff.20.llvm.14548151582184166452>
  10ae85:	lea    -0xe02df(%rip),%rdx        # 2abad <anon.07dd289d6752232cc34d2640517a38ff.21.llvm.14548151582184166452>
  10ae8c:	mov    $0xa,%esi
  10ae91:	mov    $0xd,%ecx
  10ae96:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10ae9b:	mov    %r12,%rsi
  10ae9e:	addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
  10aea4:	test   %rax,%rax
  10aea7:	je     10b4fe <fn_4+0x2f7e>
  10aead:	mov    %rax,%r13
  10aeb0:	mov    %rdx,%r15
  10aeb3:	jmp    10884e <fn_4+0x2ce>
  10aeb8:	mov    $0x8,%edi
  10aebd:	mov    $0x28,%esi
  10aec2:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10aec8:	xor    %r13d,%r13d
  10aecb:	jmp    1091ae <fn_4+0xc2e>
  10aed0:	lea    0x5a1d1(%rip),%rdi        # 1650a8 <anon.b5c5b1d202edf6079cbd4240259d7569.9.llvm.9011365425941023334>
  10aed7:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10aedd:	mov    $0x26,%ecx
  10aee2:	lea    -0xdff16(%rip),%rdx        # 2afd3 <anon.5a426941b95332e7deb832e37db0b8d7.19.llvm.13056261042975510615>
  10aee9:	mov    $0x9,%esi
  10aeee:	lea    -0xe0029(%rip),%rdi        # 2aecc <anon.5a426941b95332e7deb832e37db0b8d7.0.llvm.13056261042975510615>
  10aef5:	jmp    10af0f <fn_4+0x298f>
  10aef7:	mov    $0x1c,%ecx
  10aefc:	lea    -0xdffcd(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10af03:	mov    $0xb,%esi
  10af08:	lea    -0xdfffe(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10af0f:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10af14:	mov    $0x8,%edi
  10af19:	mov    $0x28,%esi
  10af1e:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10af24:	lea    -0xe0388(%rip),%rdi        # 2aba3 <anon.07dd289d6752232cc34d2640517a38ff.20.llvm.14548151582184166452>
  10af2b:	lea    -0xe0385(%rip),%rdx        # 2abad <anon.07dd289d6752232cc34d2640517a38ff.21.llvm.14548151582184166452>
  10af32:	mov    $0xa,%esi
  10af37:	mov    $0xd,%ecx
  10af3c:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10af41:	mov    0x48(%rsp),%r13
  10af46:	jmp    10a5d2 <fn_4+0x2052>
  10af4b:	mov    %r15,%rsi
  10af4e:	addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
  10af54:	test   %rax,%rax
  10af57:	je     10b50b <fn_4+0x2f8b>
  10af5d:	mov    %rax,%r12
  10af60:	mov    %rdx,%r14
  10af63:	jmp    109077 <fn_4+0xaf7>
  10af68:	mov    $0x8,%edi
  10af6d:	mov    $0x28,%esi
  10af72:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10af78:	lea    0x10(%rsp),%rbx
  10af7d:	mov    $0x8,%edi
  10af82:	mov    $0x40,%esi
  10af87:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10af8d:	lea    -0xe0083(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10af94:	lea    -0xe0065(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10af9b:	mov    $0xb,%esi
  10afa0:	mov    $0x1c,%ecx
  10afa5:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10afaa:	lea    0x5a25f(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
  10afb1:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10afb7:	test   %rbp,%rbp
  10afba:	sete   %al
  10afbd:	or     %bpl,%al
  10afc0:	test   $0x1,%al
  10afc2:	jne    10afcd <fn_4+0x2a4d>
  10afc4:	mov    %rbp,%rdi
  10afc7:	addr32 call 115940 <relar_int_release>
  10afcd:	mov    %r14,%rbx
  10afd0:	mov    0x48(%rsp),%r13
  10afd5:	mov    0x40(%rsp),%r12
  10afda:	jmp    1091b6 <fn_4+0xc36>
  10afdf:	mov    %rax,%rdi
  10afe2:	mov    %r13,%rsi
  10afe5:	addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
  10afeb:	test   %rax,%rax
  10afee:	je     10b53c <fn_4+0x2fbc>
  10aff4:	mov    %rax,%rbp
  10aff7:	mov    %rdx,%r15
  10affa:	jmp    1089d8 <fn_4+0x458>
  10afff:	mov    $0x8,%edi
  10b004:	mov    $0x28,%esi
  10b009:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b00f:	lea    0x5a212(%rip),%rdi        # 165228 <anon.e35a9af1f69509cfdb48e0a540415976.9.llvm.14158413026871995055>
  10b016:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10b01c:	lea    -0xe0480(%rip),%rdi        # 2aba3 <anon.07dd289d6752232cc34d2640517a38ff.20.llvm.14548151582184166452>
  10b023:	lea    -0xe047d(%rip),%rdx        # 2abad <anon.07dd289d6752232cc34d2640517a38ff.21.llvm.14548151582184166452>
  10b02a:	mov    $0xa,%esi
  10b02f:	mov    $0xd,%ecx
  10b034:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b039:	mov    %r13,%rsi
  10b03c:	addr32 call 139ed0 <_RNvMNtNtCs1AOPbhp2p9e_11compact_str4repr4heapNtB2_10HeapBuffer10alloc_copy>
  10b042:	test   %rax,%rax
  10b045:	je     10b549 <fn_4+0x2fc9>
  10b04b:	mov    %rax,%rbp
  10b04e:	mov    %rdx,%r12
  10b051:	jmp    10948f <fn_4+0xf0f>
  10b056:	mov    $0x8,%edi
  10b05b:	mov    $0x28,%esi
  10b060:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b066:	lea    0x10(%rsp),%rbx
  10b06b:	mov    $0x8,%edi
  10b070:	mov    $0x40,%esi
  10b075:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b07b:	lea    -0xe0171(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10b082:	lea    -0xe0153(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10b089:	mov    $0xb,%esi
  10b08e:	mov    $0x1c,%ecx
  10b093:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b098:	lea    -0xdf9bb(%rip),%rdi        # 2b6e4 <anon.a6314b0dfcd62d2058f2b6595a6854b4.0.llvm.7526630615700072279>
  10b09f:	lea    -0xdf9b7(%rip),%rdx        # 2b6ef <anon.a6314b0dfcd62d2058f2b6595a6854b4.1.llvm.7526630615700072279>
  10b0a6:	mov    $0xb,%esi
  10b0ab:	mov    $0x1c,%ecx
  10b0b0:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b0b5:	lea    -0xe01ab(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10b0bc:	lea    -0xe018d(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10b0c3:	mov    $0xb,%esi
  10b0c8:	mov    $0x1c,%ecx
  10b0cd:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b0d2:	lea    0x5a137(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
  10b0d9:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10b0df:	lea    0x5a142(%rip),%rdi        # 165228 <anon.e35a9af1f69509cfdb48e0a540415976.9.llvm.14158413026871995055>
  10b0e6:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10b0ec:	lea    0x68(%rsp),%rcx
  10b0f1:	mov    0x8(%r14),%rsi
  10b0f5:	mov    0x10(%r14),%rdx
  10b0f9:	mov    %rsp,%rdi
  10b0fc:	call   1255a0 <_RNvNtNtCs3V9firECmdE_12relar_runtime7objects5bytes12decode_error.llvm.12851202843824566656>
  10b101:	mov    %rsp,%rdi
  10b104:	xor    %esi,%esi
  10b106:	call   12bea0 <_RINvMs0_NtNtCs3V9firECmdE_12relar_runtime7objects10exceptionsNtB6_5Error9returningPINtNtCscJq9HK9IcCJ_5alloc3vec3VechEEBa_>
  10b10b:	mov    %rax,%r14
  10b10e:	jmp    1086a7 <fn_4+0x127>
  10b113:	xor    %r13d,%r13d
  10b116:	jmp    1091b3 <fn_4+0xc33>
  10b11b:	test   $0x1,%r15b
  10b11f:	jne    10b12a <fn_4+0x2baa>
  10b121:	mov    %rbx,%rdi
  10b124:	addr32 call 115940 <relar_int_release>
  10b12a:	mov    0x40(%rsp),%r12
  10b12f:	jmp    10b15b <fn_4+0x2bdb>
  10b131:	test   %r13,%r13
  10b134:	sete   %al
  10b137:	or     %r13b,%al
  10b13a:	test   $0x1,%al
  10b13c:	mov    0x40(%rsp),%r12
  10b141:	jne    10b14c <fn_4+0x2bcc>
  10b143:	mov    %r13,%rdi
  10b146:	addr32 call 115940 <relar_int_release>
  10b14c:	test   $0x1,%r15b
  10b150:	jne    10b15b <fn_4+0x2bdb>
  10b152:	mov    %rbx,%rdi
  10b155:	addr32 call 115940 <relar_int_release>
  10b15b:	mov    %r12,%rdi
  10b15e:	addr32 call 1167e0 <relar_list_release>
  10b164:	mov    0x48(%rsp),%r13
  10b169:	jmp    1091b6 <fn_4+0xc36>
  10b16e:	mov    $0x8,%edi
  10b173:	mov    $0x28,%esi
  10b178:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b17e:	mov    0x40(%rsp),%r12
  10b183:	jmp    1091b6 <fn_4+0xc36>
  10b188:	lea    -0xe027e(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10b18f:	lea    -0xe0260(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10b196:	mov    $0xb,%esi
  10b19b:	mov    $0x1c,%ecx
  10b1a0:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b1a5:	lea    0x5a064(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
  10b1ac:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10b1b2:	xor    %r15d,%r15d
  10b1b5:	jmp    108733 <fn_4+0x1b3>
  10b1ba:	mov    $0x8,%edi
  10b1bf:	mov    $0x28,%esi
  10b1c4:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b1ca:	mov    $0x8,%edi
  10b1cf:	mov    $0x28,%esi
  10b1d4:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b1da:	cmp    $0x1,%eax
  10b1dd:	jne    10a3bb <fn_4+0x1e3b>
  10b1e3:	lea    0x29cb6(%rip),%rsi        # 134ea0 <_RINvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local6native5eager7destroyINtNtCs6SLOTazmNXq_4core4cell7RefCellAINtNtCscJq9HK9IcCJ_5alloc3vec3VecNtCs3V9firECmdE_12relar_runtime3IntEj2_EEB2g_.llvm.6207308902554770856>
  10b1ea:	mov    %rbp,%rdi
  10b1ed:	addr32 call a2320 <_RNvNtNtNtNtCs3w1E8YNP9ew_3std3sys12thread_local11destructors10linux_like8register>
  10b1f3:	movb   $0x0,0x38(%rbp)
  10b1f7:	mov    0x50(%rsp),%r14
  10b1fc:	cmpq   $0x0,0x0(%rbp)
  10b201:	jne    10a3bb <fn_4+0x1e3b>
  10b207:	lea    (%r12,%r12,1),%rcx
  10b20b:	mov    0x8(%rbp),%rdx
  10b20f:	mov    0x20(%rbp),%rax
  10b213:	cmp    %rdx,%r12
  10b216:	seta   %sil
  10b21a:	cmp    %rcx,%rdx
  10b21d:	seta   %dil
  10b221:	or     %sil,%dil
  10b224:	je     10b248 <fn_4+0x2cc8>
  10b226:	cmp    %rax,%r12
  10b229:	seta   %dl
  10b22c:	cmp    %rcx,%rax
  10b22f:	seta   %al
  10b232:	or     %dl,%al
  10b234:	mov    $0x1,%ecx
  10b239:	je     10b266 <fn_4+0x2ce6>
  10b23b:	movq   $0x0,0x0(%rbp)
  10b243:	jmp    10a3bb <fn_4+0x1e3b>
  10b248:	cmp    %rax,%r12
  10b24b:	setbe  %sil
  10b24f:	cmp    %rcx,%rax
  10b252:	setbe  %cl
  10b255:	test   %cl,%sil
  10b258:	je     10b264 <fn_4+0x2ce4>
  10b25a:	xor    %ecx,%ecx
  10b25c:	cmp    %rax,%rdx
  10b25f:	seta   %cl
  10b262:	jmp    10b266 <fn_4+0x2ce6>
  10b264:	xor    %ecx,%ecx
  10b266:	lea    0x8(%rbp),%rdx
  10b26a:	lea    (%rcx,%rcx,2),%rsi
  10b26e:	mov    (%rdx,%rsi,8),%r13
  10b272:	mov    0x8(%rdx,%rsi,8),%rax
  10b277:	mov    0x10(%rdx,%rsi,8),%rbx
  10b27c:	movq   $0x0,(%rdx,%rsi,8)
  10b284:	movq   $0x8,0x8(%rdx,%rsi,8)
  10b28d:	movq   $0x0,0x10(%rdx,%rsi,8)
  10b296:	test   %rcx,%rcx
  10b299:	jne    10b2cf <fn_4+0x2d4f>
  10b29b:	lea    0x20(%rbp),%rcx
  10b29f:	mov    0x10(%rdx),%rsi
  10b2a3:	mov    %rsi,0x10(%rsp)
  10b2a8:	movups (%rdx),%xmm0
  10b2ab:	movaps %xmm0,(%rsp)
  10b2af:	mov    0x10(%rcx),%rsi
  10b2b3:	mov    %rsi,0x10(%rdx)
  10b2b7:	movups (%rcx),%xmm0
  10b2ba:	movups %xmm0,(%rdx)
  10b2bd:	mov    0x10(%rsp),%rdx
  10b2c2:	mov    %rdx,0x10(%rcx)
  10b2c6:	movdqa (%rsp),%xmm0
  10b2cb:	movdqu %xmm0,(%rcx)
  10b2cf:	movq   $0x0,0x0(%rbp)
  10b2d7:	cmp    $0xffffffffffffffff,%r13
  10b2db:	je     10a3bb <fn_4+0x1e3b>
  10b2e1:	cmp    %r12,%r13
  10b2e4:	jae    10b2ee <fn_4+0x2d6e>
  10b2e6:	mov    %rax,%r15
  10b2e9:	jmp    10a3c0 <fn_4+0x1e40>
  10b2ee:	mov    0x10(%r14),%rcx
  10b2f2:	mov    0x18(%r14),%r15
  10b2f6:	mov    0x20(%r14),%rdx
  10b2fa:	mov    %r13,0x10(%r14)
  10b2fe:	mov    %rax,0x18(%r14)
  10b302:	mov    %rbx,0x20(%r14)
  10b306:	mov    %rcx,%r13
  10b309:	mov    %rdx,%rbx
  10b30c:	jmp    10a3da <fn_4+0x1e5a>
  10b311:	mov    $0x8,%edi
  10b316:	mov    $0x28,%esi
  10b31b:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b321:	lea    0x10(%rsp),%rbx
  10b326:	mov    $0x8,%edi
  10b32b:	mov    $0x40,%esi
  10b330:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b336:	mov    $0x8,%edi
  10b33b:	mov    $0x28,%esi
  10b340:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b346:	lea    -0xe043c(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10b34d:	lea    -0xe041e(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10b354:	mov    $0xb,%esi
  10b359:	mov    $0x1c,%ecx
  10b35e:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b363:	lea    0x10(%rsp),%rbx
  10b368:	mov    $0x8,%edi
  10b36d:	mov    $0x40,%esi
  10b372:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b378:	lea    -0xe046e(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10b37f:	lea    -0xe0450(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10b386:	mov    $0xb,%esi
  10b38b:	mov    $0x1c,%ecx
  10b390:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b395:	lea    0x59e74(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
  10b39c:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10b3a2:	lea    0x59e67(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
  10b3a9:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10b3af:	mov    $0x8,%edi
  10b3b4:	mov    $0x28,%esi
  10b3b9:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b3bf:	mov    $0x8,%edi
  10b3c4:	mov    $0x28,%esi
  10b3c9:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b3cf:	lea    0x10(%rsp),%rbx
  10b3d4:	mov    $0x8,%edi
  10b3d9:	mov    $0x40,%esi
  10b3de:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b3e4:	lea    0x10(%rsp),%rbx
  10b3e9:	mov    $0x8,%edi
  10b3ee:	mov    $0x40,%esi
  10b3f3:	addr32 call df129 <_RNvNtCscJq9HK9IcCJ_5alloc5alloc18handle_alloc_error>
  10b3f9:	lea    -0xe04ef(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10b400:	lea    -0xe04d1(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10b407:	mov    $0xb,%esi
  10b40c:	mov    $0x1c,%ecx
  10b411:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b416:	lea    -0xe050c(%rip),%rdi        # 2af11 <anon.5a426941b95332e7deb832e37db0b8d7.9.llvm.13056261042975510615>
  10b41d:	lea    -0xe04ee(%rip),%rdx        # 2af36 <anon.5a426941b95332e7deb832e37db0b8d7.13.llvm.13056261042975510615>
  10b424:	mov    $0xb,%esi
  10b429:	mov    $0x1c,%ecx
  10b42e:	call   10e100 <_RNvCs3V9firECmdE_12relar_runtime4fail>
  10b433:	lea    0x59dd6(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
  10b43a:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10b440:	lea    0x59dc9(%rip),%rdi        # 165210 <anon.e35a9af1f69509cfdb48e0a540415976.6.llvm.14158413026871995055>
  10b447:	addr32 call ec700 <_RNvNtCs6SLOTazmNXq_4core4cell22panic_already_borrowed>
  10b44d:	lea    0x599a4(%rip),%rdi        # 164df8 <anon.a32fe9f9f6555f50d5f367eaf6585c5b.2.llvm.12851202843824566656>
  10b454:	addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
  10b45a:	lea    0x59d7f(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b461:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b467:	decq   (%r14)
  10b46a:	jne    10b477 <fn_4+0x2ef7>
  10b46c:	lea    0x60(%rsp),%rdi
  10b471:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b477:	lea    0x59d62(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b47e:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b484:	decq   (%rbx)
  10b487:	jne    10b494 <fn_4+0x2f14>
  10b489:	lea    0x60(%rsp),%rdi
  10b48e:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b494:	lea    0x59d45(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b49b:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b4a1:	decq   (%r12)
  10b4a5:	jne    10b4b2 <fn_4+0x2f32>
  10b4a7:	lea    0x60(%rsp),%rdi
  10b4ac:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b4b2:	lea    0x59d27(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b4b9:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b4bf:	test   %r15,%r15
  10b4c2:	je     10b4d4 <fn_4+0x2f54>
  10b4c4:	decq   (%r15)
  10b4c7:	jne    10b4d4 <fn_4+0x2f54>
  10b4c9:	lea    0x60(%rsp),%rdi
  10b4ce:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b4d4:	lea    0x59d05(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b4db:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b4e1:	decq   (%rbx)
  10b4e4:	jne    10b4f1 <fn_4+0x2f71>
  10b4e6:	lea    0x60(%rsp),%rdi
  10b4eb:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b4f1:	lea    0x59ce8(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b4f8:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b4fe:	lea    0x596fb(%rip),%rdi        # 164c00 <anon.07dd289d6752232cc34d2640517a38ff.59.llvm.14548151582184166452>
  10b505:	addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
  10b50b:	lea    0x596ee(%rip),%rdi        # 164c00 <anon.07dd289d6752232cc34d2640517a38ff.59.llvm.14548151582184166452>
  10b512:	addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
  10b518:	lea    0x60(%rsp),%rax
  10b51d:	mov    %rax,0x88(%rsp)
  10b525:	jmp    10a2ff <fn_4+0x1d7f>
  10b52a:	lea    0x60(%rsp),%rax
  10b52f:	mov    %rax,0x88(%rsp)
  10b537:	jmp    10a32a <fn_4+0x1daa>
  10b53c:	lea    0x597ed(%rip),%rdi        # 164d30 <anon.5a426941b95332e7deb832e37db0b8d7.23.llvm.13056261042975510615>
  10b543:	addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
  10b549:	lea    0x596b0(%rip),%rdi        # 164c00 <anon.07dd289d6752232cc34d2640517a38ff.59.llvm.14548151582184166452>
  10b550:	addr32 call 139590 <_RINvCs1AOPbhp2p9e_11compact_str20unwrap_with_msg_failNtB2_12ReserveErrorEB2_>
  10b556:	lea    0x60(%rsp),%rax
  10b55b:	mov    %rax,0x78(%rsp)
  10b560:	jmp    10ab7b <fn_4+0x25fb>
  10b565:	lea    0x60(%rsp),%rax
  10b56a:	mov    %rax,0x78(%rsp)
  10b56f:	jmp    10ab53 <fn_4+0x25d3>
  10b574:	decq   (%r12)
  10b578:	jne    10b585 <fn_4+0x3005>
  10b57a:	lea    0x60(%rsp),%rdi
  10b57f:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b585:	lea    0x59c54(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b58c:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b592:	decq   (%r12)
  10b596:	jne    10b5a3 <fn_4+0x3023>
  10b598:	lea    0x60(%rsp),%rdi
  10b59d:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b5a3:	lea    0x59c36(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b5aa:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b5b0:	decq   (%r12)
  10b5b4:	jne    10b5c1 <fn_4+0x3041>
  10b5b6:	lea    0x60(%rsp),%rdi
  10b5bb:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b5c1:	lea    0x59c18(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b5c8:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b5ce:	decq   (%r12)
  10b5d2:	jne    10b5df <fn_4+0x305f>
  10b5d4:	lea    0x60(%rsp),%rdi
  10b5d9:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b5df:	lea    0x59bfa(%rip),%rdi        # 1651e0 <anon.e35a9af1f69509cfdb48e0a540415976.2.llvm.14158413026871995055>
  10b5e6:	addr32 call 9c910 <_RNvNtNtCs3w1E8YNP9ew_3std6thread5local18panic_access_error>
  10b5ec:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b5f2:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b5f8:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b5fe:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b604:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b60a:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b610:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b616:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b61c:	decq   (%r12)
  10b620:	jne    10bc40 <fn_4+0x36c0>
  10b626:	lea    0x60(%rsp),%rdi
  10b62b:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b631:	jmp    10bc40 <fn_4+0x36c0>
  10b636:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b63c:	decq   (%r12)
  10b640:	jne    10bc40 <fn_4+0x36c0>
  10b646:	lea    0x60(%rsp),%rdi
  10b64b:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b651:	jmp    10bc40 <fn_4+0x36c0>
  10b656:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b65c:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b662:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b668:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b66e:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b674:	mov    %rbx,%rdi
  10b677:	call   10d190 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtCs3V9firECmdE_12relar_runtime3IntEBD_.llvm.14548151582184166452>
  10b67c:	jmp    10bc40 <fn_4+0x36c0>
  10b681:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b687:	decq   (%r12)
  10b68b:	jne    10bc40 <fn_4+0x36c0>
  10b691:	lea    0x60(%rsp),%rdi
  10b696:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b69c:	jmp    10bc40 <fn_4+0x36c0>
  10b6a1:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b6a7:	decq   (%r12)
  10b6ab:	jne    10bc40 <fn_4+0x36c0>
  10b6b1:	lea    0x60(%rsp),%rdi
  10b6b6:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b6bc:	jmp    10bc40 <fn_4+0x36c0>
  10b6c1:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b6c7:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6cd:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6d3:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6d9:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6df:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6e5:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6eb:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6f1:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6f7:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b6fd:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b703:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b709:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b70f:	mov    %rbx,(%r14)
  10b712:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b718:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b71e:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b724:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b72a:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b730:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b736:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b73c:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b742:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b748:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b74e:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b754:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b75a:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b760:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b766:	lea    0x33a3(%rip),%r14        # 10eb10 <_RNvXs0_Cs3V9firECmdE_12relar_runtimeNtB5_3IntNtNtNtCs6SLOTazmNXq_4core3ops4drop4Drop4drop>
  10b76d:	dec    %rbx
  10b770:	je     10b782 <fn_4+0x3202>
  10b772:	lea    0x8(%r12),%r15
  10b777:	mov    %r12,%rdi
  10b77a:	call   *%r14
  10b77d:	mov    %r15,%r12
  10b780:	jmp    10b76d <fn_4+0x31ed>
  10b782:	mov    %rsp,%rdi
  10b785:	call   130340 <_RNvXs1_NtCscJq9HK9IcCJ_5alloc7raw_vecINtB5_6RawVecINtNtCs6SLOTazmNXq_4core6option6OptionINtNtNtCs3V9firECmdE_12relar_runtime7objects8mappings5EntryINtNtB7_2rc2RcINtNtB7_3vec3VechEEuEEENtNtNtBR_3ops4drop4Drop4dropB1v_>
  10b78a:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b790:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b796:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b79c:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7a2:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7a8:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7ae:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7b4:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7ba:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7c0:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7c6:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7cc:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7d2:	mov    0x58(%rsp),%rdi
  10b7d7:	call   10d190 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtCs3V9firECmdE_12relar_runtime3IntEBD_.llvm.14548151582184166452>
  10b7dc:	jmp    10bc40 <fn_4+0x36c0>
  10b7e1:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b7e7:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7ed:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7f3:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b7f9:	decq   (%rbx)
  10b7fc:	jne    10bc40 <fn_4+0x36c0>
  10b802:	lea    0x60(%rsp),%rdi
  10b807:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b80d:	jmp    10bc40 <fn_4+0x36c0>
  10b812:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b818:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b81e:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b824:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b82a:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b830:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b836:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b83c:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b842:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b848:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b84e:	test   %r15,%r15
  10b851:	je     10bc40 <fn_4+0x36c0>
  10b857:	decq   (%r15)
  10b85a:	jne    10bc40 <fn_4+0x36c0>
  10b860:	lea    0x60(%rsp),%rdi
  10b865:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b86b:	jmp    10bc40 <fn_4+0x36c0>
  10b870:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b876:	decq   (%r12)
  10b87a:	jne    10bc40 <fn_4+0x36c0>
  10b880:	lea    0x60(%rsp),%rdi
  10b885:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b88b:	jmp    10bc40 <fn_4+0x36c0>
  10b890:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b896:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b89c:	decq   (%rbx)
  10b89f:	jne    10bc40 <fn_4+0x36c0>
  10b8a5:	lea    0x60(%rsp),%rdi
  10b8aa:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b8b0:	jmp    10bc40 <fn_4+0x36c0>
  10b8b5:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b8bb:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b8c1:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b8c7:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b8cd:	decq   (%r14)
  10b8d0:	jne    10bc40 <fn_4+0x36c0>
  10b8d6:	lea    0x60(%rsp),%rdi
  10b8db:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b8e1:	jmp    10bc40 <fn_4+0x36c0>
  10b8e6:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b8ec:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b8f2:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b8f8:	lea    0x60(%rsp),%rdi
  10b8fd:	call   1253a0 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc3vec3VechEECs3V9firECmdE_12relar_runtime.llvm.12851202843824566656>
  10b902:	jmp    10bc40 <fn_4+0x36c0>
  10b907:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b90d:	decq   (%r12)
  10b911:	jne    10bc40 <fn_4+0x36c0>
  10b917:	mov    %rsp,%rdi
  10b91a:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b920:	jmp    10bc40 <fn_4+0x36c0>
  10b925:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b92b:	decq   (%r12)
  10b92f:	jne    10bc40 <fn_4+0x36c0>
  10b935:	mov    %rsp,%rdi
  10b938:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b93e:	jmp    10bc40 <fn_4+0x36c0>
  10b943:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b949:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b94f:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b955:	mov    %rbx,%rdi
  10b958:	call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12relar_runtime7objects7StorageEBF_.llvm.7526630615700072279>
  10b95d:	jmp    10bc40 <fn_4+0x36c0>
  10b962:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b968:	mov    %rbx,%rdi
  10b96b:	call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12relar_runtime7objects7StorageEBF_.llvm.7526630615700072279>
  10b970:	jmp    10bc40 <fn_4+0x36c0>
  10b975:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b97b:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b981:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b987:	decq   (%r12)
  10b98b:	jne    10bc40 <fn_4+0x36c0>
  10b991:	mov    %rsp,%rdi
  10b994:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b99a:	jmp    10bc40 <fn_4+0x36c0>
  10b99f:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b9a5:	decq   (%r12)
  10b9a9:	jne    10bc40 <fn_4+0x36c0>
  10b9af:	mov    %rsp,%rdi
  10b9b2:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10b9b8:	jmp    10bc40 <fn_4+0x36c0>
  10b9bd:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b9c3:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b9c9:	mov    %rbx,%rdi
  10b9cc:	call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12relar_runtime7objects7StorageEBF_.llvm.7526630615700072279>
  10b9d1:	jmp    10bc40 <fn_4+0x36c0>
  10b9d6:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b9dc:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b9e2:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10b9e8:	mov    %rbx,%rdi
  10b9eb:	call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12relar_runtime7objects7StorageEBF_.llvm.7526630615700072279>
  10b9f0:	jmp    10bc40 <fn_4+0x36c0>
  10b9f5:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10b9fb:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10ba01:	mov    %rsp,%rdi
  10ba04:	call   10cc70 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerNtCs3V9firECmdE_12relar_runtime4ListEEB1d_.llvm.14548151582184166452>
  10ba09:	jmp    10bc40 <fn_4+0x36c0>
  10ba0e:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10ba14:	mov    %rsp,%rdi
  10ba17:	call   125380 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerINtNtBG_3vec3VechEEECs3V9firECmdE_12relar_runtime.llvm.12851202843824566656>
  10ba1c:	jmp    10bc40 <fn_4+0x36c0>
  10ba21:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10ba27:	decq   (%rbx)
  10ba2a:	jne    10bc40 <fn_4+0x36c0>
  10ba30:	mov    %rsp,%rdi
  10ba33:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10ba39:	jmp    10bc40 <fn_4+0x36c0>
  10ba3e:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10ba44:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10ba4a:	mov    %rsp,%rdi
  10ba4d:	call   10cc70 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerNtCs3V9firECmdE_12relar_runtime4ListEEB1d_.llvm.14548151582184166452>
  10ba52:	jmp    10bc40 <fn_4+0x36c0>
  10ba57:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10ba5d:	test   %r15,%r15
  10ba60:	je     10bc40 <fn_4+0x36c0>
  10ba66:	decq   (%r15)
  10ba69:	jne    10bc40 <fn_4+0x36c0>
  10ba6f:	mov    %rsp,%rdi
  10ba72:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10ba78:	jmp    10bc40 <fn_4+0x36c0>
  10ba7d:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10ba83:	decq   (%r12)
  10ba87:	jne    10bc40 <fn_4+0x36c0>
  10ba8d:	mov    %rsp,%rdi
  10ba90:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10ba96:	jmp    10bc40 <fn_4+0x36c0>
  10ba9b:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10baa1:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10baa7:	decq   (%rbx)
  10baaa:	jne    10bc40 <fn_4+0x36c0>
  10bab0:	mov    %rsp,%rdi
  10bab3:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10bab9:	jmp    10bc40 <fn_4+0x36c0>
  10babe:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10bac4:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10baca:	mov    %rbx,%rdi
  10bacd:	call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12relar_runtime7objects7StorageEBF_.llvm.7526630615700072279>
  10bad2:	jmp    10bc40 <fn_4+0x36c0>
  10bad7:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10badd:	mov    %r12,%rax
  10bae0:	shr    $0x38,%rax
  10bae4:	cmp    $0xd8,%eax
  10bae9:	jne    10bc40 <fn_4+0x36c0>
  10baef:	movabs $0xffffffffffffff,%rax
  10baf9:	and    %rax,%r12
  10bafc:	mov    $0x1,%edx
  10bb01:	mov    %rbp,%rdi
  10bb04:	mov    %r12,%rsi
  10bb07:	call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  10bb0c:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bb12:	decq   (%rbx)
  10bb15:	jne    10bc40 <fn_4+0x36c0>
  10bb1b:	mov    %rsp,%rdi
  10bb1e:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10bb24:	jmp    10bc40 <fn_4+0x36c0>
  10bb29:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10bb2f:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bb35:	mov    %r15,%rax
  10bb38:	shr    $0x38,%rax
  10bb3c:	cmp    $0xd8,%eax
  10bb41:	jne    10bc40 <fn_4+0x36c0>
  10bb47:	movabs $0xffffffffffffff,%rax
  10bb51:	and    %rax,%r15
  10bb54:	mov    $0x1,%edx
  10bb59:	mov    %rbp,%rdi
  10bb5c:	mov    %r15,%rsi
  10bb5f:	call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  10bb64:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bb6a:	decq   (%r14)
  10bb6d:	jne    10bc40 <fn_4+0x36c0>
  10bb73:	mov    %rsp,%rdi
  10bb76:	addr32 call 133f00 <_RNvMs6_NtCscJq9HK9IcCJ_5alloc2rcINtB5_2RcNtNtCs3V9firECmdE_12relar_runtime7objects6ObjectE9drop_slowBH_>
  10bb7c:	jmp    10bc40 <fn_4+0x36c0>
  10bb81:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10bb87:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bb8d:	mov    %rbx,%rdi
  10bb90:	call   12ce00 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueNtNtCs3V9firECmdE_12relar_runtime7objects7StorageEBF_.llvm.7526630615700072279>
  10bb95:	jmp    10bc40 <fn_4+0x36c0>
  10bb9a:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10bba0:	mov    %r14,%rax
  10bba3:	shr    $0x38,%rax
  10bba7:	cmp    $0xd8,%eax
  10bbac:	jne    10bc40 <fn_4+0x36c0>
  10bbb2:	movabs $0xffffffffffffff,%rax
  10bbbc:	and    %rax,%r14
  10bbbf:	mov    $0x1,%edx
  10bbc4:	mov    %r12,%rdi
  10bbc7:	mov    %r14,%rsi
  10bbca:	call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  10bbcf:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bbd5:	mov    %rsp,%rdi
  10bbd8:	call   10cc70 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCscJq9HK9IcCJ_5alloc2rc7RcInnerNtCs3V9firECmdE_12relar_runtime4ListEEB1d_.llvm.14548151582184166452>
  10bbdd:	jmp    10bc40 <fn_4+0x36c0>
  10bbdf:	addr32 call eca3e <_RNvNtCs6SLOTazmNXq_4core9panicking16panic_in_cleanup>
  10bbe5:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bbeb:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bbf1:	mov    %r15,%rax
  10bbf4:	shr    $0x38,%rax
  10bbf8:	cmp    $0xd8,%eax
  10bbfd:	jne    10bc40 <fn_4+0x36c0>
  10bbff:	movabs $0xffffffffffffff,%rax
  10bc09:	and    %rax,%r15
  10bc0c:	mov    $0x1,%edx
  10bc11:	mov    %r13,%rdi
  10bc14:	mov    %r15,%rsi
  10bc17:	call   77530 <_RNvCsdDBZ5SCsGGz_7___rustc13___rdl_dealloc>
  10bc1c:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bc22:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bc28:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bc2e:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bc34:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bc3a:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>
  10bc40:	addr32 call ecbb3 <_RNvNtCs6SLOTazmNXq_4core9panicking19panic_cannot_unwind>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
