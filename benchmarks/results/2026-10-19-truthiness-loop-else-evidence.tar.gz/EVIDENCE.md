# Truthiness and loop-else evidence

Measurements use clean source commit 5b3e8438376091340f6610d7e603b9808d7ed65c. `source/` is that Git tree,
excluding historical benchmark results. `retained/` holds all four current raw
families, exact old/new application sources, captured baseline workload cases,
generated LLVM, build records, test snapshots, validation logs and receipts,
the stale optional-guard rejection and corrected matching run, the test-only
restack proof, and launch/audit/publication scripts.

The application family combines source and compiler/runtime changes. The
common-source family holds the old application source fixed. Each family is a
separate sequential measurement batch, so cross-family source-effect ratios
are not paired causal estimates. Each run retains all six workloads, 48 sample
rounds, two warmups, and four engines in balanced permutation order.

The portable audit checks every retained byte and recomputes saved statistics,
orders, output/filesystem oracles, and validation joins. It needs Python and
these text/source records; it does not execute native artifacts. Executables,
runtime archives, caches, toolchains, and historical raw result archives are
excluded. Their original paths/hashes and baseline publication references are
recorded. Captured baseline cases preserve the comparison's workload contract.

All 1,654 semantic checks, 86 Rust tests, and 205 inventory ASan outcomes are
reported separately. The test-only restack changed two Python test files; all
compiled inputs and all four artifacts remained identical. ASan covers emitted
application LLVM and the custom runtime, with leaks enabled outside ptrace;
the prebuilt Rust standard library was not rebuilt with ASan.
