import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
mode = "normal"
config = json.loads((root / "config-v2.json").read_text())
source = Path(config["source"])
output = root / "matching-v2"
output.mkdir(exist_ok=True)
all_suites = sorted(path.stem for path in (source / "tests").glob("*.py") if path.name != "lto.py")
assert len(all_suites) == 17, all_suites
suites = ["matching"]
levels = ["3"] if mode == "thin-lto" else ["0", "1"] if mode == "asan" else ["0", "3"]
runtime = config[mode + "_runtime"]
tool_paths = [config["compiler"], runtime, config["python"], config["clang"]]
if mode == "thin-lto":
    tool_paths.append(config["linker"])
inputs = sorted(path for path in source.rglob("*") if path.is_file())
inputs += [Path(path) for path in tool_paths]
inputs += [Path(__file__), root / "config-v2.json"]
def hashes():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
def now():
    return datetime.datetime.now(datetime.UTC).isoformat()
def write_json(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)
tracer_pid = next(line.split(":", 1)[1].strip() for line in Path("/proc/self/status").read_text().splitlines() if line.startswith("TracerPid:"))
if mode == "asan":
    assert tracer_pid == "0", "LeakSanitizer must execute outside ptrace"
before = hashes()
manifest = {"source_commit": config["commit"], "mode": mode, "opt_levels": levels, "suites": suites, "inputs": before, "tracer_pid": tracer_pid, "started": now(), "environment": {"ASAN_OPTIONS": "detect_leaks=1:halt_on_error=1", "LSAN_OPTIONS": "exitcode=23", "PYTHONDONTWRITEBYTECODE": "1"}}
write_json(output / "manifest.json", manifest)
manifest_hash = hashlib.sha256((output / "manifest.json").read_bytes()).hexdigest()
results = []
for suite in suites:
    command = [config["python"], "-I", "-B", str(source / "tests" / (suite + ".py")), "--compiler", config["compiler"], "--runtime", runtime, "--python", config["python"], "--clang", config["clang"], "--target", config["target"], "--opt-levels", *levels]
    if mode == "thin-lto":
        command += ["--lto-linker", config["linker"]]
    elif mode == "asan":
        command += ["--sanitize"]
    print(f"[{mode}] Starting {suite}", flush=True)
    started = now()
    result = subprocess.run(command, cwd=source, capture_output=True, text=True, env={**os.environ, **manifest["environment"]})
    checks = re.search(r"Passed (\d+) ", result.stdout)
    receipt = {"suite": suite, "mode": mode, "source_commit": config["commit"], "command": command, "cwd": str(source), "manifest_sha256": manifest_hash, "started": started, "finished": now(), "returncode": result.returncode, "checks": int(checks.group(1)) if checks else None, "stdout": result.stdout, "stderr": result.stderr}
    write_json(output / (suite + ".json"), receipt)
    (output / (suite + ".stdout.log")).write_text(result.stdout)
    (output / (suite + ".stderr.log")).write_text(result.stderr)
    results.append({"suite": suite, "returncode": result.returncode, "checks": receipt["checks"]})
    write_json(output / "progress.json", {"mode": mode, "completed": results, "remaining": suites[len(results):]})
    print(f"[{mode}] {suite}: returncode={result.returncode}", flush=True)
    print(result.stdout, end="", flush=True)
    if result.stderr:
        print(result.stderr, end="", flush=True)
after = hashes()
summary = {"mode": mode, "source_commit": config["commit"], "manifest_sha256": manifest_hash, "started": manifest["started"], "finished": now(), "results": results, "total_checks": sum(result["checks"] or 0 for result in results), "inputs_unchanged": before == after, "inputs_after": after, "success": before == after and all(result["returncode"] == 0 for result in results)}
write_json(output / "summary.json", summary)
print(f"[{mode}] {len(results)} suites completed; {summary['total_checks']} checks; success={summary['success']}", flush=True)
raise SystemExit(0 if summary["success"] else 1)
