def bad(flag: bool | None) -> None:
    match 1:
        case _ if flag:
            pass
