import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent
config = json.loads((root / 'config-v2.json').read_text())
old_record = json.loads((root / 'build-record-v1.json').read_text())
new_record = json.loads((root / 'build-record-v2.json').read_text())
assert new_record['git_head'] == config['commit']
assert old_record['source_sha256'] == new_record['source_sha256']
def artifact_hashes(record):
    return {Path(path).name: digest for path, digest in record['sha256'].items()}
assert artifact_hashes(old_record) == artifact_hashes(new_record)
assert len(artifact_hashes(new_record)) == 4
changes = json.loads((root / 'test-input-changes-v2.json').read_text())
assert set(changes) == {'tests/matching.py', 'tests/fixtures/matching/optional_guards.py'}
def read(path):
    return json.loads(path.read_text())
def count(stdout):
    match = re.search(r'^Passed (\d+) ', stdout, re.MULTILINE)
    if match is None:
        match = re.search(r'^(\d+) .* checks passed\b', stdout, re.MULTILINE)
    assert match is not None, stdout
    return int(match.group(1))
results = {}
for mode in ('normal', 'thin-lto', 'asan'):
    group = read(root / mode / 'summary.json')
    assert group['inputs_unchanged']
    receipts = []
    for result in group['results']:
        suite = result['suite']
        path = root / mode / (suite + '.json')
        if mode == 'normal' and suite == 'matching':
            assert read(path)['returncode'] != 0
            assert 'guard_optional_bool' in read(path)['stderr']
            path = root / 'matching-v2' / 'matching.json'
            assert read(root / 'matching-v2' / 'summary.json')['inputs_unchanged']
        receipt = read(path)
        assert receipt['returncode'] == 0, receipt
        receipts.append({'suite': suite, 'checks': count(receipt['stdout']), 'receipt': str(path), 'receipt_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'source_commit': receipt['source_commit']})
    results[mode] = {'suites': receipts, 'total_checks': sum(receipt['checks'] for receipt in receipts), 'success': True}
summary = {
    'source_commit': config['commit'],
    'success': True,
    'compiled_sources_identical': True,
    'artifacts_identical': True,
    'artifact_sha256': artifact_hashes(new_record),
    'build_records': {str(root / name): hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ('build-record-v1.json', 'build-record-v2.json')},
    'test_input_changes': changes,
    'groups': results,
    'count_parser': 'Supports both Passed N ... and N ... checks passed summary formats, including imports.',
    'preserved_failure': str(root / 'normal' / 'matching.json'),
    'replacement_receipt': str(root / 'matching-v2' / 'matching.json'),
    'reuse_basis': 'The corrected snapshot changes only matching.py and its new optional-guard fixture. Every compiled source and all four frozen artifacts are identical. All other frozen test inputs are identical, so their completed checks remain valid.'
}
(root / 'combined-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for mode, result in results.items():
    print(mode, len(result['suites']), 'suites,', result['total_checks'], 'checks passed')
