import json
from pathlib import Path

HERE = Path(__file__).parent
PREFIX = "2026-10-19-truthiness-loop-else"
audit = json.loads(Path("/tmp/imre-control-flow-independent-audit/audit.json").read_text())
assert audit["passed"]
families = audit["families"]


def application_table(mode):
    lines = [
        "| Input | CPython ms | Previous Imre ms | Current Imre ms | Rust BigInt ms | Imre time change |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in families[f"application-{mode}"]["rows"]:
        times = row["median_ms"]
        cells = [row["workload"]]
        cells += [f"{times[engine]:.3f}" for engine in ("cpython", "baseline", "imre", "rust_bigint")]
        cells += [f'{row["new_vs_baseline_time_change_percent"]:+.2f}%']
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def common_table():
    lines = [
        "| Input | Ordinary previous ms | Ordinary current ms | Change | ThinLTO previous ms | ThinLTO current ms | Change |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    ordinary = families["common-source-normal"]["rows"]
    thin_lto = families["common-source-lto"]["rows"]
    for normal, lto in zip(ordinary, thin_lto, strict=True):
        assert normal["workload"] == lto["workload"]
        cells = [normal["workload"]]
        for row in (normal, lto):
            cells += [f'{row["median_ms"][engine]:.3f}' for engine in ("baseline", "imre")]
            cells += [f'{row["new_vs_baseline_time_change_percent"]:+.2f}%']
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


large = families["application-lto"]["rows"][-2:]
assert [row["workload"] for row in large] == ["dense-16384", "sparse-16384"]
dense, sparse = large
common = [row for mode in ("normal", "lto") for row in families[f"common-source-{mode}"]["rows"]]
assert all(row["iqr_overlap_vs_previous"] for row in common)
changes = [row["new_vs_baseline_time_change_percent"] for row in common]

report = f"""# Truthiness, boolean values, and loop else

Imre now supports Python truth tests, operand-returning `and`/`or`, and `for`/`while` `else` suites. The inventory reconciler uses all three capabilities while preserving its input, error, and output behavior. On the two large workloads, ThinLTO Imre runs **{dense['cpython_speedup']:.2f}× faster than CPython for dense input and {sparse['cpython_speedup']:.2f}× for sparse input**, taking **{dense['rust_gap_percent']:.1f}% and {sparse['rust_gap_percent']:.1f}% more time than Rust BigInt**, respectively.

[Truthiness and boolean values](https://github.com/viarius-experiments/imre/pull/42) and [loop else](https://github.com/viarius-experiments/imre/pull/43) continue GitHub Stack 4 after the [floats, bytes, matching, and assignment-expression milestone](2026-10-19-floats-bytes-match-walrus.md). Measurements use clean source commit `5b3e8438376091340f6610d7e603b9808d7ed65c`; the results and README refresh are committed separately.

## Capability and application

- **Truthiness:** conditions, assertions, comprehension filters, match guards, `not`, and `bool(value)` use Python's truth rules for supported concrete types. Numeric zero, `None`, and empty containers are false; NaN is true and both floating-point signed zeros are false. Class instances, exceptions, and file handles are true. `bool()` returns `False`. Scalar tests lower directly to LLVM, and string/bytes truth checks do not scan their contents.
- **Boolean values:** `and` and `or` evaluate left to right, short-circuit, and return the selected operand while preserving shared identity and ownership. Stored results must fit a concrete type or its `T | None` form; truth contexts can directly consume heterogeneous operands. A true optional local narrows to its payload; a false optional value can still be a present zero or empty container. Type annotations remain enforced.
- **Loop else:** exhaustion, including zero iterations, runs the `else` suite. `break`, `return`, and escaping exceptions skip it. Nested loops, `continue`, `finally`, definite assignment, optional narrowing, and compiler-owned iterator cleanup preserve the corresponding Python behavior.

The inventory parser uses `not token` and a digit-scanning `for ... else`; the stock reader uses a countdown `while ... else`. Reconciliation uses one dictionary `get` and an operand-returning `and`/`or` expression for the filled quantity, retaining an explicit `is not None` check when missing and zero stock must differ. The [language contract](../../docs/subset.md) documents the exact boundaries, including unsupported general unions and user-defined `__bool__`/`__len__` protocols.

## Updated-application comparisons

CPython and current Imre run the updated application. Preserved Imre runs the previous application because the previous compiler cannot accept the new syntax. Rust uses its unchanged source and executables. These comparisons therefore include both compiler/runtime changes and the application rewrite. Times are median milliseconds; positive change means more time than preserved Imre.

**Ordinary linking**

{application_table('normal')}

**ThinLTO**

{application_table('lto')}

For 16,384 positive requests, ordinary Imre takes 2.5–4.7% less time than preserved Imre and runs 2.25–2.95× faster than CPython. ThinLTO takes 1.4–1.9% less time than preserved Imre and narrows the Rust gap to 4.1–8.7%. These are descriptive changes in this session, not a general compiler speedup claim. Small cases include substantial process-startup and small-file overhead. No new CPU or allocation profiles were collected.

## Unchanged-application controls

Both current and preserved Imre also run the exact previous application, holding all six Python files fixed. CPython and Rust participate in the same balanced rounds. This isolates the compiler/runtime comparison from adopting the new syntax.

{common_table()}

Across these twelve comparisons, median changes range from **{min(changes):+.2f}% to {max(changes):+.2f}%**, and every current/preserved Imre interquartile range overlaps. This provides no clear compiler-only regression signal. Interquartile ranges describe sample spread, not confidence intervals or proof of equivalent performance. The application and unchanged-source families ran sequentially; subtracting their changes would not establish a causal source-only effect. The [summary]({PREFIX}-summary.json) retains all four engines' statistics in every family.

## Method and provenance

The session ran on October 19, 2026, from 11:25:19 to 11:28:41 UTC. Each of four families uses six workloads, 48 measured rounds covering all 24 engine permutations twice, and two warmup rounds. Measured execution positions and directed within-round predecessors are balanced; warmups, cross-round predecessors, and workload order are not. Records retain **4,608 measured executions, 192 warmups, and 96 workload gates**.

Before timing, every family checks the independent 204-case oracle and `/dev/full` on all four engines: **3,264 oracle outcomes and 16 device-error outcomes**. Every timed run and warmup checks exit status, stdout/stderr, complete report bytes, and filesystem effects. The launcher verifies clean source, frozen tools, preserved references, and unchanged CPython bytecode caches before and after the session.

Fresh processes run on CPU 0 outside ptrace. Timing includes startup/imports, reading/decoding/parsing, reconciliation, rendering, buffered writes, flush/close, and exit. Builds, fixture preparation, oracles, hashing, verification, and deletion stay outside the clock. OS caches are warm; writes are not fsynced. Task-owned builds, tests, and profiling stop during measurements; CPU frequency and unrelated activity on the shared host remain uncontrolled.

The host is x86-64 AMD EPYC-Milan. CPython 3.14.5 is a GIL build with its experimental JIT disabled and PGO/LTO enabled. Imre uses Clang 18.1.3 at `-O3`, with LLD 22.1.8 for cross-language ThinLTO and matched LLVM optimization budgets. Rust preserves the eager algorithm and arbitrary-precision quantities while using native containers, borrowed strings, and direct formatting. These results apply to this complete inventory program and recorded environment.

## Validation and evidence

All **1,654 semantic/regression checks** pass: **1,202 ordinary-linking checks** across all 17 suites, **187 targeted ThinLTO checks**, and **265 targeted ASan/LSan checks**. Counts include compile-time rejections. Targeted suites cover truthiness, loop else, assignment expressions, exceptions, and files; ordinary checks also cover existing imports, classes, containers, comprehensions, calls, formatting, matching, scalar types, and sequence access. The compiled source passes **86 Rust unit tests**, Clippy with warnings denied, formatting, and focused Ruff checks.

The updated inventory application separately passes **204 oracle cases and `/dev/full`** under O1 ASan/LSan outside ptrace, with leak detection enabled. Sanitizers instrument generated code and runtime dependencies; the prebuilt Rust standard library remains uninstrumented.

One old matching rejection still expected optional-bool guards to fail. It was replaced with a positive regression and the matching suite was rerun successfully. The original failure and retry are retained. Rebuilding after this test-only restack produced byte-identical compiler and ordinary/ThinLTO/ASan runtime artifacts; all 35 compiled source inputs match the earlier validation build. The final [build record]({PREFIX}-build.json), [validation index]({PREFIX}-validation.json), and archived restack proof connect both runs to the measured source.

The [independent audit]({PREFIX}-audit.json) passed **358,308 checks** of raw integer-nanosecond samples, exact quantiles, execution order, outcomes, source-family separation, and provenance. The [session record]({PREFIX}-session.json) retains commands and actual timestamps. Compressed original records are available for [application/ordinary]({PREFIX}-application-normal.json.gz), [application/ThinLTO]({PREFIX}-application-lto.json.gz), [unchanged-source/ordinary]({PREFIX}-common-source-normal.json.gz), and [unchanged-source/ThinLTO]({PREFIX}-common-source-lto.json.gz).

The [evidence archive]({PREFIX}-evidence.tar.gz) and [manifest]({PREFIX}-evidence-manifest.json) retain source, generated LLVM, validation logs, raw records, and reproduction/audit scripts. Native executables, runtime archives, interpreters, toolchains, and bytecode caches are excluded. A portable publication audit verifies retained text/source evidence; rerunning the complete live artifact audit requires the original native artifacts identified in the records.
"""
(HERE / "report.md").write_text(report)
