"""Preserve old/new inventory source and verify references without running timings."""

import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/home/dev-user/code/oss/imre")
APPLICATION = Path("/home/dev-user/code/oss/imre-control-flow-inventory")
HERE = Path(__file__).resolve().parent
BASE = "1a177d422d15ca73f525a6229c1c832dfb5c2e88"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(checkout, *arguments):
    return subprocess.check_output(["git", "-C", str(checkout), *arguments])


def snapshot(checkout, commit, destination):
    names = git(checkout, "ls-tree", "-r", "--name-only", commit,
                "examples/inventory_reconciliation").decode().splitlines()
    result = {}
    for name in names:
        if not name.endswith(".py"):
            continue
        relative = name.removeprefix("examples/")
        data = git(checkout, "show", commit + ":" + name)
        output = destination / relative
        if output.exists():
            if output.read_bytes() != data:
                raise RuntimeError("existing source snapshot changed: " + str(output))
        else:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(data)
            output.chmod(0o444)
        result[relative] = hashlib.sha256(data).hexdigest()
    return {"commit": commit, "root": str(destination), "sources": result}


def main():
    current = git(APPLICATION, "rev-parse", "HEAD").decode().strip()
    if git(APPLICATION, "status", "--porcelain"):
        raise RuntimeError("application snapshot requires clean committed source")
    baseline = snapshot(ROOT, BASE, HERE / "baseline-source")
    application = snapshot(APPLICATION, current, HERE / ("application-source-" + current[:12]))
    prepared = {
        "schema_version": 1,
        "prepared_at_utc": datetime.now(timezone.utc).isoformat(),
        "baseline_source": baseline,
        "application_source": application,
        "changed_application_sources": {
            name: {"baseline_sha256": baseline["sources"].get(name),
                   "application_sha256": application["sources"].get(name)}
            for name in sorted(baseline["sources"].keys() | application["sources"].keys())
            if baseline["sources"].get(name) != application["sources"].get(name)
        },
        "modes": {},
    }
    for mode in ("normal", "lto"):
        comparison = ROOT / "benchmarks/local/four-feature-inventory-regression" / (mode + ".json")
        published = ROOT / "benchmarks/results" / ("2026-10-19-floats-bytes-match-walrus-" + mode + ".json.gz")
        if gzip.decompress(published.read_bytes()) != comparison.read_bytes():
            raise RuntimeError("published baseline does not match local raw record")
        data = json.loads(comparison.read_text())
        if data["sources"] != baseline["sources"]:
            raise RuntimeError("baseline source differs from recorded application")
        command = data["method"]["compile_commands"]["inventory"]
        paths = {
            "inventory_binary": data["method"]["commands"]["inventory"]["imre"][0],
            "inventory_ir": command[command.index("--emit-llvm") + 1],
            "rust_bigint": data["method"]["commands"]["inventory"]["rust_bigint"][0],
            "python": data["method"]["commands"]["inventory"]["cpython"][0],
            "compiler": command[0],
            "runtime": command[command.index("--runtime") + 1],
            "clang": command[command.index("--clang") + 1],
        }
        if mode == "lto":
            paths["lto_linker"] = command[command.index("--lto-linker") + 1]
        hashes = {name: sha(path) for name, path in paths.items()}
        if any(hashes[name] != data["sha256"][name] for name in hashes):
            raise RuntimeError("baseline artifact no longer matches its record")
        rust_record = Path(paths["rust_bigint"]).parent / "build-record.json"
        rust = json.loads(rust_record.read_text())
        if rust != data["rust_build_record"] or sha(rust_record) != data["sha256"]["rust_record"]:
            raise RuntimeError("Rust build record no longer matches baseline")
        for name, expected in rust["sources"].items():
            if sha(APPLICATION / "benchmarks/reference/inventory_reconciliation" / name) != expected:
                raise RuntimeError("Rust source changed: " + name)
        prepared["modes"][mode] = {
            "comparison": str(comparison), "comparison_sha256": sha(comparison),
            "published": str(published), "published_sha256": sha(published),
            "compiler_source_commit": data["git"]["revision"],
            "paths": paths, "sha256": hashes,
            "rust_build_record": str(rust_record), "rust_build_record_sha256": sha(rust_record),
            "rust_sources": rust["sources"],
            "options": data["options"],
            "case_sha256": {
                item["label"]: hashlib.sha256(json.dumps(item["case"], sort_keys=True).encode()).hexdigest()
                for item in data["workloads"]["inventory"]
            },
        }
    tools = ROOT / "benchmarks/local/four-feature-tools-final"
    prepared["preserved_tools"] = {
        str(path): sha(path) for path in sorted(tools.iterdir()) if path.is_file()
    }
    manifest = HERE / "prepared-manifest.json"
    manifest.write_text(json.dumps(prepared, indent=2) + "\n")
    print(json.dumps({"manifest": str(manifest), "sha256": sha(manifest),
                      "baseline": BASE, "application": current,
                      "changed_sources": list(prepared["changed_application_sources"])}))


if __name__ == "__main__":
    main()
