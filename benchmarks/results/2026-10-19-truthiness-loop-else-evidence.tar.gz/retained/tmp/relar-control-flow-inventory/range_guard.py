def selected(values: list[int], index: int) -> bool:
    return (0 <= index and index < 4) and values[index] == 7


values = [7, 3, 7, 1]
for index in range(-2, 6):
    print(selected(values, index))
