def inside(values: list[int], index: int) -> bool:
    return (0 <= index and index < 4) and values[index] == 7


def outside(values: list[int], index: int) -> bool:
    return (index < 0 or index >= 4) or values[index] == 7


values = [7, 3, 7, 1]
for index in range(-2, 6):
    print(inside(values, index))
    print(outside(values, index))
