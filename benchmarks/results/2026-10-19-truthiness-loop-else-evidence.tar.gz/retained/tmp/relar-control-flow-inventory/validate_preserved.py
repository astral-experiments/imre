"""Check both application snapshots and preserved native references against the oracle."""

import hashlib
import json
import runpy
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/home/dev-user/code/oss/relar-control-flow-inventory")


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    manifest_path = HERE / "prepared-manifest.json"
    prepared = json.loads(manifest_path.read_text())
    validator = runpy.run_path(str(ROOT / "benchmarks/inventory_validate.py"))
    python = prepared["modes"]["normal"]["paths"]["python"]
    commands = {
        "cpython_" + label: [python, "-I", "-c", validator["BOOTSTRAP"],
                             prepared[kind]["root"]]
        for label, kind in (("old_source", "baseline_source"),
                            ("new_source", "application_source"))
    }
    for mode, item in prepared["modes"].items():
        commands["preserved_relar_" + mode] = [item["paths"]["inventory_binary"]]
        commands["rust_bigint_" + mode] = [item["paths"]["rust_bigint"]]
    inputs = {str(manifest_path): sha(manifest_path), str(Path(__file__)): sha(__file__)}
    for source in sorted((ROOT / "benchmarks").glob("*.py")):
        inputs[str(source)] = sha(source)
    for name, command in commands.items():
        inputs[command[0]] = sha(command[0])
    for kind in ("baseline_source", "application_source"):
        for name, expected in prepared[kind]["sources"].items():
            path = Path(prepared[kind]["root"]) / name
            if sha(path) != expected:
                raise RuntimeError("application snapshot changed")
            inputs[str(path)] = expected
    started = datetime.now(timezone.utc).isoformat()
    validation = validator["validate_commands"](commands)
    if {path: sha(path) for path in inputs} != inputs:
        raise RuntimeError("validation inputs changed")
    result = {"started_at_utc": started,
              "completed_at_utc": datetime.now(timezone.utc).isoformat(),
              "commands": commands, "inputs_sha256": inputs,
              "timing": "Functional validation only; no benchmark samples collected.",
              "validation": validation}
    output = HERE / ("preserved-parity-" + prepared["application_source"]["commit"][:12] + ".json")
    if output.exists():
        raise RuntimeError("validation receipt already exists")
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"path": str(output), "sha256": sha(output),
                      "cases": validation["cases"], "engines": validation["engines"],
                      "outcomes": validation["cases"] * len(commands),
                      "device_outcomes": len(validation["device_check"]["engines"])}))


if __name__ == "__main__":
    main()
