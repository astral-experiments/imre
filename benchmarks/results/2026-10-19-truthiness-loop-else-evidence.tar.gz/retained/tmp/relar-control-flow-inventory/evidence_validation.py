"""Join retained control-flow validation evidence using injected byte readers."""

import hashlib
import json
from pathlib import Path
import re

COMMIT = "5b3e8438376091340f6610d7e603b9808d7ed65c"
PREVIOUS_TEST_COMMIT = "0ee001ac0804cb4abec5f21fa5a5534ba1fb378c"
ROOT = Path("/home/dev-user/code/oss/relar")
TOOLS = ROOT / "benchmarks/local/control-flow-tools-final-v2"
TESTS = Path("/tmp/relar-control-flow-tests/final")
RUST = Path("/tmp/relar-control-flow-rust-validation")
INVENTORY = Path("/tmp/relar-control-flow-inventory-asan")


def info(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def count(log):
    matches = re.findall(r"Passed\s+(\d+)[^\n]*checks|(\d+) import checks passed", log)
    assert matches, log
    return int(next(value for value in matches[-1] if value))


def validate(read_bytes, source_bytes):
    """Recompute validation joins without executing compilers or native artifacts."""
    retained = {}

    def read(path, expected=None):
        path = str(path)
        data = read_bytes(path)
        actual = info(data)
        assert expected is None or actual["sha256"] == expected, path
        retained[path] = actual
        return data

    def load(path, expected=None):
        return json.loads(read(path, expected))

    build = load(TOOLS / "build-record.json")
    joined = load(TESTS / "combined-summary.json")
    assert build["git_head"] == joined["source_commit"] == COMMIT
    assert build["compiled_sources_match_commit"] and not build["git_status"]
    assert (
        joined["success"]
        and joined["compiled_sources_identical"]
        and joined["artifacts_identical"]
    )
    artifacts = {name: item["sha256"] for name, item in build["artifacts"].items()}
    assert joined["artifact_sha256"] == artifacts
    for path, expected in joined["build_records"].items():
        record = load(path, expected)
        assert record["source_sha256"] == build["source_sha256"]
        assert record["source_contents"] == build["source_contents"]
        assert {
            Path(name).name: value for name, value in record["sha256"].items()
        } == artifacts
    for name, expected in build["source_sha256"].items():
        assert info(source_bytes(name))["sha256"] == expected
        assert build["source_contents"][name].encode() == source_bytes(name)

    proof = load(TESTS / "test-only-restack.json")
    assert proof["old_source_commit"] == PREVIOUS_TEST_COMMIT
    assert proof["new_source_commit"] == COMMIT
    assert proof["compiled_sources_identical"] and proof["artifacts_identical"]
    assert proof["artifact_sha256"] == artifacts
    changes = joined["test_input_changes"]
    assert set(changes) == {
        "tests/matching.py",
        "tests/fixtures/matching/optional_guards.py",
    }
    for name, values in changes.items():
        assert info(source_bytes(name))["sha256"] == values["after"]

    totals = {}
    expected_suites = {"normal": 17, "thin-lto": 5, "asan": 5}
    for mode, group in joined["groups"].items():
        assert group["success"] and len(group["suites"]) == expected_suites[mode]
        totals[mode] = 0
        for suite in group["suites"]:
            path = Path(suite["receipt"])
            receipt = load(path, suite["receipt_sha256"])
            assert receipt["returncode"] == 0 and receipt["mode"] == mode
            assert receipt["source_commit"] == suite["source_commit"]
            assert receipt["source_commit"] in (COMMIT, PREVIOUS_TEST_COMMIT)
            assert count(receipt["stdout"]) == suite["checks"]
            assert read(path.with_suffix(".stdout.log")).decode() == receipt["stdout"]
            assert (
                read(path.with_suffix(".stderr.log")).decode()
                == receipt["stderr"]
                == ""
            )
            manifest = load(path.parent / "manifest.json", receipt["manifest_sha256"])
            summary = load(path.parent / "summary.json")
            assert summary["inputs_unchanged"]
            assert summary["inputs_after"] == manifest["inputs"]
            assert manifest["source_commit"] == receipt["source_commit"]
            if mode == "asan":
                assert manifest["tracer_pid"] == "0"
                assert (
                    manifest["environment"]["ASAN_OPTIONS"]
                    == "detect_leaks=1:halt_on_error=1"
                )
                assert manifest["environment"]["LSAN_OPTIONS"] == "exitcode=23"
                assert "--sanitize" in receipt["command"]
            runtime = {
                "normal": "librelar_runtime.a",
                "thin-lto": "librelar_runtime_lto.a",
                "asan": "librelar_runtime_asan.a",
            }[mode]
            for flag, name in (("--compiler", "relar"), ("--runtime", runtime)):
                artifact = receipt["command"][receipt["command"].index(flag) + 1]
                assert manifest["inputs"][artifact] == artifacts[name]
            for name, expected in manifest["inputs"].items():
                value = Path(name)
                if not value.is_relative_to(TESTS):
                    continue  # External binary identities are joined through provenance, not archived.
                read(value, expected)
                for snapshot in (TESTS / "source", TESTS / "source-v2"):
                    if value.is_relative_to(snapshot):
                        relative = str(value.relative_to(snapshot))
                        if snapshot.name == "source" and relative in changes:
                            assert expected == changes[relative]["before"]
                        else:
                            assert expected == info(source_bytes(relative))["sha256"], (
                                relative
                            )
            totals[mode] += suite["checks"]
        assert totals[mode] == group["total_checks"]
    assert totals == {"normal": 1202, "thin-lto": 187, "asan": 265}
    stale = load(joined["preserved_failure"])
    assert stale["returncode"] != 0 and "guard_optional_bool" in stale["stderr"]
    replacement = load(joined["replacement_receipt"])
    assert replacement["returncode"] == 0 and count(replacement["stdout"]) == 73

    rust = load(RUST / "receipt.json")
    assert rust["status"] == "passed" and rust["source_commit"] == PREVIOUS_TEST_COMMIT
    rust_count = 0
    for command in rust["commands"]:
        assert command["status"] == 0
        log = read(command["log"], command["log_sha256"]).decode()
        rust_count += sum(
            map(int, re.findall(r"test result: ok\. (\d+) passed; 0 failed;", log))
        )
    assert rust_count == 86

    inventory = load(INVENTORY / "receipt.json")
    assert inventory["source_commit"] == inventory["git_head_after"] == COMMIT
    assert not inventory["git_status_before"] and not inventory["git_status_after"]
    assert inventory["input_hashes_unchanged"] and inventory["compile_returncode"] == 0
    assert inventory["cases"] == 204 and inventory["device_checks"] == 1
    assert inventory["total_native_executions"] == 205
    assert inventory["compiler_sha256"] == artifacts["relar"]
    assert inventory["runtime_asan_sha256"] == artifacts["librelar_runtime_asan.a"]
    assert inventory["runtime_asan_rustflags"] == build["runtime_asan_rustflags"]
    for when in ("before", "after"):
        execution = inventory["execution_" + when]
        assert (
            execution["tracer_pid"] == 0
            and "detect_leaks=1" in execution["asan_options"]
        )
        assert "exitcode=23" in execution["lsan_options"]
    for name, item in inventory["artifacts"].items():
        if name != "binary":
            read(item["path"], item["sha256"])
    for name, item in load(INVENTORY / "source-manifest.json").items():
        read(item["snapshot"], item["sha256"])
        assert info(source_bytes(name))["sha256"] == item["sha256"]

    return {
        "schema": "relar-control-flow-validation-v1",
        "status": "passed",
        "source_commit": COMMIT,
        "build_record_sha256": info(read(TOOLS / "build-record.json"))["sha256"],
        "native_checks": totals,
        "total_native_semantic_checks": sum(totals.values()),
        "rust_unit_tests": rust_count,
        "inventory_asan": {
            "cases": 204,
            "device_checks": 1,
            "native_executions": 205,
            "receipt": str(INVENTORY / "receipt.json"),
        },
        "combined_receipt": str(TESTS / "combined-summary.json"),
        "test_only_restack_proof": str(TESTS / "test-only-restack.json"),
        "retained_stale_rejection": joined["preserved_failure"],
        "corrected_matching_receipt": joined["replacement_receipt"],
        "retained_evidence_files": retained,
        "reconciliation": "The test-only restack changed the optional Boolean match-guard rejection and added its positive fixture. All compiled sources and all four frozen artifacts are identical; the other test inputs are unchanged. The stale failure and corrected 73-check run are retained.",
        "sanitizer_limit": "Application LLVM and the custom runtime were instrumented; leak checking was enabled outside ptrace. The prebuilt Rust standard library was not rebuilt with sanitizer instrumentation.",
        "scope": "Semantic checks include accepted programs, expected errors, and compile-time rejections; Rust unit tests and the 205 inventory ASan outcomes are reported separately. Native artifact bytes are external to the text/source archive; their identities are joined from recorded hashes.",
    }
