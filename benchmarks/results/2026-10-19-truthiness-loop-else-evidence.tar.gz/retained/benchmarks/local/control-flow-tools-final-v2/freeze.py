"""Build and freeze the control-flow milestone from one clean source commit."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/home/dev-user/code/oss/imre')
WRAPPER = Path('/tmp/imre-cargo.sh')
TARGET = Path('/home/dev-user/.cache/imre/target')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sources(head):
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert not git('status', '--porcelain')
    names = git('ls-files', '-z', '--', 'Cargo.toml', 'Cargo.lock',
                'rust-toolchain.toml', '.cargo', 'crates').decode().split('\0')
    result = {name: sha(ROOT / name) for name in names if name}
    for name, expected in result.items():
        assert hashlib.sha256(git('show', head + ':' + name)).hexdigest() == expected, name
    return result


def now():
    return datetime.now(timezone.utc).isoformat()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expected-head', required=True)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
dest = args.output.resolve()
before = sources(args.expected_head)
dest.mkdir(parents=True, exist_ok=False)
record = {'stage': 'control-flow-tools-final', 'started_at_utc': now(),
          'git_head': args.expected_head, 'git_status': '',
          'compiled_sources_match_commit': True, 'source_sha256': before,
          'source_contents': {name: (ROOT / name).read_text() for name in before},
          'commands': {}, 'artifacts': {}, 'sha256': {}}
environment = dict(os.environ)
for key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_BOOTSTRAP'):
    environment.pop(key, None)
environment['CARGO_BUILD_JOBS'] = '4'
settings = [
    ('ordinary', 'imre-integrated', ['--workspace'], {},
     [('imre', TARGET / 'imre-integrated/imre'),
      ('libimre_runtime.a', TARGET / 'imre-integrated/libimre_runtime.a')]),
    ('thinlto', 'imre-truthiness-lto', ['-p', 'imre-runtime'],
     {'RUSTFLAGS': '-Clinker-plugin-lto'},
     [('libimre_runtime_lto.a', TARGET / 'imre-truthiness-lto/libimre_runtime.a')]),
    ('asan', 'imre-truthiness-asan', ['-p', 'imre-runtime', '--target',
                                   'x86_64-unknown-linux-gnu'],
     {'RUSTC_BOOTSTRAP': '1', 'RUSTFLAGS': '-Zsanitizer=address -Cforce-frame-pointers=yes'},
     [('libimre_runtime_asan.a', TARGET / 'x86_64-unknown-linux-gnu/imre-truthiness-asan/libimre_runtime.a')]),
]
for mode, profile, selection, extra_env, artifacts in settings:
    command = ['sh', str(WRAPPER), '--config', f'profile.{profile}.inherits="release"',
               'build', *selection, '--profile', profile, '--locked']
    item = {'command': command, 'profile': profile, 'started_at_utc': now(),
            'environment': {'CARGO_BUILD_JOBS': '4', **extra_env}}
    log = dest / (mode + '.log')
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=ROOT, env={**environment, **extra_env},
                                stdout=stream, stderr=subprocess.STDOUT, check=False)
    item.update(returncode=result.returncode, completed_at_utc=now(),
                log_path=str(log), log_sha256=sha(log))
    record['commands'][mode] = item
    print(mode + ': ' + log.read_text().strip(), flush=True)
    assert result.returncode == 0, mode
    assert sources(args.expected_head) == before
    for name, original in artifacts:
        expected = sha(original)
        target = dest / name
        shutil.copy2(original, target)
        assert target.is_file() and not target.is_symlink() and target.stat().st_nlink == 1
        assert sha(target) == sha(original) == expected
        target.chmod(0o555 if name == 'imre' else 0o444)
        record['artifacts'][name] = {'path': str(target), 'source_path': str(original),
                                     'sha256': expected}
        record['sha256'][str(target.relative_to(ROOT))] = expected
record.update(
    completed_at_utc=now(),
    rustc_verbose=subprocess.check_output(['rustc', '+ohm', '-vV'], text=True),
    cargo_version=subprocess.check_output(['cargo', '+ohm', '-Zohm-defaults=no', '--version'], text=True).strip(),
    cargo_wrapper={'path': str(WRAPPER), 'sha256': sha(WRAPPER), 'source': WRAPPER.read_text()},
    runtime_lto_rustflags='-Clinker-plugin-lto',
    runtime_asan_rustflags='-Zsanitizer=address -Cforce-frame-pointers=yes',
    build_environment={'CARGO_HOME': '/home/dev-user/.cache/imre/cargo-home',
                       'CARGO_TARGET_DIR': str(TARGET),
                       'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/shared-build',
                       'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST': 'all',
                       'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST': 'all',
                       'ohm_automatic_defaults': 'disabled with -Zohm-defaults=no'},
    source_proof={'before_and_after_each_build_match_clean_commit': True,
                  'independent_regular_artifact_copies': True},
    build_script=Path(__file__).read_text(), build_script_sha256=sha(__file__),
)
assert sources(args.expected_head) == before
for name, item in record['artifacts'].items():
    assert sha(dest / name) == item['sha256']
shutil.copy2(__file__, dest / 'freeze.py')
output = dest / 'build-record.json'
output.write_text(json.dumps(record, indent=2) + '\n')
print('Build record: ' + str(output))
print('SHA256: ' + sha(output))
