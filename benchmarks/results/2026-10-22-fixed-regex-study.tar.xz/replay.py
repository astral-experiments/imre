"""Check every indexed file and reconstruct both timing matrices and report/capture oracles."""
import hashlib,json,subprocess,sys
from pathlib import Path
if sys.flags.optimize:raise RuntimeError("portable audit requires assertions")
r=Path(__file__).resolve().parent;idx=json.loads((r/'manifest.json').read_bytes());hashfn=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert set(idx['files'])=={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and p!=r/'manifest.json' and '__pycache__' not in p.parts}
for name,i in idx['files'].items():
 p=r/name;assert p.is_file() and p.stat().st_size==i['bytes'] and hashfn(p)==i['sha256'],name
oracle=r/'sources/after';rows={}
for mode in ('normal','thinlto'):
 raw=r/mode/'results.json';a=json.loads(subprocess.check_output([sys.executable,'-B',str(oracle/'benchmarks/conformance_regex_audit.py'),str(raw),'--source-root',str(oracle),'--retained',str(r/'inputs')],cwd=r))
 strict=json.loads((r/mode/'audit-strict.json').read_bytes());assert strict['matrix_sha256']==a['matrix_sha256'] and strict['strict_files_checked']>0 and {k:v for k,v in strict.items() if k!='strict_files_checked'}=={k:v for k,v in a.items() if k!='strict_files_checked'};rows[mode]=a
for mode,raw in rows.items():assert raw['timed']==1008 and raw['warmups']==84
valid=json.loads((r/'checks/validation.json').read_bytes());assert len(valid['engines'])==11 and valid['seeded_lines']==30000 and len(set(valid['engines'].values()))==1 and hashfn(r/'checks/expected.captures')==valid['expected_sha256'] and hashfn(r/'checks/scanner-lines')==valid['input_sha256']
scans=json.loads((r/'builds/scanner-builds.json').read_bytes())
for mode in rows:
 m=json.loads((r/mode/'results.json').read_bytes())
 for name in ('before','after'):
  s=scans[name+'-'+mode];assert m['config']['engines'][name]['scan']==[s['executable']['path']]
  assert s['parser_revision']==(idx['baseline_revision'] if name=='before' else idx['revision'])
  assert s['llvm']['sha256']==hashfn(r/'builds/ir'/(name+'-'+mode+'.ll'));assert s['driver_revision']==idx['revision'] and s['source_hashes']['conformance_report/benchmark_scanner.py']==hashfn(oracle/'benchmarks/conformance_scanner.py')
 for engine,root in [('before','before-'+mode),('after','after-'+mode),('rust','rust-'+mode),('codon','codon-'+mode)]:
  assert m['config']['build_records'][engine]['sha256']==hashfn(r/'builds'/root/'build-record.json')
for engine in ('before','after','rust'):
 pr=json.loads((r/'profiles'/engine/'provenance.json').read_bytes());sm=json.loads((r/'profiles'/engine/'summary.json').read_bytes())
 assert pr['status']=='passed' and pr['input_guards_passed']
 for x in sm['runs']:
  assert x['returncode']==0 and hashfn(r/'profiles'/engine/(engine+'.'+x['tool']+'.trace'))==x['trace_sha256']

outputs=json.loads((r/'checks/outputs.json').read_bytes());assert outputs['revision']==idx['revision']
for mode,engines in outputs['modes'].items():
 assert mode in rows and set(engines)=={'upstream','cpython','before','after','codon','rust'}
 for engine,artifacts in engines.items():
  assert set(artifacts)=={'corpus.captures','edge.captures','unchanged-github.md','changed-github.md','changed-diff.md'}
  for name,observation in artifacts.items():
   config=json.loads((r/mode/'results.json').read_bytes())['config'];prefix=config['engines'][engine]['report' if name.endswith('.md') else 'scan'];assert observation['command'][:len(prefix)]==prefix
   data=(r/'outputs'/mode/engine/name).read_bytes()
   assert observation['stdout_sha256']==(hashlib.sha256(b'').hexdigest() if name.endswith('.md') else observation['file_sha256']);assert (r/'inputs'/name).read_bytes()==data and observation['file_sha256']==hashlib.sha256(data).hexdigest() and observation['bytes']==len(data)
provenance=json.loads((r/'builds/verified-builds.json').read_bytes());assert provenance['revision']==idx['revision'] and provenance['baseline_revision']==idx['baseline_revision'] and provenance['bundle']['sha256']==hashfn(r/'builds/changes.bundle')
config=json.loads((r/'normal/results.json').read_bytes())['config'];verified=0
for name,item in provenance['guarded'].items():
 for label,checkout in [('before',config['baseline_source_root']),('after',config['source_root'])]:
  src=Path(name);checkout=Path(checkout)
  if src.is_relative_to(checkout):
   retained=r/'sources'/label/src.relative_to(checkout)
   if retained.is_file():
    assert hashfn(retained)==item['sha256'];verified+=1
assert verified>=80
import runpy
records=(r/'checks/scanner-lines').read_text(encoding='utf-8').split('\0')
pattern=runpy.run_path(str(oracle/'benchmarks/conformance_validate.py'))['upstream']().CONFORMANCE_ERROR_PATTERN
observe=runpy.run_path(str(oracle/'benchmarks/conformance_regex_benchmark.py'))['observations']
dump,n,score=observe(records,pattern);assert len(records)==valid['seeded_lines'] and (n,score)==(valid['seeded_matches'],valid['seeded_checksum']) and dump==(r/'checks/expected.captures').read_bytes()
parsers=runpy.run_path(str(r/'sources/after/benchmarks/dependency_profile.py'));profile_totals={}
for engine in ('before','after','rust'):
 profile_totals[engine]={}
 for suffix,rounds in (('',16),('-zero',0)):
  d=r/'profiles'/(engine+suffix);pr=json.loads((d/'provenance.json').read_bytes());sm=json.loads((d/'summary.json').read_bytes())
  assert pr['status']=='passed' and pr['input_guards_passed']
  profile_totals[engine][str(rounds)]={}
  for x in sm['runs']:
   raw=parsers[x['tool']](d/(engine+'.'+x['tool']+'.trace'));assert all(x[k]==v for k,v in raw.items())
   if x['tool']=='callgrind':profile_totals[engine][str(rounds)]['instructions']=raw['total_instructions']
   else:
    for head,key in [('allocated_blocks','tbk'),('allocated_bytes','tb'),('peak_live_bytes','gb')]:profile_totals[engine][str(rounds)][head]=raw['totals'][key]
   assert x['command'][-2:]==[str(rounds),'checksum'] and x['returncode']==0 and hashfn(d/(engine+'.'+x['tool']+'.trace'))==x['trace_sha256'] and hashfn(d/(engine+'.'+x['tool']+'.log'))==x['log_sha256']

print(json.dumps({'revision':idx['revision'],'baseline_revision':idx['baseline_revision'],'indexed_files':len(idx['files']),'timed':sum(v['timed'] for v in rows.values()),'warmups':sum(v['warmups'] for v in rows.values()),'seeded_lines':valid['seeded_lines'],'seeded_comparators':len(valid['engines']),'profile_totals':profile_totals,'all_time_targets_met':all(v['time_target_met'] for v in rows.values()),'modes':rows},indent=2))
