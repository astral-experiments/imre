"""Build the independent conformance report reference and record its sources, tools, and flags."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

if sys.flags.optimize:
    raise SystemExit("build validation requires Python assertions; do not use -O")

HERE = Path(__file__).resolve().parent


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sources() -> dict[str, Path]:
    return {
        os.path.relpath(path, HERE): path
        for path in (
            HERE / "Cargo.toml",
            HERE / "Cargo.lock",
            *sorted((HERE / "src").glob("*.rs")),
            HERE / "../../native_platform/Cargo.toml",
            HERE / "../../native_platform/src/lib.rs",
        )
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--toolchain", help="pinned repository toolchain by default; ohm locally"
    )
    parser.add_argument("--artifact-dir", type=Path, required=True)
    parser.add_argument("--target-dir", type=Path)
    parser.add_argument("--build-cache", type=Path)
    parser.add_argument("--thinlto", action="store_true")
    args = parser.parse_args()
    artifacts = args.artifact_dir.resolve()
    target = (
        args.target_dir
        or Path(os.environ.get("CARGO_TARGET_DIR", artifacts / "target"))
    ).resolve()
    environment = {
        **os.environ,
        "CARGO_TARGET_DIR": str(target),
        "CARGO_PROFILE_RELEASE_OPT_LEVEL": "3",
        "CARGO_PROFILE_RELEASE_LTO": "thin" if args.thinlto else "off",
        "CARGO_PROFILE_RELEASE_CODEGEN_UNITS": "16",
        "RUSTFLAGS": "",
        "CARGO_ENCODED_RUSTFLAGS": "",
    }
    for name in (
        "RUSTC", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER",
        "CARGO_BUILD_RUSTC", "CARGO_BUILD_RUSTC_WRAPPER",
        "CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER", "CARGO_BUILD_TARGET",
    ):
        environment.pop(name, None)
    # Empty values also override wrappers configured outside this workspace.
    environment["RUSTC_WRAPPER"] = ""
    environment["RUSTC_WORKSPACE_WRAPPER"] = ""
    if args.thinlto:
        environment.pop("CARGO_ENCODED_RUSTFLAGS")
        environment["RUSTFLAGS"] = (
            "-Cllvm-args=-import-instr-limit=1000 -Cllvm-args=-inline-threshold=1000"
        )
    if args.build_cache:
        environment["CARGO_BUILD_BUILD_DIR"] = str(args.build_cache.resolve())
    if (cache := environment.get("CARGO_BUILD_BUILD_DIR")) and Path(
        cache
    ).resolve() == target:
        raise ValueError("target directory and shared build cache must differ")
    selected = ["+" + args.toolchain] if args.toolchain else []
    cargo = ["cargo", *selected]
    if args.toolchain == "ohm":
        cargo.append("-Zohm-defaults=no")

    def run(command: list[str]) -> subprocess.CompletedProcess:
        return subprocess.run(
            command,
            cwd=HERE,
            env=environment,
            capture_output=True,
            text=True,
            check=True,
            timeout=1200,
        )

    paths = sources()
    paths["build.py"] = Path(__file__).resolve()
    hashes = {name: digest(path) for name, path in paths.items()}
    contents = {name: path.read_text() for name, path in paths.items()}
    tools = {}
    for name in ("cargo", "rustc"):
        command = ["rustup", "which", name]
        if args.toolchain:
            command += ["--toolchain", args.toolchain]
        tools[name] = Path(run(command).stdout.strip()).resolve(strict=True)
    tool_hashes = {name: digest(path) for name, path in tools.items()}
    environment["RUSTC"] = str(tools["rustc"])
    destination, output = (
        artifacts / "conformance-report-reference",
        artifacts / "build-record.json",
    )
    protected = [*paths.values(), *tools.values()]
    for path in (destination, output):
        if any(
            path.resolve() == item.resolve()
            or (path.exists() and item.exists() and path.samefile(item))
            for item in protected
        ):
            raise ValueError("output would overwrite a source, tool, or other output")
        protected.append(path)
    artifacts.mkdir(parents=True, exist_ok=True)
    rustc = run(["rustc", *selected, "--version", "--verbose"]).stdout
    host = next(line.removeprefix("host: ") for line in rustc.splitlines() if line.startswith("host: "))
    environment["CARGO_BUILD_TARGET"] = host
    cargo_version = run([*cargo, "--version"]).stdout
    run([*cargo, "fmt", "--check"])
    command = [
        *cargo,
        "build",
        "--release",
        "--locked",
        "--offline",
        "--verbose",
        "--message-format=json-render-diagnostics",
        "--target",
        host,
        "--target-dir",
        str(target),
    ]
    # The shared Ohm build directory can outlive a worktree. Force the local
    # reference package to compile and copy the executable named by this build,
    # rather than trusting a conventional target path left by a previous run.
    for path in sorted((HERE / "src").glob("*.rs")):
        path.touch()
    start = time.perf_counter_ns()
    built = run(command)
    build_ns = time.perf_counter_ns() - start
    messages = [json.loads(line) for line in built.stdout.splitlines() if line]
    artifacts_found = [
        message
        for message in messages
        if message.get("reason") == "compiler-artifact"
        and message["target"]["name"] == "conformance-report-reference"
        and message.get("executable")
    ]
    assert len(artifacts_found) == 1 and artifacts_found[0]["fresh"] is False
    native_artifact = artifacts_found[0]
    shutil.copy2(Path(native_artifact["executable"]), destination)
    assert hashes == {name: digest(path) for name, path in paths.items()}
    assert tool_hashes == {name: digest(path) for name, path in tools.items()}
    record = {
        "schema": 1,
        "entrypoint": "conformance_report",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "sources": hashes,
        "source_contents": contents,
        "tool_sha256": tool_hashes,
        "tool_paths": {name: str(path) for name, path in tools.items()},
        "target": host,
        "rustc_verbose": rustc,
        "cargo_version": cargo_version,
        "command": command,
        "environment": {
            **{
                name: value
                for name, value in environment.items()
                if name.startswith("CARGO_PROFILE_RELEASE_")
            },
            **{
                name: environment.get(name)
                for name in (
                    "CARGO_TARGET_DIR",
                    "CARGO_BUILD_BUILD_DIR",
                    "RUSTFLAGS",
                    "CARGO_ENCODED_RUSTFLAGS",
                    "RUSTC",
                    "RUSTC_WRAPPER",
                    "RUSTC_WORKSPACE_WRAPPER",
                    "CARGO_BUILD_TARGET",
                    "CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST",
                    "CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST",
                )
            },
        },
        "thinlto": args.thinlto,
        "llvm_budget": 1000 if args.thinlto else None,
        "build_ns": build_ns,
        "build_stdout": built.stdout,
        "build_stderr": built.stderr,
        "native_artifact": native_artifact,
        "binary_sha256": digest(destination),
        "binary_bytes": destination.stat().st_size,
        "binaries": {
            "reference": {"name": destination.name, "sha256": digest(destination), "bytes": destination.stat().st_size},
        },
        "comparison_domain": (
            "Complete offline typing-conformance report: read UTF-8 source text and two raw GitLab JSON arrays; "
            "scan required, optional, tagged and multi annotations; normalize diagnostics; group/classify; "
            "compute every summary and per-file metric; and render exact github/diff reports. Manifest inputs "
            "supply the same prepared canonical paths for all engines. Position integers retain arbitrary "
            "precision with native i64 storage for ordinary coordinates. The compute mode repeats all report "
            "computation over preloaded raw text with black-boxed inputs/results and a Unicode-length checksum. "
            "Optional compute output publishes the full final report once, or an empty report for zero rounds. "
            "Both success bytes and errors are checked against pinned upstream Ruff code and typed CPython. "
            "Live mode discovers typing cases from TOML, runs both ty children with deadlines, resolves paths, "
            "and atomically publishes the same report. Only native OS/TOML support is shared with Codon's "
            "benchmark platform crate; all report computation remains independently implemented here."
        ),
        "input_guards_passed": True,
    }
    output.write_text(json.dumps(record, indent=2) + "\n")
    print(f"Saved {output}")


if __name__ == "__main__":
    main()
