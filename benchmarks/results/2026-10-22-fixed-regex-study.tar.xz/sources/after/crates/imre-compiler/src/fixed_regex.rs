//! Translate the supported Python lexical forms, then let the native regex parser
//! validate precedence, character ranges, repetition, captures, and engine limits.

use std::fmt::Write;

use regex_syntax::hir::HirKind;

// Python str.isspace(), also used by Unicode `re`, includes four C0 separators
// omitted from the Unicode White_Space property used by the Rust engine.
const SPACE: &str =
    r"\x09-\x0d\x1c-\x20\x85\xa0\x{1680}\x{2000}-\x{200a}\x{2028}\x{2029}\x{202f}\x{205f}\x{3000}";

pub(crate) struct FixedPattern {
    pub(crate) source: String,
    pub(crate) groups: Vec<Option<String>>,
}

pub(crate) fn translate(pattern: &str, verbose: bool) -> Result<FixedPattern, String> {
    let mut input = pattern.chars().peekable();
    let mut output = String::new();
    let mut groups = vec![None]; // Group zero is the whole match.
    let mut can_repeat = false;
    while let Some(c) = input.next() {
        match c {
            c if verbose && verbose_space(c) => continue,
            '#' if verbose => {
                // The Python tokenizer consumes a backslash and its next character
                // as one token even inside a comment, including a physical newline.
                while let Some(ch) = input.next() {
                    match ch {
                        '\\' => {
                            input.next().ok_or("incomplete regex escape in comment")?;
                        }
                        '\n' => break,
                        _ => {}
                    }
                }
                continue;
            }
            '(' => {
                output.push('(');
                if input.next_if_eq(&'?').is_some() {
                    if input.next_if_eq(&':').is_some() {
                        output.push_str("?:");
                    } else if input.next_if_eq(&'P').is_some() && input.next_if_eq(&'<').is_some() {
                        let mut name = String::new();
                        loop {
                            match input.next() {
                                Some('>') if !name.is_empty() => break,
                                Some(c)
                                    if c == '_'
                                        || c.is_ascii_alphabetic()
                                        || !name.is_empty() && c.is_ascii_digit() =>
                                {
                                    name.push(c)
                                }
                                _ => return Err("expected an ASCII Python capture name".into()),
                            }
                        }
                        write!(output, "?P<{name}>").unwrap();
                        groups.push(Some(name));
                    } else {
                        return Err("unsupported regex group, assertion, or inline flag".into());
                    }
                } else {
                    groups.push(None);
                }
                can_repeat = false;
            }
            ')' | '|' | '.' | '^' => {
                output.push(c);
                can_repeat = c == ')' || c == '.';
            }
            '$' => return Err("the Python final-newline $ anchor is not supported".into()),
            '[' => {
                class(&mut input, &mut output)?;
                can_repeat = true;
            }
            '\\' => {
                let kind = escaped(&mut input, &mut output, false)?;
                can_repeat = kind != Escape::Anchor;
            }
            '*' | '+' | '?' | '{' => {
                if !can_repeat {
                    return Err("regex quantifier requires a preceding atom".into());
                }
                output.push(c);
                if c == '{' {
                    if !count(&mut input, &mut output)? {
                        return Err("expected a compact regex repetition count".into());
                    }
                    if input.next_if_eq(&',').is_some() {
                        output.push(',');
                        count(&mut input, &mut output)?;
                    }
                    if input.next_if_eq(&'}').is_none() {
                        return Err("expected a compact regex repetition count".into());
                    }
                    output.push('}');
                }
                if input.next_if_eq(&'?').is_some() {
                    output.push('?');
                }
                // Python requires lazy modifiers to be adjacent and rejects nested
                // or possessive quantifiers in this subset. Verbose stripping must
                // not accidentally turn a separated '?' into a modifier.
                can_repeat = false;
            }
            c => {
                literal(&mut output, c);
                can_repeat = true;
            }
        }
    }
    let hir = regex_syntax::Parser::new()
        .parse(&output)
        .map_err(|e| e.to_string())?;
    let mut nodes = vec![&hir];
    while let Some(node) = nodes.pop() {
        if let HirKind::Repetition(repeat) = node.kind()
            && repeat.max != Some(1)
            && (repeat.sub.properties().minimum_len() == Some(0)
                || repeat.sub.properties().explicit_captures_len() != 0)
        {
            return Err("repeating a nullable expression or capture is not supported".into());
        }
        nodes.extend(node.kind().subs());
    }
    let regex = regex::Regex::new(&output).map_err(|e| e.to_string())?;
    if !regex
        .capture_names()
        .eq(groups.iter().map(Option::as_deref))
    {
        return Err("regex optimization would change the Python capture groups".into());
    }
    Ok(FixedPattern {
        source: output,
        groups,
    })
}

type Input<'a> = std::iter::Peekable<std::str::Chars<'a>>;

fn count(input: &mut Input<'_>, output: &mut String) -> Result<bool, String> {
    let digits: String = std::iter::from_fn(|| input.next_if(char::is_ascii_digit)).collect();
    if digits.is_empty() {
        return Ok(false);
    }
    // Python reserves UINT32_MAX to mean unbounded repetition.
    if digits.parse::<u32>().ok().is_none_or(|n| n == u32::MAX) {
        return Err("regex repetition count is too large".into());
    }
    output.push_str(&digits);
    Ok(true)
}

fn verbose_space(c: char) -> bool {
    matches!(c, ' ' | '\t' | '\n' | '\r' | '\x0b' | '\x0c')
}

/// Emitting punctuation as a scalar prevents Rust-only syntax from appearing
/// when Python literal characters become adjacent after comment removal.
fn literal(output: &mut String, c: char) {
    if c.is_alphanumeric() || c == '_' {
        output.push(c);
    } else {
        write!(output, "\\x{{{:x}}}", c as u32).unwrap();
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Escape {
    Scalar,
    Class,
    Anchor,
}

fn escaped(input: &mut Input<'_>, output: &mut String, in_class: bool) -> Result<Escape, String> {
    let c = input.next().ok_or("incomplete regex escape")?;
    let value = match c {
        's' | 'S' => {
            output.push('[');
            if c == 'S' {
                output.push('^');
            }
            output.push_str(SPACE);
            output.push(']');
            return Ok(Escape::Class);
        }
        'A' | 'Z' | 'z' if !in_class => {
            output.push_str(if c == 'A' { r"\A" } else { r"\z" });
            return Ok(Escape::Anchor);
        }
        'a' => '\x07',
        'b' if in_class => '\x08',
        't' => '\t',
        'n' => '\n',
        'v' => '\x0b',
        'f' => '\x0c',
        'r' => '\r',
        'x' | 'u' | 'U' => {
            let digits = match c {
                'x' => 2,
                'u' => 4,
                _ => 8,
            };
            let mut result = 0;
            for _ in 0..digits {
                let next = input
                    .next()
                    .and_then(|c| c.to_digit(16))
                    .ok_or("invalid hexadecimal regex escape")?;
                result = result * 16 + next;
            }
            char::from_u32(result).ok_or("regex escape is not a Unicode scalar")?
        }
        c if c.is_ascii_punctuation() || verbose_space(c) => c,
        _ => return Err(format!("unsupported Python regex escape \\{c}")),
    };
    literal(output, value);
    Ok(Escape::Scalar)
}

fn class(input: &mut Input<'_>, output: &mut String) -> Result<(), String> {
    output.push('[');
    if input.next_if_eq(&'^').is_some() {
        output.push('^');
    }
    let mut first = true;
    let mut range_left = false;
    let mut range_pending = false;
    while let Some(c) = input.next() {
        if c == ']' && !first {
            output.push(']');
            return Ok(());
        }
        if c == '[' || matches!(c, '&' | '~' | '|' | '-') && input.peek() == Some(&c) {
            return Err("nested or ambiguous regex character class is not supported".into());
        }
        if c == '-' && !first && input.peek() != Some(&']') {
            if !range_left {
                return Err("regex range requires scalar endpoints".into());
            }
            output.push('-');
            range_left = false;
            range_pending = true;
            continue;
        }
        let scalar = if c == '\\' {
            escaped(input, output, true)? == Escape::Scalar
        } else {
            literal(output, c);
            true
        };
        if range_pending && !scalar {
            return Err("regex range requires scalar endpoints".into());
        }
        range_left = scalar && !range_pending;
        range_pending = false;
        first = false;
    }
    Err("unclosed regex character class".into())
}

#[cfg(test)]
mod tests {
    use super::translate;
    use regex::Regex;

    #[test]
    fn preserves_verbose_class_contents_and_python_whitespace() {
        let pattern = r"\# \s* E # comment
             (?P<tag>[ #\]]+)";
        let translated = translate(pattern, true).unwrap();
        assert_eq!(translated.groups, [None, Some("tag".to_string())]);
        let regex = Regex::new(&translated.source).unwrap();
        let caps = regex.captures("🌍#\u{1c}\u{85}E #]z").unwrap();
        assert_eq!(&caps["tag"], " #]");
        let regex = Regex::new(&translate(r"[\s][^\s]\S", false).unwrap().source).unwrap();
        assert!(regex.is_match("\u{1f}xé"));
        assert!(!regex.is_match("\u{200b}xé"));
        // Only the six ASCII VERBOSE whitespace characters are ignored.
        assert!(
            Regex::new(&translate("a\u{a0}b", true).unwrap().source)
                .unwrap()
                .is_match("a\u{a0}b")
        );
    }

    #[test]
    fn escaped_newline_inside_verbose_comment_is_still_comment_text() {
        for (slashes, expected) in [(1, "a"), (2, "ab"), (3, "a")] {
            let pattern = format!("a#comment{}{}b", "\\".repeat(slashes), '\n');
            assert_eq!(
                Regex::new(&translate(&pattern, true).unwrap().source)
                    .unwrap()
                    .find("ab")
                    .unwrap()
                    .as_str(),
                expected
            );
        }
        assert!(translate("a#comment\\", true).is_err());
        assert!(translate("(?:){4294967295}", false).is_err());
    }

    #[test]
    fn rejects_semantics_the_engine_does_not_share() {
        for source in [
            r"a$",
            r"\1",
            r"\w",
            r"\b",
            r"(?=a)",
            r"(?P<a>x)(?P=a)",
            r"(?i:a)",
            r"a*+",
            r"a* ?",
            r"a{1, 3}",
            r"(a)+",
            r"(x?)*",
            r"[a&&b]",
            r"[[a]]",
            r"[\s-x]",
            r"[x-\s]",
            r"\uD800",
            r"(?P<1bad>x)",
        ] {
            assert!(translate(source, true).is_err(), "{source}");
        }
        for source in [
            r"\A(ab|c)(?P<maybe>z)?\Z",
            r"[a-z]{2,4}?",
            r"[\-\]]+",
            r"(?P<empty>x*)?",
        ] {
            assert!(translate(source, false).is_ok(), "{source}");
        }
    }
}
