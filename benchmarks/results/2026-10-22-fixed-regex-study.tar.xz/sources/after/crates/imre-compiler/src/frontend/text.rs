//! Binds native text methods without losing keyword evaluation order.

use super::*;
use crate::ir::TextOperation;

/// Constructs a fixed signature slot for the shared argument binder.
fn parameter(name: &str, ty: Type, kind: ParameterKind, default: Option<Expr>) -> Parameter {
    Parameter {
        name: name.to_owned(),
        ty,
        kind,
        default,
    }
}

/// Supplies an absent optional value without changing its concrete type.
fn absent(ty: Type) -> Expr {
    Expr {
        ty,
        kind: ExprKind::Absent(Box::new(Expr {
            ty: Type::None,
            kind: ExprKind::None,
        })),
    }
}

impl Checker<'_> {
    /// Checks the bounded native signatures while retaining source evaluation order.
    pub(super) fn text_method(
        &mut self,
        receiver: Expr,
        name: &str,
        call: &ast::ExprCall,
    ) -> Result<Expr, String> {
        use ParameterKind::{PositionalOnly, PositionalOrKeyword};
        // Existing infallible entry points avoid a pending-error check for these
        // common signatures, whose arguments cannot request an invalid split.
        if call.arguments.args.is_empty()
            && call.arguments.keywords.is_empty()
            && matches!(name, "split" | "rstrip")
        {
            return Ok(Expr {
                ty: if name == "split" {
                    self.types.list(Type::Str)
                } else {
                    Type::Str
                },
                kind: ExprKind::Builtin(
                    if name == "split" {
                        Builtin::Split
                    } else {
                        Builtin::RStrip
                    },
                    vec![receiver],
                ),
            });
        }
        let optional_string = self.types.optional(Type::Str);
        let (operation, returns, parameters) = match name {
            "split" | "rsplit" => (
                TextOperation::Split(name == "rsplit"),
                self.types.list(Type::Str),
                vec![
                    parameter(
                        "sep",
                        optional_string,
                        PositionalOrKeyword,
                        Some(absent(optional_string)),
                    ),
                    parameter(
                        "maxsplit",
                        Type::Int,
                        PositionalOrKeyword,
                        Some(Expr {
                            ty: Type::Int,
                            kind: ExprKind::Int("-1".to_owned()),
                        }),
                    ),
                ],
            ),
            "strip" | "lstrip" | "rstrip" => (
                TextOperation::Strip(match name {
                    "lstrip" => 1,
                    "rstrip" => 2,
                    _ => 0,
                }),
                Type::Str,
                vec![parameter(
                    "chars",
                    optional_string,
                    PositionalOnly,
                    Some(absent(optional_string)),
                )],
            ),
            "startswith" | "endswith" => (
                if name == "startswith" {
                    TextOperation::StartsWith
                } else {
                    TextOperation::EndsWith
                },
                Type::Bool,
                vec![parameter(
                    if name == "startswith" {
                        "prefix"
                    } else {
                        "suffix"
                    },
                    Type::Str,
                    PositionalOnly,
                    None,
                )],
            ),
            "find" => {
                let optional_index = self.types.optional(Type::Int);
                (
                    TextOperation::Find,
                    Type::Int,
                    vec![
                        parameter("sub", Type::Str, PositionalOnly, None),
                        parameter(
                            "start",
                            optional_index,
                            PositionalOnly,
                            Some(absent(optional_index)),
                        ),
                    ],
                )
            }
            "partition" => (
                TextOperation::Partition,
                self.types.tuple(vec![Type::Str; 3]),
                vec![parameter("sep", Type::Str, PositionalOnly, None)],
            ),
            _ => unreachable!("only supported text methods reach this binder"),
        };
        let arguments = self.arguments(call, &parameters, Some(receiver))?;
        Ok(self.text_operation(operation, returns, arguments))
    }

    /// Binds UTF-8 replacement decoding without exposing other URL operations.
    pub(super) fn unquote_call(&mut self, call: &ast::ExprCall) -> Result<Expr, String> {
        let parameters = [parameter(
            "string",
            Type::Str,
            ParameterKind::PositionalOrKeyword,
            None,
        )];
        let arguments = self.arguments(call, &parameters, None)?;
        Ok(self.text_operation(TextOperation::Unquote, Type::Str, arguments))
    }

    /// Keyword permutation happens only after supplied expressions have executed
    /// and acquired independent roots. Identity order needs no extra scope.
    fn text_operation(
        &mut self,
        operation: TextOperation,
        returns: Type,
        arguments: ir::CallArgs,
    ) -> Expr {
        if arguments
            .order
            .iter()
            .copied()
            .eq(0..arguments.values.len())
        {
            return Expr {
                ty: returns,
                kind: ExprKind::Builtin(Builtin::Text(operation), arguments.values),
            };
        }
        let mut body = Vec::new();
        let mut clear = Vec::new();
        for value in arguments.values {
            let slot = self.hidden(value.ty);
            body.push(Statement::Assign(slot, value));
            clear.push(slot);
        }
        let args = arguments
            .order
            .iter()
            .map(|&index| self.local(clear[index]))
            .collect();
        Expr {
            ty: returns,
            kind: ExprKind::Scope {
                body,
                value: Box::new(Expr {
                    ty: returns,
                    kind: ExprKind::Builtin(Builtin::Text(operation), args),
                }),
                clear,
            },
        }
    }
}
