"""Retain per-engine complete outputs and zero-round profiles after the canonical timed study."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys,time
c=Path('/home/dev-user/.cache/relar/fixed-regex-20261022');rev=sys.argv[1];stage=c/('final-'+rev[:7]);root=Path('/home/dev-user/code/oss/relar-fixed-regex-final-'+rev[:7]);py='/home/dev-user/.local/bin/python3.14';load=lambda p:json.loads(Path(p).read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while not (stage/'finished').exists():
 assert not (stage/'failed').exists() and not (stage/'build-failed').exists();time.sleep(3)
funcs=runpy.run_path(str(root/'benchmarks/conformance_validate.py'));out=stage/'postflight';out.mkdir(exist_ok=False);h=out/'home';h.mkdir();env=funcs['environment'](h);env['PYTHONPATH']=''
def validate(cmd,expected_file,expected_stdout,target,cwd):
 cp=subprocess.run(list(map(str,cmd)),capture_output=True,env=env,cwd=cwd,timeout=180)
 assert cp.returncode==0 and not cp.stderr and cp.stdout==expected_stdout,(cmd,cp.returncode,cp.stderr)
 if expected_file is None:target.write_bytes(cp.stdout)
 else:assert target.read_bytes()==expected_file
 return {'command':list(map(str,cmd)),'file_sha256':sha(target),'stdout_sha256':hashlib.sha256(cp.stdout).hexdigest(),'bytes':target.stat().st_size}
result={'revision':rev,'modes':{}}
for mode in ('normal','thinlto'):
 m=load(stage/mode/'results.json');cells={}
 for label,v in m['config']['engines'].items():
  p=out/'outputs'/mode/label;p.mkdir(parents=True);observations={}
  for task,f in m['inputs']['fixtures'].items():
   oracle=Path(f['capture_oracle']['path']).read_bytes();target=p/(task+'.captures')
   observations[target.name]=validate(v['scan']+[f['input']['path'],'1','dump'],None,oracle,target,p)
  for panel,f in m['panels'].items():
   paths=f['captures'];w=funcs['Workload'](*[Path(paths[k]['path']) for k in ('manifest','old','new')],panel.split('-')[1]);expected=Path(f['expected_report']['path']).read_bytes();target=p/(panel+'.md')
   observations[target.name]=validate(v['report']+w.arguments()+['--output',str(target)],expected,b'',target,p)
  cells[label]=observations
 result['modes'][mode]=cells
 print(mode,'retained 30 complete outputs',flush=True)
(out/'outputs.json').write_text(json.dumps(result,indent=2)+'\n')
normal=load(stage/'normal/results.json');x=normal['inputs']['fixtures']['corpus']
def profile(engine,cpu):
 cmd=normal['config']['engines'][engine]['scan'];args=[py,str(root/'benchmarks/native_tools_profile.py'),'--binary',engine+'='+cmd[0],'--cpu',str(cpu),'--input','corpus.txt='+x['input']['path'],'--stdout','0 0\n','--output',str(out/('profile-0-'+engine)),'--',*cmd[1:],'corpus.txt','0','checksum']
 with (out/('profile-0-'+engine+'.log')).open('wb') as f:subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
with ThreadPoolExecutor(3) as p:list(p.map(profile,('before','after','rust'),(4,5,6)))
(out/'finished').write_text('passed\n');print('verified all post-timing outputs and six zero-round traces',flush=True)
