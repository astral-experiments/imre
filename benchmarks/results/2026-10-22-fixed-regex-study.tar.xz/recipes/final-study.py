"""Run the ordered, one-core benchmark, source/process validation, and post-timing profiles."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import fcntl,hashlib,json,os,runpy,shutil,subprocess,sys,time
cache=Path('/home/dev-user/.cache/relar/fixed-regex-20261022');rev=sys.argv[1];stage=cache/('final-'+rev[:7]);build=stage/'build';root=Path('/home/dev-user/code/oss/relar-fixed-regex-final-'+rev[:7]);oldroot=root.parent/'relar-fixed-regex-base-20261022';py='/home/dev-user/.local/bin/python3.14';prior=Path('/home/dev-user/.cache/relar-live-conformance-20261022');caps=prior/'measurements-normal-2/changed-github/captures'
read=lambda p:json.loads(Path(p).read_bytes())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
def run(label,args,env=None,tolerant=False):
 print(datetime.now(timezone.utc).isoformat(),'start',label,flush=True)
 with (stage/(label+'.log')).open('wb') as f:s=subprocess.run(list(map(str,args)),cwd=root,stdout=f,stderr=subprocess.STDOUT,env=env)
 print(datetime.now(timezone.utc).isoformat(),'finish',label,s.returncode,flush=True)
 if not tolerant:s.check_returncode()
 return s.returncode
while not (stage/'ready').exists():
 assert not (stage/'build-failed').exists();time.sleep(2)
lock=(cache/'official-cpu31.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 for work,head in [(root,rev),(oldroot,'dad5a967fa7fa34cc34cddbc02e4ab35d147e0da')]:
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=work)
 check=stage/'checks';check.mkdir()
 # A separate independently seeded corpus, shared by all 11 native/Python argv forms.
 funcs=runpy.run_path(str(root/'benchmarks/conformance_validate.py'));sdk=runpy.run_path(str(root/'benchmarks/conformance_regex_benchmark.py'));asan={**funcs['environment'](check/'home'),'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1'};(check/'home').mkdir()
 seeded=check/'seeded';seeded.mkdir();n=funcs['parser_differentials'](30_000,native=build/'after-asan-scanner',directory=seeded)
 lines=(seeded/'scanner-lines').read_text(encoding='utf-8').split('\0');assert n==len(lines)==30000
 oracle,matches,score=sdk['observations'](lines,funcs['upstream']().CONFORMANCE_ERROR_PATTERN);(seeded/'expected.captures').write_bytes(oracle)
 validation={'seeded_lines':n,'seeded_matches':matches,'seeded_checksum':score,'input_sha256':sha(seeded/'scanner-lines'),'expected_sha256':hashlib.sha256(oracle).hexdigest(),'engines':{}}
 commands={}
 for mode in ('normal','thinlto'):
  cfg=read(stage/('config-'+mode+'.json'))
  for engine,v in cfg['engines'].items():
   label=engine if engine in ('upstream','cpython') else engine+'-'+mode
   commands[label]=v['scan']
 commands['after-asan']=[str(build/'after-asan-scanner')]
 for label,cmd in commands.items():
  cp=subprocess.run(cmd+[str(seeded/'scanner-lines'),'1','dump'],cwd=root,capture_output=True,env=asan,timeout=60)
  assert cp.returncode==0 and not cp.stderr and cp.stdout==oracle,(label,cp.returncode,cp.stderr[-800:])
  validation['engines'][label]=hashlib.sha256(cp.stdout).hexdigest()
 # Bind a complete changed report to all ordinary/ThinLTO program modes including ASan.
 work=funcs['Workload'](caps/'manifest.json',caps/'old.json',caps/'new.json');expected=funcs['oracle'](work).report.encode()
 target=check/'asan-report.md';cp=subprocess.run([build/'relar-asan/conformance-report',*work.arguments(),'--output',target],env=asan,cwd=root,capture_output=True)
 assert cp.returncode==0 and not cp.stderr and not cp.stdout and target.read_bytes()==expected
 validation['asan_complete_report_sha256']=sha(target);save(check/'validation.json',validation);print('30K CAPTURES VERIFIED',len(commands),validation['expected_sha256'],flush=True)
 for mode in ('normal','thinlto'):
  mroot=stage/mode;cfg=stage/('config-'+mode+'.json')
  code=run('matrix-'+mode,[py,'-u',root/'benchmarks/conformance_regex_benchmark.py','--config',cfg,'--captures',caps,'--output',mroot,'--cpu','31','--samples','12','--scan-rounds','64','--report-rounds','4'],tolerant=True)
  matrix=mroot/'results.json';m=read(matrix);assert m['completed'] and (code==0)==m['time_target_met']
  run('audit-'+mode,[py,root/'benchmarks/conformance_regex_audit.py',matrix,'--strict-files','--source-root',root])
  shutil.copy2(stage/('audit-'+mode+'.log'),mroot/'audit-strict.json');(mroot/'ready').write_text(sha(matrix)+'\n')
 # Include native baseline/after/reference CPU and heap counts after all wall-clock timings.
 m=read(stage/'normal/results.json');x=m['inputs']['fixtures']['corpus'];cmds=m['config']['engines']
 def profile(engine,cpu):
  cmd=cmds[engine]['scan'];run('profile-'+engine,[py,root/'benchmarks/native_tools_profile.py','--binary',engine+'='+cmd[0],'--cpu',cpu,'--input','corpus.txt='+x['input']['path'],'--stdout',f"{x['matches']*16} {x['checksum']*16}\n",'--output',stage/('profile-'+engine),'--',*cmd[1:],'corpus.txt','16','checksum'])
 with ThreadPoolExecutor(3) as pool:
  fs=[pool.submit(profile,k,str(4+i)) for i,k in enumerate(('before','after','rust'))]
  for f in fs:f.result()
 verified=read(stage/'verified-builds.json');assert all(sha(path)==i['sha256'] for path,i in verified['guarded'].items())
 (stage/'finished').write_text(datetime.now(timezone.utc).isoformat()+'\n')
except BaseException:
 (stage/'failed').write_text(datetime.now(timezone.utc).isoformat()+'\n');raise
