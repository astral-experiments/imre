"""Build exact old/new/native scanner/report binaries and hash every input before official timing."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import fcntl,hashlib,json,os,runpy,shutil,subprocess,sys,time
cache=Path('/home/dev-user/.cache/relar/fixed-regex-20261022');rev,ref,bundle_sha=sys.argv[1:];old='dad5a967fa7fa34cc34cddbc02e4ab35d147e0da'
prior=Path('/home/dev-user/.cache/relar-live-conformance-20261022');oldroot=Path('/home/dev-user/code/oss/relar-fixed-regex-base-20261022');root=oldroot.parent/('relar-fixed-regex-final-'+rev[:7]);stage=cache/('final-'+rev[:7]);build=stage/'build';stage.mkdir(exist_ok=False);build.mkdir()
py='/home/dev-user/.local/bin/python3.14';clang='/usr/lib/llvm-18/bin/clang';lld='/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld'
read=lambda p:json.loads(Path(p).read_bytes())
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def identity(p):return {'path':str(p),'bytes':Path(p).stat().st_size,'sha256':digest(p)}
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def run(label,argv,cwd=root,env=None):
 print(datetime.now(timezone.utc).isoformat(),'start',label,flush=True)
 with (build/(label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(datetime.now(timezone.utc).isoformat(),'finish',label,p.returncode,flush=True);p.check_returncode()
def git(*args,cwd=oldroot):return subprocess.check_output(['git',*map(str,args)],cwd=cwd,text=True).strip()
def clean(p,h):
 assert git('rev-parse','--show-toplevel',cwd=p)==str(p) and git('rev-parse','--path-format=absolute','--git-common-dir',cwd=p)=='/home/dev-user/code/oss/relar-workspaces-20261021/.git'
 assert git('config','user.email',cwd=p)=='charlie.r.marsh@gmail.com' and git('remote','get-url','origin',cwd=p)=='https://github.com/astral-sh/relar.git'
 assert git('rev-parse','HEAD',cwd=p)==h and not git('status','--porcelain',cwd=p)
oldcore=cache/'baseline/core';oldbuild=read(oldcore/'build-record.json');env={**os.environ,'RUSTUP_HOME':oldbuild['environment']['RUSTUP_HOME'],'RUSTC':oldbuild['environment']['RUSTC'],'CARGO_BUILD_BUILD_DIR':oldbuild['environment']['CARGO_BUILD_BUILD_DIR'],'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all','CARGO_TARGET_DIR':str(cache/'old-target')}
try:
 clean(oldroot,old);bundle=cache/(rev+'.bundle');assert digest(bundle)==bundle_sha and git('bundle','list-heads',bundle)==rev+' '+ref;git('bundle','verify',bundle);git('fetch','--no-tags','--no-write-fetch-head',bundle,ref);git('merge-base','--is-ancestor',old,rev)
 target=cache/('target-'+rev[:7]);run('worktree',['cargo','+ohm','worktree','add','--target-dir',target,'-b','charlie/fixed-regex-measure-'+rev[:7],root,rev],oldroot,env);clean(root,rev)
 assert not git('diff','--name-only',old,rev,'--','examples/conformance_report/upstream','benchmarks/native_platform',cwd=root)
 env['CARGO_TARGET_DIR']=str(target)
 run('core',[py,'benchmarks/native_tools_build.py','--toolchain','ohm','--target-dir',target,'--shared-build-dir',env['CARGO_BUILD_BUILD_DIR'],'--rustup-home',env['RUSTUP_HOME'],'--jobs',oldbuild['environment']['CARGO_BUILD_JOBS'],'--modes','normal','thinlto','asan','--output',build/'core'],env=env)
 core=read(build/'core/build-record.json');assert core['revision']==rev and core['input_guards_passed'] and core['source_matches_revision'];assert all(core[k]==oldbuild[k] for k in ['tool_sha256','tool_paths','toolchain','cargo','target'])
 helpers={r:runpy.run_path(str(r/'benchmarks/live_conformance_benchmark.py')) for r in (root,oldroot)}
 guarded={}
 scan_sources={}
 for label,src in [('before',oldroot),('after',root)]:
  d=build/('scan-source-'+label);app=d/'conformance_report';shutil.copytree(src/'examples/conformance_report',app,ignore=shutil.ignore_patterns('__pycache__'));driver=root/'benchmarks/conformance_scanner.py';shutil.copy2(driver,app/'benchmark_scanner.py')
  hashes={}
  for f in app.rglob('*.py'):
   sr=driver if f.name=='benchmark_scanner.py' else src/'examples/conformance_report'/f.relative_to(app)
   assert digest(sr)==digest(f) and hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+str(sr.relative_to(root if sr==driver else src))],cwd=root if sr==driver else src)).hexdigest()==digest(sr)
   hashes[str(f.relative_to(d))]=digest(f)
  scan_sources[label]=hashes
 def scan(label,mode):
  source=oldroot if label=='before' else root;d=build/('scan-source-'+label);cc=oldcore if label=='before' else build/'core';out=build/f'{label}-{mode}-scanner';rt=cc/(mode+'_runtime.a');ll=Path(str(out)+'.ll');cmd=[cc/'relar','build',d/'conformance_report/benchmark_scanner.py','--module-root',d,'-o',out,'--runtime',rt,'--clang',clang,'--target',core['target'],'--opt-level','3','--emit-llvm',ll]
  if mode=='thinlto':cmd+=['--lto-linker',lld]
  if mode=='asan':cmd+=['--sanitize']
  run(out.name,cmd,env=env)
  return {'parser_revision':git('rev-parse','HEAD',cwd=source),'driver_revision':rev,'source_hashes':scan_sources[label],'compiler':identity(cc/'relar'),'runtime':identity(rt),'core_build':identity(cc/'build-record.json'),'llvm':identity(ll),'executable':identity(out),'command':list(map(str,cmd)),'clang':identity(Path(clang)),'lto_linker':identity(Path(lld)) if mode=='thinlto' else None}
 def program(mode):
  cmd=[py,'benchmarks/live_conformance_build.py','--application','conformance_report','--core-build-record',build/'core/build-record.json','--mode',mode,'--clang',clang,'--output',build/('relar-'+mode)]
  if mode=='thinlto':cmd+=['--lto-linker',lld]
  run('program-'+mode,cmd,env=env)
 def refs(mode):
  cmd=[py,'benchmarks/reference/conformance_report/build.py','--toolchain','ohm','--artifact-dir',build/('rust-'+mode),'--target-dir',cache/('ref-'+mode+'-'+rev[:7]),'--build-cache',env['CARGO_BUILD_BUILD_DIR']]
  if mode=='thinlto':cmd+=['--thinlto']
  run('rust-'+mode,cmd,env=env)
 def codon(mode):
  previous='final-codon-normal-2' if mode=='normal' else 'final-codon-thin-2';b=read(prior/previous/'build-record.json');assert digest(Path(b['compiler']))==b['compiler_sha256'] and digest(Path(b['native_platform']['path']))==b['native_platform']['sha256']
  run('codon-'+mode,[py,'benchmarks/codon_native/build.py','--codon',b['compiler'],'--output',build/('codon-'+mode),'--applications','conformance_report','--conformance-scanner','--platform-library',b['native_platform']['path']],env=env)
 with ThreadPoolExecutor(5) as pool:
  programs=[pool.submit(program,mode) for mode in ('normal','thinlto','asan')]
  comps=[pool.submit(fn,mode) for fn in (refs,codon) for mode in ('normal','thinlto')]
  scans={(key,mode):pool.submit(scan,key,mode) for key in ('before','after') for mode in (('normal','thinlto') if key=='before' else ('normal','thinlto','asan'))}
  for f in programs+comps:f.result()
  scan_records={key+'-'+mode:f.result() for (key,mode),f in scans.items()}
 write(stage/'scanner-builds.json',scan_records)
 for mode in ('normal','thinlto'):
  for owner,d in ((oldroot,cache/'baseline'/mode),(root,build/('relar-'+mode)),(root,build/('rust-'+mode)),(root,build/('codon-'+mode))):
   record=helpers[owner]['verify_build_record'](d/'build-record.json',guarded)
   if 'native_re' in record:assert digest(Path(record['native_re']['path']))==record['native_re']['sha256']
  run('config-'+mode,[py,cache/'recipes/configure.py',root,oldroot,mode,cache/'baseline'/mode,build/('relar-'+mode),build/('before-'+mode+'-scanner'),build/('after-'+mode+'-scanner'),build/('rust-'+mode),build/('codon-'+mode),stage/('config-'+mode+'.json'),'--fresh'])
 helpers[root]['verify_build_record'](build/'relar-asan/build-record.json',guarded)
 clean(root,rev);clean(oldroot,old)
 write(stage/'verified-builds.json',{'revision':rev,'baseline_revision':old,'bundle':identity(bundle),'guarded':guarded,'scanners':scan_records,'toolchain':core['toolchain'],'target':core['target']})
 (stage/'ready').write_text(rev+'\n')
except BaseException:
 (stage/'build-failed').write_text(datetime.now(timezone.utc).isoformat()+'\n')
 raise
