from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys
from datetime import datetime,timezone
c=Path('/home/dev-user/.cache/relar/fixed-regex-20261022');c.mkdir(parents=True,exist_ok=True);bundle=c/'baseline.bundle'
rev='dad5a967fa7fa34cc34cddbc02e4ab35d147e0da';base=Path('/home/dev-user/code/oss/relar-catalog-ownership-db2a6f8-20261022')
old=Path('/home/dev-user/.cache/relar/catalog-ownership-20261022/candidates/db2a6f8/core/build-record.json');record=json.loads(old.read_bytes())
def check(cmd,cwd=base,**kw):return subprocess.check_output(list(map(str,cmd)),cwd=cwd,text=True,stderr=subprocess.STDOUT,**kw).strip()
assert check(['git','rev-parse','--path-format=absolute','--git-common-dir'])=='/home/dev-user/code/oss/relar-workspaces-20261021/.git'
assert check(['git','config','user.email'])=='charlie.r.marsh@gmail.com' and check(['git','remote','get-url','origin'])=='https://github.com/astral-sh/relar.git'
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==sys.argv[1]
head,ref=check(['git','bundle','list-heads',bundle]).split();assert head==rev
check(['git','bundle','verify',bundle]);check(['git','fetch','--no-tags','--no-write-fetch-head',bundle,ref])
root=base.parent/'relar-fixed-regex-base-20261022'
env={**os.environ,'RUSTUP_HOME':record['environment']['RUSTUP_HOME'],'RUSTC':record['environment']['RUSTC'],'CARGO_TARGET_DIR':str(c/'old-target'),'CARGO_BUILD_BUILD_DIR':record['environment']['CARGO_BUILD_BUILD_DIR'],'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all'}
if not root.exists():check(['cargo','+ohm','worktree','add','--target-dir',c/'old-target','-b','charlie/fixed-regex-baseline-bench-20261022',root,rev],env=env)
assert check(['git','rev-parse','HEAD'],root)==rev and not check(['git','status','--porcelain'],root)
py='/home/dev-user/.local/bin/python3.14';out=c/'baseline';out.mkdir(exist_ok=True)
def run(label,cmd):
 print(datetime.now(timezone.utc).isoformat(),label,'start',flush=True)
 with (out/(label+'.log')).open('wb') as f:subprocess.run(list(map(str,cmd)),cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(datetime.now(timezone.utc).isoformat(),label,'finished',flush=True)
run('core',[py,'benchmarks/native_tools_build.py','--toolchain','ohm','--target-dir',c/'old-target','--shared-build-dir',record['environment']['CARGO_BUILD_BUILD_DIR'],'--rustup-home',record['environment']['RUSTUP_HOME'],'--jobs',record['environment']['CARGO_BUILD_JOBS'],'--modes','normal','thinlto','--output',out/'core'])
def prog(mode):
 args=[py,'benchmarks/live_conformance_build.py','--application','conformance_report','--core-build-record',out/'core/build-record.json','--mode',mode,'--clang','/usr/lib/llvm-18/bin/clang','--output',out/mode]
 if mode=='thinlto':args+=['--lto-linker','/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld']
 run(mode,args)
with ThreadPoolExecutor(2) as p:list(p.map(prog,['normal','thinlto']))
(out/'finished').write_text(rev+'\n')
