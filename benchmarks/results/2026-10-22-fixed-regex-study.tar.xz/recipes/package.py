"""Create a compact, self-contained source/oracle/timing/profile archive with content index."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,subprocess,sys,tarfile
c=Path('/home/dev-user/.cache/imre/fixed-regex-20261022');rev=sys.argv[1];s=c/('final-'+rev[:7]);assert (s/'finished').exists();oldroot=Path('/home/dev-user/code/oss/imre-fixed-regex-base-20261022');root=oldroot.parent/('imre-fixed-regex-final-'+rev[:7]);each={};old='dad5a967fa7fa34cc34cddbc02e4ab35d147e0da'
def add(name,path):
 path=Path(path);assert path.is_file(),path
 if name in each:assert each[name].read_bytes()==path.read_bytes(),name
 else:each[name]=path
def read(p):return json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for mode in ['normal','thinlto']:
 m=read(s/mode/'results.json');add(mode+'/results.json',s/mode/'results.json');add(mode+'/audit-strict.json',s/mode/'audit-strict.json');add(mode+'/config.json',s/('config-'+mode+'.json'))
 for k,p in [('before',c/'baseline'/mode),('after',s/'build'/('imre-'+mode)),('codon',s/'build'/('codon-'+mode)),('rust',s/'build'/('rust-'+mode))]:add('builds/'+k+'-'+mode+'/build-record.json',p/'build-record.json')
 for k,info in m['inputs']['fixtures'].items():
  add('inputs/'+k+'.txt',info['input']['path']);add('inputs/'+k+'.captures',info['capture_oracle']['path'])
 for name,item in m['panels'].items():
  add('inputs/'+name+'.md',item['expected_report']['path']);add('inputs/'+name+'/preparation.json',item['preparation']['path'])
  for k,x in item['captures'].items():add('inputs/'+name+'/'+k+'.json',x['path'])
 for f in m['inputs']['test_files']:add('inputs/suite/'+Path(f['path']).name,f['path'])
for key,base in [('before',oldroot),('after',root)]:
 inputs=['Cargo.toml','Cargo.lock','crates','stdlib','examples/conformance_report','benchmarks/reference/conformance_report','benchmarks/native_platform','benchmarks/codon_native','benchmarks/native_tools_build.py','benchmarks/native_tools_benchmark.py','benchmarks/native_tools_profile.py','benchmarks/benchmark.py','benchmarks/validate.py','benchmarks/live_conformance_benchmark.py','benchmarks/live_conformance_validate.py','benchmarks/live_conformance_build.py','benchmarks/conformance_validate.py','benchmarks/conformance_regex_benchmark.py','benchmarks/conformance_regex_audit.py','benchmarks/conformance_scanner.py','benchmarks/conformance_scanner_upstream.py','LICENSE-APACHE','LICENSE-MIT']
 for name in subprocess.check_output(['git','ls-files','-z','--',*inputs],cwd=base).split(b'\0'):
  if name:add('sources/'+key+'/'+name.decode(),base/name.decode())
for name,src in [('before-core',c/'baseline/core'),('after-core',s/'build/core'),('after-asan',s/'build/imre-asan')]:add('builds/'+name+'/build-record.json',src/'build-record.json')
for file in ['scanner-builds.json','verified-builds.json']:add('builds/'+file,s/file)
for name in ('validation.json','seeded/scanner-lines','seeded/expected.captures'):add('checks/'+Path(name).name,s/'checks'/name)
for engine in ('before','after','rust'):
 for p in sorted((s/('profile-'+engine)).glob('*')):
  if p.is_file() and (p.suffix in ('.trace','.log') or p.name in ('provenance.json','summary.json')):add('profiles/'+engine+'/'+p.name,p)
for name in ('configure.py','final-build.py','final-study.py','freeze.py','final-dispatch.py','package.py'):add('recipes/'+name,c/'recipes'/name)
for f in ['/home/dev-user/code/oss/typing-imre-live-20261022/LICENSE','/home/dev-user/code/oss/typing-imre-live-20261022/LICENSE.txt']:
 if Path(f).is_file():add('licenses/typing-'+Path(f).name,f)
for p in (root/'examples/conformance_report/upstream').glob('*'):
 if p.name in ('LICENSE','UPSTREAM.json'):add('licenses/ruff-'+p.name,p)
add('replay.py',c/'recipes/replay.py');add('README.md',c/'recipes/README.md');add('builds/changes.bundle',c/(rev+'.bundle'))
for label,scan in read(s/'scanner-builds.json').items():add('builds/ir/'+label+'.ll',scan['llvm']['path'])
for mode in ('normal','thinlto'):
 for p in (s/'build'/('codon-'+mode)).rglob('*.codon'):add('builds/codon-'+mode+'/generated/'+str(p.relative_to(s/'build'/('codon-'+mode))),p)
idx={'schema':1,'revision':rev,'baseline_revision':old,'created_utc':datetime.now(timezone.utc).isoformat(),'files':{k:{'sha256':sha(p),'bytes':p.stat().st_size} for k,p in sorted(each.items())}}
(s/'evidence-index.json').write_text(json.dumps(idx,indent=2)+'\n');each['manifest.json']=s/'evidence-index.json'
out=s/'evidence.tar.xz'
with tarfile.open(out,'w:xz',preset=6) as t:
 for k,p in sorted(each.items()):t.add(p,arcname=k,recursive=False)
print(len(each)-1,out.stat().st_size,sha(out),flush=True)
