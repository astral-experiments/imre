"""Add separately retained per-engine outputs, 0-round trace controls and their audit to the sealed archive."""
from pathlib import Path
import hashlib,io,json,shutil,subprocess,sys,tarfile,tempfile,time
c=Path('/home/dev-user/.cache/imre/fixed-regex-20261022');rev=sys.argv[1];s=c/('final-'+rev[:7]);post=s/'postflight';base=s/'evidence.tar.xz'
while not (post/'finished').exists() or not base.exists() or not (c/('package-'+rev[:7]+'.log')).is_file() or len((c/('package-'+rev[:7]+'.log')).read_text().split())!=3:time.sleep(1)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for mode in ('normal','thinlto'):
 cfg=json.loads((s/('config-'+mode+'.json')).read_bytes())
 assert all(Path(x['path']).stat().st_size==x['bytes'] and sha(x['path'])==x['sha256'] for x in cfg['guarded_inputs'])

with tempfile.TemporaryDirectory(prefix='portable-',dir=s) as tmp:
 root=Path(tmp)
 with tarfile.open(base) as t:t.extractall(root,filter='data')
 shutil.copy2(Path('/home/dev-user/code/oss/imre-fixed-regex-final-'+rev[:7])/'benchmarks/dependency_profile.py',root/'sources/after/benchmarks/dependency_profile.py');shutil.copy2(s/'host.json',root/'host.json');shutil.copy2(c/'recipes/host.py',root/'recipes/host.py');idx=json.loads((root/'manifest.json').read_bytes());assert all(sha(root/n)==v['sha256'] for n,v in idx['files'].items())
 shutil.copytree(post/'outputs',root/'outputs');shutil.copy2(post/'outputs.json',root/'checks/outputs.json')
 for e in ['before','after','rust']:
  p=root/'profiles'/(e+'-zero');p.mkdir()
  for src in (post/('profile-0-'+e)).iterdir():
   if src.suffix in ('.log','.trace') or src.name in ('provenance.json','summary.json'):shutil.copy2(src,p/src.name)
 shutil.copy2(c/'recipes/postflight.py',root/'recipes/postflight.py');shutil.copy2(c/'recipes/pack-complete.py',root/'recipes/pack-complete.py')
 replay=root/'replay.py';text=replay.read_text().replace('r=Path(__file__)', 'if sys.flags.optimize:raise RuntimeError("portable audit requires assertions")\nr=Path(__file__)');prefix,report=text.split('print(json.dumps(',1);suffix="""
outputs=json.loads((r/'checks/outputs.json').read_bytes());assert outputs['revision']==idx['revision']
for mode,engines in outputs['modes'].items():
 assert mode in rows and set(engines)=={'upstream','cpython','before','after','codon','rust'}
 for engine,artifacts in engines.items():
  assert set(artifacts)=={'corpus.captures','edge.captures','unchanged-github.md','changed-github.md','changed-diff.md'}
  for name,observation in artifacts.items():
   config=json.loads((r/mode/'results.json').read_bytes())['config'];prefix=config['engines'][engine]['report' if name.endswith('.md') else 'scan'];assert observation['command'][:len(prefix)]==prefix
   data=(r/'outputs'/mode/engine/name).read_bytes()
   assert observation['stdout_sha256']==(hashlib.sha256(b'').hexdigest() if name.endswith('.md') else observation['file_sha256']);assert (r/'inputs'/name).read_bytes()==data and observation['file_sha256']==hashlib.sha256(data).hexdigest() and observation['bytes']==len(data)
provenance=json.loads((r/'builds/verified-builds.json').read_bytes());assert provenance['revision']==idx['revision'] and provenance['baseline_revision']==idx['baseline_revision'] and provenance['bundle']['sha256']==hashfn(r/'builds/changes.bundle')
config=json.loads((r/'normal/results.json').read_bytes())['config'];verified=0
for name,item in provenance['guarded'].items():
 for label,checkout in [('before',config['baseline_source_root']),('after',config['source_root'])]:
  src=Path(name);checkout=Path(checkout)
  if src.is_relative_to(checkout):
   retained=r/'sources'/label/src.relative_to(checkout)
   if retained.is_file():
    assert hashfn(retained)==item['sha256'];verified+=1
assert verified>=80
import runpy
records=(r/'checks/scanner-lines').read_text(encoding='utf-8').split('\\0')
pattern=runpy.run_path(str(oracle/'benchmarks/conformance_validate.py'))['upstream']().CONFORMANCE_ERROR_PATTERN
observe=runpy.run_path(str(oracle/'benchmarks/conformance_regex_benchmark.py'))['observations']
dump,n,score=observe(records,pattern);assert len(records)==valid['seeded_lines'] and (n,score)==(valid['seeded_matches'],valid['seeded_checksum']) and dump==(r/'checks/expected.captures').read_bytes()
parsers=runpy.run_path(str(r/'sources/after/benchmarks/dependency_profile.py'));profile_totals={}
for engine in ('before','after','rust'):
 profile_totals[engine]={}
 for suffix,rounds in (('',16),('-zero',0)):
  d=r/'profiles'/(engine+suffix);pr=json.loads((d/'provenance.json').read_bytes());sm=json.loads((d/'summary.json').read_bytes())
  assert pr['status']=='passed' and pr['input_guards_passed']
  profile_totals[engine][str(rounds)]={}
  for x in sm['runs']:
   raw=parsers[x['tool']](d/(engine+'.'+x['tool']+'.trace'));assert all(x[k]==v for k,v in raw.items())
   if x['tool']=='callgrind':profile_totals[engine][str(rounds)]['instructions']=raw['total_instructions']
   else:
    for head,key in [('allocated_blocks','tbk'),('allocated_bytes','tb'),('peak_live_bytes','gb')]:profile_totals[engine][str(rounds)][head]=raw['totals'][key]
   assert x['command'][-2:]==[str(rounds),'checksum'] and x['returncode']==0 and hashfn(d/(engine+'.'+x['tool']+'.trace'))==x['trace_sha256'] and hashfn(d/(engine+'.'+x['tool']+'.log'))==x['log_sha256']
"""
 report=report.replace("'all_time_targets_met':","'profile_totals':profile_totals,'all_time_targets_met':");replay.write_text(prefix+suffix+'\nprint(json.dumps('+report);idx['initial_archive_sha256']=sha(base);idx['files']={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(root.rglob('*')) if p.is_file() and p!=root/'manifest.json'}
 (root/'manifest.json').write_text(json.dumps(idx,indent=2)+'\n')
 result=subprocess.check_output([sys.executable,'-B',replay],cwd=root);(s/'portable-audit.json').write_bytes(result)
 target=s/'evidence-complete.tar.xz'
 with tarfile.open(target,'w:xz',preset=6) as t:
  for p in sorted(root.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:t.add(p,arcname=str(p.relative_to(root)),recursive=False)
 (s/'complete-manifest.json').write_text(json.dumps(idx,indent=2)+'\n')
 print(len(idx['files']),target.stat().st_size,sha(target),flush=True)
