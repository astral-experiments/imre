
## [Typing conformance results](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/) improved 🎉

The percentage of diagnostics emitted that were expected errors increased from <b>94.49%</b> to <b>98.24%</b>. The percentage of expected errors that received a diagnostic increased from <b>89.24%</b> to <b>98.24%</b>. The number of fully passing files improved from <b>103/146</b> to <b>134/146</b>.

### Summary

<details>
<summary>How are test cases classified?</summary>

<br>

Each test case represents one expected error annotation or a group of annotations sharing a tag. Counts are per test case, not per diagnostic — multiple diagnostics on the same line count as one. Required annotations (`E`) are true positives when ty flags the expected location and false negatives when it does not. Optional annotations (`E?`) are true positives when flagged but true negatives (not false negatives) when not. Tagged annotations (`E[tag]`) require ty to flag exactly one of the tagged lines; tagged multi-annotations (`E[tag+]`) allow any number up to the tag count. Flagging unexpected locations counts as a false positive.

</details>

| Metric | Old | New | Diff | Outcome |
|--------|-----|-----|------|---------|
| True Positives  | 1012 | 1116 | +104 | ⏫ (✅) |
| False Positives | 59 | 20 | -39 | ⏬ (✅) |
| False Negatives | 122 | 20 | -102 | ⏬ (✅) |
| Total Diagnostics | 1148 | 1180 | +32 | ⏫ |
| Precision | 94.49% | 98.24% | +3.75% | ⏫ (✅) |
| Recall | 89.24% | 98.24% | +9.00% | ⏫ (✅) |
| Passing Files | 103/146 | 134/146 | +31 | ⏫ (✅) |



### Test file breakdown

<details>
<summary>37 files altered</summary>

| File | True Positives | False Positives | False Negatives | Status |
|------|----|----|----|--------|
| [generics_typevartuple_variance.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py) | 26 (+11) ✅ | 0 (-8) ✅ | 0 (-11) ✅ | ✅ Newly Passing 🎉 |
| [generics_typevartuple_specialization.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py) | 6 (+4) ✅ | 0 (-15) ✅ | 0 (-4) ✅ | ✅ Newly Passing 🎉 |
| [aliases_recursive.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py) | 11 (+11) ✅ | 0 | 0 (-11) ✅ | ✅ Newly Passing 🎉 |
| [generics_typevartuple_basic.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py) | 14 (+10) ✅ | 0 (-1) ✅ | 0 (-10) ✅ | ✅ Newly Passing 🎉 |
| [generics_typevartuple_args.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py) | 8 (+8) ✅ | 0 (-3) ✅ | 0 (-8) ✅ | ✅ Newly Passing 🎉 |
| [aliases_typealiastype.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py) | 23 (+8) ✅ | 0 | 0 (-7) ✅ | ✅ Newly Passing 🎉 |
| [directives_deprecated.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py) | 13 (+7) ✅ | 0 | 0 (-7) ✅ | ✅ Newly Passing 🎉 |
| [protocols_variance.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py) | 7 (+7) ✅ | 0 | 0 (-7) ✅ | ✅ Newly Passing 🎉 |
| [generics_type_erasure.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_type_erasure.py) | 6 (+4) ✅ | 0 | 0 (-4) ✅ | ✅ Newly Passing 🎉 |
| [dataclasses_slots.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_slots.py) | 5 (+3) ✅ | 0 | 0 (-3) ✅ | ✅ Newly Passing 🎉 |
| [generics_basic.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_basic.py) | 18 (+3) ✅ | 0 | 0 (-3) ✅ | ✅ Newly Passing 🎉 |
| [protocols_explicit.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_explicit.py) | 4 (+3) ✅ | 0 | 2 (-3) ✅ | 📈 Improving |
| [generics_typevartuple_callable.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_callable.py) | 1 (+1) ✅ | 0 (-3) ✅ | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [classes_override.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/classes_override.py) | 7 (+2) ✅ | 0 | 0 (-2) ✅ | ✅ Newly Passing 🎉 |
| [dataclasses_hash.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_hash.py) | 4 (+2) ✅ | 0 | 0 (-2) ✅ | ✅ Newly Passing 🎉 |
| [generics_paramspec_variance.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_paramspec_variance.py) | 22 (+2) ✅ | 0 | 0 (-2) ✅ | ✅ Newly Passing 🎉 |
| [generics_scoping.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_scoping.py) | 14 (+2) ✅ | 0 | 0 (-2) ✅ | ✅ Newly Passing 🎉 |
| [specialtypes_type.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/specialtypes_type.py) | 9 (+2) ✅ | 9 | 0 (-2) ✅ | 📈 Improving |
| [aliases_type_statement.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_type_statement.py) | 25 (+1) ✅ | 0 (-1) ✅ | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_defaults.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py) | 5 | 4 (-3) ✅ | 1 | 📈 Improving |
| [protocols_class_objects.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_class_objects.py) | 5 (+2) ✅ | 0 | 3 (-1) ✅ | 📈 Improving |
| [annotations_forward_refs.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/annotations_forward_refs.py) | 27 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [annotations_future_import.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/annotations_future_import.py) | 4 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [classes_classvar.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/classes_classvar.py) | 19 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [constructors_call_init.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/constructors_call_init.py) | 4 (+1) ✅ | 0 | 1 (-1) ✅ | 📈 Improving |
| [constructors_call_type.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/constructors_call_type.py) | 8 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [exceptions_context_managers.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/exceptions_context_managers.py) | 0 | 0 (-2) ✅ | 0 | ✅ Newly Passing 🎉 |
| [generics_paramspec_components.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_paramspec_components.py) | 16 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_self_usage.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_self_usage.py) | 11 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_typevartuple_unpack.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_unpack.py) | 1 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [protocols_merging.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_merging.py) | 6 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [qualifiers_final_annotation.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/qualifiers_final_annotation.py) | 28 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_defaults_specialization.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults_specialization.py) | 2 | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_mixed_variance_inference.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_mixed_variance_inference.py) | 3 | 0 (-1) ✅ | 0 | ✅ Newly Passing 🎉 |
| [generics_typevartuple_concat.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_concat.py) | 0 | 0 (-1) ✅ | 0 | ✅ Newly Passing 🎉 |
| [narrowing_typeis.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/narrowing_typeis.py) | 9 | 0 (-1) ✅ | 0 | ✅ Newly Passing 🎉 |
| [protocols_definition.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_definition.py) | 23 (+1) ✅ | 0 | 0 | ✅ Still Passing |
| **Total (all files)** | **1116 (+104) ✅** | **20 (-39) ✅** | **20 (-102) ✅** | 134/146 |

</details>


### True positives added (102)

<details>
<summary>102 diagnostics</summary>

<table>
<tr>
<th>Test case</th>
<th>Diff</th>
</tr>

<tr>
<td>

[aliases_recursive.py:19](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L19)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `dict[str, None | complex | str | list[Json] | dict[str, Json]]` is not assignable to `Json`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:20](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L20)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `list[None | complex | str | list[Json] | dict[str, Json]]` is not assignable to `Json`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:38](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L38)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `tuple[Literal[1], tuple[Literal["1"], Literal[1]], tuple[Literal[1], tuple[Literal[1], list[int]]]]` is not assignable to `RecursiveTuple`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:39](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L39)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `tuple[Literal[1], list[int]]` is not assignable to `RecursiveTuple`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:50](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L50)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `dict[str, list[int]]` is not assignable to `RecursiveMapping`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:51](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L51)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `dict[str, str | int | list[int]]` is not assignable to `RecursiveMapping`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:52](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L52)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `dict[str, str | int | dict[str, str | int | list[int]]]` is not assignable to `RecursiveMapping`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:63](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L63)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `list[list[GenericTypeAlias1[str] | str] | str | list[list[GenericTypeAlias1[str] | str] | str | float]]` is not assignable to `GenericTypeAlias1[str]`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:69](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L69)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `list[list[GenericTypeAlias2[str, int] | str | int] | str | int | list[list[GenericTypeAlias2[str, int] | str | int] | str | int | list[list[GenericTypeAlias2[str, int] | str | int] | str | int | list[list[GenericTypeAlias2[str, int] | str | int] | str | float]]]]` is not assignable to `GenericTypeAlias2[str, int]`
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:72](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L72)

</td>

<td>

```diff
+error[cyclic-type-alias-definition] Type alias `RecursiveUnion` has a circular definition
```

</td>
</tr>

<tr>
<td>

[aliases_recursive.py:75](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py#L75)

</td>

<td>

```diff
+error[cyclic-type-alias-definition] Type alias `MutualReference1` has a circular definition
+error[cyclic-type-alias-definition] Type alias `MutualReference2` has a circular definition
```

</td>
</tr>

<tr>
<td>

[aliases_type_statement.py:75](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_type_statement.py#L75)

</td>

<td>

```diff
+error[cyclic-type-alias-definition] Type alias `RecursiveTypeAlias4` has a circular definition
```

</td>
</tr>

<tr>
<td>

[aliases_typealiastype.py:40](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py#L40)

</td>

<td>

```diff
+error[invalid-type-arguments] Type `int` is not assignable to upper bound `str` of type variable `TStr@GoodAlias5`
```

</td>
</tr>

<tr>
<td>

[aliases_typealiastype.py:43](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py#L43)

</td>

<td>

```diff
+error[invalid-type-alias-type] Type parameter `S` used in the alias value must be included in `type_params`
```

</td>
</tr>

<tr>
<td>

[aliases_typealiastype.py:44](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py#L44)

</td>

<td>

```diff
+error[invalid-type-alias-type] Type parameter `S` used in the alias value must be included in `type_params`
```

</td>
</tr>

<tr>
<td>

[aliases_typealiastype.py:45](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py#L45)

</td>

<td>

```diff
+error[invalid-type-alias-type] The `type_params` argument to `TypeAliasType` must be a tuple literal
```

</td>
</tr>

<tr>
<td>

[aliases_typealiastype.py:46](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py#L46)

</td>

<td>

```diff
+error[cyclic-type-alias-definition] Type alias `BadAlias4` has a circular definition
```

</td>
</tr>

<tr>
<td>

[aliases_typealiastype.py:47](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py#L47)

</td>

<td>

```diff
+error[cyclic-type-alias-definition] Type alias `BadAlias5` has a circular definition
```

</td>
</tr>

<tr>
<td>

[aliases_typealiastype.py:48](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py#L48)

</td>

<td>

```diff
+error[cyclic-type-alias-definition] Type alias `BadAlias6` has a circular definition
```

</td>
</tr>

<tr>
<td>

[annotations_forward_refs.py:94](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/annotations_forward_refs.py#L94)

</td>

<td>

```diff
+error[invalid-type-form] Variable of type `Literal[""]` is not allowed in a type expression
```

</td>
</tr>

<tr>
<td>

[annotations_future_import.py:37](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/annotations_future_import.py#L37)

</td>

<td>

```diff
+error[invalid-type-form] Variable of type `Literal[""]` is not allowed in a type expression
```

</td>
</tr>

<tr>
<td>

[classes_classvar.py:94](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/classes_classvar.py#L94)

</td>

<td>

```diff
+error[invalid-named-tuple] Type qualifier `ClassVar` is not allowed on NamedTuple field `b`
```

</td>
</tr>

<tr>
<td>

[classes_override.py:135](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/classes_override.py#L135)

</td>

<td>

```diff
+error[invalid-method-override] Invalid override of method `__init__`: Definition is incompatible with `ParentC.__init__`
```

</td>
</tr>

<tr>
<td>

[classes_override.py:138](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/classes_override.py#L138)

</td>

<td>

```diff
+error[invalid-method-override] Invalid override of method `__new__`: Definition is incompatible with `ParentC.__new__`
```

</td>
</tr>

<tr>
<td>

[constructors_call_init.py:107](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/constructors_call_init.py#L107)

</td>

<td>

```diff
+error[invalid-init-type-variable] First parameter of `__init__` cannot use type variable `T2` from an outer scope
+error[invalid-init-type-variable] First parameter of `__init__` cannot use type variable `T1` from an outer scope
```

</td>
</tr>

<tr>
<td>

[constructors_call_type.py:64](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/constructors_call_type.py#L64)

</td>

<td>

```diff
+error[too-many-positional-arguments] Too many positional arguments to `type[T]`: expected 0, got 1
```

</td>
</tr>

<tr>
<td>

[dataclasses_hash.py:18](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_hash.py#L18)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `DC1` is not assignable to `Hashable`
```

</td>
</tr>

<tr>
<td>

[dataclasses_hash.py:40](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_hash.py#L40)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `DC3` is not assignable to `Hashable`
```

</td>
</tr>

<tr>
<td>

[dataclasses_slots.py:25](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_slots.py#L25)

</td>

<td>

```diff
+error[unresolved-attribute] Unresolved attribute `y` on type `Self@__init__`
```

</td>
</tr>

<tr>
<td>

[dataclasses_slots.py:38](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_slots.py#L38)

</td>

<td>

```diff
+error[unresolved-attribute] Unresolved attribute `y` on type `Self@__init__`
```

</td>
</tr>

<tr>
<td>

[dataclasses_slots.py:11](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_slots.py#L11)

</td>

<td>

```diff
+error[invalid-dataclass] Dataclass `DC1` cannot combine `slots=True` with manually assigned `__slots__`
```

</td>
</tr>

<tr>
<td>

[directives_deprecated.py:30](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py#L30)

</td>

<td>

```diff
+error[deprecated] The overload of `foo` is Only str will be allowed
```

</td>
</tr>

<tr>
<td>

[directives_deprecated.py:41](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py#L41)

</td>

<td>

```diff
+error[deprecated] The function `__add__` is There is enough spam in the world
```

</td>
</tr>

<tr>
<td>

[directives_deprecated.py:42](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py#L42)

</td>

<td>

```diff
+error[deprecated] The function `__add__` is There is enough spam in the world
```

</td>
</tr>

<tr>
<td>

[directives_deprecated.py:44](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py#L44)

</td>

<td>

```diff
+error[deprecated] The function `greasy` is All spam will be equally greasy
```

</td>
</tr>

<tr>
<td>

[directives_deprecated.py:47](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py#L47)

</td>

<td>

```diff
+error[deprecated] The function `shape` is Shapes are becoming immutable
```

</td>
</tr>

<tr>
<td>

[directives_deprecated.py:48](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py#L48)

</td>

<td>

```diff
+error[deprecated] The function `shape` is Shapes are becoming immutable
```

</td>
</tr>

<tr>
<td>

[directives_deprecated.py:58](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py#L58)

</td>

<td>

```diff
+error[deprecated] The function `__call__` is Deprecated
```

</td>
</tr>

<tr>
<td>

[generics_basic.py:40](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_basic.py#L40)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `concat` is incorrect: Inferred lower bound `str | bytes` does not satisfy constraints (`str`, `bytes`) of type variable `AnyStr`
```

</td>
</tr>

<tr>
<td>

[generics_basic.py:41](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_basic.py#L41)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `concat` is incorrect: Inferred lower bound `bytes | str` does not satisfy constraints (`str`, `bytes`) of type variable `AnyStr`
```

</td>
</tr>

<tr>
<td>

[generics_basic.py:69](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_basic.py#L69)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `concat` is incorrect: Inferred lower bound `MyStr | bytes` does not satisfy constraints (`str`, `bytes`) of type variable `AnyStr`
```

</td>
</tr>

<tr>
<td>

[generics_defaults_specialization.py:58](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults_specialization.py#L58)

</td>

<td>

```diff
+error[not-subscriptable] Cannot specialize non-generic class `Foo`
```

</td>
</tr>

<tr>
<td>

[generics_paramspec_components.py:30](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_paramspec_components.py#L30)

</td>

<td>

```diff
+error[unbound-type-variable] ParamSpec `P` is not in scope
```

</td>
</tr>

<tr>
<td>

[generics_paramspec_variance.py:117](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_paramspec_variance.py#L117)

</td>

<td>

```diff
+error[invalid-generic-class] Variance of type variable `InP` is incompatible with method `out_f`
```

</td>
</tr>

<tr>
<td>

[generics_paramspec_variance.py:126](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_paramspec_variance.py#L126)

</td>

<td>

```diff
+error[invalid-generic-class] Variance of type variable `OutP` is incompatible with method `in_f`
```

</td>
</tr>

<tr>
<td>

[generics_scoping.py:107](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_scoping.py#L107)

</td>

<td>

```diff
+error[unbound-type-variable] Type variable `T` is not bound to any outer generic context
```

</td>
</tr>

<tr>
<td>

[generics_scoping.py:98](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_scoping.py#L98)

</td>

<td>

```diff
+error[invalid-type-form] Type alias cannot capture class-scoped type variable `T`
```

</td>
</tr>

<tr>
<td>

[generics_self_usage.py:82](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_self_usage.py#L82)

</td>

<td>

```diff
+error[invalid-type-form] `Self` requires `self: Self` or `cls: type[Self]` for annotated receivers
```

</td>
</tr>

<tr>
<td>

[generics_type_erasure.py:42](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_type_erasure.py#L42)

</td>

<td>

```diff
+error[invalid-attribute-access] Cannot access generic instance attribute `label` through a class
```

</td>
</tr>

<tr>
<td>

[generics_type_erasure.py:43](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_type_erasure.py#L43)

</td>

<td>

```diff
+error[invalid-attribute-access] Cannot access generic instance attribute `label` through a class
```

</td>
</tr>

<tr>
<td>

[generics_type_erasure.py:44](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_type_erasure.py#L44)

</td>

<td>

```diff
+error[invalid-attribute-access] Cannot access generic instance attribute `label` through a class
```

</td>
</tr>

<tr>
<td>

[generics_type_erasure.py:45](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_type_erasure.py#L45)

</td>

<td>

```diff
+error[invalid-attribute-access] Cannot access generic instance attribute `label` through a class
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:33](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L33)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `exec_le` is incorrect: Expected `Env`, found `Literal[""]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:34](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L34)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `exec_le` is incorrect: Expected `Env`, found `Literal[""]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:48](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L48)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `func1` is incorrect: Expected `int`, found `Literal["2"]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:57](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L57)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `func2` is incorrect: Expected `str`, found `Literal[1]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:58](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L58)

</td>

<td>

```diff
+error[missing-argument] No argument provided for required parameter `*args` of function `func2`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:59](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L59)

</td>

<td>

```diff
+error[missing-argument] No argument provided for required parameter `*args` of function `func2`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:67](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L67)

</td>

<td>

```diff
+error[missing-argument] No argument provided for required parameter `*args` of function `func3`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:75](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L75)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `func4` is incorrect: Expected `tuple[Literal[0]]`, found `tuple[Literal[1], Literal[2]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:100](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L100)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `multiply` is incorrect: Expected `Array[Height | Width]`, found `Array[Height]`
+error[invalid-argument-type] Argument to function `multiply` is incorrect: Expected `Array[Height | Width]`, found `Array[Width]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:101](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L101)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `multiply` is incorrect: Expected `Array[Height]`, found `Array[Height, Width]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:107](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L107)

</td>

<td>

```diff
+error[invalid-generic-class] Only one `TypeVarTuple` parameter is allowed in a `Generic` subscription
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:111](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L111)

</td>

<td>

```diff
+error[invalid-type-form] Generic class `Array4` cannot have multiple `TypeVarTuple` type parameters: `Ts2` is an additional TypeVarTuple
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:44](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L44)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to `Array.__init__` is incorrect: Expected `tuple[Batch, Height, Width]`, found `tuple[Batch, Width]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:54](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L54)

</td>

<td>

```diff
+error[invalid-type-form] Bare TypeVarTuple `Shape` is not valid in this context in a parameter annotation
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:57](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L57)

</td>

<td>

```diff
+error[invalid-type-form] Bare TypeVarTuple `Shape` is not valid in this context in a return type annotation
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:60](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L60)

</td>

<td>

```diff
+error[invalid-type-form] Bare TypeVarTuple `Shape` is not valid in this context in a parameter annotation
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:91](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L91)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `func2` is incorrect: Expected `tuple[Literal[0], Literal[0]]`, found `tuple[Literal[0]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:45](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L45)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `Array[Time, Batch, Width, Height]` is not assignable to `Array[Time, Batch, Height, Width]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_callable.py:26](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_callable.py#L26)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to `Process.__init__` is incorrect: Expected `(int | Literal[""], str | Literal[0], /) -> None`, found `def func1(arg1: int, arg2: str) -> None`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:109](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L109)

</td>

<td>

```diff
+error[invalid-type-form] `*` can only unpack a tuple type or `TypeVarTuple`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:110](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L110)

</td>

<td>

```diff
+error[invalid-type-form] `Unpack` can only be used with a fixed tuple type in this context
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:127](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L127)

</td>

<td>

```diff
+error[invalid-type-arguments] No type arguments provided for required type variables `T1`, `T2`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:163](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L163)

</td>

<td>

```diff
+error[invalid-type-form] A TypeVarTuple cannot be split to provide a fixed type argument
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_unpack.py:30](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_unpack.py#L30)

</td>

<td>

```diff
+error[invalid-argument-type] Argument to function `process_batch_channels` is incorrect: Expected `Array[*tuple[Batch, *tuple[Any, ...], Channels]]`, found `Array[Batch]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:107](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L107)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `InferredContravariantTypeVarTupleOld[int]` is not assignable to `InferredContravariantTypeVarTupleOld[object]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:116](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L116)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `InferredCovariantTypeVarTupleOld[object]` is not assignable to `InferredCovariantTypeVarTupleOld[int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:56](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L56)

</td>

<td>

```diff
+error[invalid-legacy-type-variable] A `TypeVarTuple` cannot be both covariant and contravariant
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:57](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L57)

</td>

<td>

```diff
+error[invalid-legacy-type-variable] A `TypeVarTuple` cannot specify variance when `infer_variance=True`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:58](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L58)

</td>

<td>

```diff
+error[invalid-legacy-type-variable] A `TypeVarTuple` cannot specify variance when `infer_variance=True`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:68](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L68)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `InvariantTypeVarTupleOld[int]` is not assignable to `InvariantTypeVarTupleOld[object]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:69](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L69)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `InvariantTypeVarTupleOld[object]` is not assignable to `InvariantTypeVarTupleOld[int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:79](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L79)

</td>

<td>

```diff
+error[invalid-generic-class] Variance of type variable `InTs` is incompatible with method `out_f`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:83](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L83)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `ContravariantTypeVarTupleOld[int]` is not assignable to `ContravariantTypeVarTupleOld[object]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:90](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L90)

</td>

<td>

```diff
+error[invalid-generic-class] Variance of type variable `OutTs` is incompatible with method `in_f`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:97](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L97)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `CovariantTypeVarTupleOld[object]` is not assignable to `CovariantTypeVarTupleOld[int]`
```

</td>
</tr>

<tr>
<td>

[protocols_class_objects.py:74](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_class_objects.py#L74)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `<class 'ConcreteB'>` is not assignable to `ProtoB1`
```

</td>
</tr>

<tr>
<td>

[protocols_explicit.py:134](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_explicit.py#L134)

</td>

<td>

```diff
+error[call-non-callable] Cannot instantiate `Concrete5` with unimplemented abstract method `method1`
```

</td>
</tr>

<tr>
<td>

[protocols_explicit.py:164](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_explicit.py#L164)

</td>

<td>

```diff
+error[call-non-callable] Cannot instantiate `Concrete7A` with unimplemented abstract method `method1`
```

</td>
</tr>

<tr>
<td>

[protocols_explicit.py:60](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_explicit.py#L60)

</td>

<td>

```diff
+error[call-non-callable] Cannot instantiate `Point` with unimplemented abstract methods `intensity` and `transparency`
```

</td>
</tr>

<tr>
<td>

[protocols_merging.py:82](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_merging.py#L82)

</td>

<td>

```diff
+error[call-non-callable] Cannot instantiate `SizedAndClosable4` with unimplemented abstract method `close`
```

</td>
</tr>

<tr>
<td>

[protocols_variance.py:105](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py#L105)

</td>

<td>

```diff
+error[invalid-protocol] Type variable `T1` in protocol `Protocol12` should be covariant, but is invariant
```

</td>
</tr>

<tr>
<td>

[protocols_variance.py:22](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py#L22)

</td>

<td>

```diff
+error[invalid-protocol] Type variable `T1` in protocol `AnotherBox` should be covariant, but is invariant
```

</td>
</tr>

<tr>
<td>

[protocols_variance.py:41](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py#L41)

</td>

<td>

```diff
+error[invalid-protocol] Type variable `T3` in protocol `Protocol2` should be contravariant, but is invariant
```

</td>
</tr>

<tr>
<td>

[protocols_variance.py:57](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py#L57)

</td>

<td>

```diff
+error[invalid-protocol] Type variable `T1` in protocol `Protocol4` should be contravariant, but is invariant
```

</td>
</tr>

<tr>
<td>

[protocols_variance.py:67](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py#L67)

</td>

<td>

```diff
+error[invalid-protocol] Type variable `T1` in protocol `Protocol6` should be covariant, but is invariant
```

</td>
</tr>

<tr>
<td>

[protocols_variance.py:72](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py#L72)

</td>

<td>

```diff
+error[invalid-protocol] Type variable `T1_contra` in protocol `Protocol7` should be covariant, but is contravariant
```

</td>
</tr>

<tr>
<td>

[protocols_variance.py:62](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py#L62)

</td>

<td>

```diff
+error[invalid-protocol] Type variable `T1_co` in protocol `Protocol5` should be contravariant, but is covariant
```

</td>
</tr>

<tr>
<td>

[qualifiers_final_annotation.py:136](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/qualifiers_final_annotation.py#L136)

</td>

<td>

```diff
+error[invalid-named-tuple] Type qualifier `Final` is not allowed on NamedTuple field `b`
```

</td>
</tr>

<tr>
<td>

[specialtypes_type.py:144](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/specialtypes_type.py#L144)

</td>

<td>

```diff
+error[unresolved-attribute] Object of type `<special-form 'type[Any]'>` has no attribute `unknown`
```

</td>
</tr>

<tr>
<td>

[specialtypes_type.py:146](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/specialtypes_type.py#L146)

</td>

<td>

```diff
+error[unresolved-attribute] Object of type `<special-form 'type[Any]'>` has no attribute `unknown`
```

</td>
</tr>
</table>
</details>

### False positives removed (41)

<details>
<summary>41 diagnostics</summary>

<table>
<tr>
<th>Test case</th>
<th>Diff</th>
</tr>

<tr>
<td>

[aliases_type_statement.py:10](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_type_statement.py#L10)

</td>

<td>

```diff
-error[invalid-type-arguments] Too many type arguments: expected 2, got 3
-error[invalid-type-form] `...` is not allowed in this context in a type alias value
```

</td>
</tr>

<tr>
<td>

[exceptions_context_managers.py:50](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/exceptions_context_managers.py#L50)

</td>

<td>

```diff
-error[type-assertion-failure] Type `str` does not match asserted type `int | str`
```

</td>
</tr>

<tr>
<td>

[exceptions_context_managers.py:57](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/exceptions_context_managers.py#L57)

</td>

<td>

```diff
-error[type-assertion-failure] Type `str` does not match asserted type `int | str`
```

</td>
</tr>

<tr>
<td>

[generics_defaults.py:139](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L139)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[str, int]`
```

</td>
</tr>

<tr>
<td>

[generics_defaults.py:140](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L140)

</td>

<td>

```diff
-error[type-assertion-failure] Type `Class_TypeVarTuple` does not match asserted type `@Todo`
```

</td>
</tr>

<tr>
<td>

[generics_defaults.py:200](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L200)

</td>

<td>

```diff
-error[invalid-type-form] The first argument to `Callable` must be either a list of types, ParamSpec, Concatenate, or `...`
```

</td>
</tr>

<tr>
<td>

[generics_defaults.py:207](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L207)

</td>

<td>

```diff
-error[type-assertion-failure] Type `@Todo` does not match asserted type `tuple[int, str]`
```

</td>
</tr>

<tr>
<td>

[generics_defaults.py:208](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L208)

</td>

<td>

```diff
-error[type-assertion-failure] Type `@Todo` does not match asserted type `(bytes, /) -> None`
```

</td>
</tr>

<tr>
<td>

[generics_mixed_variance_inference.py:17](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_mixed_variance_inference.py#L17)

</td>

<td>

```diff
-error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
-error[invalid-type-arguments] Too many type arguments to class `Mixed`: expected 2, got 3
-error[invalid-type-form] List literals are not allowed in this context in a type expression
-error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
-error[invalid-type-arguments] Too many type arguments to class `Mixed`: expected 2, got 3
-error[invalid-type-form] List literals are not allowed in this context in a type expression
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:29](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L29)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int, str]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:31](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L31)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[()]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_args.py:32](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py#L32)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int, str]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:85](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L85)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_callable.py:41](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_callable.py#L41)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[str, int, int | float | complex]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_callable.py:42](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_callable.py#L42)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[str]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_callable.py:50](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_callable.py#L50)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int | float | complex, str, int | float]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_concat.py:53](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_concat.py#L53)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int, bool, str]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:135](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L135)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown]` does not match asserted type `tuple[tuple[()], str, bool]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:136](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L136)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown]` does not match asserted type `tuple[tuple[str], bool, int | float]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:137](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L137)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown]` does not match asserted type `tuple[tuple[str, bool], int | float, int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:148](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L148)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown, Unknown]` does not match asserted type `tuple[tuple[()], str, bool, int | float]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:149](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L149)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown, Unknown]` does not match asserted type `tuple[tuple[bool], str, int | float, int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:157](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L157)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[*tuple[int, ...], int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:158](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L158)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[*tuple[int, ...], str]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:159](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L159)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[*tuple[int, ...], str]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:45](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L45)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'tuple[str, @Todo]'>`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:46](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L46)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int, int | float, bool]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:47](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L47)

</td>

<td>

```diff
-error[type-assertion-failure] Type `Unknown` does not match asserted type `tuple[str, @Todo]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:51](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L51)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:93](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L93)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[str, int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:94](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L94)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int | float]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_specialization.py:95](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py#L95)

</td>

<td>

```diff
-error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[Any, *tuple[Any, ...]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:16](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L16)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:29](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L29)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:30](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L30)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:33](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L33)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:43](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L43)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:44](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L44)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:49](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L49)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:52](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L52)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
```

</td>
</tr>

<tr>
<td>

[narrowing_typeis.py:35](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/narrowing_typeis.py#L35)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `object` is not assignable to `int`
```

</td>
</tr>
</table>
</details>

### True positives changed (98)

<details>
<summary>98 diagnostics</summary>

<table>
<tr>
<th>Test case</th>
<th>Diff</th>
</tr>

<tr>
<td>

[aliases_implicit.py:81](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_implicit.py#L81)

</td>

<td>

```diff
-error[invalid-type-arguments] Type `str` is not assignable to upper bound `int | float` of type variable `TFloat@GoodTypeAlias12`
+error[invalid-type-arguments] Type `str` is not assignable to upper bound `float` of type variable `TFloat@GoodTypeAlias12`
```

</td>
</tr>

<tr>
<td>

[aliases_newtype.py:23](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_newtype.py#L23)

</td>

<td>

```diff
-error[invalid-argument-type] Argument to function `isinstance` is incorrect: Expected `type | UnionType | tuple[Divergent, ...]`, found `<NewType pseudo-class 'UserId'>`
+error[invalid-argument-type] Argument to function `isinstance` is incorrect: Expected `_ClassInfo`, found `<NewType pseudo-class 'UserId'>`
```

</td>
</tr>

<tr>
<td>

[aliases_type_statement.py:31](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_type_statement.py#L31)

</td>

<td>

```diff
-error[invalid-argument-type] Argument to function `isinstance` is incorrect: Expected `type | UnionType | tuple[Divergent, ...]`, found `TypeAliasType`
+error[invalid-argument-type] Argument to function `isinstance` is incorrect: Expected `_ClassInfo`, found `TypeAliasType`
```

</td>
</tr>

<tr>
<td>

[aliases_type_statement.py:73](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_type_statement.py#L73)

</td>

<td>

```diff
-error[cyclic-type-alias-definition] Cyclic definition of `RecursiveTypeAlias3`
+error[cyclic-type-alias-definition] Type alias `RecursiveTypeAlias3` has a circular definition
```

</td>
</tr>

<tr>
<td>

[aliases_type_statement.py:79:80](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_type_statement.py#L79-L80)

</td>

<td>

```diff
-error[cyclic-type-alias-definition] Cyclic definition of `RecursiveTypeAlias6`
-error[cyclic-type-alias-definition] Cyclic definition of `RecursiveTypeAlias7`
+error[cyclic-type-alias-definition] Type alias `RecursiveTypeAlias6` has a circular definition
+error[cyclic-type-alias-definition] Type alias `RecursiveTypeAlias7` has a circular definition
```

</td>
</tr>

<tr>
<td>

[callables_protocol.py:121](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/callables_protocol.py#L121)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `def cb6_bad1(*vals: bytes, *, max_len: int | None = None) -> list[bytes]` is not assignable to `NotProto6`
+error[invalid-assignment] Object of type `def cb6_bad1(*vals: bytes, max_len: int | None = None) -> list[bytes]` is not assignable to `NotProto6`
```

</td>
</tr>

<tr>
<td>

[callables_protocol.py:260](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/callables_protocol.py#L260)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `def cb12_bad1(*args: Any, *, kwarg0: Any) -> None` is not assignable to `Proto12`
+error[invalid-assignment] Object of type `def cb12_bad1(*args: Any, kwarg0: Any) -> None` is not assignable to `Proto12`
```

</td>
</tr>

<tr>
<td>

[callables_protocol.py:35](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/callables_protocol.py#L35)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `def cb1_bad1(*vals: bytes, *, max_items: int | None) -> list[bytes]` is not assignable to `Proto1`
+error[invalid-assignment] Object of type `def cb1_bad1(*vals: bytes, max_items: int | None) -> list[bytes]` is not assignable to `Proto1`
```

</td>
</tr>

<tr>
<td>

[callables_protocol.py:37](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/callables_protocol.py#L37)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `def cb1_bad3(*vals: bytes, *, max_len: str | None) -> list[bytes]` is not assignable to `Proto1`
+error[invalid-assignment] Object of type `def cb1_bad3(*vals: bytes, max_len: str | None) -> list[bytes]` is not assignable to `Proto1`
```

</td>
</tr>

<tr>
<td>

[callables_subtyping.py:26](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/callables_subtyping.py#L26)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `(int, /) -> int` is not assignable to `(int | float, /) -> int | float`
+error[invalid-assignment] Object of type `(int, /) -> int` is not assignable to `(float, /) -> float`
```

</td>
</tr>

<tr>
<td>

[callables_subtyping.py:29](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/callables_subtyping.py#L29)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `(int | float, /) -> int | float` is not assignable to `(int, /) -> int`
+error[invalid-assignment] Object of type `(float, /) -> float` is not assignable to `(int, /) -> int`
```

</td>
</tr>

<tr>
<td>

[constructors_call_init.py:21](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/constructors_call_init.py#L21)

</td>

<td>

```diff
-error[invalid-argument-type] Argument to `Class1.__init__` is incorrect: Expected `int`, found `float`
+error[invalid-argument-type] Argument to `Class1.__init__` is incorrect: Expected `int`, found `float*`
```

</td>
</tr>

<tr>
<td>

[constructors_call_new.py:21](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/constructors_call_new.py#L21)

</td>

<td>

```diff
-error[invalid-argument-type] Argument to constructor `Class1.__new__` is incorrect: Expected `int`, found `float`
+error[invalid-argument-type] Argument to constructor `Class1.__new__` is incorrect: Expected `int`, found `float*`
```

</td>
</tr>

<tr>
<td>

[dataclasses_transform_converter.py:109](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_transform_converter.py#L109)

</td>

<td>

```diff
-error[invalid-argument-type] Argument is incorrect: Expected `str | list[str]`, found `complex`
+error[invalid-argument-type] Argument is incorrect: Expected `str | list[str]`, found `complex*`
```

</td>
</tr>

<tr>
<td>

[dataclasses_usage.py:52](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_usage.py#L52)

</td>

<td>

```diff
-error[invalid-argument-type] Argument is incorrect: Expected `int | float`, found `Literal["price"]`
+error[invalid-argument-type] Argument is incorrect: Expected `float`, found `Literal["price"]`
```

</td>
</tr>

<tr>
<td>

[generics_basic.py:241](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_basic.py#L241)

</td>

<td>

```diff
-error[invalid-argument-type] Argument to function `takes_two_int_lists` is incorrect: Argument type `int | str` does not satisfy upper bound `int` of type variable `T_int`
-error[invalid-argument-type] Argument to function `takes_two_int_lists` is incorrect: Expected `list[int]`, found `list[int | str]`
+error[invalid-argument-type] Argument to function `takes_two_int_lists` is incorrect: Argument type `int | str` does not satisfy upper bound `int` of type variable `T_int`
```

</td>
</tr>

<tr>
<td>

[generics_mixed_variance_inference.py:16](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_mixed_variance_inference.py#L16)

</td>

<td>

```diff
-error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
-error[invalid-type-arguments] Too many type arguments to class `Mixed`: expected 2, got 3
-error[invalid-type-form] List literals are not allowed in this context in a type expression
-error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
-error[invalid-type-arguments] Too many type arguments to class `Mixed`: expected 2, got 3
-error[invalid-type-form] List literals are not allowed in this context in a type expression
+error[invalid-assignment] Object of type `Mixed[int, object, ()]` is not assignable to `Mixed[int, int, ()]`
```

</td>
</tr>

<tr>
<td>

[generics_self_usage.py:108](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_self_usage.py#L108)

</td>

<td>

```diff
-error[invalid-type-form] `Self` cannot be used in a type alias
+error[invalid-type-form] Variable of type `<special-form 'typing.Self'>` is not allowed in a type expression
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:112](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L112)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant1[int]` is not assignable to `ShouldBeInvariant1[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant1[int]` is not assignable to `ShouldBeInvariant1[float]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:113](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L113)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant1[int | float]` is not assignable to `ShouldBeInvariant1[int]`
+error[invalid-assignment] Object of type `ShouldBeInvariant1[float]` is not assignable to `ShouldBeInvariant1[int]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:127](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L127)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant2[int]` is not assignable to `ShouldBeInvariant2[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant2[int]` is not assignable to `ShouldBeInvariant2[float]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:128](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L128)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant2[int | float]` is not assignable to `ShouldBeInvariant2[int]`
+error[invalid-assignment] Object of type `ShouldBeInvariant2[float]` is not assignable to `ShouldBeInvariant2[int]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:135](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L135)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant3[int, str]` is not assignable to `ShouldBeInvariant3[int | float, str]`
+error[invalid-assignment] Object of type `ShouldBeInvariant3[int, str]` is not assignable to `ShouldBeInvariant3[float, str]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:136](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L136)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant3[int | float, str]` is not assignable to `ShouldBeInvariant3[int, str]`
+error[invalid-assignment] Object of type `ShouldBeInvariant3[float, str]` is not assignable to `ShouldBeInvariant3[int, str]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:137](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L137)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int]` is not assignable to `ShouldBeInvariant3[str, int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int]` is not assignable to `ShouldBeInvariant3[str, float]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:138](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L138)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int | float]` is not assignable to `ShouldBeInvariant3[str, int]`
+error[invalid-assignment] Object of type `ShouldBeInvariant3[str, float]` is not assignable to `ShouldBeInvariant3[str, int]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:146](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L146)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant4[int]` is not assignable to `ShouldBeInvariant4[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant4[int]` is not assignable to `ShouldBeInvariant4[float]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:154](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L154)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant5[int]` is not assignable to `ShouldBeInvariant5[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant5[int]` is not assignable to `ShouldBeInvariant5[float]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:165](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L165)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeContravariant1[int]` is not assignable to `ShouldBeContravariant1[int | float]`
+error[invalid-assignment] Object of type `ShouldBeContravariant1[int]` is not assignable to `ShouldBeContravariant1[float]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:29](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L29)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant1[int | float]` is not assignable to `ShouldBeCovariant1[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant1[float]` is not assignable to `ShouldBeCovariant1[int]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:47](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L47)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant2[int | float]` is not assignable to `ShouldBeCovariant2[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant2[float]` is not assignable to `ShouldBeCovariant2[int]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:56](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L56)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant3[int | float]` is not assignable to `ShouldBeCovariant3[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant3[float]` is not assignable to `ShouldBeCovariant3[int]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:85](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L85)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant5[int | float]` is not assignable to `ShouldBeCovariant5[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant5[float]` is not assignable to `ShouldBeCovariant5[int]`
```

</td>
</tr>

<tr>
<td>

[generics_syntax_infer_variance.py:96](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_syntax_infer_variance.py#L96)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant6[int | float]` is not assignable to `ShouldBeCovariant6[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant6[float]` is not assignable to `ShouldBeCovariant6[int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:43](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L43)

</td>

<td>

```diff
-error[invalid-argument-type] Argument to `Array.__init__` is incorrect: Expected `tuple[@Todo(TypeVarTuple), ...]`, found `Height`
+error[invalid-argument-type] Argument to `Array.__init__` is incorrect: Expected `tuple[Height, Width]`, found `Height`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:66](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L66)

</td>

<td>

```diff
-error[too-many-positional-arguments] Too many positional arguments to constructor `TypeVarTuple.__new__`: expected 2, got 4
+error[invalid-legacy-type-variable] `TypeVarTuple` can only have one positional argument
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_basic.py:67](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py#L67)

</td>

<td>

```diff
-error[unknown-argument] Argument `bound` does not match any known parameter of constructor `TypeVarTuple.__new__`
+error[invalid-legacy-type-variable] The `bound` parameter of `typing.TypeVarTuple` was added in Python 3.15
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:14](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L14)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `InvariantTypeVarTuple[int]` is not assignable to `InvariantTypeVarTuple[object]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:15](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L15)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `InvariantTypeVarTuple[object]` is not assignable to `InvariantTypeVarTuple[int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:17](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L17)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `InvariantTypeVarTuple[*tuple[object, ...]]` is not assignable to `InvariantTypeVarTuple[*tuple[int, ...]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:18](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L18)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `InvariantTypeVarTuple[*tuple[int, ...]]` is not assignable to `InvariantTypeVarTuple[*tuple[object, ...]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:20](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L20)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `InvariantTypeVarTuple[*tuple[int, ...]]` is not assignable to `InvariantTypeVarTuple[int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:21](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L21)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `InvariantTypeVarTuple[int]` is not assignable to `InvariantTypeVarTuple[*tuple[int, ...]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:28](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L28)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `ContravariantTypeVarTuple[object, int]` is not assignable to `ContravariantTypeVarTuple[object, object]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:31](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L31)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `ContravariantTypeVarTuple[*tuple[int, ...]]` is not assignable to `ContravariantTypeVarTuple[*tuple[object, ...]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:34](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L34)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `ContravariantTypeVarTuple[int]` is not assignable to `ContravariantTypeVarTuple[*tuple[int, ...]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:42](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L42)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `CovariantTypeVarTuple[object]` is not assignable to `CovariantTypeVarTuple[int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:45](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L45)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `CovariantTypeVarTuple[bool, object]` is not assignable to `CovariantTypeVarTuple[int, int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:46](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L46)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `CovariantTypeVarTuple[object, bool]` is not assignable to `CovariantTypeVarTuple[int, int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:47](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L47)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `CovariantTypeVarTuple[object, object]` is not assignable to `CovariantTypeVarTuple[int, int]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:48](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L48)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `CovariantTypeVarTuple[*tuple[object, ...]]` is not assignable to `CovariantTypeVarTuple[*tuple[int, ...]]`
```

</td>
</tr>

<tr>
<td>

[generics_typevartuple_variance.py:51](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py#L51)

</td>

<td>

```diff
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
-error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+error[invalid-assignment] Object of type `CovariantTypeVarTuple[*tuple[int, ...]]` is not assignable to `CovariantTypeVarTuple[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:111](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L111)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant2[int]` is not assignable to `ShouldBeInvariant2[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant2[int]` is not assignable to `ShouldBeInvariant2[float]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:112](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L112)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant2[int | float]` is not assignable to `ShouldBeInvariant2[int]`
+error[invalid-assignment] Object of type `ShouldBeInvariant2[float]` is not assignable to `ShouldBeInvariant2[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:119](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L119)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant3[int, str]` is not assignable to `ShouldBeInvariant3[int | float, str]`
+error[invalid-assignment] Object of type `ShouldBeInvariant3[int, str]` is not assignable to `ShouldBeInvariant3[float, str]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:120](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L120)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant3[int | float, str]` is not assignable to `ShouldBeInvariant3[int, str]`
+error[invalid-assignment] Object of type `ShouldBeInvariant3[float, str]` is not assignable to `ShouldBeInvariant3[int, str]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:121](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L121)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int]` is not assignable to `ShouldBeInvariant3[str, int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int]` is not assignable to `ShouldBeInvariant3[str, float]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:122](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L122)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int | float]` is not assignable to `ShouldBeInvariant3[str, int]`
+error[invalid-assignment] Object of type `ShouldBeInvariant3[str, float]` is not assignable to `ShouldBeInvariant3[str, int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:130](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L130)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant4[int]` is not assignable to `ShouldBeInvariant4[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant4[int]` is not assignable to `ShouldBeInvariant4[float]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:138](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L138)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant5[int]` is not assignable to `ShouldBeInvariant5[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant5[int]` is not assignable to `ShouldBeInvariant5[float]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:149](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L149)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeContravariant1[int]` is not assignable to `ShouldBeContravariant1[int | float]`
+error[invalid-assignment] Object of type `ShouldBeContravariant1[int]` is not assignable to `ShouldBeContravariant1[float]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:169](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L169)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant6[int | float]` is not assignable to `ShouldBeInvariant6[int]`
+error[invalid-assignment] Object of type `ShouldBeInvariant6[float]` is not assignable to `ShouldBeInvariant6[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:170](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L170)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant6[int]` is not assignable to `ShouldBeInvariant6[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant6[int]` is not assignable to `ShouldBeInvariant6[float]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:181](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L181)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant6[int | float]` is not assignable to `ShouldBeCovariant6[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant6[float]` is not assignable to `ShouldBeCovariant6[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:194](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L194)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeContravariant2[int]` is not assignable to `ShouldBeContravariant2[int | float]`
+error[invalid-assignment] Object of type `ShouldBeContravariant2[int]` is not assignable to `ShouldBeContravariant2[float]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:24](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L24)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ClassA[int | float, int, int]` is not assignable to `ClassA[int, int, int]`
+error[invalid-assignment] Object of type `ClassA[float, int, int]` is not assignable to `ClassA[int, int, int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:25](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L25)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ClassA[int | float, int, int]` is not assignable to `ClassA[int | float, int | float, int]`
+error[invalid-assignment] Object of type `ClassA[float, int, int]` is not assignable to `ClassA[float, float, int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:28](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L28)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ClassA[int, int | float, int | float]` is not assignable to `ClassA[int, int, int]`
+error[invalid-assignment] Object of type `ClassA[int, float, float]` is not assignable to `ClassA[int, int, int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:41](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L41)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant1[int | float]` is not assignable to `ShouldBeCovariant1[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant1[float]` is not assignable to `ShouldBeCovariant1[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:49](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L49)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant2[int | float]` is not assignable to `ShouldBeCovariant2[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant2[float]` is not assignable to `ShouldBeCovariant2[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:58](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L58)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant3[int | float]` is not assignable to `ShouldBeCovariant3[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant3[float]` is not assignable to `ShouldBeCovariant3[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:67](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L67)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant4[int | float]` is not assignable to `ShouldBeCovariant4[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant4[float]` is not assignable to `ShouldBeCovariant4[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:80](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L80)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeCovariant5[int | float]` is not assignable to `ShouldBeCovariant5[int]`
+error[invalid-assignment] Object of type `ShouldBeCovariant5[float]` is not assignable to `ShouldBeCovariant5[int]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:96](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L96)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant1[int]` is not assignable to `ShouldBeInvariant1[int | float]`
+error[invalid-assignment] Object of type `ShouldBeInvariant1[int]` is not assignable to `ShouldBeInvariant1[float]`
```

</td>
</tr>

<tr>
<td>

[generics_variance_inference.py:97](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_variance_inference.py#L97)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `ShouldBeInvariant1[int | float]` is not assignable to `ShouldBeInvariant1[int]`
+error[invalid-assignment] Object of type `ShouldBeInvariant1[float]` is not assignable to `ShouldBeInvariant1[int]`
```

</td>
</tr>

<tr>
<td>

[literals_literalstring.py:133](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/literals_literalstring.py#L133)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `Container[T@Container]` is not assignable to `Container[LiteralString]`
-error[invalid-argument-type] Argument to `Container.__init__` is incorrect: Argument type `str` does not satisfy upper bound `LiteralString` of type variable `T`
-error[invalid-argument-type] Argument to `Container.__init__` is incorrect: Expected `LiteralString`, found `str`
+error[invalid-argument-type] Argument to `Container.__init__` is incorrect: Argument type `str` does not satisfy upper bound `LiteralString` of type variable `T`
```

</td>
</tr>

<tr>
<td>

[namedtuples_define_class.py:140](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/namedtuples_define_class.py#L140)

</td>

<td>

```diff
-error[invalid-argument-type] Argument is incorrect: Expected `str`, found `float`
+error[invalid-argument-type] Argument is incorrect: Expected `str`, found `float*`
```

</td>
</tr>

<tr>
<td>

[namedtuples_define_functional.py:43](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/namedtuples_define_functional.py#L43)

</td>

<td>

```diff
-error[invalid-argument-type] Argument is incorrect: Expected `int`, found `float`
+error[invalid-argument-type] Argument is incorrect: Expected `int`, found `float*`
```

</td>
</tr>

<tr>
<td>

[protocols_generic.py:56](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_generic.py#L56)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `Box[int | float]` is not assignable to `Box[int]`
+error[invalid-assignment] Object of type `Box[float]` is not assignable to `Box[int]`
```

</td>
</tr>

<tr>
<td>

[protocols_generic.py:66](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_generic.py#L66)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `Sender[int]` is not assignable to `Sender[int | float]`
+error[invalid-assignment] Object of type `Sender[int]` is not assignable to `Sender[float]`
```

</td>
</tr>

<tr>
<td>

[protocols_generic.py:74](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_generic.py#L74)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `AttrProto[int]` is not assignable to `AttrProto[int | float]`
+error[invalid-assignment] Object of type `AttrProto[int]` is not assignable to `AttrProto[float]`
```

</td>
</tr>

<tr>
<td>

[protocols_generic.py:75](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_generic.py#L75)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `AttrProto[int | float]` is not assignable to `AttrProto[int]`
+error[invalid-assignment] Object of type `AttrProto[float]` is not assignable to `AttrProto[int]`
```

</td>
</tr>

<tr>
<td>

[protocols_subtyping.py:102](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_subtyping.py#L102)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `Proto6[int | float, int | float]` is not assignable to `Proto7[int, int | float]`
+error[invalid-assignment] Object of type `Proto6[float, float]` is not assignable to `Proto7[int, float]`
```

</td>
</tr>

<tr>
<td>

[protocols_subtyping.py:103](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_subtyping.py#L103)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `Proto6[int | float, int | float]` is not assignable to `Proto7[int | float, object]`
+error[invalid-assignment] Object of type `Proto6[float, float]` is not assignable to `Proto7[float, object]`
```

</td>
</tr>

<tr>
<td>

[protocols_subtyping.py:79](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_subtyping.py#L79)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `Proto5[int]` is not assignable to `Proto4[int, int | float]`
+error[invalid-assignment] Object of type `Proto5[int]` is not assignable to `Proto4[int, float]`
```

</td>
</tr>

<tr>
<td>

[protocols_subtyping.py:80](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_subtyping.py#L80)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `Proto4[int, int]` is not assignable to `Proto5[int | float]`
+error[invalid-assignment] Object of type `Proto4[int, int]` is not assignable to `Proto5[float]`
```

</td>
</tr>

<tr>
<td>

[specialtypes_promotions.py:13](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/specialtypes_promotions.py#L13)

</td>

<td>

```diff
-error[unresolved-attribute] Attribute `numerator` is not defined on `float` in union `int | float`
+error[unresolved-attribute] Attribute `numerator` is not defined on `float*` in union `float`
```

</td>
</tr>

<tr>
<td>

[tuples_type_compat.py:15](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_compat.py#L15)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `tuple[int | float, int | float | complex]` is not assignable to `tuple[int, int]`
+error[invalid-assignment] Object of type `tuple[float, complex]` is not assignable to `tuple[int, int]`
```

</td>
</tr>

<tr>
<td>

[tuples_type_compat.py:170](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_compat.py#L170)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `tuple[Literal[1], Literal[""], Literal[""], float]` is not assignable to `tuple[int, *tuple[str, ...], int]`
+error[invalid-assignment] Object of type `tuple[Literal[1], Literal[""], Literal[""], float*]` is not assignable to `tuple[int, *tuple[str, ...], int]`
```

</td>
</tr>

<tr>
<td>

[tuples_type_compat.py:176](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_compat.py#L176)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `tuple[Literal[""], Literal[""], float]` is not assignable to `tuple[*tuple[str, ...], int]`
+error[invalid-assignment] Object of type `tuple[Literal[""], Literal[""], float*]` is not assignable to `tuple[*tuple[str, ...], int]`
```

</td>
</tr>

<tr>
<td>

[tuples_type_form.py:40](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_form.py#L40)

</td>

<td>

```diff
-error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
+error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
```

</td>
</tr>

<tr>
<td>

[tuples_type_form.py:41](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_form.py#L41)

</td>

<td>

```diff
-error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
+error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
```

</td>
</tr>

<tr>
<td>

[tuples_type_form.py:42](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_form.py#L42)

</td>

<td>

```diff
-error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
+error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
```

</td>
</tr>

<tr>
<td>

[tuples_type_form.py:43](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_form.py#L43)

</td>

<td>

```diff
-error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
+error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
```

</td>
</tr>

<tr>
<td>

[tuples_type_form.py:44](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_form.py#L44)

</td>

<td>

```diff
-error[invalid-type-form] Invalid `tuple` specialization: `...` cannot be used after an unpacked element
+error[invalid-type-form] Invalid `tuple` specialization: `...` cannot be used after an unpacked element
```

</td>
</tr>

<tr>
<td>

[tuples_type_form.py:45](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/tuples_type_form.py#L45)

</td>

<td>

```diff
-error[invalid-type-form] Invalid `tuple` specialization: `...` cannot be used after an unpacked element
+error[invalid-type-form] Invalid `tuple` specialization: `...` cannot be used after an unpacked element
```

</td>
</tr>

<tr>
<td>

[typeddicts_operations.py:29](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/typeddicts_operations.py#L29)

</td>

<td>

```diff
-error[invalid-argument-type] Invalid argument to key "year" with declared type `int` on TypedDict `Movie`: value of type `float`
+error[invalid-argument-type] Invalid argument to key "year" with declared type `int` on TypedDict `Movie`: value of type `float*`
```

</td>
</tr>

<tr>
<td>

[typeddicts_readonly_inheritance.py:119](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/typeddicts_readonly_inheritance.py#L119)

</td>

<td>

```diff
-error[invalid-typed-dict-field] Cannot overwrite TypedDict field `x` while merging base classes: Inherited mutable field type `int | float` is incompatible with `int`
+error[invalid-typed-dict-field] Cannot overwrite TypedDict field `x` while merging base classes: Inherited mutable field type `float` is incompatible with `int`
```

</td>
</tr>
</table>
</details>

### False positives changed (2)

<details>
<summary>2 diagnostics</summary>

<table>
<tr>
<th>Test case</th>
<th>Diff</th>
</tr>

<tr>
<td>

[generics_defaults.py:204](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L204)

</td>

<td>

```diff
-error[type-assertion-failure] Type `@Todo` does not match asserted type `tuple[int, str]`
+error[type-assertion-failure] Type `tuple[int]` does not match asserted type `tuple[int, str]`
```

</td>
</tr>

<tr>
<td>

[generics_defaults.py:205](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L205)

</td>

<td>

```diff
-error[type-assertion-failure] Type `@Todo` does not match asserted type `(int | float, bool, /) -> None`
+error[type-assertion-failure] Type `(...) -> None` does not match asserted type `(float, bool, /) -> None`
```

</td>
</tr>
</table>
</details>

### False positives added (2)

<details>
<summary>2 diagnostics</summary>

<table>
<tr>
<th>Test case</th>
<th>Diff</th>
</tr>

<tr>
<td>

[generics_defaults.py:144](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L144)

</td>

<td>

```diff
+error[invalid-type-form] `Unpack` can only unpack a tuple type or `TypeVarTuple`
```

</td>
</tr>

<tr>
<td>

[generics_defaults.py:203](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py#L203)

</td>

<td>

```diff
+error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
```

</td>
</tr>
</table>
</details>

### Optional Diagnostics Added (3)

<details>
<summary>3 diagnostics</summary>

<table>
<tr>
<th>Test case</th>
<th>Diff</th>
</tr>

<tr>
<td>

[aliases_typealiastype.py:49](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py#L49)

</td>

<td>

```diff
+error[cyclic-type-alias-definition] Type alias `BadAlias7` has a circular definition
```

</td>
</tr>

<tr>
<td>

[protocols_class_objects.py:108](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_class_objects.py#L108)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `<class 'ConcreteC3'>` is not assignable to `ProtoC1`
```

</td>
</tr>

<tr>
<td>

[protocols_definition.py:117](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_definition.py#L117)

</td>

<td>

```diff
+error[invalid-assignment] Object of type `Concrete2_Bad4` is not assignable to `Template2`
```

</td>
</tr>
</table>
</details>

### Optional Diagnostics Removed (1)

<details>
<summary>1 diagnostic</summary>

<table>
<tr>
<th>Test case</th>
<th>Diff</th>
</tr>

<tr>
<td>

[generics_defaults_specialization.py:48](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults_specialization.py#L48)

</td>

<td>

```diff
-error[invalid-assignment] Object of type `<class 'Bar'>` is not assignable to `type[Bar[int]]`
```

</td>
</tr>
</table>
</details>
