"""Recheck the fixed source corpus with shorter absolute names on the same pinned CPU."""
import argparse,hashlib,json,os,runpy,shutil,statistics,subprocess,sys,tempfile,time
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--cpu',type=int,default=31);a=p.parse_args();c=a.cache.resolve();ordinary=(c/'fixtures').resolve();record={'cpu':a.cpu,'input_root':str(ordinary),'panels':{},'roots':{}};directory=c/'path-sensitivity';directory.mkdir(exist_ok=False)
runner=runpy.run_path(str(c/'source/benchmarks/conformance_regex_benchmark.py'));val=runner['VALIDATION'];os.sched_setaffinity(0,{a.cpu});env=val['environment'](directory)
def sha(b):return hashlib.sha256(b).hexdigest()
def build_short(tmp):
 for scale in (1,10):
  long=ordinary/f'{scale}x';short=tmp/f'{scale}x';shared=short/'tests';shared.mkdir(parents=True)
  for f in (long/'tests').iterdir():
   dest=shared/f.name
   try:os.link(f,dest)
   except OSError:shutil.copy2(f,dest)
   assert dest.read_bytes()==f.read_bytes()
  panel=short/'changed';panel.mkdir()
  for name in ('manifest','old','new'):
   raw=(long/'changed'/(name+'.json')).read_bytes()
   altered=raw.replace(str(ordinary).encode(),str(tmp).encode());(panel/(name+'.json')).write_bytes(altered)
   assert altered.replace(str(tmp).encode(),str(ordinary).encode())==raw
  d=json.loads((panel/'manifest.json').read_bytes());assert all(Path(f).is_file() and str(Path(f).parent)==str(shared) for f in d['test_files']) and len(d['test_files'])==146*scale
def call(cmd): 
 t=time.perf_counter_ns();v=subprocess.run(cmd,capture_output=True,check=True,env=env);elapsed=time.perf_counter_ns()-t;assert not v.stderr;return elapsed,v.stdout
with tempfile.TemporaryDirectory(prefix='',dir='/tmp') as tmp:
 short=Path(tmp);build_short(short);record['short_root']=str(short)
 for mode in ('normal','thinlto'):
  cfg=json.loads((c/'configs'/mode/'config.json').read_bytes());record['revision']=cfg['revision']
  for scale,n in ((1,64),(10,12)):
   base={name:root/f'{scale}x'/'changed' for name,root in [('long',ordinary),('short',short)]};engines={}
   for e in ('after','rust'):
    for variant,data in base.items():
     args=[str(data/(role+'.json')) for role in ('manifest','old','new')];cmd=cfg['engines'][e]['analysis'];engines[e+'-'+variant]=(cmd,args)
   golds={};parity={}
   for k,(cmd,args) in engines.items():
    _,dump=call([*cmd,'dump',*args,'1']);which=k.split('-')[1];golds.setdefault(which,dump);assert dump==golds[which];parity[k]=sha(dump)
   assert golds['short'].replace(str(short).encode(),str(ordinary).encode())==golds['long']
   order=['after-long','after-short','rust-long','rust-short'];schedule=runner['orders'](tuple(order));case={'rounds':n,'schedule':schedule,'dumps':parity,'outputs':{},'samples':[]};oracle={}
   for sample in range(-1,8):
    row=[]
    for i,k in enumerate(schedule[sample%len(schedule)]):
     cmd,args=engines[k];times={}
     for rep in ((0,n) if (sample+i)%2==0 else (n,0)):
      elapsed,output=call([*cmd,'group',*args,str(rep)]);assert oracle.setdefault(rep,output)==output;times[rep]=elapsed
     row.append({'engine':k,'zero_ns':times[0],'repeat_ns':times[n]})
    if sample<0:case['warmup']=row
    else:case['samples'].append(row)
   case['outputs']={r:sha(b) for r,b in oracle.items()};med={k:statistics.median((v['repeat_ns']-v['zero_ns'])/n for row in case['samples'] for v in row if v['engine']==k) for k in order};case['median_ns']=med;case['ratios']={name:med['after-'+name]/med['rust-'+name] for name in base};record['panels'][f'{mode}/{scale}']=case;record['roots'][scale]={name:len(str(root.parent/'tests').encode())+1 for name,root in base.items()};(directory/'comparison.json').write_text(json.dumps(record,indent=2)+'\n');print(mode,scale,{k:round(v/1e6,4) for k,v in med.items()},case['ratios'],flush=True)
