"""Render tables from the audited observations, retaining all six engines."""

import argparse
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("study", type=Path)
p.add_argument("output", type=Path)
a = p.parse_args()
study = a.study
read = lambda f: json.loads(f.read_bytes())
modes = {m: read(study / "modes" / m / "results.json") for m in ("normal", "thinlto")}
engines = ["upstream", "cpython", "before", "after", "codon", "rust"]
mnames = {"normal": "Ordinary", "thinlto": "ThinLTO"}
kernels = {
    "group": "Group diagnostics",
    "equivalent": "Compare fingerprints",
    "files": "Collect file statistics",
}
rows = []


def line(s=""):
    rows.append(s)


def table_header():
    line(
        "| Corpus | Work | Link | Ruff CPython | Typed CPython | Previous Relar | Relar | Codon | Rust | Relar/Rust |"
    )
    line("|---|---|---|---:|---:|---:|---:|---:|---:|---:|")


def item(mode, name, label):
    case = modes[mode]["cases"][name]
    med = case["median_ns"]
    scale = name.split("/")[0].replace("x", "×")
    val = [
        "{:.3f}".format(med[e] / 1e6)
        if med[e] < 100e6
        else "{:,.2f}".format(med[e] / 1e6)
        for e in engines
    ]
    line(
        f"| {scale} | {label} | {mnames[mode]} | "
        + " | ".join(val)
        + f" | {med['after'] / med['rust']:.2f}× |"
    )


def band(what):
    xs = [
        ratio
        for d in modes.values()
        for name, ratio in d["ratios"].items()
        if what(name)
    ]
    return f"{min(xs):.2f}–{max(xs):.2f}×"


line("# Ruff diagnostic grouping and per-file statistics")
line()
line(
    "Relar compiles Ruff’s three original analysis functions, a total of 2,768 bytes of Python. The real changed run produced 1,269 ordered groups from 146 typing-conformance files. The larger run produced 12,690 groups from 1,460 distinct files. All six implementations matched the fields of every grouped record, both sets of per-file statistics, and every byte of both report formats. [Pinned Ruff source](https://github.com/astral-sh/ruff/blob/de9071547cfec12f689142a7b8ce98edc7aef909/scripts/conformance.py#L549) · [Relar application](../../examples/conformance_report/model.py)"
)
line()
line(
    f"Relar took {band(lambda n: n.endswith('/group'))} Rust’s time for grouping and {band(lambda n: n.endswith('/report'))} for complete report invocations. The largest median on the canonical checkout path across the 32 ordinary and ThinLTO workloads was {max(r for d in modes.values() for r in d['ratios'].values()):.2f}× Rust."
)
line()
line(
    "A separate native-only control reached 2.28× Rust for 10× grouping on a short checkout path and 2.13× on the canonical path with ThinLTO."
)
line()
line("## Isolated analysis")
line()
line(
    "Milliseconds per pass over preloaded diagnostic records. Grouping starts from parsed old, new and expected records. Equivalence and file statistics start from already-grouped cases. Every file-statistics pass resolves the full file list before collecting counts."
)
line()
table_header()
for scale in (1, 10):
    for operation, display in kernels.items():
        for mode in modes:
            item(mode, f"{scale}x/changed-github/{operation}", display)
line()
line(
    "The previous string-based port skipped filesystem resolution on each statistics pass. Ruff resolves every path and merges aliases that name the same file. The differential checks include a symlink that produced a fifth file row on the previous port and four rows in Ruff, current Relar, and Rust. The independent Rust reference calls the OS to resolve each input path, preserves input order, and handles missing paths through its non-strict resolver. [Previous port](https://github.com/astral-sh/relar/blob/17845276508a0431276b2606f4f076dcd58ecf37/examples/conformance_report/model.py) · [Rust reference](../reference/conformance_report/src/main.rs)"
)
source_control = study / "source-control/source-attribution.json"
if source_control.is_file():
    controls = read(source_control)["panels"]
    line()
    line(
        "A separate 12-pair run on a second Linux devbox compiled the previous string port with the same final compiler and runtime. Switching that build to Ruff’s source sped up grouping "
        + ", ".join(
            f"{v['old_over_ruff']:.2f}× at {key.split('/')[1]}× ({mnames[key.split('/')[0]]})"
            for key, v in controls.items()
        )
        + ". The complete group and file-statistic dumps matched. On that second host, 10× grouping took 2.13× Rust’s time in both link modes."
    )
line()
line("### Checkout-path length")
line()
paths = read(study / "path-sensitivity.json")
line(
    "Grouping sorts string keys that contain the absolute source path. A separate control on the same pinned CPU varied only the root of the checkout. Each row used eight counterbalanced pairs and identical files, diagnostics, and normalized group transcripts."
)
line()
line(
    "| Link | Files | Common directory prefix (bytes) | Relar (ms) | Rust (ms) | Relar/Rust |"
)
line("|---|---:|---:|---:|---:|---:|")
for key, case in paths["panels"].items():
    mode, scale = key.split("/")
    med = case["median_ns"]
    for variant in ("long", "short"):
        line(
            f"| {mnames[mode]} | {146 * int(scale):,} | {paths['roots'][scale][variant]} | {med['after-' + variant] / 1e6:.3f} | {med['rust-' + variant] / 1e6:.3f} | {case['ratios'][variant]:.2f}× |"
        )
line()
line(
    "The native-only 10× control exceeded 2× Rust on the short path in both modes and on the canonical path with ThinLTO. Both engines ran faster under the short path; Rust gained more. The control also used 12 repeated passes per process, versus eight in the six-engine panel. The 2× result for isolated 10× grouping therefore depends on the checkout and measurement protocol."
)
line()
line("## Complete reports")
line()
line(
    "Milliseconds. A complete invocation reads the manifest, individual source files and two captured GitLab JSON arrays, computes the report, and writes its Markdown. The repeated panel preloads raw input, then reruns annotation scanning, JSON decoding, analysis, and rendering for each pass."
)
line()
table_header()
for scale in (1, 10):
    for state, fmt in [
        ("changed", "github"),
        ("changed", "diff"),
        ("unchanged", "github"),
        ("unchanged", "diff"),
    ]:
        for mode in modes:
            item(
                mode,
                f"{scale}x/{state}-{fmt}/report",
                state.capitalize() + " " + ("GitHub" if fmt == "github" else "diff"),
            )
    for mode in modes:
        item(mode, f"{scale}x/changed-github/compute", "Changed GitHub, repeated")
line()
full = [
    case["median_ns"]["after"] / case["median_ns"]["before"]
    for raw in modes.values()
    for name, case in raw["cases"].items()
    if name.endswith("/report")
]
line(
    f"Complete invocations take {min(full):.2f}–{max(full):.2f}× the previous port’s time. The full measurements include input decoding, per-file filesystem resolution, and Markdown rendering as well as grouping."
)
line()
line(
    "Separate fresh processes measured peak resident memory for the changed GitHub report. Values are the median of six observations in MiB, using Linux `ru_maxrss` from GNU time."
)
line()
line(
    "| Corpus | Link | Ruff CPython | Typed CPython | Previous Relar | Relar | Codon | Rust |"
)
line("|---|---|---:|---:|---:|---:|---:|---:|")
for scale in ("1", "10"):
    for mode in modes:
        rss = read(study / "modes" / mode / "rss.json")["cases"][scale]["median_kib"]
        line(
            f"| {scale}× | {mnames[mode]} | "
            + " | ".join(f"{rss[e] / 1024:.1f}" for e in engines)
            + " |"
        )
line()
live = study / "qa/live-timing.json"
if live.exists():
    timer = read(live)
    med = timer["median_ms"]
    line(
        f"A separate live checkout run included both ty processes for every changed GitHub report on 146 files. On a second Linux devbox with CPUs 20 and 21 and two Rayon threads, medians were {med['upstream']:.1f} ms for upstream CPython, {med['relar']:.1f} ms for ordinary Relar, and {med['rust']:.1f} ms for Rust ({timer['relar_over_rust']:.2f}× Relar/Rust). All 12 measurements per engine produced the same {timer['report_bytes']:,} bytes."
    )
    line()
line("## Native profiles")
line()
line(
    "The 10× ordinary kernel ran on a second Linux devbox under Callgrind and DHAT, with the same executable hashes and zero or four rounds. Instruction counts, allocated blocks and cumulative allocated bytes subtract the preload and divide by four. Peak live heap is the observed high-water mark for the entire four-round process."
)
line()
line(
    "| Engine | Instructions/pass | Allocations/pass | Allocated MB/pass | Peak live MB |"
)
line("|---|---:|---:|---:|---:|")
for name, label in [("before", "Previous Relar"), ("after", "Relar"), ("rust", "Rust")]:
    d = study / "profiles" / name
    cpu = read(d / "callgrind-summary.json")
    heap = read(d / "dhat-summary.json")
    line(
        f"| {label} | {cpu['net_per_pass']['instructions']:,.0f} | {heap['net_per_pass']['tbk']:,.0f} | {heap['net_per_pass']['tb'] / 1e6:.2f} | {heap['runs'][1]['total']['gb'] / 1e6:.2f} |"
    )
line()
intermediate = read(study / "intermediate/results.json")["cases"][
    "10x/changed-github/group"
]["median_ns"]
line(
    f"Before the sorted-record gather, the ordinary 10× kernel took {intermediate['after'] / 1e6:.2f} ms, {intermediate['after'] / intermediate['rust']:.2f}× Rust, on the canonical checkout. That earlier source and complete timing panel are included under `intermediate/` in the study."
)
line()
line(
    "The source uses three list-factory dictionaries followed by a sorted key union. Relar recognizes the fixed record constructed from each key, gathers the three list owners in one traversal, and keeps each result row’s key and buckets together through sorting. The compiler checks the list-factory dictionary types, generated initializer, assignment order, and absence of user callbacks. [Compiler proof](../../crates/relar-compiler/src/frontend/sorted_rows.rs) · [Runtime](../../crates/relar-runtime/src/objects/mappings/sorted_rows.rs)"
)
line()
hash_cost = {}
for engine in ("before", "after"):
    ranks = read(study / "profiles" / engine / "ranks.json")
    hash_cost[engine] = next(
        cost
        for fn, cost in ranks["instructions"]
        if "Sip13Rounds" in fn and fn.endswith(">::write")
    )
line(
    f"SipHash's byte-feed function fell from {hash_cost['before'] / 1e6:.1f} million to {hash_cost['after'] / 1e6:.1f} million instructions per 10× pass. The previous port also made 93,120 buffer allocations on one path-normalization stack. In the current port, the largest allocation stack accounts for 34,150 list owners created on first access to a grouping key. Each of the 12,690 final rows still owns a record."
)
line()
sim = study / "cache-probes/after/summary.json"
if sim.is_file():
    d = read(sim)["net"]
    rust = read(study / "cache-probes/rust/summary.json")["net"]
    line(
        f"Under Valgrind’s two-level cache simulation, Relar incurred {d['D1mr'] / 1e6:.2f} million first-level data read misses per 10× pass and Rust incurred {rust['D1mr'] / 1e6:.2f} million. This simulation used 32 KiB eight-way instruction and data caches, a 32 MiB sixteen-way last-level cache, and 64-byte cache lines."
    )
    line()
line(
    "Codon uses native concrete list and dictionary types, set materialization for dictionary-key union, native JSON and RE2, and Codon’s native `Path` for file resolution. Its benchmark uses signed 64-bit integers. The evidence includes the 20 generated Codon modules, their source transformations, and a separate native-platform build receipt for each link mode. [Codon adapters](../codon_native/README.md)"
)
line()
line("## Reproduction")
line()
line(
    "Ruff is pinned at `de9071547cfec12f689142a7b8ce98edc7aef909` and the Python typing suite at `835b70f3f795f8e061b1f7621178515b0a77a0ad`. The changed case uses captured ty 0.0.60 and 0.0.90 diagnostics. The unchanged case uses identical captures. At 10×, each copy gets a unique basename and diagnostic aliases, including a distinct copy of the stub file. [Input preparation](../conformance_grouping_inputs.py) · [Differentials](../conformance_grouping_validate.py)"
)
line()
line(
    f"Measured source `{modes['normal']['config']['revision']}`, previous native source `{modes['normal']['config']['baseline_revision']}`. Both link modes ran serially on CPU 31 of the same AMD EPYC-Milan Linux host. Each of 16 panels per mode ran six engines in 12 balanced orders, after one warmup per engine. Paired panels alternated the order of zero and repeated runs within each observation. Across both modes that is 3,456 measured processes and 288 warmups. Tools were CPython 3.14.5, native Codon 0.20.4, Ohm Rust 1.99.0-7, Clang 18.1.3, and LLD 23.1.1 for ThinLTO. Codon’s compiler flags are identical in both modes and its linked native platform library is rebuilt for each Rust link mode. [Benchmark](../conformance_grouping_benchmark.py)"
)
line()
line(
    "The grouping probe exchanges the first and last old diagnostic every round and consumes every group’s index and three bucket lengths. The size checksum stays constant per pass on this capture. Callgrind recorded zero calls from the kernel driver to the grouping function in each preload control and four calls in each four-round previous Relar, current Relar, and Rust run. All six engines also produce complete transcripts containing each case key, all source labels, diagnostic fields, positions, expected tags, equivalence and per-file counts. [Timed driver](../conformance_grouping.py) · [Audit](../conformance_grouping_audit.py)"
)
line()
line(
    "Extract the portable study into an empty directory and run `python3.14 -B tools/replay.py .`. It rechecks the original Ruff source, captures, build receipts, each process observation, all medians and gates, raw profiles, and the real and seeded upstream results. The replay relocates fixture paths while preserving the exact measured path spelling for output comparisons. [Portable study](2026-10-23-diagnostic-grouping-study.tar.xz) · [Ordinary observations](2026-10-23-diagnostic-grouping-ordinary.json.gz) · [ThinLTO observations](2026-10-23-diagnostic-grouping-thinlto.json.gz) · [Replay receipt](2026-10-23-diagnostic-grouping-audit.json)"
)
a.output.write_text("\n".join(rows) + "\n")
