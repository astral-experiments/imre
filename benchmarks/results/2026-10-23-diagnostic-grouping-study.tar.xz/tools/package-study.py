"""Package the two audited timing panels, reproducible inputs, probes and sources."""

import argparse
import hashlib
import json
import shutil
import tarfile
from pathlib import Path


def sha(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--cache", type=Path, required=True)
p.add_argument("--checkout", type=Path, required=True)
p.add_argument("--output", type=Path, required=True)
p.add_argument(
    "--qa",
    type=Path,
    required=True,
    help="directory with frozen live and integrated validation receipts",
)
a = p.parse_args()
c = a.cache.resolve()
checkout = a.checkout.resolve()
dest = a.output.resolve()
dest.mkdir(parents=True, exist_ok=False)
g = Path(__file__).resolve().parent
src = c / "source"
assert (src / "checkout.json").exists()
shutil.copytree(
    src, dest / "source", ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
)
previous_dir = c / "build-base/kernels/normal/source"
shutil.copytree(
    previous_dir,
    dest / "previous-source",
    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
)
(dest / "tools").mkdir()
for name in (
    "replay.py",
    "controls-audit.py",
    "render-note.py",
    "path-sensitivity.py",
    "build-grouping.py",
    "make-config.py",
    "bind-builds.py",
    "stage-builds.py",
    "prepare-codon.py",
    "run-formal.py",
    "profile-kernel.py",
    "rank-profiles.py",
    "package-study.py",
    "build-candidate.py",
    "peak-rss.py",
    "cache-probe.py",
    "cache-ranks.py",
    "source-control-build.py",
    "source-control-pilot.py",
):
    shutil.copy2(g / name, dest / "tools" / name)
for mode in ("normal", "thinlto"):
    d = dest / "modes" / mode
    shutil.copytree(
        c / "export" / mode,
        d,
        ignore=shutil.ignore_patterns("report.md", "results.tmp"),
    )
for label in ("before", "after", "rust"):
    d = dest / "profiles" / label
    shutil.copytree(c / "profiles" / label, d)
for label in ("after", "rust"):
    source = c / "cache-probes" / label
    if source.is_dir():
        shutil.copytree(source, dest / "cache-probes" / label)
if (c / "source-control/source-attribution.json").is_file():
    d = dest / "source-control"
    d.mkdir()
    shutil.copy2(c / "source-control/host.json", d / "host.json")
    shutil.copy2(
        c / "source-control/source-attribution.json", d / "source-attribution.json"
    )
    for mode in ("normal", "thinlto"):
        q = d / mode
        q.mkdir()
        shutil.copy2(
            c / "source-control" / mode / "build-record.json", q / "build-record.json"
        )
for mode in ("normal", "thinlto"):
    f = c / "memory" / mode / "rss.json"
    shutil.copy2(f, dest / "modes" / mode / "rss.json")
shutil.copy2(c / "path-sensitivity/comparison.json", dest / "path-sensitivity.json")
import runpy

fixture = runpy.run_path(str(dest / "source/benchmarks/conformance_grouping_inputs.py"))
original_study = (
    checkout / "benchmarks/results/2026-10-22-collector-ownership-study.tar.xz"
)
fixture["unpack"](original_study, dest / "captures")
intermediate = dest / "intermediate"
intermediate.mkdir()
for n in ("results.json", "strict-audit.json"):
    shutil.copy2(c / "intermediate" / n, intermediate / n)
recipe_notes = g / "reproduction.md"
if not recipe_notes.is_file():
    recipe_notes = g.parent / "README.md"
shutil.copy2(recipe_notes, dest / "README.md")
codon = c / "codon-native"
generated = dest / "codon-native"
for mode in ("normal", "thinlto"):
    record = json.loads((dest / "modes" / mode / "records/codon.json").read_bytes())
    tree = codon / mode / "source"
    assert record["generated"] == {
        str(f.relative_to(tree)): sha(f) for f in tree.rglob("*") if f.is_file()
    }
    if mode == "normal":
        shutil.copytree(tree, generated)
    else:
        assert all(
            (tree / p).read_bytes() == (generated / p).read_bytes()
            for p in record["generated"]
        )
licenses = dest / "licenses"
licenses.mkdir()
with tarfile.open(original_study, "r:xz") as tf:
    (licenses / "typing-LICENSE").write_bytes(
        tf.extractfile("licenses/typing-LICENSE").read()
    )
for n in ("LICENSE", "UPSTREAM.json"):
    shutil.copy2(
        checkout / "examples/conformance_report/upstream" / n, licenses / ("ruff-" + n)
    )
shutil.copy2(c / "profiles/glibc-offsets.json", dest / "profiles/glibc-offsets.json")
qa = dest / "qa"
qa.mkdir()
for name in (
    "ordinary-integrated.json",
    "sanitized-integrated.json",
    "live-checkout.json",
):
    shutil.copy2(a.qa / name, qa / name)
shutil.copytree(a.qa / "live", qa / "live")
if (a.qa / "live-timing.json").is_file():
    shutil.copy2(a.qa / "live-timing.json", qa / "live-timing.json")
    shutil.copy2(a.qa / "live-timing.py", qa / "live-timing.py")
for mode in ("normal", "thinlto"):
    for label, folder in [("before", "build-base"), ("after", "build-final")]:
        ir = c / folder / "kernels" / mode / "grouping.ll"
        d = dest / "ir" / mode
        d.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ir, d / f"{label}.ll")
for name in ("430b253-sort", "sorted-keys"):
    point = c / "pilots" / name / "native-pilot.json"
    if point.exists():
        out = dest / "pilots" / name
        out.mkdir(parents=True)
        shutil.copy2(point, out / "native-pilot.json")
licensefile = checkout / "LICENSE-MIT"
shutil.copy2(licensefile, dest / licensefile.name)
shutil.copy2(checkout / "LICENSE-APACHE", dest / "LICENSE-APACHE")
index = {
    "revision": json.loads((src / "checkout.json").read_bytes())["revision"],
    "files": {
        str(f.relative_to(dest)): sha(f)
        for f in sorted(dest.rglob("*"))
        if f.is_file() and "__pycache__" not in f.parts
    },
}
(dest / "index.json").write_text(json.dumps(index, indent=2) + "\n")
print(dest, len(index["files"]), flush=True)
