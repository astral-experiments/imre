"""Rank simulated per-function cache events after subtracting the identical preload."""
import json,re,sys
from collections import Counter
from pathlib import Path
def counters(path):
 ls=path.read_text().splitlines();keys=next(l.split()[1:] for l in ls if l.startswith('events:'));tot=next([int(v) for v in l.split()[1:]] for l in ls if l.startswith('totals:'));sym={m[1]:m[2] for l in ls if (m:=re.match(r'c?fn=\((\d+)\) (.+)',l))}
 cost={k:Counter() for k in keys};edge=False;fn=None
 for line in ls:
  if (m:=re.match(r'fn=\((\d+)\)',line)):fn=sym[m[1]];edge=False
  elif line.startswith('calls='):edge=True
  elif re.match(r'^(?:[+-]?\d+|\*) ',line):
   values=list(map(int,line.split()[1:]))
   if not edge:
    for k,v in zip(keys,values):cost[k][fn]+=v
   edge=False
 assert [sum(cost[k].values()) for k in keys]==tot,dict(zip(keys,[(sum(cost[k].values()),v,sum(cost[k].values())-v) for k,v in zip(keys,tot)]))
 return cost
def ranks(d):
 z=counters(d/'0.out');all_=counters(d/'4.out')
 return {k:sorted([(f,(all_[k][f]-z[k][f])/4) for f in all_[k].keys()|z[k].keys() if all_[k][f]!=z[k][f]],key=lambda r:(-r[1],r[0])) for k in z}
if __name__=='__main__':
 d=Path(sys.argv[1]);res=ranks(d);(d/'ranks.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:res[k][:10] for k in ('D1mr','D1mw','Bim')},indent=2))
