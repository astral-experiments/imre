"""Time string-port and Ruff source on one compiler/runtime with verified equal full outputs."""
import argparse,hashlib,json,os,statistics,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--cpu',type=int,default=31);a=p.parse_args();c=a.cache.resolve();os.sched_setaffinity(0,{a.cpu});results={'cpu':a.cpu,'panels':{}};dest=c/'source-control/source-attribution.json'
def sha(b):return hashlib.sha256(b).hexdigest()
for mode in ('normal','thinlto'):
  native={'old_source':[str(c/'source-control'/mode/'grouping')],'ruff_source':[str(c/'build-final/kernels'/mode/'grouping')],'rust':[str((c/'build-rust'/mode/'conformance-report-reference').resolve()),'--grouping']}
  for scale,n in [(1,64),(10,12)]:
    data=c/'fixtures'/f'{scale}x'/'changed';args=[str(data/(key+'.json')) for key in ('manifest','old','new')];dump=None;keys={};rows=[];
    for name,cmd in native.items():
        trial=subprocess.run([*cmd,'dump',*args,'1'],capture_output=True,check=True);assert trial.stderr==b'';dump=trial.stdout if dump is None else dump;assert trial.stdout==dump
    for index in range(-1,12):
        row=[];names=['old_source','ruff_source','rust'];shift=index%3;names=names[shift:]+names[:shift] if index%2==0 else list(reversed(names[shift:]+names[:shift]))
        for pos,e in enumerate(names):
            obs={}
            for r in ((0,n) if (index+pos)%2==0 else (n,0)):
                t=time.perf_counter_ns();run=subprocess.run([*native[e],'group',*args,str(r)],capture_output=True,check=True);elapsed=time.perf_counter_ns()-t;assert run.stderr==b'' and keys.setdefault(r,run.stdout)==run.stdout;obs[r]=elapsed
            row.append({'engine':e,'repeat_ns':obs[n],'zero_ns':obs[0]})
        rows.append(row)
    med={k:statistics.median((v['repeat_ns']-v['zero_ns'])/n for row in rows[1:] for v in row if v['engine']==k) for k in native};result={'rounds':n,'warmup':rows[0],'samples':rows[1:],'median_ns':med,'old_over_ruff':med['old_source']/med['ruff_source'],'ruff_over_rust':med['ruff_source']/med['rust'],'identities':{k:sha(Path(cmd[0]).read_bytes()) for k,cmd in native.items()},'outputs':{k:sha(v) for k,v in keys.items()},'dump_sha256':sha(dump)};results['panels'][mode+'/'+str(scale)]=result;dest.write_text(json.dumps(results,indent=2)+'\n');print(mode,scale,{k:round(v/1e6,3) for k,v in med.items()},'old/new',round(result['old_over_ruff'],3),flush=True)
