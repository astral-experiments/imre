"""Recompute the grouped-diagnostic benchmark audits from this unpacked study."""

import argparse
import ast
import hashlib
import json
import re
import runpy
import subprocess
import sys
import tempfile
from pathlib import Path


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(f):
    return json.loads(f.read_bytes())


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("study", type=Path)
p.add_argument(
    "--skip-seeded-replay",
    action="store_true",
    help="do not re-execute the seeded CPython oracle",
)
a = p.parse_args()
assert not sys.flags.optimize
root = a.study.resolve()
src = root / "source"
modes = root / "modes"
entry = src / "benchmarks"
validation = runpy.run_path(str(entry / "conformance_validate.py"))
fixture = runpy.run_path(str(entry / "conformance_grouping_inputs.py"))
seed_cases = runpy.run_path(str(entry / "conformance_grouping_validate.py"))
analytic = runpy.run_path(str(entry / "conformance_grouping_audit.py"))
bind = runpy.run_path(str(root / "tools/bind-builds.py"))["dissect"]
index = read(root / "index.json")
actual = {
    str(f.relative_to(root)): sha(f.read_bytes())
    for f in root.rglob("*")
    if f.is_file() and f != root / "index.json" and "__pycache__" not in f.parts
}
assert actual == index["files"]
source = read(src / "checkout.json")
assert all(sha((src / f).read_bytes()) == h for f, h in source["files"].items())


def exact_definitions(file):
    text = file.read_text()
    lines = text.splitlines(keepends=True)
    wanted = {
        "group_diagnostics_by_key",
        "diagnostics_are_equivalent",
        "collect_file_stats",
    }
    return {
        node.name: "".join(lines[node.lineno - 1 : node.end_lineno]).encode()
        for node in ast.parse(text).body
        if isinstance(node, ast.FunctionDef) and node.name in wanted
    }


model = src / "examples/conformance_report"
ruff = read(root / "licenses/ruff-UPSTREAM.json")
assert (
    ruff["revision"] == "de9071547cfec12f689142a7b8ce98edc7aef909"
    and sha((model / "upstream/conformance.py").read_bytes())
    == ruff["files"]["conformance.py"]
    and sha((root / "licenses/ruff-LICENSE").read_bytes()) == ruff["files"]["LICENSE"]
)
observed = exact_definitions(model / "model.py")
assert len(observed) == 3 and observed == exact_definitions(
    model / "upstream/conformance.py"
)
reports = {}
configs = {}
seeds = {}
dumps = {}
parities = 0
for mode in ("normal", "thinlto"):
    d = modes / mode
    reports[mode] = analytic["audit"](d)
    raw = read(d / "results.json")
    cfg = raw["config"]
    configs[mode] = cfg
    assert cfg["revision"] == source["revision"]
    assert bind(cfg, d / "records") == read(d / "binding.json")
    for engine in ("before", "after"):
        kernel = read(d / "records" / f"kernel-{engine}.json")
        if engine == "before":
            previous = root / "previous-source"
            for name, rec in kernel["application_inputs"].items():
                original = previous / Path(name).relative_to("examples")
                assert sha(original.read_bytes()) == rec["sha256"]
            assert (
                sha((previous / "grouping.py").read_bytes())
                == kernel["generated_driver"]["sha256"]
            )
            old_driver = (src / "benchmarks/conformance_grouping.py").read_text()
            for before, after in kernel["older_string_adapter"]:
                assert old_driver.count(before) == 1
                old_driver = old_driver.replace(before, after)
            assert old_driver == (previous / "grouping.py").read_text()

        ir = (root / "ir" / mode / f"{engine}.ll").read_bytes()
        assert sha(ir) == kernel["llvm"]["sha256"]
        row_calls = re.findall(
            rb"^  %\S+ = call ptr @imre_sorted_record_rows\([^\n]+", ir, re.MULTILINE
        )
        if engine == "after":
            assert len(row_calls) == 1 and b"i64 3, ptr @layout_class_" in row_calls[0]
        else:
            assert not row_calls
    codon = read(d / "records/codon.json")
    native = root / "codon-native"
    assert codon["generated"] == {
        str(f.relative_to(native)): sha(f.read_bytes())
        for f in native.rglob("*")
        if f.is_file()
    }
    assert not codon["domain"]["python_interop"]
    assert reports[mode] == read(d / "strict-audit.json")
    receipt = read(d / "validation.json")
    assert receipt["seeds"] >= 96 and len(receipt["fixed"]) >= 12
    cases = receipt["comparisons"]
    assert len(cases) == 2 * (receipt["seeds"] + len(receipt["fixed"])) - 5
    assert {row["case"] for row in cases} == set(receipt["fixed"]) | set(
        range(receipt["start"], receipt["start"] + receipt["seeds"])
    )
    for row in cases:
        assert set(row["engines"]) == set(cfg["engines"])
        for e, v in row["engines"].items():
            if (
                e == "before"
                and row["case"] == "symlink-dedup"
                and row["mode"] == "dump"
            ):
                assert v == "historical fifth file row"
            else:
                assert v == (row["error"] or row["oracle_sha256"])
    seeds[mode] = receipt
    dumps[mode] = raw["parity"]
assert reports["normal"]["revision"] == reports["thinlto"]["revision"]
with tempfile.TemporaryDirectory() as tmp:
    # The archived intermediate retained the same complete canonical outputs.
    stage = Path(tmp)
    (stage / "results.json").symlink_to(root / "intermediate/results.json")
    for name in (modes / "normal").iterdir():
        if name.suffix in (".md", ".txt"):
            (stage / name.name).symlink_to(name)
    intermediate = analytic["audit"](stage)
    assert (
        intermediate == read(root / "intermediate/strict-audit.json")
        and not intermediate["time_target_met"]
    )

assert configs["normal"]["baseline_revision"] == configs["thinlto"]["baseline_revision"]
groups_script = entry / "conformance_grouping_upstream.py"
with tempfile.TemporaryDirectory() as tmp:
    testroot = Path(tmp) / "fixtures"
    capture = root / "captures"
    proof = fixture["prepare"](
        capture / "changed-github",
        capture / "unchanged-github",
        testroot,
        capture / "suite",
    )
    env = validation["environment"](Path(tmp))
    for scale in (1, 10):
        for state in ("changed", "unchanged"):
            panel = f"{scale}x/{state}"
            d = testroot / panel
            args = [str(d / (k + ".json")) for k in ("manifest", "old", "new")]
            for format_ in ("github", "diff"):
                case = validation["Workload"](*(Path(f) for f in args), format_)
                o = validation["oracle"](case)
                assert o.error is None
                expected = o.report.encode()
                for mode, cfg in configs.items():
                    stored = (
                        modes / mode / f"{scale}x-{state}-{format_}.md"
                    ).read_bytes()
                    assert stored == expected.replace(
                        str(testroot).encode(), cfg["fixtures_directory"].encode()
                    ), (scale, state, format_, mode)
                    parities += 1
                if scale == 1:
                    live = read(root / "qa/live-checkout.json")
                    work = validation["Workload"](
                        *(Path(f) for f in args), format_, False
                    )
                    original = validation["oracle"](work)
                    assert original.error is None
                    live_tests = Path(live["checkouts"][0]) / "conformance/tests"
                    normalized = original.report.encode().replace(
                        str(d.parent / "tests").encode(), str(live_tests).encode()
                    )
                    for engine in live["engines"]:
                        assert (
                            normalized
                            == (
                                root / "qa/live" / f"{state}-{format_}-{engine}.md"
                            ).read_bytes()
                        )
            for which in ("dump", "aliases"):
                out = subprocess.check_output(
                    [sys.executable, "-B", str(groups_script), which, *args, "1"],
                    env=env,
                )
                for mode, cfg in configs.items():
                    stored = (
                        modes / mode / f"{scale}x-{state}-{which}.txt"
                    ).read_bytes()
                    assert stored == out.replace(
                        str(testroot).encode(), cfg["fixtures_directory"].encode()
                    ), (scale, state, which, mode)
                    parities += 1
            for mode, cfg in configs.items():
                raw = read(modes / mode / "results.json")
                assert (
                    proof["revision"] == raw["fixtures"]["revision"]
                    and proof["sources"] == raw["fixtures"]["sources"]
                )
                info = raw["fixtures"]["panels"][panel]
                assert (
                    info["records"] == proof["panels"][panel]["records"]
                    and info["files"] == 146 * scale
                    and info["aliases"]
                    == proof["panels"][panel]["aliases"]
                    == {"changed": 137, "unchanged": 135}[state] * scale
                )
                assert all(
                    sha(
                        (d / (k + ".json"))
                        .read_bytes()
                        .replace(
                            str(testroot).encode(), cfg["fixtures_directory"].encode()
                        )
                    )
                    == v
                    for k, v in info["inputs"].items()
                )
    if not a.skip_seeded_replay:
        origin = seeds["normal"]
        seed_dir = Path(tmp) / "differentials"
        seed_dir.mkdir()
        for name in [
            *origin["fixed"],
            *range(origin["start"], origin["start"] + origin["seeds"]),
        ]:
            special = name if isinstance(name, str) else None
            seed = origin["start"] if special else name
            sd = seed_dir / (special or f"seed-{seed}")
            sd.mkdir()
            args = seed_cases["fixture"](sd, seed, special)
            for row in (r for r in origin["comparisons"] if r["case"] == name):
                error, output = seed_cases["observation"](
                    [sys.executable, "-B", str(groups_script)],
                    [row["mode"], *args, "1"],
                    sd,
                    env,
                )
                for mode, cfg in configs.items():
                    destination = cfg["validation_directory"].encode()
                    normal = output.replace(str(seed_dir).encode(), destination)
                    stored = next(
                        v
                        for v in seeds[mode]["comparisons"]
                        if v["case"] == name and v["mode"] == row["mode"]
                    )
                    assert (
                        error == stored["error"]
                        and sha(normal) == stored["oracle_sha256"]
                    ), (mode, name, row["mode"])
for label in ("before", "after", "rust"):
    dir_ = root / "profiles" / label
    stored_ranks = read(dir_ / "ranks.json")
    computed = runpy.run_path(str(root / "tools/rank-profiles.py"))["ranks"](dir_)
    assert json.loads(json.dumps(computed)) == stored_ranks
    for kind in ("callgrind", "dhat"):
        r = read(dir_ / (kind + "-summary.json"))
        assert (
            r["binary"]["sha256"]
            == configs["normal"]["guarded_inputs"][
                next(
                    i
                    for i, f in enumerate(configs["normal"]["guarded_inputs"])
                    if f["path"] == r["binary"]["path"]
                )
            ]["sha256"]
        )
        vals = []
        for sample in r["runs"]:
            n = sample["rounds"]
            file = dir_ / (f"{kind}-{n}." + ("out" if kind == "callgrind" else "json"))
            assert sha(file.read_bytes()) == sample["trace"]["sha256"]
            if kind == "callgrind":
                v = {
                    "instructions": int(
                        re.search(r"^summary: (\d+)", file.read_text(), re.M)[1]
                    )
                }
            else:
                v = {
                    k: sum(x[k] for x in read(file)["pps"])
                    for k in ("tb", "tbk", "gb", "gbk", "eb", "ebk")
                }
            assert v == sample["total"]
            vals.append(v)
        assert r["net_per_pass"] == {
            k: (vals[1][k] - vals[0][k]) / r["runs"][1]["rounds"]
            for k in vals[0]
            if k in ("instructions", "tb", "tbk")
        }
# These optional controls are outside the hard wall-time gates.
for label in ("after", "rust"):
    folder = root / "cache-probes" / label
    if folder.is_dir():
        probe = read(folder / "summary.json")
        recalculated = runpy.run_path(str(root / "tools/cache-ranks.py"))["ranks"](
            folder
        )
        assert read(folder / "ranks.json") == json.loads(json.dumps(recalculated))
        assert all(
            sha((folder / (str(r["rounds"]) + ".out")).read_bytes()) == r["sha256"]
            for r in probe["runs"]
        )
controls = root / "source-control/source-attribution.json"
if controls.is_file():
    measured = read(controls)
    assert set(measured["panels"]) == {f"{m}/{s}" for m in configs for s in (1, 10)}
    for key, case in measured["panels"].items():
        mode, scale = key.split("/")
        n = case["rounds"]
        import statistics

        assert n == {"1": 64, "10": 12}[scale] and len(case["samples"]) == 12
        engines = ("old_source", "ruff_source", "rust")
        for i, row in enumerate([case["warmup"], *case["samples"]], -1):
            offset = i % len(engines)
            expected = list(engines[offset:] + engines[:offset])
            if i % 2:
                expected.reverse()
            assert [v["engine"] for v in row] == expected and all(
                v["repeat_ns"] > v["zero_ns"] > 0 for v in row
            )
        med = {
            e: statistics.median(
                (v["repeat_ns"] - v["zero_ns"]) / n
                for row in case["samples"]
                for v in row
                if v["engine"] == e
            )
            for e in engines
        }
        assert (
            med == case["median_ns"]
            and med["ruff_source"] / med["rust"] == case["ruff_over_rust"]
        )
        scores = {"1": 8107277, "10": 799131362}
        assert case["outputs"] == {
            str(k): sha(f"{scores[scale] * k}\n".encode()) for k in (0, n)
        }
        assert (
            case["median_ns"]["old_source"] / case["median_ns"]["ruff_source"]
            == case["old_over_ruff"]
        )
        frozen = read(root / "source-control" / mode / "build-record.json")
        assert (
            frozen["binary_sha256"] == case["identities"]["old_source"]
            and frozen["compiler_revision"] == configs[mode]["revision"]
        )
        bd = modes / mode / "records"
        assert (
            frozen["source_revision"] == configs[mode]["baseline_revision"]
            and frozen["mode"] == mode
        )
        assert frozen["original_source_record_sha256"] == sha(
            (bd / "kernel-before.json").read_bytes()
        ) and frozen["candidate_record_sha256"] == sha(
            (bd / "kernel-after.json").read_bytes()
        )
        candidate = read(bd / "kernel-after.json")
        assert (
            frozen["compiler"] == candidate["compiler"]
            and frozen["runtime"] == candidate["runtime"]
        )
        assert case["identities"]["ruff_source"] == candidate["binary"]["sha256"]
        cmd = configs[mode]["engines"]["rust"]["analysis"][0]
        assert case["identities"]["rust"] == next(
            x["sha256"] for x in configs[mode]["guarded_inputs"] if x["path"] == cmd
        )
        assert (
            case["dump_sha256"]
            == dumps[mode][f"{scale}x-changed-dump"]["oracle"]["sha256"]
        )
controls = runpy.run_path(str(root / "tools/controls-audit.py"))
orders = runpy.run_path(str(entry / "conformance_regex_benchmark.py"))["orders"]
profile_calls = controls["audit_calls"](root)
path_control = controls["audit_paths"](root, configs, orders)
peak_rss = controls["audit_rss"](root, configs, orders)
qa = {}
for mode in ("ordinary", "sanitized"):
    d = read(root / "qa" / f"{mode}-integrated.json")
    assert d["status"] == "passed" and d["counts"] == {
        "application": 96,
        "compute": 120,
        "stdout": 3,
        "output-error": 6,
    }
    assert d["parser_differentials"] == 30_000 and d["report_differentials"] == 400
    qa[mode] = {
        **d["counts"],
        "parser_differentials": d["parser_differentials"],
        "report_differentials": d["report_differentials"],
    }
live = read(root / "qa/live-checkout.json")
assert live["suite_revision"] == proof["revision"]
assert set(live["engines"]) == {"upstream", "imre", "rust"}
assert set(live["reports"]) == {
    "changed-github",
    "changed-diff",
    "unchanged-github",
    "unchanged-diff",
}
assert live["reports"]["unchanged-github"] == live["reports"]["unchanged-diff"]
prepared = read(root / "captures/changed-github/preparation.json")
assert live["analyzers"] == [
    {
        "version": prepared["captures"][side]["version"],
        "sha256": prepared["tools"][side]["sha256"],
    }
    for side in ("old", "new")
]
for case, item in live["reports"].items():
    bodies = [
        (root / "qa/live" / f"{case}-{engine}.md").read_bytes()
        for engine in live["engines"]
    ]
    assert (
        len(set(bodies)) == 1
        and len(bodies[0]) == item["bytes"]
        and sha(bodies[0]) == item["sha256"]
    )

live_timing = None
if (root / "qa/live-timing.json").exists():
    import statistics

    live_timing = read(root / "qa/live-timing.json")
    assert (
        live_timing["imre_revision"] == source["revision"]
        and live_timing["suite_revision"] == proof["revision"]
    )
    assert (
        live_timing["cpu_affinity"] == [20, 21]
        and live_timing["rayon_num_threads"] == 2
    )
    assert live_timing["analyzer_sha256"] == [x["sha256"] for x in live["analyzers"]]
    assert (
        live_timing["report_sha256"] == live["reports"]["changed-github"]["sha256"]
        and live_timing["report_bytes"] == live["reports"]["changed-github"]["bytes"]
    )
    assert len(live_timing["warmup"]) == 1 and len(live_timing["samples"]) == 12
    orders = [tuple(v["engine"] for v in row) for row in live_timing["samples"]]
    assert len(set(orders[:6])) == 6 and orders[6:] == orders[5::-1]
    assert all(set(row) == set(live["engines"]) for row in orders)
    assert len(live_timing["warmup"][0]) == 3 and [
        v["engine"] for v in live_timing["warmup"][0]
    ] == list(orders[0])
    assert all(
        s["ns"] > 0
        for row in [*live_timing["warmup"], *live_timing["samples"]]
        for s in row
    )
    med = {
        e: statistics.median(
            v["ns"] for row in live_timing["samples"] for v in row if v["engine"] == e
        )
        / 1e6
        for e in live["engines"]
    }
    assert (
        med == live_timing["median_ms"]
        and med["imre"] / med["rust"] == live_timing["imre_over_rust"]
    )
    ins = src / "examples/conformance_report/original_live.py"
    assert sha(ins.read_bytes()) == live_timing["engine_sha256"]["upstream"][1]
    assert live_timing["engine_sha256"]["rust"] == [
        next(
            x["sha256"]
            for x in configs["normal"]["guarded_inputs"]
            if x["path"] == configs["normal"]["engines"]["rust"]["report"][0]
        )
    ]
result = {
    "status": "passed",
    "revision": source["revision"],
    "indexed_files": len(actual),
    "exact_definitions": {k: sha(v) for k, v in observed.items()},
    "real_outputs_reexecuted": parities,
    "seeded_replay": not a.skip_seeded_replay,
    "modes": reports,
    "intermediate": intermediate,
    "grouping_calls_zero_four_rounds": profile_calls,
    "path_sensitivity": path_control,
    "full_report_peak_kib": peak_rss,
    "qa": qa,
    "live_checkout": live["reports"],
    "live_median_ms": live_timing["median_ms"] if live_timing else None,
}
print(json.dumps(result, indent=2))
sys.exit(0 if all(x["time_target_met"] for x in reports.values()) else 1)
