"""Observe Linux per-child peak RSS for changed full GitHub reports, outside wall timings."""
import argparse,hashlib,json,os,runpy,statistics,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--mode',required=True);p.add_argument('--cpu',type=int,default=31);a=p.parse_args();c=a.cache.resolve();cfg=json.loads((c/'configs'/a.mode/'config.json').read_bytes());target=c/'memory'/a.mode;target.mkdir(parents=True,exist_ok=False);val=runpy.run_path(str(c/'source/benchmarks/conformance_validate.py'));shared=runpy.run_path(str(c/'source/benchmarks/conformance_regex_benchmark.py'));os.sched_setaffinity(0,{a.cpu});env=val['environment'](target);time=Path('/usr/bin/time');receipt={'mode':a.mode,'revision':cfg['revision'],'time_sha256':hashlib.sha256(time.read_bytes()).hexdigest(),'tool':subprocess.check_output([str(time),'--version'],text=True).splitlines()[0],'unit':'KiB, Linux per-process ru_maxrss via GNU time','cpu':a.cpu,'cases':{}};out=target/'output.md';ob=target/'peak.txt';plan=shared['orders']()
# A fresh, small GNU time process starts and waits for each measured command. The
# Python orchestrator may have larger retained input/output than a native child.
for scale in [1,10]:
    inputs=c/'fixtures'/f'{scale}x'/'changed';w=val['Workload'](*(inputs/(key+'.json') for key in ('manifest','old','new')),'github');gold=val['oracle'](w).report.encode();args=[*w.arguments(),'--output',str(out)];samples=[]
    for idx in range(-1,6):
        row=[]
        for e in plan[idx%6]:
            out.unlink(missing_ok=True);ob.unlink(missing_ok=True);cmd=[str(time),'-f','%M','-o',str(ob),*cfg['engines'][e]['report'],*args]
            cp=subprocess.run(cmd,capture_output=True,check=True,env=env,timeout=120);assert cp.stdout==cp.stderr==b'' and out.read_bytes()==gold
            row.append({'engine':e,'peak_kib':int(ob.read_text()),'output_sha256':hashlib.sha256(gold).hexdigest()})
        samples.append(row)
    ns={e:statistics.median(v['peak_kib'] for row in samples[1:] for v in row if v['engine']==e) for e in cfg['engines']}
    receipt['cases'][str(scale)]={'warmup':samples[0],'samples':samples[1:],'median_kib':ns};print(a.mode,scale,ns,flush=True)
(target/'rss.json').write_text(json.dumps(receipt,indent=2)+'\n')
