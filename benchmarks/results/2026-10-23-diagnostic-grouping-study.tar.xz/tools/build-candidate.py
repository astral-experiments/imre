"""Build all measured Imre applications from a clean, immutable checkout."""
import argparse,json,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--checkout',type=Path,required=True);p.add_argument('--cache',type=Path,required=True);p.add_argument('--linker',type=Path,required=True);a=p.parse_args();repo=a.checkout.resolve();c=a.cache.resolve();root=c/'build-final';core=root/'core/build-record.json';rec=json.loads(core.read_bytes());revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert revision==rec['revision'] and rec['status']=='passed' and not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
def run(mode):
 programs=root/'programs'/mode;kernel=root/'kernels'/mode
 program=[sys.executable,'-B','-u',str(repo/'benchmarks/live_conformance_build.py'),'--application','conformance_report','--core-build-record',str(core),'--mode',mode,'--clang','/usr/lib/llvm-18/bin/clang','--output',str(programs)]
 if mode=='thinlto':program+=['--lto-linker',str(a.linker)]
 subprocess.run(program,cwd=repo,check=True);subprocess.run([sys.executable,'-u',str(c/'build-grouping.py'),'--study',str(repo),'--application',str(repo),'--program-record',str(programs/'build-record.json'),'--output',str(kernel)],check=True)
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in [pool.submit(run,mode) for mode in ('normal','thinlto')]:f.result()
