"""Compile ordinary and ThinLTO-platform Codon comparators on the isolated native host."""
from concurrent.futures import ThreadPoolExecutor
import argparse,subprocess,os,sys,json
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--codon',type=Path,required=True);a=p.parse_args();c=a.cache.resolve()
def build(mode,cpu):
    out=c/'build-codon'/mode
    cmd=['taskset','-c',cpu,sys.executable,'-B','-u',str(c/'source/benchmarks/codon_native/build.py'),'--codon',str(a.codon),'--platform-library',str(c/'build-platform'/mode/'libimre_benchmark_platform.so'),'--output',str(out),'--applications','conformance_report','--conformance-grouping']
    b=subprocess.run(cmd,capture_output=True,text=True,timeout=600);(c/('codon-'+mode+'.log')).write_text(b.stdout+b.stderr);assert b.returncode==0,b.stderr[-1900:];rec=json.loads((out/'build-record.json').read_bytes());assert rec['status']=='passed' and len(rec['binaries'])==3;return {mode:rec['binaries']}
with ThreadPoolExecutor(max_workers=2) as executor:
    jobs=[executor.submit(build,mode,pin) for mode,pin in [('normal','2,3'),('thinlto','4,5')]]
    for job in jobs:print(json.dumps(job.result()),flush=True)
