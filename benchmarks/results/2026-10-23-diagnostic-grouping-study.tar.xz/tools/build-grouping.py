"""Build a source-locked grouping driver against a verified program/runtime build."""
import argparse,hashlib,json,os,runpy,shutil,subprocess,time
from pathlib import Path
from datetime import datetime,timezone

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--study',type=Path,required=True,help='checkout containing the benchmark driver')
p.add_argument('--application',type=Path,required=True,help='checkout for the measured application')
p.add_argument('--program-record',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--older-strings',action='store_true')
a=p.parse_args();a.study=a.study.resolve();a.application=a.application.resolve();output=a.output.resolve()
bench=runpy.run_path(str(a.application/'benchmarks/live_conformance_benchmark.py'))
identity=bench['identity'];guard={}
program=bench['verify_build_record'](a.program_record.resolve(),guard)
assert program['source_matches_revision'] and program['input_guards_passed'] and program['status']=='passed'
def revision(root):return subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
def check_one(root,f,rev):
    raw=subprocess.check_output(['git','show',rev+':'+str(f.relative_to(root))],cwd=root);assert raw==f.read_bytes(),f;guard[str(f)]=identity(f)
rev=revision(a.application);study_rev=revision(a.study)
assert program['revision']==rev
appfiles={}
for f in sorted((a.application/'examples/conformance_report').rglob('*.py')):
    if '__pycache__' not in f.parts:
        check_one(a.application,f,rev)
        appfiles[str(f.relative_to(a.application))]=identity(f)
driver=a.study/'benchmarks/conformance_grouping.py';check_one(a.study,driver,study_rev)
core=Path(program['core_build_record']['path']);assert identity(core)==program['core_build_record']
for value in [program['compiler'],program['runtime'],*program['tools'].values()]:
    path=Path(value['path']);assert identity(path)==value;guard[str(path)]=value
output.mkdir(parents=True,exist_ok=False)
modules=output/'source';modules.mkdir()
for rel,item in appfiles.items():
    f=a.application/rel;dest=modules/f.relative_to(a.application/'examples');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
    assert identity(dest)['sha256']==item['sha256'];guard[str(dest)]=identity(dest)
generated=modules/'grouping.py';original=driver.read_text()
replacements=(
    [('paths: list[Path]','paths: list[str]'),('[Path(path) for path in inputs.manifest.test_files]','inputs.manifest.test_files')]
    if a.older_strings else [])
text=original
for before,after in replacements:
    assert text.count(before)==1,(before,text.count(before));text=text.replace(before,after)
generated.write_text(text);guard[str(generated)]=identity(generated)
llvm=output/'grouping.ll';exe=output/'grouping';command=[program['compiler']['path'],'build',str(generated),'--module-root',str(modules),'-o',str(exe),'--runtime',program['runtime']['path'],'--clang',program['tools']['clang']['path'],'--opt-level','3','--emit-llvm',str(llvm),'--target',program['target']]
if program['mode']=='thinlto':command+=['--lto-linker',program['tools']['lto_linker']['path']]
if program['mode']=='asan':command+=['--sanitize']
env=program['environment'];start=time.perf_counter_ns();cp=subprocess.run(command,cwd=a.application,env=env,check=False,capture_output=True,timeout=900);elapsed=time.perf_counter_ns()-start
(output/'stdout').write_bytes(cp.stdout);(output/'stderr').write_bytes(cp.stderr);assert cp.returncode==0,cp.stderr
assert all(identity(Path(k))==v for k,v in guard.items());assert revision(a.application)==rev and revision(a.study)==study_rev
record={'schema':1,'kind':'conformance-grouping-program-build','status':'passed','revision':rev,'study_revision':study_rev,'mode':program['mode'],'target':program['target'],'build_time_utc':datetime.now(timezone.utc).isoformat(),'input_guards_passed':True,'application_inputs':appfiles,'core_build_record':identity(core),'program_record':identity(a.program_record.resolve()),'driver':identity(driver),'generated_driver':identity(generated),'older_string_adapter':replacements,'command':command,'environment':env,'tools':program['tools'],'tool_versions':program['tool_versions'],'runtime':program['runtime'],'compiler':program['compiler'],'llvm':identity(llvm),'binary':identity(exe),'elapsed_ns':elapsed,'recipe':identity(Path(__file__).resolve()),'linked_libraries':bench['shared'].linked_libraries(exe)}
(output/'build-record.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'mode':record['mode'],'revision':rev,'binary':record['binary'],'llvm':record['llvm']}),flush=True)
