"""Independently recompute the grouping call count and the path and memory controls."""

import hashlib
import json
import re
import statistics
from pathlib import Path


def read(path):
    return json.loads(path.read_bytes())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def count_calls(trace, caller_pattern, callee_pattern):
    lines = trace.read_text().splitlines()
    names = {}
    for line in lines:
        match = re.fullmatch(r"c?fn=\((\d+)\) (.+)", line)
        if match:
            identifier, name = match.groups()
            assert names.setdefault(identifier, name) == name
    caller = callee = None
    count = 0
    for line in lines:
        fn = re.match(r"(c?)fn=\((\d+)\)", line)
        if fn:
            if fn[1]:
                callee = names[fn[2]]
            else:
                caller, callee = names[fn[2]], None
        elif line.startswith("calls=") and caller and callee:
            if re.fullmatch(caller_pattern, caller) and re.fullmatch(
                callee_pattern, callee
            ):
                count += int(line.split("=", 1)[1].split()[0])
    return count


def audit_calls(root):
    functions = {
        "before": ("fn_6", "fn_13"),
        "after": ("fn_6", "fn_11"),
        "rust": (r".*::grouping_benchmark::run", r".*::model::group_diagnostics::<.*>"),
    }
    calls = {}
    for engine, names in functions.items():
        counts = [
            count_calls(root / "profiles" / engine / f"callgrind-{n}.out", *names)
            for n in (0, 4)
        ]
        assert counts[1] - counts[0] == 4, (engine, counts)
        calls[engine] = counts
    return calls


def audit_paths(root, configs, orders):
    control = read(root / "path-sensitivity.json")
    assert control["cpu"] == 31
    keys = ("after-long", "after-short", "rust-long", "rust-short")
    expected_order = orders(keys)
    assert set(control["panels"]) == {
        f"{mode}/{scale}" for mode in configs for scale in (1, 10)
    }
    for key, panel in control["panels"].items():
        mode, scale = key.split("/")
        mode_dir = root / "modes" / mode
        base = configs[mode]["fixtures_directory"]
        assert (
            control["revision"] == configs[mode]["revision"]
            and base == control["input_root"]
        )
        counts = control["roots"][scale]
        for variant, prefix in [("long", base), ("short", control["short_root"])]:
            assert (
                counts[variant]
                == len(str(Path(prefix) / f"{scale}x/tests/").encode()) + 1
            )
        assert counts["short"] < counts["long"]
        n = panel["rounds"]
        assert n == {"1": 64, "10": 12}[scale]
        assert panel["schedule"] == expected_order and len(panel["samples"]) == 8
        for i, row in enumerate([panel["warmup"], *panel["samples"]], start=-1):
            assert [v["engine"] for v in row] == expected_order[i % len(expected_order)]
            assert all(v["repeat_ns"] > v["zero_ns"] > 0 for v in row)
        median = {
            e: statistics.median(
                (v["repeat_ns"] - v["zero_ns"]) / n
                for row in panel["samples"]
                for v in row
                if v["engine"] == e
            )
            for e in keys
        }
        ratios = {
            variant: median[f"after-{variant}"] / median[f"rust-{variant}"]
            for variant in ("short", "long")
        }
        assert median == panel["median_ns"] and ratios == panel["ratios"]
        dump = (mode_dir / f"{scale}x-changed-dump.txt").read_bytes()
        short = dump.replace(base.encode(), control["short_root"].encode())
        assert (
            short != dump
            and short.replace(control["short_root"].encode(), base.encode()) == dump
        )
        assert panel["dumps"] == {
            e: sha(short if e.endswith("-short") else dump) for e in keys
        }
        raw = read(mode_dir / "results.json")
        sample = raw["cases"][f"{scale}x/changed-github/group"]["samples"][0][0]
        assert set(panel["outputs"]) == {"0", str(n)}
        assert panel["outputs"]["0"] == sample["zero"]["stdout"]
        # Read the score independently from the complete ordered records. Swapping
        # the first and last diagnostics leaves group membership and sizes unchanged.
        score = group_index = 0
        for record in dump.splitlines():
            fields = record.split(b"\t", maxsplit=2)
            if fields[0] == b"G":
                group_index += 1
                score += group_index
            elif fields[0] == b"D":
                score += {b"old": 1, b"new": 3}[fields[1]] * group_index
            elif fields[0] == b"E":
                score += 5 * group_index
            else:
                assert fields[0] == b"F"
        assert group_index == 1269 * int(scale)
        expected = {
            str(rounds): sha(f"{rounds * score}\n".encode()) for rounds in (0, n)
        }
        assert expected == panel["outputs"]
    return {key: panel["ratios"] for key, panel in control["panels"].items()}


def audit_rss(root, configs, orders):
    out = {}
    schedule = orders()
    for mode, cfg in configs.items():
        rss = read(root / "modes" / mode / "rss.json")
        assert (
            rss["revision"] == cfg["revision"]
            and rss["mode"] == mode
            and rss["cpu"] == 31
        )
        assert set(rss["cases"]) == {"1", "10"}
        for scale, item in rss["cases"].items():
            expected = sha(
                (root / "modes" / mode / f"{scale}x-changed-github.md").read_bytes()
            )
            assert len(item["samples"]) == 6
            for i, row in enumerate([item["warmup"], *item["samples"]], start=-1):
                assert [v["engine"] for v in row] == schedule[i % 6]
                assert all(
                    v["output_sha256"] == expected and v["peak_kib"] > 0 for v in row
                )
            med = {
                e: statistics.median(
                    v["peak_kib"]
                    for row in item["samples"]
                    for v in row
                    if v["engine"] == e
                )
                for e in cfg["engines"]
            }
            assert med == item["median_kib"]
            out[f"{mode}/{scale}"] = med
    return out
