"""Prepare byte-verified study bundles on the source-build host."""
import argparse,hashlib,json,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',required=True,type=Path);p.add_argument('--stage',choices=['references','candidate','sources'],required=True);p.add_argument('--repo',type=Path);p.add_argument('--revision');a=p.parse_args();c=a.cache.resolve();stage=a.stage
sha=lambda b:hashlib.sha256(b).hexdigest()
def add_file(t,f,rel):t.add(f,arcname=str(rel),recursive=False)
name=stage+('-'+a.revision[:8] if a.revision else '');dest=c/(name+'.tar.gz')
with tarfile.open(dest,'w:gz',compresslevel=3) as t:
 if stage=='sources':
  repo=a.repo.resolve();rev=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert rev==a.revision
  files=[*sorted((repo/'examples/conformance_report').rglob('*.py')),*sorted((repo/'stdlib/relar').rglob('*.py')),*sorted((repo/'benchmarks/codon_native').glob('*.py')),*sorted((repo/'benchmarks/reference/conformance_report/src').rglob('*.rs')),*sorted((repo/'benchmarks/native_platform/src').rglob('*.rs'))]
  for sub in ('benchmarks/reference/conformance_report','benchmarks/native_platform'):
   files+= [repo/sub/x for x in ['Cargo.toml','Cargo.lock','build.py']]
  files += list((repo/'benchmarks').glob('conformance_grouping*.py'))+[repo/'benchmarks'/n for n in ('conformance_regex_benchmark.py','conformance_validate.py','benchmark.py','native_tools_benchmark.py','live_conformance_benchmark.py')]
  files += [repo/'LICENSE-APACHE',repo/'LICENSE-MIT']
  sources={}
  for f in sorted(set(files)):
   if '__pycache__' in f.parts:continue
   rel=f.relative_to(repo);b=f.read_bytes();assert subprocess.check_output(['git','show',rev+':'+str(rel)],cwd=repo)==b,f
   sources[str(rel)]=sha(b);add_file(t,f,Path('source')/rel)
  stamp=c/('source-'+rev[:8]+'.json');stamp.write_text(json.dumps({'revision':rev,'files':sources},indent=2)+'\n');add_file(t,stamp,Path('source')/'checkout.json')
 else:
  part='build-base' if stage=='references' else 'build-final';files=[c/part/'core/build-record.json']
  for mode in ('normal','thinlto'):
   for n in ('build-record.json','conformance-report','conformance-report-compute'):
    files.append(c/part/'programs'/mode/n)
   for n in ('build-record.json','grouping','grouping.ll'):
    files.append(c/part/'kernels'/mode/n)
   files.extend((c/part/'kernels'/mode/'source').rglob('*.py'))
   if stage=='references':
    for sub,binname in [('build-rust','conformance-report-reference'),('build-platform','librelar_benchmark_platform.so')]:
     files.extend([c/sub/mode/'build-record.json',c/sub/mode/binname])
  for f in files:add_file(t,f,f.relative_to(c))
print(dest,dest.stat().st_size,sha(dest.read_bytes()),flush=True)
