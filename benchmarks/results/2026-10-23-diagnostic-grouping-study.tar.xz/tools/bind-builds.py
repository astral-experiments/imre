"""Check cross-engine source and ABI binding, on the producer or from archived build records."""
import argparse,hashlib,json,posixpath,re,sys
from pathlib import Path
ROLES={'core-before','program-before','kernel-before','core-after','program-after','kernel-after','rust','platform','codon','source','python'}
def dissect(cfg, archive=None):
    ids=cfg['receipt_ids'];assert set(ids)==ROLES
    def load(role):
        f=Path(ids[role]['path']) if archive is None else archive/(role+'.json')
        data=f.read_bytes();assert len(data)==ids[role]['bytes'] and hashlib.sha256(data).hexdigest()==ids[role]['sha256'],role;return json.loads(data)
    r={role:load(role) for role in ROLES}
    guarded={item['path']:item['sha256'] for item in cfg['guarded_inputs']}
    engines=cfg['engines'];source=r['source']['files'];mode=cfg['mode'];thin=mode=='thinlto';assert r['source']['revision']==cfg['revision']
    for engine in ('before','after'):
        revision=cfg['revision'] if engine=='after' else cfg['baseline_revision']
        core,program,kernel=[r[k+'-'+engine] for k in ('core','program','kernel')]
        assert all(x['status']=='passed' and x['revision']==revision and x['input_guards_passed'] for x in (core,program,kernel))
        assert core['source_matches_revision'] and program['source_matches_revision'] and program['mode']==kernel['mode']==mode
        assert set(program['binaries'])=={'conformance_report','conformance_report-compute'}
        assert kernel['program_record']['sha256']==ids['program-'+engine]['sha256']
        assert {program['core_build_record']['sha256'],kernel['core_build_record']['sha256']}=={ids['core-'+engine]['sha256']}
        assert kernel['driver']['sha256']==source['benchmarks/conformance_grouping.py']
        assert bool(kernel['older_string_adapter'])==(engine=='before')
        if engine=='after':
            assert kernel['generated_driver']['sha256']==kernel['driver']['sha256']
            assert all(source[rel]==item['sha256'] for rel,item in kernel['application_inputs'].items())
        for record in (program,kernel):
            assert record['compiler']['sha256']==core['sha256']['compiler'] and record['runtime']['sha256']==core['sha256'][mode+'_runtime']
        for role,item in (('analysis',kernel['binary']),('report',program['binaries']['conformance_report']),('compute',program['binaries']['conformance_report-compute'])):
            assert item['path']==engines[engine][role][0] and item['sha256']==guarded[item['path']]
        assert ('--lto-linker' in kernel['command'])==thin
        assert all(('--lto-linker' in step['command'])==thin for step in program['steps'])
    rust,platform,codon=r['rust'],r['platform'],r['codon']
    assert rust['thinlto']==platform['thinlto']==thin and rust['input_guards_passed'] and platform['input_guards_passed'] and platform['status']=='passed'
    assert rust['environment']['CARGO_PROFILE_RELEASE_LTO']==platform['environment']['CARGO_PROFILE_RELEASE_LTO']==('thin' if thin else 'off')
    assert r['core-after']['tool_sha256']['rustc']==r['core-before']['tool_sha256']['rustc']==rust['tool_sha256']['rustc']==platform['tool_sha256']['rustc']
    for rec,directory in [(rust,'benchmarks/reference/conformance_report'),(platform,'benchmarks/native_platform')]:
        for key,h in rec['sources'].items():
            path=posixpath.normpath(posixpath.join(directory,key));assert source[path]==h,(path,h)
    assert all(guarded[cmd[0]]==rust['binary_sha256'] for cmd in engines['rust'].values())
    assert engines['rust']['analysis'][1:]==['--grouping'] and engines['rust']['compute'][1:]==['--compute'] and engines['rust']['report'][1:]==[]
    assert codon['release']=='v0.20.4' and codon['status']=='passed' and codon['domain']['python_interop'] is False
    assert codon['native_platform']['sha256']==platform['library']['sha256']==guarded[platform['library']['path']]
    for command in codon['commands']:
        assert command['returncode']==0 and command['command'][1:6]==['build','-release','-numerics=py','-disable-native','-exe']
    for name,role in (('conformance_report','report'),('conformance_report-compute','compute'),('conformance_report-grouping','analysis')):
        item=codon['binaries'][name];assert item['path']==engines['codon'][role][0] and guarded[item['path']]==item['sha256']
    for path,h in codon['source_inputs'].items():
        if '/source/' in path:
            rel=path.split('/source/',1)[1];assert source[rel]==h,(rel,h)
    py=r['python'];assert re.match(r'3\.14\.',py['version']) and py['executable']['sha256']==guarded[py['executable']['path']]
    assert all(command[0]==py['executable']['path'] for name in ('upstream','cpython') for command in engines[name].values())
    assert {str(f['path']) for f in cfg['build_records']}=={v['path'] for v in ids.values()}
    return {'mode':mode,'revision':cfg['revision'],'baseline_revision':cfg['baseline_revision'],'roles':sorted(ROLES),'guarded':len(guarded),'study_driver':source['benchmarks/conformance_grouping.py'],'ohm_rustc_sha256':rust['tool_sha256']['rustc'],'codon':codon['release'],'cpython':py['version'].split()[0]}
if __name__=='__main__':
    assert not sys.flags.optimize
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('config',type=Path);p.add_argument('--records',type=Path);a=p.parse_args();print(json.dumps(dissect(json.loads(a.config.read_bytes()),a.records),indent=2))
