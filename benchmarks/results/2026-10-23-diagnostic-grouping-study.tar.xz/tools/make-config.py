"""Bind the six benchmark engine commands to the immutable source/toolchain receipts."""
import argparse,hashlib,json,os,platform,re,runpy,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--mode',choices=['normal','thinlto'],required=True);p.add_argument('--python',type=Path,required=True);a=p.parse_args();c=a.cache.resolve();s=c/'source';mode=a.mode
def fid(path):
    path=Path(path);b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(p.read_bytes())
source=read(s/'checkout.json');bpath=(c/'build-base').resolve();apath=(c/'build-final').resolve();rs=(c/'build-rust'/mode).resolve();plat=(c/'build-platform'/mode).resolve();cod=(c/'build-codon'/mode).resolve();d=c/'configs'/mode;d.mkdir(parents=True,exist_ok=False)
cfg={'schema':1,'mode':mode,'revision':source['revision'],'baseline_revision':read(bpath/'core/build-record.json')['revision'],'fixtures_directory':str((c/'fixtures').resolve()),'validation_directory':str(c/'validation'/mode),'engines':{},'host':platform.uname()._asdict()}
receipts={'source':s/'checkout.json','rust':rs/'build-record.json','codon':cod/'build-record.json','platform':plat/'build-record.json'}
for engine,base in [('before',bpath),('after',apath)]:
    for role,receipt in [('core',base/'core/build-record.json'),('program',base/'programs'/mode/'build-record.json'),('kernel',base/'kernels'/mode/'build-record.json')]:receipts[role+'-'+engine]=receipt
    cfg['engines'][engine]={'analysis':[str(base/'kernels'/mode/'grouping')],'report':[str(base/'programs'/mode/'conformance-report')],'compute':[str(base/'programs'/mode/'conformance-report-compute')]}
ref=str(rs/'conformance-report-reference')
cfg['engines']['rust']={'analysis':[ref,'--grouping'],'report':[ref],'compute':[ref,'--compute']}
cfg['engines']['codon']={key:[str(cod/name)] for key,name in [('analysis','conformance_report-grouping'),('report','conformance_report'),('compute','conformance_report-compute')]}
v=runpy.run_path(str(s/'benchmarks/conformance_validate.py'))
def pypath(entry):
    bootstrap="import runpy,sys;root=sys.argv.pop(1);script=sys.argv.pop(1);sys.path[:0]=[root+'/examples',root+'/stdlib',root+'/benchmarks'];sys.argv[0]=script;runpy.run_path(script,run_name='__main__')"
    return [str(a.python),'-P','-s','-B','-c',bootstrap,str(s),str(s/'benchmarks'/entry)]
cfg['engines']['upstream']={'analysis':pypath('conformance_grouping_upstream.py'),'report':v['original_command'](a.python),'compute':v['original_compute_command'](a.python)}
cfg['engines']['cpython']={'analysis':pypath('conformance_grouping.py'),'report':v['python_command'](a.python),'compute':v['python_compute_command'](a.python)}
py=subprocess.check_output([str(a.python),'-P','-s','-B','-c',
    "import importlib.metadata,json,platform,sys,sysconfig;print(json.dumps({'version':sys.version,'build':platform.python_build(),'implementation':sys.implementation.name,'configuration':sysconfig.get_config_var('CONFIG_ARGS'),'libdir':sysconfig.get_config_var('LIBDIR'),'library':sysconfig.get_config_var('LDLIBRARY'),'packages':sorted([[d.metadata['Name'],d.version] for d in importlib.metadata.distributions()])}))"],text=True)
py=json.loads(py);py['executable']=fid(a.python);python_rec=d/'python.json';python_rec.write_text(json.dumps(py,indent=2)+'\n');receipts['python']=python_rec
guard=set()
for e in cfg['engines'].values():
    for cmd in e.values():guard.add(Path(cmd[0]))
for path in source['files']:
    f=s/path;assert fid(f)['sha256']==source['files'][path],f;guard.add(f)
codrec=read(receipts['codon'])
for f in [plat/'librelar_benchmark_platform.so',Path(codrec['compiler']),*[Path(val['path']) for val in codrec['libraries'].values()]]:guard.add(f)
for f,h in codrec['generated'].items():
    f=cod/'source'/f;assert fid(f)['sha256']==h;guard.add(f)
libs={}
for exe in sorted({Path(cmd[0]) for e in cfg['engines'].values() for cmd in e.values()}):
    listing=subprocess.check_output(['ldd',str(exe)],text=True);assert 'not found' not in listing;libs[str(exe)]=listing
    for item in re.findall(r'(?:=> )?(/\S+) \(0x',listing):guard.add(Path(item))
for f in receipts.values():guard.add(f)
getcpu=subprocess.check_output(['lscpu','--json'],text=True);cfg['cpu_details']=json.loads(getcpu);cfg['linked_libraries']=libs;cfg['perf_counter']=__import__('time').get_clock_info('perf_counter').implementation
cfg['guarded_inputs']=[fid(f) for f in sorted(guard)];cfg['receipt_ids']={name:fid(path) for name,path in receipts.items()};cfg['build_records']=list(cfg['receipt_ids'].values())
target=d/'config.json';target.write_text(json.dumps(cfg,indent=2)+'\n');result=runpy.run_path(str(c/'bind-builds.py'))['dissect'](cfg);(d/'binding.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
