"""Run both validated six-engine modes serially on one isolated CPU; retain failures for diagnosis."""
import argparse,json,os,subprocess,sys,shutil
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--cpu',type=int,default=31);p.add_argument('--python',type=Path,required=True);p.add_argument('--modes',nargs='+',choices=['normal','thinlto'],default=['normal','thinlto']);a=p.parse_args();c=a.cache.resolve();s=c/'source/benchmarks';failed=False
for mode in a.modes:
    subprocess.run([str(a.python),'-B',str(c/'make-config.py'),'--cache',str(c),'--mode',mode,'--python',str(a.python)],check=True)
    config=c/'configs'/mode/'config.json';validation=c/'validation'/mode;validation.parent.mkdir(exist_ok=True)
    subprocess.run(['taskset','-c',str(a.cpu),str(a.python),'-B','-u',str(s/'conformance_grouping_validate.py'),'--config',str(config),'--output',str(validation),'--seeds','96'],check=True)
    out=c/'measurements'/mode;out.parent.mkdir(exist_ok=True)
    command=[str(a.python),'-B','-u',str(s/'conformance_grouping_benchmark.py'),'--config',str(config),'--fixtures',str(c/'fixtures'),'--output',str(out),'--cpu',str(a.cpu),'--samples','12']
    result=subprocess.run(command,check=False);raw=json.loads((out/'results.json').read_bytes());assert raw['completed'] and (result.returncode==0)==raw['time_target_met']
    audit=subprocess.run([str(a.python),'-B','-u',str(s/'conformance_grouping_audit.py'),str(out),'--verify-host'],capture_output=True,text=True);assert not audit.stderr and (audit.returncode==0)==raw['time_target_met'],audit.stderr;(out/'strict-audit.json').write_text(audit.stdout)
    shutil.copy2(validation/'validation.json',out/'validation.json');shutil.copy2(c/'configs'/mode/'binding.json',out/'binding.json')
    records=out/'records';records.mkdir();receipt=json.loads(config.read_bytes())['receipt_ids']
    for role,item in receipt.items():shutil.copy2(item['path'],records/(role+'.json'))
    print('strict audit',mode,audit.stdout,flush=True)
    if not raw['time_target_met']:failed=True
sys.exit(int(failed))
