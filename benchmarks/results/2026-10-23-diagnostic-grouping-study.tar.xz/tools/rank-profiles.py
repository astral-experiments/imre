"""Compute disjoint Callgrind self costs and DHAT allocation stacks per extra group pass."""
from collections import Counter
import argparse,json,re
from pathlib import Path
def split_cpu(path):
    lines=path.read_text().splitlines();assert 'positions: line' in lines and 'events: Ir' in lines
    names={s[1]:s[2] for l in lines if (s:=re.fullmatch(r'c?fn=\((\d+)\) (.*)',l))}
    self_ir=Counter();fn=None;edge=False
    for l in lines:
        if (m:=re.match(r'fn=\((\d+)\)',l)):fn=names[m[1]];edge=False
        elif l.startswith('calls='):edge=True
        elif (m:=re.fullmatch(r'(?:[+-]?\d+|\*) (\d+)',l)):
            if not edge:self_ir[fn]+=int(m[1])
            edge=False
    total=int(next(l.split()[1] for l in lines if l.startswith('summary:')));assert total==sum(self_ir.values()),(total,sum(self_ir.values()))
    return self_ir
def split_alloc(path,key):
    data=json.loads(path.read_bytes());points=Counter()
    for p in data['pps']:
        # Normalize instruction addresses while preserving the whole allocating call stack.
        stack=tuple(re.sub(r'^0x[0-9a-fA-F]+: ','',data['ftbl'][i]) for i in p['fs'])
        points[stack]+=p[key]
    return points
def deltas(z,n,k):
    vals={name:(n[name]-z[name])/k for name in n.keys()|z.keys() if n[name]!=z[name]}
    return sorted(vals.items(),key=lambda t:(-t[1],t[0]))
def ranks(directory):
    pd=Path(directory);cg=json.loads((pd/'callgrind-summary.json').read_bytes());n=cg['runs'][1]['rounds'];cpu=deltas(split_cpu(pd/'callgrind-0.out'),split_cpu(pd/f'callgrind-{n}.out'),n);dh=json.loads((pd/'dhat-summary.json').read_bytes());assert n==dh['runs'][1]['rounds']
    result={'instructions':cpu}
    for k in ('tbk','tb'):
        pairs=deltas(split_alloc(pd/'dhat-0.json',k),split_alloc(pd/f'dhat-{n}.json',k),n)
        assert sum(v for f,v in pairs)==dh['net_per_pass'][k]
        result[k]=pairs
    assert sum(v for f,v in cpu)==cg['net_per_pass']['instructions']
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('directory',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();data=ranks(a.directory);a.output.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({'instructions':data['instructions'][:10],'top_allocation_stacks':[[[s for s in f if 'relar_' in s][-3:],v] for f,v in data['tbk'][:5]]},indent=2))
