"""Use the candidate native toolchain with the original checked benchmark/application source."""
import argparse,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);a=p.parse_args();c=a.cache.resolve()
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for mode in ('normal','thinlto'):
 old=(c/'build-base/kernels'/mode).resolve();root=c/'source-control'/mode;root.mkdir(parents=True,exist_ok=False)
 new=c/'build-final/kernels'/mode;oldrec=json.loads((old/'build-record.json').read_bytes());newrec=json.loads((new/'build-record.json').read_bytes());assert mode==newrec['mode']==oldrec['mode'] and oldrec['driver']['sha256']==newrec['driver']['sha256'] 
 mods=old/'source'
 for rel,original in oldrec['application_inputs'].items():assert sha(mods/Path(rel).relative_to('examples'))==original['sha256']
 entry=mods/'grouping.py';assert sha(entry)==oldrec['generated_driver']['sha256']
 cmd=list(newrec['command']);cmd[2]=str(entry);cmd[cmd.index('--module-root')+1]=str(mods);cmd[cmd.index('-o')+1]=str(root/'grouping');cmd[cmd.index('--emit-llvm')+1]=str(root/'grouping.ll')
 assert sha(Path(cmd[0]))==newrec['compiler']['sha256'] and sha(Path(cmd[cmd.index('--runtime')+1]))==newrec['runtime']['sha256']
 subprocess.run(cmd,env=newrec['environment'],capture_output=True,timeout=600,check=True)
 receipt={'mode':mode,'source_revision':oldrec['revision'],'compiler_revision':newrec['revision'],'compiler':newrec['compiler'],'runtime':newrec['runtime'],'original_source_record_sha256':sha(old/'build-record.json'),'candidate_record_sha256':sha(new/'build-record.json'),'command':cmd,'generated_source_sha256':sha(entry),'binary_sha256':sha(root/'grouping'),'ir_sha256':sha(root/'grouping.ll')}
 (root/'build-record.json').write_text(json.dumps(receipt,indent=2)+'\n');print(mode,receipt['binary_sha256'],flush=True)
