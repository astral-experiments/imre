# Diagnostic grouping study

Run the offline audit from the unpacked directory with CPython 3.14. It requires the standard library and a filesystem that supports symlinks.

```sh
python3.14 -B tools/replay.py .
```

This hashes each indexed file, replays all 32 measured panels from the raw process times, checks the source-to-executable bindings, reproduces all upstream outputs from the captured source tree, and reruns the 211 focused and seeded observations. It also independently recomputes the six-engine memory results, path-length controls, profile counters and kernel call counts. The `--skip-seeded-replay` option skips reexecuting the synthetic oracle while retaining checks on all recorded native comparisons. Both commands use Python assertions. Any failed canonical 2× gate exits nonzero. The path-length and other-host controls report their actual ratios separately.

## Inputs and build commands

`previous-source/` contains every prior port module and its two recorded type-annotation adaptations in the common grouping driver. `source/checkout.json` identifies the measured Git revision and SHA-256 of the source files. `modes/{normal,thinlto}/records/` contains a receipt for each compiler/runtime build, report program/LLVM grouping kernel, Rust executable, Codon executable, platform library and CPython installation. These receipts record compilation flags, environment, tools, and executable hashes. `modes/{normal,thinlto}/results.json` contains the actual six-engine argv for each role, all raw observations, path-sensitive fixture manifest, guarded sources and dynamic libraries.

To generate the real inputs and run the recorded upstream grouping code from the unpacked archive, on either Linux or macOS:

```sh
python3.14 -B source/benchmarks/conformance_grouping_inputs.py \
  --changed-captures captures/changed-github \
  --unchanged-captures captures/unchanged-github \
  --source-directory captures/suite --output /tmp/relar-grouping-inputs
python3.14 -B source/benchmarks/conformance_grouping_upstream.py dump \
  /tmp/relar-grouping-inputs/1x/changed/manifest.json \
  /tmp/relar-grouping-inputs/1x/changed/old.json \
  /tmp/relar-grouping-inputs/1x/changed/new.json 1
```

For a fresh timed run, check out the two Relar revisions in the per-mode results. Use the recorded Ohm/Rust version, Clang, ThinLTO linker, CPython and native Codon. The application is under `examples/conformance_report` and the Rust reference and Codon preparation under `benchmarks/reference/conformance_report` and `benchmarks/codon_native`. `tools/build-grouping.py` builds the kernel with the link flags and runtime specified by a verified program receipt. Pass `--older-strings` for the previous application. `tools/make-config.py` resolves the guarded per-engine commands. Once these executable and receipt paths exist on the benchmark host, `tools/run-formal.py --cache STUDY_CACHE --cpu CPU --python /path/to/python3.14` runs both link modes in series, with the focused and seeded correctness campaign before each timed matrix, then the on-host source and binary audit. The `codon-native/` directory holds the 20 generated native Codon modules measured in both modes, each bound to the per-mode build record. The commands in `tools/` and the matching receipt `command` entries preserve the exact measured build and validation recipe. The study does not redistribute installed toolchains or native executables.

To collect CPU and allocation profiles, see `tools/profile-kernel.py` and `tools/rank-profiles.py`. The raw Callgrind and DHAT traces are under `profiles/`, with separate cache simulations under `cache-probes/`. ELF symbol names in the retained LLVM and full call-chain data permit inspection beyond the published totals. `tools/path-sensitivity.py` and `tools/peak-rss.py` ran only after the wall-time matrix finished. The separate source attribution uses `tools/source-control-{build,pilot}.py` and its own recorded binaries. Validation receipts for the real live checkout and both ordinary and sanitized application campaigns are under `qa/`.
