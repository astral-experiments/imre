import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import tempfile
import time


root = Path('/home/dev-user/code/oss/imre-diagnostic-pipeline')
cache = Path('/home/dev-user/.cache')
live = cache / 'imre/diagnostic-pipeline-20261023/production-gather-validation'
suite = Path('/home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance')
old = cache / 'imre-native-tools-20261021/input-tools/ty-0.0.60/bin/ty'
new = cache / 'imre/memory-uv/archive-v0/YYGFTbINyot7UutP/bin/ty'
commands = {
    'upstream': ['/home/dev-user/.local/bin/python3.14', '-s', '-B', str(root / 'examples/conformance_report/original_live.py')],
    'imre': [str(live / 'report')],
    'rust': [str(cache / 'imre/grouping-study-20261023/final-7178431/build-rust/normal/conformance-report-reference')],
}
schedule = [s.split() for s in ['upstream imre rust','imre rust upstream','rust upstream imre','rust imre upstream','upstream rust imre','imre upstream rust']]
env = {**os.environ, 'RAYON_NUM_THREADS': '2', 'PYTHONHASHSEED': '0', 'PYTHONPATH': str(root / 'examples/conformance_report')}
oracle = (live / 'live/changed-github-upstream.md').read_bytes()
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
fingerprints = {key: [digest(command[0])] for key, command in commands.items()}
fingerprints['upstream'].append(digest(commands['upstream'][-1]))
record = {'suite':str(suite),'suite_revision': subprocess.check_output(['git','-C',suite,'rev-parse','HEAD'],text=True).strip(), 'imre_revision':'7178431490cd6d8838b67daca89ccbdf03e7ce34', 'cpu_affinity':sorted(os.sched_getaffinity(0)), 'rayon_num_threads':2, 'platform':platform.platform(), 'commands':commands, 'engine_sha256':fingerprints,'analyzer_sha256':[digest(old),digest(new)], 'report_bytes':len(oracle), 'report_sha256':hashlib.sha256(oracle).hexdigest(), 'warmup':[], 'samples':[]}
with tempfile.TemporaryDirectory(prefix='imre-102-live-time-') as folder:
    output = Path(folder) / 'published.md'
    arguments = ['--suite',str(suite),'--old-ty',str(old),'--new-ty',str(new),'--timeout','30','--format','github','--output',str(output)]
    record['arguments'] = arguments
    for i, order in enumerate([schedule[0], *schedule, *reversed(schedule)]):
        observations = []
        for role in order:
            output.unlink(missing_ok=True)
            start = time.perf_counter_ns()
            proc = subprocess.run(commands[role] + arguments,env=env,capture_output=True,timeout=120)
            elapsed = time.perf_counter_ns()-start
            assert proc.returncode == 0 and not proc.stdout and not proc.stderr, (role,proc.stderr)
            assert output.read_bytes() == oracle, role
            observations.append({'engine':role,'ns':elapsed})
        record['warmup' if i==0 else 'samples'].append(observations)
record['median_ms'] = {role:statistics.median(sample['ns'] for row in record['samples'] for sample in row if sample['engine']==role)/1e6 for role in commands}
record['imre_over_rust'] = record['median_ms']['imre']/record['median_ms']['rust']
destination = live / 'live-timing.json'
destination.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key:record[key] for key in ('median_ms','imre_over_rust','report_bytes','report_sha256')}))
