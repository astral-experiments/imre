
## [Typing conformance results](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/)

### No changes detected ✅

<details>
<summary>Current numbers</summary>

<br>
The percentage of diagnostics emitted that were expected errors held steady at <b>98.24%</b>. The percentage of expected errors that received a diagnostic held steady at <b>98.24%</b>. The number of fully passing files held steady at <b>134/146</b>.

</details>
