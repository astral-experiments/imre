
## [Typing conformance results](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/) improved 🎉

The percentage of diagnostics emitted that were expected errors increased from <b>94.49%</b> to <b>98.24%</b>. The percentage of expected errors that received a diagnostic increased from <b>89.24%</b> to <b>98.24%</b>. The number of fully passing files improved from <b>103/146</b> to <b>134/146</b>.

### Summary

<details>
<summary>How are test cases classified?</summary>

<br>

Each test case represents one expected error annotation or a group of annotations sharing a tag. Counts are per test case, not per diagnostic — multiple diagnostics on the same line count as one. Required annotations (`E`) are true positives when ty flags the expected location and false negatives when it does not. Optional annotations (`E?`) are true positives when flagged but true negatives (not false negatives) when not. Tagged annotations (`E[tag]`) require ty to flag exactly one of the tagged lines; tagged multi-annotations (`E[tag+]`) allow any number up to the tag count. Flagging unexpected locations counts as a false positive.

</details>

| Metric | Old | New | Diff | Outcome |
|--------|-----|-----|------|---------|
| True Positives  | 1012 | 1116 | +104 | ⏫ (✅) |
| False Positives | 59 | 20 | -39 | ⏬ (✅) |
| False Negatives | 122 | 20 | -102 | ⏬ (✅) |
| Total Diagnostics | 1148 | 1180 | +32 | ⏫ |
| Precision | 94.49% | 98.24% | +3.75% | ⏫ (✅) |
| Recall | 89.24% | 98.24% | +9.00% | ⏫ (✅) |
| Passing Files | 103/146 | 134/146 | +31 | ⏫ (✅) |



### Test file breakdown

<details>
<summary>37 files altered</summary>

| File | True Positives | False Positives | False Negatives | Status |
|------|----|----|----|--------|
| [generics_typevartuple_variance.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_variance.py) | 26 (+11) ✅ | 0 (-8) ✅ | 0 (-11) ✅ | ✅ Newly Passing 🎉 |
| [generics_typevartuple_specialization.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_specialization.py) | 6 (+4) ✅ | 0 (-15) ✅ | 0 (-4) ✅ | ✅ Newly Passing 🎉 |
| [aliases_recursive.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_recursive.py) | 11 (+11) ✅ | 0 | 0 (-11) ✅ | ✅ Newly Passing 🎉 |
| [generics_typevartuple_basic.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_basic.py) | 14 (+10) ✅ | 0 (-1) ✅ | 0 (-10) ✅ | ✅ Newly Passing 🎉 |
| [generics_typevartuple_args.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_args.py) | 8 (+8) ✅ | 0 (-3) ✅ | 0 (-8) ✅ | ✅ Newly Passing 🎉 |
| [aliases_typealiastype.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_typealiastype.py) | 23 (+8) ✅ | 0 | 0 (-7) ✅ | ✅ Newly Passing 🎉 |
| [directives_deprecated.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/directives_deprecated.py) | 13 (+7) ✅ | 0 | 0 (-7) ✅ | ✅ Newly Passing 🎉 |
| [protocols_variance.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_variance.py) | 7 (+7) ✅ | 0 | 0 (-7) ✅ | ✅ Newly Passing 🎉 |
| [generics_type_erasure.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_type_erasure.py) | 6 (+4) ✅ | 0 | 0 (-4) ✅ | ✅ Newly Passing 🎉 |
| [dataclasses_slots.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_slots.py) | 5 (+3) ✅ | 0 | 0 (-3) ✅ | ✅ Newly Passing 🎉 |
| [generics_basic.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_basic.py) | 18 (+3) ✅ | 0 | 0 (-3) ✅ | ✅ Newly Passing 🎉 |
| [protocols_explicit.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_explicit.py) | 4 (+3) ✅ | 0 | 2 (-3) ✅ | 📈 Improving |
| [generics_typevartuple_callable.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_callable.py) | 1 (+1) ✅ | 0 (-3) ✅ | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [classes_override.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/classes_override.py) | 7 (+2) ✅ | 0 | 0 (-2) ✅ | ✅ Newly Passing 🎉 |
| [dataclasses_hash.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/dataclasses_hash.py) | 4 (+2) ✅ | 0 | 0 (-2) ✅ | ✅ Newly Passing 🎉 |
| [generics_paramspec_variance.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_paramspec_variance.py) | 22 (+2) ✅ | 0 | 0 (-2) ✅ | ✅ Newly Passing 🎉 |
| [generics_scoping.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_scoping.py) | 14 (+2) ✅ | 0 | 0 (-2) ✅ | ✅ Newly Passing 🎉 |
| [specialtypes_type.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/specialtypes_type.py) | 9 (+2) ✅ | 9 | 0 (-2) ✅ | 📈 Improving |
| [aliases_type_statement.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/aliases_type_statement.py) | 25 (+1) ✅ | 0 (-1) ✅ | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_defaults.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults.py) | 5 | 4 (-3) ✅ | 1 | 📈 Improving |
| [protocols_class_objects.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_class_objects.py) | 5 (+2) ✅ | 0 | 3 (-1) ✅ | 📈 Improving |
| [annotations_forward_refs.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/annotations_forward_refs.py) | 27 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [annotations_future_import.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/annotations_future_import.py) | 4 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [classes_classvar.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/classes_classvar.py) | 19 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [constructors_call_init.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/constructors_call_init.py) | 4 (+1) ✅ | 0 | 1 (-1) ✅ | 📈 Improving |
| [constructors_call_type.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/constructors_call_type.py) | 8 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [exceptions_context_managers.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/exceptions_context_managers.py) | 0 | 0 (-2) ✅ | 0 | ✅ Newly Passing 🎉 |
| [generics_paramspec_components.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_paramspec_components.py) | 16 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_self_usage.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_self_usage.py) | 11 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_typevartuple_unpack.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_unpack.py) | 1 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [protocols_merging.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_merging.py) | 6 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [qualifiers_final_annotation.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/qualifiers_final_annotation.py) | 28 (+1) ✅ | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_defaults_specialization.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_defaults_specialization.py) | 2 | 0 | 0 (-1) ✅ | ✅ Newly Passing 🎉 |
| [generics_mixed_variance_inference.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_mixed_variance_inference.py) | 3 | 0 (-1) ✅ | 0 | ✅ Newly Passing 🎉 |
| [generics_typevartuple_concat.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/generics_typevartuple_concat.py) | 0 | 0 (-1) ✅ | 0 | ✅ Newly Passing 🎉 |
| [narrowing_typeis.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/narrowing_typeis.py) | 9 | 0 (-1) ✅ | 0 | ✅ Newly Passing 🎉 |
| [protocols_definition.py](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/tests/protocols_definition.py) | 23 (+1) ✅ | 0 | 0 | ✅ Still Passing |
| **Total (all files)** | **1116 (+104) ✅** | **20 (-39) ✅** | **20 (-102) ✅** | 134/146 |

</details>


### True positives added (102)

<details>
<summary>102 diagnostics</summary>

```diff
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:19:12: error[invalid-assignment] Object of type `dict[str, None | complex | str | list[Json] | dict[str, Json]]` is not assignable to `Json`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:20:12: error[invalid-assignment] Object of type `list[None | complex | str | list[Json] | dict[str, Json]]` is not assignable to `Json`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:38:22: error[invalid-assignment] Object of type `tuple[Literal[1], tuple[Literal["1"], Literal[1]], tuple[Literal[1], tuple[Literal[1], list[int]]]]` is not assignable to `RecursiveTuple`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:39:22: error[invalid-assignment] Object of type `tuple[Literal[1], list[int]]` is not assignable to `RecursiveTuple`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:50:24: error[invalid-assignment] Object of type `dict[str, list[int]]` is not assignable to `RecursiveMapping`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:51:24: error[invalid-assignment] Object of type `dict[str, str | int | list[int]]` is not assignable to `RecursiveMapping`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:52:24: error[invalid-assignment] Object of type `dict[str, str | int | dict[str, str | int | list[int]]]` is not assignable to `RecursiveMapping`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:63:30: error[invalid-assignment] Object of type `list[list[GenericTypeAlias1[str] | str] | str | list[list[GenericTypeAlias1[str] | str] | str | float]]` is not assignable to `GenericTypeAlias1[str]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:69:35: error[invalid-assignment] Object of type `list[list[GenericTypeAlias2[str, int] | str | int] | str | int | list[list[GenericTypeAlias2[str, int] | str | int] | str | int | list[list[GenericTypeAlias2[str, int] | str | int] | str | int | list[list[GenericTypeAlias2[str, int] | str | int] | str | float]]]]` is not assignable to `GenericTypeAlias2[str, int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:72:29: error[cyclic-type-alias-definition] Type alias `RecursiveUnion` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:75:31: error[cyclic-type-alias-definition] Type alias `MutualReference1` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_recursive.py:75:93: error[cyclic-type-alias-definition] Type alias `MutualReference2` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:75:31: error[cyclic-type-alias-definition] Type alias `RecursiveTypeAlias4` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_typealiastype.py:40:21: error[invalid-type-arguments] Type `int` is not assignable to upper bound `str` of type variable `TStr@GoodAlias5`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_typealiastype.py:43:40: error[invalid-type-alias-type] Type parameter `S` used in the alias value must be included in `type_params`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_typealiastype.py:44:40: error[invalid-type-alias-type] Type parameter `S` used in the alias value must be included in `type_params`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_typealiastype.py:45:57: error[invalid-type-alias-type] The `type_params` argument to `TypeAliasType` must be a tuple literal
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_typealiastype.py:46:40: error[cyclic-type-alias-definition] Type alias `BadAlias4` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_typealiastype.py:47:40: error[cyclic-type-alias-definition] Type alias `BadAlias5` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_typealiastype.py:48:40: error[cyclic-type-alias-definition] Type alias `BadAlias6` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/annotations_forward_refs.py:94:11: error[invalid-type-form] Variable of type `Literal[""]` is not allowed in a type expression
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/annotations_future_import.py:37:10: error[invalid-type-form] Variable of type `Literal[""]` is not allowed in a type expression
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/classes_classvar.py:94:5: error[invalid-named-tuple] Type qualifier `ClassVar` is not allowed on NamedTuple field `b`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/classes_override.py:135:9: error[invalid-method-override] Invalid override of method `__init__`: Definition is incompatible with `ParentC.__init__`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/classes_override.py:138:9: error[invalid-method-override] Invalid override of method `__new__`: Definition is incompatible with `ParentC.__new__`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/constructors_call_init.py:107:32: error[invalid-init-type-variable] First parameter of `__init__` cannot use type variable `T2` from an outer scope
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/constructors_call_init.py:107:36: error[invalid-init-type-variable] First parameter of `__init__` cannot use type variable `T1` from an outer scope
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/constructors_call_type.py:64:9: error[too-many-positional-arguments] Too many positional arguments to `type[T]`: expected 0, got 1
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_hash.py:18:16: error[invalid-assignment] Object of type `DC1` is not assignable to `Hashable`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_hash.py:40:16: error[invalid-assignment] Object of type `DC3` is not assignable to `Hashable`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_slots.py:25:9: error[unresolved-attribute] Unresolved attribute `y` on type `Self@__init__`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_slots.py:38:9: error[unresolved-attribute] Unresolved attribute `y` on type `Self@__init__`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_slots.py:11:7: error[invalid-dataclass] Dataclass `DC1` cannot combine `slots=True` with manually assigned `__slots__`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/directives_deprecated.py:30:1: error[deprecated] The overload of `foo` is Only str will be allowed
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/directives_deprecated.py:41:5: error[deprecated] The function `__add__` is There is enough spam in the world
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/directives_deprecated.py:42:1: error[deprecated] The function `__add__` is There is enough spam in the world
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/directives_deprecated.py:44:6: error[deprecated] The function `greasy` is All spam will be equally greasy
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/directives_deprecated.py:47:6: error[deprecated] The function `shape` is Shapes are becoming immutable
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/directives_deprecated.py:48:6: error[deprecated] The function `shape` is Shapes are becoming immutable
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/directives_deprecated.py:58:1: error[deprecated] The function `__call__` is Deprecated
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_basic.py:40:5: error[invalid-argument-type] Argument to function `concat` is incorrect: Inferred lower bound `str | bytes` does not satisfy constraints (`str`, `bytes`) of type variable `AnyStr`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_basic.py:41:5: error[invalid-argument-type] Argument to function `concat` is incorrect: Inferred lower bound `bytes | str` does not satisfy constraints (`str`, `bytes`) of type variable `AnyStr`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_basic.py:69:5: error[invalid-argument-type] Argument to function `concat` is incorrect: Inferred lower bound `MyStr | bytes` does not satisfy constraints (`str`, `bytes`) of type variable `AnyStr`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults_specialization.py:58:1: error[not-subscriptable] Cannot specialize non-generic class `Foo`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_paramspec_components.py:30:25: error[unbound-type-variable] ParamSpec `P` is not in scope
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_paramspec_variance.py:117:25: error[invalid-generic-class] Variance of type variable `InP` is incompatible with method `out_f`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_paramspec_variance.py:126:23: error[invalid-generic-class] Variance of type variable `OutP` is incompatible with method `in_f`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_scoping.py:107:6: error[unbound-type-variable] Type variable `T` is not bound to any outer generic context
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_scoping.py:98:29: error[invalid-type-form] Type alias cannot capture class-scoped type variable `T`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_self_usage.py:82:54: error[invalid-type-form] `Self` requires `self: Self` or `cls: type[Self]` for annotated receivers
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_type_erasure.py:42:1: error[invalid-attribute-access] Cannot access generic instance attribute `label` through a class
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_type_erasure.py:43:1: error[invalid-attribute-access] Cannot access generic instance attribute `label` through a class
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_type_erasure.py:44:1: error[invalid-attribute-access] Cannot access generic instance attribute `label` through a class
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_type_erasure.py:45:1: error[invalid-attribute-access] Cannot access generic instance attribute `label` through a class
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:33:20: error[invalid-argument-type] Argument to function `exec_le` is incorrect: Expected `Env`, found `Literal[""]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:34:20: error[invalid-argument-type] Argument to function `exec_le` is incorrect: Expected `Env`, found `Literal[""]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:48:10: error[invalid-argument-type] Argument to function `func1` is incorrect: Expected `int`, found `Literal["2"]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:57:10: error[invalid-argument-type] Argument to function `func2` is incorrect: Expected `str`, found `Literal[1]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:58:1: error[missing-argument] No argument provided for required parameter `*args` of function `func2`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:59:1: error[missing-argument] No argument provided for required parameter `*args` of function `func2`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:67:1: error[missing-argument] No argument provided for required parameter `*args` of function `func3`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:75:13: error[invalid-argument-type] Argument to function `func4` is incorrect: Expected `tuple[Literal[0]]`, found `tuple[Literal[1], Literal[2]]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:100:14: error[invalid-argument-type] Argument to function `multiply` is incorrect: Expected `Array[Height | Width]`, found `Array[Height]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:100:17: error[invalid-argument-type] Argument to function `multiply` is incorrect: Expected `Array[Height | Width]`, found `Array[Width]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:101:17: error[invalid-argument-type] Argument to function `multiply` is incorrect: Expected `Array[Height]`, found `Array[Height, Width]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:107:14: error[invalid-generic-class] Only one `TypeVarTuple` parameter is allowed in a `Generic` subscription
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:111:20: error[invalid-type-form] Generic class `Array4` cannot have multiple `TypeVarTuple` type parameters: `Ts2` is an additional TypeVarTuple
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:44:41: error[invalid-argument-type] Argument to `Array.__init__` is incorrect: Expected `tuple[Batch, Height, Width]`, found `tuple[Batch, Width]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:54:37: error[invalid-type-form] Bare TypeVarTuple `Shape` is not valid in this context in a parameter annotation
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:57:34: error[invalid-type-form] Bare TypeVarTuple `Shape` is not valid in this context in a return type annotation
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:60:24: error[invalid-type-form] Bare TypeVarTuple `Shape` is not valid in this context in a parameter annotation
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:91:15: error[invalid-argument-type] Argument to function `func2` is incorrect: Expected `tuple[Literal[0], Literal[0]]`, found `tuple[Literal[0]]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:45:41: error[invalid-assignment] Object of type `Array[Time, Batch, Width, Height]` is not assignable to `Array[Time, Batch, Height, Width]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_callable.py:26:9: error[invalid-argument-type] Argument to `Process.__init__` is incorrect: Expected `(int | Literal[""], str | Literal[0], /) -> None`, found `def func1(arg1: int, arg2: str) -> None`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:109:17: error[invalid-type-form] `*` can only unpack a tuple type or `TypeVarTuple`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:110:17: error[invalid-type-form] `Unpack` can only be used with a fixed tuple type in this context
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:127:5: error[invalid-type-arguments] No type arguments provided for required type variables `T1`, `T2`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:163:13: error[invalid-type-form] A TypeVarTuple cannot be split to provide a fixed type argument
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_unpack.py:30:28: error[invalid-argument-type] Argument to function `process_batch_channels` is incorrect: Expected `Array[*tuple[Batch, *tuple[Any, ...], Channels]]`, found `Array[Batch]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:107:66: error[invalid-assignment] Object of type `InferredContravariantTypeVarTupleOld[int]` is not assignable to `InferredContravariantTypeVarTupleOld[object]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:116:60: error[invalid-assignment] Object of type `InferredCovariantTypeVarTupleOld[object]` is not assignable to `InferredCovariantTypeVarTupleOld[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:56:10: error[invalid-legacy-type-variable] A `TypeVarTuple` cannot be both covariant and contravariant
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:57:10: error[invalid-legacy-type-variable] A `TypeVarTuple` cannot specify variance when `infer_variance=True`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:58:10: error[invalid-legacy-type-variable] A `TypeVarTuple` cannot specify variance when `infer_variance=True`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:68:45: error[invalid-assignment] Object of type `InvariantTypeVarTupleOld[int]` is not assignable to `InvariantTypeVarTupleOld[object]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:69:42: error[invalid-assignment] Object of type `InvariantTypeVarTupleOld[object]` is not assignable to `InvariantTypeVarTupleOld[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:79:24: error[invalid-generic-class] Variance of type variable `InTs` is incompatible with method `out_f`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:83:52: error[invalid-assignment] Object of type `ContravariantTypeVarTupleOld[int]` is not assignable to `ContravariantTypeVarTupleOld[object]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:90:27: error[invalid-generic-class] Variance of type variable `OutTs` is incompatible with method `in_f`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:97:46: error[invalid-assignment] Object of type `CovariantTypeVarTupleOld[object]` is not assignable to `CovariantTypeVarTupleOld[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_class_objects.py:74:16: error[invalid-assignment] Object of type `<class 'ConcreteB'>` is not assignable to `ProtoB1`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_explicit.py:134:6: error[call-non-callable] Cannot instantiate `Concrete5` with unimplemented abstract method `method1`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_explicit.py:164:7: error[call-non-callable] Cannot instantiate `Concrete7A` with unimplemented abstract method `method1`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_explicit.py:60:5: error[call-non-callable] Cannot instantiate `Point` with unimplemented abstract methods `intensity` and `transparency`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_merging.py:82:5: error[call-non-callable] Cannot instantiate `SizedAndClosable4` with unimplemented abstract method `close`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_variance.py:105:7: error[invalid-protocol] Type variable `T1` in protocol `Protocol12` should be covariant, but is invariant
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_variance.py:22:7: error[invalid-protocol] Type variable `T1` in protocol `AnotherBox` should be covariant, but is invariant
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_variance.py:41:7: error[invalid-protocol] Type variable `T3` in protocol `Protocol2` should be contravariant, but is invariant
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_variance.py:57:7: error[invalid-protocol] Type variable `T1` in protocol `Protocol4` should be contravariant, but is invariant
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_variance.py:67:7: error[invalid-protocol] Type variable `T1` in protocol `Protocol6` should be covariant, but is invariant
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_variance.py:72:7: error[invalid-protocol] Type variable `T1_contra` in protocol `Protocol7` should be covariant, but is contravariant
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_variance.py:62:7: error[invalid-protocol] Type variable `T1_co` in protocol `Protocol5` should be contravariant, but is covariant
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/qualifiers_final_annotation.py:136:5: error[invalid-named-tuple] Type qualifier `Final` is not allowed on NamedTuple field `b`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/specialtypes_type.py:144:1: error[unresolved-attribute] Object of type `<special-form 'type[Any]'>` has no attribute `unknown`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/specialtypes_type.py:146:1: error[unresolved-attribute] Object of type `<special-form 'type[Any]'>` has no attribute `unknown`
```
</details>

### False positives removed (41)

<details>
<summary>41 diagnostics</summary>

```diff
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:10:52: error[invalid-type-arguments] Too many type arguments: expected 2, got 3
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:10:52: error[invalid-type-form] `...` is not allowed in this context in a type alias value
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/exceptions_context_managers.py:50:5: error[type-assertion-failure] Type `str` does not match asserted type `int | str`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/exceptions_context_managers.py:57:5: error[type-assertion-failure] Type `str` does not match asserted type `int | str`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:139:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[str, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:140:5: error[type-assertion-failure] Type `Class_TypeVarTuple` does not match asserted type `@Todo`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:200:17: error[invalid-type-form] The first argument to `Callable` must be either a list of types, ParamSpec, Concatenate, or `...`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:207:5: error[type-assertion-failure] Type `@Todo` does not match asserted type `tuple[int, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:208:5: error[type-assertion-failure] Type `@Todo` does not match asserted type `(bytes, /) -> None`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:17:16: error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:17:21: error[invalid-type-arguments] Too many type arguments to class `Mixed`: expected 2, got 3
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:17:21: error[invalid-type-form] List literals are not allowed in this context in a type expression
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:17:38: error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:17:44: error[invalid-type-arguments] Too many type arguments to class `Mixed`: expected 2, got 3
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:17:44: error[invalid-type-form] List literals are not allowed in this context in a type expression
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:29:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:31:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[()]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_args.py:32:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:85:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_callable.py:41:1: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[str, int, int | float | complex]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_callable.py:42:1: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_callable.py:50:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int | float | complex, str, int | float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_concat.py:53:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int, bool, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:135:5: error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown]` does not match asserted type `tuple[tuple[()], str, bool]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:136:5: error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown]` does not match asserted type `tuple[tuple[str], bool, int | float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:137:5: error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown]` does not match asserted type `tuple[tuple[str, bool], int | float, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:148:5: error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown, Unknown]` does not match asserted type `tuple[tuple[()], str, bool, int | float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:149:5: error[type-assertion-failure] Type `tuple[tuple[@Todo(TypeVarTuple), ...], Unknown, Unknown, Unknown]` does not match asserted type `tuple[tuple[bool], str, int | float, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:157:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[*tuple[int, ...], int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:158:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[*tuple[int, ...], str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:159:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[*tuple[int, ...], str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:45:40: error[not-subscriptable] Cannot subscript non-generic type `<class 'tuple[str, @Todo]'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:46:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int, int | float, bool]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:47:5: error[type-assertion-failure] Type `Unknown` does not match asserted type `tuple[str, @Todo]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:51:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:93:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[str, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:94:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[int | float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_specialization.py:95:5: error[type-assertion-failure] Type `tuple[@Todo(TypeVarTuple), ...]` does not match asserted type `tuple[Any, *tuple[Any, ...]]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:16:14: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:29:9: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:29:42: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:30:18: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:30:64: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:33:25: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:33:58: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:43:10: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:43:42: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:44:16: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:44:50: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:49:22: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:49:67: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:52:26: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:52:68: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/narrowing_typeis.py:35:18: error[invalid-assignment] Object of type `object` is not assignable to `int`
```
</details>

### True positives changed (98)

<details>
<summary>98 diagnostics</summary>

```diff
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_implicit.py:81:25: error[invalid-type-arguments] Type `str` is not assignable to upper bound `int | float` of type variable `TFloat@GoodTypeAlias12`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_implicit.py:81:25: error[invalid-type-arguments] Type `str` is not assignable to upper bound `float` of type variable `TFloat@GoodTypeAlias12`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_newtype.py:23:16: error[invalid-argument-type] Argument to function `isinstance` is incorrect: Expected `type | UnionType | tuple[Divergent, ...]`, found `<NewType pseudo-class 'UserId'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_newtype.py:23:16: error[invalid-argument-type] Argument to function `isinstance` is incorrect: Expected `_ClassInfo`, found `<NewType pseudo-class 'UserId'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:31:22: error[invalid-argument-type] Argument to function `isinstance` is incorrect: Expected `type | UnionType | tuple[Divergent, ...]`, found `TypeAliasType`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:31:22: error[invalid-argument-type] Argument to function `isinstance` is incorrect: Expected `_ClassInfo`, found `TypeAliasType`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:73:1: error[cyclic-type-alias-definition] Cyclic definition of `RecursiveTypeAlias3`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:73:28: error[cyclic-type-alias-definition] Type alias `RecursiveTypeAlias3` has a circular definition
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:79:1: error[cyclic-type-alias-definition] Cyclic definition of `RecursiveTypeAlias6`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:80:1: error[cyclic-type-alias-definition] Cyclic definition of `RecursiveTypeAlias7`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:79:28: error[cyclic-type-alias-definition] Type alias `RecursiveTypeAlias6` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_type_statement.py:80:28: error[cyclic-type-alias-definition] Type alias `RecursiveTypeAlias7` has a circular definition
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_protocol.py:121:18: error[invalid-assignment] Object of type `def cb6_bad1(*vals: bytes, *, max_len: int | None = None) -> list[bytes]` is not assignable to `NotProto6`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_protocol.py:121:18: error[invalid-assignment] Object of type `def cb6_bad1(*vals: bytes, max_len: int | None = None) -> list[bytes]` is not assignable to `NotProto6`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_protocol.py:260:8: error[invalid-assignment] Object of type `def cb12_bad1(*args: Any, *, kwarg0: Any) -> None` is not assignable to `Proto12`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_protocol.py:260:8: error[invalid-assignment] Object of type `def cb12_bad1(*args: Any, kwarg0: Any) -> None` is not assignable to `Proto12`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_protocol.py:35:7: error[invalid-assignment] Object of type `def cb1_bad1(*vals: bytes, *, max_items: int | None) -> list[bytes]` is not assignable to `Proto1`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_protocol.py:35:7: error[invalid-assignment] Object of type `def cb1_bad1(*vals: bytes, max_items: int | None) -> list[bytes]` is not assignable to `Proto1`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_protocol.py:37:7: error[invalid-assignment] Object of type `def cb1_bad3(*vals: bytes, *, max_len: str | None) -> list[bytes]` is not assignable to `Proto1`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_protocol.py:37:7: error[invalid-assignment] Object of type `def cb1_bad3(*vals: bytes, max_len: str | None) -> list[bytes]` is not assignable to `Proto1`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_subtyping.py:26:36: error[invalid-assignment] Object of type `(int, /) -> int` is not assignable to `(int | float, /) -> int | float`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_subtyping.py:26:36: error[invalid-assignment] Object of type `(int, /) -> int` is not assignable to `(float, /) -> float`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_subtyping.py:29:32: error[invalid-assignment] Object of type `(int | float, /) -> int | float` is not assignable to `(int, /) -> int`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/callables_subtyping.py:29:32: error[invalid-assignment] Object of type `(float, /) -> float` is not assignable to `(int, /) -> int`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/constructors_call_init.py:21:13: error[invalid-argument-type] Argument to `Class1.__init__` is incorrect: Expected `int`, found `float`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/constructors_call_init.py:21:13: error[invalid-argument-type] Argument to `Class1.__init__` is incorrect: Expected `int`, found `float*`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/constructors_call_new.py:21:13: error[invalid-argument-type] Argument to constructor `Class1.__new__` is incorrect: Expected `int`, found `float`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/constructors_call_new.py:21:13: error[invalid-argument-type] Argument to constructor `Class1.__new__` is incorrect: Expected `int`, found `float*`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_transform_converter.py:109:29: error[invalid-argument-type] Argument is incorrect: Expected `str | list[str]`, found `complex`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_transform_converter.py:109:29: error[invalid-argument-type] Argument is incorrect: Expected `str | list[str]`, found `complex*`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_usage.py:52:28: error[invalid-argument-type] Argument is incorrect: Expected `int | float`, found `Literal["price"]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/dataclasses_usage.py:52:28: error[invalid-argument-type] Argument is incorrect: Expected `float`, found `Literal["price"]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_basic.py:241:26: error[invalid-argument-type] Argument to function `takes_two_int_lists` is incorrect: Argument type `int | str` does not satisfy upper bound `int` of type variable `T_int`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_basic.py:241:26: error[invalid-argument-type] Argument to function `takes_two_int_lists` is incorrect: Expected `list[int]`, found `list[int | str]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_basic.py:241:26: error[invalid-argument-type] Argument to function `takes_two_int_lists` is incorrect: Argument type `int | str` does not satisfy upper bound `int` of type variable `T_int`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:16:16: error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:16:21: error[invalid-type-arguments] Too many type arguments to class `Mixed`: expected 2, got 3
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:16:21: error[invalid-type-form] List literals are not allowed in this context in a type expression
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:16:38: error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:16:46: error[invalid-type-arguments] Too many type arguments to class `Mixed`: expected 2, got 3
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:16:46: error[invalid-type-form] List literals are not allowed in this context in a type expression
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_mixed_variance_inference.py:16:27: error[invalid-assignment] Object of type `Mixed[int, object, ()]` is not assignable to `Mixed[int, int, ()]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_self_usage.py:108:30: error[invalid-type-form] `Self` cannot be used in a type alias
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_self_usage.py:108:30: error[invalid-type-form] Variable of type `<special-form 'typing.Self'>` is not allowed in a type expression
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:112:38: error[invalid-assignment] Object of type `ShouldBeInvariant1[int]` is not assignable to `ShouldBeInvariant1[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:112:38: error[invalid-assignment] Object of type `ShouldBeInvariant1[int]` is not assignable to `ShouldBeInvariant1[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:113:36: error[invalid-assignment] Object of type `ShouldBeInvariant1[int | float]` is not assignable to `ShouldBeInvariant1[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:113:36: error[invalid-assignment] Object of type `ShouldBeInvariant1[float]` is not assignable to `ShouldBeInvariant1[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:127:38: error[invalid-assignment] Object of type `ShouldBeInvariant2[int]` is not assignable to `ShouldBeInvariant2[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:127:38: error[invalid-assignment] Object of type `ShouldBeInvariant2[int]` is not assignable to `ShouldBeInvariant2[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:128:36: error[invalid-assignment] Object of type `ShouldBeInvariant2[int | float]` is not assignable to `ShouldBeInvariant2[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:128:36: error[invalid-assignment] Object of type `ShouldBeInvariant2[float]` is not assignable to `ShouldBeInvariant2[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:135:43: error[invalid-assignment] Object of type `ShouldBeInvariant3[int, str]` is not assignable to `ShouldBeInvariant3[int | float, str]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:135:43: error[invalid-assignment] Object of type `ShouldBeInvariant3[int, str]` is not assignable to `ShouldBeInvariant3[float, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:136:41: error[invalid-assignment] Object of type `ShouldBeInvariant3[int | float, str]` is not assignable to `ShouldBeInvariant3[int, str]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:136:41: error[invalid-assignment] Object of type `ShouldBeInvariant3[float, str]` is not assignable to `ShouldBeInvariant3[int, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:137:43: error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int]` is not assignable to `ShouldBeInvariant3[str, int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:137:43: error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int]` is not assignable to `ShouldBeInvariant3[str, float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:138:41: error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int | float]` is not assignable to `ShouldBeInvariant3[str, int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:138:41: error[invalid-assignment] Object of type `ShouldBeInvariant3[str, float]` is not assignable to `ShouldBeInvariant3[str, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:146:38: error[invalid-assignment] Object of type `ShouldBeInvariant4[int]` is not assignable to `ShouldBeInvariant4[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:146:38: error[invalid-assignment] Object of type `ShouldBeInvariant4[int]` is not assignable to `ShouldBeInvariant4[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:154:38: error[invalid-assignment] Object of type `ShouldBeInvariant5[int]` is not assignable to `ShouldBeInvariant5[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:154:38: error[invalid-assignment] Object of type `ShouldBeInvariant5[int]` is not assignable to `ShouldBeInvariant5[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:165:45: error[invalid-assignment] Object of type `ShouldBeContravariant1[int]` is not assignable to `ShouldBeContravariant1[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:165:45: error[invalid-assignment] Object of type `ShouldBeContravariant1[int]` is not assignable to `ShouldBeContravariant1[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:29:35: error[invalid-assignment] Object of type `ShouldBeCovariant1[int | float]` is not assignable to `ShouldBeCovariant1[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:29:35: error[invalid-assignment] Object of type `ShouldBeCovariant1[float]` is not assignable to `ShouldBeCovariant1[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:47:35: error[invalid-assignment] Object of type `ShouldBeCovariant2[int | float]` is not assignable to `ShouldBeCovariant2[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:47:35: error[invalid-assignment] Object of type `ShouldBeCovariant2[float]` is not assignable to `ShouldBeCovariant2[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:56:35: error[invalid-assignment] Object of type `ShouldBeCovariant3[int | float]` is not assignable to `ShouldBeCovariant3[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:56:35: error[invalid-assignment] Object of type `ShouldBeCovariant3[float]` is not assignable to `ShouldBeCovariant3[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:85:34: error[invalid-assignment] Object of type `ShouldBeCovariant5[int | float]` is not assignable to `ShouldBeCovariant5[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:85:34: error[invalid-assignment] Object of type `ShouldBeCovariant5[float]` is not assignable to `ShouldBeCovariant5[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:96:34: error[invalid-assignment] Object of type `ShouldBeCovariant6[int | float]` is not assignable to `ShouldBeCovariant6[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_syntax_infer_variance.py:96:34: error[invalid-assignment] Object of type `ShouldBeCovariant6[float]` is not assignable to `ShouldBeCovariant6[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:43:34: error[invalid-argument-type] Argument to `Array.__init__` is incorrect: Expected `tuple[@Todo(TypeVarTuple), ...]`, found `Height`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:43:34: error[invalid-argument-type] Argument to `Array.__init__` is incorrect: Expected `tuple[Height, Width]`, found `Height`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:66:27: error[too-many-positional-arguments] Too many positional arguments to constructor `TypeVarTuple.__new__`: expected 2, got 4
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:66:7: error[invalid-legacy-type-variable] `TypeVarTuple` can only have one positional argument
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:67:27: error[unknown-argument] Argument `bound` does not match any known parameter of constructor `TypeVarTuple.__new__`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_basic.py:67:27: error[invalid-legacy-type-variable] The `bound` parameter of `typing.TypeVarTuple` was added in Python 3.15
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:14:13: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:14:45: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:14:45: error[invalid-assignment] Object of type `InvariantTypeVarTuple[int]` is not assignable to `InvariantTypeVarTuple[object]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:15:13: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:15:42: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:15:42: error[invalid-assignment] Object of type `InvariantTypeVarTuple[object]` is not assignable to `InvariantTypeVarTuple[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:17:22: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:17:64: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:17:64: error[invalid-assignment] Object of type `InvariantTypeVarTuple[*tuple[object, ...]]` is not assignable to `InvariantTypeVarTuple[*tuple[int, ...]]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:18:25: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:18:70: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:18:70: error[invalid-assignment] Object of type `InvariantTypeVarTuple[*tuple[int, ...]]` is not assignable to `InvariantTypeVarTuple[*tuple[object, ...]]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:20:29: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:20:58: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:20:58: error[invalid-assignment] Object of type `InvariantTypeVarTuple[*tuple[int, ...]]` is not assignable to `InvariantTypeVarTuple[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:21:29: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:21:71: error[not-subscriptable] Cannot subscript non-generic type `<class 'InvariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:21:71: error[invalid-assignment] Object of type `InvariantTypeVarTuple[int]` is not assignable to `InvariantTypeVarTuple[*tuple[int, ...]]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:28:9: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:28:53: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:28:53: error[invalid-assignment] Object of type `ContravariantTypeVarTuple[object, int]` is not assignable to `ContravariantTypeVarTuple[object, object]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:31:21: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:31:70: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:31:70: error[invalid-assignment] Object of type `ContravariantTypeVarTuple[*tuple[int, ...]]` is not assignable to `ContravariantTypeVarTuple[*tuple[object, ...]]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:34:25: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:34:71: error[not-subscriptable] Cannot subscript non-generic type `<class 'ContravariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:34:71: error[invalid-assignment] Object of type `ContravariantTypeVarTuple[int]` is not assignable to `ContravariantTypeVarTuple[*tuple[int, ...]]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:42:10: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:42:39: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:42:39: error[invalid-assignment] Object of type `CovariantTypeVarTuple[object]` is not assignable to `CovariantTypeVarTuple[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:45:16: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:45:50: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:45:50: error[invalid-assignment] Object of type `CovariantTypeVarTuple[bool, object]` is not assignable to `CovariantTypeVarTuple[int, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:46:16: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:46:50: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:46:50: error[invalid-assignment] Object of type `CovariantTypeVarTuple[object, bool]` is not assignable to `CovariantTypeVarTuple[int, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:47:16: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:47:50: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:47:50: error[invalid-assignment] Object of type `CovariantTypeVarTuple[object, object]` is not assignable to `CovariantTypeVarTuple[int, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:48:19: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:48:61: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:48:61: error[invalid-assignment] Object of type `CovariantTypeVarTuple[*tuple[object, ...]]` is not assignable to `CovariantTypeVarTuple[*tuple[int, ...]]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:51:26: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:51:55: error[not-subscriptable] Cannot subscript non-generic type `<class 'CovariantTypeVarTuple'>`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_typevartuple_variance.py:51:55: error[invalid-assignment] Object of type `CovariantTypeVarTuple[*tuple[int, ...]]` is not assignable to `CovariantTypeVarTuple[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:111:38: error[invalid-assignment] Object of type `ShouldBeInvariant2[int]` is not assignable to `ShouldBeInvariant2[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:111:38: error[invalid-assignment] Object of type `ShouldBeInvariant2[int]` is not assignable to `ShouldBeInvariant2[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:112:36: error[invalid-assignment] Object of type `ShouldBeInvariant2[int | float]` is not assignable to `ShouldBeInvariant2[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:112:36: error[invalid-assignment] Object of type `ShouldBeInvariant2[float]` is not assignable to `ShouldBeInvariant2[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:119:43: error[invalid-assignment] Object of type `ShouldBeInvariant3[int, str]` is not assignable to `ShouldBeInvariant3[int | float, str]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:119:43: error[invalid-assignment] Object of type `ShouldBeInvariant3[int, str]` is not assignable to `ShouldBeInvariant3[float, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:120:41: error[invalid-assignment] Object of type `ShouldBeInvariant3[int | float, str]` is not assignable to `ShouldBeInvariant3[int, str]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:120:41: error[invalid-assignment] Object of type `ShouldBeInvariant3[float, str]` is not assignable to `ShouldBeInvariant3[int, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:121:43: error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int]` is not assignable to `ShouldBeInvariant3[str, int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:121:43: error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int]` is not assignable to `ShouldBeInvariant3[str, float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:122:41: error[invalid-assignment] Object of type `ShouldBeInvariant3[str, int | float]` is not assignable to `ShouldBeInvariant3[str, int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:122:41: error[invalid-assignment] Object of type `ShouldBeInvariant3[str, float]` is not assignable to `ShouldBeInvariant3[str, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:130:38: error[invalid-assignment] Object of type `ShouldBeInvariant4[int]` is not assignable to `ShouldBeInvariant4[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:130:38: error[invalid-assignment] Object of type `ShouldBeInvariant4[int]` is not assignable to `ShouldBeInvariant4[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:138:38: error[invalid-assignment] Object of type `ShouldBeInvariant5[int]` is not assignable to `ShouldBeInvariant5[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:138:38: error[invalid-assignment] Object of type `ShouldBeInvariant5[int]` is not assignable to `ShouldBeInvariant5[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:149:45: error[invalid-assignment] Object of type `ShouldBeContravariant1[int]` is not assignable to `ShouldBeContravariant1[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:149:45: error[invalid-assignment] Object of type `ShouldBeContravariant1[int]` is not assignable to `ShouldBeContravariant1[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:169:31: error[invalid-assignment] Object of type `ShouldBeInvariant6[int | float]` is not assignable to `ShouldBeInvariant6[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:169:31: error[invalid-assignment] Object of type `ShouldBeInvariant6[float]` is not assignable to `ShouldBeInvariant6[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:170:33: error[invalid-assignment] Object of type `ShouldBeInvariant6[int]` is not assignable to `ShouldBeInvariant6[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:170:33: error[invalid-assignment] Object of type `ShouldBeInvariant6[int]` is not assignable to `ShouldBeInvariant6[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:181:31: error[invalid-assignment] Object of type `ShouldBeCovariant6[int | float]` is not assignable to `ShouldBeCovariant6[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:181:31: error[invalid-assignment] Object of type `ShouldBeCovariant6[float]` is not assignable to `ShouldBeCovariant6[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:194:37: error[invalid-assignment] Object of type `ShouldBeContravariant2[int]` is not assignable to `ShouldBeContravariant2[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:194:37: error[invalid-assignment] Object of type `ShouldBeContravariant2[int]` is not assignable to `ShouldBeContravariant2[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:24:33: error[invalid-assignment] Object of type `ClassA[int | float, int, int]` is not assignable to `ClassA[int, int, int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:24:33: error[invalid-assignment] Object of type `ClassA[float, int, int]` is not assignable to `ClassA[int, int, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:25:37: error[invalid-assignment] Object of type `ClassA[int | float, int, int]` is not assignable to `ClassA[int | float, int | float, int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:25:37: error[invalid-assignment] Object of type `ClassA[float, int, int]` is not assignable to `ClassA[float, float, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:28:33: error[invalid-assignment] Object of type `ClassA[int, int | float, int | float]` is not assignable to `ClassA[int, int, int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:28:33: error[invalid-assignment] Object of type `ClassA[int, float, float]` is not assignable to `ClassA[int, int, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:41:35: error[invalid-assignment] Object of type `ShouldBeCovariant1[int | float]` is not assignable to `ShouldBeCovariant1[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:41:35: error[invalid-assignment] Object of type `ShouldBeCovariant1[float]` is not assignable to `ShouldBeCovariant1[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:49:35: error[invalid-assignment] Object of type `ShouldBeCovariant2[int | float]` is not assignable to `ShouldBeCovariant2[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:49:35: error[invalid-assignment] Object of type `ShouldBeCovariant2[float]` is not assignable to `ShouldBeCovariant2[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:58:35: error[invalid-assignment] Object of type `ShouldBeCovariant3[int | float]` is not assignable to `ShouldBeCovariant3[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:58:35: error[invalid-assignment] Object of type `ShouldBeCovariant3[float]` is not assignable to `ShouldBeCovariant3[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:67:34: error[invalid-assignment] Object of type `ShouldBeCovariant4[int | float]` is not assignable to `ShouldBeCovariant4[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:67:34: error[invalid-assignment] Object of type `ShouldBeCovariant4[float]` is not assignable to `ShouldBeCovariant4[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:80:34: error[invalid-assignment] Object of type `ShouldBeCovariant5[int | float]` is not assignable to `ShouldBeCovariant5[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:80:34: error[invalid-assignment] Object of type `ShouldBeCovariant5[float]` is not assignable to `ShouldBeCovariant5[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:96:38: error[invalid-assignment] Object of type `ShouldBeInvariant1[int]` is not assignable to `ShouldBeInvariant1[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:96:38: error[invalid-assignment] Object of type `ShouldBeInvariant1[int]` is not assignable to `ShouldBeInvariant1[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:97:36: error[invalid-assignment] Object of type `ShouldBeInvariant1[int | float]` is not assignable to `ShouldBeInvariant1[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_variance_inference.py:97:36: error[invalid-assignment] Object of type `ShouldBeInvariant1[float]` is not assignable to `ShouldBeInvariant1[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/literals_literalstring.py:133:41: error[invalid-assignment] Object of type `Container[T@Container]` is not assignable to `Container[LiteralString]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/literals_literalstring.py:133:51: error[invalid-argument-type] Argument to `Container.__init__` is incorrect: Argument type `str` does not satisfy upper bound `LiteralString` of type variable `T`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/literals_literalstring.py:133:51: error[invalid-argument-type] Argument to `Container.__init__` is incorrect: Expected `LiteralString`, found `str`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/literals_literalstring.py:133:51: error[invalid-argument-type] Argument to `Container.__init__` is incorrect: Argument type `str` does not satisfy upper bound `LiteralString` of type variable `T`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/namedtuples_define_class.py:140:19: error[invalid-argument-type] Argument is incorrect: Expected `str`, found `float`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/namedtuples_define_class.py:140:19: error[invalid-argument-type] Argument is incorrect: Expected `str`, found `float*`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/namedtuples_define_functional.py:43:15: error[invalid-argument-type] Argument is incorrect: Expected `int`, found `float`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/namedtuples_define_functional.py:43:15: error[invalid-argument-type] Argument is incorrect: Expected `int`, found `float*`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_generic.py:56:20: error[invalid-assignment] Object of type `Box[int | float]` is not assignable to `Box[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_generic.py:56:20: error[invalid-assignment] Object of type `Box[float]` is not assignable to `Box[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_generic.py:66:25: error[invalid-assignment] Object of type `Sender[int]` is not assignable to `Sender[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_generic.py:66:25: error[invalid-assignment] Object of type `Sender[int]` is not assignable to `Sender[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_generic.py:74:28: error[invalid-assignment] Object of type `AttrProto[int]` is not assignable to `AttrProto[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_generic.py:74:28: error[invalid-assignment] Object of type `AttrProto[int]` is not assignable to `AttrProto[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_generic.py:75:26: error[invalid-assignment] Object of type `AttrProto[int | float]` is not assignable to `AttrProto[int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_generic.py:75:26: error[invalid-assignment] Object of type `AttrProto[float]` is not assignable to `AttrProto[int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_subtyping.py:102:30: error[invalid-assignment] Object of type `Proto6[int | float, int | float]` is not assignable to `Proto7[int, int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_subtyping.py:102:30: error[invalid-assignment] Object of type `Proto6[float, float]` is not assignable to `Proto7[int, float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_subtyping.py:103:33: error[invalid-assignment] Object of type `Proto6[int | float, int | float]` is not assignable to `Proto7[int | float, object]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_subtyping.py:103:33: error[invalid-assignment] Object of type `Proto6[float, float]` is not assignable to `Proto7[float, object]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_subtyping.py:79:30: error[invalid-assignment] Object of type `Proto5[int]` is not assignable to `Proto4[int, int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_subtyping.py:79:30: error[invalid-assignment] Object of type `Proto5[int]` is not assignable to `Proto4[int, float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_subtyping.py:80:25: error[invalid-assignment] Object of type `Proto4[int, int]` is not assignable to `Proto5[int | float]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_subtyping.py:80:25: error[invalid-assignment] Object of type `Proto4[int, int]` is not assignable to `Proto5[float]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/specialtypes_promotions.py:13:5: error[unresolved-attribute] Attribute `numerator` is not defined on `float` in union `int | float`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/specialtypes_promotions.py:13:5: error[unresolved-attribute] Attribute `numerator` is not defined on `float*` in union `float`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_compat.py:15:27: error[invalid-assignment] Object of type `tuple[int | float, int | float | complex]` is not assignable to `tuple[int, int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_compat.py:15:27: error[invalid-assignment] Object of type `tuple[float, complex]` is not assignable to `tuple[int, int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_compat.py:170:6: error[invalid-assignment] Object of type `tuple[Literal[1], Literal[""], Literal[""], float]` is not assignable to `tuple[int, *tuple[str, ...], int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_compat.py:170:6: error[invalid-assignment] Object of type `tuple[Literal[1], Literal[""], Literal[""], float*]` is not assignable to `tuple[int, *tuple[str, ...], int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_compat.py:176:6: error[invalid-assignment] Object of type `tuple[Literal[""], Literal[""], float]` is not assignable to `tuple[*tuple[str, ...], int]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_compat.py:176:6: error[invalid-assignment] Object of type `tuple[Literal[""], Literal[""], float*]` is not assignable to `tuple[*tuple[str, ...], int]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:40:6: error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:40:22: error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:41:6: error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:41:12: error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:42:6: error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:42:12: error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:43:6: error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:43:17: error[invalid-type-form] Invalid `tuple` specialization: `...` can only be used as the second element in a two-element `tuple` specialization
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:44:6: error[invalid-type-form] Invalid `tuple` specialization: `...` cannot be used after an unpacked element
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:44:25: error[invalid-type-form] Invalid `tuple` specialization: `...` cannot be used after an unpacked element
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:45:6: error[invalid-type-form] Invalid `tuple` specialization: `...` cannot be used after an unpacked element
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/tuples_type_form.py:45:30: error[invalid-type-form] Invalid `tuple` specialization: `...` cannot be used after an unpacked element
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/typeddicts_operations.py:29:42: error[invalid-argument-type] Invalid argument to key "year" with declared type `int` on TypedDict `Movie`: value of type `float`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/typeddicts_operations.py:29:42: error[invalid-argument-type] Invalid argument to key "year" with declared type `int` on TypedDict `Movie`: value of type `float*`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/typeddicts_readonly_inheritance.py:119:7: error[invalid-typed-dict-field] Cannot overwrite TypedDict field `x` while merging base classes: Inherited mutable field type `int | float` is incompatible with `int`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/typeddicts_readonly_inheritance.py:119:7: error[invalid-typed-dict-field] Cannot overwrite TypedDict field `x` while merging base classes: Inherited mutable field type `float` is incompatible with `int`
```
</details>

### False positives changed (2)

<details>
<summary>2 diagnostics</summary>

```diff
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:204:5: error[type-assertion-failure] Type `@Todo` does not match asserted type `tuple[int, str]`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:204:5: error[type-assertion-failure] Type `tuple[int]` does not match asserted type `tuple[int, str]`
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:205:5: error[type-assertion-failure] Type `@Todo` does not match asserted type `(int | float, bool, /) -> None`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:205:5: error[type-assertion-failure] Type `(...) -> None` does not match asserted type `(float, bool, /) -> None`
```
</details>

### False positives added (2)

<details>
<summary>2 diagnostics</summary>

```diff
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:144:61: error[invalid-type-form] `Unpack` can only unpack a tuple type or `TypeVarTuple`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults.py:203:28: error[invalid-type-arguments] Type argument for `ParamSpec` must be either a list of types, `ParamSpec`, `Concatenate`, or `...`
```
</details>

### Optional Diagnostics Added (3)

<details>
<summary>3 diagnostics</summary>

```diff
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/aliases_typealiastype.py:49:40: error[cyclic-type-alias-definition] Type alias `BadAlias7` has a circular definition
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_class_objects.py:108:16: error[invalid-assignment] Object of type `<class 'ConcreteC3'>` is not assignable to `ProtoC1`
+ /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/protocols_definition.py:117:22: error[invalid-assignment] Object of type `Concrete2_Bad4` is not assignable to `Template2`
```
</details>

### Optional Diagnostics Removed (1)

<details>
<summary>1 diagnostic</summary>

```diff
- /home/dev-user/code/oss/typing-imre-diagnostic-20261023/conformance/tests/generics_defaults_specialization.py:48:22: error[invalid-assignment] Object of type `<class 'Bar'>` is not assignable to `type[Bar[int]]`
```
</details>
