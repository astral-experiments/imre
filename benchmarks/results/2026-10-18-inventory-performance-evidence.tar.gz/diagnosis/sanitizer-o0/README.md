# O0 AddressSanitizer parameter initialization diagnosis

The failing minimal dictionary program executes no concatenation. Both frozen dev2 and dev3 compiler/runtime combinations fail at O0 with `TypeError: unexpected null runtime handle`. The earlier dev2 ASan matrix used O1 and therefore did not cover this path.

Clang 18 ASan instrumentation moves `store ptr %arg0, ptr %local0` ahead of the earlier default initialization. The instrumented IR records the argument store at line 259 and the null store at line 305; the latter clobbers the parameter. Deleting only the default null store from the generated input IR fixes the same binary configuration. The successful run occurred outside ptrace with ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 and LSAN_OPTIONS=exitcode=23; it exited 0 with exactly the retained stdout and empty stderr.

From the repository root, the successful focused link command was:

```sh
clang-18 -O0 -Wno-override-module /tmp/relar-candidate3-runtime-debug/dict-min-single-init.ll benchmarks/local/inventory-performance-tools-dev3/librelar_runtime_asan.a -ldl -lpthread -lm -lrt -lutil -o /tmp/relar-candidate3-runtime-debug/dict-min-single-init -fsanitize=address -fno-omit-frame-pointer
```

The LLVM agent's production correction skips default initialization only for parameter locals; their existing argument stores remain the sole initialization. Nonparameter cleanup slots still receive their defaults. Parameter retains are infallible, and every parameter is initialized before fallible body work or recoverable cleanup. No runtime change was needed. The retained source IR can be linked again with the frozen dev3 archive; binaries are represented by their hashes rather than copied here.
