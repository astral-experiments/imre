def first_row(values: dict[str, list[int]]) -> list[int]:
    for key, row in values.items():
        del values[key]
        print(key)
        return row
    return []


def main() -> None:
    huge = 100000000000000000000000000000000000000000000000007
    retained = first_row({"an owned key removed before return": [huge]})
    print(retained[0])

main()
