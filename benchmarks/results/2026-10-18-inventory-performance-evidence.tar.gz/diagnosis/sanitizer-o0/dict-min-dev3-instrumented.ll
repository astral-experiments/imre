; ModuleID = '/tmp/relar-candidate3-runtime-debug/dict-min-dev3.ll'
source_filename = "/tmp/relar-candidate3-runtime-debug/dict-min-dev3.ll"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

$asan.module_ctor = comdat any

$asan.module_dtor = comdat any

$kinds_tuple_1.21576b91ab9b15712202e1b4a494877f = comdat any

$layout_tuple_1.21576b91ab9b15712202e1b4a494877f = comdat any

$str_0.21576b91ab9b15712202e1b4a494877f = comdat any

$str_1.21576b91ab9b15712202e1b4a494877f = comdat any

@kinds_tuple_1 = internal constant { [2 x i32], [24 x i8] } { [2 x i32] [i32 3, i32 4], [24 x i8] zeroinitializer }, comdat($kinds_tuple_1.21576b91ab9b15712202e1b4a494877f), align 32
@layout_tuple_1 = internal constant { { i64, ptr }, [16 x i8] } { { i64, ptr } { i64 2, ptr @kinds_tuple_1 }, [16 x i8] zeroinitializer }, comdat($layout_tuple_1.21576b91ab9b15712202e1b4a494877f), align 32
@str_0 = internal constant { [51 x i8], [45 x i8] } { [51 x i8] c"100000000000000000000000000000000000000000000000007", [45 x i8] zeroinitializer }, comdat($str_0.21576b91ab9b15712202e1b4a494877f), align 32
@str_1 = internal constant { [34 x i8], [62 x i8] } { [34 x i8] c"an owned key removed before return", [62 x i8] zeroinitializer }, comdat($str_1.21576b91ab9b15712202e1b4a494877f), align 32
@__asan_option_detect_stack_use_after_return = external global i32
@___asan_gen_ = private unnamed_addr constant [54 x i8] c"2 32 8 16 mapping_key_word 64 8 18 mapping_value_word\00", align 1
@___asan_gen_.1 = private constant [52 x i8] c"/tmp/relar-candidate3-runtime-debug/dict-min-dev3.ll\00", align 1
@___asan_gen_.2 = private unnamed_addr constant [14 x i8] c"kinds_tuple_1\00", align 1
@___asan_gen_.3 = private unnamed_addr constant [15 x i8] c"layout_tuple_1\00", align 1
@___asan_gen_.4 = private unnamed_addr constant [6 x i8] c"str_0\00", align 1
@___asan_gen_.5 = private unnamed_addr constant [6 x i8] c"str_1\00", align 1
@__asan_global_kinds_tuple_1 = private global { i64, i64, i64, i64, i64, i64, i64, i64 } { i64 ptrtoint (ptr @0 to i64), i64 8, i64 32, i64 ptrtoint (ptr @___asan_gen_.2 to i64), i64 ptrtoint (ptr @___asan_gen_.1 to i64), i64 0, i64 0, i64 -1 }, section "asan_globals", comdat($kinds_tuple_1.21576b91ab9b15712202e1b4a494877f), !associated !0
@__asan_global_layout_tuple_1 = private global { i64, i64, i64, i64, i64, i64, i64, i64 } { i64 ptrtoint (ptr @1 to i64), i64 16, i64 32, i64 ptrtoint (ptr @___asan_gen_.3 to i64), i64 ptrtoint (ptr @___asan_gen_.1 to i64), i64 0, i64 0, i64 -1 }, section "asan_globals", comdat($layout_tuple_1.21576b91ab9b15712202e1b4a494877f), !associated !1
@__asan_global_str_0 = private global { i64, i64, i64, i64, i64, i64, i64, i64 } { i64 ptrtoint (ptr @2 to i64), i64 51, i64 96, i64 ptrtoint (ptr @___asan_gen_.4 to i64), i64 ptrtoint (ptr @___asan_gen_.1 to i64), i64 0, i64 0, i64 -1 }, section "asan_globals", comdat($str_0.21576b91ab9b15712202e1b4a494877f), !associated !2
@__asan_global_str_1 = private global { i64, i64, i64, i64, i64, i64, i64, i64 } { i64 ptrtoint (ptr @3 to i64), i64 34, i64 96, i64 ptrtoint (ptr @___asan_gen_.5 to i64), i64 ptrtoint (ptr @___asan_gen_.1 to i64), i64 0, i64 0, i64 -1 }, section "asan_globals", comdat($str_1.21576b91ab9b15712202e1b4a494877f), !associated !3
@llvm.compiler.used = appending global [8 x ptr] [ptr @kinds_tuple_1, ptr @layout_tuple_1, ptr @str_0, ptr @str_1, ptr @__asan_global_kinds_tuple_1, ptr @__asan_global_layout_tuple_1, ptr @__asan_global_str_0, ptr @__asan_global_str_1], section "llvm.metadata"
@___asan_globals_registered = common hidden global i64 0
@__start_asan_globals = extern_weak hidden global i64
@__stop_asan_globals = extern_weak hidden global i64
@llvm.used = appending global [2 x ptr] [ptr @asan.module_ctor, ptr @asan.module_dtor], section "llvm.metadata"
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_ctor, ptr @asan.module_ctor }]
@llvm.global_dtors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 1, ptr @asan.module_dtor, ptr @asan.module_dtor }]

@0 = private alias { [2 x i32], [24 x i8] }, ptr @kinds_tuple_1
@1 = private alias { { i64, ptr }, [16 x i8] }, ptr @layout_tuple_1
@2 = private alias { [51 x i8], [45 x i8] }, ptr @str_0
@3 = private alias { [34 x i8], [62 x i8] }, ptr @str_1

declare i8 @relar_error_pending()

declare ptr @relar_error_take()

declare void @relar_error_set(ptr)

declare i32 @relar_error_unhandled()

declare ptr @relar_exception_new(i32, ptr)

declare i8 @relar_exception_matches(ptr, i32)

declare ptr @relar_exception_message(ptr)

declare ptr @relar_exception_current()

declare ptr @relar_exception_swap_active(ptr)

declare void @relar_exception_raise(ptr)

declare void @relar_exception_reraise()

declare void @relar_flush_stdout()

declare ptr @relar_record_new(ptr)

declare void @relar_record_retain(ptr)

declare void @relar_record_release(ptr)

declare void @relar_object_retain(ptr)

declare void @relar_object_release(ptr)

declare ptr @relar_seq_new(i32)

declare i64 @relar_seq_get(ptr, i64)

declare void @relar_seq_set(ptr, i64, i64, i32)

declare i64 @relar_seq_get_index(ptr, i64)

declare void @relar_seq_set_index(ptr, i64, i64, i32)

declare void @relar_seq_append(ptr, i64, i32)

declare i64 @relar_seq_pop(ptr)

declare i64 @relar_seq_len(ptr)

declare ptr @relar_seq_repeat(ptr, i64)

declare ptr @relar_dict_new(i32, i32)

declare i64 @relar_dict_len(ptr)

declare i8 @relar_dict_contains(ptr, i64)

declare i64 @relar_dict_get(ptr, i64)

declare i8 @relar_dict_try_get(ptr, i64, ptr)

declare i64 @relar_dict_get_default(ptr, i64, i64)

declare void @relar_dict_set(ptr, i64, i64)

declare void @relar_dict_delete(ptr, i64)

declare ptr @relar_dict_iter(ptr, i32)

declare ptr @relar_set_new(i32)

declare i64 @relar_set_len(ptr)

declare i8 @relar_set_contains(ptr, i64)

declare void @relar_set_add(ptr, i64)

declare void @relar_set_discard(ptr, i64)

declare ptr @relar_set_iter(ptr)

declare i8 @relar_mapping_iter_next(ptr, ptr, ptr)

declare ptr @relar_str_concat(ptr, ptr)

declare ptr @relar_str_concat_parts(ptr, i64)

declare ptr @relar_int_str_part(i64, ptr, ptr)

declare ptr @relar_str_split_whitespace(ptr)

declare ptr @relar_str_splitlines(ptr)

declare ptr @relar_int_str(i64)

declare ptr @relar_bool_str(i8)

declare ptr @relar_none_str()

declare ptr @relar_text_open(ptr, i32)

declare i8 @relar_text_enter(ptr)

declare ptr @relar_text_read(ptr)

declare i64 @relar_text_write(ptr, ptr)

declare i8 @relar_text_write_discard(ptr, ptr)

declare i8 @relar_text_write_parts(ptr, ptr, i64)

declare i8 @relar_text_flush(ptr)

declare i8 @relar_text_close(ptr)

declare i8 @relar_text_closed(ptr)

declare void @relar_args_init(i32, ptr)

declare ptr @relar_sys_argv()

declare void @relar_args_clear()

declare void @relar_int_retain(i64)

declare void @relar_int_release(i64)

declare i64 @relar_int_literal(ptr, i64)

declare i64 @relar_int_binary(i64, i64, i32)

declare i32 @relar_int_compare(i64, i64)

declare void @relar_print_int(i64)

declare void @relar_print_bool(i8)

declare void @relar_print_none()

declare ptr @relar_str_literal(ptr, i64)

declare void @relar_str_retain(ptr)

declare void @relar_str_release(ptr)

declare void @relar_print_str(ptr)

declare i64 @relar_str_len(ptr)

declare i8 @relar_str_equal(ptr, ptr)

declare i64 @relar_int_parse(ptr)

declare ptr @relar_input()

declare ptr @relar_list_new()

declare void @relar_list_retain(ptr)

declare void @relar_list_release(ptr)

declare i64 @relar_list_get(ptr, i64)

declare i8 @relar_list_set(ptr, i64, i64)

declare i64 @relar_list_get_index(ptr, i64)

declare i8 @relar_list_set_index(ptr, i64, i64)

declare i64 @relar_list_borrow_index(ptr, i64)

declare i8 @relar_list_copy_index(ptr, i64, i64)

declare void @relar_list_append(ptr, i64)

declare i64 @relar_list_pop(ptr)

declare i64 @relar_list_len(ptr)

declare ptr @relar_list_repeat(ptr, i64)

declare void @relar_assert_fail()

declare void @relar_range_step_zero()

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64) #0

; Function Attrs: sanitize_address
define internal ptr @fn_0(ptr %arg0) #1 {
entry:
  %function_return = alloca ptr, align 8
  store ptr null, ptr %function_return, align 8
  %local0 = alloca ptr, align 8
  %local1 = alloca ptr, align 8
  %local2 = alloca ptr, align 8
  %local3 = alloca ptr, align 8
  %local4 = alloca ptr, align 8
  %local5 = alloca i1, align 1
  %local6 = alloca i8, align 1
  %local7 = alloca ptr, align 8
  %local8 = alloca ptr, align 8
  %local9 = alloca ptr, align 8
  %local10 = alloca ptr, align 8
  %local11 = alloca ptr, align 8
  %local12 = alloca ptr, align 8
  store ptr %arg0, ptr %local0, align 8
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  %1 = icmp ne i32 %0, 0
  br i1 %1, label %2, label %4

2:                                                ; preds = %entry
  %3 = call i64 @__asan_stack_malloc_1(i64 96)
  br label %4

4:                                                ; preds = %entry, %2
  %5 = phi i64 [ 0, %entry ], [ %3, %2 ]
  %6 = icmp eq i64 %5, 0
  br i1 %6, label %7, label %9

7:                                                ; preds = %4
  %MyAlloca = alloca i8, i64 96, align 32
  %8 = ptrtoint ptr %MyAlloca to i64
  br label %9

9:                                                ; preds = %4, %7
  %10 = phi i64 [ %5, %4 ], [ %8, %7 ]
  store i64 %10, ptr %asan_local_stack_base, align 8
  %11 = add i64 %10, 32
  %12 = inttoptr i64 %11 to ptr
  %13 = add i64 %10, 64
  %14 = inttoptr i64 %13 to ptr
  %15 = inttoptr i64 %10 to ptr
  store i64 1102416563, ptr %15, align 8
  %16 = add i64 %10, 8
  %17 = inttoptr i64 %16 to ptr
  store i64 ptrtoint (ptr @___asan_gen_ to i64), ptr %17, align 8
  %18 = add i64 %10, 16
  %19 = inttoptr i64 %18 to ptr
  store i64 ptrtoint (ptr @fn_0 to i64), ptr %19, align 8
  %20 = lshr i64 %10, 3
  %21 = add i64 %20, 2147450880
  %22 = add i64 %21, 0
  %23 = inttoptr i64 %22 to ptr
  store i64 -940423286293925391, ptr %23, align 1
  %24 = add i64 %21, 9
  %25 = inttoptr i64 %24 to ptr
  store i16 -3085, ptr %25, align 1
  %26 = add i64 %21, 11
  %27 = inttoptr i64 %26 to ptr
  store i8 -13, ptr %27, align 1
  store ptr null, ptr %local0, align 8
  store ptr null, ptr %local1, align 8
  store ptr null, ptr %local2, align 8
  store ptr null, ptr %local3, align 8
  store ptr null, ptr %local4, align 8
  store i1 false, ptr %local5, align 1
  store i8 0, ptr %local6, align 1
  store ptr null, ptr %local7, align 8
  store ptr null, ptr %local8, align 8
  store ptr null, ptr %local9, align 8
  store ptr null, ptr %local10, align 8
  store ptr null, ptr %local11, align 8
  store ptr null, ptr %local12, align 8
  %v0 = load ptr, ptr %local0, align 8
  call void @relar_object_retain(ptr %v0)
  %v1 = load ptr, ptr %local1, align 8
  store ptr %v0, ptr %local1, align 8
  call void @relar_object_release(ptr %v1)
  %v2 = load ptr, ptr %local1, align 8
  %v3 = call ptr @relar_dict_iter(ptr %v2, i32 1)
  %v4 = load ptr, ptr %local2, align 8
  store ptr %v3, ptr %local2, align 8
  call void @relar_object_release(ptr %v4)
  br label %b2

b2:                                               ; preds = %9
  br i1 true, label %b3, label %b4

b3:                                               ; preds = %b2
  %v5 = load ptr, ptr %local2, align 8
  %v6 = call i8 @relar_mapping_iter_next(ptr %v5, ptr %12, ptr %14)
  %v7 = call i8 @relar_error_pending()
  %v8 = icmp ne i8 %v7, 0
  br i1 %v8, label %b5, label %b6, !prof !4

b5:                                               ; preds = %b3
  %v9 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_object_release(ptr %v9)
  %v10 = load ptr, ptr %local2, align 8
  store ptr null, ptr %local2, align 8
  call void @relar_object_release(ptr %v10)
  %v11 = load ptr, ptr %local3, align 8
  store ptr null, ptr %local3, align 8
  call void @relar_str_release(ptr %v11)
  %v12 = load ptr, ptr %local4, align 8
  store ptr null, ptr %local4, align 8
  call void @relar_list_release(ptr %v12)
  br label %b1

b6:                                               ; preds = %b3
  %v13 = icmp ne i8 %v6, 0
  %v14 = load i1, ptr %local5, align 1
  store i1 %v13, ptr %local5, align 1
  br i1 %v13, label %b7, label %b8

b7:                                               ; preds = %b6
  %v15 = load i64, ptr %12, align 4
  %v16 = inttoptr i64 %v15 to ptr
  %v17 = load ptr, ptr %local3, align 8
  store ptr %v16, ptr %local3, align 8
  call void @relar_str_release(ptr %v17)
  %v18 = load i64, ptr %14, align 4
  %v19 = inttoptr i64 %v18 to ptr
  %v20 = load ptr, ptr %local4, align 8
  store ptr %v19, ptr %local4, align 8
  call void @relar_list_release(ptr %v20)
  br label %b8

b8:                                               ; preds = %b7, %b6
  %v21 = load i1, ptr %local5, align 1
  %v22 = xor i1 %v21, true
  br i1 %v22, label %b9, label %b10

b9:                                               ; preds = %b8
  br label %b4

b10:                                              ; preds = %b8
  br label %b11

b11:                                              ; preds = %b10
  %v23 = load ptr, ptr %local3, align 8
  call void @relar_str_retain(ptr %v23)
  %v24 = load ptr, ptr %local11, align 8
  store ptr %v23, ptr %local11, align 8
  call void @relar_str_release(ptr %v24)
  %v25 = load ptr, ptr %local4, align 8
  call void @relar_list_retain(ptr %v25)
  %v26 = load ptr, ptr %local12, align 8
  store ptr %v25, ptr %local12, align 8
  call void @relar_list_release(ptr %v26)
  %v27 = load ptr, ptr %local11, align 8
  store ptr null, ptr %local11, align 8
  %v28 = load ptr, ptr %local9, align 8
  store ptr %v27, ptr %local9, align 8
  call void @relar_str_release(ptr %v28)
  %v29 = load ptr, ptr %local12, align 8
  store ptr null, ptr %local12, align 8
  %v30 = load ptr, ptr %local10, align 8
  store ptr %v29, ptr %local10, align 8
  call void @relar_list_release(ptr %v30)
  %v31 = load ptr, ptr %local11, align 8
  store ptr null, ptr %local11, align 8
  call void @relar_str_release(ptr %v31)
  %v32 = load ptr, ptr %local12, align 8
  store ptr null, ptr %local12, align 8
  call void @relar_list_release(ptr %v32)
  %v33 = load ptr, ptr %local9, align 8
  call void @relar_str_retain(ptr %v33)
  %v34 = load ptr, ptr %local7, align 8
  store ptr %v33, ptr %local7, align 8
  call void @relar_str_release(ptr %v34)
  %v35 = load ptr, ptr %local10, align 8
  call void @relar_list_retain(ptr %v35)
  %v36 = load ptr, ptr %local8, align 8
  store ptr %v35, ptr %local8, align 8
  call void @relar_list_release(ptr %v36)
  %v37 = load ptr, ptr %local9, align 8
  store ptr null, ptr %local9, align 8
  call void @relar_str_release(ptr %v37)
  %v38 = load ptr, ptr %local10, align 8
  store ptr null, ptr %local10, align 8
  call void @relar_list_release(ptr %v38)
  %v39 = load ptr, ptr %local3, align 8
  store ptr null, ptr %local3, align 8
  call void @relar_str_release(ptr %v39)
  %v40 = load ptr, ptr %local4, align 8
  store ptr null, ptr %local4, align 8
  call void @relar_list_release(ptr %v40)
  %v41 = load ptr, ptr %local0, align 8
  %v42 = load ptr, ptr %local7, align 8
  %v43 = ptrtoint ptr %v42 to i64
  call void @relar_dict_delete(ptr %v41, i64 %v43)
  %v44 = call i8 @relar_error_pending()
  %v45 = icmp ne i8 %v44, 0
  br i1 %v45, label %b12, label %b13, !prof !4

b12:                                              ; preds = %b11
  %v46 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_object_release(ptr %v46)
  %v47 = load ptr, ptr %local2, align 8
  store ptr null, ptr %local2, align 8
  call void @relar_object_release(ptr %v47)
  %v48 = load ptr, ptr %local3, align 8
  store ptr null, ptr %local3, align 8
  call void @relar_str_release(ptr %v48)
  %v49 = load ptr, ptr %local4, align 8
  store ptr null, ptr %local4, align 8
  call void @relar_list_release(ptr %v49)
  br label %b1

b13:                                              ; preds = %b11
  %v50 = load ptr, ptr %local7, align 8
  call void @relar_print_str(ptr %v50)
  %v51 = call i8 @relar_error_pending()
  %v52 = icmp ne i8 %v51, 0
  br i1 %v52, label %b14, label %b15, !prof !4

b14:                                              ; preds = %b13
  %v53 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_object_release(ptr %v53)
  %v54 = load ptr, ptr %local2, align 8
  store ptr null, ptr %local2, align 8
  call void @relar_object_release(ptr %v54)
  %v55 = load ptr, ptr %local3, align 8
  store ptr null, ptr %local3, align 8
  call void @relar_str_release(ptr %v55)
  %v56 = load ptr, ptr %local4, align 8
  store ptr null, ptr %local4, align 8
  call void @relar_list_release(ptr %v56)
  br label %b1

b15:                                              ; preds = %b13
  %v57 = load ptr, ptr %local8, align 8
  call void @relar_list_retain(ptr %v57)
  %v58 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_object_release(ptr %v58)
  %v59 = load ptr, ptr %local2, align 8
  store ptr null, ptr %local2, align 8
  call void @relar_object_release(ptr %v59)
  %v60 = load ptr, ptr %local3, align 8
  store ptr null, ptr %local3, align 8
  call void @relar_str_release(ptr %v60)
  %v61 = load ptr, ptr %local4, align 8
  store ptr null, ptr %local4, align 8
  call void @relar_list_release(ptr %v61)
  store ptr %v57, ptr %function_return, align 8
  br label %b0

b4:                                               ; preds = %b9, %b2
  %v62 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_object_release(ptr %v62)
  %v63 = load ptr, ptr %local2, align 8
  store ptr null, ptr %local2, align 8
  call void @relar_object_release(ptr %v63)
  %v64 = load ptr, ptr %local3, align 8
  store ptr null, ptr %local3, align 8
  call void @relar_str_release(ptr %v64)
  %v65 = load ptr, ptr %local4, align 8
  store ptr null, ptr %local4, align 8
  call void @relar_list_release(ptr %v65)
  %v66 = call ptr @relar_list_new()
  store ptr %v66, ptr %function_return, align 8
  br label %b0

b0:                                               ; preds = %b4, %b15
  %v67 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_object_release(ptr %v67)
  %v68 = load ptr, ptr %local2, align 8
  store ptr null, ptr %local2, align 8
  call void @relar_object_release(ptr %v68)
  %v69 = load ptr, ptr %local3, align 8
  store ptr null, ptr %local3, align 8
  call void @relar_str_release(ptr %v69)
  %v70 = load ptr, ptr %local4, align 8
  store ptr null, ptr %local4, align 8
  call void @relar_list_release(ptr %v70)
  %v71 = load i1, ptr %local5, align 1
  store i1 false, ptr %local5, align 1
  %v72 = load i8, ptr %local6, align 1
  store i8 0, ptr %local6, align 1
  %v73 = load ptr, ptr %local7, align 8
  store ptr null, ptr %local7, align 8
  call void @relar_str_release(ptr %v73)
  %v74 = load ptr, ptr %local8, align 8
  store ptr null, ptr %local8, align 8
  call void @relar_list_release(ptr %v74)
  %v75 = load ptr, ptr %local9, align 8
  store ptr null, ptr %local9, align 8
  call void @relar_str_release(ptr %v75)
  %v76 = load ptr, ptr %local10, align 8
  store ptr null, ptr %local10, align 8
  call void @relar_list_release(ptr %v76)
  %v77 = load ptr, ptr %local11, align 8
  store ptr null, ptr %local11, align 8
  call void @relar_str_release(ptr %v77)
  %v78 = load ptr, ptr %local12, align 8
  store ptr null, ptr %local12, align 8
  call void @relar_list_release(ptr %v78)
  %v79 = load ptr, ptr %function_return, align 8
  store i64 1172321806, ptr %15, align 8
  %28 = icmp ne i64 %5, 0
  br i1 %28, label %29, label %38

29:                                               ; preds = %b0
  %30 = add i64 %21, 0
  %31 = inttoptr i64 %30 to ptr
  store i64 -723401728380766731, ptr %31, align 1
  %32 = add i64 %21, 8
  %33 = inttoptr i64 %32 to ptr
  store i64 -723401728380766731, ptr %33, align 1
  %34 = add i64 %5, 120
  %35 = inttoptr i64 %34 to ptr
  %36 = load i64, ptr %35, align 8
  %37 = inttoptr i64 %36 to ptr
  store i8 0, ptr %37, align 1
  br label %45

38:                                               ; preds = %b0
  %39 = add i64 %21, 0
  %40 = inttoptr i64 %39 to ptr
  store i64 0, ptr %40, align 1
  %41 = add i64 %21, 9
  %42 = inttoptr i64 %41 to ptr
  store i16 0, ptr %42, align 1
  %43 = add i64 %21, 11
  %44 = inttoptr i64 %43 to ptr
  store i8 0, ptr %44, align 1
  br label %45

45:                                               ; preds = %38, %29
  ret ptr %v79

b1:                                               ; preds = %b14, %b12, %b5
  %v80 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_object_release(ptr %v80)
  %v81 = load ptr, ptr %local2, align 8
  store ptr null, ptr %local2, align 8
  call void @relar_object_release(ptr %v81)
  %v82 = load ptr, ptr %local3, align 8
  store ptr null, ptr %local3, align 8
  call void @relar_str_release(ptr %v82)
  %v83 = load ptr, ptr %local4, align 8
  store ptr null, ptr %local4, align 8
  call void @relar_list_release(ptr %v83)
  %v84 = load i1, ptr %local5, align 1
  store i1 false, ptr %local5, align 1
  %v85 = load i8, ptr %local6, align 1
  store i8 0, ptr %local6, align 1
  %v86 = load ptr, ptr %local7, align 8
  store ptr null, ptr %local7, align 8
  call void @relar_str_release(ptr %v86)
  %v87 = load ptr, ptr %local8, align 8
  store ptr null, ptr %local8, align 8
  call void @relar_list_release(ptr %v87)
  %v88 = load ptr, ptr %local9, align 8
  store ptr null, ptr %local9, align 8
  call void @relar_str_release(ptr %v88)
  %v89 = load ptr, ptr %local10, align 8
  store ptr null, ptr %local10, align 8
  call void @relar_list_release(ptr %v89)
  %v90 = load ptr, ptr %local11, align 8
  store ptr null, ptr %local11, align 8
  call void @relar_str_release(ptr %v90)
  %v91 = load ptr, ptr %local12, align 8
  store ptr null, ptr %local12, align 8
  call void @relar_list_release(ptr %v91)
  store i64 1172321806, ptr %15, align 8
  %46 = icmp ne i64 %5, 0
  br i1 %46, label %47, label %56

47:                                               ; preds = %b1
  %48 = add i64 %21, 0
  %49 = inttoptr i64 %48 to ptr
  store i64 -723401728380766731, ptr %49, align 1
  %50 = add i64 %21, 8
  %51 = inttoptr i64 %50 to ptr
  store i64 -723401728380766731, ptr %51, align 1
  %52 = add i64 %5, 120
  %53 = inttoptr i64 %52 to ptr
  %54 = load i64, ptr %53, align 8
  %55 = inttoptr i64 %54 to ptr
  store i8 0, ptr %55, align 1
  br label %63

56:                                               ; preds = %b1
  %57 = add i64 %21, 0
  %58 = inttoptr i64 %57 to ptr
  store i64 0, ptr %58, align 1
  %59 = add i64 %21, 9
  %60 = inttoptr i64 %59 to ptr
  store i16 0, ptr %60, align 1
  %61 = add i64 %21, 11
  %62 = inttoptr i64 %61 to ptr
  store i8 0, ptr %62, align 1
  br label %63

63:                                               ; preds = %56, %47
  ret ptr null
}

; Function Attrs: sanitize_address
define internal i8 @fn_1() #1 {
entry:
  %function_return = alloca i8, align 1
  store i8 0, ptr %function_return, align 1
  %mapping_key_word = alloca i64, align 8
  %mapping_value_word = alloca i64, align 8
  %local0 = alloca i64, align 8
  store i64 1, ptr %local0, align 4
  %local1 = alloca ptr, align 8
  store ptr null, ptr %local1, align 8
  %v92 = call i64 @relar_int_literal(ptr @str_0, i64 51)
  %v93 = load i64, ptr %local0, align 4
  store i64 %v92, ptr %local0, align 4
  %tag.i19 = and i64 %v93, 1
  %small.i20 = icmp eq i64 %tag.i19, 1
  %absent.i21 = icmp eq i64 %v93, 0
  %immediate.i22 = or i1 %small.i20, %absent.i21
  br i1 %immediate.i22, label %release_int.exit24, label %big.i23

big.i23:                                          ; preds = %entry
  call void @relar_int_release(i64 %v93)
  br label %release_int.exit24

release_int.exit24:                               ; preds = %entry, %big.i23
  %v94 = call ptr @relar_dict_new(i32 3, i32 4)
  %v95 = call ptr @relar_str_literal(ptr @str_1, i64 34)
  %v96 = call ptr @relar_list_new()
  %v97 = load i64, ptr %local0, align 4
  call void @relar_list_append(ptr %v96, i64 %v97)
  %v98 = ptrtoint ptr %v95 to i64
  %v99 = ptrtoint ptr %v96 to i64
  call void @relar_dict_set(ptr %v94, i64 %v98, i64 %v99)
  call void @relar_list_release(ptr %v96)
  call void @relar_str_release(ptr %v95)
  %v100 = call ptr @fn_0(ptr %v94)
  %v101 = call i8 @relar_error_pending()
  %v102 = icmp ne i8 %v101, 0
  br i1 %v102, label %b18, label %b19, !prof !4

b18:                                              ; preds = %release_int.exit24
  call void @relar_object_release(ptr %v94)
  br label %b17

b19:                                              ; preds = %release_int.exit24
  call void @relar_object_release(ptr %v94)
  %v103 = load ptr, ptr %local1, align 8
  store ptr %v100, ptr %local1, align 8
  call void @relar_list_release(ptr %v103)
  %v104 = load ptr, ptr %local1, align 8
  %v105 = lshr i64 1, 1
  %v106 = call i64 @relar_list_get_index(ptr %v104, i64 %v105)
  %v107 = icmp eq i64 %v106, 0
  br i1 %v107, label %b20, label %b21, !prof !4

b20:                                              ; preds = %b19
  br label %b17

b21:                                              ; preds = %b19
  call void @relar_print_int(i64 %v106)
  %v108 = call i8 @relar_error_pending()
  %v109 = icmp ne i8 %v108, 0
  br i1 %v109, label %b22, label %b23, !prof !4

b22:                                              ; preds = %b21
  %tag.i13 = and i64 %v106, 1
  %small.i14 = icmp eq i64 %tag.i13, 1
  %absent.i15 = icmp eq i64 %v106, 0
  %immediate.i16 = or i1 %small.i14, %absent.i15
  br i1 %immediate.i16, label %release_int.exit18, label %big.i17

big.i17:                                          ; preds = %b22
  call void @relar_int_release(i64 %v106)
  br label %release_int.exit18

release_int.exit18:                               ; preds = %b22, %big.i17
  br label %b17

b23:                                              ; preds = %b21
  %tag.i7 = and i64 %v106, 1
  %small.i8 = icmp eq i64 %tag.i7, 1
  %absent.i9 = icmp eq i64 %v106, 0
  %immediate.i10 = or i1 %small.i8, %absent.i9
  br i1 %immediate.i10, label %release_int.exit12, label %big.i11

big.i11:                                          ; preds = %b23
  call void @relar_int_release(i64 %v106)
  br label %release_int.exit12

release_int.exit12:                               ; preds = %b23, %big.i11
  br label %b16

b16:                                              ; preds = %release_int.exit12
  %v110 = load i64, ptr %local0, align 4
  store i64 1, ptr %local0, align 4
  %tag.i1 = and i64 %v110, 1
  %small.i2 = icmp eq i64 %tag.i1, 1
  %absent.i3 = icmp eq i64 %v110, 0
  %immediate.i4 = or i1 %small.i2, %absent.i3
  br i1 %immediate.i4, label %release_int.exit6, label %big.i5

big.i5:                                           ; preds = %b16
  call void @relar_int_release(i64 %v110)
  br label %release_int.exit6

release_int.exit6:                                ; preds = %b16, %big.i5
  %v111 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_list_release(ptr %v111)
  %v112 = load i8, ptr %function_return, align 1
  ret i8 %v112

b17:                                              ; preds = %release_int.exit18, %b20, %b18
  %v113 = load i64, ptr %local0, align 4
  store i64 1, ptr %local0, align 4
  %tag.i = and i64 %v113, 1
  %small.i = icmp eq i64 %tag.i, 1
  %absent.i = icmp eq i64 %v113, 0
  %immediate.i = or i1 %small.i, %absent.i
  br i1 %immediate.i, label %release_int.exit, label %big.i

big.i:                                            ; preds = %b17
  call void @relar_int_release(i64 %v113)
  br label %release_int.exit

release_int.exit:                                 ; preds = %b17, %big.i
  %v114 = load ptr, ptr %local1, align 8
  store ptr null, ptr %local1, align 8
  call void @relar_list_release(ptr %v114)
  ret i8 0
}

; Function Attrs: sanitize_address
define i32 @main() #1 {
entry:
  %function_return = alloca i8, align 1
  store i8 0, ptr %function_return, align 1
  %mapping_key_word = alloca i64, align 8
  %mapping_value_word = alloca i64, align 8
  %v115 = call i8 @fn_1()
  %v116 = call i8 @relar_error_pending()
  %v117 = icmp ne i8 %v116, 0
  br i1 %v117, label %b26, label %b27, !prof !4

b26:                                              ; preds = %entry
  br label %b25

b27:                                              ; preds = %entry
  br label %b24

b24:                                              ; preds = %b27
  call void @relar_flush_stdout()
  %v118 = call i8 @relar_error_pending()
  %v119 = icmp ne i8 %v118, 0
  br i1 %v119, label %b28, label %b29, !prof !4

b28:                                              ; preds = %b24
  br label %b25

b29:                                              ; preds = %b24
  ret i32 0

b25:                                              ; preds = %b28, %b26
  %v120 = call i32 @relar_error_unhandled()
  ret i32 %v120
}

declare void @__asan_report_load_n(i64, i64)

declare void @__asan_loadN(i64, i64)

declare void @__asan_report_load1(i64)

declare void @__asan_load1(i64)

declare void @__asan_report_load2(i64)

declare void @__asan_load2(i64)

declare void @__asan_report_load4(i64)

declare void @__asan_load4(i64)

declare void @__asan_report_load8(i64)

declare void @__asan_load8(i64)

declare void @__asan_report_load16(i64)

declare void @__asan_load16(i64)

declare void @__asan_report_store_n(i64, i64)

declare void @__asan_storeN(i64, i64)

declare void @__asan_report_store1(i64)

declare void @__asan_store1(i64)

declare void @__asan_report_store2(i64)

declare void @__asan_store2(i64)

declare void @__asan_report_store4(i64)

declare void @__asan_store4(i64)

declare void @__asan_report_store8(i64)

declare void @__asan_store8(i64)

declare void @__asan_report_store16(i64)

declare void @__asan_store16(i64)

declare void @__asan_report_exp_load_n(i64, i64, i32)

declare void @__asan_exp_loadN(i64, i64, i32)

declare void @__asan_report_exp_load1(i64, i32)

declare void @__asan_exp_load1(i64, i32)

declare void @__asan_report_exp_load2(i64, i32)

declare void @__asan_exp_load2(i64, i32)

declare void @__asan_report_exp_load4(i64, i32)

declare void @__asan_exp_load4(i64, i32)

declare void @__asan_report_exp_load8(i64, i32)

declare void @__asan_exp_load8(i64, i32)

declare void @__asan_report_exp_load16(i64, i32)

declare void @__asan_exp_load16(i64, i32)

declare void @__asan_report_exp_store_n(i64, i64, i32)

declare void @__asan_exp_storeN(i64, i64, i32)

declare void @__asan_report_exp_store1(i64, i32)

declare void @__asan_exp_store1(i64, i32)

declare void @__asan_report_exp_store2(i64, i32)

declare void @__asan_exp_store2(i64, i32)

declare void @__asan_report_exp_store4(i64, i32)

declare void @__asan_exp_store4(i64, i32)

declare void @__asan_report_exp_store8(i64, i32)

declare void @__asan_exp_store8(i64, i32)

declare void @__asan_report_exp_store16(i64, i32)

declare void @__asan_exp_store16(i64, i32)

declare ptr @__asan_memmove(ptr, ptr, i64)

declare ptr @__asan_memcpy(ptr, ptr, i64)

declare ptr @__asan_memset(ptr, i32, i64)

declare void @__asan_handle_no_return()

declare void @__sanitizer_ptr_cmp(i64, i64)

declare void @__sanitizer_ptr_sub(i64, i64)

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.amdgcn.is.shared(ptr nocapture) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.amdgcn.is.private(ptr nocapture) #0

declare i64 @__asan_stack_malloc_0(i64)

declare void @__asan_stack_free_0(i64, i64)

declare i64 @__asan_stack_malloc_1(i64)

declare void @__asan_stack_free_1(i64, i64)

declare i64 @__asan_stack_malloc_2(i64)

declare void @__asan_stack_free_2(i64, i64)

declare i64 @__asan_stack_malloc_3(i64)

declare void @__asan_stack_free_3(i64, i64)

declare i64 @__asan_stack_malloc_4(i64)

declare void @__asan_stack_free_4(i64, i64)

declare i64 @__asan_stack_malloc_5(i64)

declare void @__asan_stack_free_5(i64, i64)

declare i64 @__asan_stack_malloc_6(i64)

declare void @__asan_stack_free_6(i64, i64)

declare i64 @__asan_stack_malloc_7(i64)

declare void @__asan_stack_free_7(i64, i64)

declare i64 @__asan_stack_malloc_8(i64)

declare void @__asan_stack_free_8(i64, i64)

declare i64 @__asan_stack_malloc_9(i64)

declare void @__asan_stack_free_9(i64, i64)

declare i64 @__asan_stack_malloc_10(i64)

declare void @__asan_stack_free_10(i64, i64)

declare void @__asan_poison_stack_memory(i64, i64)

declare void @__asan_unpoison_stack_memory(i64, i64)

declare void @__asan_set_shadow_00(i64, i64)

declare void @__asan_set_shadow_01(i64, i64)

declare void @__asan_set_shadow_02(i64, i64)

declare void @__asan_set_shadow_03(i64, i64)

declare void @__asan_set_shadow_04(i64, i64)

declare void @__asan_set_shadow_05(i64, i64)

declare void @__asan_set_shadow_06(i64, i64)

declare void @__asan_set_shadow_07(i64, i64)

declare void @__asan_set_shadow_f1(i64, i64)

declare void @__asan_set_shadow_f2(i64, i64)

declare void @__asan_set_shadow_f3(i64, i64)

declare void @__asan_set_shadow_f5(i64, i64)

declare void @__asan_set_shadow_f8(i64, i64)

declare void @__asan_alloca_poison(i64, i64)

declare void @__asan_allocas_unpoison(i64, i64)

declare void @__asan_before_dynamic_init(i64)

declare void @__asan_after_dynamic_init()

declare void @__asan_register_globals(i64, i64)

declare void @__asan_unregister_globals(i64, i64)

declare void @__asan_register_image_globals(i64)

declare void @__asan_unregister_image_globals(i64)

declare void @__asan_register_elf_globals(i64, i64, i64)

declare void @__asan_unregister_elf_globals(i64, i64, i64)

declare void @__asan_init()

; Function Attrs: nounwind
define internal void @asan.module_ctor() #2 comdat {
  call void @__asan_init()
  call void @__asan_version_mismatch_check_v8()
  call void @__asan_register_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

declare void @__asan_version_mismatch_check_v8()

; Function Attrs: nounwind
define internal void @asan.module_dtor() #2 comdat {
  call void @__asan_unregister_elf_globals(i64 ptrtoint (ptr @___asan_globals_registered to i64), i64 ptrtoint (ptr @__start_asan_globals to i64), i64 ptrtoint (ptr @__stop_asan_globals to i64))
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { sanitize_address }
attributes #2 = { nounwind }

!0 = !{ptr @kinds_tuple_1}
!1 = !{ptr @layout_tuple_1}
!2 = !{ptr @str_0}
!3 = !{ptr @str_1}
!4 = !{!"branch_weights", i32 1, i32 2000}
