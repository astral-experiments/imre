"""Run only after the parent declares final tools frozen and the host quiet."""

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
SESSION = LOCAL / "inventory-performance-final-session.json"
CACHE_PROBE = r"""
import hashlib, importlib.util, json, pathlib, struct, sys
records = {}
for package in sys.argv[1:]:
    for source in sorted(pathlib.Path(package).rglob('*.py')):
        cached = pathlib.Path(importlib.util.cache_from_source(str(source)))
        data, content = cached.read_bytes(), source.read_bytes()
        assert data[:4] == importlib.util.MAGIC_NUMBER, source
        flags = int.from_bytes(data[4:8], 'little')
        if flags & 1:
            assert data[8:16] == importlib.util.source_hash(content), source
        else:
            timestamp, size = struct.unpack('<II', data[8:16])
            assert timestamp == (int(source.stat().st_mtime) & 0xffffffff), source
            assert size == (len(content) & 0xffffffff), source
        records[str(source)] = {'source_sha256': hashlib.sha256(content).hexdigest(), 'cache_path': str(cached), 'cache_sha256': hashlib.sha256(data).hexdigest(), 'cache_bytes': len(data), 'flags': flags, 'source_mtime_ns': source.stat().st_mtime_ns, 'valid_header': True}
print(json.dumps({'python': sys.version, 'cache_tag': sys.implementation.cache_tag, 'magic': importlib.util.MAGIC_NUMBER.hex(), 'pycache_prefix': sys.pycache_prefix, 'dont_write_bytecode': sys.dont_write_bytecode, 'files': records}))
"""


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*arguments):
    return subprocess.check_output(["git", "-C", str(ROOT), *arguments])


def clean_sources(tools, expected_head=None):
    head = git("rev-parse", "HEAD").decode().strip()
    if (
        git("status", "--porcelain")
        or expected_head is not None
        and head != expected_head
    ):
        raise RuntimeError("final comparisons require one unchanged clean checkout")
    record = json.loads((tools / "build-record.json").read_text())
    for name, expected in record["source_sha256"].items():
        if (
            sha(ROOT / name) != expected
            or hashlib.sha256(git("show", head + ":" + name)).hexdigest() != expected
        ):
            raise RuntimeError(
                "frozen compiled source differs from clean HEAD: " + name
            )
    return {
        "head": head,
        "dirty": False,
        "all_compiled_sources_match_commit": True,
        "build_record_sha256": sha(tools / "build-record.json"),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--tools", type=Path, default=LOCAL / "inventory-performance-tools-final"
    )
    args = parser.parse_args()
    tools = args.tools.resolve(strict=True)
    if SESSION.exists():
        raise RuntimeError("final session record must be new: " + str(SESSION))
    before = clean_sources(tools)
    python = json.loads((LOCAL / "inventory-normal-final.json").read_text())["method"][
        "commands"
    ]["inventory"]["cpython"][0]

    def caches():
        command = [
            python,
            "-I",
            "-c",
            CACHE_PROBE,
            str(ROOT / "examples/inventory_reconciliation"),
            str(ROOT / "examples/incremental_planner"),
        ]
        return json.loads(subprocess.check_output(command, cwd=ROOT, text=True))

    session = {
        "command": [sys.executable, *sys.argv],
        "launcher_sha256": sha(Path(__file__)),
        "runner_source": Path(__file__).read_text(),
        "before": before,
        "runs": {},
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_commit": before["head"],
        "git_status_before": "",
        "bytecode_before": caches(),
    }
    for mode in ("normal", "lto"):
        guard = clean_sources(tools, before["head"])
        old = json.loads((LOCAL / f"inventory-{mode}-final.json").read_text())
        old_compile = old["method"]["compile_commands"]["inventory"]
        clang = old_compile[old_compile.index("--clang") + 1]
        output = LOCAL / f"inventory-performance-{mode}-final.json"
        if output.exists() or output.with_suffix("").exists():
            raise RuntimeError("final output must be new: " + str(output))
        command = [
            sys.executable,
            "-u",
            str(ROOT / "benchmarks/inventory_benchmark.py"),
            "--compiler",
            str(tools / "relar"),
            "--runtime",
            str(
                tools
                / ("librelar_runtime_lto.a" if mode == "lto" else "librelar_runtime.a")
            ),
            "--relar-build-record",
            str(tools / "build-record.json"),
            "--rust-bigint",
            str(LOCAL / f"inventory-reference-final-{mode}/inventory-bigint"),
            "--rust-build-record",
            str(LOCAL / f"inventory-reference-final-{mode}/build-record.json"),
            "--inventory-baseline",
            str(LOCAL / f"inventory-{mode}-final/inventory_reconciliation"),
            "--inventory-baseline-record",
            str(LOCAL / f"inventory-{mode}-final.json"),
            "--baseline",
            str(LOCAL / f"layout-{mode}-final/incremental_planner"),
            "--baseline-record",
            str(LOCAL / f"layout-{mode}-final.json"),
            "--python",
            old["method"]["commands"]["inventory"]["cpython"][0],
            "--clang",
            clang,
            "--target",
            "x86_64-unknown-linux-gnu",
            "--samples",
            "48",
            "--warmups",
            "2",
            "--cpu",
            "0",
            "--output",
            str(output),
            "--artifact-dir",
            str(output.with_suffix("")),
        ]
        if mode == "lto":
            command += ["--lto-linker", str(LOCAL / "batch-linker/ld.lld")]
        log_path = output.with_suffix(".log")
        item = {
            "mode": mode,
            "command": command,
            "source_guard": guard,
            "started_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        session["runs"][mode] = item
        SESSION.write_text(json.dumps(session, indent=2) + "\n")
        print("Starting final " + mode, flush=True)
        with log_path.open("w") as log:
            process = subprocess.Popen(
                command,
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            for line in process.stdout:
                log.write(line)
                log.flush()
                print(line, end="", flush=True)
            status = process.wait()
        item.update(
            returncode=status,
            completed_at_utc=datetime.now(timezone.utc).isoformat(),
            log_sha256=sha(log_path),
        )
        if output.exists():
            item["record_sha256"] = sha(output)
        SESSION.write_text(json.dumps(session, indent=2) + "\n")
        if status:
            raise SystemExit(status)
        item["source_guard_after"] = clean_sources(tools, before["head"])
        if caches() != session["bytecode_before"]:
            raise RuntimeError("Python package cache bytes changed during measurement")
        SESSION.write_text(json.dumps(session, indent=2) + "\n")
    session.update(
        bytecode_after=caches(),
        git_status_after=git("status", "--porcelain").decode(),
        completed_at_utc=datetime.now(timezone.utc).isoformat(),
    )
    SESSION.write_text(json.dumps(session, indent=2) + "\n")


if __name__ == "__main__":
    main()
