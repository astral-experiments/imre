"""Run the authorized final profile pair sequentially, retaining outer statuses."""

import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
RECORD = LOCAL / "inventory-performance-final-profiling.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if RECORD.exists():
        raise RuntimeError("outer profile record must be new")
    record = {
        "schema_version": 1,
        "command": [sys.executable, *sys.argv],
        "runner_sha256": sha(Path(__file__)),
        "profiler_driver_sha256": sha(ROOT / "benchmarks/inventory_profile.py"),
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "runs": {},
        "scope": "Sequential Callgrind/DHAT diagnostics on final Relar only; no builds, native timings, or Rust reruns.",
    }

    def save():
        RECORD.write_text(json.dumps(record, indent=2) + "\n")

    save()
    for mode in ("normal", "lto"):
        source = LOCAL / f"inventory-performance-{mode}-final.json"
        output = LOCAL / f"inventory-performance-final-profile-{mode}"
        log_path = output.with_suffix(".log")
        if output.exists() or log_path.exists():
            raise RuntimeError("profile output and log must be new: " + str(output))
        command = [
            sys.executable, "-I", "-u", str(ROOT / "benchmarks/inventory_profile.py"),
            "--record", str(source), "--output", str(output),
            "--engine", "relar", "--workload", "dense-16384", "--workload", "sparse-16384",
            "--tools", "callgrind", "dhat", "--cpu", "0",
        ]
        item = {"command": command, "record_sha256": sha(source), "started_at_utc": datetime.now(timezone.utc).isoformat()}
        record["runs"][mode] = item
        save()
        with log_path.open("w") as log:
            process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in process.stdout:
                log.write(line)
                log.flush()
                print(line, end="", flush=True)
            item["returncode"] = process.wait()
        item.update(completed_at_utc=datetime.now(timezone.utc).isoformat(), log_sha256=sha(log_path))
        save()
        if item["returncode"]:
            raise SystemExit(item["returncode"])
        item["artifacts_sha256"] = {name: sha(output / name) for name in ("summary.json", "provenance.json", "manifest.json")}
        save()
    record.update(completed_at_utc=datetime.now(timezone.utc).isoformat(), status="passed")
    save()
    print("Final profiles passed; outer record SHA256 " + sha(RECORD), flush=True)


if __name__ == "__main__":
    main()
