import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess


ROOT = Path('/home/dev-user/code/oss/relar')
OUTPUT = ROOT / 'benchmarks/local/inventory-performance-validation-final'
TOOLS = ROOT / 'benchmarks/local/inventory-performance-tools-final'
PYTHON = Path('/home/dev-user/.local/bin/python3.14')
CLANG = Path('/usr/bin/clang-18')
TARGET = 'x86_64-unknown-linux-gnu'
EXPECTED_HEAD = '7ec35cbd0a94ca82419061c725382b2e2a1d4a1e'
ENV = {**os.environ, 'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1'}


def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def captured(command):
    return subprocess.check_output(command, cwd=ROOT, text=True).strip()


def provenance():
    tracer = next(line.split(':', 1)[1].strip() for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('TracerPid:'))
    assert tracer == '0', f'Validation must run outside ptrace, got {tracer}'
    head = captured(['git', 'rev-parse', 'HEAD'])
    assert head == EXPECTED_HEAD, head
    record_path = TOOLS / 'build-record.json'
    record = json.loads(record_path.read_text())
    assert record['git_head'] == head and record['compiled_sources_match_commit']
    for name, expected in record['source_sha256'].items():
        assert digest(ROOT / name) == expected, name
    for name, expected in record['sha256'].items():
        assert digest(ROOT / name) == expected, name
    sysroot = Path(captured(['rustc', '+ohm', '--print', 'sysroot']))
    linker = sysroot / 'lib/rustlib' / TARGET / 'bin/rust-lld'
    sources = [ROOT / 'tests/lto.py', ROOT / 'tests/programs/short_strings.py', ROOT / 'benchmarks/inventory_validate.py', ROOT / 'benchmarks/manifest_validate.py']
    sources += sorted((ROOT / 'examples/inventory_reconciliation').rglob('*.py'))
    return {
        'head': head,
        'tracer_pid': int(tracer),
        'cwd': str(ROOT),
        'started_at': stamp(),
        'build_record': str(record_path),
        'build_record_sha256': digest(record_path),
        'compiled_sources_sha256': record['source_sha256'],
        'tools_sha256': record['sha256'],
        'validation_sources_sha256': {str(path.relative_to(ROOT)): digest(path) for path in sources},
        'python': {'path': str(PYTHON), 'resolved': str(PYTHON.resolve()), 'sha256': digest(PYTHON), 'version': captured([str(PYTHON), '--version'])},
        'clang': {'path': str(CLANG), 'resolved': str(CLANG.resolve()), 'sha256': digest(CLANG), 'version': captured([str(CLANG), '--version'])},
        'rust_lld': {'path': str(linker), 'sha256': digest(linker), 'version': captured([str(linker), '-flavor', 'gnu', '--version'])},
        'target': TARGET,
        'environment': {'ASAN_OPTIONS': ENV['ASAN_OPTIONS']},
        'runner_sha256': digest(Path(__file__)),
    }


def run_step(directory, name, command, steps):
    stdout = directory / (name + '.stdout')
    stderr = directory / (name + '.stderr')
    step = {'name': name, 'command': [str(arg) for arg in command], 'started_at': stamp()}
    with stdout.open('wb') as out, stderr.open('wb') as err:
        result = subprocess.run(step['command'], cwd=ROOT, env=ENV, stdout=out, stderr=err, check=False, timeout=900)
    step.update(returncode=result.returncode, completed_at=stamp(), stdout=str(stdout), stderr=str(stderr), stdout_sha256=digest(stdout), stderr_sha256=digest(stderr))
    steps.append(step)
    assert result.returncode == 0, (name, result.returncode, str(stderr))


def validate(kind, common):
    directory = OUTPUT / kind
    directory.mkdir(exist_ok=False)
    record = {**common, 'validation': kind, 'steps': [], 'status': 'running'}
    path = directory / 'record.json'
    path.write_text(json.dumps(record, indent=2) + '\n')
    try:
        if kind == 'lto-cli':
            command = [PYTHON, ROOT / 'tests/lto.py', '--compiler', TOOLS / 'relar', '--runtime', TOOLS / 'librelar_runtime_lto.a', '--clang', CLANG, '--target', TARGET, '--rust-lld', common['rust_lld']['path'], '--python', PYTHON]
            run_step(directory, 'checks', command, record['steps'])
            record['checks'] = 10
        else:
            binary = directory / 'inventory_reconciliation'
            llvm = directory / 'inventory_reconciliation.ll'
            oracle = directory / 'oracle.json'
            command = [TOOLS / 'relar', 'build', ROOT / 'examples/inventory_reconciliation/__main__.py', '--module-root', ROOT / 'examples', '--runtime', TOOLS / 'librelar_runtime_asan.a', '--clang', CLANG, '--opt-level', '1', '--sanitize', '--emit-llvm', llvm, '-o', binary]
            run_step(directory, 'build', command, record['steps'])
            command = [PYTHON, ROOT / 'benchmarks/inventory_validate.py', '--python', PYTHON, '--binary', binary, '--output', oracle]
            run_step(directory, 'oracle', command, record['steps'])
            evidence = json.loads(oracle.read_text())
            assert evidence['device_check'].get('case') == 'terminal-report-device-error'
            assert set(evidence['device_check']['engines']) == {'cpython', 'relar'}
            record['oracle_summary'] = {key: evidence[key] for key in ('cases', 'successful', 'terminal_errors', 'engines')}
            record['device_check'] = evidence['device_check']
            record['artifacts_sha256'] = {str(item): digest(item) for item in (binary, llvm, oracle)}
        for name, expected in common['validation_sources_sha256'].items():
            assert digest(ROOT / name) == expected, name
        for name, expected in common['compiled_sources_sha256'].items():
            assert digest(ROOT / name) == expected, name
        record['status'] = 'passed'
    except BaseException as error:
        record['status'] = 'failed'
        record['failure'] = repr(error)
        raise
    finally:
        record['completed_at'] = stamp()
        path.write_text(json.dumps(record, indent=2) + '\n')
    return {'validation': kind, 'status': record['status'], 'record': str(path), 'record_sha256': digest(path), 'checks': record.get('checks'), 'oracle': record.get('oracle_summary')}


common = provenance()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(validate, kind, common) for kind in ('lto-cli', 'inventory-asan')]
    results = [future.result() for future in futures]
print(json.dumps(results, indent=2))
