# Report renderer

The retained renderer expects its input audits beside the script. Copy `../../audit/inventory-performance-final-audit.json` and `../../audit/inventory-performance-final-profile-audit.json` into this directory, then run `python3 inventory-performance-fill-report.py`. It writes `inventory-performance-report.md`. The original source and template are preserved without path rewrites.
