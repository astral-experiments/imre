"""Render the publication tables from the independently audited records."""

import json
from pathlib import Path


LOCAL = Path(__file__).resolve().parent
REPORT = LOCAL / "inventory-performance-report.md"
TEMPLATE = LOCAL / "inventory-performance-report-template.md"
PREFIX = "2026-10-18-inventory-performance"


def load(name):
    return json.loads((LOCAL / name).read_text())


def time_cell(row, engine):
    stats = row["statistics"][engine]
    return (
        f"{stats['median_ns'] / 1e6:.3f} "
        f"[{stats['p25_ns'] / 1e6:.3f}–{stats['p75_ns'] / 1e6:.3f}]"
    )


audit = load("inventory-performance-final-audit.json")
profiles = load("inventory-performance-final-profile-audit.json")
assert audit["status"] == "passed"
inventory = []
controls = [
    "| Mode | Workload | CPython ms | Preserved Relar ms | Optimized Relar ms | Time change |",
    "|---|---|---:|---:|---:|---:|",
]
for mode in audit["modes"]:
    label = "Ordinary" if mode["mode"] == "normal" else "ThinLTO"
    inventory += [
        f"**{label}**",
        "",
        "| Workload | CPython ms | Preserved Relar ms | Optimized Relar ms | Rust BigInt ms | Before/Relar | CPython/Relar | Relar/Rust |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in mode["rows"]:
        ratios = row["ratios_of_medians"]
        if row["group"] == "inventory":
            cells = [row["workload"]]
            cells += [time_cell(row, name) for name in ("cpython", "baseline", "relar", "rust_bigint")]
            cells += [f"{ratios[key]:.3f}×" for key in ("baseline_over_relar", "cpython_over_relar", "relar_over_rust_bigint")]
            inventory.append("| " + " | ".join(cells) + " |")
        else:
            cells = [label, row["workload"]]
            cells += [time_cell(row, name) for name in ("cpython", "baseline", "relar")]
            cells.append(f"{100 * (ratios['relar_over_baseline'] - 1):+.2f}%")
            controls.append("| " + " | ".join(cells) + " |")
    inventory.append("")

cpu = [
    "| Mode | Input | Original instructions | Optimized instructions | Rust instructions | Relar reduction |",
    "|---|---|---:|---:|---:|---:|",
]
memory = [
    "| Input | Engine | Allocated blocks | Requested bytes | Peak live requested bytes |",
    "|---|---|---:|---:|---:|",
]
for mode, data in profiles["modes"].items():
    label = "Ordinary" if mode == "normal" else "ThinLTO"
    for row in data["workloads"]:
        p = row["profiles"]
        cells = [label, row["label"]]
        cells += [f"{p[engine]['instructions']:,}" for engine in ("baseline", "relar", "rust_bigint")]
        cells.append(f"{100 * row['reduction_fraction_from_baseline']['instructions']:.1f}%")
        cpu.append("| " + " | ".join(cells) + " |")
        if mode == "normal":
            for engine, display in (("baseline", "Original Relar"), ("relar", "Optimized Relar"), ("rust_bigint", "Rust BigInt")):
                cells = [row["label"], display]
                cells += [f"{p[engine][key]:,}" for key in ("allocated_blocks", "requested_bytes", "peak_live_bytes")]
                memory.append("| " + " | ".join(cells) + " |")

replacements = {
    "FINAL_HEADLINE": "Fusing string construction reduces large inventory times by **29.0–33.6% with ThinLTO** and **32.7–36.0% with ordinary linking**, without changing the program. With ThinLTO, Relar runs **2.52–3.37× faster than CPython** and takes **1.048–1.098× the Rust BigInt reference's time**. Allocation counts fall **68.7–70.9%**; a measurable Rust timing advantage remains.",
    "PROFILE_TABLES": "\n".join(cpu) + "\n\nAllocation counts are identical across linking modes. Requested and peak bytes differ by three bytes with executable-path length; this table uses ordinary linking.\n\n" + "\n".join(memory) + "\n\nRequested allocation bytes fall 66.3% on dense input and 58.7% on sparse input. Optimized allocation counts are 2.48% above Rust on dense input and 0.029% above Rust on sparse input; requested bytes are 7.45% and 11.25% below Rust. Peak live requested heap is essentially unchanged by this optimization. The preserved Rust profiles use the exact unchanged reference binaries and captured inputs used in the final timing run; only optimized Relar needed new profile runs.",
    "REMAINING_COSTS": "The remaining allocation traffic is concentrated in parsing, eager records, owned concatenation results, and complete write buffers. Ordinary-mode stacks retain the runtime entry-point boundaries used for this attribution; ThinLTO inlining moves many allocations into generated functions.\n\n| Allocation entry | Dense blocks | Sparse blocks |\n|---|---:|---:|\n| `split_whitespace` | 76,145 | 142,445 |\n| `record_new` | 54,330 | 90,757 |\n| `concat_parts` | 42,514 | 84,270 |\n| `text_write_parts` | 21,891 | 24,811 |\n| `splitlines` | 19,080 | 35,663 |\n\nThe final traces contain no allocating `int_str` entry and no executed `CompactString::push_str` function. The six remaining ordinary-mode literal allocations are negligible. ThinLTO self-instruction counts include 15.65M/25.00M in the dense/sparse renderer, 14.01M/17.70M in dictionary insertion, and 7.37M/15.69M in token splitting. These exclude callees. Total ThinLTO instructions remain 32.5%/31.8% above Rust, while native elapsed times are 4.8%/9.8% higher; instruction counts and elapsed-time ratios are not interchangeable.\n\nThe unchanged renderer still materializes a string before its `line` helper adds the newline. The Rust reference formats directly into its writer. Further work could investigate that call boundary and record/container ownership, guided by these profiles.",
    "INVENTORY_TABLES": "\n".join(inventory).rstrip(),
    "CONTROL_TABLE": "\n".join(controls),
    "CONTROL_INTERPRETATION": "All ten optimized-control IQRs overlap their preserved-baseline IQRs. Median changes range from −2.09% to +1.04%; these runs show no clear control regression. Their Python sources are unchanged, but generated LLVM differs because the compiler changed. We do not claim LLVM identity or infer exact equivalence of performance from overlapping IQRs.",
    "VALIDATION_COUNTS": "All eight semantic suites pass: **710 checks at ordinary `-O0`/`-O3`, 533 at ThinLTO `-O3`, and 710 with AddressSanitizer at `-O0`/`-O1`**, plus 10 ThinLTO CLI checks. A separately instrumented inventory executable passes all 176 oracle cases and `/dev/full`. The 65 Rust unit tests, Clippy, formatting, and Ruff checks pass. There are also 45 pure-Python harness/preflight checks; they are not native executions.\n\nThe retained timing audit verifies 39,569 assertions across 3,744 measured runs, 156 warmups, 48 workload gates, and 2,448 oracle/parser/device outcomes. The semantic index checks 177 file hashes and establishes exact source/artifact identity for reused development-candidate validation. Unit/Clippy commands and zero exits are explicitly recorded as root-observed results, with their logs. The profile audit reparses all 24 baseline/final/Rust traces and verifies 222 sealed profile files.",
    "TOOL_VERSIONS": "The host is an x86-64 AMD EPYC-Milan Linux VM. Native compilation uses Clang 18.1.3 at `-O3`; ThinLTO uses LLD 22.1.8. Runtime/reference builds use Rust 1.98.1-dev (`ohm-1.98.1-1`, LLVM 22.1.8) with Ohm's experimental defaults disabled. CPython 3.14.5 is a GIL build with PGO and LTO enabled and its experimental JIT disabled. Exact flags, hashes, versions, commands, environment allowlists, and build logs are retained.",
    "EVIDENCE_LINKS": f"The [ordinary samples]({PREFIX}-normal.json.gz) and [ThinLTO samples]({PREFIX}-lto.json.gz) preserve the raw JSON bytes under deterministic gzip compression. The [timing audit]({PREFIX}-audit.json), [profile audit]({PREFIX}-profiles.json), [semantic validation index]({PREFIX}-validation.json), and [frozen build record]({PREFIX}-build.json) record the checks and identities behind the tables.\n\nThe [evidence archive]({PREFIX}-evidence.tar.gz) contains the measured source snapshot, generated LLVM, baseline/final raw traces, complete retained profile outputs, validation logs and runner records, timing/profiling launchers, audit scripts, and the isolated sanitizer diagnosis. The [manifest]({PREFIX}-evidence-manifest.json) hashes every archive member and companion file. Native binaries, runtime archives, interpreters, and toolchains are excluded; their paths and hashes remain in the records. Audits that need those artifacts require the preserved local files. Raw timing and trace data support statistical recomputation and trace parsing independently.\n\nUse the [benchmark guide](../README.md) for builds and comparisons. `inventory_benchmark.py` accepts a preserved inventory executable and its record through `--inventory-baseline` and `--inventory-baseline-record`; `inventory_profile.py` profiles exact artifacts from a completed timing record without rebuilding them. The archived launchers preserve the exact commands used here. Rebuilds should produce new records rather than replace these retained observations.",
}

if not TEMPLATE.exists():
    TEMPLATE.write_text(REPORT.read_text())
text = TEMPLATE.read_text()
for marker, replacement in replacements.items():
    assert text.count(marker) == 1, marker
    text = text.replace(marker, replacement)
text = text.replace(
    "Literal surrogate-escape validation must account for f-string literal spans and raw prefixes.",
    "Literal surrogate-escape validation must account for each adjacent part's raw prefix and recursively inspect field expressions. Ruff's flattened element iterator omits adjacent ordinary literals, so lowering must preserve the complete part sequence. Multiline literal tabs/form feeds must also remain data rather than trigger code-indentation checks.",
)
text = text.replace(
    "Keyword/default arguments can follow with a separate argument-binding and definition-time default-storage design.",
    "Acceptance cases should also cover mixed raw/ordinary adjacency, escaped braces/NUL, nested f-strings in field expressions, explicit empty `:`, `KeyError` quoting, narrowed optionals, a shadowed `str` name, ownership across later mutation/failure, and used/discarded write results. Debug `=` must be rejected even with `!s`, as must dynamic specifications that happen to produce an empty string. Keyword/default arguments can follow with a separate argument-binding and definition-time default-storage design.",
)
text = text.replace(
    "plus 10 ThinLTO CLI checks. A separately",
    "plus 10 ThinLTO CLI checks. These suite totals include compile-time rejections and are not all native executions. A separately",
)
text = text.replace(
    "The six remaining ordinary-mode literal allocations are negligible.",
    "The six remaining ordinary-mode literal allocations in each workload are negligible.",
)
REPORT.write_text(text)
print(f"Rendered {REPORT.name}: {len(text.splitlines())} lines from audited records")
