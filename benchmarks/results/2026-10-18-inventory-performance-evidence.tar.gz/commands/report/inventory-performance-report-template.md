# Inventory string construction: CPU, allocations, and Rust comparison

FINAL_HEADLINE

The application and Rust reference are unchanged. The implementation is [PR 28](https://github.com/viarius-experiments/imre/pull/28), continuing native GitHub Stack 4. Measurements use clean source commit `7ec35cbd0a94ca82419061c725382b2e2a1d4a1e`; its compiler and runtime artifacts are byte-identical to the final development candidate validated before publication.

## What the profiles changed

The original runtime spent most allocation traffic on intermediate concatenations, string literals, and integer-to-string conversion: 79.6% of allocated blocks on dense input and 77.7% on sparse input. Callgrind also showed substantial work in allocation/free paths and repeated `CompactString::push_str` calls.

We now stage each exact string-concatenation tree in source order. Literals borrow immutable UTF-8 spans. Exact builtin `str` conversion leaves format tagged integers into 20-byte function-entry scratch at their original evaluation point; larger integers retain the existing arbitrary-precision conversion. Computed strings remain independently rooted across later mutation and exceptions. After one checked capacity calculation, the runtime copies fragments into their final string storage and publishes the length once.

Discarded file writes omit the unused Unicode character count. When their argument is a direct concatenation, they also construct the complete text without a temporary reference-counted wrapper. The text is still fully assembled before checking file state, and the existing single contiguous write preserves buffering and failure behavior. Writes whose result is used retain their character-count result.

Descriptor arrays and integer buffers have unique entry-block storage, so loops reuse scratch and nested expressions cannot overwrite an earlier fragment. Allocation exhaustion remains terminal. The optimization applies to exact built-in strings and sealed file operations under the existing type and ownership rules.

Expanded sanitizer checks also exposed a pre-existing `-O0` issue: Clang 18 AddressSanitizer moved argument stores ahead of redundant default initialization, which then erased the arguments. Initializing parameter slots exactly once fixes the isolated reproduction and the existing container/file suites. CI now covers those suites at `-O0` as well as the full sanitizer suite at `-O1`.

## CPU and allocation evidence

PROFILE_TABLES

Callgrind reports executed instructions, not CPU cycles or elapsed-time shares. DHAT reports requested allocation traffic and peak live heap bytes, not process RSS. Hardware performance counters are unavailable on this devbox. Profiled elapsed times are diagnostic only and are excluded from the native timing comparison. Inclusive call costs overlap and are never added together.

REMAINING_COSTS

## Timing method

Each mode compares the preserved original inventory executable, optimized Imre, CPython, and the unchanged Rust BigInt reference on six inputs. It also compares CPython, preserved Imre, and optimized Imre on the five existing incremental-planner controls. Every inventory workload has 48 measured rounds containing all 24 engine permutations twice; controls use all six permutations eight times. There are two warmups per engine. The measured rounds balance engine positions and directed within-round predecessors; warmups, cross-round predecessors, and workload order are not balanced.

All 3,744 measured executions and 156 warmups are retained. Each uses a fresh process pinned to CPU 0, outside ptrace. Timing includes startup, input open/read/decode/parse, eager collection construction, reconciliation, complete report rendering/writes, flush/close, and exit. Fixture preparation, oracle execution, hashing/comparison, builds, and deletion are outside the timer. Inputs are created before timing and executables are exercised by validation/warmups; OS page caches are not deliberately flushed, and output is not fsynced. CPython uses its normal bytecode cache, whose application/control cache bytes are recorded before and after both sessions.

Ordinary and ThinLTO runs are sequential, after all task-owned builds, tests, and profilers stop. CPU frequency and other shared-machine activity are uncontrolled. These are complete-application measurements on one shared devbox. The Rust implementation follows the same eager algorithm and arbitrary-precision contract, using native containers, borrowed strings, and direct formatting. The comparison includes those representation differences. No C implementation was measured.

## Inventory results

Times are median milliseconds with observed Q1–Q3 in brackets. These ranges describe sample spread, not confidence intervals. Ratios divide medians; `Imre/Rust` above one means Rust is faster. The preserved and optimized executables run in the same session.

INVENTORY_TABLES

The two largest inputs each contain 16,384 positive requests and 18,906 total requests. Dense input repeats 64 stock SKUs; sparse input uses many unique and unknown SKUs. Their complete reports contain 654,942 and 1,438,871 bytes. The boundary input retains Unicode names, duplicates, unknown requests, and quantities around `10**80`. Empty and small inputs include a substantial process-startup and small-file floor; their CPython ratios do not establish equivalent computational speedups.

## Existing planner controls

CONTROL_TABLE

CONTROL_INTERPRETATION

## Semantics and validation

The independent inventory oracle checks all 176 filesystem cases (127 successful and 49 expected terminal failures), plus Linux `/dev/full`, for every timing engine before measurement. It checks complete report bytes, status/error category, and filesystem contents. Workload gates, warmups, and every measured execution receive complete checks too. The unchanged incremental planner retains its 172-case oracle.

Input ordering, last-wins stock with first insertion order, ignored nonpositive requests, unknown SKUs, arbitrary-precision quantities, Unicode/NUL handling, input/output aliases and hard links, parse-before-output-open behavior, and terminal output failures remain unchanged. The [application contract](../../examples/inventory_reconciliation/README.md) defines the exact shared domain.

VALIDATION_COUNTS

New regressions exercise both concat tree associations, expression/conversion order, field/list replacement, aliases, integer tag boundaries and large values, Unicode/NUL/empty fragments, the 23/24/25-byte inline/heap boundary, loop scratch reuse, early/late failures, closed/read-only empty writes, receiver lifetime, large writes, and `/dev/full` cleanup. Sanitizers instrument generated code and the Rust runtime/target dependencies with leak detection outside ptrace; the prebuilt Rust standard library is not instrumented.

TOOL_VERSIONS

## Next compatibility milestone

The next bounded capability should be scalar f-strings. Ruff already parses their structure, and the new ordered string construction path provides the backend. Start with ordinary/raw/triple-quoted and adjacent f-strings, escaped braces, and fields whose exact types already support `str`: integers, booleans, strings, `None`, and sealed exceptions. Support default conversion or `!s` with an empty format specification; require existing narrowing for optional values.

Each field expression and its conversion must complete before the next field evaluates. Lower directly to the sealed typed conversion operation so a local name `str` cannot change f-string behavior. Nonempty/dynamic format specifications, `!r`, `!a`, and debug `=` need explicit formatting/repr contracts and should initially receive clear compile errors. Literal surrogate-escape validation must account for f-string literal spans and raw prefixes.

The acceptance example is rewriting this same inventory renderer with expressions such as `f"FULFILL {request.batch} {request.row} {request.sku} {request.quantity} {result.filled} {result.shortage}"`, retaining the complete oracle and performance checks. This is a syntax/usability milestone; equivalent fused concatenation should already have the same optimized execution path. Keyword/default arguments can follow with a separate argument-binding and definition-time default-storage design.

## Evidence and reproduction

EVIDENCE_LINKS
