"""Stage deterministic final inventory-performance publication evidence.

Run only after final timing, profiles and audits are complete. This packages
existing bytes, never runs a benchmark/compiler, and only writes a new directory
below benchmarks/local. Native artifacts stay external with recorded hashes.
"""

import argparse
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
MODES = ("normal", "lto")
SOURCE_ROOTS = (
    "crates/", "tests/", "examples/inventory_reconciliation/",
    "examples/incremental_planner/", "benchmarks/reference/inventory_reconciliation/",
    ".github/workflows/",
)
SOURCE_FILES = {"Cargo.toml", "Cargo.lock", "rust-toolchain.toml", "docs/design.md", "docs/subset.md", "benchmarks/README.md"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def source_name(path):
    path = path.resolve()
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)


def git(*arguments):
    return subprocess.check_output(["git", "-C", str(ROOT), *arguments])


def compressed(data):
    """Use stable gzip metadata, including an empty filename and fixed OS byte."""
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0, compresslevel=9) as stream:
        stream.write(data)
    return output.getvalue()


class Package:
    def __init__(self):
        self.payloads = {}
        self.members = {}
        self.excluded = {}

    def add(self, name, data, source):
        require(name not in self.payloads and not Path(name).is_absolute() and ".." not in Path(name).parts, f"invalid/duplicate member: {name}")
        self.payloads[name] = data
        self.members[name] = {"sha256": digest(data), "bytes": len(data), "source": source}

    def file(self, path, name):
        require(not path.is_symlink(), f"evidence must not be a symlink: {path}")
        data = path.read_bytes()
        if data.startswith((b"\x7fELF", b"!<arch>\n", b"BC\xc0\xde")) or path.suffix in {".a", ".so", ".o", ".rlib", ".bc", ".exe"}:
            self.excluded[source_name(path)] = {"sha256": digest(data), "bytes": len(data), "reason": "Native executable/library/toolchain artifact is not published."}
            return
        self.add(name, data, source_name(path))

    def tree(self, path, prefix):
        require(path.is_dir(), f"required evidence directory is missing: {path}")
        for entry in sorted(path.rglob("*")):
            require(not entry.is_symlink(), f"unexpected evidence symlink: {entry}")
            if entry.is_file():
                self.file(entry, prefix + "/" + entry.relative_to(path).as_posix())

    def sealed_tree(self, path, prefix):
        manifest = load(path / "manifest.json")
        actual = {entry.relative_to(path).as_posix() for entry in path.rglob("*") if entry.is_file() and entry != path / "manifest.json"}
        require(actual == set(manifest), f"sealed evidence inventory differs: {path}")
        for name, expected in manifest.items():
            entry = (path / name).resolve(strict=True)
            require(entry.is_relative_to(path.resolve()), f"sealed evidence path escapes: {name}")
            data = entry.read_bytes()
            require(len(data) == expected["bytes"] and digest(data) == expected["sha256"], f"sealed evidence bytes changed: {entry}")
        self.tree(path, prefix)


def validate_build(final, reused, revision):
    require(final["git_head"] == revision and final["git_status"] == "" and final["compiled_sources_match_commit"] is True, "final build is not the measured clean source")
    require(final["source_sha256"] == reused["source_sha256"] and final["source_contents"] == reused["source_contents"], "reused validation source differs")
    final_hashes = {Path(path).name: value for path, value in final["sha256"].items()}
    reused_hashes = {Path(path).name: value for path, value in reused["sha256"].items()}
    require(final_hashes == reused_hashes, "reused validation tools are not byte-identical")
    for build in (final, reused):
        require(set(build["source_contents"]) == set(build["source_sha256"]), "build source inventory differs")
        require(all(digest(content.encode()) == build["source_sha256"][name] for name, content in build["source_contents"].items()), "embedded build source hash differs")
        require(all(step["returncode"] == 0 for step in build["commands"].values()), "frozen build contains a failed step")
    return final_hashes


def add_source_snapshot(package, revision, build, records):
    tracked = git("ls-tree", "-r", "--name-only", revision).decode().splitlines()
    selected = [name for name in tracked if name.startswith(SOURCE_ROOTS) or name in SOURCE_FILES or (name.startswith("benchmarks/") and name.count("/") == 1 and name.endswith(".py"))]
    snapshot = git("archive", "--format=tar", revision, "--", *selected)
    sources = {}
    with tarfile.open(fileobj=io.BytesIO(snapshot), mode="r:") as archive:
        for member in archive:
            if member.isfile():
                sources[member.name] = archive.extractfile(member).read()
                package.add("source/" + member.name, sources[member.name], f"git:{revision}:{member.name}")
    require(set(sources) == set(selected), "source archive selection differs")
    for name, expected in build["source_sha256"].items():
        require(name in sources and digest(sources[name]) == expected, f"compiled source differs from commit: {name}")
    for record in records.values():
        for name, expected in record["sources"].items():
            if name.startswith(("inventory_reconciliation/", "incremental_planner/")):
                require(digest(sources["examples/" + name]) == expected, f"measured application source differs from commit: {name}")
    return sources


def add_validation(package, revision, tool_hashes, sources):
    expected_suites = {
        ("final", "ordinary"): {"classes", "exceptions", "comprehensions", "imports", "io", "differential"},
        ("final", "asan"): {"classes", "exceptions", "comprehensions", "imports", "io", "differential"},
        ("final", "thinlto"): {"classes", "exceptions", "comprehensions", "imports", "io", "differential", "containers", "files"},
        ("dev3b", "ordinary"): {"containers", "files"},
        ("dev3b", "asan"): {"containers", "files"},
    }
    for (stage, mode), suites in expected_suites.items():
        directory = LOCAL / f"inventory-performance-validation-{stage}" / mode
        record = load(directory / "results.json")
        require(record["passed"] is True and record["inputs_unchanged"] is True and set(record["results"]) == suites, f"incomplete validation: {stage}:{mode}")
        require(record["compiler"]["sha256"] == tool_hashes["relar"], "validated compiler identity differs")
        runtime = {"ordinary": "librelar_runtime.a", "thinlto": "librelar_runtime_lto.a", "asan": "librelar_runtime_asan.a"}[mode]
        require(record["runtime"]["sha256"] == tool_hashes[runtime], "validated runtime identity differs")
        if stage == "final":
            require(record["head"] == revision and not record["git_status"], "final validation source identity differs")
        for name, expected in record["test_sources"].items():
            require(digest(sources[name]) == expected, f"validated test differs from measured commit: {name}")
        for result in record["results"].values():
            require(result["returncode"] == 0, "native suite failed")
            for stream in ("stdout", "stderr"):
                require(digest(Path(result[stream]["path"]).read_bytes()) == result[stream]["sha256"], "native suite log changed")
        runner = Path(record["runner"]["path"])
        require(digest(runner.read_bytes()) == record["runner"]["sha256"], "validation runner changed")
    for stage in ("final", "dev3b"):
        package.tree(LOCAL / f"inventory-performance-validation-{stage}", f"validation/{stage}")
    extra_runner = Path("/tmp/relar-inventory-final-extra-validation.py")
    for name in ("lto-cli", "inventory-asan"):
        record = load(LOCAL / "inventory-performance-validation-final" / name / "record.json")
        require(record["status"] == "passed" and record["head"] == revision, f"extra validation incomplete: {name}")
        require(record["runner_sha256"] == digest(extra_runner.read_bytes()), "extra-check runner changed")
    require((LOCAL / "inventory-performance-validation-final/inventory-asan/oracle.json").is_file(), "ASan inventory oracle record missing")
    package.file(Path("/tmp/relar-inventory-performance-validation.py"), "commands/native-validation.py")
    package.file(extra_runner, "commands/extra-validation.py")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=LOCAL / "inventory-performance-publication-stage")
    parser.add_argument("--prefix", default="2026-10-18-inventory-performance")
    parser.add_argument("--report", type=Path, default=LOCAL / "inventory-performance-report.md")
    args = parser.parse_args()
    destination = args.output.resolve()
    require(destination.is_relative_to(LOCAL.resolve()) and not destination.exists(), "output must be a new ignored benchmarks/local directory")
    require(re.fullmatch(r"[A-Za-z0-9_-]+", args.prefix), "prefix must be a simple filename component")
    require(args.report.is_file(), "final report draft is missing")
    session_path = LOCAL / "inventory-performance-final-session.json"
    session = load(session_path)
    build_path = LOCAL / "inventory-performance-tools-final/build-record.json"
    build = load(build_path)
    reused = load(LOCAL / "inventory-performance-tools-dev3b/build-record.json")
    revision = session["source_commit"]
    require(re.fullmatch(r"[0-9a-f]{40}", revision), "invalid measured source commit")
    require(session.get("completed_at_utc") and not session["git_status_before"] and not session["git_status_after"], "final timing session is incomplete or dirty")
    require(session["before"]["build_record_sha256"] == digest(build_path.read_bytes()), "timing/build identity differs")
    tool_hashes = validate_build(build, reused, revision)
    records = {mode: load(LOCAL / f"inventory-performance-{mode}-final.json") for mode in MODES}
    for mode, record in records.items():
        require(record["git"] == {"revision": revision, "dirty": False}, "timing source differs from measured commit")
        require(session["runs"][mode]["returncode"] == 0 and session["runs"][mode]["record_sha256"] == digest((LOCAL / f"inventory-performance-{mode}-final.json").read_bytes()), "timing session record identity differs")
    for name in ("audit", "validation"):
        require(load(LOCAL / f"inventory-performance-final-{name}.json")["status"] == "passed", f"final {name} is missing or unsuccessful")
    profile_audit = load(LOCAL / "inventory-performance-final-profile-audit.json")
    require(profile_audit["audit_script"]["sha256"] == digest((LOCAL / "inventory-performance-final-profile-audit.py").read_bytes()), "profile audit script changed")
    require(set(profile_audit["modes"]) == set(MODES), "final profile audit is incomplete")
    profile_audit_run = load(LOCAL / "inventory-performance-final-profile-audit-run.json")
    require(profile_audit_run["returncode"] == 0 and profile_audit_run["output_sha256"] == digest((LOCAL / "inventory-performance-final-profile-audit.json").read_bytes()), "profile audit execution record differs")
    require(profile_audit_run["log_sha256"] == digest((LOCAL / "inventory-performance-final-profile-audit.log").read_bytes()), "profile audit log changed")
    for mode in MODES:
        require(profile_audit["modes"][mode]["timing_record"]["sha256"] == session["runs"][mode]["record_sha256"], "profile/timing join differs")
    outer_profiles = load(LOCAL / "inventory-performance-final-profiling.json")
    require(outer_profiles["status"] == "passed", "final profile driver did not complete")
    require(outer_profiles["runner_sha256"] == digest((LOCAL / "inventory-performance-final-profiling.py").read_bytes()), "profile launcher changed")
    for mode in MODES:
        require(outer_profiles["runs"][mode]["returncode"] == 0 and outer_profiles["runs"][mode]["record_sha256"] == session["runs"][mode]["record_sha256"], "outer profile status/identity differs")
    package = Package()
    sources = add_source_snapshot(package, revision, build, records)
    add_validation(package, revision, tool_hashes, sources)
    for stage in ("final", "dev3b"):
        frozen = build if stage == "final" else reused
        for name, step in frozen["commands"].items():
            require(digest((LOCAL / f"inventory-performance-tools-{stage}" / (name + ".log")).read_bytes()) == step["log_sha256"], "frozen build log changed")
        for name in ("build-record.json", "ordinary.log", "thinlto.log", "asan.log"):
            package.file(LOCAL / f"inventory-performance-tools-{stage}" / name, f"build/relar-{stage}/{name}")
    for name in ("inventory-performance-dev3b-unit.log", "inventory-performance-dev3b-clippy.log", "inventory-performance-tools-final-build.log", "inventory-performance-tools-dev3b-build.log", "inventory-performance-final-ordinary.log", "inventory-performance-final-thinlto.log", "inventory-performance-final-asan.log", "inventory-performance-dev3b-ordinary.log", "inventory-performance-dev3b-asan.log"):
        package.file(LOCAL / name, "validation/driver-logs/" + name)
    for mode in MODES:
        package.file(LOCAL / f"inventory-reference-final-{mode}/build-record.json", f"build/rust-{mode}/build-record.json")
        package.file(LOCAL / f"inventory-performance-{mode}-final.log", f"timing/{mode}.log")
        profile_log = LOCAL / f"inventory-performance-final-profile-{mode}.log"
        require(digest(profile_log.read_bytes()) == outer_profiles["runs"][mode]["log_sha256"], "outer profile log changed")
        package.file(profile_log, f"profiles/{mode}-driver.log")
        record = records[mode]
        for name, command in record["method"]["compile_commands"].items():
            path = Path(command[command.index("--emit-llvm") + 1])
            require(digest(path.read_bytes()) == record["sha256"][name + "_ir"], "generated IR hash differs")
            package.file(path, f"generated/{mode}/{name}.ll")
        for group, directory in (("baseline", f"inventory-profile-baseline-{mode}"), ("final", f"inventory-performance-final-profile-{mode}")):
            package.sealed_tree(LOCAL / directory, f"profiles/{group}-{mode}")
        old = load(LOCAL / f"inventory-{mode}-final.json")
        for name, command in old["method"]["compile_commands"].items():
            path = Path(command[command.index("--emit-llvm") + 1])
            require(digest(path.read_bytes()) == old["sha256"][name + "_ir"], "preserved generated IR hash differs")
            package.file(path, f"generated/preserved-{mode}/{name}.ll")
        package.file(LOCAL / f"layout-{mode}-final/incremental_planner.ll", f"generated/control-baseline-{mode}/incremental_planner.ll")
    package.file(LOCAL / "inventory-reference-final-freeze.json", "build/rust-reference-freeze.json")
    for name in ("inventory-performance-final-audit.py", "inventory-performance-final-audit.json", "inventory-performance-final-audit.md", "inventory-performance-final-validation.py", "inventory-performance-final-validation.json", "inventory-performance-final-profile-audit.py", "inventory-performance-final-profile-audit.json", "inventory-performance-final-profile-audit.log", "inventory-performance-final-profile-audit-run.json", "inventory-performance-harness-checks.py", "inventory-performance-harness-checks.json", "inventory-performance-profile-path-checks.py", "inventory-performance-profile-path-checks.json"):
        package.file(LOCAL / name, "audit/" + name)
    package.file(session_path, "timing/session.json")
    launcher = LOCAL / "inventory-performance-final-launch.py"
    require(digest(launcher.read_bytes()) == session["launcher_sha256"], "timing launcher changed")
    package.file(launcher, "commands/timing-launch.py")
    package.file(LOCAL / "inventory-performance-final-profiling.py", "commands/profile-launch.py")
    package.file(LOCAL / "inventory-performance-final-profiling.json", "profiles/driver-record.json")
    for name in ("inventory-performance-fill-report.py", "inventory-performance-report-template.md"):
        package.file(LOCAL / name, "commands/report/" + name)
    package.add("commands/report/README.md", (
        "# Report renderer\n\n"
        "The retained renderer expects its input audits beside the script. Copy "
        "`../../audit/inventory-performance-final-audit.json` and "
        "`../../audit/inventory-performance-final-profile-audit.json` into this "
        "directory, then run `python3 inventory-performance-fill-report.py`. "
        "It writes `inventory-performance-report.md`. The original source and "
        "template are preserved without path rewrites.\n"
    ).encode(), "packaging reproduction instructions")
    package.add("commands/build-tools.py", build["build_script"].encode(), "embedded frozen build record")
    package.add("commands/cargo.sh", build["cargo_wrapper"].encode(), "embedded frozen build record")
    package.file(Path(__file__), "commands/package-evidence.py")
    package.sealed_tree(LOCAL / "inventory-performance-sanitizer-o0-diagnosis", "diagnosis/sanitizer-o0")

    # Nothing is written until every required record and source is present.
    companions = {}
    for mode in MODES:
        companions[f"{args.prefix}-{mode}.json.gz"] = compressed((LOCAL / f"inventory-performance-{mode}-final.json").read_bytes())
    for suffix, path in (
        ("build.json", build_path),
        ("audit.json", LOCAL / "inventory-performance-final-audit.json"),
        ("validation.json", LOCAL / "inventory-performance-final-validation.json"),
        ("profiles.json", LOCAL / "inventory-performance-final-profile-audit.json"),
    ):
        companions[f"{args.prefix}-{suffix}"] = path.read_bytes()
    companions[f"{args.prefix}.md"] = args.report.read_bytes()
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(package.payloads.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            member.mtime = member.uid = member.gid = 0
            member.uname = member.gname = ""
            archive.addfile(member, io.BytesIO(data))
    archive_name = f"{args.prefix}-evidence.tar.gz"
    archive_data = compressed(tar_buffer.getvalue())
    companion_info = {}
    for name, data in companions.items():
        info = {"sha256": digest(data), "bytes": len(data)}
        if name.endswith(".json.gz"):
            info["decompressed_sha256"] = digest(gzip.decompress(data))
        companion_info[name] = info
    external_controls = {}
    for mode in MODES:
        name = f"2026-10-18-concrete-layouts-{mode}.json.gz"
        data = (ROOT / "benchmarks/results" / name).read_bytes()
        raw = (LOCAL / f"layout-{mode}-final.json").read_bytes()
        require(gzip.decompress(data) == raw, "published control record differs from retained bytes")
        external_controls[name] = {"sha256": digest(data), "decompressed_sha256": digest(raw), "role": "Previously published source/build provenance for unchanged incremental control executables."}
    manifest = {
        "schema_version": 1,
        "measured_source_commit": revision,
        "source_snapshot_file_count": len(sources),
        "timing_session_completed_at_utc": session["completed_at_utc"],
        "archive": {"file": archive_name, "sha256": digest(archive_data), "bytes": len(archive_data), "member_count": len(package.members)},
        "members": dict(sorted(package.members.items())),
        "companion_files": dict(sorted(companion_info.items())),
        "excluded_native_artifacts": dict(sorted(package.excluded.items())),
        "external_control_records": external_controls,
        "scope": [
            "Source snapshots come from the measured commit recorded by the final build and timing session, independently of the later documentation checkout.",
            "Reused dev3b validation retains its original dirty-worktree metadata; its compiled sources and all compiler/runtime artifact hashes match the clean final build exactly.",
            "Final and reused validation logs/records, baseline/final raw traces, complete retained profile files, generated LLVM, exact command records and audit source/results are included.",
            "Native binaries, runtime archives, interpreter binaries and toolchains are excluded. Their original paths and hashes remain in frozen records and audits; excluded files encountered in validation trees are also indexed here.",
            "Raw final timing JSON is separately gzip-compressed without byte changes. The profile and timing audits retain their measurement limitations; instrumented elapsed times are not performance results.",
            "Tar members are sorted with mode0644, uid/gid/mtime0 and empty owner names. Gzip filename is empty and mtime0. The manifest uses the recorded session completion time, not packaging wall time.",
            "Audits requiring executable/toolchain bytes need the external frozen local paths. Published raw timing/trace/source bytes support statistical recomputation, trace parsing and hash verification without those binaries.",
        ],
    }
    destination.mkdir(parents=True, exist_ok=False)
    for name, data in companions.items():
        (destination / name).write_bytes(data)
    (destination / archive_name).write_bytes(archive_data)
    manifest_path = destination / f"{args.prefix}-evidence-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode="r:gz") as archive:
        members = archive.getmembers()
        require(len(members) == len(package.members), "archive member count changed")
        for member in members:
            data = archive.extractfile(member).read()
            require(digest(data) == package.members[member.name]["sha256"], "archive extraction hash differs")
            require(member.isfile() and member.mode == 0o644 and member.uid == member.gid == member.mtime == 0 and member.uname == member.gname == "", "archive metadata is not normalized")
    print(json.dumps({"output": source_name(destination), "archive": manifest["archive"], "manifest_sha256": digest(manifest_path.read_bytes()), "companion_count": len(companions)}, indent=2))


if __name__ == "__main__":
    main()
