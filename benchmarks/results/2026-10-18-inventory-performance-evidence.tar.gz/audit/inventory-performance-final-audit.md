| Mode | Inventory workload | CPython ms | Preserved Relar ms | Current Relar ms | Rust BigInt ms | Baseline / Relar | CPython / Relar | Relar / Rust |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| normal | empty | 26.911 | 2.250 | 2.221 | 2.266 | 1.013x | 12.115x | 0.980x |
| normal | boundary-128 | 28.182 | 3.087 | 2.863 | 2.754 | 1.078x | 9.845x | 1.039x |
| normal | dense-2048 | 33.919 | 8.275 | 6.596 | 6.077 | 1.255x | 5.142x | 1.085x |
| normal | sparse-2048 | 38.067 | 13.018 | 9.578 | 8.812 | 1.359x | 3.974x | 1.087x |
| normal | dense-16384 | 74.821 | 43.193 | 27.644 | 23.832 | 1.562x | 2.707x | 1.160x |
| normal | sparse-16384 | 107.831 | 77.122 | 51.918 | 43.736 | 1.485x | 2.077x | 1.187x |
| lto | empty | 26.924 | 2.261 | 2.211 | 2.336 | 1.023x | 12.180x | 0.946x |
| lto | boundary-128 | 27.868 | 2.928 | 2.804 | 2.722 | 1.044x | 9.937x | 1.030x |
| lto | dense-2048 | 32.664 | 7.056 | 5.633 | 5.606 | 1.253x | 5.799x | 1.005x |
| lto | sparse-2048 | 36.232 | 10.084 | 7.840 | 7.695 | 1.286x | 4.622x | 1.019x |
| lto | dense-16384 | 73.016 | 32.671 | 21.697 | 20.710 | 1.506x | 3.365x | 1.048x |
| lto | sparse-16384 | 106.178 | 59.335 | 42.125 | 38.354 | 1.409x | 2.521x | 1.098x |

| Mode | Unchanged control | Baseline ms | Current ms | Current time change |
|---|---|---:|---:|---:|
| normal | layered-16384-sparse | 49.433 | 49.674 | +0.487% |
| normal | layered-16384-all | 75.670 | 75.866 | +0.259% |
| normal | wide-16384-sparse | 26.766 | 27.005 | +0.891% |
| normal | wide-16384-all | 45.262 | 45.530 | +0.592% |
| normal | boundary-128-all | 3.678 | 3.601 | -2.089% |
| lto | layered-16384-sparse | 43.136 | 43.088 | -0.113% |
| lto | layered-16384-all | 63.988 | 64.083 | +0.148% |
| lto | wide-16384-sparse | 21.430 | 21.481 | +0.238% |
| lto | wide-16384-all | 36.806 | 37.188 | +1.040% |
| lto | boundary-128-all | 3.478 | 3.467 | -0.315% |
