"""Audit saved inventory comparisons without running benchmarks or compilers.

Statistics are independently interpolated from integer nanoseconds. Only the
hashed independent validators are imported; no production statistics helper is.
"""

import argparse
import base64
import hashlib
import itertools
import json
import math
import runpy
import struct
import subprocess
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

APPLICATION = None
ENGINES = {
    "inventory": ("cpython", "relar", "rust_bigint", "baseline"),
    "control": ("cpython", "baseline", "relar"),
}
COUNTS = {"inventory": 6, "control": 5}
CHECKS = 0
FILES = {}


def require(condition, message):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise AssertionError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_info(path):
    path = Path(path).resolve(strict=True)
    stat = path.stat()
    signature = (stat.st_size, stat.st_mtime_ns)
    if path not in FILES:
        with path.open("rb") as stream:
            FILES[path] = signature, hashlib.file_digest(stream, "sha256").hexdigest()
    require(FILES[path][0] == signature, f"file changed during audit: {path}")
    return {"sha256": FILES[path][1], "bytes": signature[0]}


def verify_file(path, expected, size=None):
    result = file_info(path)
    require(result["sha256"] == expected, f"file hash differs: {path}")
    if size is not None:
        require(result["bytes"] == size, f"file size differs: {path}")
    return result


def verify_committed(root, revision, hashes):
    names = list(hashes)
    data = subprocess.run(
        ["git", "-C", str(root), "cat-file", "--batch"],
        input="".join(f"{revision}:{name}\n" for name in names).encode(),
        capture_output=True,
        check=True,
    ).stdout
    offset = 0
    for name in names:
        end = data.index(b"\n", offset)
        header = data[offset:end].split()
        require(
            len(header) == 3 and header[1] == b"blob",
            f"missing committed file: {revision}:{name}",
        )
        length = int(header[2])
        offset = end + 1
        require(
            digest(data[offset : offset + length]) == hashes[name],
            f"committed source differs: {revision}:{name}",
        )
        offset += length
        require(data[offset : offset + 1] == b"\n", "invalid Git batch delimiter")
        offset += 1
    require(offset == len(data), "unexpected Git batch remainder")


def decode_files(encoded):
    result = {}
    for name, spec in encoded.items():
        data = base64.b64decode(spec["base64"], validate=True)
        require(
            digest(data) == spec["sha256"] and len(data) == spec["bytes"],
            "encoded file differs: " + name,
        )
        result[name] = data
    return result


def inventory(files):
    return {
        name: {"sha256": digest(data), "bytes": len(data)}
        for name, data in sorted(files.items())
    }


def result_matches(result, expected, label):
    output = expected["stdout"].encode()
    require(result["returncode"] == expected["returncode"], label + ": status")
    require(
        result["stdout_sha256"] == digest(output)
        and result["stdout_bytes"] == len(output),
        label + ": full stdout identity",
    )
    if expected.get("error_category") is None:
        require(result["stderr"] == "", label + ": unexpected stderr")
    else:
        lines = result["stderr"].strip().splitlines()
        category = expected["error_category"]
        require(
            bool(lines)
            and (lines[-1] == category or lines[-1].startswith(category + ":")),
            label + ": error category",
        )
        if expected.get("error_message") is not None:
            require(
                lines[-1] == category + ": " + expected["error_message"],
                label + ": normalized error message",
            )
    if "files" in expected:
        require(
            result["files"] == inventory(expected["files"]),
            label + ": complete file inventory",
        )
        require(
            result["directories"] == expected["directories"],
            label + ": complete directory inventory",
        )


def quantile(values, numerator, denominator):
    ordered = sorted(values)
    position = Fraction((len(ordered) - 1) * numerator, denominator)
    left = position.numerator // position.denominator
    right = min(left + 1, len(ordered) - 1)
    return Fraction(ordered[left]) + (ordered[right] - ordered[left]) * (
        position - left
    )


def statistics(values):
    return {
        "median_ns": float(quantile(values, 1, 2)),
        "min_ns": min(values),
        "max_ns": max(values),
        "p25_ns": float(quantile(values, 1, 4)),
        "p75_ns": float(quantile(values, 3, 4)),
    }


def close(actual, expected, label):
    require(math.isclose(actual, expected, rel_tol=2e-13, abs_tol=1e-12), label)


def flag(command, name):
    return command[command.index(name) + 1]


def path_at(root, value):
    value = Path(value)
    return value if value.is_absolute() else root / value


def artifact_identities(root, mode, record, session):
    run = session["runs"][mode]
    command = run["command"]
    paths = {
        name: path_at(root, flag(command, option))
        for name, option in (
            ("compiler", "--compiler"),
            ("runtime", "--runtime"),
            ("relar_build_record", "--relar-build-record"),
            ("rust_bigint", "--rust-bigint"),
            ("rust_record", "--rust-build-record"),
            ("baseline", "--baseline"),
            ("baseline_record", "--baseline-record"),
            ("python", "--python"),
            ("inventory_baseline", "--inventory-baseline"),
            ("inventory_baseline_record", "--inventory-baseline-record"),
        )
    }
    paths["rust_build_script"] = paths["tracked_rust_build_script"] = (
        root / "benchmarks/reference/inventory_reconciliation/build.py"
    )
    paths["guard_helpers"] = (
        root / "benchmarks/reference/dependency_planner/check_boundaries.py"
    )
    source_hashes = record["relar_build_provenance"]["source_sha256"]
    for group, compiler_command in record["method"]["compile_commands"].items():
        require(
            compiler_command[0] == str(paths["compiler"])
            and compiler_command[1] == "build",
            "compiler command identity",
        )
        paths[group + "_binary"] = Path(flag(compiler_command, "-o"))
        paths[group + "_ir"] = Path(flag(compiler_command, "--emit-llvm"))
        paths["clang"] = Path(flag(compiler_command, "--clang"))
        require(
            flag(compiler_command, "--runtime") == str(paths["runtime"]),
            "runtime pairing",
        )
        require(
            flag(compiler_command, "--opt-level") == "3"
            and flag(compiler_command, "--target") == "x86_64-unknown-linux-gnu",
            "application build mode",
        )
        require(
            "--sanitize" not in compiler_command, "sanitizer in measured application"
        )
        if mode == "lto":
            paths["lto_linker"] = Path(flag(compiler_command, "--lto-linker"))
            require(paths["lto_linker"].name == "ld.lld", "lexical linker flavor")
        else:
            require(
                "--lto-linker" not in compiler_command, "LTO in ordinary application"
            )
        require(
            record["compilation"][group]["returncode"] == 0
            and record["compilation"][group]["stderr"] == "",
            "application compilation failed",
        )
    committed = {}
    for name, expected in record["sha256"].items():
        if name.startswith("harness:"):
            paths[name] = root / "benchmarks" / name.split(":", 1)[1]
        if name.startswith("relar_source:"):
            relative = name.split(":", 1)[1]
            paths[name] = root / relative
            require(
                source_hashes[relative] == expected, "compiled source identity field"
            )
        require(name in paths, "unmapped artifact: " + name)
        verify_file(paths[name], expected)
        if name.startswith(("harness:", "relar_source:")) or name in (
            "guard_helpers",
            "tracked_rust_build_script",
        ):
            committed[str(paths[name].relative_to(root))] = expected
    verify_committed(root, APPLICATION, committed)
    for name, spec in record["artifacts"].items():
        require(
            file_info(paths[name])["bytes"] == spec["bytes"],
            "artifact recorded length: " + name,
        )
    for name, expected in record["sources"].items():
        verify_file(root / "examples" / name, expected)
    verify_committed(
        root,
        APPLICATION,
        {"examples/" + name: value for name, value in record["sources"].items()},
    )
    full_build = json.loads(paths["relar_build_record"].read_text())
    for key, value in record["relar_build_provenance"].items():
        require(full_build[key] == value, "embedded Relar build provenance: " + key)
    require(
        full_build["compiled_sources_match_commit"] is True,
        "compiler source commit guard",
    )
    verify_committed(root, APPLICATION, source_hashes)
    require(
        set(full_build["source_contents"]) == set(source_hashes),
        "compiler source snapshot coverage",
    )
    for name, content in full_build["source_contents"].items():
        require(
            digest(content.encode()) == source_hashes[name],
            "compiler source snapshot bytes",
        )
    for name, expected in full_build["sha256"].items():
        verify_file(root / name, expected)
    for name, build in full_build["commands"].items():
        require(build["returncode"] == 0, "runtime/compiler build failure")
        verify_file(
            paths["relar_build_record"].parent / (name + ".log"), build["log_sha256"]
        )
    require(
        full_build["runtime_lto_rustflags"] == "-Clinker-plugin-lto",
        "runtime ThinLTO flags",
    )
    baseline = json.loads(paths["baseline_record"].read_text())
    for key, value in record["baseline_provenance"].items():
        require(baseline[key] == value, "embedded baseline provenance: " + key)
    require(baseline["git"]["dirty"] is False, "baseline timing checkout dirty")
    require(
        baseline["sha256"]["incremental_binary"] == record["sha256"]["baseline"],
        "baseline exact executable",
    )
    require(
        {
            n: v
            for n, v in baseline["sources"].items()
            if n.startswith("incremental_planner/")
        }
        == {
            n: v
            for n, v in record["sources"].items()
            if n.startswith("incremental_planner/")
        },
        "unchanged control sources",
    )
    for key in ("lto", "llvm_budget", "target", "optimization_level"):
        require(
            baseline["options"][key] == record["options"][key],
            "baseline build mode: " + key,
        )
    for key in ("clang", "lto_linker"):
        if key in record["sha256"]:
            require(
                baseline["sha256"][key] == record["sha256"][key],
                "baseline tool mismatch: " + key,
            )
    original_inventory = json.loads(paths["inventory_baseline_record"].read_text())
    for key, value in record["inventory_baseline_provenance"].items():
        require(
            original_inventory[key] == value,
            "embedded inventory baseline provenance: " + key,
        )
    require(
        original_inventory["git"]["dirty"] is False,
        "original inventory timing checkout dirty",
    )
    require(
        original_inventory["sha256"]["inventory_binary"]
        == record["sha256"]["inventory_baseline"],
        "inventory baseline exact executable",
    )
    require(
        {
            n: v
            for n, v in original_inventory["sources"].items()
            if n.startswith("inventory_reconciliation/")
        }
        == {
            n: v
            for n, v in record["sources"].items()
            if n.startswith("inventory_reconciliation/")
        },
        "unchanged inventory sources",
    )
    for key in ("lto", "llvm_budget", "target", "optimization_level"):
        require(
            original_inventory["options"][key] == record["options"][key],
            "inventory baseline build mode: " + key,
        )
    for key in ("clang", "lto_linker"):
        if key in record["sha256"]:
            require(
                original_inventory["sha256"][key] == record["sha256"][key],
                "inventory baseline tool mismatch: " + key,
            )
    old_command = original_inventory["method"]["compile_commands"]["inventory"]
    for key, path in (
        ("compiler", old_command[0]),
        ("runtime", flag(old_command, "--runtime")),
        ("inventory_ir", flag(old_command, "--emit-llvm")),
    ):
        verify_file(path_at(root, path), original_inventory["sha256"][key])
    old_sources = {
        "examples/" + name: value
        for name, value in original_inventory["sources"].items()
    }
    old_sources.update(
        {
            "benchmarks/" + name.split(":", 1)[1]: value
            for name, value in original_inventory["sha256"].items()
            if name.startswith("harness:")
        }
    )
    verify_committed(root, original_inventory["git"]["revision"], old_sources)
    rust = json.loads(paths["rust_record"].read_text())
    require(
        rust == record["rust_build_record"] and rust["entrypoint"] == "inventory",
        "Rust build identity",
    )
    require(
        rust["binaries"]["bigint"]["sha256"] == record["sha256"]["rust_bigint"],
        "Rust executable identity",
    )
    require(rust["sources"] == record["rust_sources"], "Rust source identity")
    require(
        set(rust["source_contents"]) == set(rust["sources"]),
        "Rust source snapshot coverage",
    )
    for name, expected in rust["sources"].items():
        verify_file(
            root / "benchmarks/reference/inventory_reconciliation" / name, expected
        )
        require(
            digest(rust["source_contents"][name].encode()) == expected,
            "Rust source snapshot",
        )
    verify_committed(
        root,
        APPLICATION,
        {
            "benchmarks/reference/inventory_reconciliation/" + name: value
            for name, value in rust["sources"].items()
        },
    )
    require(
        digest(rust["build_script"].encode())
        == rust["build_script_sha256"]
        == record["sha256"]["rust_build_script"],
        "Rust build helper snapshot",
    )
    require(
        digest(rust["cargo_wrapper"]["source"].encode())
        == rust["cargo_wrapper"]["sha256"],
        "Rust wrapper snapshot",
    )
    env = rust["environment"]
    thin = mode == "lto"
    require(
        env.get("CARGO_PROFILE_RELEASE_OPT_LEVEL", "3") == "3",
        "Rust release optimization",
    )
    require(rust["llvm_budget"] == (1000 if thin else None), "Rust LLVM budget")
    require(
        env.get("CARGO_PROFILE_RELEASE_LTO") == ("thin" if thin else None),
        "Rust LTO mode",
    )
    require(
        env.get("CARGO_ENCODED_RUSTFLAGS") == (None if thin else ""),
        "Rust encoded flags",
    )
    require(
        env["RUSTFLAGS"]
        == (
            "-Cllvm-args=-import-instr-limit=1000 -Cllvm-args=-inline-threshold=1000"
            if thin
            else ""
        ),
        "Rust explicit flags",
    )
    require("host: x86_64-unknown-linux-gnu" in rust["rustc_verbose"], "Rust target")
    require(
        rust["sources"]["Cargo.toml"]
        == digest(
            (
                root / "benchmarks/reference/inventory_reconciliation/Cargo.toml"
            ).read_bytes()
        ),
        "Rust profile source",
    )
    for group, engines in ENGINES.items():
        commands = record["method"]["commands"][group]
        require(tuple(commands) == engines, "engine command ordering")
        require(
            commands["cpython"][0] == str(paths["python"])
            and commands["cpython"][1:3] == ["-I", "-c"],
            "CPython isolation command",
        )
        require(
            commands["relar"] == [str(paths[group + "_binary"])],
            "Relar executable command",
        )
        if group == "inventory":
            require(
                commands["rust_bigint"] == [str(paths["rust_bigint"])],
                "Rust executable command",
            )
            require(
                commands["baseline"] == [str(paths["inventory_baseline"])],
                "inventory baseline executable command",
            )
        else:
            require(
                commands["baseline"] == [str(paths["baseline"])],
                "control executable command",
            )
    return paths, baseline, original_inventory


def correctness(record, validator):
    inv = record["validation"]["inventory"]
    inc = validator["files"].batch.incremental
    expected_cases = validator["cases"]()
    require(
        inv["cases"] == len(inv["records"]) == len(expected_cases) == 176,
        "inventory oracle count",
    )
    require(
        inv["engines"] == list(ENGINES["inventory"]), "inventory validation engines"
    )
    success = 0
    for item, case in zip(inv["records"], expected_cases):
        require(
            item["case"] == validator["case_record"](case),
            "inventory oracle captured case",
        )
        expected = validator["oracle"](case)
        success += expected["returncode"] == 0
        require(
            item["expected"] == {k: v for k, v in expected.items() if k != "files"},
            "inventory expected status/output",
        )
        require(
            decode_files(item["expected_files"]) == expected["files"],
            "inventory oracle expected file bytes",
        )
        require(
            set(item["engines"]) == set(ENGINES["inventory"]),
            "inventory oracle result coverage",
        )
        for engine, result in item["engines"].items():
            result_matches(
                result, expected, "inventory oracle/" + case.label + "/" + engine
            )
    require(
        success == inv["successful"] == 127 and inv["terminal_errors"] == 49,
        "inventory oracle totals",
    )
    device = inv["device_check"]
    require(
        device["case"] == "terminal-report-device-error"
        and set(device["engines"]) == set(ENGINES["inventory"]),
        "device coverage",
    )
    device_case = validator["case"](
        "terminal-report-device-error", [("a", 4)], [[("a", 2)]]
    )
    expected = {
        "returncode": 1,
        "stdout": "",
        "error_category": "OSError",
        "error_message": "report: cannot write",
        "files": device_case.files,
        "directories": [],
    }
    for engine, result in device["engines"].items():
        result_matches(result, expected, "device/" + engine)
    control = record["validation"]["control"]
    cases = inc.cases()
    require(
        control["oracle_cases"] == len(control["checks"]) == len(cases) == 155,
        "control oracle count",
    )
    require(
        control["passed_by_engine"] == dict.fromkeys(ENGINES["control"], 155),
        "control oracle totals",
    )
    for item, case in zip(control["checks"], cases):
        oracle = inc.oracle(case.tasks, case.changes)
        require(
            item["case"] == case.label
            and item["input"]
            == (case.stdin_override or inc.input_text(case.tasks, case.changes)),
            "control oracle inputs",
        )
        require(item["expected_stdout"] == oracle["output"], "control oracle output")
        require(
            set(item["results"]) == set(ENGINES["control"]), "control oracle engines"
        )
        for engine, result in item["results"].items():
            result_matches(
                result,
                {"stdout": oracle["output"], "returncode": 0},
                "control oracle/" + case.label + "/" + engine,
            )
    parser = inc.parser_cases()
    require(
        control["parser_cases"] == len(control["parser_checks"]) == len(parser) == 17,
        "parser case count",
    )
    require(
        control["parser_passed_by_engine"] == dict.fromkeys(ENGINES["control"], 17),
        "parser totals",
    )
    for item, (label, source, category, output) in zip(
        control["parser_checks"], parser
    ):
        require(
            item["case"] == label
            and item["input"] == source
            and item["expected_stdout"] == output
            and item["expected_error_category"] == category,
            "parser captured expectations",
        )
        require(
            item["expected_returncode"] == int(category is not None),
            "parser status expectation",
        )
        require(
            set(item["results"]) == set(ENGINES["control"]), "parser engine coverage"
        )
        for engine, result in item["results"].items():
            result_matches(
                result,
                {
                    "stdout": output,
                    "returncode": int(category is not None),
                    "error_category": category,
                },
                "parser/" + label + "/" + engine,
            )
    return {
        "inventory": 176 * len(ENGINES["inventory"]),
        "inventory_device": len(ENGINES["inventory"]),
        "control_graph": 155 * len(ENGINES["control"]),
        "control_parser": 17 * len(ENGINES["control"]),
    }


def audit_mode(root, mode, session, validator):
    path = root / f"benchmarks/local/inventory-performance-{mode}-final.json"
    record = json.loads(path.read_text())
    run = session["runs"][mode]
    verify_file(path, run["record_sha256"])
    verify_file(path.with_suffix(".log"), run["log_sha256"])
    require(run["returncode"] == 0, "timing harness failed")
    require(
        run["started_at_utc"]
        <= record["started_at_utc"]
        <= record["completed_at_utc"]
        <= run["completed_at_utc"],
        "record is outside its session interval",
    )
    require(
        record["git"] == {"revision": APPLICATION, "dirty": False},
        "timing source identity",
    )
    require(record["example"] == "inventory_reconciliation", "comparison example")
    options = record["options"]
    thin = mode == "lto"
    require(
        options["samples"] == 48
        and options["warmups"] == 2
        and options["validation_only"] is False,
        "sample settings",
    )
    require(
        options["optimization_level"] == 3
        and options["target"]
        == options["requested_target"]
        == "x86_64-unknown-linux-gnu",
        "target/optimization settings",
    )
    require(
        options["lto"] == ("thin" if thin else None)
        and options["llvm_budget"] == (1000 if thin else None),
        "LTO settings",
    )
    contexts = record["execution"]
    require(
        set(contexts) == {"before", "before_samples", "after"},
        "tracing checkpoint coverage",
    )
    require(
        contexts["before"] == contexts["before_samples"] == contexts["after"],
        "runtime context changed",
    )
    require(contexts["before"]["tracer_pid"] == 0, "traced benchmark")
    require(
        record["host"]["cpu"]["affinity"] == [0]
        and 0 in record["host"]["cpu"]["allowed_cpus_before_pinning"],
        "CPU affinity",
    )
    require(
        record["clock"]["monotonic"]
        and not record["clock"]["adjustable"]
        and record["clock"]["resolution"] == 1e-9,
        "clock properties",
    )
    for name in ("LD_PRELOAD", "ASAN_OPTIONS", "LSAN_OPTIONS", "UBSAN_OPTIONS"):
        require(
            contexts["before"]["inherited_environment"][name] is None,
            "instrumentation environment: " + name,
        )
    python = record["tools"]["cpython"]
    require(
        python["implementation"] == "cpython" and python["version_number"] == "3.14.5",
        "CPython identity",
    )
    require(
        python["gil_enabled"]
        and not python["free_threaded_build"]
        and not python["jit_enabled"]
        and not python["debug_build"],
        "CPython execution mode",
    )
    _paths, baseline, original_inventory = artifact_identities(
        root, mode, record, session
    )
    validation = correctness(record, validator)
    rows = []
    ordering = {}
    measured = warmups = gates = 0
    baseline_workloads = {w["label"]: w for w in baseline["workloads"]["incremental"]}
    original_cases = {
        w["label"]: w for w in original_inventory["workloads"]["inventory"]
    }
    for group, engines in ENGINES.items():
        workloads = record["workloads"][group]
        require(len(workloads) == COUNTS[group], "workload count: " + group)
        cycle = [list(order) for order in itertools.permutations(engines)]
        require(
            record["method"]["order_cycles"][group] == cycle,
            "complete permutation cycle: " + group,
        )
        for workload in workloads:
            label = group + "/" + workload["label"]
            expected = {"returncode": 0, "stdout": workload["expected_stdout"]}
            if group == "inventory":
                original = original_cases[workload["label"]]
                for key in (
                    "case",
                    "expected_stdout",
                    "expected_file_inventory",
                    "expected_changed_files",
                    "stock_rows",
                    "stock_skus",
                    "batches",
                    "request_rows",
                    "positive_requests",
                ):
                    require(
                        workload[key] == original[key],
                        label + ": original captured inventory differs: " + key,
                    )
                case = validator["case_from_record"](workload["case"])
                oracle = validator["oracle"](case)
                require(
                    oracle["returncode"] == 0
                    and oracle["stdout"] == workload["expected_stdout"],
                    label + ": independent oracle",
                )
                require(
                    workload["expected_file_inventory"] == inventory(oracle["files"]),
                    label + ": expected complete inventory",
                )
                changed = {
                    name: data
                    for name, data in oracle["files"].items()
                    if case.files.get(name) != data
                }
                require(
                    decode_files(workload["expected_changed_files"]) == changed,
                    label + ": complete changed bytes",
                )
                stocks = validator["parse"](case.files["stock.txt"].decode(), "stock")
                batches = validator["parse"](
                    case.files["orders.txt"].decode(), "orders"
                )
                require(
                    workload["stock_rows"] == len(stocks)
                    and workload["stock_skus"] == len(dict(stocks))
                    and workload["batches"] == len(batches),
                    label + ": shape metadata",
                )
                require(
                    workload["request_rows"] == sum(map(len, batches))
                    and workload["positive_requests"]
                    == sum(quantity > 0 for batch in batches for _, quantity in batch),
                    label + ": request metadata",
                )
                expected.update(
                    files=oracle["files"], directories=oracle["directories"]
                )
                require(
                    set(workload["gates"]) == set(engines),
                    label + ": correctness gates",
                )
                for engine, result in workload["gates"].items():
                    result_matches(result, expected, label + "/gate/" + engine)
                    gates += 1
            else:
                original = baseline_workloads[workload["label"]]
                for key in (
                    "input",
                    "expected_stdout",
                    "targets",
                    "changed",
                    "affected",
                    "input_sha256",
                    "expected_stdout_sha256",
                    "expected_stdout_bytes",
                ):
                    require(
                        workload[key] == original[key],
                        label + ": baseline captured control differs: " + key,
                    )
                require(
                    digest(workload["input"].encode()) == workload["input_sha256"],
                    label + ": input digest",
                )
                require(
                    digest(workload["expected_stdout"].encode())
                    == workload["expected_stdout_sha256"]
                    and len(workload["expected_stdout"].encode())
                    == workload["expected_stdout_bytes"],
                    label + ": output digest",
                )
                tasks, changes = validator["files"].batch.parse_payload(
                    tuple(workload["input"].removesuffix("\n").split("\n"))
                )
                require(
                    validator["files"].batch.incremental.oracle(tasks, changes)[
                        "output"
                    ]
                    == workload["expected_stdout"],
                    label + ": independent control oracle",
                )
            positions = Counter()
            adjacent = Counter()
            orders = Counter()
            for phase, count in (("warmups", 2), ("samples", 48)):
                require(
                    len(workload[phase]) == count,
                    label + ": missing/discarded saved round",
                )
                for index, sample in enumerate(workload[phase]):
                    require(
                        sample["index"] == index
                        and sample["order"] == cycle[index % len(cycle)],
                        label + ": round order/index",
                    )
                    require(
                        set(sample) == {*engines, "index", "order"},
                        label + ": round engine coverage",
                    )
                    for engine in engines:
                        require(
                            type(sample[engine]["elapsed_ns"]) is int
                            and sample[engine]["elapsed_ns"] > 0,
                            label + ": duration",
                        )
                        result_matches(
                            sample[engine], expected, label + "/" + phase + "/" + engine
                        )
                    if phase == "samples":
                        measured += len(engines)
                        positions.update(
                            (engine, position)
                            for position, engine in enumerate(sample["order"])
                        )
                        adjacent.update(zip(sample["order"], sample["order"][1:]))
                        orders[tuple(sample["order"])] += 1
                    else:
                        warmups += len(engines)
            require(
                set(positions) == set(itertools.product(engines, range(len(engines))))
                and set(positions.values()) == {48 // len(engines)},
                label + ": position balance",
            )
            require(
                set(adjacent) == set(itertools.permutations(engines, 2))
                and set(adjacent.values()) == {48 // len(engines)},
                label + ": within-round predecessor balance",
            )
            require(
                len(orders) == len(cycle)
                and set(orders.values()) == {48 // len(cycle)},
                label + ": permutation balance",
            )
            ordering[label] = {
                "positions": {f"{a}@{b}": n for (a, b), n in sorted(positions.items())},
                "within_round_predecessors": {
                    f"{a}->{b}": n for (a, b), n in sorted(adjacent.items())
                },
                "each_permutation_count": 48 // len(cycle),
            }
            computed = {
                engine: statistics(
                    [sample[engine]["elapsed_ns"] for sample in workload["samples"]]
                )
                for engine in engines
            }
            for engine, values in computed.items():
                for key, value in values.items():
                    close(
                        workload["summary"][engine][key.replace("_ns", "_seconds")],
                        value / 1e9,
                        label + ": statistic " + engine + "/" + key,
                    )
            medians = {
                engine: values["median_ns"] for engine, values in computed.items()
            }
            ratios = {
                a + "_over_" + b: medians[a] / medians[b]
                for a, b in itertools.permutations(engines, 2)
            }
            expected_ratios = (
                set(ratios)
                if group == "inventory"
                else {
                    "cpython_over_baseline",
                    "cpython_over_relar",
                    "baseline_over_relar",
                }
            )
            require(
                set(workload["summary"]["ratios_of_medians"]) == expected_ratios,
                label + ": summary ratio coverage",
            )
            for name, reported in workload["summary"]["ratios_of_medians"].items():
                close(reported, ratios[name], label + ": ratio " + name)
            row = {
                "group": group,
                "workload": workload["label"],
                "statistics": computed,
                "median_ms": {name: value / 1e6 for name, value in medians.items()},
                "ratios_of_medians": ratios,
            }
            if group == "control":
                row["new_vs_baseline_time_change_percent"] = 100 * (
                    medians["relar"] / medians["baseline"] - 1
                )
                row["baseline_to_new_time_reduction_percent"] = 100 * (
                    1 - medians["relar"] / medians["baseline"]
                )
            rows.append(row)
    require(
        measured == (6 * 4 + 5 * 3) * 48
        and warmups == (6 * 4 + 5 * 3) * 2
        and gates == 6 * 4,
        "total process accounting",
    )
    return {
        "mode": mode,
        "record_sha256": file_info(path)["sha256"],
        "workloads": 11,
        "measured_process_runs": measured,
        "warmup_process_runs": warmups,
        "inventory_gate_runs": gates,
        "validation_process_results": validation,
        "source_commit": APPLICATION,
        "compiler_sources_verified_at_commit": APPLICATION,
        "compiler_build_git_head": record["relar_build_provenance"]["git_head"],
        "control_llvm_ir_byte_identical_to_baseline": baseline["sha256"][
            "incremental_ir"
        ]
        == record["sha256"]["control_ir"],
        "build_status_note": "Exact frozen build metadata is retained; every compiled source matches the clean measured source commit.",
        "artifact_hashes": {
            name: record["sha256"][name]
            for name in (
                "compiler",
                "runtime",
                "inventory_binary",
                "control_binary",
                "rust_bigint",
                "baseline",
                "inventory_baseline",
            )
        },
        "execution": contexts,
        "affinity": [0],
        "ordering": ordering,
        "rows": rows,
    }, record


def bytecode_session(root, session, records):
    require(
        session["source_commit"] == APPLICATION
        and not session["git_status_before"]
        and not session["git_status_after"],
        "session clean source identity",
    )
    before, after = session["bytecode_before"], session["bytecode_after"]
    require(before == after, "bytecode changed during timing")
    require(
        before["python"] == records[0]["tools"]["cpython"]["version"]
        and before["cache_tag"] == "cpython-314",
        "bytecode Python identity",
    )
    require(
        before["pycache_prefix"] is None and before["dont_write_bytecode"] is False,
        "bytecode policy",
    )
    require(
        len(before["files"]) == len(records[0]["sources"]) == 12,
        "bytecode source coverage",
    )
    for source, item in before["files"].items():
        path = Path(source)
        relative = str(path.relative_to(root / "examples"))
        require(
            item["source_sha256"] == records[0]["sources"][relative],
            "bytecode source identity",
        )
        verify_file(path, item["source_sha256"])
        require(
            path.stat().st_mtime_ns == item["source_mtime_ns"], "bytecode source mtime"
        )
        verify_file(item["cache_path"], item["cache_sha256"], item["cache_bytes"])
        data = Path(item["cache_path"]).read_bytes()
        require(data[:4].hex() == before["magic"], "bytecode magic")
        flags = int.from_bytes(data[4:8], "little")
        require(
            flags == item["flags"] == 0 and item["valid_header"] is True,
            "timestamp cache header mode",
        )
        timestamp, size = struct.unpack("<II", data[8:16])
        require(
            timestamp == ((item["source_mtime_ns"] // 1_000_000_000) & 0xFFFFFFFF)
            and size == (path.stat().st_size & 0xFFFFFFFF),
            "bytecode current source header",
        )
    require(
        session["started_at_utc"]
        <= session["runs"]["normal"]["started_at_utc"]
        <= session["runs"]["normal"]["completed_at_utc"]
        <= session["runs"]["lto"]["started_at_utc"]
        <= session["runs"]["lto"]["completed_at_utc"]
        <= session["completed_at_utc"],
        "session mode ordering",
    )
    return {
        "source_and_cache_files": 12,
        "before_after_identical": True,
        "timestamp_headers_match_sources": True,
        "python_version": before["python"],
        "cache_magic": before["magic"],
        "runner_source_sha256": digest(session["runner_source"].encode()),
    }


def main():
    global APPLICATION
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[2]
    )
    args = parser.parse_args()
    root = args.root.resolve()
    session_path = root / "benchmarks/local/inventory-performance-final-session.json"
    session = json.loads(session_path.read_text())
    initial = file_info(session_path)
    APPLICATION = session["source_commit"]
    # Verify validator transitive sources before loading them; no benchmark module is imported.
    normal = json.loads(
        (root / "benchmarks/local/inventory-performance-normal-final.json").read_text()
    )
    for name in (
        "inventory_validate.py",
        "manifest_validate.py",
        "batch_validate.py",
        "incremental_validate.py",
    ):
        verify_file(root / "benchmarks" / name, normal["sha256"]["harness:" + name])
    validator = runpy.run_path(str(root / "benchmarks/inventory_validate.py"))
    audited, records = zip(
        *(audit_mode(root, mode, session, validator) for mode in ("normal", "lto"))
    )
    require(
        records[0]["sources"] == records[1]["sources"]
        and records[0]["rust_sources"] == records[1]["rust_sources"],
        "cross-mode source identity",
    )
    require(
        records[0]["relar_build_provenance"] == records[1]["relar_build_provenance"]
        and records[0]["git"] == records[1]["git"],
        "cross-mode build identity",
    )
    require(
        records[0]["tools"]["cpython"] == records[1]["tools"]["cpython"]
        and records[0]["execution"] == records[1]["execution"],
        "cross-mode runtime controls",
    )
    for key in (
        "rustc_verbose",
        "cargo_version",
        "tool_sha256",
        "cargo_wrapper",
        "build_script_sha256",
    ):
        require(
            records[0]["rust_build_record"][key]
            == records[1]["rust_build_record"][key],
            "cross-mode Rust tool identity: " + key,
        )
    for group in ENGINES:
        for left, right in zip(
            records[0]["workloads"][group], records[1]["workloads"][group]
        ):
            excluded = {"gates", "warmups", "samples", "summary"}
            require(
                {k: v for k, v in left.items() if k not in excluded}
                == {k: v for k, v in right.items() if k not in excluded},
                "cross-mode workload/input/output identity",
            )
    caches = bytecode_session(root, session, records)
    require(file_info(session_path) == initial, "session changed during audit")
    source = Path(__file__).read_text()
    result = {
        "schema_version": 1,
        "status": "passed",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "audit_script_sha256": digest(source.encode()),
        "audit_script_source": source,
        "reproduction": "python3 benchmarks/local/inventory-performance-final-audit.py",
        "method": "Independent integer-nanosecond median/min/max and inclusive linear-interpolation quartiles, all reported ratios, every recorded process result, exact artifact/build/committed-source identities, and before/after cache headers/hashes. Independent validators reused only after their source hashes were verified. No benchmark/statistics helper, compiler, native executable, or timed workload was executed.",
        "session_sha256": initial["sha256"],
        "bytecode": caches,
        "limits": [
            "Forty-eight measured rounds cover each inventory four-engine permutation twice and each control three-engine permutation eight times; the two warmup rounds and cross-round predecessors are not fully balanced.",
            "Consecutive saved indices, exact expected counts and reviewed no-filter harness establish completeness of these records; no independent OS process log can rule out earlier unrecorded attempts.",
            "The hashed harness compared full stdout and filesystem bytes before storing each result. This audit verifies retained expected bytes and all per-run hashes/lengths/status/stderr; full per-run output file copies are not retained.",
            "TracerPid was sampled at three checkpoints and affinity recorded after pinning, not continuously. Shared-host interference and CPU migrations outside those controls cannot be excluded from records alone.",
            "Bytecode timestamp headers and before/after bytes are verified; the audit does not independently decompile cache payloads. These are warm-cache whole-process runs, not cold import benchmarks.",
            "Rust preserves the eager algorithm and BigInt quantities but uses native containers, borrowed references and direct formatting. No identical-allocation or general language-speed claim follows.",
            "The normal and ThinLTO sessions ran sequentially. Their within-mode matched comparisons are stronger than attributing cross-session changes solely to LTO.",
        ],
        "assertions_passed": CHECKS,
        "distinct_files_hashed": len(FILES),
        "modes": list(audited),
    }
    output = root / "benchmarks/local/inventory-performance-final-audit.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    lines = [
        "| Mode | Inventory workload | CPython ms | Preserved Relar ms | Current Relar ms | Rust BigInt ms | Baseline / Relar | CPython / Relar | Relar / Rust |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for audit in audited:
        for row in audit["rows"]:
            if row["group"] == "inventory":
                med = row["median_ms"]
                ratio = row["ratios_of_medians"]
                lines.append(
                    f"| {audit['mode']} | {row['workload']} | {med['cpython']:.3f} | {med['baseline']:.3f} | {med['relar']:.3f} | {med['rust_bigint']:.3f} | {ratio['baseline_over_relar']:.3f}x | {ratio['cpython_over_relar']:.3f}x | {ratio['relar_over_rust_bigint']:.3f}x |"
                )
    lines += [
        "",
        "| Mode | Unchanged control | Baseline ms | Current ms | Current time change |",
        "|---|---|---:|---:|---:|",
    ]
    for audit in audited:
        for row in audit["rows"]:
            if row["group"] == "control":
                med = row["median_ms"]
                lines.append(
                    f"| {audit['mode']} | {row['workload']} | {med['baseline']:.3f} | {med['relar']:.3f} | {row['new_vs_baseline_time_change_percent']:+.3f}% |"
                )
    output.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(
        json.dumps(
            {
                "status": "passed",
                "assertions": CHECKS,
                "files_hashed": len(FILES),
                "script_sha256": digest(source.encode()),
                "audit_sha256": file_info(output)["sha256"],
            },
            indent=2,
        )
    )
    print("\n".join(lines))


if __name__ == "__main__":
    main()
