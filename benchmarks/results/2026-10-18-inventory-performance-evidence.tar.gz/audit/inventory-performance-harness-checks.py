"""Pure-Python inventory guard checks; never build, execute, profile, or time a workload."""

import collections
import contextlib
import copy
import hashlib
import io
import itertools
import json
import runpy
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / 'benchmarks/local'
sources = [Path(__file__), ROOT / 'benchmarks/inventory_benchmark.py', ROOT / 'benchmarks/inventory_profile.py']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source_hashes = {str(path.relative_to(ROOT)): digest(path) for path in sources}
checks = []
benchmark = runpy.run_path(str(ROOT / 'benchmarks/inventory_benchmark.py'))
old_path = LOCAL / 'inventory-normal-final.json'
old = json.loads(old_path.read_text())
assert benchmark['captured_workloads'](old) == [benchmark['workload'](case) for case in benchmark['corpus']()]
checks.append('six captured baseline cases equal independently generated corpus')
small = {'workloads': {'inventory': [copy.deepcopy(old['workloads']['inventory'][0])]}}
mutations = [
    ('empty workload list', lambda r: r['workloads'].__setitem__('inventory', [])),
    ('duplicate workload label', lambda r: r['workloads']['inventory'].append(copy.deepcopy(r['workloads']['inventory'][0]))),
    ('incorrect expected stdout', lambda r: r['workloads']['inventory'][0].__setitem__('expected_stdout', 'wrong')),
    ('incorrect request count', lambda r: r['workloads']['inventory'][0].__setitem__('positive_requests', 99)),
    ('inconsistent workload label', lambda r: r['workloads']['inventory'][0].__setitem__('label', 'wrong')),
    ('parent-traversing output path', lambda r: r['workloads']['inventory'][0]['case']['arguments'].__setitem__(2, '../report.txt')),
    ('absolute output path', lambda r: r['workloads']['inventory'][0]['case']['arguments'].__setitem__(2, '/tmp/report.txt')),
    ('incorrect input hash', lambda r: r['workloads']['inventory'][0]['case']['files']['stock.txt'].__setitem__('sha256', '0' * 64)),
    ('incorrect output length', lambda r: r['workloads']['inventory'][0]['expected_file_inventory']['report.txt'].__setitem__('bytes', 99)),
]
for label, mutate in mutations:
    record = copy.deepcopy(small)
    mutate(record)
    try:
        benchmark['captured_workloads'](record)
    except ValueError:
        checks.append('reject ' + label)
    else:
        raise AssertionError('accepted ' + label)


class Parsed(Exception):
    pass


seen = []


def stop_before_benchmark(args):
    seen.append(args)
    raise Parsed


benchmark['main'].__globals__['benchmark'] = stop_before_benchmark
required = [item for name in ['compiler', 'runtime', 'imre-build-record', 'rust-bigint', 'rust-build-record'] for item in ['--' + name, 'unused']]
pair = ['--inventory-baseline', 'unused', '--inventory-baseline-record', 'unused']
for label, extra, count in [
    ('three-engine default', [], 30), ('four-engine default', pair, 48),
    ('four-engine explicit complete cycle', pair + ['--samples', '24'], 24),
    ('three-engine explicit complete cycles', ['--samples', '12'], 12),
]:
    sys.argv = ['inventory_benchmark.py', *required, *extra]
    try:
        benchmark['main']()
    except Parsed:
        assert seen[-1].samples == count
        checks.append(label)
for label, extra, message in [
    ('missing baseline record', ['--inventory-baseline', 'unused'], 'must be supplied together'),
    ('missing baseline executable', ['--inventory-baseline-record', 'unused'], 'must be supplied together'),
    ('30 samples with four engines', pair + ['--samples', '30'], 'multiple of 24'),
    ('36 samples with four engines', pair + ['--samples', '36'], 'multiple of 24'),
    ('zero samples', ['--samples', '0'], 'positive'),
    ('zero warmups', ['--warmups', '0'], 'positive'),
    ('control selection without control baseline', ['--control-workload', 'empty'], 'requires a baseline'),
    ('LTO linker without target', ['--lto-linker', 'unused'], 'requires explicit --target'),
]:
    sys.argv = ['inventory_benchmark.py', *required, *extra]
    error = io.StringIO()
    with contextlib.redirect_stderr(error):
        try:
            benchmark['main']()
        except SystemExit as status:
            assert status.code == 2 and message in error.getvalue()
            checks.append('reject ' + label)
        else:
            raise AssertionError('accepted ' + label)
for engines in [('cpython', 'imre', 'rust_bigint', 'baseline'), ('cpython', 'baseline', 'imre')]:
    orders = list(itertools.permutations(engines))
    positions, adjacent = collections.Counter(), collections.Counter()
    for index in range(48):
        order = orders[index % len(orders)]
        positions.update((name, position) for position, name in enumerate(order))
        adjacent.update(zip(order, order[1:]))
    assert set(positions.values()) == {48 // len(engines)}
    checks.append(f'{len(engines)}-engine48-round position balance')
    assert set(adjacent.values()) == {48 // len(engines)}
    checks.append(f'{len(engines)}-engine48-round within-round predecessor balance')

profile = runpy.run_path(str(ROOT / 'benchmarks/inventory_profile.py'))
profile['shared'].pin_cpu = lambda _: {'selected_cpu': 0}
profile['profile'].__globals__['tracer_pid'] = lambda: 0


class Ready(Exception):
    pass


def stop_before_profiler(_):
    raise Ready


profile['profile'].__globals__['profiler'] = stop_before_profiler
with tempfile.TemporaryDirectory(prefix='inventory-profile-preflight-') as temporary:
    synthetic = copy.deepcopy(old)
    synthetic['sha256']['inventory_baseline'] = old['sha256']['inventory_binary']
    synthetic['sha256']['inventory_baseline_record'] = digest(old_path)
    synthetic['method']['commands']['inventory']['baseline'] = old['method']['commands']['inventory']['imre']
    path = Path(temporary) / 'comparison.json'
    path.write_text(json.dumps(synthetic))
    args = SimpleNamespace(cpu=0, record=path, engines=['baseline'], workloads=['empty'], tools=['callgrind'], binary=[], build_record=[], baseline_record=old_path, llvm_ir=None)
    try:
        profile['profile'](args)
    except Ready:
        checks.append('baseline profile artifact/source preflight reaches mocked profiler barrier')
    else:
        raise AssertionError('preflight failed to reach profiler barrier')
    args.baseline_record = None
    try:
        profile['profile'](args)
    except ValueError as error:
        assert 'requires --baseline-record' in str(error)
        checks.append('reject profile baseline without original record')
    else:
        raise AssertionError('missing baseline record accepted')
    args.baseline_record = LOCAL / 'inventory-lto-final.json'
    try:
        profile['profile'](args)
    except ValueError as error:
        assert 'preserved input differs' in str(error)
        checks.append('reject mismatched profile baseline record hash')
    else:
        raise AssertionError('wrong baseline record accepted')
assert len(checks) == 29
assert source_hashes == {str(path.relative_to(ROOT)): digest(path) for path in sources}
result = {
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'command': ['python3', 'benchmarks/local/inventory-performance-harness-checks.py'],
    'source_sha256': source_hashes,
    'baseline_record_sha256': digest(old_path),
    'checks_passed': len(checks), 'checks': checks,
    'native_runs': 0, 'builds': 0, 'profiles': 0, 'timing_samples': 0,
    'scope': 'Pure-Python CLI/captured-record/balance/preflight checks. Benchmark and profiler entry points are replaced with stopping sentinels. Profile CPU pinning/tracer reads are mocked, so this does not test ptrace refusal or execute instrumentation.',
}
output = LOCAL / 'inventory-performance-harness-checks.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(f'{len(checks)} checks passed; saved {output}')
