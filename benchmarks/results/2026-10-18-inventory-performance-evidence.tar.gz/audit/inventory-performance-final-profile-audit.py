"""Audit final inventory profiles against their raw traces and timing identities.

This reads existing artifacts only. Run after the isolated timing window and
after both final profile directories are complete; it never profiles or builds.
"""

import argparse
import hashlib
import json
import re
import runpy
import statistics
from pathlib import Path

LOCAL = Path(__file__).resolve().parent
ROOT = LOCAL.parent.parent
MODES = ("normal", "lto")
LABELS = ("dense-16384", "sparse-16384")
COUNTERS = ("tb", "tbk", "gb", "gbk", "eb", "ebk", "rb", "wb")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def display(value):
    """Keep display paths portable while original bytes remain hash-addressed."""
    if isinstance(value, str):
        return value.replace(str(ROOT) + "/", "").replace(str(Path.home()) + "/", "$HOME/")
    if isinstance(value, list):
        return [display(item) for item in value]
    if isinstance(value, dict):
        return {key: display(item) for key, item in value.items()}
    return value


def artifact(path):
    return {"path": display(str(path.resolve())), "sha256": digest(path), "bytes": path.stat().st_size}


def child(directory, relative):
    path = (directory / relative).resolve(strict=True)
    require(path.is_relative_to(directory.resolve()), f"path escapes profile: {relative}")
    return path


def nearest_entry(stack):
    for frame in stack:
        match = re.search(r": (relar_[a-z_]+) ", frame)
        if match:
            return match[1]
    return "other"


def point_summary(point):
    return display({key: point[key] for key in ("id", "tb", "tbk", "gb", "gbk", "eb", "ebk", "stack")})


def profile_metrics(callgrind, dhat, top):
    functions = sorted(callgrind["functions"], key=lambda row: row["self_instructions"], reverse=True)
    require(sum(row["self_instructions"] for row in functions) == callgrind["total_instructions"], "exclusive instruction reconciliation failed")
    require(callgrind["exclusive_sum_verified"] is True, "Callgrind exclusive counts unverified")
    points = dhat["points"]
    for key in COUNTERS:
        require(sum(point[key] for point in points) == dhat["totals"][key], f"DHAT point total differs: {key}")
        require(sum(row[key] for row in dhat["by_nearest_runtime_entry"]) == dhat["totals"][key], f"DHAT entry total differs: {key}")
    entries = []
    for entry in sorted(dhat["by_nearest_runtime_entry"], key=lambda row: row["tbk"], reverse=True):
        selected = [point for point in points if nearest_entry(point["stack"]) == entry["entry"]]
        require(all(sum(point[key] for point in selected) == entry[key] for key in COUNTERS), f"allocation entry attribution differs: {entry['entry']}")
        entries.append({**entry, "top_stacks_by_allocated_blocks": [point_summary(point) for point in sorted(selected, key=lambda row: row["tbk"], reverse=True)[:3]]})
    totals = dhat["totals"]
    return {
        "instructions": callgrind["total_instructions"],
        "allocated_blocks": totals["tbk"],
        "requested_bytes": totals["tb"],
        "peak_live_bytes": totals["gb"],
        "peak_live_blocks": totals["gbk"],
        "end_live_bytes": totals["eb"],
        "end_live_blocks": totals["ebk"],
        "dhat_counters": totals,
        "dhat_global_peak_instruction": dhat["global_peak_time"],
        "top_self_functions": display([{key: row[key] for key in ("name", "self_instructions", "self_fraction", "calls", "objects")} for row in functions[:top]]),
        "allocation_entries": entries,
        "top_allocation_stacks_by_requested_bytes": [point_summary(point) for point in sorted(points, key=lambda row: row["tb"], reverse=True)[:top]],
        "trace_sha256": {"callgrind": callgrind["trace_sha256"], "dhat": dhat["trace_sha256"]},
    }


def audit_bundle(directory, record_path):
    """Reparse sealed traces with their preserved parser and verify output bytes."""
    manifest = load(directory / "manifest.json")
    actual = {path.relative_to(directory).as_posix() for path in directory.rglob("*") if path.is_file() and path != directory / "manifest.json"}
    require(actual == set(manifest), f"profile manifest inventory differs: {directory}")
    for name, expected in manifest.items():
        value = child(directory, name)
        require(value.stat().st_size == expected["bytes"] and digest(value) == expected["sha256"], f"profile artifact changed: {value}")
    provenance = load(directory / "provenance.json")
    summary = load(directory / "summary.json")
    record = load(record_path)
    require(provenance["completed_at_utc"] and provenance["tracer_pid_before"] == provenance["tracer_pid_after"] == 0, "profile did not complete untraced")
    require(not provenance["comparison_was_validation_only"], "profile is not tied to a measured comparison")
    require(digest(record_path) == provenance["inputs"]["comparison"]["sha256"] == digest(directory / "comparison.json"), "profile comparison identity differs")
    require(provenance["comparison_git"] == record["git"] and provenance["comparison_options"] == record["options"], "profile comparison metadata differs")
    for name, expected in provenance["inputs"].items():
        if name == "comparison":
            source = directory / "comparison.json"
        elif name.startswith("harness:"):
            source = directory / "sources" / name.split(":", 1)[1]
        elif name.startswith("build:"):
            source = directory / "build-records" / (name.split(":", 1)[1] + ".json")
        else:
            source = Path(expected["path"])
        require(source.stat().st_size == expected["bytes"] and digest(source) == expected["sha256"], f"profile input identity differs: {name}")
    workloads = {row["label"]: row for row in record["workloads"]["inventory"]}
    captured = load(directory / "workloads.json")["workloads"]
    require({row["label"] for row in captured} == set(LABELS), "profile workload selection differs")
    require(all(row == workloads[row["label"]] for row in captured), "profile captured workload bytes differ")
    parser_path = directory / "sources" / "dependency_profile.py"
    parser = runpy.run_path(str(parser_path))
    key = lambda row: (row["workload"], row["engine"], row["tool"])
    parsed = {key(row): row for row in summary["runs"]}
    runs = {key(row): row for row in provenance["runs"]}
    require(len(parsed) == len(summary["runs"]) and len(runs) == len(provenance["runs"]) and parsed.keys() == runs.keys(), "duplicate or unmatched profile runs")
    engines = {engine for _, engine, _ in runs}
    require(set(runs) == {(label, engine, tool) for label in LABELS for engine in engines for tool in ("callgrind", "dhat")}, "incomplete profile run matrix")
    for identity, run in runs.items():
        label, engine, tool = identity
        workload = workloads[label]
        require(run["returncode"] == 0 and not run["timed_out"] and run["complete_output_verified"] is True, f"unsuccessful profile: {identity}")
        require(run["result"]["returncode"] == 0 and run["result"]["files"] == workload["expected_file_inventory"] and run["result"]["stderr"] == "", f"profile output result differs: {identity}")
        stem = f"{label}.{engine}.{tool}"
        stdout = (directory / (stem + ".stdout")).read_bytes()
        stderr = (directory / (stem + ".stderr")).read_bytes()
        require(stdout == workload["expected_stdout"].encode() and not stderr, f"profile output bytes differ: {identity}")
        require(digest(directory / (stem + ".stdout")) == run["stdout_sha256"] == run["result"]["stdout_sha256"] and digest(directory / (stem + ".stderr")) == run["stderr_sha256"], "profile stream hash differs")
        cwd = child(directory, run["cwd"])
        inventory = {path.relative_to(cwd).as_posix(): {"sha256": digest(path), "bytes": path.stat().st_size} for path in cwd.rglob("*") if path.is_file()}
        require(inventory == workload["expected_file_inventory"], f"retained output filesystem differs: {identity}")
        directories = sorted(path.relative_to(cwd).as_posix() for path in cwd.rglob("*") if path.is_dir())
        require(directories == run["result"]["directories"], "retained directory inventory differs")
        arguments = workload["case"]["arguments"]
        require(run["command"][-len(arguments):] == arguments, "profile arguments differ")
        binary = Path(run["command"][-len(arguments) - 1])
        require(digest(binary) == provenance["inputs"]["binary:" + engine]["sha256"], "executed binary identity differs")
        trace = child(directory, run["trace"])
        require(digest(trace) == run["trace_sha256"] == parsed[identity]["trace_sha256"], "trace identity differs")
        require(digest(child(directory, run["log"])) == run["log_sha256"], "profiler log identity differs")
        reparsed = parser[tool](trace)
        require(reparsed == {name: value for name, value in parsed[identity].items() if name not in ("workload", "engine", "tool", "trace_sha256")}, f"raw trace parsing differs: {identity}")
    return {
        "artifacts": {name: artifact(directory / name) for name in ("summary.json", "provenance.json", "manifest.json", "sources/dependency_profile.py")},
        "verified_manifest_files": len(manifest),
        "verified_runs": len(runs),
        "profiler": provenance["profiler"],
        "profiler_sha256": {name: value["sha256"] for name, value in provenance["inputs"].items() if name.startswith("profiler:")},
        "inputs": provenance["inputs"],
        "environment": display(provenance["environment"]),
        "host": provenance["host"],
        "cpu": provenance["cpu"],
        "tracer_pid": [provenance["tracer_pid_before"], provenance["tracer_pid_after"]],
        "runs": parsed,
    }


def app_sources(record):
    return {name: value for name, value in record["sources"].items() if name.startswith("inventory_reconciliation/")}


def audit_mode(mode, record_path, top):
    current = load(record_path)
    baseline_path = LOCAL / f"inventory-{mode}-final.json"
    baseline = load(baseline_path)
    require(current["example"] == baseline["example"] == "inventory_reconciliation", "wrong example")
    require(current["git"]["dirty"] is False and not current["options"]["validation_only"], "final timing must identify clean measured source")
    require(app_sources(current) == app_sources(baseline) and current["rust_sources"] == baseline["rust_sources"], "application or reference source changed")
    for name in ("target", "lto", "llvm_budget", "optimization_level"):
        require(current["options"][name] == baseline["options"][name], f"baseline mode differs: {name}")
    require(current["sha256"]["inventory_baseline_record"] == digest(baseline_path), "baseline timing record changed")
    require(current["sha256"]["inventory_baseline"] == baseline["sha256"]["inventory_binary"], "baseline executable changed")
    require(current["sha256"]["rust_bigint"] == baseline["sha256"]["rust_bigint"], "Rust executable changed")
    bundles = {
        "baseline_and_rust": audit_bundle(LOCAL / f"inventory-profile-baseline-{mode}", baseline_path),
        "final": audit_bundle(LOCAL / f"inventory-performance-final-profile-{mode}", record_path),
    }
    require(bundles["baseline_and_rust"]["profiler_sha256"] == bundles["final"]["profiler_sha256"], "profiler implementation changed")
    for name, record in (("baseline_and_rust", baseline), ("final", current)):
        inputs = bundles[name]["inputs"]
        for input_name, record_key in (("binary:relar", "inventory_binary"), ("build:relar", "relar_build_record"), ("compiler", "compiler"), ("runtime", "runtime"), ("llvm_ir", "inventory_ir")):
            require(inputs[input_name]["sha256"] == record["sha256"][record_key], f"profile/timing artifact mismatch: {name}:{input_name}")
    require(bundles["baseline_and_rust"]["inputs"]["binary:rust_bigint"]["sha256"] == current["sha256"]["rust_bigint"], "Rust profile/timing identity mismatch")
    rows = []
    for label in LABELS:
        workload = next(row for row in current["workloads"]["inventory"] if row["label"] == label)
        old = next(row for row in baseline["workloads"]["inventory"] if row["label"] == label)
        for field in ("case", "expected_stdout", "expected_changed_files", "expected_file_inventory"):
            require(workload[field] == old[field], f"baseline/final workload differs: {label}:{field}")
        metrics = {}
        for name, group, engine in (("baseline", "baseline_and_rust", "relar"), ("relar", "final", "relar"), ("rust_bigint", "baseline_and_rust", "rust_bigint")):
            runs = bundles[group]["runs"]
            metrics[name] = profile_metrics(runs[label, engine, "callgrind"], runs[label, engine, "dhat"], top)
        medians = {engine: statistics.median(sample[engine]["elapsed_ns"] for sample in workload["samples"]) / 1e6 for engine in current["method"]["commands"]["inventory"]}
        rows.append({
            "label": label,
            "case_sha256": hashlib.sha256(json.dumps(workload["case"], sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
            "expected_stdout_sha256": hashlib.sha256(workload["expected_stdout"].encode()).hexdigest(),
            "expected_file_inventory": workload["expected_file_inventory"],
            "timing_median_ms": medians,
            "timing_ratios": {"baseline_over_relar": medians["baseline"] / medians["relar"], "relar_over_rust_bigint": medians["relar"] / medians["rust_bigint"], "cpython_over_relar": medians["cpython"] / medians["relar"]},
            "profiles": metrics,
            "reduction_fraction_from_baseline": {key: 1 - metrics["relar"][key] / metrics["baseline"][key] for key in ("instructions", "allocated_blocks", "requested_bytes", "peak_live_bytes")},
            "ratio_to_rust_bigint": {key: metrics["relar"][key] / metrics["rust_bigint"][key] for key in ("instructions", "allocated_blocks", "requested_bytes", "peak_live_bytes")},
        })
    return {
        "timing_record": artifact(record_path),
        "baseline_record": artifact(baseline_path),
        "timing_source_identity": current["git"],
        "application_sources": app_sources(current),
        "artifact_sha256": {name: current["sha256"][name] for name in ("compiler", "runtime", "relar_build_record", "inventory_binary", "inventory_ir", "inventory_baseline", "rust_bigint", "rust_record")},
        "profile_audit": {name: display({key: value for key, value in bundle.items() if key != "runs"}) for name, bundle in bundles.items()},
        "workloads": rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--record", action="append", default=[], metavar="MODE=PATH", help="Override final timing record for normal or lto")
    parser.add_argument("--output", type=Path, default=LOCAL / "inventory-performance-final-profile-audit.json")
    parser.add_argument("--top", type=int, default=15)
    args = parser.parse_args()
    require(args.top > 0, "--top must be positive")
    records = {mode: LOCAL / f"inventory-performance-{mode}-final.json" for mode in MODES}
    overrides = {}
    for value in args.record:
        mode, separator, path = value.partition("=")
        require(separator and mode in MODES and mode not in overrides and path, "--record requires unique MODE=PATH")
        overrides[mode] = Path(path).resolve()
    records.update(overrides)
    result = {
        "schema_version": 1,
        "audit_script": {**artifact(Path(__file__)), "source": Path(__file__).read_text()},
        "method": {
            "verification": "Every retained profile member, frozen input, binary, parser, trace, log, stdout and complete filesystem output is hash-checked; sealed raw traces are reparsed and exactly matched to summaries. Timing medians use raw uninstrumented samples. Detailed timing-order/oracle/cache auditing is separate.",
            "instructions": "Callgrind Ir counts instructions, not cycles or elapsed-time shares. Exclusive function costs reconcile with the whole-process total. Inclusive edge costs are never summed or used as time fractions.",
            "allocations": "DHAT counts requested heap blocks/bytes in a fresh executable process, including startup and application file I/O. Fixture materialization and output validation run outside instrumentation. Peak live bytes sum gb at the shared global heap peak; individual allocation-site mb maxima are never summed. End-live bytes are recorded, not interpreted as a leak detector.",
            "attribution": "Each allocation stack is assigned once to its nearest visible relar_* entry, otherwise other. Inlining changes available stack labels, especially under ThinLTO. Top stacks retain their point IDs and source frames; full traces remain in sealed profile directories.",
            "limits": ["Instrumented elapsed times are excluded from performance comparisons.", "No hardware cycle counters or RSS are measured.", "Shared-devbox warm-cache results do not establish cold-cache or durable-storage behavior.", "Path length and process startup can change small allocation totals.", "Rust retains the same application algorithm and arbitrary-precision contract, with different containers, ownership and formatting implementation.", "Display paths are normalized; original artifact bytes and hashes remain unchanged."],
        },
        "modes": {mode: audit_mode(mode, records[mode], args.top) for mode in MODES},
    }
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(artifact(args.output)))
    for mode, data in result["modes"].items():
        for row in data["workloads"]:
            print(mode, row["label"], json.dumps({engine: {key: metrics[key] for key in ("instructions", "allocated_blocks", "requested_bytes", "peak_live_bytes")} for engine, metrics in row["profiles"].items()}))


if __name__ == "__main__":
    main()
