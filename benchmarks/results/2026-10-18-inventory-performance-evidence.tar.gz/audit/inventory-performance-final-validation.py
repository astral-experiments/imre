#!/usr/bin/env python3
"""Audit saved validation evidence; never build, run native code, or time programs.

Run from the original evidence checkout (or pass --root). Native executables and
runtime archives must still be available to verify their recorded byte hashes.
The resulting index contains references and hashes, not embedded source or input
data. Cargo unit/Clippy exits are explicitly attributed to the root observer;
their logs did not include independent machine-readable exit receipts.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import subprocess


COMMIT = "7ec35cbd0a94ca82419061c725382b2e2a1d4a1e"
PREFIX = Path("benchmarks/local")
PYTHON = "/home/dev-user/.local/bin/python3.14"
CLANG = "/usr/bin/clang-18"
TARGET = "x86_64-unknown-linux-gnu"
ASAN = "detect_leaks=1:halt_on_error=1"
SUITES = {
    "classes", "comprehensions", "containers", "differential",
    "exceptions", "files", "imports", "io",
}
EXPECTED = {
    "ordinary": {"classes": 58, "comprehensions": 65, "containers": 282,
                 "differential": 112, "exceptions": 48, "files": 74,
                 "imports": 51, "io": 20},
    "thinlto": {"classes": 56, "comprehensions": 52, "containers": 212,
                "differential": 72, "exceptions": 32, "files": 52,
                "imports": 47, "io": 10},
}
EXPECTED["asan"] = EXPECTED["ordinary"]
LEVELS = {"ordinary": ["0", "3"], "thinlto": ["3"], "asan": ["0", "1"]}
RUNTIMES = {"ordinary": "libimre_runtime.a", "thinlto": "libimre_runtime_lto.a",
            "asan": "libimre_runtime_asan.a"}
SANITIZER_DIAGNOSTIC = re.compile(
    r"(?:ERROR|SUMMARY): (?:Address|Leak|UndefinedBehavior)Sanitizer|"
    r"AddressSanitizer:DEADLYSIGNAL|runtime error:"
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: bool, message: object) -> None:
    if not condition:
        raise ValueError(message)


class Audit:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.verified: dict[str, str] = {}
        self.committed: set[str] = set()

    def path(self, value: str | Path) -> Path:
        path = Path(value)
        return path if path.is_absolute() else self.root / path

    def label(self, value: str | Path) -> str:
        path = self.path(value)
        return str(path.relative_to(self.root)) if path.is_relative_to(self.root) else str(path)

    def file(self, value: str | Path, expected: str | None = None) -> dict:
        path = self.path(value)
        label = self.label(path)
        if label not in self.verified:
            with path.open("rb") as source:
                self.verified[label] = hashlib.file_digest(source, "sha256").hexdigest()
        actual = self.verified[label]
        require(expected is None or actual == expected, (label, "hash mismatch"))
        return {"path": label, "sha256": actual}

    def record(self, path: str | Path) -> tuple[dict, dict]:
        reference = self.file(path)
        return json.loads(self.path(path).read_text()), reference

    def sources(self, values: dict[str, str], *, committed: bool = True) -> None:
        for name, expected in values.items():
            self.file(name, expected)
            if committed and name not in self.committed:
                blob = subprocess.check_output(
                    ["git", "show", f"{COMMIT}:{name}"], cwd=self.root
                )
                require(sha(blob) == expected, (name, "differs from final commit"))
                self.committed.add(name)

    def build(self, stage: str) -> tuple[dict, dict]:
        directory = PREFIX / f"inventory-performance-tools-{stage}"
        data, reference = self.record(directory / "build-record.json")
        self.sources(data["source_sha256"])
        require(set(data["source_contents"]) == set(data["source_sha256"]), stage)
        for name, contents in data["source_contents"].items():
            require(sha(contents.encode()) == data["source_sha256"][name], name)
        self.file("/tmp/imre-cargo.sh", sha(data["cargo_wrapper"].encode()))
        artifacts = {Path(name).name: digest for name, digest in data["sha256"].items()}
        require(set(artifacts) == {"imre", *RUNTIMES.values()}, stage)
        for name, digest in data["sha256"].items():
            self.file(name, digest)
        for mode, entry in data["commands"].items():
            require(entry["returncode"] == 0, (stage, mode, "build failed"))
            self.file(directory / f"{mode}.log", entry["log_sha256"])
        require(set(data["commands"]) == set(LEVELS), stage)
        require(data["commands"]["asan"]["environment"]["RUSTFLAGS"]
                == "-Zsanitizer=address -Cforce-frame-pointers=yes", stage)
        require(data["commands"]["thinlto"]["environment"]["RUSTFLAGS"]
                == "-Clinker-plugin-lto", stage)
        if stage == "final":
            require(data["git_head"] == COMMIT and data["compiled_sources_match_commit"], stage)
        return data, {"record": reference, "artifacts_sha256": artifacts,
                      "recorded_head": data["git_head"],
                      "embedded_build_script_sha256": sha(data["build_script"].encode()),
                      "embedded_cargo_wrapper_sha256": sha(data["cargo_wrapper"].encode())}


def option(command: list[str], flag: str) -> str:
    return command[command.index(flag) + 1]


def levels(command: list[str]) -> list[str]:
    start = command.index("--opt-levels") + 1
    end = next((i for i in range(start, len(command)) if command[i].startswith("--")), len(command))
    return command[start:end]


def suite_records(audit: Audit, builds: dict) -> dict:
    result = {mode: {"optimization_levels": LEVELS[mode], "suites": {}} for mode in LEVELS}
    sources = None
    for stage, mode in [("final", "ordinary"), ("dev3b", "ordinary"),
                        ("final", "thinlto"), ("final", "asan"), ("dev3b", "asan")]:
        path = PREFIX / f"inventory-performance-validation-{stage}" / mode / "results.json"
        record, reference = audit.record(path)
        require(record["passed"] and record["inputs_unchanged"] and record.get("finished_at_unix"), path)
        require(record["mode"] == mode, path)
        require(record["head"] == builds[stage]["git_head"], path)
        expected_suites = SUITES if mode == "thinlto" else (
            {"containers", "files"} if stage == "dev3b" else SUITES - {"containers", "files"}
        )
        require(set(record["results"]) == expected_suites, (path, "suite coverage"))
        require(sources is None or sources == record["test_sources"], "test source snapshots differ")
        sources = record["test_sources"]
        audit.sources(sources)
        audit.file(record["runner"]["path"], record["runner"]["sha256"])
        for tool in ("compiler", "runtime"):
            audit.file(record[tool]["path"], record[tool]["sha256"])
        require(record["compiler"]["sha256"] == builds[stage]["sha256"][str(
            PREFIX / f"inventory-performance-tools-{stage}" / "imre")], path)
        require(record["runtime"]["sha256"] == builds[stage]["sha256"][str(
            PREFIX / f"inventory-performance-tools-{stage}" / RUNTIMES[mode])], path)
        for suite, entry in record["results"].items():
            require(suite not in result[mode]["suites"], (mode, suite, "duplicate"))
            command = entry["command"]
            require(command[:3] == [PYTHON, "-I", str(audit.root / f"tests/{suite}.py")], command)
            require(option(command, "--compiler") == record["compiler"]["path"], command)
            require(option(command, "--runtime") == record["runtime"]["path"], command)
            require(option(command, "--python") == PYTHON and option(command, "--clang") == CLANG, command)
            require(levels(command) == LEVELS[mode], command)
            require(("--sanitize" in command) == (mode == "asan"), command)
            require(("--lto-linker" in command) == (mode == "thinlto"), command)
            if mode == "thinlto":
                require(option(command, "--target") == TARGET, command)
                linker = Path(option(command, "--lto-linker"))
                require(linker.name == "ld.lld", "lexical LLD flavor was lost")
                audit.file(linker)
            require(entry["returncode"] == 0, (mode, suite, "failure"))
            stdout = audit.file(entry["stdout"]["path"], entry["stdout"]["sha256"])
            stderr = audit.file(entry["stderr"]["path"], entry["stderr"]["sha256"])
            require(not audit.path(stderr["path"]).read_bytes(), (mode, suite, "unexpected stderr"))
            text = audit.path(stdout["path"]).read_text().strip()
            match = re.search(r"^(?:Passed (\d+) .*checks|(?P<imports>\d+) import checks passed)", text)
            require(match is not None, (suite, text))
            count = int(match.group(1) or match.group("imports"))
            require(count == EXPECTED[mode][suite], (mode, suite, count))
            if mode == "asan":
                require(f'"ASAN_OPTIONS": "{ASAN}"' in (audit.root / f"tests/{suite}.py").read_text(), suite)
            result[mode]["suites"][suite] = {
                "source_record": reference, "tool_stage": stage,
                "reported_checks": count, "command": command,
                "stdout": stdout, "stderr": stderr, "returncode": 0,
            }
    for mode, entry in result.items():
        require(set(entry["suites"]) == SUITES, mode)
        entry["reported_checks"] = sum(suite["reported_checks"] for suite in entry["suites"].values())
    return result


def check_oracle(audit: Audit, path: Path) -> dict:
    oracle, reference = audit.record(path)
    require(oracle["engines"] == ["cpython", "imre"], path)
    require(oracle["cases"] == len(oracle["records"]) == 176, path)
    labels = set()
    successes = 0
    for row in oracle["records"]:
        label = row["case"]["label"]
        require(label not in labels, (label, "duplicate oracle case"))
        labels.add(label)
        expected = row["expected"]
        successes += expected["returncode"] == 0
        for inventory in (row["case"]["files"], row["expected_files"]):
            for name, entry in inventory.items():
                content = base64.b64decode(entry["base64"], validate=True)
                require(len(content) == entry["bytes"] and sha(content) == entry["sha256"], (label, name))
        expected_files = {name: {key: value[key] for key in ("sha256", "bytes")}
                          for name, value in row["expected_files"].items()}
        require(set(row["engines"]) == {"cpython", "imre"}, label)
        for engine, actual in row["engines"].items():
            require(actual["returncode"] == expected["returncode"], (label, engine, "status"))
            output = expected["stdout"].encode()
            require(actual["stdout_sha256"] == sha(output) and actual["stdout_bytes"] == len(output), (label, engine, "stdout"))
            require(actual["files"] == expected_files and actual["directories"] == expected["directories"], (label, engine, "filesystem"))
            if expected["error_category"] is None:
                require(not actual["stderr"], (label, engine, "stderr"))
            else:
                require(actual["stderr"].strip().splitlines()[-1] == expected["error_category"] + ": " + expected["error_message"], (label, engine, "error"))
            require(not SANITIZER_DIAGNOSTIC.search(actual["stderr"]), (label, engine, "sanitizer"))
    require(successes == oracle["successful"] == 127 and oracle["terminal_errors"] == 49, path)
    device = oracle["device_check"]
    require(device["case"] == "terminal-report-device-error", device)
    require(set(device["engines"]) == {"cpython", "imre"}, device)
    expected_device_files = {
        name: {"sha256": sha(content), "bytes": len(content)}
        for name, content in {"stock.txt": b"1\na 4\n", "orders.txt": b"1\n1\na 2\n"}.items()
    }
    for engine, actual in device["engines"].items():
        require(actual["returncode"] == 1 and actual["stdout_sha256"] == sha(b"") and actual["stdout_bytes"] == 0, engine)
        require(actual["stderr"].strip().splitlines()[-1] == "OSError: report: cannot write", engine)
        require(actual["files"] == expected_device_files and actual["directories"] == [], engine)
        require(not SANITIZER_DIAGNOSTIC.search(actual["stderr"]), engine)
    return {"record": reference, "cases": 176, "successful": 127, "terminal_errors": 49,
            "device_checks": 1, "engines": oracle["engines"],
            "complete_output_status_filesystem_verified": True}


def extra_records(audit: Audit, build: dict, build_reference: dict) -> dict:
    result = {}
    for name in ("lto-cli", "inventory-asan"):
        directory = PREFIX / "inventory-performance-validation-final" / name
        record, reference = audit.record(directory / "record.json")
        require(record["head"] == COMMIT and record["status"] == "passed" and record["tracer_pid"] == 0, name)
        require(record["build_record_sha256"] == build_reference["record"]["sha256"], name)
        require(record["compiled_sources_sha256"] == build["source_sha256"], name)
        audit.sources(record["validation_sources_sha256"])
        for path, digest in record["tools_sha256"].items():
            audit.file(path, digest)
        for tool in ("python", "clang", "rust_lld"):
            audit.file(record[tool]["path"], record[tool]["sha256"])
        audit.file("/tmp/imre-inventory-final-extra-validation.py", record["runner_sha256"])
        require(record["environment"]["ASAN_OPTIONS"] == ASAN and record["target"] == TARGET, name)
        for entry in record["steps"]:
            require(entry["returncode"] == 0, (name, entry["name"]))
            audit.file(entry["stdout"], entry["stdout_sha256"])
            audit.file(entry["stderr"], entry["stderr_sha256"])
            require(not audit.path(entry["stderr"]).read_bytes(), (name, "stderr"))
        if name == "lto-cli":
            require(record["checks"] == 10 and len(record["steps"]) == 1, name)
            command = record["steps"][0]["command"]
            require(command[0] == PYTHON and option(command, "--target") == TARGET, name)
            require(audit.path(record["steps"][0]["stdout"]).read_text().strip() == "Passed 10 ThinLTO CLI checks", name)
            result[name] = {"record": reference, "checks": 10, "tracer_pid": 0}
        else:
            require(len(record["steps"]) == 2, name)
            command = record["steps"][0]["command"]
            require(option(command, "--opt-level") == "1" and "--sanitize" in command, name)
            require(Path(option(command, "--runtime")).name == RUNTIMES["asan"], name)
            for path, digest in record["artifacts_sha256"].items():
                audit.file(path, digest)
            oracle = check_oracle(audit, directory / "oracle.json")
            require(record["oracle_summary"] == {key: oracle[key] for key in ("cases", "successful", "terminal_errors", "engines")}, name)
            require(record["device_check"] == json.loads(audit.path(directory / "oracle.json").read_text())["device_check"], name)
            result[name] = {"record": reference, "optimization_level": "1",
                            "tracer_pid": 0, "oracle": oracle}
    return result


def rust_checks(audit: Audit) -> dict:
    unit = audit.file(PREFIX / "inventory-performance-dev3b-unit.log")
    clippy = audit.file(PREFIX / "inventory-performance-dev3b-clippy.log")
    text = audit.path(unit["path"]).read_text()
    rows = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", text)
    require([int(row[0]) for row in rows] == [25, 0, 40, 0, 0], "unit result groups")
    require(all(all(int(value) == 0 for value in row[1:]) for row in rows), "unit failures/skips")
    clippy_text = audit.path(clippy["path"]).read_text()
    require("Finished `dev` profile" in clippy_text and not re.search(r"(?m)^(?:error|warning)(?:\[|:)", clippy_text), "Clippy diagnostics")
    caveat = ("Commands and terminal exit 0 were observed and reported by /root; "
              "there is no separate machine-readable exit receipt for these two invocations. "
              "The hashed logs show successful completion, and their dev3b compiled source "
              "snapshot is identical to the final committed snapshot.")
    return {
        "status_evidence": caveat,
        "unit": {"command": ["sh", "/tmp/imre-cargo.sh", "test", "--workspace"],
                 "root_observed_exec_session": 73174, "root_observed_exit_code": 0,
                 "passed": 65, "compiler_tests": 25, "runtime_tests": 40, "log": unit},
        "clippy": {"command": ["sh", "/tmp/imre-cargo.sh", "clippy", "--workspace", "--all-targets", "--", "-D", "warnings"],
                   "root_observed_exec_session": 29513, "root_observed_exit_code": 0, "log": clippy},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    audit = Audit(args.root)
    builds, provenance = {}, {}
    for stage in ("dev3b", "final"):
        builds[stage], provenance[stage] = audit.build(stage)
    require(builds["dev3b"]["source_sha256"] == builds["final"]["source_sha256"], "source reuse mismatch")
    require(provenance["dev3b"]["artifacts_sha256"] == provenance["final"]["artifacts_sha256"], "artifact reuse mismatch")
    native = suite_records(audit, builds)
    extras = extra_records(audit, builds["final"], provenance["final"])
    rust = rust_checks(audit)
    script = audit.file(Path(__file__).absolute())
    index = {
        "schema": "imre-inventory-performance-final-validation-v1",
        "status": "passed", "source_commit": COMMIT, "audit_script": script,
        "builds": provenance,
        "dev3b_reuse": {"compiled_sources_identical": True, "all_four_artifacts_byte_identical": True,
                        "note": "Only containers/files ordinary and ASan records are reused; all other suite records use final tools."},
        "native_suites": native, "extra_checks": extras, "rust_checks": rust,
        "sanitizer": {"runtime_and_generated_code_instrumented": True, "ASAN_OPTIONS": ASAN,
                      "environment_evidence": "Verified suite source sets this value; both extra records capture it explicitly."},
        "counting_note": "Suite totals are the harness-reported checks, including repeated rejection checks across modes; they are not counts of unique source programs. Oracle cases and the device case are reported separately.",
        "verified_files_sha256": dict(sorted(audit.verified.items())),
    }
    output = args.output or audit.root / PREFIX / "inventory-performance-final-validation.json"
    output.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"path": str(output), "sha256": sha(output.read_bytes()), "status": "passed",
                      "native_checks": {mode: value["reported_checks"] for mode, value in native.items()},
                      "lto_cli_checks": 10, "inventory_cases": 176, "device_checks": 1,
                      "rust_unit_tests": 65, "verified_files": len(audit.verified)}, sort_keys=True))


if __name__ == "__main__":
    main()
