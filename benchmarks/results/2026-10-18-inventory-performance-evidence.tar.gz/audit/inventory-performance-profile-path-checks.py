"""Check captured profile paths without materializing or executing any fixture."""

import copy
import hashlib
import json
import runpy
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / 'benchmarks/local'
module = ROOT / 'benchmarks/inventory_profile.py'
profile = runpy.run_path(str(module))
record_path = LOCAL / 'inventory-normal-final.json'
record = json.loads(record_path.read_text())
original = record['workloads']['inventory'][0]
profile['captured'](original)
checks = ['valid captured empty case']
for path in ['/tmp/outside-fixture', '../outside-fixture', 'invalid\0path']:
    for field in ['arguments', 'files', 'directories', 'hardlink_key', 'hardlink_target']:
        workload = copy.deepcopy(original)
        case = workload['case']
        if field == 'arguments':
            case['arguments'][2] = path
        elif field == 'files':
            case['files'][path] = copy.deepcopy(case['files']['stock.txt'])
        elif field == 'directories':
            case['directories'].append(path)
        elif field == 'hardlink_key':
            case['hardlinks'][path] = 'stock.txt'
        else:
            case['hardlinks']['alias'] = path
        try:
            profile['captured'](workload)
        except ValueError as error:
            assert 'profiled file paths must remain inside the fixture' in str(error)
            checks.append(f'reject {field}: {path!r}')
        else:
            raise AssertionError((field, path))
result = {
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'command': ['python3', 'benchmarks/local/inventory-performance-profile-path-checks.py'],
    'source_sha256': {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [Path(__file__), module]},
    'baseline_record_sha256': hashlib.sha256(record_path.read_bytes()).hexdigest(),
    'checks_passed': len(checks), 'checks': checks,
    'native_runs': 0, 'builds': 0, 'profiles': 0, 'timing_samples': 0,
    'scope': 'Pure-Python captured-path validation before fixture creation; no filesystem fixture is materialized.',
}
output = LOCAL / 'inventory-performance-profile-path-checks.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(f'{len(checks)} checks passed; saved {output}')
