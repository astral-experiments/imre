# Replaying Ruff’s diagnostic-entry comparison

Extract this archive to an empty directory. From that directory run `python3.14 -B replay.py`. Replay checks the full index, both ordinary and ThinLTO source and binary receipts, the 146-file corpus and the three original ty captures. It regenerates Ruff's 249 ordered title/key/source rows and the full reports, verifies the six independent output streams, reconstructs all 2,016 timed observations and 168 warmups, and parses the raw Callgrind and DHAT runs.

The timed commits, flags and complete commands are in each mode’s config and build records. The immutable former #93 port and new collector run the same driver on 1,269 groups. It exchanges the first and last case before every iteration and consumes the position, complete title/key lengths and source of every emitted row. Each process verifies its checksum, and a separate full transcript verifies exact identities/order. Net kernel time subtracts the zero-round group preload and divides by 128. Repeated reports subtract a zero-round decoded-input preload and divide by four. The complete-report gate covers all three captured and live outputs and repeated reports in both link modes.

The commit bundle follows the squash of the previous stack on main. The recorded benchmark baseline uses the PR revision of #93, whose tree is byte-identical to that squash. For a fresh run reproduce the compiler toolchains and native platform paths in the build records, then follow recipes/final-build.py, final-study.py and package.py. Full CLI/runtime sources and the dependency license are retained here. Native Codon uses its stock in-place list sort and its compiled assertion adapter in addition to the previously recorded native boundaries.

Ordinary and ThinLTO ran concurrently on separate non-sibling CPU cores (31 and 15), which have separate L1/L2 and share the guest L3. Each process and its child tools were pinned. The #93 PR commit can be fetched with `git fetch origin refs/pull/93/head`.

Recreate the bounded source bundles, including the deleted #93 branch, with `python3 recipes/pr-bundles.py /new/cache --proposal 94`. It fetches persistent GitHub pull refs into a new temporary bare repository and verifies the two frozen commits and the #93 squash tree.

A separate serial run interleaves both modes and Rust on CPU 31 alone. It checks the isolated collector and all three complete/repeated reports with eight balanced rounds. Its raw observations are in validation/serial-check.json.
