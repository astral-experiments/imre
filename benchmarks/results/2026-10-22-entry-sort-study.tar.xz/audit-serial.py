from collections import Counter
from pathlib import Path
from statistics import median
import hashlib,json,sys
assert not sys.flags.optimize
r=Path(__file__).resolve().parent
load=lambda p:json.loads((r/p).read_bytes())
h=lambda b:hashlib.sha256(b).hexdigest()
modes={k:load(k+'/results.json') for k in ('normal','thinlto')}
d=load('validation/serial-check.json')
assert {m['revision'] for m in modes.values()}=={d['revision']} and d['cpu']==31 and d['affinity']==[31] and d['samples']==8
groups=d['commands'];labels=set(groups);assert labels=={'after-normal','after-thinlto','rust-normal','rust-thinlto'}
allobs=d['observations'];ord=d['orders'];assert len(ord)==4 and all(set(row)==labels and len(row)==4 for row in ord)
assert all({row[i] for row in ord}==labels for i in range(4))
assert Counter(pair for row in ord for pair in zip(row,row[1:]))=={(a,b):1 for a in labels for b in labels if a!=b}
panels=set(modes['normal']['panels']);expected={'entries/0','entries/128'}|{p+'/'+t for p in panels for t in ('complete','preload','repeated')};assert set(allobs)==set(d['expected'])==set(d['repetitions'])==expected
gold=modes['normal']['inputs']['fixtures']['corpus'];med={};net={};rat={};warmup=timed=0
for panel,dump in allobs.items():
 section,typ=panel.split('/');reps=d['repetitions'][panel]
 if section=='entries':
  assert str(reps)==typ
  st=out=f"{gold['cases']} {gold['checksum']*reps}\n".encode();role='entries'
 else:
  report=(r/'inputs'/(section+'.md')).read_bytes()
  assert reps=={'complete':1,'preload':0,'repeated':4}[typ]
  st=b'' if typ=='complete' else f'{len(report.decode())*reps}\n'.encode()
  out=report if reps else b'';role='report' if typ=='complete' else 'compute'
 assert d['expected'][panel]=={'stdout':h(st),'output':h(out)}
 assert [v[0]for v in dump['warmup']]==ord[0][::-1]
 assert [[v[0]for v in row]for row in dump['runs']]==ord*2
 for obs in [*dump['warmup'],*(obs for row in dump['runs']for obs in row)]:
  lbl,ns,stdout,output=obs;assert ns>0 and stdout==h(st) and output==h(out)
 for lbl in labels:
  name,m=lbl.split('-');cfg=modes[m]['config'];pfx=cfg['engines'][name][role]
  cmd=groups[lbl][panel];assert cmd[:len(pfx)]==pfx
  idx={item['path']:item['sha256']for item in cfg['guarded_inputs']};assert d['binary_hashes'][cmd[0]]==idx[cmd[0]]
  if section=='entries':assert cmd[len(pfx):]==gold['arguments']+[str(reps),'checksum']
  else:
   captures=modes[m]['panels'][section]['captures'];args=['--manifest',captures['manifest']['path'],'--old',captures['old']['path'],'--new',captures['new']['path'],'--format',section.split('-')[1],'--force-summary-table'];args+=['--rounds',str(reps)] if role=='compute' else []
   assert cmd[len(pfx):-2]==args and cmd[-2]=='--output'
 med[panel]={lbl:median(v[1]for row in dump['runs']for v in row if v[0]==lbl)for lbl in labels};warmup+=4;timed+=32
assert med==d['medians_ns']
for k,control,reps in [('entries/128','entries/0',128),*((p+'/repeated',p+'/preload',4)for p in panels)]:
 net[k]={l:(med[k][l]-med[control][l])/reps for l in labels}
assert net==d['net_ns'] and all(x>0 for v in net.values() for x in v.values())
for name,v in {**{k:v for k,v in med.items() if k.endswith('/complete')},**net}.items():
 rat[name]={m:v['after-'+m]/v['rust-'+m]for m in modes}
assert rat==d['ratios'] and d['time_target_met']==all(x<=2 for k,v in rat.items() if not k.startswith('entries/')for x in v.values())
import tarfile
qa=r/'validation/local-qa.tar.gz'
with tarfile.open(qa) as t:
 qa_index=json.load(t.extractfile('qa-index.json')); assert qa_index['revision']==d['revision']
 files={i.name for i in t.getmembers() if i.isfile() and i.name!='qa-index.json'}
 assert files==set(qa_index['files'])
 for name,receipt in qa_index['files'].items():
  content=t.extractfile(name).read();assert len(content)==receipt['bytes'] and h(content)==receipt['sha256']
 suites=qa_index['suites'];assert suites['ordinary_exit_code']==suites['asan_exit_code']==0 and len(suites['names'])==37 and suites['llvm_optimization']==[0,3] and suites['sanitizers']==['address','leak']
print(json.dumps({'ratios':rat,'timed':timed,'warmups':warmup,'time_target_met':d['time_target_met'],'cpu':31,'qa_indexed_files':len(files),'local_qa_sha256':h(qa.read_bytes()),'raw_sha256':h((r/'validation/serial-check.json').read_bytes())}))
