from pathlib import Path
import json,subprocess,sys
p=Path(__file__).resolve().parent
assert not sys.flags.optimize
run=lambda name:json.loads(subprocess.check_output([sys.executable,"-B",p/name],cwd=p))
result=run("formal_replay.py")
result["serial_native_control"]=run("audit-serial.py")
print(json.dumps(result,indent=2))
