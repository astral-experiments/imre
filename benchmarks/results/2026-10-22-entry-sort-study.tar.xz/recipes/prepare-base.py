from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib, json, os, subprocess, sys

c = Path("/home/dev-user/.cache/relar/entry-sort-20261022")
prior = c.parent / "string-enums-20261022"
r = Path("/home/dev-user/code/oss/relar-entries-base-20261022")
seed = r.parent / "relar-enums-fix-9778ef2"
old = "490ff91eb4ac3d9af47e790259a7441bf8a6fa00"
base = "9778ef24b8e504da5402f4d8adef39e5b60e54a4"
s = c / "base"
s.mkdir(exist_ok=True)
py = "/home/dev-user/.local/bin/python3.14"
meta = json.loads((prior / "equivalence-9778ef2/core/build-record.json").read_bytes())
env = {
    **os.environ,
    **{k: meta["environment"][k] for k in ["RUSTUP_HOME", "RUSTC", "CARGO_BUILD_BUILD_DIR"]},
    "CARGO_TARGET_DIR": str(prior / "target-fix-9778ef2"),
    "CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST": "all",
    "CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST": "all",
}


def go(label, args, d=r):
    print("start", label, flush=True)
    with (s / (label + ".log")).open("wb") as f:
        subprocess.run(
            list(map(str, args)), cwd=d, stdout=f, stderr=subprocess.STDOUT, check=True, env=env
        )
    print("finish", label, flush=True)


def git(*args, d=seed):
    return subprocess.check_output(["git", *map(str, args)], cwd=d, text=True).strip()


assert (
    git("rev-parse", "--show-toplevel") == str(seed)
    and git("rev-parse", "--path-format=absolute", "--git-common-dir")
    == "/home/dev-user/code/oss/relar-workspaces-20261021/.git"
    and git("config", "user.email") == "charlie.r.marsh@gmail.com"
    and git("remote", "get-url", "origin") == "https://github.com/astral-sh/relar.git"
)
bundle = c / "base.bundle"
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == sys.argv[1]
git("bundle", "verify", bundle)
git("fetch", "--no-tags", "--no-write-fetch-head", bundle, "refs/heads/charlie/codex-string-enums")
git("merge-base", "--is-ancestor", base, old)
assert (
    git(
        "diff",
        "--name-only",
        base,
        old,
        "--",
        "Cargo.toml",
        "Cargo.lock",
        "crates",
        "examples/conformance_report",
        "stdlib",
    )
    == "examples/conformance_report/README.md"
)
go(
    "worktree",
    [
        "cargo",
        "+ohm",
        "worktree",
        "add",
        "--target-dir",
        c / "target-base",
        "-b",
        "charlie/entry-sort-baseline-study",
        r,
        old,
    ],
    seed,
)
assert git("rev-parse", "HEAD", d=r) == old and not git("status", "--porcelain", d=r)
env["CARGO_TARGET_DIR"] = str(c / "target-base")
go(
    "core",
    [
        py,
        "benchmarks/native_tools_build.py",
        "--toolchain",
        "ohm",
        "--modes",
        "normal",
        "thinlto",
        "--target-dir",
        c / "target-base",
        "--shared-build-dir",
        env["CARGO_BUILD_BUILD_DIR"],
        "--rustup-home",
        env["RUSTUP_HOME"],
        "--jobs",
        meta["environment"]["CARGO_BUILD_JOBS"],
        "--output",
        s / "core",
    ],
)


def program(mode):
    args = [
        py,
        "benchmarks/live_conformance_build.py",
        "--application",
        "conformance_report",
        "--core-build-record",
        s / "core/build-record.json",
        "--mode",
        mode,
        "--clang",
        "/usr/lib/llvm-18/bin/clang",
        "--output",
        s / mode,
    ]
    if mode == "thinlto":
        args += [
            "--lto-linker",
            "/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld",
        ]
    go(mode, args)


with ThreadPoolExecutor(2) as p:
    list(p.map(program, ["normal", "thinlto"]))
(s / "ready").write_text(old)
print("baseline ready", flush=True)
