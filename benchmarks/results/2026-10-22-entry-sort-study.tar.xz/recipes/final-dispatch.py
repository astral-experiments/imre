"""Transfer a single exact Git commit and launch one serial, frozen code/evidence pipeline."""

from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shlex, subprocess, sys, tarfile

c = Path("/home/dev-user/.cache/relar/entry-sort-20261022")
r = Path("/home/dev-user/code/oss/relar-entry-sort")
base = "27a2e2d4ae960e8524fb5530be85dd1f43437b0a"
rev = sys.argv[1]
sp = c / "recipes"
ssh = "/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh"
py = "/home/dev-user/.local/bin/python3.14"


def git(*args):
    return subprocess.check_output(["git", *map(str, args)], cwd=r, text=True).strip()


assert (
    git("rev-parse", "--show-toplevel") == str(r)
    and git("rev-parse", "--path-format=absolute", "--git-common-dir")
    == "/home/dev-user/code/oss/relar/.git"
    and git("config", "user.email") == "charlie.r.marsh@gmail.com"
)
assert rev == git("rev-parse", rev + "^{commit}") and git("merge-base", base, rev) == base
refs = git(
    "for-each-ref",
    "--points-at",
    rev,
    "--format=%(refname)",
    "refs/heads/charlie/codex-entry-sort",
).splitlines()
assert len(refs) == 1
ref = refs[0]
bundle = c / (rev + ".bundle")
git("bundle", "create", bundle, ref, "^231f19a")
assert git("bundle", "list-heads", bundle) == rev + " " + ref
files = {
    str(p.relative_to(c)): p
    for p in [
        bundle,
        *[
            sp / n
            for n in [
                "final-build.py",
                "configure.py",
                "final-study.py",
                "prepare-base.py",
                "final-dispatch.py",
                "package.py",
                "profile.py",
                "replay.py",
                "progress.py",
                "host.py",
                "README.md",
            ]
        ],
    ]
}
hashes = {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in files.items()}
tx = c / ("transfer-" + rev[:7] + ".tar")
with tarfile.open(tx, "w") as t:
    for dest, p in files.items():
        t.add(p, arcname=dest, recursive=False)
with tx.open("rb") as f:
    subprocess.run([ssh, "charlie-oss-8", "--", "tar", "-xf", "-", "-C", c], stdin=f, check=True)
verify = (
    "from pathlib import Path;import hashlib,json;c=Path("
    + repr(str(c))
    + ");h=json.loads("
    + repr(json.dumps(hashes))
    + ');assert all(hashlib.sha256((c/k).read_bytes()).hexdigest()==s for k,s in h.items());print("verified",len(h))'
)
subprocess.run([ssh, "charlie-oss-8", "--", py, "-c", verify], check=True)
stage = c / ("final-" + rev[:7])
cmds = [
    (
        [py, "-u", sp / "final-build.py", rev, ref, hashes[bundle.name]],
        c / ("build-" + rev[:7] + ".log"),
    ),
    ([py, "-u", sp / "final-study.py", rev], c / ("study-" + rev[:7] + ".log")),
    ([py, "-u", sp / "package.py", rev], c / ("package-" + rev[:7] + ".log")),
]
cmd = " && ".join(
    shlex.join(list(map(str, a))) + " > " + shlex.quote(str(p)) + " 2>&1" for a, p in cmds
)
subprocess.run(
    [ssh, "charlie-oss-8", "--", "tmux", "new-session", "-d", "-s", "entries-final-" + rev[:7], cmd],
    check=True,
)
print(
    json.dumps(
        {
            "source": rev,
            "bundle_sha256": hashes[bundle.name],
            "bundle_ref": ref,
            "utc": datetime.now(timezone.utc).isoformat(),
            "recipe_hashes": hashes,
        },
        indent=2,
    )
)
