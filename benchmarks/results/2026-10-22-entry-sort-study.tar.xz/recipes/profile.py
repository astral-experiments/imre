from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json, os, subprocess, sys

c = Path("/home/dev-user/.cache/relar/entry-sort-20261022")
dest = c / sys.argv[1]
dest.mkdir(exist_ok=True)
root = (
    Path("/home/dev-user/code/oss/relar-entries-" + sys.argv[1].split("/")[0])
    if sys.argv[1].startswith("final-")
    else Path("/home/dev-user/code/oss/relar-entries-base-20261022")
)
caps = Path(
    "/home/dev-user/.cache/relar-live-conformance-20261022/measurements-normal-2/changed-github/captures"
)
v = {x.split("=", 1)[0]: x.split("=", 1)[1] for x in sys.argv[2:]}


def profile(item):
    i, (label, exe) = item
    run = []
    for n in (0, 64):
        d = dest / (label + "-" + str(n))
        cmd = [
            "python3.14",
            str(root / "benchmarks/native_tools_profile.py"),
            "--binary",
            label + "=" + exe,
            "--cpu",
            str(4 + i),
            "--output",
            str(d),
            "--stdout",
            f"1269 {10247030*n}\n",
        ]
        keys = ["manifest.json", "old.json", "new.json"]
        for k in keys:
            cmd += ["--input", k + "=" + str(caps / k)]
        cmd += (
            ["--"]
            + ["--entries"]
            + keys
            + [str(n), "checksum"]
        )
        with (dest / (label + "-" + str(n) + ".log")).open("wb") as f:
            subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, check=True)
        run.append(json.loads((d / "summary.json").read_bytes())["runs"])
    cg0, cg1 = run[0][0], run[1][0]
    p0 = {f["name"]: f for f in cg0["functions"]}
    delta = [
        (
            f["self_instructions"] - p0.get(f["name"], {}).get("self_instructions", 0),
            f["calls"] - p0.get(f["name"], {}).get("calls", 0),
            f["name"],
        )
        for f in cg1["functions"]
    ]
    delta.sort(reverse=True)
    dh0, dh1 = run[0][1], run[1][1]
    return label, {
        "instructions_per_pass": (cg1["total_instructions"] - cg0["total_instructions"]) / 64,
        "allocations_per_pass": (dh1["totals"]["tbk"] - dh0["totals"]["tbk"]) / 64,
        "bytes_per_pass": (dh1["totals"]["tb"] - dh0["totals"]["tb"]) / 64,
        "top_self_delta": delta[:35],
    }


with ThreadPoolExecutor(len(v)) as ex:
    data = dict(ex.map(profile, enumerate(v.items())))
(dest / "delta.json").write_text(json.dumps(data, indent=2))
print(
    json.dumps({k: {h: q for h, q in d.items() if h != "top_self_delta"} for k, d in data.items()}),
    flush=True,
)
