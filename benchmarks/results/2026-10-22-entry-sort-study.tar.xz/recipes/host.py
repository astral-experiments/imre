from pathlib import Path
import hashlib, json, os, platform, shutil, subprocess, sys

c = Path("/home/dev-user/.cache/imre/entry-sort-20261022")
rev = sys.argv[1]
s = c / ("final-" + rev[:7])
os.sched_setaffinity(0, {7})


def run(argv):
    p = subprocess.run(argv, capture_output=True, text=True, check=True)
    return (p.stdout + p.stderr).strip()


def ident(p, args):
    p = Path(p).resolve()
    return {
        "path": str(p),
        "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        "version": run([p, *args]),
    }


sc = json.loads((s / "kernel-builds.json").read_bytes())
cfg = json.loads((s / "config-normal.json").read_bytes())
crec = json.loads((s / "build/core/build-record.json").read_bytes())
cod = json.loads((s / "build/codon-normal/build-record.json").read_bytes())
clang = sc["after-normal"]["clang"]["path"]
thin = sc["after-thinlto"]["lto_linker"]["path"]
cc = run([clang, "-print-prog-name=ld"])
ld = shutil.which(cc) if "/" not in cc else cc
lscpu = json.loads(run(["lscpu", "--json"]))["lscpu"]
fields = {x["field"].rstrip(":"): x["data"] for x in lscpu if x["data"] is not None}
top = Path("/sys/devices/system/cpu/cpu31/topology")
record = {
    "revision": rev,
    "cpu_pins": {"normal": 31, "thinlto": 15},
    "scheduling": "simultaneous mode runs; six engines serial and balanced within each mode",
    "per_mode_topology": {mode: {name: (Path(f"/sys/devices/system/cpu/cpu{cpu}") / rel).read_text().strip()
       for name,rel in {"thread_siblings":"topology/thread_siblings_list","physical_package":"topology/physical_package_id","core":"topology/core_id","shared_l3":"cache/index3/shared_cpu_list"}.items()}
       for mode,cpu in (("normal",31),("thinlto",15))},
    "host": platform.uname()._asdict(),
    "cpu_model": fields["Model name"],
    "cpu_details": fields,
    "topology": {
        p.name: p.read_text().strip()
        for p in [top / "thread_siblings_list", top / "physical_package_id", top / "core_id"]
        if p.is_file()
    },
    "clang": ident(clang, ["--version"]),
    "normal_linker": ident(ld, ["--version"]),
    "thinlto_linker": ident(thin, ["--version"]),
    "rustc": ident(crec["environment"]["RUSTC"], ["-vV"]),
    "codon": ident(cod["compiler"], ["--version"]),
    "cpython": ident(cfg["engines"]["cpython"]["entries"][0], ["--version"]),
    "native_elf_comments": {},
}
for mode in ["normal", "thinlto"]:
    m = json.loads((s / ("config-" + mode + ".json")).read_bytes())
    for name in ["before", "after", "rust", "codon"]:
        binary = m["engines"][name]["entries"][0]
        record["native_elf_comments"][name + "-" + mode] = run(
            ["readelf", "-p", ".comment", binary]
        )
(s / "host.json").write_text(json.dumps(record, indent=2) + "\n")
print(
    record["cpu_model"],
    record["clang"]["version"].splitlines()[0],
    record["normal_linker"]["version"].splitlines()[0],
    record["thinlto_linker"]["version"].splitlines()[0],
    flush=True,
)
