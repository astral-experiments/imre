"""Check the source-locked enum workload, time each mode in order, retain profiles and error cases."""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import fcntl, hashlib, json, os, runpy, shutil, subprocess, sys, time

c = Path("/home/dev-user/.cache/relar/entry-sort-20261022")
rev = sys.argv[1]
s = c / ("final-" + rev[:7])
build = s / "build"
r = Path("/home/dev-user/code/oss/relar-entries-final-" + rev[:7])
base = r.parent / "relar-entries-base-20261022"
py = "/home/dev-user/.local/bin/python3.14"
prior = Path("/home/dev-user/.cache/relar-live-conformance-20261022")
caps = prior / "measurements-normal-2/changed-github/captures"
vpy = prior / "python-venv/bin/python"
read = lambda p: json.loads(Path(p).read_bytes())


def sha(p):
    with Path(p).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def save(p, v):
    p.write_text(json.dumps(v, indent=2) + "\n")


def run(k, argv, tolerant=False):
    print(datetime.now(timezone.utc).isoformat(), "start", k, flush=True)
    with (s / (k + ".log")).open("wb") as f:
        q = subprocess.run(list(map(str, argv)), cwd=r, stdout=f, stderr=subprocess.STDOUT)
    print(datetime.now(timezone.utc).isoformat(), "finish", k, q.returncode, flush=True)
    if not tolerant:
        q.check_returncode()
    return q.returncode


assert (s / "ready").read_text().strip() == rev


def clean():
    for source, head in ((r, rev), (base, "490ff91eb4ac3d9af47e790259a7441bf8a6fa00")):
        assert subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=source, text=True
        ).strip() == head and not subprocess.check_output(
            ["git", "status", "--porcelain"], cwd=source
        )


lock = (c / "official-cpu15-cpu31.lock").open("a")
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
clean()
try:
    val = runpy.run_path(str(r / "benchmarks/conformance_validate.py"))
    h = runpy.run_path(str(r / "benchmarks/conformance_classification_upstream.py"))
    d = s / "validation"
    d.mkdir()
    env = val["environment"](d / "home")
    env["PYTHONPATH"] = ""
    (d / "home").mkdir()
    inputs = [str(caps / (k + ".json")) for k in ["manifest", "old", "new"]]
    work = val["Workload"](*map(Path, inputs))
    gold, dist = h["snapshot"](val, work, kernel="entries")
    (d / "expected.captures").write_bytes(gold)
    counts = gold.splitlines()[-1:]
    assert len(gold.splitlines()) == 250
    cfgs = {m: read(s / ("config-" + m + ".json")) for m in ("normal", "thinlto")}
    checks = {
        "revision": rev,
        "cases": 1269,
        "distribution": dist,
        "stats": [v.decode() for v in counts],
        "oracle_sha256": hashlib.sha256(gold).hexdigest(),
        "modes": {},
        "targets": {},
    }

    def checkcmd(cmd, expected, where, custom=env):
        x = subprocess.run(list(map(str, cmd)), env=custom, capture_output=True, cwd=d, timeout=180)
        assert x.returncode == 0 and not x.stderr and x.stdout == expected, (
            cmd,
            x.returncode,
            x.stderr[-1400:],
            x.stdout[:140],
        )
        where.write_bytes(x.stdout)
        return {"command": list(map(str, cmd)), "stdout_sha256": sha(where)}

    p = r / "benchmarks/codon_native/enum_probe.py"
    prefix = [
        vpy,
        "-P",
        "-B",
        "-c",
        'import runpy,sys;sys.path.insert(0,sys.argv.pop(1));entry=sys.argv.pop(1);runpy.run_path(entry,run_name="__main__")',
        r / "examples",
        p,
    ]
    member = subprocess.check_output(prefix, env=env)
    (d / "members.txt").write_bytes(member)
    for mode, cfg in cfgs.items():
        place = d / mode
        place.mkdir()
        outputs = {}
        for e, v in cfg["engines"].items():
            outputs[e] = checkcmd(
                v["entries"] + inputs + ["1", "dump"], gold, place / (e + ".captures")
            )
        outputs["member-probe"] = checkcmd(
            [build / ("codon-" + mode) / "conformance_report-enum-probe"],
            member,
            place / "members.txt",
        )
        checks["modes"][mode] = outputs
    asan = {**env, "ASAN_OPTIONS": "detect_leaks=1:halt_on_error=1"}
    checks["asan"] = checkcmd(
        [build / "after-asan-kernel", "--entries", *inputs, "1", "dump"], gold, d / "asan.captures", asan
    )
    for panel in ["unchanged-github", "changed-github", "changed-diff"]:
        loc = prior / ("measurements-normal-2/" + panel + "/captures")
        work = val["Workload"](
            loc / "manifest.json", loc / "old.json", loc / "new.json", panel.split("-")[1]
        )
        report = val["oracle"](work).report.encode()
        checks["targets"][panel] = {}
        for mode, cfg in cfgs.items():
            cmds = cfg["engines"]
            for e, v in cmds.items():
                dest = d / mode / (e + "-" + panel + ".md")
                cmd = v["report"] + work.arguments() + ["--output", str(dest)]
                q = subprocess.run(cmd, cwd=d, env=env, capture_output=True)
                assert (
                    not q.returncode
                    and not q.stderr
                    and not q.stdout
                    and dest.read_bytes() == report
                ), (e, q.stderr[-1000:])
                checks["targets"][panel][e + "-" + mode] = sha(dest)
        dest = d / ("asan-" + panel + ".md")
        q = subprocess.run(
            [build / "relar-asan/conformance-report", *work.arguments(), "--output", dest],
            cwd=d,
            env=asan,
            capture_output=True,
        )
        assert not q.returncode and not q.stderr and not q.stdout and dest.read_bytes() == report
        checks["targets"][panel]["asan"] = sha(dest)
    save(d / "checks.json", checks)
    print("all native/CPython entry and report outputs verified", flush=True)
    def measure(mode):
        out = s / mode
        argv = [
            py,
            "-u",
            "benchmarks/conformance_regex_benchmark.py",
            "--kernel",
            "entries",
            "--kernel-rounds",
            "128",
            "--report-rounds",
            "4",
            "--samples",
            "12",
            "--cpu",
            str(31 if mode == "normal" else 15),
            "--captures",
            caps,
            "--config",
            s / ("config-" + mode + ".json"),
            "--output",
            out,
        ]
        code = run("matrix-" + mode, argv, tolerant=True)
        m = read(out / "results.json")
        assert m["completed"] and (code == 0) == m["time_target_met"]
        checks[mode + "_passed"] = m["time_target_met"]
        if m["time_target_met"]:
            run(
                "audit-" + mode,
                [
                    py,
                    "benchmarks/conformance_regex_audit.py",
                    out / "results.json",
                    "--strict-files",
                    "--source-root",
                    r,
                ],
            )
            shutil.copy2(s / ("audit-" + mode + ".log"), out / "audit-strict.json")
        (out / "ready").write_text(sha(out / "results.json") + "\n")
    with ThreadPoolExecutor(2) as pool:
        list(pool.map(measure, ("normal", "thinlto")))
    cfg = cfgs["normal"]["engines"]
    run(
        "profile",
        [
            py,
            "-u",
            c / "recipes/profile.py",
            "final-" + rev[:7] + "/profiles",
            *[e + "=" + cfg[e]["entries"][0] for e in ("before", "after", "rust")],
        ],
    )
    run(
        "boundary-validation",
        [
            vpy,
            "-u",
            "benchmarks/conformance_validate.py",
            "--python",
            vpy,
            "--binary",
            build / "relar-normal/conformance-report",
            "--compute-binary",
            build / "relar-normal/conformance-report-compute",
            "--rust-binary",
            build / "rust-normal/conformance-report-reference",
            "--codon-binary",
            build / "codon-normal/conformance_report",
            "--codon-compute-binary",
            build / "codon-normal/conformance_report-compute",
            "--retain-dir",
            d / "boundaries",
        ],
    )
    run("host", [py, c / "recipes/host.py", rev])
    clean()
    v = read(s / "verified-builds.json")
    assert all(sha(k) == a["sha256"] for k, a in v["guarded"].items())
    save(d / "checks.json", checks)
    assert all(
        checks[m + "_passed"] for m in cfgs
    ), "specified Rust target missed; both full raw matrices retained"
    (s / "finished").write_text(datetime.now(timezone.utc).isoformat())
except BaseException:
    (s / "failed").write_text(datetime.now(timezone.utc).isoformat())
    raise
