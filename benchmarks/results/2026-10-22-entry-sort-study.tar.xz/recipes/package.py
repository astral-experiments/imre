"""Archive immutable source, case/report bytes, raw samples, native traces, validations and replay."""

from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys, tarfile, tempfile

c = Path("/home/dev-user/.cache/imre/entry-sort-20261022")
rev = sys.argv[1]
s = c / ("final-" + rev[:7])
r = Path("/home/dev-user/code/oss/imre-entries-final-" + rev[:7])
base = r.parent / "imre-entries-base-20261022"
assert (s / "finished").exists()
load = lambda p: json.loads(Path(p).read_bytes())
files = {}


def add(name, p):
    p = Path(p)
    assert p.is_file(), p
    if name in files:
        assert files[name].read_bytes() == p.read_bytes(), name
    else:
        files[name] = p


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


for k in ["host.json", "verified-builds.json", "kernel-builds.json"]:
    add("builds/" + k, s / k)
for name, src in [
    ("before-core", c / "base/core"),
    ("after-core", s / "build/core"),
    ("after-asan", s / "build/imre-asan"),
]:
    add("builds/" + name + "/build-record.json", src / "build-record.json")
for label, info in load(s / "kernel-builds.json").items():
    add("builds/ir/" + label + ".ll", info["llvm"]["path"])
for mode in ["normal", "thinlto"]:
    m = load(s / mode / "results.json")
    add(mode + "/results.json", s / mode / "results.json")
    add(mode + "/audit-strict.json", s / mode / "audit-strict.json")
    add(mode + "/config.json", s / ("config-" + mode + ".json"))
    for label, i in m["config"]["build_records"].items():
        add("builds/" + label + "-" + mode + "/build-record.json", i["path"])
    for f in m["inputs"]["test_files"]:
        add("inputs/suite/" + Path(f["path"]).name, f["path"])
    add("inputs/corpus.captures", m["inputs"]["fixtures"]["corpus"]["capture_oracle"]["path"])
    for name, v in m["panels"].items():
        add("inputs/" + name + ".md", v["expected_report"]["path"])
        add("inputs/" + name + "/preparation.json", v["preparation"]["path"])
        for k, f in v["captures"].items():
            add("inputs/" + name + "/" + k + ".json", f["path"])
    for p in (s / "build" / ("codon-" + mode)).rglob("*.codon"):
        add(
            "builds/codon-"
            + mode
            + "/generated/"
            + str(p.relative_to(s / "build" / ("codon-" + mode))),
            p,
        )
for label, src in [("before", base), ("after", r)]:
    parts = [
        "Cargo.toml",
        "Cargo.lock",
        "crates",
        "stdlib",
        "examples/conformance_report",
        "benchmarks/reference/conformance_report",
        "benchmarks/codon_native",
        "benchmarks/native_platform",
        "benchmarks/native_tools_build.py",
        "benchmarks/native_tools_benchmark.py",
        "benchmarks/native_tools_profile.py",
        "benchmarks/dependency_profile.py",
        "benchmarks/conformance_classification.py",
        "benchmarks/conformance_classification_upstream.py",
        "benchmarks/conformance_regex_benchmark.py",
        "benchmarks/conformance_regex_audit.py",
        "benchmarks/conformance_validate.py",
        "benchmarks/live_conformance_build.py",
        "benchmarks/live_conformance_benchmark.py",
        "benchmarks/live_conformance_validate.py",
        "LICENSE-APACHE",
        "LICENSE-MIT",
    ]
    for q in subprocess.check_output(["git", "ls-files", "-z", "--", *parts], cwd=src).split(b"\0"):
        if q:
            add("sources/" + label + "/" + q.decode(), src / q.decode())
for p in (s / "validation").rglob("*"):
    if not p.is_file():
        continue
    rel = p.relative_to(s / "validation")
    if "boundaries" in rel.parts:
        if p.name not in ("record.json", "provenance.json"):
            continue
    add("validation/" + str(rel), p)
for p in (s / "profiles").rglob("*"):
    if p.is_file() and (
        p.suffix in (".trace", ".log")
        or p.name in ("provenance.json", "summary.json", "delta.json")
    ):
        add("profiles/" + str(p.relative_to(s / "profiles")), p)
for name in (
    "final-dispatch.py",
    "prepare-base.py",
    "final-build.py",
    "configure.py",
    "final-study.py",
    "profile.py",
    "host.py",
    "package.py",
):
    add("recipes/" + name, c / "recipes" / name)
add("builds/changes.bundle", c / (rev + ".bundle"))
add("licenses/typing-LICENSE", "/home/dev-user/code/oss/typing-imre-live-20261022/LICENSE")
add("README.md", c / "recipes/README.md")
add("replay.py", c / "recipes/replay.py")
idx = {
    "schema": 1,
    "revision": rev,
    "baseline_revision": "490ff91eb4ac3d9af47e790259a7441bf8a6fa00",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "files": {k: {"sha256": sha(p), "bytes": p.stat().st_size} for k, p in sorted(files.items())},
}
index = s / "manifest.json"
index.write_text(json.dumps(idx, indent=2) + "\n")
add("manifest.json", index)
out = s / "evidence.tar.xz"
with tarfile.open(out, "w:xz", preset=6) as t:
    for k, p in sorted(files.items()):
        t.add(p, arcname=k, recursive=False)
with tempfile.TemporaryDirectory(dir=s) as temp:
    with tarfile.open(out) as t:
        t.extractall(temp, filter="data")
    raw = subprocess.check_output([sys.executable, "-B", str(Path(temp) / "replay.py")], cwd=temp)
    (s / "portable-audit.json").write_bytes(raw)
print(len(idx["files"]), out.stat().st_size, sha(out), flush=True)
