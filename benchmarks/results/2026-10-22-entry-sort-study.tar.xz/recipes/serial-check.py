"""Compare frozen Relar and Rust on one otherwise idle core at both link modes."""
from pathlib import Path
from statistics import median
from collections import Counter
import argparse, hashlib, json, os, runpy, subprocess, time
sha=lambda data:hashlib.sha256(data).hexdigest()
p=argparse.ArgumentParser();p.add_argument('stage',type=Path);a=p.parse_args();stage=a.stage.resolve();revision=(stage/'ready').read_text().strip()
assert (stage/'portable-audit.json').is_file()
cfg={mode:json.loads((stage/('config-'+mode+'.json')).read_bytes()) for mode in ('normal','thinlto')}
matrix={mode:json.loads((stage/mode/'results.json').read_bytes()) for mode in cfg}
root=Path(cfg['normal']['source_root']);vl=runpy.run_path(str(root/'benchmarks/conformance_validate.py'))
labels=['after-normal','rust-normal','after-thinlto','rust-thinlto']
order=[[labels[(i+j)%4] for j in (0,1,-1,2)] for i in range(4)]
assert Counter(pair for r in order for pair in zip(r,r[1:]))=={(a,b):1 for a in labels for b in labels if a!=b}
dst=stage/'extra-serial';dst.mkdir();env=vl['environment'](dst);os.sched_setaffinity(0,{31})
g=matrix['normal']['inputs']['fixtures']['corpus'];panels=matrix['normal']['panels'];ks=['entries','complete','repeated']
commands={};expected={};reps_by={};obs={}
for label in labels:
 engine,mode=label.split('-');cmds=cfg[mode]['engines'][engine];commands[label]={}
 def command(name,base,paths,rounds,op,report=None):
  if name not in reps_by:reps_by[name]=rounds
  cmd=cmds[base]+paths;dest=str(dst/(label+'.txt'))
  if op=='entries':cmd+=[str(rounds),'checksum'];stdout=f"{g['cases']} {g['checksum']*rounds}\n".encode();output=stdout
  else:
   if base=='compute':cmd+=['--rounds',str(rounds)]
   cmd+=['--output',dest];stdout=f"{len(report.decode())*rounds}\n".encode() if base=='compute' else b'';output=b'' if rounds==0 else report
  commands[label][name]=cmd;expected[name]={'stdout':sha(stdout),'output':sha(output)}
 for n in [0,128]:command('entries/'+str(n),'entries',g['arguments'],n,'entries')
 for panel,d in panels.items():
  md=Path(d['expected_report']['path']).read_bytes()
  w=vl['Workload'](*(Path(d['captures'][v]['path']) for v in ('manifest','old','new')),panel.split('-')[1])
  for op,num in [('complete',1),('preload',0),('repeated',4)]:command(panel+'/'+op,'report' if op=='complete' else 'compute',w.arguments(),num,'report',md)
for name in reps_by:
 rows=[]
 for i,r in enumerate([order[0][::-1],*(order*2)]):
  row=[]
  for label in r:
   cmd=commands[label][name];out=dst/(label+'.txt');out.write_bytes(b'guard');start=time.perf_counter_ns();cp=subprocess.run(cmd,cwd=dst,env=env,capture_output=True,timeout=120);dt=time.perf_counter_ns()-start
   h=sha(cp.stdout);o=h if name.startswith('entries/') else sha(out.read_bytes());assert cp.returncode==0 and not cp.stderr and {'stdout':h,'output':o}==expected[name],(name,label,cp.stderr[-200:])
   row.append([label,dt,h,o])
  rows.append(row)
 obs[name]={'warmup':rows[0],'runs':rows[1:]}
med={n:{e:median(v[1] for row in rec['runs'] for v in row if v[0]==e)for e in labels}for n,rec in obs.items()}
net={name:{e:(med[name][e]-med[base][e])/n for e in labels}for name,base,n in [('entries/128','entries/0',128),*((p+'/repeated',p+'/preload',4)for p in panels)]}
rat={p:{m:med[p]['after-'+m]/med[p]['rust-'+m] for m in cfg}for p in med if p.endswith('/complete')}
rat.update({p:{m:v['after-'+m]/v['rust-'+m] for m in cfg}for p,v in net.items()})
d={'revision':revision,'cpu':31,'binary_hashes':{cmd[0]:sha(Path(cmd[0]).read_bytes()) for cmds in commands.values()for cmd in cmds.values()},'commands':commands,'expected':expected,'orders':order,'affinity':sorted(os.sched_getaffinity(0)),'samples':8,'repetitions':reps_by,'observations':obs,'medians_ns':med,'net_ns':net,'ratios':rat,'time_target_met':all(v<=2 for k,modes in rat.items() if not k.startswith('entries/') for v in modes.values())}
(stage/'serial-check.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(rat),flush=True);assert d['time_target_met']
