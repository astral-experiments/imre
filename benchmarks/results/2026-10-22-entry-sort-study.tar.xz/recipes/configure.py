from pathlib import Path
import argparse, hashlib, json, os, subprocess

p = argparse.ArgumentParser()
p.add_argument("root", type=Path)
p.add_argument("oldroot", type=Path)
p.add_argument("mode")
p.add_argument("oldprograms", type=Path)
p.add_argument("newprograms", type=Path)
p.add_argument("oldscan", type=Path)
p.add_argument("newscan", type=Path)
p.add_argument("rustdir", type=Path)
p.add_argument("codondir", type=Path)
p.add_argument("dest", type=Path)
p.add_argument("--fresh", action="store_true")
a = p.parse_args()
f = Path("/home/dev-user/.cache/imre-live-conformance-20261022")
record = json.loads((f / "measurements-normal-2/benchmark.json").read_bytes())
py = str(f / "python-venv/bin/python")


def prefix(root, entry):
    return [
        py,
        "-P",
        "-s",
        "-B",
        "-c",
        'import runpy,sys; root=sys.argv.pop(1); entry=sys.argv.pop(1); sys.path[:0]=[root+"/examples",root+"/stdlib"];sys.argv[0]=entry;runpy.run_path(entry,run_name="__main__")',
        str(root),
        str(entry),
    ]


app = a.root / "examples/conformance_report"
refs = a.rustdir / "conformance-report-reference"
cod = a.codondir


def rel(progs, scan):
    return {
        "entries": [str(scan), "--entries"],
        "report": [str(progs / "conformance-report")],
        "compute": [str(progs / "conformance-report-compute")],
        "live": [str(progs / "conformance-report")],
    }


cmds = {
    "upstream": {
        "entries": prefix(a.root, a.root / "benchmarks/conformance_classification_upstream.py") + ["--entries"],
        "report": [py, "-P", "-s", "-B", str(app / "original.py")],
        "compute": [py, "-P", "-s", "-B", str(app / "original.py"), "--compute"],
        "live": [py, "-s", "-B", str(app / "original_live.py")],
    },
    "cpython": {
        "entries": prefix(a.root, a.root / "benchmarks/conformance_classification.py") + ["--entries"],
        "report": prefix(a.root, app / "__main__.py"),
        "compute": prefix(a.root, app / "compute.py"),
        "live": prefix(a.root, app / "__main__.py"),
    },
    "before": rel(a.oldprograms, a.oldscan),
    "after": rel(a.newprograms, a.newscan),
    "codon": {
        "entries": [str(cod / "conformance_report-classification"), "--entries"],
        "report": [str(cod / "conformance_report")],
        "compute": [str(cod / "conformance_report-compute")],
        "live": [str(cod / "conformance_report")],
    },
    "rust": {
        "entries": [str(refs), "--entries"],
        "report": [str(refs)],
        "compute": [str(refs), "--compute"],
        "live": [str(refs)],
    },
}
live_args = {}
for v in record["workloads"]:
    if v["name"].endswith("/live"):
        args = v["arguments"][:]
        i = args.index("--output")
        del args[i : i + 2]
        live_args[v["name"].split("/")[0]] = args
args = live_args["changed-github"]


def rev(root):
    return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()


def fileid(p):
    return {
        "path": str(p),
        "bytes": p.stat().st_size,
        "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
    }


paths = {
    Path(py),
    a.root / "benchmarks/conformance_classification.py",
    a.root / "benchmarks/conformance_classification_upstream.py",
    a.root / "benchmarks/conformance_regex_benchmark.py",
    a.root / "benchmarks/conformance_validate.py",
    Path(args[args.index("--old-ty") + 1]),
    Path(args[args.index("--new-ty") + 1]),
}
for root in (a.root, a.oldroot):
    for sub in ("examples/conformance_report", "stdlib/imre"):
        paths.update((root / sub).rglob("*.py"))
builds = {}
for label, directory in [
    ("before", a.oldprograms),
    ("after", a.newprograms),
    ("codon", a.codondir),
    ("rust", a.rustdir),
]:
    rec = directory / "build-record.json"
    d = json.loads(rec.read_bytes())
    assert d.get("status", "passed") == "passed"
    paths.add(rec)
    builds[label] = fileid(rec)
    if label in ("before", "after"):
        for k in ("compiler", "runtime", "core_build_record"):
            paths.add(Path(d[k]["path"]))
        for x in d["tools"].values():
            paths.add(Path(x["path"]))
        assert all(fileid(Path(i["path"]))["sha256"] == i["sha256"] for i in d["binaries"].values())
    if label == "codon":
        for k in ("compiler", "native_json", "native_re", "native_enum", "native_platform"):
            item = d[k]
            paths.add(Path(item["path"] if isinstance(item, dict) else item))
        for item in d["libraries"].values():
            paths.add(Path(item["path"]))
for group in cmds.values():
    for cmd in group.values():
        paths.add(Path(cmd[0]))
libraries = {}
for exe in sorted(
    {
        Path(command[0])
        for kind in ("before", "after", "codon", "rust")
        for command in cmds[kind].values()
    }
):
    deps = set()
    for line in subprocess.check_output(["ldd", str(exe)], text=True).splitlines():
        parts = line.strip().split()
        a_path = next((Path(s) for s in parts if s.startswith("/")), None)
        if a_path:
            deps.add(a_path.resolve())
    assert all("libpython" not in p.name for p in deps)
    paths.update(deps)
    libraries[str(exe)] = {str(q): fileid(q)["sha256"] for q in sorted(deps)}
if a.fresh:
    assert all(
        not subprocess.check_output(["git", "status", "--porcelain"], cwd=r, text=True).strip()
        for r in [a.root, a.oldroot]
    )
    for label, root in [("before", a.oldroot), ("after", a.root)]:
        d = json.loads(Path(builds[label]["path"]).read_bytes())
        assert d["source_matches_revision"] and d["revision"] == rev(root)
    x = a.dest.parent / "kernel-builds.json"
    assert x.is_file()
    paths.add(x)
config = {
    "schema": 1,
    "revision": rev(a.root),
    "baseline_revision": rev(a.oldroot),
    "mode": a.mode,
    "source_locked": a.fresh,
    "source_root": str(a.root),
    "baseline_source_root": str(a.oldroot),
    "engines": cmds,
    "live_arguments": live_args,
    "build_records": builds,
    "linked_libraries": libraries,
    "guarded_inputs": [fileid(v) for v in sorted(paths)],
}
a.dest.write_text(json.dumps(config, indent=2) + "\n")
