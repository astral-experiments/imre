"""Recreate the two study bundles from GitHub pull refs and exact commit IDs."""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse, subprocess
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--proposal',type=int,required=True);arg=p.parse_args()
arg.output.mkdir(exist_ok=True,parents=True)
old='490ff91eb4ac3d9af47e790259a7441bf8a6fa00';new='918e77728b7afdadb5ab1d63f785cb2c291482b8';main='27a2e2d4ae960e8524fb5530be85dd1f43437b0a'
with TemporaryDirectory() as temp:
 def git(*args):return subprocess.check_output(['git','-C',temp,*map(str,args)],text=True).strip()
 git('init','--bare')
 git('fetch','--no-tags','https://github.com/astral-sh/imre.git','refs/pull/93/head:refs/benchmarks/pr93',f'refs/pull/{arg.proposal}/head:refs/benchmarks/proposal')
 assert git('rev-parse','refs/benchmarks/pr93')==old
 git('merge-base','--is-ancestor',new,'refs/benchmarks/proposal')
 assert git('rev-parse',old+'^{tree}')==git('rev-parse',main+'^{tree}')
 for sha,branch,filename,prior in [(old,'charlie/codex-string-enums','base.bundle','9778ef24b8e504da5402f4d8adef39e5b60e54a4'),(new,'charlie/codex-entry-sort',new+'.bundle','231f19a')]:
  git('branch',branch,sha);dest=arg.output.resolve()/filename
  assert not dest.exists()
  git('bundle','create',dest,'refs/heads/'+branch,'^'+prior)
  assert git('bundle','list-heads',dest)==sha+' refs/heads/'+branch
  print(dest,sha)
