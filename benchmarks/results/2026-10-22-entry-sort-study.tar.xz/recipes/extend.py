"""Add independent serial native control to the complete, source-validated measurement export."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib,json,shutil,subprocess,sys,tarfile
s=Path(sys.argv[1]).resolve();rec=Path(__file__).parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with TemporaryDirectory(dir=s)as t:
 r=Path(t)
 with tarfile.open(s/'evidence.tar.xz') as a:a.extractall(r,filter='data')
 (r/'replay.py').rename(r/'formal_replay.py')
 shutil.copy2(s/'serial-check.json',r/'validation/serial-check.json')
 shutil.copy2(rec/'pr-bundles.py',r/'recipes/pr-bundles.py');shutil.copy2(rec/'serial-check.py',r/'recipes/serial-check.py');shutil.copy2(rec/'audit-serial.py',r/'audit-serial.py');shutil.copy2(__file__,r/'recipes/extend.py')
 if len(sys.argv)>2:
  qa=Path(sys.argv[2]).resolve(strict=True)
  assert h(qa)=='50bce05c8eb81aaf33613ff9f4d5813aeb35b2c5d20bc7731d04c54a9d34968a' and qa.stat().st_size==22437
  shutil.copy2(qa,r/'validation'/'local-qa.tar.gz')
  (r/'validation'/'local-qa-sha256.txt').write_text(h(qa)+'\n')
 (r/'replay.py').write_text('from pathlib import Path\nimport json,subprocess,sys\np=Path(__file__).resolve().parent\nassert not sys.flags.optimize\nrun=lambda name:json.loads(subprocess.check_output([sys.executable,"-B",p/name],cwd=p))\nresult=run("formal_replay.py")\nresult["serial_native_control"]=run("audit-serial.py")\nprint(json.dumps(result,indent=2))\n')
 (r/'README.md').write_text((r/'README.md').read_text()+'\nRecreate the bounded source bundles, including the deleted #93 branch, with `python3 recipes/pr-bundles.py /new/cache --proposal 94`. It fetches persistent GitHub pull refs into a new temporary bare repository and verifies the two frozen commits and the #93 squash tree.\n\nA separate serial run interleaves both modes and Rust on CPU 31 alone. It checks the isolated collector and all three complete/repeated reports with eight balanced rounds. Its raw observations are in validation/serial-check.json.\n')
 idx=json.loads((r/'manifest.json').read_text());idx['original_formal_export_sha256']=h(s/'evidence.tar.xz')
 idx['files']={str(p.relative_to(r)):{'sha256':h(p),'bytes':p.stat().st_size}for p in sorted(r.rglob('*')) if p.is_file() and p!=r/'manifest.json'}
 (r/'manifest.json').write_text(json.dumps(idx,indent=2)+'\n')
 final=s/'publication-study.tar.xz'
 with tarfile.open(final,'w:xz',preset=6)as a:
  for p in sorted(r.rglob('*')):
   if p.is_file():a.add(p,arcname=str(p.relative_to(r)),recursive=False)
 j=json.loads(subprocess.check_output([sys.executable,'-B',r/'replay.py'],cwd=r))
 (s/'publication-audit.json').write_text(json.dumps(j,indent=2)+'\n')
 print(final.stat().st_size,h(final),j['serial_native_control']['timed'])
