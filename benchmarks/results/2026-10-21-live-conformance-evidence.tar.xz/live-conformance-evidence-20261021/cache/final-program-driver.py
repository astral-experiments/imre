from pathlib import Path
import concurrent.futures,json,subprocess
cache=Path("/home/dev-user/.cache/imre-live-conformance-20261022")
repo=Path("/home/dev-user/code/oss/imre-live-conformance-20261022")
linker="/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld"
assert Path(linker).is_file()
def build(mode):
    command=[str(cache/"python-venv/bin/python"),str(repo/"benchmarks/live_conformance_build.py"),"--core-build-record",str(cache/"final-core-1/build-record.json"),"--mode",mode,"--clang","/usr/lib/llvm-18/bin/clang","--output",str(cache/("final-programs-"+mode+"-1"))]
    if mode=="thinlto":command += ["--lto-linker",linker]
    with (cache/("final-programs-"+mode+".log")).open("w") as output:
        result=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
    return {"mode":mode,"returncode":result.returncode,"command":command}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(build,["normal","thinlto","asan"]))
(cache/"final-program-exit.json").write_text(json.dumps(results,indent=2)+"\n")
