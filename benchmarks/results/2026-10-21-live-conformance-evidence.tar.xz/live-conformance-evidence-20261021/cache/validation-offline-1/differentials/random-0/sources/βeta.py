# E: comment only
x() # E?: unicode
x() # E[bad++]
x() # E[mixed]
x() # E?[mixed]
x()
