
## [Typing conformance results](https://github.com/python/typing/blob/835b70f3f795f8e061b1f7621178515b0a77a0ad/conformance/)

The percentage of diagnostics emitted that were expected errors held steady at <b>100.00%</b>. The percentage of expected errors that received a diagnostic held steady at <b>50.00%</b>. The number of fully passing files held steady at <b>1/2</b>.

### Summary

<details>
<summary>How are test cases classified?</summary>

<br>

Each test case represents one expected error annotation or a group of annotations sharing a tag. Counts are per test case, not per diagnostic — multiple diagnostics on the same line count as one. Required annotations (`E`) are true positives when ty flags the expected location and false negatives when it does not. Optional annotations (`E?`) are true positives when flagged but true negatives (not false negatives) when not. Tagged annotations (`E[tag]`) require ty to flag exactly one of the tagged lines; tagged multi-annotations (`E[tag+]`) allow any number up to the tag count. Flagging unexpected locations counts as a false positive.

</details>

| Metric | Old | New | Diff | Outcome |
|--------|-----|-----|------|---------|
| True Positives  | 1 | 1 | +0 |  |
| False Positives | 0 | 0 | +0 |  |
| False Negatives | 1 | 1 | +0 |  |
| Total Diagnostics | 1 | 1 | +0 |  |
| Precision | 100.00% | 100.00% | +0.00% |  |
| Recall | 50.00% | 50.00% | +0.00% |  |
| Passing Files | 1/2 | 1/2 | +0 |  |

