previous complete report must survive
