value: int = "x"  # E: incompatible
