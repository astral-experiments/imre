other: int = "x"  # E: stub
