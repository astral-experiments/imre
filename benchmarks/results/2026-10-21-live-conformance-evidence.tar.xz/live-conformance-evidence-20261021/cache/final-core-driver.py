import json, os, subprocess
from pathlib import Path
cache=Path("/home/dev-user/.cache/relar-live-conformance-20261022")
repo=Path("/home/dev-user/code/oss/relar-live-conformance-20261022")
command=["/home/dev-user/.local/bin/python3.14",str(repo/"benchmarks/native_tools_build.py"),"--toolchain","ohm","--target-dir",str(cache/"target"),"--shared-build-dir","/home/dev-user/.cache/relar/ohm-build-1.98.1-1","--rustup-home","/home/dev-user/.cache/relar-native-tools-20261021/rustup","--output",str(cache/"final-core-1"),"--jobs","4","--modes","normal","thinlto","asan"]
with (cache/"final-core-driver.log").open("w") as output:
    result=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
(cache/"final-core-exit.json").write_text(json.dumps({"returncode":result.returncode,"command":command})+"\n")
