from pathlib import Path
import datetime,json,os,platform,subprocess
cache=Path('/home/dev-user/.cache/relar-live-conformance-20261022')
repo=Path('/home/dev-user/code/oss/relar-live-conformance-20261022')
revision='207ad26a179fdf2e3cd6e6ad2c555d49a603d329'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==revision
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
assert all(item['returncode']==0 for item in json.loads((cache/'final-program-exit.json').read_text()))
assert json.loads((cache/'final-core-exit.json').read_text())['returncode']==0
assert json.loads((cache/'final-live-asan-1/validation.json').read_text())['status']=='passed'
for session in ['relar-core-final','relar-native-final','relar-native-final-2','relar-programs-final','relar-measurements-final']:
    assert subprocess.run(['tmux','has-session','-t','='+session],capture_output=True).returncode != 0,session
python=str(cache/'python-venv/bin/python')
suite='/home/dev-user/code/oss/typing-relar-live-20261022/conformance'
old='/home/dev-user/.cache/relar-native-tools-20261021/input-tools/ty-0.0.60/bin/ty'
new='/home/dev-user/.cache/relar-workspaces-20261021/input-tools/ty-0.0.90/bin/ty'
cpu=31
assert cpu in os.sched_getaffinity(0)
metadata={'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host':platform.node(),'platform':platform.platform(),'source_revision':revision,'affinity':sorted(os.sched_getaffinity(0)),'cpu':cpu,'cpu_reason':'Same pinned CPU as the preceding developer-tools milestone.','lscpu':json.loads(subprocess.check_output(['lscpu','--json'],text=True)),'superseded_attempt':str(cache/'measurements-normal-1/superseded.json'),'sanitizer_validation':str(cache/'final-live-asan-1/validation.json')}
(cache/'final-host-2.json').write_text(json.dumps(metadata,indent=2)+'\n')
results=[]
for mode,other in [('normal','normal'),('thinlto','thin')]:
    programs=cache/('final-programs-'+mode+'-1')
    codon=cache/('final-codon-'+other+'-2')
    reference=cache/('final-reference-'+other+'-2')
    native=cache/('final-platform-'+other+'-2')
    command=[python,str(repo/'benchmarks/live_conformance_benchmark.py'),'--suite',suite,'--old-ty',old,'--new-ty',new,'--python',python,'--relar',str(programs/'conformance-report'),'--relar-compute',str(programs/'conformance-report-compute'),'--codon',str(codon/'conformance_report'),'--codon-compute',str(codon/'conformance_report-compute'),'--rust',str(reference/'conformance-report-reference'),'--samples','20','--warmups','2','--compute-rounds','4','--cpu',str(cpu),'--output',str(cache/('measurements-'+mode+'-2'))]
    for directory in [programs,codon,reference,native]:command+=['--build-record',str(directory/'build-record.json')]
    print('Starting '+mode,flush=True)
    with (cache/('measurements-'+mode+'-2.log')).open('x') as output:
        result=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
    results.append({'mode':mode,'returncode':result.returncode,'command':command})
    (cache/'final-measurement-exit-2.json').write_text(json.dumps(results,indent=2)+'\n')
    if result.returncode:raise SystemExit(result.returncode)
print('Both final timing modes passed',flush=True)
