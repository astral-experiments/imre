from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import subprocess
import traceback

ROOT = Path('/home/dev-user/code/oss/imre-live-conformance-20261022')
CACHE = Path('/home/dev-user/.cache/imre-live-conformance-20261022')
SHARED = Path('/home/dev-user/.cache/imre/ohm-build-1.98.1-1')
PYTHON = CACHE / 'python-venv/bin/python'
CODON = Path('/home/dev-user/.cache/imre-codon-20261021/install/codon-deploy-linux-x86_64/bin/codon')
MANIFEST = json.loads((CACHE / 'native-final-source-inputs-2.json').read_text())
ENV = {**os.environ, 'PATH':'/home/dev-user/.cargo/bin:/usr/bin:/bin',
       'RUSTUP_HOME':'/home/dev-user/.cache/imre-native-tools-20261021/rustup',
       'CARGO_HOME':str(CACHE / 'cargo-home'), 'CARGO_BUILD_JOBS':'4',
       'CARGO_BUILD_BUILD_DIR':str(SHARED),
       'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all',
       'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all'}


def sources():
    return {name:hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in MANIFEST}


def run(name, command):
    print('START ' + name, flush=True)
    result = subprocess.run([str(x) for x in command], cwd=ROOT, env=ENV, capture_output=True, timeout=1800)
    (CACHE / (name + '.stdout')).write_bytes(result.stdout)
    (CACHE / (name + '.stderr')).write_bytes(result.stderr)
    if result.returncode:
        raise RuntimeError(f'{name} failed ({result.returncode}): {result.stderr.decode(errors="replace")[-12000:]}')
    print('DONE ' + name, flush=True)


def platform_and_codon():
    results = []
    for mode in ('normal','thin'):
        artifact = CACHE / ('final-platform-' + mode + '-2')
        run(artifact.name,[PYTHON, ROOT / 'benchmarks/native_platform/build.py', '--toolchain','ohm',
            '--artifact-dir',artifact,'--target-dir',CACHE/'platform-target','--build-cache',SHARED,
            *(['--thinlto'] if mode == 'thin' else [])])
        results.append(str(artifact))
    for mode in ('normal','thin'):
        artifact = CACHE / ('final-codon-' + mode + '-2')
        run(artifact.name,[PYTHON, ROOT/'benchmarks/codon_native/build.py','--codon',CODON,
            '--output',artifact,'--applications','conformance_report',
            '--platform-library',CACHE/('final-platform-'+mode+'-2/libimre_benchmark_platform.so')])
        results.append(str(artifact))
    return results


def reference():
    results = []
    for mode in ('normal','thin'):
        artifact = CACHE / ('final-reference-' + mode + '-2')
        run(artifact.name,[PYTHON,ROOT/'benchmarks/reference/conformance_report/build.py','--toolchain','ohm',
            '--artifact-dir',artifact,'--target-dir',CACHE/'reference-target','--build-cache',SHARED,
            *(['--thinlto'] if mode == 'thin' else [])])
        results.append(str(artifact))
    return results


try:
    assert sources() == MANIFEST, 'remote frozen sources differ from local manifest'
    manifest = ROOT / 'benchmarks/native_platform/Cargo.toml'
    fmt_command = ['cargo', '+ohm', '-Zohm-defaults=no', 'fmt', '--manifest-path', manifest, '--check']
    test_command = ['cargo', '+ohm', '-Zohm-defaults=no', 'test', '--manifest-path', manifest, '--locked', '--offline', '--target-dir', CACHE/'platform-target']
    run('final-platform-fmt-2', fmt_command)
    run('final-platform-tests-2', test_command)
    assert sources() == MANIFEST, 'source changed during tests'
    (CACHE/'native-platform-tests-2.json').write_text(json.dumps({'status':'passed','fmt_command':[str(x) for x in fmt_command],'test_command':[str(x) for x in test_command],'source_inputs':MANIFEST,'input_guards_passed':True},indent=2)+'\n')
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(platform_and_codon),pool.submit(reference)]
        artifacts = [path for future in futures for path in future.result()]
    assert sources() == MANIFEST, 'source changed during builds'
    record = {'status':'passed','artifacts':artifacts,'source_inputs':MANIFEST,'input_guards_passed':True}
except BaseException:
    record = {'status':'failed','traceback':traceback.format_exc()}
    print(record['traceback'],flush=True)
(CACHE/'native-final-builds-2.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='source_inputs'}),flush=True)
raise SystemExit(0 if record['status']=='passed' else 1)
