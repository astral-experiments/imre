# Dataclass record evidence

Original preparation, timing, validation and filesystem bytes are retained through
the content-addressed logical index. Each source entry binds its measured Git
revision, blob ID, mode, SHA-256 and byte length. Unrelated historical results are
omitted with their Git identities recorded. No measurement identities are rewritten.

Native executables, static archives, LLVM bitcode and Python bytecode are excluded
and retain their hashes in provenance/exclusions.json. LLVM text and build/test
logs are included. This milestone has no CPU or allocation-profile artifacts.

Run the published 2026-10-21-dataclass-records-replay.py beside the archive, manifest
and index for data-only output-oracle and statistical replay. No local developer
paths, Git checkout, native binary or compiler are required. Replaying evidence
does not remeasure runtime or authenticate the original clock observations.
