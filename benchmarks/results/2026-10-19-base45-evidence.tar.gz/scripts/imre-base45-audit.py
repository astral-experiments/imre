"""Independently audit the two completed Base45 benchmark records, read-only."""

import argparse
import base64
import hashlib
import json
import math
import os
import runpy
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def percentile(sorted_values, fraction):
    position = (len(sorted_values) - 1) * fraction
    low, high = math.floor(position), math.ceil(position)
    if low == high:
        return sorted_values[low]
    return (
        sorted_values[low] * (high - position)
        + sorted_values[high] * (position - low)
    )


def close(actual, expected):
    assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), (
        actual,
        expected,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/imre"))
    parser.add_argument("--normal", type=Path, default=Path("/tmp/imre-base45-normal.json"))
    parser.add_argument("--thinlto", type=Path, default=Path("/tmp/imre-base45-thinlto.json"))
    parser.add_argument("--build", type=Path, default=Path("/tmp/imre-base45-frozen/build.json"))
    parser.add_argument("--output", type=Path, default=Path("/tmp/imre-base45-audit.json"))
    args = parser.parse_args()
    root = args.root.resolve()
    os.sched_setaffinity(0, {max(os.sched_getaffinity(0))})
    raw_records = {name: path.read_bytes() for name, path in [("normal", args.normal), ("thinlto", args.thinlto)]}
    records = {name: json.loads(raw) for name, raw in raw_records.items()}
    # Refuse partial records before reading/hashing the large executable files.
    for name, record in records.items():
        assert record.get("input_guards_passed") is True, (name, "benchmark still incomplete")
        assert len(record["workloads"]) == 9
    build_raw = args.build.read_bytes()
    build = json.loads(build_raw)
    package = root / "examples/base45_codec"
    manifest = json.loads((package / "UPSTREAM.json").read_bytes())
    # Execute the unchanged source directly, bypassing any cached package bytecode.
    codec = runpy.run_path(str(package / "base45/__init__.py"))
    files = {}

    def verify_file(path, expected):
        path = path.resolve()
        if str(path) not in files:
            with path.open("rb") as stream:
                actual = hashlib.file_digest(stream, "sha256").hexdigest()
            files[str(path)] = {"sha256": actual, "bytes": path.stat().st_size}
        assert files[str(path)]["sha256"] == expected, path
        return files[str(path)]

    def oracle(operation, payload, repetitions=1):
        try:
            if operation == "encode":
                result = codec["b45encode"](payload)
            elif operation == "decode-bytes":
                result = codec["b45decode"](payload)
            elif operation == "decode-text":
                result = codec["b45decode"](payload.decode())
            else:
                raise AssertionError(operation)
        except (ValueError, KeyError, TypeError, AttributeError) as error:
            cause = error.__cause__
            lines = [
                "ERROR", type(error).__name__, str(error),
                str(error.__suppress_context__),
                "None" if cause is None else type(cause).__name__,
                "" if cause is None else str(cause),
            ]
            return "\n".join(lines) + "\n", None
        checksum = len(result) + (result[0] + result[-1] if result else 0)
        return f"OK\n{checksum * repetitions}\n", result

    for name, metadata in build["artifacts"].items():
        verify_file(Path(metadata["path"]), metadata["sha256"])
    for name, expected in build["source_sha256"].items():
        verify_file(root / name, expected)
    for name, metadata in manifest["files"].items():
        verify_file(package / name, metadata["sha256"])
    actual_core_files = {str(path.relative_to(root)) for path in (root / "crates").rglob("*.rs")}
    actual_core_files.update(str(path.relative_to(root)) for path in (root / "crates").rglob("Cargo.toml"))
    actual_core_files.update(["Cargo.toml", "Cargo.lock", "rust-toolchain.toml"])
    assert actual_core_files == set(build["source_sha256"])
    output = {
        "schema": 1,
        "audited_at": datetime.now(timezone.utc).isoformat(),
        "script_sha256": digest(Path(__file__).read_bytes()),
        "audit_python": sys.version,
        "audit_cpu_affinity": sorted(os.sched_getaffinity(0)),
        "build_manifest": {"path": str(args.build.resolve()), "sha256": digest(build_raw), "revision": build["revision"]},
        "source_manifest_files": len(build["source_sha256"]),
        "upstream": manifest,
        "records": {},
        "findings": [],
        "caveats": [
            "Ratios measure whole fresh processes, including startup, imports, one input read, repeated codec calls, and one output write; they are not isolated codec-call timings.",
            "Each workload processes 2 MiB of decoded payload through repeated calls on one deterministic input. Timing covers valid random inputs of 64, 1024 and 16384 decoded bytes, all even lengths; separate validation covers odd lengths and malformed inputs.",
            "The CPython baseline is 3.14.5 with PGO and LTO enabled and its optional JIT disabled. There is no Rust codec comparison in these records.",
            "The two wrong-typed upstream calls are compiler rejections, not runtime TypeError equivalence at a dynamically typed extension boundary.",
            "Ordinary and ThinLTO runs occurred sequentially. Compare each against its paired CPython samples; a cross-record ratio of Imre times is not a randomized paired estimate of the ThinLTO effect.",
            "File hashes verify the named source files, executables, archives, linker and generated artifacts; they do not constitute a hash of every transitive system-library dependency.",
        ],
    }
    for name, record in records.items():
        assert record["samples"] == 20 and record["warmups"] == 2 and record["dirty"] is False
        assert record["thinlto"] == (name == "thinlto")
        assert record["upstream"] == manifest
        assert record["cpu"]["affinity"] == [0]
        assert record["python"]["version"] == sys.version
        assert record["python"]["implementation"] == "cpython"
        assert record["python"]["version_number"] == "3.14.5"
        assert record["python"]["jit_enabled"] is False
        assert record["python"]["pgo"]["configure_enable_optimizations"] is True
        assert record["python"]["lto"]["configure_option"] == "--with-lto"
        command = record["compile_command"]
        flag = lambda name: command[command.index(name) + 1]
        binary, llvm = Path(flag("-o")), Path(flag("--emit-llvm"))
        assert command[1:3] == ["build", str(package / "driver.py")]
        assert flag("--module-root") == str(package)
        assert flag("--opt-level") == "3"
        assert (flag("--target") if "--target" in command else None) == record["requested_target"]
        assert ("--lto-linker" in command) == record["thinlto"]
        named_inputs = {
            "compiler": Path(command[0]), "runtime": Path(flag("--runtime")),
            "python": Path(sys.executable), "clang": Path(flag("--clang")),
            "codec": package / "base45/__init__.py", "driver": package / "driver.py",
            "harness": root / "benchmarks/base45_benchmark.py",
            "validator": root / "benchmarks/base45_validate.py",
            "shared_harness": root / "benchmarks/benchmark.py",
            "upstream_manifest": package / "UPSTREAM.json",
        }
        if record["thinlto"]:
            named_inputs["lto_linker"] = Path(flag("--lto-linker"))
        named_inputs.update({f"upstream_{index}": package / path for index, path in enumerate(manifest["files"])})
        assert set(named_inputs) == set(record["source_and_tool_sha256"])
        for label, path in named_inputs.items():
            verify_file(path, record["source_and_tool_sha256"][label])
        verify_file(binary, record["binary_sha256"])
        verify_file(llvm, record["llvm_sha256"])
        assert record["source_and_tool_sha256"]["compiler"] == build["artifacts"]["compiler"]["sha256"]
        assert record["source_and_tool_sha256"]["runtime"] == build["artifacts"][name + "_runtime"]["sha256"]
        subprocess.run(["git", "-C", str(root), "merge-base", "--is-ancestor", build["revision"], record["revision"]], check=True)
        changed = subprocess.check_output(["git", "-C", str(root), "diff", "--name-only", build["revision"], record["revision"], "--", *build["source_sha256"]], text=True)
        assert changed == "", changed
        validation = record["validation"]
        assert validation["binary_sha256"] == record["binary_sha256"]
        assert validation["compiler_sha256"] == record["source_and_tool_sha256"]["compiler"]
        assert validation["upstream"] == manifest and validation["python"] == record["python"]["version"]
        assert validation["implementation"] == "CPython"
        assert validation["upstream_cpython"]["methods"] == validation["upstream_native_adapter"]["methods"] == 5
        assert validation["upstream_cpython"]["log"].endswith("\nOK\n")
        assert validation["upstream_native_adapter"]["log"].endswith("\nOK\n")
        assert validation["native_adapter_calls"] == 323
        rejections = validation["wrong_typed_compile_rejections"]
        assert len(rejections) == 2 and {item["operation"] for item in rejections} == {"encode", "decode"}
        for item in rejections:
            assert "expected" in item["diagnostic"] and "got int" in item["diagnostic"]
            assert "panicked" not in item["diagnostic"]
        cases = validation["differential_cases"]
        assert len(cases) == len({case["label"] for case in cases}) == 269
        for case in cases:
            stdout, result = oracle(case["operation"], base64.b64decode(case["input_base64"], validate=True))
            assert case["stdout"] == stdout, case["label"]
            assert case["output_sha256"] == (None if result is None else digest(result)), case["label"]
        summaries = []
        checked_runs = 0
        assert {(w["operation"], w["raw_bytes"]) for w in record["workloads"]} == {(op, size) for op in ["encode", "decode-bytes", "decode-text"] for size in [64, 1024, 16384]}
        for workload in record["workloads"]:
            payload = base64.b64decode(workload["input_base64"], validate=True)
            stdout, result = oracle(workload["operation"], payload, workload["repetitions"])
            assert workload["expected_stdout"] == stdout
            assert workload["expected_output_sha256"] == digest(result)
            assert workload["expected_output_bytes"] == len(result)
            assert workload["raw_bytes"] == (len(payload) if workload["operation"] == "encode" else len(result))
            assert workload["repetitions"] * workload["raw_bytes"] == 2 * 1024 * 1024
            phase_orders = {}
            for phase, count in [("warmups", 2), ("samples", 20)]:
                assert len(workload[phase]) == count
                firsts = Counter()
                for index, sample in enumerate(workload[phase]):
                    assert sample["index"] == index
                    assert sample["order"] == (["imre", "cpython"] if index % 2 == 0 else ["cpython", "imre"])
                    firsts[sample["order"][0]] += 1
                assert dict(firsts) == {"imre": count // 2, "cpython": count // 2}
                phase_orders[phase] = dict(firsts)
            engines = {}
            for engine in ["imre", "cpython"]:
                runs = [workload["gates"][engine], *(s[engine] for s in workload["warmups"]), *(s[engine] for s in workload["samples"])]
                for sample in runs:
                    assert type(sample["elapsed_ns"]) is int and sample["elapsed_ns"] > 0
                    assert sample["returncode"] == 0 and sample["stderr"] == ""
                    assert sample["stdout"] == stdout and sample["output_sha256"] == digest(result)
                    checked_runs += 1
                durations = sorted(s[engine]["elapsed_ns"] / 1e9 for s in workload["samples"])
                summary = {
                    "median_seconds": percentile(durations, .5), "min_seconds": durations[0], "max_seconds": durations[-1],
                    "p25_seconds": percentile(durations, .25), "p75_seconds": percentile(durations, .75),
                }
                for key, value in summary.items():
                    close(workload["summary"][engine][key], value)
                summary["iqr_seconds"] = summary["p75_seconds"] - summary["p25_seconds"]
                summary["iqr_over_median"] = summary["iqr_seconds"] / summary["median_seconds"]
                engines[engine] = summary
                directory = binary.parent / workload["label"] / engine
                assert (directory / "input.bin").read_bytes() == payload
                assert (directory / "output.bin").read_bytes() == result
            ratio = engines["cpython"]["median_seconds"] / engines["imre"]["median_seconds"]
            close(workload["cpython_over_imre"], ratio)
            summaries.append({
                "label": workload["label"], "raw_bytes": workload["raw_bytes"], "repetitions": workload["repetitions"],
                "input_sha256": digest(payload), "output_sha256": digest(result),
                "first_engine_counts": phase_orders, "recomputed_summary": engines,
                "cpython_over_imre": ratio,
            })
        assert checked_runs == 414
        output["records"][name] = {
            "path": str((args.normal if name == "normal" else args.thinlto).resolve()),
            "sha256": digest(raw_records[name]), "revision": record["revision"],
            "complete": True, "dirty": record["dirty"], "exact_binary_validated": True,
            "binary_sha256": record["binary_sha256"], "llvm_sha256": record["llvm_sha256"],
            "compile_command": command, "requested_target": record["requested_target"], "llvm_target": record["llvm_target"],
            "sample_count_per_workload": 20, "warmup_count_per_workload": 2, "gate_count_per_engine_workload": 1,
            "stored_process_results_checked": checked_runs, "independent_oracle_cases_checked": len(cases),
            "upstream_native_calls": 323, "compile_rejections": 2,
            "source_and_tool_sha256": record["source_and_tool_sha256"],
            "workloads": summaries,
        }
    normal, thinlto = records["normal"], records["thinlto"]
    assert normal["revision"] == thinlto["revision"]
    assert normal["python"] == thinlto["python"] and normal["cpu"] == thinlto["cpu"]
    assert normal["llvm_sha256"] == thinlto["llvm_sha256"]
    for first, second in zip(normal["workloads"], thinlto["workloads"], strict=True):
        for key in ["label", "operation", "raw_bytes", "repetitions", "input_base64", "expected_stdout", "expected_output_sha256", "expected_output_bytes"]:
            assert first[key] == second[key], key
    for key, value in normal["source_and_tool_sha256"].items():
        if key != "runtime":
            assert thinlto["source_and_tool_sha256"][key] == value, key
    large_encode = next(w for w in output["records"]["normal"]["workloads"] if w["label"] == "encode-16384")
    output["caveats"].append(f"Ordinary encode-16384 is {large_encode['cpython_over_imre']:.6f}x CPython/Imre, so Imre takes {1/large_encode['cpython_over_imre']:.6f}x as long as CPython on that workload.")
    output["cross_record_checks"] = {
        "same_revision": True, "same_compiler_and_llvm_ir": True,
        "same_inputs_expected_outputs_and_repetitions": True,
        "same_cpython_build_and_cpu_affinity": True,
        "different_runtime_and_linking_mode": True,
    }
    output["verified_files"] = files
    output["passed"] = True
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"passed": True, "records": 2, "process_results": 828, "independent_oracle_cases": 538, "verified_files": len(files), "audit": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
