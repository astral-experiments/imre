from pathlib import Path
import gzip, hashlib, io, json, re, tarfile

root=Path('/home/dev-user/code/oss/imre')
results=root/'benchmarks/results'
prefix='2026-10-19-base45'
sha=lambda data:hashlib.sha256(data).hexdigest()
records={mode:json.loads(Path('/tmp/imre-base45-'+mode+'.json').read_text()) for mode in ('normal','thinlto')}
assert all(record['input_guards_passed'] for record in records.values())
files={}
for mode,record in records.items():
 data=Path('/tmp/imre-base45-'+mode+'.json').read_bytes()
 (results/(prefix+'-'+mode+'.json.gz')).write_bytes(gzip.compress(data,mtime=0))
 files['records/'+mode+'.json']=data
 files['llvm/'+mode+'.ll']=(root/'benchmarks/local'/('base45-'+mode)/'base45.ll').read_bytes()
for name,path in [('build',Path('/tmp/imre-base45-frozen/build.json')),('audit',Path('/tmp/imre-base45-audit.json')),('profile',Path('/tmp/imre-base45-profile/summary.json'))]:
 data=path.read_bytes()
 (results/(prefix+'-'+name+'.json')).write_bytes(data)
 files['records/'+name+'.json']=data
build=json.loads(files['records/build.json'])
for name,expected in build['source_sha256'].items():
 data=(root/name).read_bytes()
 assert sha(data)==expected,name
 files['source/'+name]=data
for directory in ['examples/base45_codec/base45','examples/base45_codec/upstream']:
 for path in (root/directory).iterdir():
  if path.is_file(): files['source/'+str(path.relative_to(root))]=path.read_bytes()
for name in ['examples/base45_codec/UPSTREAM.json','examples/base45_codec/driver.py','examples/base45_codec/checks.py','benchmarks/base45_benchmark.py','benchmarks/base45_validate.py','benchmarks/benchmark.py','benchmarks/validate.py','tests/base45.py','LICENSE-MIT','LICENSE-APACHE']:
 files['source/'+name]=(root/name).read_bytes()
validation={'compiler_source_revision':build['revision'],'application_source_revision':records['normal']['revision'],'rust_unit_tests':{'compiler':42,'runtime':57,'total':99},'other_local_checks':['cargo fmt --all --check','cargo clippy --workspace --all-targets --locked -- -D warnings','focused Ruff checks','git diff --check'],'families':{}}
for family in ['normal-suites','thinlto-suites','asan-suites','asan-o0']:
 path=Path('/tmp/imre-base45-'+family)
 runs=json.loads((path/'results.json').read_text())
 assert all(run['returncode']==0 and not run['stderr'] for run in runs)
 counts={}
 for run in runs:
  if run['suite']!='base45':
   match=re.search(r'(?:Passed )?(\d+).*checks|Passed (\d+)',run['stdout'])
   assert match,run
   counts[run['suite']]=int(next(value for value in match.groups() if value is not None))
  files['source/tests/'+run['suite']+'.py']=(root/'tests'/(run['suite']+'.py')).read_bytes()
 validation['families'][family]={'suites':len(runs),'language_checks_excluding_base45':sum(counts.values()),'counts':counts,'results':runs}
 for path in path.iterdir():
  if path.is_file(): files['validation/'+family+'/'+path.name]=path.read_bytes()
validation['language_checks_excluding_base45']=sum(family['language_checks_excluding_base45'] for family in validation['families'].values())
validation['base45_per_optimization_mode']={'upstream_test_methods':5,'native_adapter_calls':323,'differential_cases':269,'compile_time_type_rejections':2}
validation['base45_modes']=['ordinary O0','ordinary O3','ThinLTO O3','ASan/LSan O1','ASan/LSan O0']
data=(json.dumps(validation,indent=2)+'\n').encode()
(results/(prefix+'-validation.json')).write_bytes(data)
files['records/validation.json']=data
for name in ['audit','profile','run-suites','publish-evidence']:
 path=Path('/tmp/imre-base45-'+name+'.py')
 files['scripts/'+path.name]=path.read_bytes()
files['validation/base45-normal.json']=Path('/tmp/imre-base45-validation-normal.json').read_bytes()
files['validation/exception-causes.log']=Path('/tmp/imre-base45-exception-cause-tests.log').read_bytes()
for path in Path('/tmp/imre-base45-profile').rglob('*'):
 if path.is_file(): files['profiles/'+str(path.relative_to('/tmp/imre-base45-profile'))]=path.read_bytes()
archive=io.BytesIO()
with tarfile.open(fileobj=archive,mode='w') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name)
  info.size=len(data)
  info.mode=0o644
  info.mtime=0
  tar.addfile(info,io.BytesIO(data))
compressed=gzip.compress(archive.getvalue(),mtime=0)
archive_path=results/(prefix+'-evidence.tar.gz')
archive_path.write_bytes(compressed)
manifest={'archive':archive_path.name,'archive_sha256':sha(compressed),'files':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())}}
(results/(prefix+'-evidence-manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n')

def table(mode):
 lines=['| Operation / raw bytes per call | CPython ms [Q1–Q3] | Imre ms [Q1–Q3] | CPython / Imre |','|---|---:|---:|---:|']
 for work in records[mode]['workloads']:
  cells=[work['label']]
  for engine in ['cpython','imre']:
   stats=work['summary'][engine]
   cells.append(f"{stats['median_seconds']*1000:.3f} [{stats['p25_seconds']*1000:.3f}–{stats['p75_seconds']*1000:.3f}]")
  cells.append(f"{work['cpython_over_imre']:.3f}×")
  lines.append('| '+' | '.join(cells)+' |')
 return '\n'.join(lines)

report='''# Compiling unchanged python-base45

Imre compiles the original typed `python-base45` codec ahead of time. With ThinLTO, decoding is **1.80–2.11× faster than CPython**, and encoding 64-byte and 1,024-byte inputs is **1.47× and 1.30× faster**. Encoding 16 KiB inputs takes **1.50× as long**. Profiles identify repeated copying of the growing output string as the large-input bottleneck.

The [compiler/runtime change](https://github.com/viarius-experiments/imre/pull/47) follows PR #46 in GitHub Stack 4. The [example](../../examples/base45_codec/README.md), validator, and benchmark continue that stack. Measured application and harness sources are clean commit `2963aa2a690139c23be23653009096da03c7b94e`; frozen compiler/runtime sources are `54d7255f3184aacd4b54b9246a4bc6c7d2235f93`. This report and its evidence are committed afterward.

## Library and compatibility

The codec, `py.typed`, upstream tests, and BSD-2-Clause license are byte-for-byte copies from [upstream commit 5f49a519](https://github.com/kirei/python-base45/tree/5f49a519c3884a4fbc4c58c5c8f1fa25d7046020). The [manifest](../../examples/base45_codec/UPSTREAM.json) records their original paths and SHA-256 hashes. The codec uses its existing annotations, with no rewrite, CPython embedding, or interpreted fallback. Its separate `argparse` command-line application is outside this example.

The required capabilities are fixed imported module values, ordered initialization, exact `str | bytes` unions and `isinstance` narrowing, arbitrary-precision integer bit operations, integer `divmod`, `list.extend`, Unicode `str.rstrip`, and explicit exception causes. Union storage uses a pointer tag without a wrapper allocation. Imported aliases share exported objects and mutations. Fresh exception instances may hold immutable causes; iterative cleanup preserves the existing acyclic reference-counted heap.

All **five unchanged upstream test methods** pass under CPython and through a native adapter. Each native run executes **323 upstream codec calls** and **269 additional differential cases**, checking complete results, error categories/messages, cause metadata, and filesystem effects. Coverage includes malformed UTF-8, text-versus-bytes newline behavior, odd and empty inputs, random round trips, all byte values, alias mutation, and repeated recovery.

Two upstream calls deliberately pass integer `42` to the annotated codec APIs. Imre rejects those calls during compilation. The adapter verifies the exact compiler diagnostic before satisfying the upstream `TypeError` assertion. These are **two compile-time boundary checks**, not native runtime `TypeError` tests or a dynamically typed Python extension API.

## Ordinary linking

Each row measures repeated calls representing 2 MiB of raw data. Values are median milliseconds with the interquartile range in brackets. A ratio above one means Imre is faster.

@NORMAL@

Ordinary decoding is 1.18–1.35× faster than CPython. Encoding the two smaller sizes is about 1.10× faster, while 16 KiB encoding takes 1.65× as long.

## ThinLTO

@THINLTO@

The two linking configurations ran as separate sequential families, each with its own interleaved CPython baseline. These data establish each native configuration's comparison with CPython; they are not a randomized direct measurement of ThinLTO's isolated effect. Quartiles describe sample spread, not confidence intervals. The largest IQR/median in either family is 3.89%.

## Why large encoding is slower

Separate DHAT and Callgrind profiles use the exact measured ThinLTO executable. Each profiled process handles 64 KiB of raw data, through 1,024 calls for the small encoding case or four calls for the 16 KiB cases. Full output, checksum, input, and binary hashes are checked again.

| Case | Cumulative allocated bytes | Allocations | Peak live bytes | Callgrind instructions |
|---|---:|---:|---:|---:|
| encode-64 | 7,046,310 | 160,854 | 14,379 | 66,583,941 |
| encode-16384 | 408,084,816 | 163,914 | 95,174 | 439,795,671 |
| decode-bytes-16384 | 7,291,988 | 98,535 | 455,557 | 70,934,097 |

The large encoder attributes **98.68% of cumulative allocated bytes** to `concat_parts` through `imre_str_concat_parts`. The runtime constructs a fresh result and copies every fragment, including the previous output, on each loop iteration. That makes total copying grow quadratically within an encoding call. The next focused optimization is ownership-aware string append that can reuse uniquely owned storage while preserving aliases and evaluation order.

These are cumulative allocations and instrumented instruction counts, not live-memory requirements or CPU-time percentages. Profiles ran after both timing families and do not contribute to benchmark durations. The [profile record](2026-10-19-base45-profile.json) and evidence archive retain the commands, tool hashes, allocation stacks, and raw profiles.

## Measurement method

The same file driver calls the original codec under both engines. Workloads encode, decode bytes, or decode text at 64, 1,024, and 16,384 raw bytes per call. Each process repeats calls on the same input for exactly 2 MiB of raw data; decoding consumes the corresponding 3 MiB of Base45 input. Input is read once, every call contributes to a checksum, and the last complete result is written once. These are whole-program batches with driver overhead, not isolated single-call latency measurements.

Each family first validates the exact executable, then runs one gate per engine/workload, two balanced warmup rounds, and twenty balanced AB/BA measured rounds. Across both families this retains **720 measured executions, 72 warmups, and 36 gates**. Every process checks exit status, stderr, stdout/checksum, full output hash and length, and unchanged input. Source, tools, upstream files, and executable hashes are guarded before and after timing.

Runs occurred on October 19, 2026, on an AMD EPYC-Milan host, pinned to CPU 0, outside tracing. CPython 3.14.5 has PGO and LTO enabled, the GIL enabled, and its available JIT disabled. Imre uses Clang 18 at `-O3`; the ThinLTO runtime uses linker-plugin bitcode and the Ohm Rust toolchain's LLVM 22 LLD. The [build record](2026-10-19-base45-build.json) retains exact Rust/Clang versions, profiles, source hashes, and frozen artifact identities.

Timing includes process startup, imports, one input read, all codec calls, one output write, and exit. Fixture preparation, builds, hashing, and verification are outside the clock. OS caches are warm and output is not fsynced. Task-owned builds, tests, and profiles were stopped during timing; host frequency and unrelated shared-host activity remain uncontrolled. Performance workloads use valid even-length inputs; correctness validation separately covers odd, empty, and malformed inputs.

## Validation and retained evidence

All 22 suites pass with ordinary O0/O3, ThinLTO O3, and ASan/LeakSanitizer O1. Primitives, unions, module values, exceptions, and Base45 also pass with ASan/LeakSanitizer at O0. Excluding the separately reported Base45 cases, these runs contain **3,640 language checks**: 1,400 ordinary, 1,057 ThinLTO, 1,057 O1 sanitizer, and 126 O0 sanitizer checks. Counts include compile-time rejections. Base45 runs its upstream and differential checks in all five optimization configurations.

The integrated compiler/runtime passes **99 Rust unit tests**, strict Clippy, formatting, and focused Ruff checks. Sanitizers cover generated native code and the custom runtime with leak detection enabled; the prebuilt Rust standard library remains uninstrumented. The [validation index](2026-10-19-base45-validation.json) preserves suite commands, results, and counts.

The [independent audit](2026-10-19-base45-audit.json) recomputed all statistics and checked **828 stored process results**, **538 differential outcomes**, ordering, exact-executable validation, and 61 named source/tool/build artifacts. It found no discrepancies. The raw records are available for [ordinary linking](2026-10-19-base45-normal.json.gz) and [ThinLTO](2026-10-19-base45-thinlto.json.gz).

The [evidence archive](2026-10-19-base45-evidence.tar.gz) and [manifest](2026-10-19-base45-evidence-manifest.json) retain measured source, generated LLVM, raw records, suite logs, profiling data, and reproduction/audit scripts. Native executables, runtime archives, interpreters, and toolchains remain external and are identified by hashes. Reproduction requires the pinned Git checkout, including its test fixtures. The [example guide](../../examples/base45_codec/README.md) provides build, use, validation, and benchmark commands.
'''
report=report.replace('@NORMAL@',table('normal')).replace('@THINLTO@',table('thinlto'))
(results/(prefix+'.md')).write_text(report)
print('Wrote report and',len(files),'evidence files;',len(compressed),'compressed bytes; language checks',validation['language_checks_excluding_base45'])
