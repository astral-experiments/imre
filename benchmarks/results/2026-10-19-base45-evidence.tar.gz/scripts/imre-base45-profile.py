"""Explain Base45 allocation growth using the exact timed ThinLTO binary."""

import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


record_path = Path('/tmp/imre-base45-thinlto.json')
record = json.loads(record_path.read_text())
assert record['input_guards_passed']
binary = Path(record['compile_command'][record['compile_command'].index('-o') + 1])
assert sha(binary) == record['binary_sha256']
root = Path('/tmp/imre-base45-profile')
root.mkdir(exist_ok=False)
tools = Path('/home/dev-user/.cache/imre/profiling-tools/root/usr')
valgrind = tools / 'bin/valgrind'
annotate = tools / 'bin/callgrind_annotate'
library = tools / 'libexec/valgrind'
env = {**os.environ, 'VALGRIND_LIB': str(library), 'VALGRIND_OPTS': ''}
version = subprocess.check_output([str(valgrind), '--version'], env=env, text=True).strip()
result = {
    'method': 'Separate instruction and heap-allocation profiles, never wall-time benchmarks. Each process handles 64 KiB of raw data in repeated calls to the exact timed ThinLTO executable. Output, checksum, input, and executable hashes are checked.',
    'benchmark_record_sha256': sha(record_path),
    'binary_sha256': record['binary_sha256'],
    'source_revision': record['revision'],
    'valgrind_version': version,
    'valgrind_sha256': sha(valgrind),
    'environment': {'VALGRIND_LIB': str(library), 'VALGRIND_OPTS': ''},
    'tools': {name: sha(library / (name + '-amd64-linux')) for name in ('dhat', 'callgrind')},
    'profiles': [],
}
for label in ('encode-64', 'encode-16384', 'decode-bytes-16384'):
    workload = next(item for item in record['workloads'] if item['label'] == label)
    repetitions = 65536 // workload['raw_bytes']
    expected_stdout = 'OK\n' + str(int(workload['expected_stdout'].splitlines()[1]) // workload['repetitions'] * repetitions) + '\n'
    for tool in ('dhat', 'callgrind'):
        directory = root / (label + '-' + tool)
        directory.mkdir()
        source = directory / 'input.bin'
        output = directory / 'output.bin'
        source.write_bytes(base64.b64decode(workload['input_base64']))
        input_hash = sha(source)
        data = directory / ('profile.json' if tool == 'dhat' else 'profile.callgrind')
        log = directory / 'stderr.log'
        command = [str(valgrind), '--tool=' + tool, '--num-callers=32', '--log-file=' + str(log), '--' + tool + '-out-file=' + str(data), str(binary), workload['operation'], str(source), str(output), str(repetitions)]
        completed = subprocess.run(command, env=env, capture_output=True, timeout=180, check=True)
        assert not completed.stderr, completed.stderr
        assert completed.stdout.decode() == expected_stdout
        assert sha(output) == workload['expected_output_sha256']
        assert len(output.read_bytes()) == workload['expected_output_bytes']
        assert sha(source) == input_hash
        assert sha(binary) == record['binary_sha256']
        (directory / 'stdout.txt').write_bytes(completed.stdout)
        entry = {'label': label, 'tool': tool, 'command': command, 'repetitions': repetitions, 'raw_bytes_per_process': 65536, 'input_sha256': input_hash, 'output_sha256': sha(output), 'stdout': completed.stdout.decode(), 'returncode': completed.returncode, 'profile_sha256': sha(data), 'log_sha256': sha(log)}
        if tool == 'dhat':
            heap = json.loads(data.read_text())
            points = heap['pps']
            entry.update({'total_allocated_bytes': sum(point['tb'] for point in points), 'total_allocated_blocks': sum(point['tbk'] for point in points), 'peak_live_bytes': sum(point['gb'] for point in points), 'exit_live_bytes': sum(point['eb'] for point in points), 'top_allocation_stacks': [{'bytes': point['tb'], 'blocks': point['tbk'], 'frames': [heap['ftbl'][index] for index in point['fs']]} for point in sorted(points, key=lambda item: item['tb'], reverse=True)[:5]]})
        else:
            entry['instructions'] = int(next(line.split(':')[1].strip() for line in data.read_text().splitlines() if line.startswith('summary:')))
            for inclusive in ('no', 'yes'):
                annotation = subprocess.check_output([str(annotate), '--auto=no', '--inclusive=' + inclusive, '--threshold=99', str(data)], env=env)
                (directory / ('functions-inclusive-' + inclusive + '.txt')).write_bytes(annotation)
        result['profiles'].append(entry)
        (root / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        print(label, tool, {key: entry[key] for key in ('total_allocated_bytes', 'total_allocated_blocks', 'peak_live_bytes', 'instructions') if key in entry}, flush=True)
result['guards_passed'] = True
(root / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
