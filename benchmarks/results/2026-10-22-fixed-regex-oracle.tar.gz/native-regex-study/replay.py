"""Rebuild the fixed regex C ABI probe and replay both CPython differentials."""

import argparse
import ast
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent
generate = runpy.run_path(str(ROOT / "generate.py"))["generate"]
REVISION = "4eb4e4cd6aa81685bb42a7f1e95c1596901d3fc8"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return sha256(data).hexdigest()


def official_corpus(suite):
    manifest = json.loads((ROOT / "suite.json").read_bytes())
    lines = []
    for entry in manifest["files"]:
        p = suite / entry["path"]
        require(
            digest(p.read_bytes()) == entry["sha256"],
            f"wrong suite file {entry['path']}",
        )
        # Same newline decoding and splitlines() as the published benchmark.
        lines.extend(p.read_text(encoding="utf-8").splitlines())
    return "\0".join(lines).encode()


def corpus_cases(pattern, lines):
    edges = []
    for size in (65_534, 65_535, 65_536, 400_000):
        edges.extend(
            (
                "#" + "x" * (size - 5) + " # E",
                "𐀀" * (size // 4) + "#\x1fE?:🌍",
                "# E: " + "é" * (size // 2),
            )
        )
    return [
        (pattern, True, lines),
        (
            pattern,
            True,
            edges + ["#false #fail # E[z+]: yes", "€ #bad# E?", " #!#n# E: "],
        ),
        (
            "(?P<x>a)(b)?(c)?(d)?(e)?(f)?(?P<g>g)",
            False,
            ["ag", "abfg", "🌍ag", "a" + "é" * 70_000 + "ag"],
        ),
        ("a[ab]+Z", False, ["ab!aaZ", "a" + "b" * 800_000 + "Z"]),
    ]


def observe(probe, cases):
    raw = "".join(
        json.dumps({"p": p, "v": v, "h": h}, ensure_ascii=False) + "\n"
        for p, v, h in cases
    ).encode()
    result = subprocess.run([probe], input=raw, capture_output=True, check=True)
    require(not result.stderr, "unexpected native diagnostic")
    return (
        [json.loads(line) for line in result.stdout.splitlines()],
        digest(raw),
        digest(result.stdout),
    )


def compare(pattern, verbose, haystacks, results):
    compiled = re.compile(pattern, re.VERBOSE if verbose else 0)
    hits = groups = 0
    for idx, (text, native) in enumerate(zip(haystacks, results, strict=True)):
        match = compiled.search(text)
        captured = (
            None
            if match is None
            else [
                [match[i], match.start(i), match.end(i)]
                for i in range(compiled.groups + 1)
            ]
        )
        require(
            captured == native,
            f"CPython mismatch in pattern {pattern!r}, haystack {idx}",
        )
        hits += match is not None
        groups += len(captured or [])
    return {"haystacks": len(haystacks), "matches": hits, "groups": groups}


def verify(probe, checkout, corpus):
    original = json.loads((ROOT / "receipts/generated.json").read_bytes())
    real = json.loads((ROOT / "receipts/corpus.json").read_bytes())
    upstream = checkout / "examples/conformance_report/upstream/conformance.py"
    pattern = next(
        node.value.args[0].value
        for node in ast.walk(ast.parse(upstream.read_bytes()))
        if isinstance(node, ast.Assign)
        and any(
            isinstance(t, ast.Name) and t.id == "CONFORMANCE_ERROR_PATTERN"
            for t in node.targets
        )
    )
    identities = {
        "runtime_sha256": digest(
            (checkout / "crates/imre-runtime/src/objects/regexes.rs").read_bytes()
        ),
        "validator_sha256": digest(
            (checkout / "crates/imre-compiler/src/fixed_regex.rs").read_bytes()
        ),
        "upstream_source_sha256": digest(upstream.read_bytes()),
        "pattern_sha256": digest(pattern.encode()),
    }
    for field, sha in identities.items():
        require(original[field] == sha, f"source hash mismatch {field}")
    require(
        real["source_sha256"] == identities["upstream_source_sha256"]
        and all(
            real[k] == identities[k] for k in ("runtime_sha256", "validator_sha256")
        ),
        "inconsistent recorded sources",
    )
    require(digest(corpus) == real["corpus_sha256"], "wrong NUL-separated corpus")
    patterns, hay = generate(pattern)
    output, request_hash, output_hash = observe(
        probe, [(p, v, hay) for p, v, _ in patterns]
    )
    counts = dict(
        patterns=len(patterns),
        inputs_per_pattern=len(hay),
        accepted=0,
        rejected=0,
        python_comparisons=0,
        captured_groups=0,
    )
    for (p, v, label), got in zip(patterns, output, strict=True):
        if "reject" in got:
            require(label != "required", f"required pattern rejected {p!r}")
            counts["rejected"] += 1
            continue
        require(label != "rejected", f"unsupported pattern accepted {p!r}")
        observed = compare(p, v, hay, got["results"])
        counts["accepted"] += 1
        counts["python_comparisons"] += observed["haystacks"]
        counts["captured_groups"] += observed["groups"]
    generated = {
        "counts": counts,
        "requests_sha256": request_hash,
        "native_stdout_sha256": output_hash,
    }
    for key, value in generated.items():
        require(value == original[key], f"generated receipt mismatch {key}")
    cases = corpus_cases(pattern, corpus.decode().split("\0"))
    output, request_hash, output_hash = observe(probe, cases)
    results = [
        compare(p, v, h, got["results"])
        for (p, v, h), got in zip(cases, output, strict=True)
    ]
    source = {
        "cases": results,
        "corpus_sha256": digest(corpus),
        "inputs_sha256": request_hash,
        "output_sha256": output_hash,
    }
    for key, value in source.items():
        require(value == real[key], f"source corpus receipt mismatch {key}")
    return {
        "status": "passed",
        "revision": REVISION,
        "cpython": sys.version,
        "probe_binary_sha256": digest(probe.read_bytes()),
        "identities": identities,
        "generated": generated,
        "corpus": source,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--checkout",
        required=True,
        type=Path,
        help="Imre Git checkout containing the pinned commit",
    )
    inp = parser.add_mutually_exclusive_group(required=True)
    inp.add_argument(
        "--suite", type=Path, help="typing-suite root containing conformance/tests"
    )
    inp.add_argument(
        "--corpus", type=Path, help="retained UTF-8 NUL-separated scanner input"
    )
    parser.add_argument(
        "--toolchain", required=True, help="installed rustup toolchain name"
    )
    parser.add_argument("--cargo", default="cargo", help="rustup cargo proxy")
    parser.add_argument(
        "--offline", action="store_true", help="use cached Cargo registry packages"
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="destination for the independently regenerated receipt",
    )
    args = parser.parse_args()
    require(
        sys.implementation.name == "cpython"
        and sys.version_info[:2] == (3, 14)
        and not sys.flags.optimize,
        "use CPython 3.14 without -O",
    )
    corpus = official_corpus(args.suite) if args.suite else args.corpus.read_bytes()
    with tempfile.TemporaryDirectory(prefix="imre-regex-study-") as temporary:
        work = Path(temporary)
        checkout = work / "checkout"
        checkout.mkdir()
        with tempfile.TemporaryFile() as archive:
            subprocess.run(
                ["git", "-C", args.checkout, "archive", "--format=tar", REVISION],
                stdout=archive,
                check=True,
            )
            archive.seek(0)
            with tarfile.open(fileobj=archive, mode="r:") as tar:
                require(
                    tar.pax_headers.get("comment") == REVISION,
                    "archive does not identify the frozen commit",
                )
                tar.extractall(checkout, filter="data")
        shutil.copytree(ROOT / "probe", work / "probe")
        target = Path(os.environ.get("CARGO_TARGET_DIR", work / "target")).resolve()
        cargo = [args.cargo, "+" + args.toolchain]
        flags = ["-Zohm-defaults=no"] if args.toolchain.startswith("ohm") else []
        command = [*cargo, *flags, "build", "--locked", "--target-dir", target]
        if args.offline:
            command.append("--offline")
        subprocess.run(command, cwd=work / "probe", check=True)
        receipt = verify(
            target / "debug/imre-fixed-regex-native-oracle", checkout, corpus
        )
        receipt["cargo"] = subprocess.check_output(
            [*cargo, "--version"], text=True
        ).strip()
        args.output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        print(
            f"Verified {receipt['generated']['counts']['python_comparisons']:,} generated searches and {sum(x['haystacks'] for x in receipt['corpus']['cases']):,} real and adversarial searches."
        )


if __name__ == "__main__":
    main()
