#[path = "../../checkout/crates/relar-compiler/src/fixed_regex.rs"]
mod fixed_regex;
use relar_runtime::Str;
use serde_json::{Value, json};
use std::io::{self, BufRead};
use std::rc::Rc;
unsafe extern "C" {
    fn relar_regex_compile(p: *const u8, n: usize) -> *const ();
    fn relar_regex_search(p: *const (), s: *const Str) -> *const ();
    fn relar_regex_group(m: *const (), sel: usize, name: u8) -> *const Str;
    fn relar_regex_present(m: *const (), sel: usize, name: u8) -> u8;
    fn relar_regex_bound(m: *const (), sel: usize, name: u8, end: u8) -> usize;
    fn relar_object_release(o: *const ());
    fn relar_error_pending() -> u8;
}
unsafe fn group(m: *const (), sel: usize, named: u8) -> Value {
    unsafe {
        let p = relar_regex_group(m, sel, named);
        let s = if p.is_null() {
            None
        } else {
            Some(Rc::from_raw(p).to_string())
        };
        assert_eq!(relar_regex_present(m, sel, named), u8::from(s.is_some()));
        let idx = |end| (relar_regex_bound(m, sel, named, end) as isize) >> 1;
        let v = json!([s, idx(0), idx(1)]);
        assert_eq!(relar_error_pending(), 0);
        v
    }
}
fn main() {
    for row in io::stdin().lock().lines() {
        let row: Value = serde_json::from_str(&row.unwrap()).unwrap();
        let pat = row["p"].as_str().unwrap();
        let verbose = row["v"].as_bool().unwrap();
        let translated = match fixed_regex::translate(pat, verbose) {
            Ok(p) => p,
            Err(e) => {
                println!("{}", json!({"reject":e}));
                continue;
            }
        };
        let meta = regex::Regex::new(&translated.source).unwrap();
        assert!(
            meta.capture_names()
                .eq(translated.groups.iter().map(Option::as_deref))
        );
        let mut outputs = Vec::new();
        unsafe {
            let regex = relar_regex_compile(translated.source.as_ptr(), translated.source.len());
            for input in row["h"].as_array().unwrap() {
                let text = Rc::new(Str::new(input.as_str().unwrap()));
                let m = relar_regex_search(regex, Rc::as_ptr(&text));
                drop(text);
                if m.is_null() {
                    outputs.push(Value::Null);
                    continue;
                }
                let mut groups = Vec::new();
                for (index, name) in meta.capture_names().enumerate() {
                    let g = group(m, (index << 1) | 1, 0);
                    if let Some(name) = name {
                        let n = Str::new(name);
                        assert_eq!(g, group(m, &n as *const Str as usize, 1));
                    }
                    groups.push(g);
                }
                outputs.push(Value::Array(groups));
                relar_object_release(m);
            }
            relar_object_release(regex);
        }
        println!("{}", json!({"results":outputs}));
    }
}
