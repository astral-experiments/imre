# Native fixed-regex differential

This study compares the Imre C ABI with CPython 3.14 on the fixed regex implementation in commit `4eb4e4cd6aa81685bb42a7f1e95c1596901d3fc8`. It checks all capture contents, missing and empty groups, group presence, and Unicode code-point start and end offsets. Each match is read after the caller releases its input. Named selectors are also compared with their integer selectors.

## Replay

Use CPython 3.14, Git, a Rustup Cargo proxy, and an installed Rust toolchain compatible with the frozen workspace (Rust 1.98 or newer). Set `IMRE_CHECKOUT` to a Git checkout containing the pinned commit and `TYPING_SUITE` to the public `python/typing` suite checkout at `835b70f3f795f8e061b1f7621178515b0a77a0ad`. The latter directory contains `conformance/tests/`.

```sh
python3.14 replay.py --checkout "$IMRE_CHECKOUT" --suite "$TYPING_SUITE" --toolchain 1.99.0 --output replay.json
```

To use a retained UTF-8 NUL-separated scanner corpus, pass `--corpus "$CORPUS"` instead of `--suite "$TYPING_SUITE"`. Its required SHA-256 is `03674dfbf69acfcdf4ed315a6c7d0a8028c6841feb8ec3989dc959b4ae86903c`. The official benchmark writes it as `corpus.txt`. `suite.json` records the 146 public source files in benchmark order and their individual SHA-256 hashes. A trailing NUL changes the input.

`--toolchain ohm` selects an installed Ohm Rustup toolchain and disables its experimental Cargo defaults. `--offline` uses an already populated Cargo registry cache. Optional `CARGO_HOME`, `CARGO_TARGET_DIR` and `CARGO_BUILD_BUILD_DIR` are respected. The default target and freshly extracted source tree are temporary. The replay builds from the exact committed Git archive with a locked, standalone probe manifest.

## Recorded observations

- Seed `8522727` produces 1,372 patterns. The Imre validator accepts 782 and rejects 590. Each accepted pattern runs against the same ordered 144 inputs. The 112,608 CPython comparisons cover 57,474 participating and nonparticipating capture slots across successful matches.
- The second panel includes all 14,986 real source lines and 21 additional haystacks. The real input produces 1,329 matches and 6,645 group comparisons. The supplemental inputs exercise misleading prefixes, wide capture layouts, multibyte text, offsets around 65,535 bytes, and bounded-engine fallback on an 800,002-byte haystack.
- `receipts/generated.json` and `receipts/corpus.json` preserve the original observations. The replay checks the same runtime, validator, upstream source, literal pattern, corpus, generated request and native output hashes. It also recomputes the CPython observations and panel counts. The original generator and executable hashes identify the original local build. The replay records its own executable hash because Cargo toolchains and build paths affect binary identity.

The archive carries the verifier, probe, Cargo lockfile, original receipts, and ordered file manifest. Inputs are read from the caller's checkout or supplied corpus. SHA256SUMS covers every other file in the archive.
