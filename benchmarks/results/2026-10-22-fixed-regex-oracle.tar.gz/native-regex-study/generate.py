import itertools
import random
import sys


def generate(pattern):
    rng = random.Random(8522727)
    spaces = [chr(n) for n in range(sys.maxunicode + 1) if chr(n).isspace()]
    assert len(spaces) == 29
    hay = sorted(
        set(
            ["".join(c) for n in range(5) for c in itertools.product("ab", repeat=n)]
            + list("éΠ🌍0_")
            + [
                "# E",
                "a\n",
                "é🌍#E?",
                "aba\r\n",
                "\n",
                "\r",
                "\x00",
                "\u200b",
                "\ufeff",
                "a-b",
                "ab\ncd",
                "[]",
                "ab|",
                "bbé",
                "xzz",
            ]
            + spaces
            + ["a" + c + "b" for c in spaces]
            + ["#" + c + "E?" for c in spaces]
            + [
                "#E[tag+] #E?: desc",
                "🌍x # E[αé+]: hi",
                "\r# E[]:bad",
                "xx # E? :",
                "E",
                "x # E\nline",
                " # E[+] :x",
                "xx # E[tag+]: a # E: b",
            ]
        )
    )
    valid = [
        ("", False),
        ("(?:)", False),
        (pattern, True),
        ("\\A(?:a|b)?\\z", False),
        ("\\A(?:a|b)?\\Z", False),
        ("(?P<a>)(?P<m>b)?", False),
        ("(?P<t>\\s*)?", False),
        ("[\\s][^\\s]\\S", False),
        ("[^\\S]+", False),
        ("[a\\S]?", False),
        ("[]x]", False),
        ("[\\x00-\\x1f]+", False),
        ("[a-z\\-\\]]+?", False),
        ("\\U0001f30d", False),
        ("\\x61\\u0062", False),
        ("\\#\\ \\t", True),
        ("a\xa0b", True),
        ("a\u2003b", True),
        ("a # line\rstill\nb", True),
        ("[ #a]", True),
        ("a|a.", False),
        ("ab|a", False),
        ("a|ab", False),
        ("|a", False),
        ("a|", False),
        ("(a|ab)?b", False),
        ("(ab|a)?b", False),
        ("(?P<x>a*)?(?P<y>b?)", False),
        ("\\a[\\b]\\f", False),
    ]
    reject = [
        "$",
        "a$",
        "(?=x)",
        "(?!x)",
        "(?<=a)b",
        "(?>a)",
        "(?P<x>a)(?P=x)",
        "(a)\\1",
        "\\w",
        "\\W",
        "\\d",
        "\\D",
        "\\b",
        "\\B",
        "\\p{L}",
        "(?i)a",
        "a++",
        "a**",
        "a+ ?",
        "a{1, 2}",
        "(a)+",
        "(a?)*",
        "[a&&b]",
        "[a--z]",
        "[[x]]",
        "[a-\\s]",
        "[\\s-a]",
        "\\x5",
        "\\uD800",
        "(?P<1>a)",
        "(?P<x>a)(?P<x>b)",
        "\\N{SPACE}",
        "(? :ab)",
        "(?P <x>a)",
    ]
    valid += [("a# continuing" + "\\" * i + "\nb", True) for i in (1, 2, 3)]
    valid += [
        ("(a)?(b)?(x)?(z)?(?P<fifth>b)?(?P<sixth>a)?", False),
        ("\\#a\\#b", False),
        ("a{1,30}z", False),
    ]
    reject += ["a#dangling" + chr(92), "(?:){4294967295}", "a{1,4294967295}"]
    rows = [(p, v, "required") for p, v in valid] + [
        (p, True, "rejected") for p in reject
    ]
    atoms = [
        "a",
        "b",
        "x",
        "0",
        "🌍",
        "é",
        ".",
        "\\s",
        "\\S",
        "\\n",
        "\\t",
        "\\x61",
        "[ab]",
        "[^a]",
        "[a-c]",
        "[a\\s]",
        "[^\\S]",
        "[]b]",
        "[-a]",
    ]
    suffixes = [
        "",
        "",
        "?",
        "??",
        "*",
        "*?",
        "+",
        "+?",
        "{0,2}",
        "{1,3}?",
        "{2}",
        "{2,}",
    ]
    for _ in range(1300):
        names = itertools.count()

        def expr(depth):
            s = []
            for _ in range(rng.randint(1, 3)):
                if depth and rng.randrange(3) == 0:
                    inside = expr(depth - 1)
                    if rng.randrange(2) == 0:
                        inside += "|" + expr(depth - 1)
                    head = rng.choice(["(", "(?:", "(?P<g" + str(next(names)) + ">"])
                    a = head + inside + ")"
                else:
                    a = rng.choice(atoms)
                s.append(a + rng.choice(suffixes))
            return "".join(s)

        p = expr(2)
        rows.append((p, rng.randrange(4) == 0, "generated"))
    return (rows, hay)
