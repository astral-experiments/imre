#!/usr/bin/env python3
"""Plan, prepare, or pilot one frozen candidate; these are separate commands.

`plan` only reads sources/artifacts and writes commands plus hash bindings.
`prepare` invokes the existing telemetry harness's compile/oracle phase in both
modes. `pilot` invokes the four-case selection wrapper, only after root explicitly
starts timing with no heavy concurrent work. No Cargo/rustc command is run here.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from types import SimpleNamespace


BASELINE = Path("/tmp/elir-telemetry-full-v1-thinlto.json")
BASELINE_SHA = "bbe69e51b7b9315bfc3e755020999443671c7f3987a3298e033610b301c87401"
REFERENCES = Path("/tmp/relar-rename-validation-v2/references")
REFERENCE_RECORD_SHA = {
    "normal": "ee20901935a5265b958d74cdeae71f0245ff01edeadb8b4c39cecc8cea044c9c",
    "thinlto": "e8913e1e708aa6f6a152fd223360d341a13b4271f06fd08e2daf8630708b3190",
}
WRAPPER = Path("/tmp/relar-telemetry-pilot.py")
WRAPPER_SHA = "e69533dc27f14c6159dcb0d97f7778f633823d4a6cf0aec36a81b1e9b74c0c9d"
MODES = ("normal", "thinlto")


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def git(root, *arguments):
    return subprocess.check_output(["git", "-C", str(root), *arguments], text=True).strip()


def clean(root, revision):
    assert git(root, "rev-parse", "HEAD") == revision
    assert not git(root, "status", "--porcelain=v1", "--untracked-files=all")


def make_plan(args):
    root = args.root.resolve(strict=True)
    validation = args.validation.resolve(strict=True)
    output = args.output.resolve()
    assert not output.exists() and not output.is_relative_to(root) and not output.is_relative_to(validation)
    index_path, build_path = validation / "index.json", validation / "build.json"
    index, build = load(index_path), load(build_path)
    revision = args.revision
    clean(root, revision)
    assert index["status"] == "passed" and index["source_unchanged"] and index["input_guards_passed"]
    assert index["revision"] == build["revision"] == revision
    assert build["source_matches_revision"] and build["input_guards_passed"]
    assert index["build_record"]["sha256"] == sha(build_path)
    assert sha(BASELINE) == BASELINE_SHA and sha(WRAPPER) == WRAPPER_SHA
    baseline = load(BASELINE)
    harness = root / "benchmarks/telemetry_benchmark.py"
    delegate = runpy.run_path(str(harness), run_name="telemetry_evidence_delegate")
    paths = {"helper": Path(__file__).resolve(), "wrapper": WRAPPER, "baseline": BASELINE,
             "validation_index": index_path, "build_record": build_path}
    evidence_path = validation / "evidence-sha256.json"
    assert sha(evidence_path) == index["evidence_manifest_sha256"]
    paths["validation_evidence_manifest"] = evidence_path
    for relative, expected in load(evidence_path).items():
        path = (validation / relative).resolve(strict=True)
        assert path.is_relative_to(validation) and sha(path) == expected
        paths["validation_evidence:" + relative] = path
    for name, item in build["tools"].items():
        path = Path(item["path"])
        assert sha(path) == item["sha256"]
        paths["build_tool:" + name] = path
    python = Path(baseline["preparation"]["source_and_tool_paths"]["python"])
    clang = Path(baseline["preparation"]["source_and_tool_paths"]["clang"])
    linker = Path(baseline["preparation"]["source_and_tool_paths"]["lto_linker"])
    common, preparation = {}, {}
    for mode in MODES:
        reference = REFERENCES / ("telemetry-" + mode)
        rust_record_path = reference / "build-record.json"
        assert sha(rust_record_path) == REFERENCE_RECORD_SHA[mode]
        selected = SimpleNamespace(
            compiler=build["artifacts"]["compiler"]["path"],
            runtime=Path(build["artifacts"]["thinlto_runtime" if mode == "thinlto" else "normal_runtime"]["path"]),
            python=str(python), clang=str(clang), rust=reference / "telemetry-reference",
            rust_build_record=rust_record_path, relar_build_record=build_path,
            target=build["target"], lto_linker=linker if mode == "thinlto" else None,
        )
        selected_paths, rust_record, _ = delegate["source_paths"](selected)
        assert rust_record["rustc_verbose"] == baseline["preparation"]["rust_build_record"]["rustc_verbose"]
        for name in ("python", "clang", "rust_source:src/main.rs",
                     *(key for key in selected_paths if key.startswith("example:") and key.endswith(".py"))):
            assert sha(selected_paths[name]) == baseline["source_and_tool_sha256"][name], name
        if mode == "thinlto":
            assert sha(selected_paths["lto_linker"]) == baseline["source_and_tool_sha256"]["lto_linker"]
        paths.update({mode + ":" + name: path for name, path in selected_paths.items()})
        command = [str(python), "-I", "-B", str(harness),
                   "--compiler", selected.compiler, "--runtime", str(selected.runtime),
                   "--relar-build-record", str(build_path), "--python", str(python),
                   "--rust", str(selected.rust), "--rust-build-record", str(rust_record_path),
                   "--clang", str(clang), "--target", selected.target]
        if mode == "thinlto":
            command += ["--lto-linker", str(linker)]
        common[mode] = command
        preparation[mode] = command + ["--prepare-only", "--artifact-dir", str(output / ("prepared-" + mode)),
                                       "--output", str(output / ("prepared-" + mode + ".json"))]
    pilot = [str(python), "-I", "-B", str(WRAPPER), "--harness", str(harness),
             "--baseline", str(BASELINE), *common["thinlto"][4:],
             "--prepared-record", str(output / "prepared-thinlto.json"),
             "--artifact-dir", str(output / "pilot-thinlto"), "--output", str(output / "pilot-thinlto.json"),
             "--cpu", "0", "--samples", "6", "--warmups", "1"]
    clean(root, revision)
    record = {
        "schema": 1, "status": "planned", "created_at": now(), "revision": revision,
        "root": str(root), "output": str(output), "validation_mode": index.get("mode", "full-validation"),
        "validation_scope": index["scope"], "validation_full_matrix_passed": index.get("full_validation_passed", True),
        "protected_paths": {name: str(path) for name, path in paths.items()},
        "protected_sha256": {name: sha(path) for name, path in paths.items()},
        "commands": {"prepare": preparation, "pilot": pilot},
        "reference_reuse": "Unmodified validation-v2 records and binaries; original stage paths remain provenance. Existing harness verifies logical source names/content hashes against this checkout.",
        "timing_policy": "Pilot is separate, CPU 0, outside ptrace, after root signals no builds/profiles/other timing or heavy hashing. Complete-process ratios, no control subtraction.",
        "input_guards_passed": True,
    }
    output.mkdir(parents=True)
    save(output / "plan.json", record)
    print(json.dumps({"plan": str(output / "plan.json"), "sha256": sha(output / "plan.json"),
                      "protected_files": len(paths), "commands": record["commands"]}, indent=2))


def guard(plan):
    clean(Path(plan["root"]), plan["revision"])
    assert plan["protected_sha256"] == {name: sha(path) for name, path in plan["protected_paths"].items()}


def timing_environment():
    status = Path("/proc/self/status").read_text()
    tracer = int(next(line.split()[1] for line in status.splitlines() if line.startswith("TracerPid:")))
    assert tracer == 0, "Run timing outside ptrace"
    assert 0 in os.sched_getaffinity(0), "CPU 0 must be available"
    heavy = {"cargo", "rustc", "clippy-driver", "clang", "clang-18", "cc1", "ld.lld", "rust-lld",
             "valgrind", "perf", "relar", "telemetry", "telemetry-reference"}
    scripts = {"telemetry_benchmark.py", "telemetry_validate.py", "relar-telemetry-pilot.py",
               "relar-iterator-performance-validation.py", "relar-rename-validation-runner.py"}
    conflicts = []
    for path in Path("/proc").iterdir():
        if not path.name.isdigit() or int(path.name) == os.getpid():
            continue
        try:
            command = (path / "cmdline").read_bytes().split(b"\0")
            names = {Path(part.decode(errors="replace")).name for part in command if part}
            name = (path / "comm").read_text().strip()
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
        if names & (heavy | scripts) or name in heavy or any(
            value.startswith(("callgrind-", "dhat-", "memcheck-")) for value in names | {name}
        ):
            conflicts.append({"pid": int(path.name), "name": name})
    assert not conflicts, ("Stop concurrent build/profile/telemetry processes before timing", conflicts)
    return {"tracer_pid": tracer, "allowed_cpus": sorted(os.sched_getaffinity(0)),
            "known_heavy_processes": conflicts, "cpu": 0}


def execute_phase(args):
    plan_path = args.plan.resolve(strict=True)
    plan = load(plan_path)
    guard(plan)
    output = Path(plan["output"])
    status_path = output / (args.command + "-status.json")
    assert not status_path.exists(), "Preserve previous evidence; use a fresh plan/output directory"
    commands = plan["commands"]["prepare"] if args.command == "prepare" else {"thinlto": plan["commands"]["pilot"]}
    if args.command == "prepare":
        assert all(not (output / ("prepared-" + mode + suffix)).exists() for mode in MODES for suffix in ("", ".json"))
    if args.command == "pilot":
        prepared_status = load(output / "prepare-status.json")
        assert prepared_status["status"] == "passed" and prepared_status["plan_sha256"] == sha(plan_path)
        for mode in MODES:
            prepared = load(output / ("prepared-" + mode + ".json"))
            assert prepared["input_guards_passed"] and prepared["revision"] == plan["revision"] and not prepared["dirty"]
            assert sha(output / ("prepared-" + mode + ".json")) == prepared_status["runs"][MODES.index(mode)]["output_sha256"]
    record = {"schema": 1, "phase": args.command, "status": "running", "started_at": now(),
              "plan": str(plan_path), "plan_sha256": sha(plan_path), "revision": plan["revision"],
              "validation_full_matrix_passed": plan["validation_full_matrix_passed"], "runs": []}
    save(status_path, record)
    try:
        for mode, command in commands.items():
            guard(plan)
            if args.command == "pilot":
                record["timing_environment"] = timing_environment()
            stdout, stderr = output / (args.command + "-" + mode + ".stdout"), output / (args.command + "-" + mode + ".stderr")
            run = {"mode": mode, "command": command, "started_at": now(), "stdout": str(stdout), "stderr": str(stderr)}
            record["runs"].append(run)
            save(status_path, record)
            with stdout.open("xb") as out, stderr.open("xb") as err:
                process = subprocess.run(command, cwd=plan["root"], stdout=out, stderr=err, check=False)
            run.update(exit_code=process.returncode, completed_at=now(), stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
            assert process.returncode == 0, (mode, "See retained stdout/stderr")
            result_path = Path(command[command.index("--output") + 1])
            result = load(result_path)
            assert result["input_guards_passed"] and result["revision"] == plan["revision"] and not result["dirty"]
            run.update(output=str(result_path), output_sha256=sha(result_path), status="passed")
            if args.command == "pilot":
                record["relar_over_rust"] = {value["label"]: value["relar_over_rust"] for value in result["workloads"]}
                record["all_four_below_two"] = len(record["relar_over_rust"]) == 4 and all(value < 2 for value in record["relar_over_rust"].values())
                record["exploratory"] = True
            guard(plan)
            assert sha(plan_path) == record["plan_sha256"]
            save(status_path, record)
        record.update(status="passed", input_guards_passed=True)
    except BaseException as error:
        record.update(status="failed", error=repr(error))
        raise
    finally:
        record["completed_at"] = now()
        save(status_path, record)
    print(json.dumps({"status": record["status"], "phase": args.command, "record": str(status_path),
                      "sha256": sha(status_path), "relar_over_rust": record.get("relar_over_rust")}, indent=2))


def main():
    if sys.flags.optimize:
        raise RuntimeError("Run evidence guards without Python -O")
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    plan = commands.add_parser("plan", help="read-only input checks and exact command preparation")
    plan.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/relar"))
    plan.add_argument("--revision", required=True)
    plan.add_argument("--validation", type=Path, required=True)
    plan.add_argument("--output", type=Path, required=True)
    for name in ("prepare", "pilot"):
        command = commands.add_parser(name)
        command.add_argument("--plan", type=Path, required=True)
    args = parser.parse_args()
    make_plan(args) if args.command == "plan" else execute_phase(args)


if __name__ == "__main__":
    main()
