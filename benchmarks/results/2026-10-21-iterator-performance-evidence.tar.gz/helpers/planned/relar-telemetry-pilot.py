#!/usr/bin/env python3
"""Measure the four published 4096-record full scans with the existing harness.

All compiler/runtime/Rust/build-record/target/CPU options are forwarded unchanged
to telemetry_benchmark.py. Preparation must already exist; this wrapper performs
no build. Defaults are six measured rounds, one warmup, CPU 0, and the original
8,388,608-pair batch. The measurement loop remains entirely in the harness.
"""

import argparse
import hashlib
import json
from pathlib import Path
import runpy
import sys
import tempfile


BASELINE_SHA256 = "bbe69e51b7b9315bfc3e755020999443671c7f3987a3298e033610b301c87401"
CANONICAL_SIZES = [16, 256, 4096]
SCENARIOS = ["report-mixed", "alert-quiet", "within-quiet", "latest-quiet"]
BATCH_PAIRS = 8_388_608
MATCHED_FIELDS = (
    "label", "scenario", "inspected_pairs_per_call", "repetitions", "case",
    "expected_stdout", "expected_files",
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def has_option(arguments, name):
    return any(value == name or value.startswith(name + "=") for value in arguments)


def main():
    original_command = [sys.executable, *sys.orig_argv[1:]]
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--harness", type=Path,
                        default=Path("/home/dev-user/code/oss/relar/benchmarks/telemetry_benchmark.py"))
    parser.add_argument("--baseline", type=Path,
                        default=Path("/tmp/elir-telemetry-full-v1-thinlto.json"))
    args, forwarded = parser.parse_known_args()
    if "--" in forwarded:
        forwarded.remove("--")
    for name, values in (
        ("--samples", ["6"]), ("--warmups", ["1"]), ("--cpu", ["0"]),
        ("--sizes", ["4096"]), ("--scenarios", SCENARIOS),
        ("--batch-pairs", [str(BATCH_PAIRS)]),
    ):
        if not has_option(forwarded, name):
            forwarded += [name, *values]

    # Inspect only the options needed by the wrapper. The original parser owns
    # all compiler, runtime, Rust, target, scheduling, and validation options.
    probe = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    for name in ("--prepared-record", "--relar-build-record", "--lto-linker",
                 "--artifact-dir", "--output"):
        probe.add_argument(name, type=Path, required=True)
    probe.add_argument("--prepare-only", action="store_true")
    probe.add_argument("--allow-dirty", action="store_true")
    selected, _ = probe.parse_known_args(forwarded)
    assert not selected.prepare_only and not selected.allow_dirty
    assert not selected.output.exists(), "Use a fresh output file"
    assert not selected.artifact_dir.exists(), "Use a fresh measurement directory"

    protected = {
        "wrapper": Path(__file__).resolve(strict=True),
        "harness": args.harness.resolve(strict=True),
        "baseline": args.baseline.resolve(strict=True),
        "preparation": selected.prepared_record.resolve(strict=True),
    }
    contents = {name: path.read_bytes() for name, path in protected.items()}
    hashes = {name: digest(value) for name, value in contents.items()}
    assert hashes["baseline"] == BASELINE_SHA256, "The historical baseline must remain unchanged"
    for path in protected.values():
        assert selected.output.resolve() != path
        assert not path.is_relative_to(selected.artifact_dir.resolve())

    baseline = json.loads(contents["baseline"])
    prepared = json.loads(contents["preparation"])
    assert baseline["input_guards_passed"] and baseline["thinlto"]
    assert baseline["batch_pairs"] == BATCH_PAIRS
    assert prepared["input_guards_passed"] and prepared["thinlto"]
    fixed_hash_keys = [
        "python", "clang", "lto_linker", "rust_source:src/main.rs",
        *(key for key in baseline["source_and_tool_sha256"]
          if key.startswith("example:") and key.endswith(".py")),
    ]
    for key in fixed_hash_keys:
        assert prepared["source_and_tool_sha256"][key] == baseline["source_and_tool_sha256"][key], (
            "Program or comparison-tool identity changed", key
        )
    assert prepared["rust_build_record"]["rustc_verbose"] == baseline["preparation"]["rust_build_record"]["rustc_verbose"]
    assert prepared["effective_target"] == baseline["preparation"]["effective_target"]
    labels = [scenario + "-4096" for scenario in SCENARIOS]
    frozen = {value["label"]: {field: value[field] for field in MATCHED_FIELDS}
              for value in baseline["workloads"] if value["label"] in labels}
    assert set(frozen) == set(labels)
    selection = {
        "kind": "canonical-generation-then-size-selection",
        "canonical_sizes": CANONICAL_SIZES,
        "selected_sizes": [4096],
        "selected_scenarios": SCENARIOS,
        "selected_labels": labels,
        "batch_pairs": BATCH_PAIRS,
        "baseline_revision": baseline["revision"],
        "baseline_native_binary_sha256": baseline["binary_sha256"],
        "baseline_rust_binary_sha256": baseline["source_and_tool_sha256"]["rust"],
        "protected_paths": {name: str(path) for name, path in protected.items()},
        "protected_sha256": hashes,
        "wrapper_source": contents["wrapper"].decode(),
        "command": original_command,
        "matched_fields": list(MATCHED_FIELDS),
        "fixed_program_and_tool_sha256": {
            key: baseline["source_and_tool_sha256"][key] for key in fixed_hash_keys
        },
        "measurement_loop": "Unmodified telemetry_benchmark.py main/measure functions",
    }
    # Do not retain historical timing rounds or duplicate preparation reports
    # in the parent process during the new measurement.
    del baseline, prepared, contents

    namespace = runpy.run_path(str(protected["harness"]), run_name="telemetry_pilot_delegate")
    original_workloads = namespace["workloads"]
    generated_count = 0

    def select_workloads(sizes, batch_pairs, scenarios):
        nonlocal generated_count
        assert sizes == [4096] and batch_pairs == BATCH_PAIRS
        assert list(scenarios) == SCENARIOS
        generated = original_workloads(CANONICAL_SIZES, batch_pairs, scenarios)
        assert len(generated) == len(CANONICAL_SIZES) * len(SCENARIOS)
        chosen = [value for value in generated if value["records"] == 4096]
        assert [value["label"] for value in chosen] == labels
        for value in chosen:
            expected = frozen[value["label"]]
            for field in MATCHED_FIELDS:
                assert value[field] == expected[field], (value["label"], field)
        generated_count += 1
        assert generated_count == 1, "The harness must generate its workload list once"
        selection["generated_workload_count"] = len(generated)
        selection["selected_workload_count"] = len(chosen)
        selection["cases"] = [
            {"label": value["label"], "records": value["records"],
             "repetitions": value["repetitions"],
             "inspected_pairs_per_call": value["inspected_pairs_per_call"],
             "input_sha256": {name: item["sha256"] for name, item in value["case"]["files"].items()}}
            for value in chosen
        ]
        selection["canonical_input_and_repetition_checks_passed"] = True
        return chosen

    # Change only input selection. main(), measure(), orders, validation,
    # complete output checking, preparation checks, and timing stay original.
    namespace["main"].__globals__["workloads"] = select_workloads
    sys.argv = [str(protected["harness"]), *forwarded]
    namespace["main"]()
    assert generated_count == 1
    assert hashes == {name: digest(path.read_bytes()) for name, path in protected.items()}
    result = json.loads(selected.output.read_text())
    assert result["input_guards_passed"] and result["thinlto"] and not result["dirty"]
    assert [value["label"] for value in result["workloads"]] == labels
    for value in result["workloads"]:
        assert value["records"] == 4096
        assert all(value[field] == frozen[value["label"]][field] for field in MATCHED_FIELDS)
    selection["input_guards_passed"] = True
    result["workload_selection"] = selection
    with tempfile.NamedTemporaryFile(mode="w", dir=selected.output.parent,
                                     prefix=selected.output.name + ".", delete=False) as output:
        json.dump(result, output, indent=2)
        output.write("\n")
        temporary = Path(output.name)
    temporary.replace(selected.output)
    print("Verified unchanged canonical inputs and appended selection provenance")


if __name__ == "__main__":
    main()
