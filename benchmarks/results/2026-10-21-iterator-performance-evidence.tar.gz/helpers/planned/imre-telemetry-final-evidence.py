#!/usr/bin/env python3
"""Extend a fully validated candidate plan with the final four-record schedule.

`plan --candidate-plan PATH --output DIR` checks complete full validation, both
preparations, and unchanged canonical workloads, then writes an immutable plan.
`measure --plan DIR/plan.json --phase full|early` runs only that reviewed phase.
Each phase uses ordinary then ThinLTO, CPU 0, 12 measured rounds, and 8 warmups.
No build or preparation is performed here. The repository harness is unchanged.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path
import runpy
import subprocess
import sys
from types import SimpleNamespace


MODES = ("normal", "thinlto")
SIZES = [16, 256, 4096]
SAMPLES = 12
WARMUPS = 8
FIELDS = ("label", "scenario", "inspected_pairs_per_call", "repetitions", "case", "expected_stdout", "expected_files")
PHASES = {
    "full": {"batch_pairs": 8_388_608, "scenarios": ["report-mixed", "alert-quiet", "within-quiet", "latest-quiet"]},
    "early": {"batch_pairs": 2_097_152, "scenarios": ["alert-early", "within-early", "latest-recent"]},
}
BASELINE_SHA = {
    "full-normal": "890834d3dedc0bbd39e1788b083ff32214f72372cb1caf93599b9f3bfcaf15a7",
    "full-thinlto": "bbe69e51b7b9315bfc3e755020999443671c7f3987a3298e033610b301c87401",
    "early-normal": "030357302cfc760a119f4c62f7ffe29120b899a5073917a7a93699a51fff1cf5",
    "early-thinlto": "b2f630c600e24a3acd7d1e94d36e4f41d98cdb82d86517730bfd9449567738f2",
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def hashes(paths):
    unique = {str(Path(path).absolute()): None for path in paths.values()}
    unique = {path: sha(path) for path in unique}
    return {name: unique[str(Path(path).absolute())] for name, path in paths.items()}


def json_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def now():
    return datetime.now(timezone.utc).isoformat()


def clean(root, revision):
    head = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
    status = subprocess.check_output(["git", "-C", str(root), "status", "--porcelain=v1", "--untracked-files=all"], text=True).strip()
    require(head == revision and not status, "candidate revision or clean source state changed")


def option(command, name):
    require(command.count(name) == 1, "expected exactly one " + name)
    return command[command.index(name) + 1]


def guard(plan):
    require(str(Path(sys.executable).resolve()) == plan["protected_paths"]["final_helper_python"],
            "final helper interpreter changed")
    clean(plan["root"], plan["revision"])
    require(hashes(plan["protected_paths"]) == plan["protected_sha256"], "frozen final measurement input changed")


def make_plan(args):
    candidate_path = args.candidate_plan.resolve(strict=True)
    candidate = load(candidate_path)
    root = Path(candidate["root"])
    output = args.output.resolve()
    require(candidate["status"] == "planned" and candidate["input_guards_passed"], "candidate plan is incomplete")
    require(candidate["validation_full_matrix_passed"] is True, "final measurements require completed full validation")
    require(not output.exists() and not output.is_relative_to(root), "use a new external measurement directory")
    candidate_paths = {name: Path(path) for name, path in candidate["protected_paths"].items()}
    require(hashes(candidate_paths) == candidate["protected_sha256"], "candidate source/build/tool input changed")
    clean(root, candidate["revision"])
    index = load(candidate_paths["validation_index"])
    require(index["status"] == "passed" and index["input_guards_passed"] and index["source_unchanged"]
            and index["mode"] == "full-validation" and index["full_validation_passed"] is True
            and index["revision"] == candidate["revision"], "full validation scope or result differs")
    preparation_status_path = Path(candidate["output"]) / "prepare-status.json"
    preparation_status = load(preparation_status_path)
    require(preparation_status["status"] == "passed" and preparation_status["input_guards_passed"]
            and preparation_status["plan_sha256"] == sha(candidate_path), "candidate preparation phase is incomplete")
    harness = root / "benchmarks/telemetry_benchmark.py"
    delegate = runpy.run_path(str(harness), run_name="telemetry_final_plan_delegate")
    paths = {"candidate:" + name: path for name, path in candidate_paths.items()}
    paths.update(final_helper=Path(__file__).resolve(), candidate_plan=candidate_path,
                 preparation_status=preparation_status_path, final_helper_python=Path(sys.executable).resolve())
    expected_hashes = {"candidate:" + name: value for name, value in candidate["protected_sha256"].items()}
    expected_hashes.update({name: sha(paths[name]) for name in
                            ("final_helper", "candidate_plan", "preparation_status", "final_helper_python")})
    common = {}
    preparations = {}
    for mode in MODES:
        command = candidate["commands"]["prepare"][mode]
        prepared_path = Path(option(command, "--output")).resolve(strict=True)
        runs = [item for item in preparation_status["runs"] if item["mode"] == mode]
        require(len(runs) == 1, "preparation mode is missing or duplicated")
        run = runs[0]
        require(run["command"] == command and run["status"] == "passed" and run["exit_code"] == 0
                and Path(run["output"]).resolve() == prepared_path and run["output_sha256"] == sha(prepared_path),
                "completed preparation command or output differs")
        prepared = load(prepared_path)
        selected = SimpleNamespace(
            compiler=option(command, "--compiler"), runtime=Path(option(command, "--runtime")),
            python=option(command, "--python"), clang=option(command, "--clang"),
            rust=Path(option(command, "--rust")), rust_build_record=Path(option(command, "--rust-build-record")),
            imre_build_record=Path(option(command, "--imre-build-record")), target=option(command, "--target"),
            lto_linker=Path(option(command, "--lto-linker")) if mode == "thinlto" else None,
        )
        source_paths, _, _ = delegate["source_paths"](selected)
        delegate["verify_preparation"](prepared, selected, source_paths, hashes(source_paths), candidate["revision"], False)
        boundary = command.index("--prepare-only")
        require(command[boundary:] == ["--prepare-only", "--artifact-dir", option(command, "--artifact-dir"),
                                       "--output", str(prepared_path)], "unexpected preparation command suffix")
        common[mode] = command[:boundary]
        preparations[mode] = {"path": str(prepared_path), "sha256": sha(prepared_path),
                              "binary_sha256": prepared["binary_sha256"]}
        paths[mode + ":preparation"] = prepared_path
        expected_hashes[mode + ":preparation"] = preparations[mode]["sha256"]
        for name in ("binary", "llvm", "validation_path"):
            paths[mode + ":" + name] = Path(prepared[name])
            expected_hashes[mode + ":" + name] = prepared[("validation" if name == "validation_path" else name) + "_sha256"]
    phases = {}
    for phase, schedule in PHASES.items():
        generated = delegate["workloads"](SIZES, schedule["batch_pairs"], schedule["scenarios"])
        for mode in MODES:
            baseline_path = Path(f"/tmp/elir-telemetry-{phase}-v1-{mode}.json")
            require(sha(baseline_path) == BASELINE_SHA[phase + "-" + mode], "historical baseline changed")
            baseline = load(baseline_path)
            require(baseline["input_guards_passed"] and baseline["samples"] == SAMPLES and baseline["warmups"] == WARMUPS
                    and baseline["batch_pairs"] == schedule["batch_pairs"], "baseline schedule differs")
            require([{field: value[field] for field in FIELDS} for value in generated]
                    == [{field: value[field] for field in FIELDS} for value in baseline["workloads"]],
                    "canonical input bytes, repetitions, or expected output differ")
            paths["baseline:" + phase + "-" + mode] = baseline_path
            expected_hashes["baseline:" + phase + "-" + mode] = BASELINE_SHA[phase + "-" + mode]
        commands = {}
        for mode in MODES:
            label = phase + "-" + mode
            commands[mode] = common[mode] + ["--prepared-record", preparations[mode]["path"],
                "--artifact-dir", str(output / label), "--output", str(output / (label + ".json")),
                "--cpu", "0", "--samples", str(SAMPLES), "--warmups", str(WARMUPS),
                "--batch-pairs", str(schedule["batch_pairs"]), "--sizes", *map(str, SIZES),
                "--scenarios", *schedule["scenarios"]]
        groups = len(generated) + 1  # One empty-input control per mode.
        phases[phase] = {**schedule, "sizes": SIZES, "samples": SAMPLES, "warmups": WARMUPS,
                         "mode_order": list(MODES), "commands": commands, "commands_sha256": json_sha(commands),
                         "expected_workloads": generated, "workloads_per_mode": len(generated),
                         "executions": {"gates": groups * 3 * 2, "warmups": groups * 3 * WARMUPS * 2,
                                        "measured": groups * 3 * SAMPLES * 2, "total": groups * 3 * (1 + WARMUPS + SAMPLES) * 2}}
    clean(root, candidate["revision"])
    require(hashes(paths) == expected_hashes, "final planning input changed during preparation of the plan")
    plan = {"schema": 1, "kind": "telemetry-final-measurement-plan", "status": "planned", "created_at": now(),
            "root": str(root), "revision": candidate["revision"], "output": str(output),
            "candidate_plan": str(candidate_path), "candidate_plan_sha256": sha(candidate_path),
            "validation_mode": "full-validation", "validation_full_matrix_passed": True,
            "preparations": preparations, "phases": phases,
            "protected_paths": {name: str(path) for name, path in paths.items()}, "protected_sha256": expected_hashes,
            "executions": {key: sum(value["executions"][key] for value in phases.values())
                           for key in ("gates", "warmups", "measured", "total")},
            "timing_policy": "Run only after root stops builds, profiles, other timing, and heavy hashing. CPU 0, outside ptrace. Original complete-process harness, no empty-control subtraction.",
            "target": "Each of the four full-scan 4096-record ThinLTO Imre/Rust median ratios must be below 2; review individual distributions and early/ordinary regressions.",
            "input_guards_passed": True}
    require(plan["executions"] == {"gates": 138, "warmups": 1104, "measured": 1656, "total": 2898}, "unexpected schedule size")
    output.mkdir(parents=True)
    save(output / "plan.json", plan)
    print(json.dumps({"plan": str(output / "plan.json"), "sha256": sha(output / "plan.json"),
                      "executions": plan["executions"], "phases": list(phases)}, indent=2))


def verify_record(result, plan, phase, mode):
    schedule = plan["phases"][phase]
    prepared_path = Path(plan["preparations"][mode]["path"])
    prepared = load(prepared_path)
    require(result["kind"] == "telemetry-benchmark" and result["input_guards_passed"] and result["completed_at_utc"]
            and result["revision"] == plan["revision"] and not result["dirty"] and result["thinlto"] == (mode == "thinlto"),
            "measurement result is incomplete or has a different revision/mode")
    require(result["samples"] == SAMPLES and result["warmups"] == WARMUPS
            and result["batch_pairs"] == schedule["batch_pairs"] and result["cpu"]["affinity"] == [0], "measurement schedule or CPU differs")
    require(result["preparation"] == prepared and result["preparation_record_sha256"] == sha(prepared_path)
            and result["binary_sha256"] == prepared["binary_sha256"]
            and result["source_and_tool_sha256"] == prepared["source_and_tool_sha256"], "measurement preparation/binary/source binding differs")
    require([{field: value[field] for field in (*FIELDS, "records")} for value in result["workloads"]]
            == [{field: value[field] for field in (*FIELDS, "records")} for value in schedule["expected_workloads"]],
            "measured canonical workloads differ")
    orders = [list(order) for order in itertools.permutations(("imre", "cpython", "rust"))]
    require(result["engine_orders"] == orders, "engine-order schedule differs")
    control = result["startup_control"]
    require(control["label"] == "empty-control" and control["records"] == 0
            and control["repetitions"] == 1 and control["inspected_pairs_per_call"] == 0, "control metadata differs")
    for value in [control, *result["workloads"]]:
        require(set(value["gates"]) == {"imre", "cpython", "rust"}, "correctness gate engines differ")
        for name, count in (("warmups", WARMUPS), ("samples", SAMPLES)):
            require(len(value[name]) == count, "round count differs")
            require(all(item["index"] == position and item["order"] == orders[position % 6]
                        and {"imre", "cpython", "rust"} <= set(item)
                        for position, item in enumerate(value[name])), "round order or engines differ")


def measure(args):
    plan_path = args.plan.resolve(strict=True)
    plan = load(plan_path)
    require(plan["kind"] == "telemetry-final-measurement-plan" and plan["status"] == "planned"
            and plan["input_guards_passed"] and plan["validation_full_matrix_passed"] is True, "final plan is incomplete")
    phase = args.phase
    schedule = plan["phases"][phase]
    require(schedule["mode_order"] == list(MODES) and schedule["samples"] == SAMPLES and schedule["warmups"] == WARMUPS
            and schedule["sizes"] == SIZES and schedule["batch_pairs"] == PHASES[phase]["batch_pairs"]
            and schedule["scenarios"] == PHASES[phase]["scenarios"], "final phase schedule differs")
    require(schedule["commands_sha256"] == json_sha(schedule["commands"]), "planned phase command hash differs")
    guard(plan)
    output = Path(plan["output"])
    status_path = output / (phase + "-timing-status.json")
    require(not status_path.exists(), "preserve previous timing evidence; use a fresh final plan")
    helper = Path(plan["protected_paths"]["candidate:helper"])
    candidate_delegate = runpy.run_path(str(helper), run_name="telemetry_final_environment_delegate")
    record = {"schema": 1, "kind": "telemetry-final-measurement-status", "phase": phase, "status": "running",
              "exploratory": False, "started_at": now(), "revision": plan["revision"],
              "plan": str(plan_path), "plan_sha256": sha(plan_path),
              "candidate_plan": plan["candidate_plan"], "candidate_plan_sha256": plan["candidate_plan_sha256"],
              "validation_mode": "full-validation", "validation_full_matrix_passed": True,
              "planned_commands": schedule["commands"], "planned_commands_sha256": schedule["commands_sha256"],
              "executions": schedule["executions"], "runs": []}
    save(status_path, record)
    try:
        for mode in schedule["mode_order"]:
            guard(plan)
            record["timing_environment"] = candidate_delegate["timing_environment"]()
            command = schedule["commands"][mode]
            result_path = Path(option(command, "--output"))
            artifacts = Path(option(command, "--artifact-dir"))
            require(not result_path.exists() and not artifacts.exists(), "use fresh measurement output paths")
            stdout, stderr = output / (phase + "-" + mode + ".stdout"), output / (phase + "-" + mode + ".stderr")
            run = {"mode": mode, "phase": phase, "command": command, "command_sha256": json_sha(command),
                   "started_at": now(), "stdout": str(stdout), "stderr": str(stderr)}
            record["runs"].append(run)
            save(status_path, record)
            with stdout.open("xb") as out, stderr.open("xb") as err:
                process = subprocess.run(command, cwd=plan["root"], stdout=out, stderr=err, check=False)
            run.update(exit_code=process.returncode, completed_at=now(), stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
            require(process.returncode == 0, "measurement failed; see retained stdout/stderr")
            require(run["command"] == plan["phases"][phase]["commands"][mode], "executed command differs from exact phase plan")
            result = load(result_path)
            verify_record(result, plan, phase, mode)
            run.update(output=str(result_path), output_sha256=sha(result_path), status="passed",
                       imre_over_rust={value["label"]: value["imre_over_rust"] for value in result["workloads"]})
            if phase == "full" and mode == "thinlto":
                ratios = {value["label"]: value["imre_over_rust"] for value in result["workloads"] if value["records"] == 4096}
                require(len(ratios) == 4, "missing full-scan target workloads")
                record["target_ratios"] = ratios
                record["all_four_below_two"] = all(value < 2 for value in ratios.values())
            del result
            guard(plan)
            require(sha(plan_path) == record["plan_sha256"], "final phase plan changed")
            save(status_path, record)
        record.update(status="passed", input_guards_passed=True, source_unchanged=True)
    except BaseException as error:
        record.update(status="failed", error=repr(error))
        raise
    finally:
        record["completed_at"] = now()
        save(status_path, record)
    print(json.dumps({"phase": phase, "status": record["status"], "record": str(status_path),
                      "sha256": sha(status_path), "target_ratios": record.get("target_ratios"),
                      "all_four_below_two": record.get("all_four_below_two")}, indent=2))


def main():
    require(sys.flags.optimize == 0, "Run evidence and imported oracle guards without Python -O")
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    plan = commands.add_parser("plan")
    plan.add_argument("--candidate-plan", type=Path, required=True)
    plan.add_argument("--output", type=Path, required=True)
    timing = commands.add_parser("measure")
    timing.add_argument("--plan", type=Path, required=True)
    timing.add_argument("--phase", choices=tuple(PHASES), required=True)
    args = parser.parse_args()
    make_plan(args) if args.command == "plan" else measure(args)


if __name__ == "__main__":
    main()
