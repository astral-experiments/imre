"""Audit final telemetry timings and profiles from retained bytes; never run engines.

Use only after all measurements and profiles stop. A passed audit establishes
record validity separately from the four-case <2x Rust performance goal.
"""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path
import re
import runpy
import shlex
import statistics
import subprocess
import sys

PARSERS = Path('/tmp/relar-telemetry-candidate-audit.py')
PARSERS_SHA256 = 'e9481b4d29553e59ff179cb377bcee84f860f764060115ca797c5b2681992b9c'
FINAL_HELPER_SHA256 = 'b8a824bbf58bfb5b97250b0d6110f77973cc7cbf887b086dd310303787dc2862'
FINAL_PROFILER_SHA256 = '0ac7a494c318de634bb18495c39d19b89f0be31af0c9baa40f1e3635dc988ccf'
MODES = ('normal', 'thinlto')
ENGINES = ('relar', 'cpython', 'rust')
ORDERS = [list(order) for order in itertools.permutations(ENGINES)]
FIELDS = ('label', 'scenario', 'inspected_pairs_per_call', 'repetitions', 'case', 'expected_stdout', 'expected_files')
PHASES = {
    'full': (8388608, ['report-mixed', 'alert-quiet', 'within-quiet', 'latest-quiet']),
    'early': (2097152, ['alert-early', 'within-early', 'latest-recent']),
}
BASELINES = {
    'full-normal': '890834d3dedc0bbd39e1788b083ff32214f72372cb1caf93599b9f3bfcaf15a7',
    'full-thinlto': 'bbe69e51b7b9315bfc3e755020999443671c7f3987a3298e033610b301c87401',
    'early-normal': '030357302cfc760a119f4c62f7ffe29120b899a5073917a7a93699a51fff1cf5',
    'early-thinlto': 'b2f630c600e24a3acd7d1e94d36e4f41d98cdb82d86517730bfd9449567738f2',
}
BOOTSTRAP = "import runpy, sys; sys.path.insert(0, sys.argv[1]); sys.argv = ['telemetry_comparison', *sys.argv[2:]]; runpy.run_module('telemetry_comparison', run_name='__main__', alter_sys=True)"
GUARDS, TREES = {}, {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def json_sha(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def option(command, name):
    require(command.count(name) == 1, 'expected exactly one ' + name)
    return command[command.index(name) + 1]


def interval(start, end):
    begin, finish = datetime.fromisoformat(start), datetime.fromisoformat(end)
    require(begin.tzinfo is not None and finish.tzinfo is not None and begin <= finish, 'invalid recorded time interval')
    return begin, finish


def safe_relative(name):
    path = Path(name)
    require(not path.is_absolute() and '..' not in path.parts and path.parts, 'unsafe relative path')
    return path


def guard(path, expected=None):
    path = Path(path).resolve(strict=True)
    actual = digest(path)
    require(expected is None or actual == expected, 'artifact changed: ' + str(path))
    prior = GUARDS.setdefault(str(path), actual)
    require(prior == actual, 'artifact changed during audit: ' + str(path))
    return actual


def load(path, expected=None):
    path = Path(path).resolve(strict=True)
    value = guard(path, expected)
    raw = path.read_bytes()
    require(sha(raw) == value, 'JSON changed while reading')
    return json.loads(raw)


def tree(path):
    path = Path(path).resolve(strict=True)
    require(path.is_dir() and not path.is_symlink(), 'expected regular evidence directory')
    entries = {}
    for member in sorted(path.rglob('*')):
        require(not member.is_symlink() and (member.is_file() or member.is_dir()), 'special evidence entry')
        entries[member.relative_to(path).as_posix()] = member.is_dir()
    require(TREES.setdefault(str(path), entries) == entries, 'evidence membership changed')
    return entries


def source_guard(path, expected, repository, revision):
    parsers['guarded_identity'](path, expected, repository, revision)
    if not Path(path).resolve(strict=True).is_relative_to(repository):
        guard(path, expected)


def audit_inputs(plan_path, validation_audit_path, validation_script):
    plan = load(plan_path)
    require(plan['schema'] == 1 and plan['kind'] == 'telemetry-final-measurement-plan'
            and plan['status'] == 'planned' and plan['input_guards_passed']
            and plan['validation_mode'] == 'full-validation' and plan['validation_full_matrix_passed'] is True,
            'final plan is incomplete or not fully validated')
    repository, revision = Path(plan['root']).resolve(strict=True), plan['revision']
    require(set(plan['protected_paths']) == set(plan['protected_sha256']), 'final plan guard keys differ')
    for name, path in plan['protected_paths'].items():
        source_guard(path, plan['protected_sha256'][name], repository, revision)
    require(plan['protected_sha256']['final_helper'] == FINAL_HELPER_SHA256, 'final measurement helper changed')
    candidate_path = Path(plan['candidate_plan']).resolve(strict=True)
    require(candidate_path == Path(plan['protected_paths']['candidate_plan']).resolve(strict=True), 'candidate plan path differs')
    candidate = load(candidate_path, plan['candidate_plan_sha256'])
    require(candidate['status'] == 'planned' and candidate['input_guards_passed']
            and candidate['revision'] == revision and Path(candidate['root']).resolve(strict=True) == repository
            and candidate['validation_mode'] == 'full-validation' and candidate['validation_full_matrix_passed'] is True,
            'candidate plan is not the final fully validated revision')
    require(set(candidate['protected_paths']) == set(candidate['protected_sha256']), 'candidate guard keys differ')
    for name, path in candidate['protected_paths'].items():
        require(Path(plan['protected_paths']['candidate:' + name]).resolve(strict=True) == Path(path).resolve(strict=True)
                and plan['protected_sha256']['candidate:' + name] == candidate['protected_sha256'][name],
                'candidate/final guard binding differs')
    index_path = Path(candidate['protected_paths']['validation_index']).resolve(strict=True)
    index = load(index_path, candidate['protected_sha256']['validation_index'])
    build_path = Path(candidate['protected_paths']['build_record']).resolve(strict=True)
    build = load(build_path, candidate['protected_sha256']['build_record'])
    require(index['status'] == 'passed' and index['input_guards_passed'] and index['source_unchanged']
            and index['mode'] == 'full-validation' and index['full_validation_passed'] is True
            and index['revision'] == build['revision'] == revision
            and index['build_record']['sha256'] == guard(build_path)
            and build['input_guards_passed'] and build['source_matches_revision'], 'full validation/build binding differs')
    audit = load(validation_audit_path)
    require(audit['status'] == 'passed' and audit['validation_revision'] == revision
            and Path(audit['validation_index']).resolve(strict=True) == index_path
            and audit['validation_index_sha256'] == guard(index_path), 'independent full validation audit differs')
    guard(validation_script, audit['audit_script_sha256'])
    require(index['job_counts'] == {'passed': len(index['jobs']), 'failed': 0}
            and audit['counts']['recorded_jobs'] == audit['counts']['passed_jobs'] == len(index['jobs'])
            and audit['counts']['failed_jobs'] == 0
            and audit['counts']['rust_units']['total'] == index['unit_tests_passed'], 'full validation counts differ')
    for job in index['jobs']:
        require(job['status'] == 'passed' and job['exit_code'] == 0, 'validation job failed')
        for key in ('record', 'stdout', 'stderr'):
            guard(job[key], job[key + '_sha256'])
    validation = index_path.parent
    evidence = load(validation / 'evidence-sha256.json', index['evidence_manifest_sha256'])
    for name, expected in evidence.items():
        guard(validation / safe_relative(name), expected)
    require(len(evidence) == audit['guard_checks']['evidence_manifest_entries'], 'validation evidence count differs')
    source = load(validation / 'source-before.json')
    require(source == load(validation / 'source-after.json') and source['revision'] == revision
            and source['status'] == '', 'full validation sources changed')
    recorded_tree = subprocess.check_output(['git', '-C', str(repository), 'rev-parse', revision + '^{tree}'], text=True).strip()
    require(source['tree'] == recorded_tree, 'full validation Git tree differs')
    for name, expected in build['source_sha256'].items():
        require(source['files'][name]['sha256'] == expected, 'compiler/runtime source snapshot differs')
    preparation_status_path = Path(candidate['output']) / 'prepare-status.json'
    require(preparation_status_path.resolve(strict=True) == Path(plan['protected_paths']['preparation_status']).resolve(strict=True), 'preparation status path differs')
    preparation_status = load(preparation_status_path, plan['protected_sha256']['preparation_status'])
    require(preparation_status['phase'] == 'prepare' and preparation_status['status'] == 'passed'
            and preparation_status['input_guards_passed'] and preparation_status['validation_full_matrix_passed'] is True
            and preparation_status['revision'] == revision
            and Path(preparation_status['plan']).resolve(strict=True) == candidate_path
            and preparation_status['plan_sha256'] == guard(candidate_path)
            and [run['mode'] for run in preparation_status['runs']] == list(MODES), 'preparation status differs')
    prepared = {}
    for run in preparation_status['runs']:
        mode = run['mode']
        command = candidate['commands']['prepare'][mode]
        path = Path(plan['preparations'][mode]['path']).resolve(strict=True)
        require(run['status'] == 'passed' and run['exit_code'] == 0 and run['command'] == command
                and Path(run['output']).resolve(strict=True) == path == Path(option(command, '--output')).resolve(strict=True)
                and run['output_sha256'] == plan['preparations'][mode]['sha256'], 'exact preparation command/output differs')
        for stream in ('stdout', 'stderr'):
            guard(run[stream], run[stream + '_sha256'])
        value = load(path, run['output_sha256'])
        require(value['kind'] == 'telemetry-preparation' and value['input_guards_passed'] and not value['dirty']
                and value['revision'] == revision and value['thinlto'] == (mode == 'thinlto')
                and value['relar_build_record'] == build, 'prepared implementation identity differs')
        hashes, paths = value['source_and_tool_sha256'], value['source_and_tool_paths']
        require(set(hashes) == set(paths), 'preparation guard keys differ')
        for name, source_path in paths.items():
            source_guard(source_path, hashes[name], repository, revision)
        require(hashes['relar_build_record'] == guard(build_path)
                and hashes['compiler'] == build['sha256']['compiler']
                and hashes['runtime'] == build['sha256'][mode + '_runtime'], 'selected compiler/runtime build differs')
        for key in ('binary', 'llvm', 'validation'):
            guard(value['validation_path' if key == 'validation' else key], value[key + '_sha256'])
        oracle = load(value['validation_path'], value['validation_sha256'])
        require(oracle == value['validation'] and oracle['input_guards_passed'] and oracle['cases'] == 258
                and oracle['source_and_binary_sha256']['relar'] == value['binary_sha256']
                and oracle['source_and_binary_sha256']['rust'] == hashes['rust'], 'prepared complete oracle/binaries differ')
        rust = load(paths['rust_build_record'], hashes['rust_build_record'])
        require(rust == value['rust_build_record'] and rust['input_guards_passed']
                and rust['thinlto'] == (mode == 'thinlto') and rust['binary_sha256'] == hashes['rust']
                and rust['native_artifact']['fresh'] is False, 'frozen Rust reference identity differs')
        environment = rust['environment']
        require(environment['CARGO_PROFILE_RELEASE_OPT_LEVEL'] == '3'
                and environment['CARGO_PROFILE_RELEASE_CODEGEN_UNITS'] == '16'
                and environment['CARGO_PROFILE_RELEASE_LTO'] == ('thin' if mode == 'thinlto' else 'off'), 'Rust optimization mode differs')
        if mode == 'thinlto':
            require(rust['llvm_budget'] == 1000 and environment['RUSTFLAGS'] == '-Cllvm-args=-import-instr-limit=1000 -Cllvm-args=-inline-threshold=1000', 'Rust ThinLTO budget differs')
        host, = [line.split(': ', 1)[1] for line in rust['rustc_verbose'].splitlines() if line.startswith('host: ')]
        require(value['effective_target'] == value['requested_target'] == host == build['target']
                == 'x86_64-unknown-linux-gnu', 'native target differs from the frozen comparison host')
        compile_command = [paths['compiler'], 'build', paths['example:__main__.py'],
                           '--module-root', str(repository / 'examples'), '-o', value['binary'],
                           '--runtime', paths['runtime'], '--clang', paths['clang'], '--opt-level', '3',
                           '--emit-llvm', value['llvm'], '--target', host]
        if mode == 'thinlto':
            compile_command += ['--lto-linker', paths['lto_linker']]
        require(value['compile_command'] == compile_command, 'exact native preparation command differs')
        require(value['validation_command'] == [paths['python'], '-I', '-B', paths['validator'],
                '--binary', value['binary'], '--rust', paths['rust'], '--output', value['validation_path']],
                'exact preparation oracle command differs')
        for binary in (value['binary'], paths['rust']):
            with Path(binary).open('rb') as stream:
                header = stream.read(20)
            require(len(header) == 20 and header[:4] == b'\x7fELF' and header[4:6] == b'\x02\x01',
                    'native artifact is not little-endian ELF64')
            target = {'bits': 64, 'byte_order': 'little', 'machine': int.from_bytes(header[18:20], 'little')}
            require(target == value['native_elf'] == {'bits': 64, 'byte_order': 'little', 'machine': 62},
                    'native binary target differs from the Rust/Relar host')
        for name, expected in rust['sources'].items():
            require(hashes['rust_source:' + name] == expected and sha(rust['source_contents'][name].encode()) == expected, 'Rust source snapshot differs')
        prepared[mode] = value
    return {'plan_path': str(Path(plan_path).resolve(strict=True)), 'plan': plan, 'candidate_path': str(candidate_path),
            'candidate': candidate, 'repository': repository, 'revision': revision, 'index_path': str(index_path),
            'index': index, 'build_path': str(build_path), 'build': build, 'validation_audit_path': str(Path(validation_audit_path).resolve(strict=True)),
            'validation_script': str(Path(validation_script).resolve(strict=True)), 'validation_audit': audit,
            'preparation_status_path': str(preparation_status_path), 'preparation_status': preparation_status, 'prepared': prepared}


def audit_record(record, run, status, context, phase, mode):
    plan, prepared = context['plan'], context['prepared'][mode]
    schedule = plan['phases'][phase]
    batch, scenarios = PHASES[phase]
    require(record['kind'] == 'telemetry-benchmark' and record['input_guards_passed'] and record['completed_at_utc']
            and not record['dirty'] and record['revision'] == context['revision']
            and record['thinlto'] == (mode == 'thinlto') and record['samples'] == 12 and record['warmups'] == 8
            and record['batch_pairs'] == batch and record['engine_orders'] == ORDERS and record['cpu']['affinity'] == [0], 'final timing identity or schedule differs')
    require(record['preparation'] == prepared and record['preparation_record_sha256'] == plan['preparations'][mode]['sha256']
            and record['binary_sha256'] == prepared['binary_sha256']
            and record['source_and_tool_sha256'] == prepared['source_and_tool_sha256'], 'final timing preparation binding differs')
    label = phase + '-' + mode
    baseline = load(plan['protected_paths']['baseline:' + label], BASELINES[label])
    require({field: record['startup_control'][field] for field in FIELDS}
            == {field: baseline['startup_control'][field] for field in FIELDS}, 'canonical empty control differs')
    for key in ['python', 'clang', 'rust_source:src/main.rs', *(['lto_linker'] if mode == 'thinlto' else []),
                *(name for name in baseline['source_and_tool_sha256'] if name.startswith('example:') and name.endswith('.py'))]:
        require(prepared['source_and_tool_sha256'][key] == baseline['source_and_tool_sha256'][key], 'unchanged program/tool differs: ' + key)
    require([{field: row[field] for field in FIELDS} for row in record['workloads']]
            == [{field: row[field] for field in FIELDS} for row in schedule['expected_workloads']]
            == [{field: row[field] for field in FIELDS} for row in baseline['workloads']], 'canonical workload bytes/repetitions differ')
    require([row['label'] for row in record['workloads']] == [scenario + '-' + str(size) for size in (16, 256, 4096) for scenario in scenarios], 'workload matrix differs')
    artifact_dir = Path(option(run['command'], '--artifact-dir')).resolve(strict=True)
    tree(artifact_dir)
    commands = {'relar': [prepared['binary']], 'rust': [prepared['source_and_tool_paths']['rust']],
                'cpython': [prepared['source_and_tool_paths']['python'], '-I', '-B', '-c', BOOTSTRAP, str(context['repository'] / 'examples')]}
    results, counts, max_control = {}, Counter(), {engine: 0.0 for engine in ENGINES}
    expected_inventory = {}
    for row in [record['startup_control'], *record['workloads']]:
        label = row['label']
        stdout, files = independent_oracle(row['case'])
        require(stdout == row['expected_stdout'] and {name: decoded_file(value) for name, value in row['expected_files'].items()} == files, 'independent full oracle differs')
        args = row['case']['arguments']
        left = [tuple(map(int, line.split())) for line in files[args[1]].decode('ascii').splitlines()[1:]]
        right = [tuple(map(int, line.split())) for line in files[args[2]].decode('ascii').splitlines()[1:]]
        size = len(left)
        breaches = [i for i, (a, b) in enumerate(zip(left, right, strict=True)) if abs(a[1] - b[1]) > int(args[4])]
        first, last = (breaches[0] + 1 if breaches else size), (size - breaches[-1] if breaches else size)
        visits = 0 if label == 'empty-control' else 3 * size + 2 * first + last if args[0] == 'report' else last if args[0] == 'latest' else first
        require(row['records'] == size and row['repetitions'] == int(args[-1])
                and row['inspected_pairs_per_call'] == visits, 'input size or inspected work differs')
        if label == 'empty-control':
            require(row['scenario'] == 'empty-control' and size == 0 and row['repetitions'] == 1, 'startup control differs')
        else:
            require(label == row['scenario'] + '-' + str(size) and row['repetitions'] == max(1, batch // visits), 'batch normalization differs')
        file_records = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in files.items()}
        expected_inventory[label] = True
        for engine in ENGINES:
            expected_inventory[label + '/' + engine] = True
            expected_inventory.update({label + '/' + engine + '/' + name: False for name in files})
        require(set(row['gates']) == set(ENGINES), 'gate engines differ')
        for name, count in (('warmups', 8), ('samples', 12)):
            require(len(row[name]) == count, 'round count differs')
            require(all(sample['index'] == index and sample['order'] == ORDERS[index % 6] for index, sample in enumerate(row[name])), 'engine order differs')
        balance = Counter(tuple(sample['order']) for sample in row['samples'])
        require(balance == Counter({tuple(order): 2 for order in ORDERS}), 'measured order balance differs')
        for name, groups in (('gates', [row['gates']]), ('warmups', row['warmups']), ('measured', row['samples'])):
            for group in groups:
                for engine in ENGINES:
                    item = group[engine]
                    require(item['returncode'] == 0 and item['stderr'] == '' and item['stdout'] == stdout
                            and item['files'] == file_records and item['directories'] == [], 'complete process output/filesystem differs')
                    require(item['command'] == commands[engine] + args and type(item['elapsed_ns']) is int and item['elapsed_ns'] > 0, 'engine command or duration differs')
                    counts[name] += 1
        summaries = {}
        for engine in ENGINES:
            durations = [sample[engine]['elapsed_ns'] / 1e9 for sample in row['samples']]
            quartiles = statistics.quantiles(durations, n=4, method='inclusive')
            summaries[engine] = {'median_seconds': statistics.median(durations), 'min_seconds': min(durations), 'max_seconds': max(durations), 'p25_seconds': quartiles[0], 'p75_seconds': quartiles[2]}
            require(summaries[engine] == row['summary'][engine], 'raw timing summaries differ')
            directory = artifact_dir / label / engine
            inventory = tree(directory)
            require(not any(inventory.values()), 'unexpected timing output directory')
            require({name: (directory / name).read_bytes() for name in inventory} == files, 'retained complete filesystem differs')
            for name, data in files.items():
                guard(directory / name, sha(data))
        ratios = {a + '_over_' + b: summaries[a]['median_seconds'] / summaries[b]['median_seconds']
                  for a, b in (('cpython', 'relar'), ('relar', 'rust'), ('cpython', 'rust'))}
        require(all(row[name] == value for name, value in ratios.items()), 'ratio of medians differs')
        if label != 'empty-control':
            fractions = {engine: record['startup_control']['summary'][engine]['median_seconds'] / summaries[engine]['median_seconds'] for engine in ENGINES}
            require(row['startup_control_fraction'] == fractions and run['relar_over_rust'][label] == ratios['relar_over_rust'], 'control fraction or status ratio differs')
            max_control = {engine: max(max_control[engine], fractions[engine]) for engine in ENGINES}
        results[label] = {'records': size, 'repetitions': row['repetitions'], 'summary': summaries, **ratios}
    require(tree(artifact_dir) == expected_inventory, 'outer timing artifact inventory differs')
    counts['total'] = sum(counts.values())
    return {'record': run['output'], 'record_sha256': guard(run['output']), 'artifact_directory': str(artifact_dir),
            'phase': phase, 'mode': mode, 'executions': dict(counts), 'ratios_and_medians': results,
            'max_control_fractions': max_control, 'balanced_measured_orders': True, 'complete_outputs_verified': True}


def audit_timings(context):
    plan = context['plan']
    statuses, records, totals = {}, {}, Counter()
    for phase, (batch, scenarios) in PHASES.items():
        schedule = plan['phases'][phase]
        require(schedule['mode_order'] == list(MODES) and schedule['sizes'] == [16, 256, 4096]
                and schedule['samples'] == 12 and schedule['warmups'] == 8 and schedule['batch_pairs'] == batch
                and schedule['scenarios'] == scenarios and schedule['commands_sha256'] == json_sha(schedule['commands']), 'final phase schedule differs')
        status_path = Path(plan['output']) / (phase + '-timing-status.json')
        status = load(status_path)
        require(status['schema'] == 1 and status['kind'] == 'telemetry-final-measurement-status'
                and status['phase'] == phase and status['status'] == 'passed' and status['exploratory'] is False
                and status['input_guards_passed'] and status['source_unchanged'] and status['completed_at']
                and status['revision'] == context['revision'] and status['validation_mode'] == 'full-validation'
                and status['validation_full_matrix_passed'] is True, 'final timing phase incomplete')
        require(Path(status['plan']).resolve(strict=True) == Path(context['plan_path'])
                and status['plan_sha256'] == guard(context['plan_path'])
                and Path(status['candidate_plan']).resolve(strict=True) == Path(context['candidate_path'])
                and status['candidate_plan_sha256'] == guard(context['candidate_path'])
                and status['planned_commands'] == schedule['commands']
                and status['planned_commands_sha256'] == schedule['commands_sha256']
                and [run['mode'] for run in status['runs']] == list(MODES), 'final phase/plan binding differs')
        environment = status['timing_environment']
        require(environment['cpu'] == 0 and environment['tracer_pid'] == 0 and not environment['known_heavy_processes'], 'timing isolation guard failed')
        phase_interval = interval(status['started_at'], status['completed_at'])
        previous_finish = phase_interval[0]
        phase_counts = Counter()
        for run in status['runs']:
            mode = run['mode']
            command = schedule['commands'][mode]
            require(run['phase'] == phase and run['status'] == 'passed' and run['exit_code'] == 0
                    and run['command'] == command and run['command_sha256'] == json_sha(command)
                    and Path(run['output']).resolve(strict=True) == Path(option(command, '--output')).resolve(strict=True)
                    and Path(option(command, '--prepared-record')).resolve(strict=True) == Path(plan['preparations'][mode]['path']).resolve(strict=True), 'exact completed phase/mode command differs')
            for stream in ('stdout', 'stderr'):
                guard(run[stream], run[stream + '_sha256'])
            require(Path(run['stderr']).read_bytes() == b'', 'timing harness stderr is nonempty')
            run_interval = interval(run['started_at'], run['completed_at'])
            require(previous_finish <= run_interval[0] <= run_interval[1] <= phase_interval[1], 'mode runs overlap or escape their final phase')
            previous_finish = run_interval[1]
            record = load(run['output'], run['output_sha256'])
            record_interval = interval(record['started_at_utc'], record['completed_at_utc'])
            require(run_interval[0] <= record_interval[0] <= record_interval[1] <= run_interval[1], 'benchmark timing escapes its recorded run')
            result = audit_record(record, run, status, context, phase, mode)
            records[phase + '-' + mode] = result
            phase_counts.update(result['executions'])
        require(dict(phase_counts) == status['executions'] == schedule['executions'], 'phase process counts differ')
        totals.update(phase_counts)
        statuses[phase] = {'path': str(status_path), 'sha256': guard(status_path), 'started_at': status['started_at'], 'completed_at': status['completed_at'],
                           'commands_sha256': schedule['commands_sha256'], 'executions': dict(phase_counts)}
    phase_intervals = sorted(interval(value['started_at'], value['completed_at']) for value in statuses.values())
    require(all(left[1] <= right[0] for left, right in zip(phase_intervals, phase_intervals[1:])), 'final wall-time phases overlap')
    require(dict(totals) == plan['executions'] == {'gates': 138, 'warmups': 1104, 'measured': 1656, 'total': 2898}, 'total process counts differ')
    values = records['full-thinlto']['ratios_and_medians']
    target = {name: row['relar_over_rust'] for name, row in values.items() if row['records'] == 4096}
    require(len(target) == 4, 'four target cases missing')
    full_status = load(statuses['full']['path'], statuses['full']['sha256'])
    met = all(value < 2 for value in target.values())
    require(full_status['target_ratios'] == target and full_status['all_four_below_two'] == met, 'performance target arithmetic differs')
    return statuses, records, {'all_four_below_two': met, 'individual_relar_over_rust': target, 'threshold': 2, 'comparison': 'strictly below'}



def audit_profiles(context, statuses, records, directory):
    root = Path(directory).resolve(strict=True)
    inventory = tree(root)
    summary = load(root / 'summary.json')
    summary_hash = guard(root / 'summary.json')
    manifest = load(root / 'manifest.json')
    require(set(manifest) == {name for name, is_dir in inventory.items() if not is_dir and name != 'manifest.json'}, 'profile artifact inventory differs')
    for name, expected in manifest.items():
        guard(root / safe_relative(name), expected)
    require(summary['status'] == 'passed' and summary['complete'] and summary['input_guards_passed']
            and summary['thinlto'] and summary['label'] == 'alert-quiet-4096'
            and summary['exploratory'] is False and summary['profile_context'] == 'final-comparison'
            and summary['timing_phase'] == 'full' and summary['full_validation_passed'] is True
            and summary['validation_mode'] == 'full-validation', 'final profile is incomplete or exploratory')
    require(all(summary[key] == context['revision'] for key in ('timing_revision', 'build_revision', 'validation_revision')), 'profile source revision differs')
    require(summary['validation_scope'] == context['index']['scope'] == context['candidate']['validation_scope'], 'profile validation scope differs')
    require(datetime.fromisoformat(summary['started_at_utc']) > max(datetime.fromisoformat(status['completed_at']) for status in statuses.values()), 'profiling overlaps final wall timing')
    for name, expected in summary['snapshot_sha256'].items():
        guard(root / safe_relative(name), expected)
    expected_snapshots = {
        'final-plan.json': guard(context['plan_path']), 'candidate-plan.json': guard(context['candidate_path']),
        'timing-status.json': statuses['full']['sha256'],
        'benchmark-record.json': records['full-thinlto']['record_sha256'],
        'normal-benchmark-record.json': records['full-normal']['record_sha256'],
        'preparation.json': context['plan']['preparations']['thinlto']['sha256'],
        'normal-preparation.json': context['plan']['preparations']['normal']['sha256'],
        'preparation-status.json': guard(context['preparation_status_path']),
        'validation-index.json': guard(context['index_path']), 'relar-build-record.json': guard(context['build_path']),
        'profiler.py': FINAL_PROFILER_SHA256, 'final-evidence-helper.py': FINAL_HELPER_SHA256,
        'metric-parsers.py': '61f2e8a59d092473ef1e8557fc40ce0033d9aeb59a5e8eff2cbe00f3ba53fa05',
    }
    for name, expected in expected_snapshots.items():
        require(summary['snapshot_sha256'][name] == expected, 'profile snapshot binding differs: ' + name)
        guard(root / name, expected)
    require(summary['final_plan_sha256'] == guard(context['plan_path'])
            and summary['candidate_plan_sha256'] == guard(context['candidate_path'])
            and summary['final_phase_commands_sha256'] == context['plan']['phases']['full']['commands_sha256']
            and summary['benchmark_record_sha256'] == records['full-thinlto']['record_sha256']
            and summary['normal_benchmark_record_sha256'] == records['full-normal']['record_sha256']
            and summary['timing_status_sha256'] == statuses['full']['sha256'], 'profile final timing/plan identities differ')
    for name, value in summary['guarded_inputs'].items():
        source_guard(value['path'], value['sha256'], context['repository'], context['revision'])
    prepared = context['prepared']['thinlto']
    benchmark = load(records['full-thinlto']['record'], records['full-thinlto']['record_sha256'])
    require(load(root / 'preparation.json') == prepared
            and load(root / 'benchmark-record.json') == benchmark
            and load(root / 'rust-build-record.json') == prepared['rust_build_record']
            and load(root / 'prepared-validation.json') == prepared['validation'], 'profile copied preparation/build/oracle differs')
    guard(root / 'native.ll', prepared['llvm_sha256'])
    guard(root / 'rust-build-record.json', prepared['source_and_tool_sha256']['rust_build_record'])
    guard(root / 'prepared-validation.json', prepared['validation_sha256'])
    for name, expected in prepared['source_and_tool_sha256'].items():
        value = summary['guarded_inputs'][name]
        require(value['sha256'] == expected and Path(value['path']).resolve(strict=True) == Path(prepared['source_and_tool_paths'][name]).resolve(strict=True), 'profile source/tool guard differs')
    for name in ('validator', 'filesystem_validator', 'batch_validator', 'incremental_validator', 'shared_validator'):
        guard(root / ('oracle-' + Path(prepared['source_and_tool_paths'][name]).name), prepared['source_and_tool_sha256'][name])
    binary_hashes = {'relar': prepared['binary_sha256'], 'rust': prepared['source_and_tool_sha256']['rust']}
    binaries = {'relar': Path(prepared['binary']).resolve(strict=True), 'rust': Path(prepared['source_and_tool_paths']['rust']).resolve(strict=True)}
    for engine, binary in binaries.items():
        guard(binary, binary_hashes[engine])
    workloads = [workload for workload in benchmark['workloads'] if workload['label'] == summary['label']]
    require(len(workloads) == 1, 'workload missing or repeated')
    workload = workloads[0]
    require(workload['scenario'] == 'alert-quiet' and workload['label'] == 'alert-quiet-4096' and workload['inspected_pairs_per_call'] == 4096, 'unexpected workload')
    require(set(summary['cases']) == {'128', '256'}, 'wrong query counts')
    cases = {}
    for count in (128, 256):
        metadata = summary['cases'][str(count)]
        case = metadata['case']
        expected_case = json.loads(json.dumps(workload['case']))
        expected_case['arguments'][-1] = str(count)
        require(case == expected_case and metadata['pairs'] == count * 4096, 'profile inputs changed beyond repeat count')
        args_ = case['arguments']
        require(len(args_) == 6 and args_[0] == 'alert' and int(args_[-1]) == count, 'wrong invocation')
        files = {name: decoded_file(value) for name, value in case['files'].items()}
        reference, observed = [files[name].decode('utf-8').splitlines() for name in args_[1:3]]
        require(int(reference[0]) == int(observed[0]) == 4096 and len(reference) == len(observed) == 4097, 'sample counts differ')
        left = [tuple(map(int, row.split())) for row in reference[1:]]
        right = [tuple(map(int, row.split())) for row in observed[1:]]
        threshold = int(args_[4])
        require(all(len(a) == len(b) == 2 and a[0] == b[0] and abs(a[1] - b[1]) <= threshold for a, b in zip(left, right, strict=True)), 'quiet workload can alert')
        require(all(rows[i - 1][0] < rows[i][0] for rows in (left, right) for i in range(1, len(rows))), 'timestamps not increasing')
        require(metadata['expected_stdout'] == 'OK\n0\n', 'false-query repetition checksum is wrong')
        expected_files = {name: decoded_file(value) for name, value in metadata['expected_files'].items()}
        files[args_[3]] = b'False\n'
        require(expected_files == files and metadata['expected_directories'] == [], 'unexpected independent file oracle')
        require(case['directories'] == [] and case['hardlinks'] == {}, 'unexpected filesystem shape')
        cases[count] = (case, expected_files)
    expected_profiles = {(engine, tool, count) for engine in binaries for tool, count in (('callgrind', 128), ('dhat', 128), ('dhat', 256))}
    require({(item['engine'], item['tool'], item['repetitions']) for item in summary['profiles']} == expected_profiles and len(summary['profiles']) == 6, 'incomplete/duplicate profile runs')
    parsed = {}
    for item in summary['profiles']:
        engine, tool, count = item['engine'], item['tool'], item['repetitions']
        name = f'{engine}-{tool}-{count}'
        directory = root / name
        record = json.loads((directory / 'command.json').read_text())
        require(record == {key: value for key, value in item.items() if key != 'files'}, 'profile command record differs')
        require(item['returncode'] == 0 and item['status'] == 'validated' and item['binary_sha256'] == binary_hashes[engine], 'profile command did not validate')
        require(item['pairs'] == count * 4096 and Path(item['cwd']) == directory / 'work', 'profile workload/cwd differs')
        command = item['command']
        expected_command = [summary['guarded_inputs']['tool_valgrind']['path'], '--tool=' + tool,
                            '--command-line-only=yes', '--num-callers=32', '--error-exitcode=97',
                            '--log-file=' + str(directory / 'valgrind.log'),
                            '--' + tool + '-out-file=' + str(directory / ('profile.callgrind' if tool == 'callgrind' else 'profile.json'))]
        if tool == 'callgrind':
            expected_command += ['--dump-instr=yes', '--collect-jumps=yes']
        expected_command += [str(binaries[engine]), *cases[count][0]['arguments']]
        require(command == expected_command, 'exact profiler command differs')
        require(Path(command[0]).resolve() == Path(summary['guarded_inputs']['tool_valgrind']['path']).resolve(), 'different Valgrind executable')
        require('--num-callers=32' in command, 'different allocation stack depth')
        if tool == 'callgrind':
            require('--dump-instr=yes' in command and '--collect-jumps=yes' in command, 'different instruction collection')
        require('--tool=' + tool in command and '--command-line-only=yes' in command and '--error-exitcode=97' in command, 'unsafe/different profiler invocation')
        position = command.index(str(binaries[engine]))
        require(command[position + 1:] == cases[count][0]['arguments'], 'native arguments differ')
        require(item['environment'] == summary['environment'] and summary['environment']['LC_ALL'] == 'C' and summary['environment']['VALGRIND_OPTS'] == '', 'environment differs')
        require((directory / 'stdout.txt').read_bytes() == summary['cases'][str(count)]['expected_stdout'].encode(), 'complete stdout/checksum differs')
        require((directory / 'stderr.txt').read_bytes() == b'', 'native stderr is nonempty')
        require({path.relative_to(directory / 'work').as_posix(): path.read_bytes() for path in (directory / 'work').rglob('*') if path.is_file()} == cases[count][1], 'final filesystem differs')
        require(not any(path.is_dir() for path in (directory / 'work').iterdir()), 'unexpected output directory')
        require(set(item['files']) == {path.relative_to(directory).as_posix() for path in directory.rglob('*') if path.is_file()}, 'profile file inventory differs')
        for relative, expected in item['files'].items():
            require(digest(directory / relative) == expected, 'profile member hash differs')
        log = (directory / 'valgrind.log').read_text()
        require(not re.search(r'ERROR SUMMARY: [1-9]|Fatal error|unhandled instruction|Process terminating with', log), 'Valgrind failure marker')
        if tool == 'callgrind':
            total, functions = parse_callgrind(directory / 'profile.callgrind')
            raw_lines = (directory / 'profile.callgrind').read_text().splitlines()
            raw_commands = [line.partition(':')[2].strip() for line in raw_lines if line.startswith('cmd:')]
            require(len(raw_commands) == 1 and shlex.split(raw_commands[0]) == command[position:], 'Callgrind profiled another command')
            require([int(line.partition(':')[2]) for line in raw_lines if line.startswith('totals:')] == [total], 'Callgrind final totals differ')
            metrics = item['metrics']
            require(metrics['instructions'] == metrics['self_cost_sum'] == total, 'instruction summary differs')
            recorded = {row['name']: {key: row[key] for key in ('self_instructions', 'calls', 'incoming_inclusive_instructions')} for row in metrics['functions']}
            require(len(recorded) == len(metrics['functions']) and recorded == functions, 'raw function counts differ')
            require(all(row['self_fraction'] == row['self_instructions'] / total for row in metrics['functions']), 'function fraction differs')
            require(len(item['annotations']) == 2 and all(value['returncode'] == 0 for value in item['annotations']), 'annotation incomplete')
            for annotation, inclusive in zip(item['annotations'], ('no', 'yes'), strict=True):
                require(annotation['command'] == [summary['guarded_inputs']['tool_annotate']['path'], '--auto=no', '--inclusive=' + inclusive, '--threshold=100', str(directory / 'profile.callgrind')], 'exact annotation command differs')
                require((directory / f'inclusive-{inclusive}-stderr.txt').read_bytes() == b'', 'annotation stderr nonempty')
            parsed[name] = {'instructions': total, 'instructions_per_inspected_pair': total / item['pairs'], 'top_self_functions': metrics['functions'][:15]}
        else:
            metrics = parse_dhat(directory / 'profile.json')
            raw_heap = json.loads((directory / 'profile.json').read_text())
            require(shlex.split(raw_heap['cmd']) == command[position:], 'DHAT profiled another command')
            require(metrics == item['metrics'], 'raw DHAT totals/stacks differ')
            parsed[name] = metrics
    slopes = {}
    for engine in binaries:
        slopes[engine] = {}
        for field in ('allocated_bytes', 'allocated_blocks'):
            a, b = [parsed[f'{engine}-dhat-{count}'][field] for count in (128, 256)]
            expected = {'at_128_queries': a, 'at_256_queries': b, 'per_additional_query': (b - a) / 128, 'two_point_fixed_estimate': 2 * a - b}
            require(summary['allocation_growth'][engine][field] == expected, 'allocation growth arithmetic differs')
            slopes[engine][field] = {**expected, 'per_additional_inspected_pair': (b - a) / (128 * 4096)}
    allocation_stack_growth = {}
    for engine in binaries:
        captures = []
        for count in (128, 256):
            heap = json.loads((root / f'{engine}-dhat-{count}/profile.json').read_text())
            totals = {}
            for point in heap['pps']:
                frames = tuple(heap['ftbl'][index] for index in point['fs'])
                item = totals.setdefault(frames, [0, 0])
                item[0] += point['tb']
                item[1] += point['tbk']
            captures.append(totals)
        differences = []
        for frames in captures[0].keys() | captures[1].keys():
            left, right = [capture.get(frames, [0, 0]) for capture in captures]
            delta = [right[index] - left[index] for index in (0, 1)]
            if any(delta):
                differences.append({'additional_bytes': delta[0], 'additional_blocks': delta[1], 'frames': list(frames)})
        require(sum(item['additional_bytes'] for item in differences) == slopes[engine]['allocated_bytes']['at_256_queries'] - slopes[engine]['allocated_bytes']['at_128_queries'], 'allocation stack byte deltas differ')
        require(sum(item['additional_blocks'] for item in differences) == slopes[engine]['allocated_blocks']['at_256_queries'] - slopes[engine]['allocated_blocks']['at_128_queries'], 'allocation stack block deltas differ')
        allocation_stack_growth[engine] = sorted(differences, key=lambda item: (item['additional_bytes'], item['frames']), reverse=True)
    require(digest(root / 'summary.json') == summary_hash, 'summary changed during audit')
    return {'directory': str(root), 'summary_sha256': summary_hash, 'manifest_sha256': guard(root / 'manifest.json'),
            'profiles_verified': 6, 'evidence_files_verified': len(manifest), 'binary_sha256': binary_hashes,
            'llvm_sha256': prepared['llvm_sha256'], 'complete_outputs_verified': True,
            'raw_counts_independently_reparsed': True, 'started_after_all_final_timing': True,
            'metrics': parsed, 'allocation_growth': slopes, 'allocation_stack_growth': allocation_stack_growth,
            'whole_process_instruction_ratio_relar_over_rust': parsed['relar-callgrind-128']['instructions'] / parsed['rust-callgrind-128']['instructions']}


def main():
    guard(__file__)
    require(sys.flags.optimize == 0, 'run audit without Python -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--profile-directory', type=Path, required=True)
    parser.add_argument('--validation-audit', type=Path, required=True)
    parser.add_argument('--validation-audit-script', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), 'preserve earlier audits; select a fresh output')
    guard(PARSERS, PARSERS_SHA256)
    global parsers, independent_oracle, decoded_file, parse_callgrind, parse_dhat
    parsers = runpy.run_path(str(PARSERS), run_name='telemetry_final_independent_parsers')
    independent_oracle, decoded_file = parsers['independent_oracle'], parsers['decoded_file']
    parse_callgrind, parse_dhat = parsers['parse_callgrind'], parsers['parse_dhat']
    context = audit_inputs(args.plan, args.validation_audit, args.validation_audit_script)
    statuses, records, target = audit_timings(context)
    profile = audit_profiles(context, statuses, records, args.profile_directory)
    guard(__file__)
    for path, expected in list(GUARDS.items()):
        guard(path, expected)
    for directory in list(TREES):
        tree(directory)
    bindings = parsers['SOURCE_BINDINGS']
    report = {
        'schema': 1, 'kind': 'telemetry-final-evidence-audit', 'status': 'passed',
        'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'revision': context['revision'],
        'validation_full_matrix_passed': True, 'exploratory': False,
        'audit_script': str(Path(__file__).resolve()), 'audit_script_sha256': guard(__file__),
        'parser_dependency': {'path': str(PARSERS), 'sha256': PARSERS_SHA256},
        'plan': {'path': context['plan_path'], 'sha256': guard(context['plan_path'])},
        'candidate_plan': {'path': context['candidate_path'], 'sha256': guard(context['candidate_path'])},
        'validation': {'index': context['index_path'], 'index_sha256': guard(context['index_path']),
                       'build': context['build_path'], 'build_sha256': guard(context['build_path']),
                       'audit': context['validation_audit_path'], 'audit_sha256': guard(context['validation_audit_path']),
                       'audit_script': context['validation_script'], 'audit_script_sha256': guard(context['validation_script']),
                       'counts': context['validation_audit']['counts']},
        'preparations': context['plan']['preparations'],
        'preparation_status': {'path': context['preparation_status_path'], 'sha256': guard(context['preparation_status_path'])},
        'statuses': statuses, 'records': records, 'profile': profile,
        'executions': context['plan']['executions'], 'performance_target': target,
        'maximum_control_fractions': {engine: max(record['max_control_fractions'][engine] for record in records.values()) for engine in ENGINES},
        'source_binding': {'method': 'Checkout source paths are verified against exact Git blobs at revision; external evidence/artifacts/tools are hashed live.',
                           'source_files_verified': len(bindings),
                           'advanced_live_sources': [value for value in bindings.values() if value['live_source_has_advanced']]},
        'guarded_files': GUARDS, 'guarded_trees': TREES,
        'input_guards_passed': True,
        'limits': [
            'Validity is separate from the performance goal. Inspect performance_target.all_four_below_two.',
            'All ratios use complete-process medians. Empty controls are not subtracted and omit nonempty parsing/alignment.',
            'Measured orders are balanced; eight warmups and cross-round transitions are not fully balanced.',
            'Callgrind counts guest instructions, not CPU cycles or wall-time speedup. Inclusive edges overlap.',
            'DHAT requested bytes/blocks are not RSS; two-count allocation slopes do not prove linearity.',
            'No engines, application oracles, builds, timing runs, or profiles were executed by this auditor.'
        ],
    }
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': 'passed', 'audit': str(args.output), 'sha256': digest(args.output), 'performance_target': target}))


if __name__ == '__main__':
    main()
