"""Package independently audited final iterator evidence without running experiments.

All final paths are derived from an explicit passed final audit. Optional extras
are retained as exploratory material and never count toward final acceptance.
The old deterministic packager is imported only as pinned archive machinery.
"""

import argparse
import hashlib
import io
import json
from pathlib import Path
import runpy
import subprocess
import sys
import tarfile

MACHINERY = Path('/tmp/elir-iterator-package-evidence.py')
MACHINERY_SHA256 = '285d2c27e38ef6ba6f02cb94b6c7ae7357d22cebbe952a31a8948bf90d66545d'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def option(command, name):
    require(command.count(name) == 1, 'expected exactly one ' + name)
    return command[command.index(name) + 1]


def main():
    script_sha = sha(__file__)
    require(sys.flags.optimize == 0, 'run packaging without Python -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--prefix', type=Path, required=True)
    parser.add_argument('--extra', nargs=2, action='append', default=[], metavar=('LABEL', 'PATH'))
    args = parser.parse_args()
    require(sha(MACHINERY) == MACHINERY_SHA256, 'pinned archive machinery changed')
    library = runpy.run_path(str(MACHINERY), run_name='imre_final_archive_machinery')
    package = library['Package']()
    package.guard(__file__, script_sha)
    package.guard(MACHINERY, MACHINERY_SHA256)
    audit = package.read_json(args.audit)
    require(audit['schema'] == 1 and audit['kind'] == 'telemetry-final-evidence-audit'
            and audit['status'] == 'passed' and audit['input_guards_passed']
            and audit['validation_full_matrix_passed'] is True and audit['exploratory'] is False,
            'complete independent final audit is required')
    package.guard(audit['audit_script'], audit['audit_script_sha256'])
    package.guard(audit['parser_dependency']['path'], audit['parser_dependency']['sha256'])
    for path, expected in audit['guarded_files'].items():
        package.guard(path, expected)
    for path, expected in audit['guarded_trees'].items():
        require(package.tree_entries(Path(path)) == expected, 'audited directory membership changed')
        package.trees[Path(path).absolute()] = expected
    plan = package.read_json(audit['plan']['path'])
    package.guard(audit['plan']['path'], audit['plan']['sha256'])
    root = Path(plan['root']).resolve(strict=True)
    revision = audit['revision']
    prefix = args.prefix.resolve()
    require(Path('/tmp') in prefix.parents and prefix.parent.is_dir(), 'use a fresh prefix under /tmp')
    require(plan['kind'] == 'telemetry-final-measurement-plan' and plan['status'] == 'planned'
            and plan['input_guards_passed'] and plan['validation_full_matrix_passed'] is True
            and plan['validation_mode'] == 'full-validation' and plan['revision'] == revision,
            'final plan revision or validation differs')

    def git(*arguments):
        return subprocess.check_output(['git', '-C', str(root), *arguments])

    candidate = package.read_json(audit['candidate_plan']['path'])
    package.guard(audit['candidate_plan']['path'], audit['candidate_plan']['sha256'])
    require(Path(plan['candidate_plan']).resolve(strict=True) == Path(audit['candidate_plan']['path']).resolve(strict=True)
            and plan['candidate_plan_sha256'] == audit['candidate_plan']['sha256']
            and candidate['revision'] == revision and candidate['validation_full_matrix_passed'] is True,
            'candidate plan binding differs')
    validation_binding = audit['validation']
    validation = Path(validation_binding['index']).resolve(strict=True).parent
    index = package.read_json(validation_binding['index'])
    build = package.read_json(validation_binding['build'])
    validation_audit = package.read_json(validation_binding['audit'])
    for name, key in (('index', 'index_sha256'), ('build', 'build_sha256'), ('audit', 'audit_sha256'), ('audit_script', 'audit_script_sha256')):
        package.guard(validation_binding[name], validation_binding[key])
    require(index['status'] == validation_audit['status'] == 'passed'
            and index['mode'] == 'full-validation' and index['full_validation_passed'] is True
            and index['input_guards_passed'] and index['source_unchanged']
            and build['input_guards_passed'] and build['source_matches_revision']
            and build['revision'] == index['revision'] == validation_audit['validation_revision'] == revision
            and index['build_record']['sha256'] == validation_binding['build_sha256']
            and validation_audit['validation_index_sha256'] == validation_binding['index_sha256']
            and validation_audit['audit_script_sha256'] == validation_binding['audit_script_sha256'],
            'full validation/build/audit identity differs')
    require(validation_audit['counts'] == validation_binding['counts']
            and index['job_counts'] == {'passed': len(index['jobs']), 'failed': 0}
            and validation_audit['counts']['passed_jobs'] == len(index['jobs'])
            and validation_audit['counts']['rust_units']['total'] == index['unit_tests_passed'], 'validation counts differ')
    evidence_manifest = package.read_json(validation / 'evidence-sha256.json')
    package.guard(validation / 'evidence-sha256.json', index['evidence_manifest_sha256'])
    inventory = package.tree_entries(validation)
    require({name for name, directory in inventory.items() if not directory}
            == set(evidence_manifest) | {'evidence-sha256.json', 'index.json'}, 'validation file inventory differs')
    for name, expected in evidence_manifest.items():
        package.guard(validation / library['relative_name'](name), expected)
    source = package.read_json(validation / 'source-before.json')
    require(source == package.read_json(validation / 'source-after.json') and source['revision'] == revision
            and source['status'] == '' and source['tree'] == git('rev-parse', revision + '^{tree}').decode().strip(),
            'frozen validation source snapshot differs')
    names = sorted(source['files'])
    require(names == sorted(name for name in git('ls-tree', '-r', '--name-only', revision).decode().splitlines()
                            if not name.startswith('benchmarks/results/')), 'source file inventory differs')
    with tarfile.open(fileobj=io.BytesIO(git('archive', '--format=tar', revision, '--', *names))) as archive:
        contents = {item.name: (archive.extractfile(item).read(), item.mode) for item in archive if item.isfile()}
    require(set(contents) == set(names), 'implementation Git source archive differs')
    for name, entry in source['files'].items():
        data, mode = contents[name]
        require(digest(data) == entry['sha256'] and bool(mode & 0o111) == entry['executable'], 'source Git blob differs: ' + name)
        package.add_bytes('source/' + name, data, 0o755 if mode & 0o111 else 0o644)
    require(all(digest(contents[name][0]) == expected for name, expected in build['source_sha256'].items()), 'compiler/runtime source identity differs')
    package.add_tree('validation', validation)
    package.add_file('audits/final-timing-profile.json', args.audit)
    package.add_file('audits/full-validation.json', validation_binding['audit'])
    package.add_file('helpers/full-validation-audit.py', validation_binding['audit_script'])
    package.add_file('helpers/final-timing-profile-audit.py', audit['audit_script'])
    package.add_file('helpers/independent-oracle-profile-parsers.py', audit['parser_dependency']['path'])
    package.add_file('helpers/archive-machinery.py', MACHINERY)
    package.add_file('helpers/package-final-evidence.py', __file__)
    package.add_file('provenance/final-plan.json', audit['plan']['path'])
    package.add_file('provenance/candidate-plan.json', audit['candidate_plan']['path'])
    package.add_file('preparation/status.json', audit['preparation_status']['path'])
    package.guard(audit['preparation_status']['path'], audit['preparation_status']['sha256'])
    preparation_status = package.read_json(audit['preparation_status']['path'])
    require(preparation_status['status'] == 'passed' and preparation_status['input_guards_passed']
            and preparation_status['revision'] == revision
            and preparation_status['plan_sha256'] == audit['candidate_plan']['sha256']
            and [run['mode'] for run in preparation_status['runs']] == ['normal', 'thinlto'], 'preparation phase differs')
    for run in preparation_status['runs']:
        mode = run['mode']
        command = candidate['commands']['prepare'][mode]
        binding = audit['preparations'][mode]
        require(run['status'] == 'passed' and run['exit_code'] == 0 and run['command'] == command
                and Path(run['output']).resolve(strict=True) == Path(binding['path']).resolve(strict=True)
                == Path(option(command, '--output')).resolve(strict=True)
                and run['output_sha256'] == binding['sha256'], 'exact preparation run differs')
        for stream in ('stdout', 'stderr'):
            package.guard(run[stream], run[stream + '_sha256'])
            package.add_file('preparation/logs/' + mode + '.' + stream, run[stream])
    for name, value in sorted(index['tools'].items()):
        package.guard(value['path'], value['sha256'])
        package.add_file('tools/validation/' + name, value['path'], omit='external tool executable')

    retained_external = set()
    for name, value in sorted(plan['protected_paths'].items()):
        path = Path(value).resolve(strict=True)
        expected = plan['protected_sha256'][name]
        if path.is_relative_to(root):
            relative = path.relative_to(root).as_posix()
            require(relative in contents and digest(contents[relative][0]) == expected, 'final source differs from implementation snapshot')
        else:
            package.guard(path, expected)
            if path.suffix == '.py' and path not in retained_external:
                package.add_file('helpers/planned/' + path.name, path)
                retained_external.add(path)
            elif name.startswith('baseline:'):
                package.add_file('historical-baselines/' + name.split(':', 1)[1] + '.json', path)
    prepared = {}
    for mode in ('normal', 'thinlto'):
        binding = audit['preparations'][mode]
        require(binding == plan['preparations'][mode], 'audited preparation metadata differs')
        value = package.read_json(binding['path'])
        package.guard(binding['path'], binding['sha256'])
        require(value['input_guards_passed'] and not value['dirty'] and value['revision'] == revision
                and value['thinlto'] == (mode == 'thinlto') and value['imre_build_record'] == build
                and value['binary_sha256'] == binding['binary_sha256'], 'prepared source/build/binary differs')
        directory = Path(value['binary']).resolve(strict=True).parent
        for key in ('binary', 'llvm', 'validation'):
            path = Path(value['validation_path' if key == 'validation' else key]).resolve(strict=True)
            require(path.is_relative_to(directory), 'prepared artifact outside retained directory')
            package.guard(path, value[key + '_sha256'])
        package.add_file('preparation/' + mode + '.json', binding['path'])
        package.add_tree('preparation/' + mode, directory)
        for key, path_text in value['source_and_tool_paths'].items():
            path = Path(path_text).resolve(strict=True)
            expected = value['source_and_tool_sha256'][key]
            if path.is_relative_to(root):
                relative = path.relative_to(root).as_posix()
                require(relative in contents and digest(contents[relative][0]) == expected, 'prepared source differs from Git snapshot')
            else:
                package.guard(path, expected)
                if key == 'rust_build_record':
                    package.add_file('references/telemetry-' + mode + '/build-record.json', path)
                elif key not in ('imre_build_record',):
                    package.add_file('external/' + mode + '/' + key.replace(':', '_') + '/' + path.name, path,
                                     omit='external tool executable' if key in ('python', 'clang', 'lto_linker') else None)
        prepared[mode] = value
    require(set(audit['statuses']) == {'full', 'early'} and set(audit['records']) == {'full-normal', 'full-thinlto', 'early-normal', 'early-thinlto'}, 'final phase/mode set differs')
    for phase in ('full', 'early'):
        binding = audit['statuses'][phase]
        status = package.read_json(binding['path'])
        package.guard(binding['path'], binding['sha256'])
        require(status['status'] == 'passed' and status['phase'] == phase and status['exploratory'] is False
                and status['revision'] == revision and status['input_guards_passed'] and status['source_unchanged']
                and status['plan_sha256'] == audit['plan']['sha256']
                and status['planned_commands'] == plan['phases'][phase]['commands'], 'final status differs')
        package.add_file('timing/status/' + phase + '.json', binding['path'])
        require([run['mode'] for run in status['runs']] == ['normal', 'thinlto'], 'timing modes differ')
        for run in status['runs']:
            mode, label = run['mode'], phase + '-' + run['mode']
            audited = audit['records'][label]
            record = package.read_json(run['output'])
            package.guard(run['output'], run['output_sha256'])
            require(run['status'] == 'passed' and run['exit_code'] == 0
                    and run['command'] == plan['phases'][phase]['commands'][mode]
                    and run['output_sha256'] == audited['record_sha256']
                    and Path(run['output']).resolve(strict=True) == Path(audited['record']).resolve(strict=True)
                    == Path(option(run['command'], '--output')).resolve(strict=True)
                    and record['preparation'] == prepared[mode]
                    and record['preparation_record_sha256'] == audit['preparations'][mode]['sha256'], 'timing record/preparation binding differs')
            directory = Path(option(run['command'], '--artifact-dir')).resolve(strict=True)
            require(directory == Path(audited['artifact_directory']).resolve(strict=True), 'timing artifact directory differs')
            package.add_file('timing/records/' + label + '.json', run['output'])
            package.add_tree('timing/artifacts/' + label, directory)
            for stream in ('stdout', 'stderr'):
                package.guard(run[stream], run[stream + '_sha256'])
                package.add_file('timing/logs/' + label + '.' + stream, run[stream])
    profile = Path(audit['profile']['directory']).resolve(strict=True)
    package.guard(profile / 'summary.json', audit['profile']['summary_sha256'])
    package.guard(profile / 'manifest.json', audit['profile']['manifest_sha256'])
    require(audit['profile']['profiles_verified'] == 6 and audit['profile']['complete_outputs_verified']
            and audit['profile']['started_after_all_final_timing'], 'final profile audit is incomplete')
    package.add_tree('profiles/final', profile)
    extras = {}
    for label, path_text in args.extra:
        require(label not in extras and label and all(char.isalnum() or char in '-_' for char in label), 'invalid or duplicate exploratory label')
        path = Path(path_text).resolve(strict=True)
        if path.is_dir():
            require(not any(name.endswith(('.tar', '.tar.gz', '.tgz', '.tar.xz', '.zip')) for name in package.tree_entries(path)), 'do not nest previous archives in exploratory extras')
            package.add_tree('exploratory/' + label, path)
        else:
            require(not path.name.endswith(('.tar', '.tar.gz', '.tgz', '.tar.xz', '.zip')), 'do not nest previous evidence archives')
            package.add_file('exploratory/' + label + '/' + path.name, path)
        extras[label] = {'path': str(path), 'scope': 'exploratory only; excluded from final acceptance'}
    metadata = {
        'schema': 1, 'kind': 'iterator-performance-final-evidence',
        'build_revision': revision, 'validation_revision': revision, 'timing_revision': revision,
        'source_tree': source['tree'], 'post_validation_paths': [], 'source_files': len(contents),
        'final_plan_sha256': audit['plan']['sha256'], 'candidate_plan_sha256': audit['candidate_plan']['sha256'],
        'final_audit_sha256': package.guard(args.audit), 'final_auditor_sha256': audit['audit_script_sha256'],
        'validation_index_sha256': validation_binding['index_sha256'], 'build_record_sha256': validation_binding['build_sha256'],
        'validation_audit_sha256': validation_binding['audit_sha256'], 'validation_counts': validation_binding['counts'],
        'timing_status_sha256': {phase: value['sha256'] for phase, value in audit['statuses'].items()},
        'timing_records': {label: {'record_sha256': value['record_sha256'], 'phase': value['phase'], 'mode': value['mode']} for label, value in audit['records'].items()},
        'profile_summary_sha256': audit['profile']['summary_sha256'], 'profile_manifest_sha256': audit['profile']['manifest_sha256'],
        'executions': audit['executions'], 'performance_target': audit['performance_target'],
        'packager_sha256': package.guard(__file__), 'archive_machinery_sha256': MACHINERY_SHA256,
        'exploratory_extras': extras,
        'notes': [
            'source/ is the exact implementation Git snapshot used for full validation, preparations, timing, and final profiling; no post-validation source overlay is permitted.',
            'Original evidence bytes and historical SHA mentions remain unchanged. Exploratory extras are not final performance or full-validation evidence.',
            'Native executables, static/object libraries, LLVM/Python bytecode, and external tools are hash-recorded exclusions identified by content where applicable.',
            'Prior evidence archives, Git administration, caches, credentials, and private-ref/worktree inventories are not selected.',
            'Every selected file and directory membership is guarded before/after writing. Archive ordering, ownership, modes, timestamps, and gzip timestamp are normalized.',
            'Validity is separate from the four-case performance goal; the audited target result is retained without changing it.',
        ],
    }
    package.write(prefix, metadata)


if __name__ == '__main__':
    main()
