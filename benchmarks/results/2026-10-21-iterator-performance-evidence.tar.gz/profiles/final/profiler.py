"""Profile the exact timed ThinLTO telemetry binaries; never build or time them.

Run only after all wall-time measurements have stopped:
  python3 -I -B /tmp/imre-telemetry-final-profile.py \
    --timing-status /tmp/imre-telemetry-final/full-timing-status.json \
    --output /tmp/imre-telemetry-final-profile

This helper accepts only the completed final full phase, with both ordinary and
ThinLTO timing commands bound to a fully validated final measurement plan.
Metric parsers are reused from the pinned, unchanged exploratory profiler.

The six whole-process profiles are Callgrind and DHAT at 128 alert-quiet-4096
queries for each engine, plus DHAT at 256 queries. The latter pair distinguishes
allocation growth per query from fixed startup/input-loading work. Inputs come
from the completed timed workload; only its repeat argument changes. Every run
is checked by the independent telemetry oracle, including complete stdout,
checksum, stderr, and all filesystem effects. No program source is modified.
"""

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
from types import SimpleNamespace


CACHE = Path("/home/dev-user/.cache/onyx/profiling-tools/root/usr")
PARSERS = Path("/tmp/imre-telemetry-profile.py")
PARSERS_SHA256 = "61f2e8a59d092473ef1e8557fc40ce0033d9aeb59a5e8eff2cbe00f3ba53fa05"
FINAL_EVIDENCE = Path("/tmp/imre-telemetry-final-evidence.py")
FINAL_EVIDENCE_SHA256 = "b8a824bbf58bfb5b97250b0d6110f77973cc7cbf887b086dd310303787dc2862"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    require(sys.flags.optimize == 0, "Run profiles without Python -O; complete oracle checks use assertions")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preparation", type=Path, help="infer from the completed timing command by default")
    parser.add_argument("--record", type=Path, help="infer from the completed ThinLTO timing run by default")
    parser.add_argument("--plan", type=Path, help="infer from timing status by default")
    parser.add_argument("--timing-status", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--valgrind", type=Path, default=CACHE / "bin/valgrind")
    parser.add_argument("--valgrind-lib", type=Path, default=CACHE / "libexec/valgrind")
    parser.add_argument("--annotate", type=Path, default=CACHE / "bin/callgrind_annotate")
    parser.add_argument("--timeout", type=float, default=900)
    args = parser.parse_args()
    require(args.timeout > 0, "timeout must be positive")
    tracer = next(line.split(":")[1] for line in Path("/proc/self/status").read_text().splitlines()
                  if line.startswith("TracerPid:"))
    require(int(tracer) == 0, "run Valgrind outside the ptrace sandbox")
    args.timing_status = args.timing_status.resolve(strict=True)
    timing_sha = sha(args.timing_status)
    timing = json.loads(args.timing_status.read_text())
    require(timing["schema"] == 1 and timing["kind"] == "telemetry-final-measurement-status"
            and timing["status"] == "passed" and timing["input_guards_passed"]
            and timing["source_unchanged"] and timing["completed_at"], "final timing is incomplete")
    require(timing["phase"] == "full" and timing["exploratory"] is False
            and timing["validation_mode"] == "full-validation"
            and timing["validation_full_matrix_passed"] is True,
            "this helper requires the completed final full phase after full validation")
    args.plan = (args.plan or Path(timing["plan"])).resolve(strict=True)
    require(args.plan == Path(timing["plan"]).resolve(strict=True)
            and sha(args.plan) == timing["plan_sha256"], "final plan differs from timing")
    plan = json.loads(args.plan.read_text())
    require(plan["schema"] == 1 and plan["kind"] == "telemetry-final-measurement-plan"
            and plan["status"] == "planned" and plan["input_guards_passed"]
            and plan["revision"] == timing["revision"] and plan["validation_mode"] == "full-validation"
            and plan["validation_full_matrix_passed"] is True, "final plan is incomplete")
    require(args.timing_status == (Path(plan["output"]) / "full-timing-status.json").resolve(strict=True),
            "timing status path differs from final phase")
    plan_paths = {name: Path(value) for name, value in plan["protected_paths"].items()}
    require({name: sha(path) for name, path in plan_paths.items()} == plan["protected_sha256"],
            "final source/build/tool/preparation evidence changed")
    require(plan_paths["final_helper"].resolve() == FINAL_EVIDENCE.resolve(strict=True)
            and plan["protected_sha256"]["final_helper"] == FINAL_EVIDENCE_SHA256
            and sha(PARSERS) == PARSERS_SHA256, "pinned final evidence helper or metric parsers changed")
    final = runpy.run_path(str(FINAL_EVIDENCE), run_name="telemetry_final_profile_evidence")
    metrics = runpy.run_path(str(PARSERS), run_name="telemetry_final_profile_parsers")
    callgrind_metrics, dhat_metrics = metrics["callgrind_metrics"], metrics["dhat_metrics"]
    candidate_path = Path(plan["candidate_plan"]).resolve(strict=True)
    require(candidate_path == plan_paths["candidate_plan"].resolve(strict=True)
            and candidate_path == Path(timing["candidate_plan"]).resolve(strict=True)
            and sha(candidate_path) == plan["candidate_plan_sha256"] == timing["candidate_plan_sha256"],
            "final timing candidate plan differs")
    candidate = json.loads(candidate_path.read_text())
    require(candidate["status"] == "planned" and candidate["input_guards_passed"]
            and candidate["revision"] == plan["revision"] and candidate["root"] == plan["root"]
            and candidate["validation_mode"] == "full-validation"
            and candidate["validation_full_matrix_passed"] is True, "candidate lacks complete full validation")
    candidate_paths = {name: Path(value) for name, value in candidate["protected_paths"].items()}
    require(all(plan_paths["candidate:" + name].resolve(strict=True) == path.resolve(strict=True)
                and plan["protected_sha256"]["candidate:" + name] == candidate["protected_sha256"][name]
                for name, path in candidate_paths.items()), "final candidate bindings differ")
    schedule = plan["phases"]["full"]
    require(schedule["mode_order"] == list(final["MODES"])
            and schedule["samples"] == final["SAMPLES"] and schedule["warmups"] == final["WARMUPS"]
            and schedule["sizes"] == final["SIZES"]
            and schedule["batch_pairs"] == final["PHASES"]["full"]["batch_pairs"]
            and schedule["scenarios"] == final["PHASES"]["full"]["scenarios"], "final full schedule differs")
    require(schedule["commands_sha256"] == final["json_sha"](schedule["commands"])
            == timing["planned_commands_sha256"] and timing["planned_commands"] == schedule["commands"]
            and timing["executions"] == schedule["executions"], "exact final phase command binding differs")
    require([item["mode"] for item in timing["runs"]] == schedule["mode_order"],
            "final timing modes are incomplete, duplicated, or reordered")
    preparation_status_path = Path(candidate["output"]) / "prepare-status.json"
    require(preparation_status_path.resolve(strict=True) == plan_paths["preparation_status"].resolve(strict=True),
            "candidate preparation status path differs")
    preparation_status = json.loads(preparation_status_path.read_text())
    require(preparation_status["status"] == "passed" and preparation_status["input_guards_passed"]
            and preparation_status["phase"] == "prepare" and preparation_status["completed_at"]
            and preparation_status["revision"] == plan["revision"]
            and preparation_status["validation_full_matrix_passed"] is True
            and Path(preparation_status["plan"]).resolve(strict=True) == candidate_path
            and preparation_status["plan_sha256"] == sha(candidate_path), "candidate preparation is incomplete")
    require([item["mode"] for item in preparation_status["runs"]] == schedule["mode_order"],
            "candidate preparation modes differ")
    completed_paths = {}
    completed_expected = {}
    for run, prepared_run in zip(timing["runs"], preparation_status["runs"], strict=True):
        mode = run["mode"]
        command = schedule["commands"][mode]
        record_path = Path(final["option"](command, "--output")).resolve(strict=True)
        prepared_path = Path(final["option"](command, "--prepared-record")).resolve(strict=True)
        require(run["phase"] == "full" and run["status"] == "passed" and run["exit_code"] == 0
                and run["completed_at"] and run["command"] == command
                and run["command_sha256"] == final["json_sha"](command)
                and Path(run["output"]).resolve(strict=True) == record_path
                and run["output_sha256"] == sha(record_path), "completed final mode command or record differs")
        prepare_command = candidate["commands"]["prepare"][mode]
        require(prepared_run["status"] == "passed" and prepared_run["exit_code"] == 0
                and prepared_run["completed_at"] and prepared_run["command"] == prepare_command
                and Path(prepared_run["output"]).resolve(strict=True) == prepared_path
                == Path(final["option"](prepare_command, "--output")).resolve(strict=True)
                == Path(plan["preparations"][mode]["path"]).resolve(strict=True)
                == plan_paths[mode + ":preparation"].resolve(strict=True)
                and prepared_run["output_sha256"] == sha(prepared_path)
                == plan["preparations"][mode]["sha256"], "completed mode preparation binding differs")
        value = json.loads(record_path.read_text())
        final["verify_record"](value, plan, "full", mode)
        preparation = value["preparation"]
        require(preparation["kind"] == "telemetry-preparation" and preparation["input_guards_passed"]
                and preparation["revision"] == plan["revision"] and not preparation["dirty"]
                and preparation["thinlto"] == (mode == "thinlto")
                and preparation["binary_sha256"] == plan["preparations"][mode]["binary_sha256"],
                "completed mode preparation identity differs")
        completed_paths[mode + "_record"] = record_path
        completed_expected[mode + "_record"] = run["output_sha256"]
        for prefix, completed in (("timing", run), ("prepare", prepared_run)):
            for stream in ("stdout", "stderr"):
                key = mode + "_" + prefix + "_" + stream
                completed_paths[key] = Path(completed[stream]).resolve(strict=True)
                completed_expected[key] = completed[stream + "_sha256"]
        if mode == "thinlto":
            args.record = (args.record or record_path).resolve(strict=True)
            args.preparation = (args.preparation or prepared_path).resolve(strict=True)
            require(args.record == record_path and args.preparation == prepared_path,
                    "selected profiling inputs differ from completed ThinLTO mode")
            record, prepared = value, preparation
    require({name: sha(path) for name, path in completed_paths.items()} == completed_expected,
            "completed final timing or preparation output changed")
    paths = {name: Path(value).absolute() for name, value in prepared["source_and_tool_paths"].items()}
    hashes = prepared["source_and_tool_sha256"]
    require(record["source_and_tool_sha256"] == hashes and set(paths) == set(hashes),
            "timed source/tool identities differ")
    require({name: sha(path) for name, path in paths.items()} == hashes, "timed input changed")
    binaries = {"imre": Path(prepared["binary"]).resolve(strict=True), "rust": paths["rust"]}
    require(sha(binaries["imre"]) == prepared["binary_sha256"] == record["binary_sha256"]
            and sha(binaries["rust"]) == hashes["rust"], "timed native binary changed")
    for key in ("llvm", "validation"):
        path = Path(prepared["validation_path" if key == "validation" else key])
        require(sha(path) == prepared[key + "_sha256"], f"prepared {key} changed")
        paths["prepared_" + key] = path
    require(json.loads(paths["prepared_validation"].read_text()) == prepared["validation"],
            "prepared validation snapshot changed")
    build = json.loads(paths["imre_build_record"].read_text())
    rust_build = json.loads(paths["rust_build_record"].read_text())
    require(build == prepared["imre_build_record"] and build["input_guards_passed"]
            and build["source_matches_revision"] and build["revision"] == timing["revision"]
            and build["sha256"]["compiler"] == hashes["compiler"]
            and build["sha256"]["thinlto_runtime"] == hashes["runtime"], "compiler/runtime build provenance differs")
    require(rust_build == prepared["rust_build_record"] and rust_build["input_guards_passed"]
            and rust_build["thinlto"] and rust_build["binary_sha256"] == hashes["rust"],
            "Rust build provenance differs")
    paths["validation_index"] = candidate_paths["validation_index"]
    index = json.loads(paths["validation_index"].read_text())
    require(index["status"] == "passed" and index["input_guards_passed"] and index["source_unchanged"]
            and index["revision"] == build["revision"] and index["mode"] == "full-validation"
            and index["full_validation_passed"] is True
            and index["build_record"]["sha256"] == hashes["imre_build_record"]
            and sha(paths["validation_index"]) == candidate["protected_sha256"]["validation_index"],
            "completed full compiler validation differs")
    full_validation = True
    validator = SimpleNamespace(**runpy.run_path(str(paths["validator"])))
    workload, = [value for value in record["workloads"] if value["label"] == "alert-quiet-4096"]
    require(workload["scenario"] == "alert-quiet" and int(workload["label"].rsplit("-", 1)[1]) == 4096
            and workload["inspected_pairs_per_call"] == 4096, "unexpected workload")
    baseline = json.loads(plan_paths["baseline:full-thinlto"].read_text())
    baseline_workload, = [value for value in baseline["workloads"] if value["label"] == "alert-quiet-4096"]
    require(all(workload[field] == baseline_workload[field] for field in
                ("scenario", "inspected_pairs_per_call", "repetitions", "case", "expected_stdout", "expected_files")),
            "profile inputs or repetitions differ from the frozen canonical workload")
    original = validator.case_from_record(workload["case"])
    expected = validator.oracle(original)
    require(expected["stdout"] == workload["expected_stdout"]
            and validator.encoded_files(expected["files"]) == workload["expected_files"]
            and expected["files"]["report.txt"] == b"False\n", "independent timed oracle differs")
    cases = {}
    for repeats in (128, 256):
        value = deepcopy(workload["case"])
        require(len(value["arguments"]) == 6 and value["arguments"][0] == "alert", "unexpected query arguments")
        value["arguments"][-1] = str(repeats)
        case = validator.case_from_record(value)
        cases[repeats] = (case, validator.oracle(case))
    library = args.valgrind_lib.resolve(strict=True)
    tools = {"valgrind": args.valgrind.resolve(strict=True), "annotate": args.annotate.resolve(strict=True),
             "valgrind_binary": args.valgrind.parent.resolve(strict=True) / "valgrind.bin",
             "callgrind": library / "callgrind-amd64-linux", "dhat": library / "dhat-amd64-linux",
             "core_preload": library / "vgpreload_core-amd64-linux.so",
             "dhat_preload": library / "vgpreload_dhat-amd64-linux.so",
             "perl": Path("/usr/bin/perl").resolve(strict=True),
             "shell": Path("/bin/sh").resolve(strict=True), "python": Path(sys.executable).resolve(strict=True)}
    paths.update({"tool_" + name: path for name, path in tools.items()})
    paths.update(preparation=args.preparation.resolve(strict=True), benchmark=args.record.resolve(strict=True),
                 timing_status=args.timing_status.resolve(strict=True), binary=binaries["imre"],
                 profiler=Path(__file__).resolve(strict=True), final_plan=args.plan,
                 candidate_plan=candidate_path, preparation_status=preparation_status_path,
                 metric_parsers=PARSERS, final_evidence_helper=FINAL_EVIDENCE)
    paths.update(completed_paths)
    paths.update({"final_" + name: path for name, path in plan_paths.items()})
    expected_hashes = {name: sha(path) for name, path in paths.items()}
    expected_hashes.update(hashes)
    expected_hashes.update(completed_expected)
    expected_hashes.update({"final_" + name: value for name, value in plan["protected_sha256"].items()})
    expected_hashes.update(timing_status=timing_sha, final_plan=timing["plan_sha256"],
                           candidate_plan=plan["candidate_plan_sha256"], metric_parsers=PARSERS_SHA256,
                           final_evidence_helper=FINAL_EVIDENCE_SHA256)
    guarded = {name: {"path": str(path), "sha256": expected_hashes[name]} for name, path in paths.items()}

    def guard():
        require(all(sha(paths[name]) == value["sha256"] for name, value in guarded.items()),
                "profile input changed")
        root = Path(plan["root"])
        head = subprocess.check_output(["git", "-C", root, "rev-parse", "HEAD"], text=True).strip()
        dirty = subprocess.check_output(["git", "-C", root, "status", "--porcelain=v1", "--untracked-files=all"], text=True).strip()
        require(head == record["revision"] and not dirty, "profile checkout changed")

    guard()
    output = args.output.resolve()
    require(Path("/tmp") in output.parents, "profiles must be written under /tmp")
    output.mkdir(parents=True, exist_ok=False)
    snapshots = {"preparation.json": args.preparation, "benchmark-record.json": args.record,
                 "timing-status.json": args.timing_status, "imre-build-record.json": paths["imre_build_record"],
                 "rust-build-record.json": paths["rust_build_record"], "validation-index.json": paths["validation_index"],
                 "prepared-validation.json": paths["prepared_validation"], "native.ll": paths["prepared_llvm"],
                 "profiler.py": Path(__file__), "candidate-plan.json": candidate_path,
                 "final-plan.json": args.plan, "metric-parsers.py": PARSERS,
                 "final-evidence-helper.py": FINAL_EVIDENCE,
                 "normal-benchmark-record.json": completed_paths["normal_record"],
                 "normal-preparation.json": plan_paths["normal:preparation"],
                 "preparation-status.json": preparation_status_path}
    for name in ("validator", "filesystem_validator", "batch_validator", "incremental_validator", "shared_validator"):
        snapshots["oracle-" + paths[name].name] = paths[name]
    for name, path in snapshots.items():
        shutil.copyfile(path, output / name)
        require(sha(output / name) == sha(path), "profile snapshot copy differs")
    snapshot_hashes = {name: sha(output / name) for name in snapshots}
    environment = {"VALGRIND_LIB": str(library), "VALGRIND_OPTS": "", "LC_ALL": "C"}
    env = {**os.environ, **environment}
    summary = {"schema": 1, "status": "running", "complete": False, "input_guards_passed": False,
               "started_at_utc": now(), "label": "alert-quiet-4096", "thinlto": True,
               "exploratory": False, "profile_context": "final-comparison", "timing_phase": "full",
               "timing_revision": record["revision"], "build_revision": build["revision"],
               "validation_revision": index["revision"], "validation_mode": index.get("mode", "full-validation"),
               "validation_scope": index["scope"], "full_validation_passed": full_validation,
               "final_plan_sha256": sha(args.plan), "candidate_plan_sha256": sha(candidate_path),
               "final_phase_commands_sha256": schedule["commands_sha256"],
               "normal_benchmark_record_sha256": sha(completed_paths["normal_record"]),
               "canonical_baseline_record_sha256": sha(plan_paths["baseline:full-thinlto"]),
               "benchmark_record_sha256": sha(args.record), "preparation_record_sha256": sha(args.preparation),
               "timing_status_sha256": sha(args.timing_status), "snapshot_sha256": snapshot_hashes,
               "guarded_inputs": guarded, "environment": environment, "profiles": [],
               "cases": {str(repeats): {"case": validator.case_record(case), "pairs": repeats * 4096,
                                        "expected_stdout": oracle["stdout"],
                                        "expected_files": validator.encoded_files(oracle["files"]),
                                        "expected_directories": oracle["directories"]}
                         for repeats, (case, oracle) in cases.items()},
               "method": "Exact timed ThinLTO Imre/Rust binaries; whole-process Callgrind and DHAT at 128 queries, DHAT again at 256. Original timed input bytes, only repeat argument changed. Independent complete stdout/checksum/filesystem oracle after every process. No wall-time samples or builds.",
               "limits": "Callgrind Ir counts guest instructions, not CPU cycles or wall-time speedup. Inclusive costs overlap. DHAT counts requested heap bytes/blocks, not RSS; gb/gbk share the global peak. Exit-live counts alone do not establish leaks. Two-count allocation slopes are descriptive, not a proof of linearity."}
    write_json(output / "summary.json", summary)
    try:
        for engine, binary in binaries.items():
            for tool, repeats in (("callgrind", 128), ("dhat", 128), ("dhat", 256)):
                guard()
                directory = output / f"{engine}-{tool}-{repeats}"
                work = directory / "work"
                work.mkdir(parents=True)
                case, oracle = cases[repeats]
                validator.materialize(case, work)
                (work / "report.txt").write_bytes(b"replace this complete report")
                profile = directory / ("profile.callgrind" if tool == "callgrind" else "profile.json")
                command = [str(tools["valgrind"]), f"--tool={tool}", "--command-line-only=yes",
                           "--num-callers=32", "--error-exitcode=97", f"--log-file={directory / 'valgrind.log'}",
                           f"--{tool}-out-file={profile}"]
                if tool == "callgrind":
                    command += ["--dump-instr=yes", "--collect-jumps=yes"]
                command += [str(binary), *case.arguments]
                item = {"engine": engine, "tool": tool, "repetitions": repeats, "pairs": repeats * 4096,
                        "command": command, "cwd": str(work), "environment": environment,
                        "binary_sha256": sha(binary), "started_at_utc": now()}
                write_json(directory / "command.json", item)
                process = subprocess.run(command, input=b"", capture_output=True, cwd=work, env=env,
                                         timeout=args.timeout, check=False)
                (directory / "stdout.txt").write_bytes(process.stdout)
                (directory / "stderr.txt").write_bytes(process.stderr)
                item.update(returncode=process.returncode, completed_at_utc=now())
                write_json(directory / "command.json", item)
                item["validation"] = validator.check_result(case, oracle, process, work)
                item["metrics"] = callgrind_metrics(profile) if tool == "callgrind" else dhat_metrics(profile)
                if tool == "callgrind":
                    item["annotations"] = []
                    for inclusive in ("no", "yes"):
                        command = [str(tools["annotate"]), "--auto=no", f"--inclusive={inclusive}",
                                   "--threshold=100", str(profile)]
                        annotation = subprocess.run(command, capture_output=True, cwd=work, env=env,
                                                    timeout=args.timeout, check=False)
                        (directory / f"inclusive-{inclusive}.txt").write_bytes(annotation.stdout)
                        (directory / f"inclusive-{inclusive}-stderr.txt").write_bytes(annotation.stderr)
                        require(annotation.returncode == 0, "Callgrind annotation failed")
                        item["annotations"].append({"command": command, "returncode": annotation.returncode})
                item["status"] = "validated"
                write_json(directory / "command.json", item)
                item["files"] = {path.relative_to(directory).as_posix(): sha(path)
                                 for path in sorted(directory.rglob("*")) if path.is_file()}
                summary["profiles"].append(item)
                guard()
                write_json(output / "summary.json", summary)
                print(f"Validated {engine}/{tool}/{repeats}", flush=True)
        require(len(summary["profiles"]) == 6, "profile matrix is incomplete")
        summary["allocation_growth"] = {}
        for engine in binaries:
            values = {item["repetitions"]: item["metrics"] for item in summary["profiles"]
                      if item["engine"] == engine and item["tool"] == "dhat"}
            summary["allocation_growth"][engine] = {
                key: {"at_128_queries": values[128][key], "at_256_queries": values[256][key],
                      "per_additional_query": (values[256][key] - values[128][key]) / 128,
                      "two_point_fixed_estimate": 2 * values[128][key] - values[256][key]}
                for key in ("allocated_bytes", "allocated_blocks")}
        for item in summary["profiles"]:
            directory = output / f"{item['engine']}-{item['tool']}-{item['repetitions']}"
            require(all(sha(directory / name) == value for name, value in item["files"].items()),
                    "retained profile artifact changed")
        require(all(sha(output / name) == value for name, value in snapshot_hashes.items()),
                "retained provenance snapshot changed")
        guard()
        summary.update(status="passed", complete=True, input_guards_passed=True, completed_at_utc=now())
        write_json(output / "summary.json", summary)
        write_json(output / "manifest.json", {path.relative_to(output).as_posix(): sha(path)
                                              for path in sorted(output.rglob("*")) if path.is_file()})
    except BaseException as error:
        summary.update(status="failed", failure=f"{type(error).__name__}: {error}")
        write_json(output / "summary.json", summary)
        raise
    print(output / "summary.json", flush=True)


if __name__ == "__main__":
    main()
