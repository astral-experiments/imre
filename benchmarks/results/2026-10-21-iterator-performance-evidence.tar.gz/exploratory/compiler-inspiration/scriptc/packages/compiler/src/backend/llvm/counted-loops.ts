import type { IntegerCountedForLoop } from "../../ir/integer-loops.js";
import type { LlvmEmitterContext } from "./expr-context.js";
import { f64Lit } from "./common.js";

/** The caller has proved or guarded the direction's finite endpoint. Clamp
 * the opposite infinity before integer conversion. Fractional limits become
 * exclusive integer endpoints for signed comparisons in either direction. */
export function emitCountedLoopLimit(
  host: LlvmEmitterContext,
  loop: IntegerCountedForLoop,
): string {
  const ascending = loop.step > 0;
  if (loop.limit.kind === "numLit") {
    const value = ascending
      ? Math.max(-(2 ** 53), loop.limit.value)
      : Math.min(2 ** 53, loop.limit.value);
    return String(
      ascending
        ? loop.inclusive
          ? Math.floor(value) + 1
          : Math.ceil(value)
        : loop.inclusive
          ? Math.ceil(value) - 1
          : Math.floor(value),
    );
  }
  const B = host.B;
  const value = host.emitExpr(loop.limit);
  const within = B.tmp(),
    bounded = B.tmp(),
    rounded = B.tmp(),
    integer = B.tmp();
  const clamp = ascending ? -(2 ** 53) : 2 ** 53;
  B.line(`${within} = fcmp ${ascending ? "oge" : "ole"} double ${value.name}, ${f64Lit(clamp)}`);
  B.line(`${bounded} = select i1 ${within}, double ${value.name}, double ${f64Lit(clamp)}`);
  const rounding = ascending === loop.inclusive ? "floor" : "ceil";
  host.declare(`declare double @llvm.${rounding}.f64(double)`);
  B.line(`${rounded} = call double @llvm.${rounding}.f64(double ${bounded})`);
  B.line(`${integer} = fptosi double ${rounded} to i64`);
  if (!loop.inclusive) return integer;
  const limit = B.tmp();
  B.line(`${limit} = add nsw i64 ${integer}, ${ascending ? 1 : -1}`);
  return limit;
}

/** The run-time test of a guarded counted loop: an unproven limit is within
 * the integer form's finite range and an unproven start is an exact safe
 * integer. Returns `true` when nothing needs testing. */
export function emitCountedLoopSafety(
  host: LlvmEmitterContext,
  loop: IntegerCountedForLoop,
): string {
  const B = host.B;
  let safe = "true";
  if (loop.limitGuarded) {
    const bound = host.emitExpr(loop.limit);
    safe = B.tmp();
    B.line(
      `${safe} = fcmp ${loop.step > 0 ? "ole" : "oge"} double ${bound.name}, ${f64Lit(loop.guardLimit)}`,
    );
  }
  if (loop.startGuarded) {
    // An exact integer of at most 2^53 - 1 in magnitude, and not -0
    // (the bit patterns of the value and its round trip agree).
    // NaN and infinities fail the ordered range tests.
    const start = host.emitExpr(loop.start);
    const low = B.tmp(),
      high = B.tmp(),
      raw = B.tmp(),
      wide = B.tmp(),
      back = B.tmp(),
      bits = B.tmp(),
      backBits = B.tmp(),
      exact = B.tmp(),
      inRange = B.tmp(),
      ok = B.tmp();
    B.line(`${low} = fcmp oge double ${start.name}, ${f64Lit(-Number.MAX_SAFE_INTEGER)}`);
    B.line(`${high} = fcmp ole double ${start.name}, ${f64Lit(Number.MAX_SAFE_INTEGER)}`);
    B.line(`${inRange} = and i1 ${low}, ${high}`);
    B.line(`${raw} = fptosi double ${start.name} to i64`);
    B.line(`${wide} = freeze i64 ${raw}`);
    B.line(`${back} = sitofp i64 ${wide} to double`);
    B.line(`${bits} = bitcast double ${start.name} to i64`);
    B.line(`${backBits} = bitcast double ${back} to i64`);
    B.line(`${exact} = icmp eq i64 ${bits}, ${backBits}`);
    B.line(`${ok} = and i1 ${inRange}, ${exact}`);
    if (safe === "true") safe = ok;
    else {
      const both = B.tmp();
      B.line(`${both} = and i1 ${safe}, ${ok}`);
      safe = both;
    }
  }
  return safe;
}
