import type { IrExpr, IrStmt } from "../../ir/ir.js";
import { everyExprChild, everyStmtChild } from "../../ir/traverse.js";
import { f64Lit } from "./common.js";
import type { LlValue, LlvmEmitterContext } from "./expr-context.js";
import { exactInteger, widenInteger } from "./integer-values.js";
import { withinInt32 } from "../../ir/integer-ranges.js";

/** Speculative integer loops.
 *
 * An innermost loop whose number locals are only written by statement-level
 * integer arithmetic (`x = x * 31 + n`, `x += y % m`, `x++`) runs as two
 * copies. The fast copy keeps those locals in i64 shadow slots holding safe
 * integers and computes the writes with checked integer arithmetic; every
 * write also stores the exact double, so the ordinary slot is always current
 * and loop exits, calls and jumps need no write-back. A check that fails
 * (overflow past 2^53 - 1, a result of -0, a fractional or non-finite leaf, a
 * zero divisor) branches to the same statement in the ordinary double copy,
 * which re-executes it and finishes the loop there. Re-execution is exact
 * because a speculated statement evaluates nothing but locals, literals and
 * arithmetic before it writes.
 *
 * The loop is entered through the fast copy only when every speculated local
 * that is live on entry already holds a safe integer other than -0. */
export interface SpeculativeLoopPlan {
  /** Speculated locals; `true` when the entry value is live and checked. */
  locals: Map<string, boolean>;
  /** Statement-level writes computed as integers in the fast copy. */
  writes: Set<IrStmt>;
  /** Nothing in the loop can observe a module global or leave it other
   * than through its condition, `break` or a failed check: no calls, no
   * throwing operations, no labeled jumps and no `return`. */
  observerFree: boolean;
}

type SpeculativeLoop = Extract<IrStmt, { kind: "for" | "while" | "doWhile" }>;

/** The fast copy duplicates the loop; keep the duplicated code small. */
const MAX_LOOP_NODES = 400;

/** Statements whose emission is plain control flow or a single write.
 * Nested loops, switches and try statements keep the loop on the ordinary
 * path (their emission keeps state that the two copies would not share). */
const SIMPLE_STATEMENTS = new Set<string>([
  "varDecl",
  "assign",
  "exprStmt",
  "if",
  "block",
  "arraySet",
  "bytesSet",
  "fieldSet",
  "recordSet",
  "break",
  "continue",
  "return",
]);

/** Statements and expressions that run no other code and cannot throw. */
const OBSERVER_FREE_STATEMENTS = new Set<string>([
  "varDecl",
  "assign",
  "exprStmt",
  "if",
  "block",
  "break",
  "continue",
]);
const OBSERVER_FREE_EXPRESSIONS = new Set<string>([
  "numLit",
  "boolLit",
  "varRef",
  "bin",
  "unary",
  "incDec",
  "assignExpr",
  "toBool",
  "logical",
  "ternary",
]);

/** Operators whose double form costs conversions or long latency, and that
 * take an integer operand directly. */
const CONSUMING_OPS = new Set<string>([
  "*",
  "/",
  "%",
  "**",
  "&",
  "|",
  "^",
  "<<",
  ">>",
  ">>>",
  "<",
  "<=",
  ">",
  ">=",
  "===",
  "!==",
]);

const INTEGER_OPS = new Set<string>(["+", "-", "*", "%", "&", "|", "^", "<<", ">>", ">>>"]);
const ARITHMETIC_OPS = new Set<string>(["+", "-", "*", "%"]);

/** A number expression that reads only locals and literals through integer
 * operators: evaluating it has no effects, so a failed check may restart its
 * statement. Division and exponentiation usually leave the integers and
 * would only bail. */
export function isSpeculableValue(e: IrExpr, reads = true): boolean {
  if (e.type.kind !== "f64") return false;
  switch (e.kind) {
    case "numLit":
      return Number.isSafeInteger(e.value) && !Object.is(e.value, -0);
    case "varRef":
      return true;
    case "bin": {
      if (!INTEGER_OPS.has(e.op)) return false;
      // Bitwise operators evaluate through the ordinary emitter, which
      // must not read the heap after a check (see speculativeReads).
      const inner = reads && ARITHMETIC_OPS.has(e.op);
      return isSpeculableValue(e.left, inner) && isSpeculableValue(e.right, inner);
    }
    case "unary":
      return (e.op === "-" || e.op === "~") && isSpeculableValue(e.operand, reads && e.op === "-");
    default:
      return reads && isSpeculativeRead(e);
  }
}

/** A number read from a string, an array, a record or an object field that
 * has no effect: it may throw (a missing element), but it changes nothing,
 * so a failed check may restart its statement. Its value carries no range,
 * so it is checked like any other unproven integer. */
export function isSpeculativeRead(e: IrExpr): boolean {
  if (e.type.kind !== "f64") return false;
  switch (e.kind) {
    case "strIntrinsic":
      return (
        e.method === "charCodeAt" &&
        isEffectFree(e.receiver) &&
        e.args.length === 1 &&
        isEffectFree(e.args[0]!)
      );
    case "arrayGet":
      return isEffectFree(e.arr) && isEffectFree(e.index);
    case "recordGet":
    case "fieldGet":
      return isEffectFree(e.obj);
    default:
      return false;
  }
}

/** Receivers and indexes of speculative reads: locals, literals, number
 * arithmetic and nested reads. */
function isEffectFree(e: IrExpr): boolean {
  switch (e.kind) {
    case "numLit":
    case "varRef":
      return true;
    case "bin":
      return e.left.type.kind === "f64" && isEffectFree(e.left) && isEffectFree(e.right);
    case "arrayGet":
      return isEffectFree(e.arr) && isEffectFree(e.index);
    case "recordGet":
    case "fieldGet":
      return isEffectFree(e.obj);
    default:
      return false;
  }
}

/** The speculative reads of a speculable value in evaluation order. */
export function speculativeReads(e: IrExpr, out: IrExpr[] = []): IrExpr[] {
  if (e.kind === "bin" && ARITHMETIC_OPS.has(e.op)) {
    speculativeReads(e.left, out);
    speculativeReads(e.right, out);
  } else if (e.kind === "unary" && e.op === "-") speculativeReads(e.operand, out);
  else if (isSpeculativeRead(e)) out.push(e);
  return out;
}

/** `x = x + y` or `x = x - y` with a step that is not a literal, as in a
 * sieve's `j += i`: the double copy pays a conversion of every index and
 * the step's own latency, while counters stepping by a literal usually
 * have a static proof or too little work to repay a second copy. */
function isVariableStep(localId: string, e: IrExpr): boolean {
  if (e.kind !== "bin" || (e.op !== "+" && e.op !== "-")) return false;
  const self = (x: IrExpr): boolean => x.kind === "varRef" && x.localId === localId;
  const step = self(e.left) ? e.right : e.op === "+" && self(e.right) ? e.left : null;
  return step !== null && step.kind !== "numLit";
}

function hasProduct(e: IrExpr): boolean {
  if (e.kind === "bin")
    return e.op === "*" || e.op === "%" || hasProduct(e.left) || hasProduct(e.right);
  if (e.kind === "unary") return hasProduct(e.operand);
  return false;
}

function hasArithmetic(e: IrExpr): boolean {
  if (e.kind === "bin")
    return ARITHMETIC_OPS.has(e.op) || hasArithmetic(e.left) || hasArithmetic(e.right);
  if (e.kind === "unary") return e.op === "-" || hasArithmetic(e.operand);
  return false;
}

/** The written local and value of a statement-level write, or null. A
 * value of null with a local means `x++`/`x--`. */
export function speculativeWriteTarget(
  s: IrStmt,
): { localId: string; value: IrExpr | null; op: "+" | "-" } | null {
  switch (s.kind) {
    case "assign":
      return { localId: s.localId, value: s.value, op: "+" };
    case "varDecl":
      return s.init ? { localId: s.localId, value: s.init, op: "+" } : null;
    case "exprStmt":
      if (s.expr.kind === "incDec") return { localId: s.expr.localId, value: null, op: s.expr.op };
      if (s.expr.kind === "assignExpr")
        return { localId: s.expr.localId, value: s.expr.value, op: "+" };
      return null;
    default:
      return null;
  }
}

/** `eligible` names the locals a shadow may stand for; `integral` those the
 * emitter already holds as integers (counters, int32 locals); `proven` the
 * expressions the static range analysis already proves integral. Static
 * proofs come first: a local whose reads are all proven is never shadowed
 * or checked, and a loop with nothing unproven is never duplicated. */
export function planSpeculativeLoop(
  loop: SpeculativeLoop,
  eligible: (localId: string) => boolean,
  integral: (localId: string) => boolean = () => false,
  proven: (e: IrExpr) => boolean = () => false,
  invariantEligible: (localId: string) => boolean = eligible,
): SpeculativeLoopPlan | null {
  const writes = new Map<string, IrStmt[]>();
  const unspeculable = new Set<string>();
  const reads = new Set<string>();
  // Locals with at least one read the static analysis does not prove.
  const unproven = new Set<string>();
  const declared = new Set<string>();
  let nodes = 0;
  let rejected = false;
  let arithmetic = false;
  let observerFree = true;
  // Locals the loop reads as integers: operands of multiplication,
  // remainder, bitwise operators and comparisons, and indexes. An
  // accumulator only ever added to gains little from an integer shadow
  // (the double add is cheap), so it keeps its double.
  const consumed = new Set<string>();
  const consume = (e: IrExpr): void => {
    if (e.kind === "varRef") consumed.add(e.localId);
  };
  // Operands of multiplication, division and remainder: the operations whose
  // double forms cost the most. A loop whose integers only count and compare
  // gains nothing measurable from a second copy, so it keeps one.
  const multiplied = new Set<string>();
  // A product in the condition alone (`i < Math.floor(n * scale)`) does not
  // make the body's work integer.
  let inCondition = false;

  const expr = (e: IrExpr): boolean => {
    if (rejected) return false;
    nodes++;
    if (!OBSERVER_FREE_EXPRESSIONS.has(e.kind) || (e.kind === "bin" && e.left.type.kind !== "f64"))
      observerFree = false;
    if (e.kind === "varRef") {
      reads.add(e.localId);
      if (!proven(e)) unproven.add(e.localId);
    } else if (e.kind === "assignExpr" || e.kind === "incDec") unspeculable.add(e.localId);
    else if (e.kind === "bin" && CONSUMING_OPS.has(e.op)) {
      consume(e.left);
      consume(e.right);
      if (!inCondition && (e.op === "*" || e.op === "/" || e.op === "%"))
        for (const operand of [e.left, e.right])
          if (operand.kind === "varRef") multiplied.add(operand.localId);
    } else if (e.kind === "arrayGet" || e.kind === "arrayHas" || e.kind === "arrayState")
      consume(e.index);
    else if (e.kind === "bytesIntrinsic" || e.kind === "strIntrinsic") e.args.forEach(consume);
    return everyExprChild(e, expr, nested);
  };
  // Statements inside expressions (sequence expressions) run mid-expression,
  // where no statement can restart: their writes stay unspeculated.
  const nested = (s: IrStmt): boolean => {
    nodes++;
    observerFree = false;
    if (s.kind === "assign" || s.kind === "varDecl") unspeculable.add(s.localId);
    return everyStmtChild(s, expr, nested);
  };
  const stmt = (s: IrStmt): boolean => {
    if (rejected) return false;
    nodes++;
    if (!SIMPLE_STATEMENTS.has(s.kind)) {
      rejected = true;
      return false;
    }
    if (
      !OBSERVER_FREE_STATEMENTS.has(s.kind) ||
      ((s.kind === "break" || s.kind === "continue") && s.label !== undefined)
    )
      observerFree = false;
    if (s.kind === "varDecl") declared.add(s.localId);
    if (s.kind === "arraySet" || s.kind === "bytesSet") consume(s.index);
    const target = speculativeWriteTarget(s);
    if (target) {
      if (target.value === null || isSpeculableValue(target.value)) {
        const list = writes.get(target.localId) ?? [];
        list.push(s);
        writes.set(target.localId, list);
        if (target.value === null) {
          reads.add(target.localId);
          if (s.kind !== "exprStmt" || !proven(s.expr)) unproven.add(target.localId);
        } else expr(target.value);
        return !rejected;
      }
      unspeculable.add(target.localId);
      if (target.value) expr(target.value);
      return !rejected;
    }
    return everyStmtChild(s, expr, stmt);
  };

  if (loop.cond) {
    inCondition = true;
    expr(loop.cond);
    inCondition = false;
  }
  if (loop.kind === "for" && loop.update) stmt(loop.update);
  for (const s of loop.body) stmt(s);
  if (rejected || nodes > MAX_LOOP_NODES) return null;

  const locals = new Map<string, boolean>();
  for (const id of writes.keys())
    if (!unspeculable.has(id) && consumed.has(id) && unproven.has(id) && eligible(id))
      locals.set(id, !declared.has(id));
  // Every local a speculated write reads must be an integer whenever the
  // write runs: speculated itself, already an integer, or loop-invariant
  // (checked on entry). A value computed from doubles the loop writes
  // would only fail its check on every entry.
  const grounded = (e: IrExpr): boolean => {
    if (e.kind === "varRef") {
      const id = e.localId;
      return (
        proven(e) ||
        locals.has(id) ||
        integral(id) ||
        (!writes.has(id) && !unspeculable.has(id) && invariantEligible(id))
      );
    }
    if (isSpeculativeRead(e)) return true;
    return everyExprChild(e, grounded, () => false);
  };
  for (let changed = true; changed;) {
    changed = false;
    for (const id of [...locals.keys()]) {
      for (const s of writes.get(id)!) {
        const target = speculativeWriteTarget(s)!;
        if (target.value !== null && !grounded(target.value)) {
          locals.delete(id);
          changed = true;
          break;
        }
      }
    }
  }
  const speculated = new Set<IrStmt>();
  for (const id of locals.keys()) for (const s of writes.get(id)!) speculated.add(s);
  if (speculated.size === 0) return null;
  // Loop-invariant integer inputs of the writes and the condition join the
  // shadows, so their reads carry integer facts too.
  const invariant = (e: IrExpr): boolean => {
    if (e.kind === "varRef") {
      const id = e.localId;
      if (
        !proven(e) &&
        !locals.has(id) &&
        !writes.has(id) &&
        !unspeculable.has(id) &&
        invariantEligible(id)
      )
        locals.set(id, true);
      return true;
    }
    return everyExprChild(e, invariant, () => true);
  };
  for (const s of speculated) {
    const target = speculativeWriteTarget(s)!;
    if (target.value === null) arithmetic = true;
    else {
      if (hasArithmetic(target.value)) arithmetic = true;
      invariant(target.value);
    }
  }
  if (!arithmetic) return null;
  if (loop.cond) invariant(loop.cond);
  const heavy =
    [...locals.keys()].some((id) => multiplied.has(id)) ||
    [...speculated].some((s) => {
      const target = speculativeWriteTarget(s)!;
      return (
        target.value !== null &&
        (hasProduct(target.value) || isVariableStep(target.localId, target.value))
      );
    });
  if (!heavy) return null;
  return { locals, writes: speculated, observerFree };
}

const SAFE = Number.MAX_SAFE_INTEGER;

/** The range every speculative shadow holds. */
export const SPECULATIVE_RANGE = { min: -SAFE, max: SAFE };

/** Convert a double to i64 and test that it is a safe integer other than
 * -0: the ordered range tests reject NaN and infinities, and the bit
 * patterns of the value and its round trip agree only for integers that are
 * not -0. `freeze` keeps out-of-range conversions from producing poison. */
export function emitSafeIntegerCheck(host: LlvmEmitterContext, value: string): [string, string] {
  const B = host.B;
  const low = B.tmp(),
    high = B.tmp(),
    inRange = B.tmp(),
    raw = B.tmp(),
    integer = B.tmp(),
    back = B.tmp(),
    bits = B.tmp(),
    backBits = B.tmp(),
    exact = B.tmp(),
    ok = B.tmp();
  B.line(`${low} = fcmp oge double ${value}, ${f64Lit(-SAFE)}`);
  B.line(`${high} = fcmp ole double ${value}, ${f64Lit(SAFE)}`);
  B.line(`${inRange} = and i1 ${low}, ${high}`);
  B.line(`${raw} = fptosi double ${value} to i64`);
  B.line(`${integer} = freeze i64 ${raw}`);
  B.line(`${back} = sitofp i64 ${integer} to double`);
  B.line(`${bits} = bitcast double ${value} to i64`);
  B.line(`${backBits} = bitcast double ${back} to i64`);
  B.line(`${exact} = icmp eq i64 ${bits}, ${backBits}`);
  B.line(`${ok} = and i1 ${inRange}, ${exact}`);
  return [integer, ok];
}

/** A condition that is true when an i64 lies outside the safe range. */
function unsafeInteger(host: LlvmEmitterContext, value: string): string {
  const B = host.B;
  const biased = B.tmp(),
    outside = B.tmp();
  B.line(`${biased} = add i64 ${value}, ${SAFE}`);
  B.line(`${outside} = icmp ugt i64 ${biased}, ${2 * SAFE}`);
  return outside;
}

/** A condition that is true when a safe i64 lies outside [low, high]. Every
 * speculative value is within ±(2^53 - 1), so bounds at or past those
 * limits need no test, and the remaining bounds are exact integers. */
function outsideRange(host: LlvmEmitterContext, value: string, low: number, high: number): string {
  const B = host.B;
  let outside = "false";
  if (low > -SAFE) {
    outside = B.tmp();
    B.line(`${outside} = icmp slt i64 ${value}, ${low}`);
  }
  if (high < SAFE) {
    const above = B.tmp();
    B.line(`${above} = icmp sgt i64 ${value}, ${high}`);
    outside = outside === "false" ? above : either(host, outside, above);
  }
  return outside;
}

/** A literal's value or the range analysis' proof for an expression whose
 * range lies well inside the safe integers. */
function staticRange(
  host: LlvmEmitterContext,
  e: IrExpr,
): { min: number; max: number } | undefined {
  const range = e.kind === "numLit" ? { min: e.value, max: e.value } : host.integerRanges.get(e);
  if (!range) return undefined;
  const limit = 2 ** 52;
  return range.min >= -limit && range.max <= limit ? range : undefined;
}

function either(host: LlvmEmitterContext, a: string, b: string): string {
  const t = host.B.tmp();
  host.B.line(`${t} = or i1 ${a}, ${b}`);
  return t;
}

/** Evaluate a speculable value (isSpeculableValue) as a safe i64. `bail`
 * branches away when its condition holds, so the integer result equals the
 * JS number exactly whenever control continues: sums and products stay
 * within 2^53 - 1, no result is -0, and `%` never divides by zero. Other
 * operators evaluate through the ordinary emitter and must yield a safe
 * integer. */
export function emitSpeculativeInteger(
  host: LlvmEmitterContext,
  e: IrExpr,
  bail: (condition: string) => void,
  reads: ReadonlyMap<IrExpr, LlValue> = new Map(),
): string {
  const B = host.B;
  // A value the range analysis already proves takes the ordinary integer
  // emission, which needs no checks.
  const proven = e.kind === "bin" ? host.integerRanges.get(e) : undefined;
  if (proven && proven.min >= -SAFE && proven.max <= SAFE && speculativeReads(e).length === 0)
    return speculativeLeaf(host, host.emitExpr(e), e, bail);
  switch (e.kind) {
    case "numLit":
      return String(e.value);
    case "varRef": {
      const slot = host.integerLoopBindings.get(e.localId);
      if (slot !== undefined) {
        const value = B.tmp();
        B.line(`${value} = load ${slot.type}, ptr ${slot.slot}`);
        if (slot.type === "i64") return value;
        const wide = B.tmp();
        B.line(`${wide} = ${slot.signed ? "sext" : "zext"} i32 ${value} to i64`);
        return wide;
      }
      const int32 = host.int32Locals.get(e.localId);
      if (int32 !== undefined) {
        const bits = B.tmp(),
          wide = B.tmp();
        B.line(`${bits} = load i32, ptr ${host.binding(e.localId).slot}`);
        B.line(`${wide} = ${int32.signed ? "sext" : "zext"} i32 ${bits} to i64`);
        return wide;
      }
      break;
    }
    case "bin": {
      if (e.op !== "+" && e.op !== "-" && e.op !== "*" && e.op !== "%") break;
      const a = emitSpeculativeInteger(host, e.left, bail, reads);
      const b = emitSpeculativeInteger(host, e.right, bail, reads);
      const result = B.tmp();
      if (e.op === "+" || e.op === "-") {
        // With one operand's range known, the other is checked against the
        // narrowed bounds before the operation: the check then depends on
        // no new value, and LLVM keeps the operation itself simple.
        const right = staticRange(host, e.right);
        const left = e.op === "+" ? staticRange(host, e.left) : undefined;
        if (right) {
          // a + b with b in [lo, hi] is safe iff a in [-SAFE - lo, SAFE - hi];
          // a - b iff a in [-SAFE + hi, SAFE + lo].
          const low = e.op === "+" ? -SAFE - right.min : -SAFE + right.max;
          const high = e.op === "+" ? SAFE - right.max : SAFE + right.min;
          bail(outsideRange(host, a, low, high));
        } else if (left) bail(outsideRange(host, b, -SAFE - left.min, SAFE - left.max));
        // Safe operands cannot overflow i64; an exact zero sum is +0.
        B.line(`${result} = ${e.op === "+" ? "add" : "sub"} nsw i64 ${a}, ${b}`);
        if (!right && !left) bail(unsafeInteger(host, result));
        return result;
      }
      if (e.op === "*") {
        host.declare("declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)");
        const pair = B.tmp(),
          overflow = B.tmp(),
          zero = B.tmp(),
          signs = B.tmp(),
          negative = B.tmp(),
          negativeZero = B.tmp();
        B.line(`${pair} = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 ${a}, i64 ${b})`);
        B.line(`${result} = extractvalue { i64, i1 } ${pair}, 0`);
        B.line(`${overflow} = extractvalue { i64, i1 } ${pair}, 1`);
        // A zero product with a negative factor is -0.
        B.line(`${zero} = icmp eq i64 ${result}, 0`);
        B.line(`${signs} = or i64 ${a}, ${b}`);
        B.line(`${negative} = icmp slt i64 ${signs}, 0`);
        B.line(`${negativeZero} = and i1 ${zero}, ${negative}`);
        bail(either(host, either(host, overflow, unsafeInteger(host, result)), negativeZero));
        return result;
      }
      // `%`: a zero divisor yields NaN, and a zero remainder of a negative
      // dividend is -0. Safe operands cannot hit INT64_MIN % -1.
      const zeroDivisor = B.tmp();
      B.line(`${zeroDivisor} = icmp eq i64 ${b}, 0`);
      bail(zeroDivisor);
      const zero = B.tmp(),
        negative = B.tmp(),
        negativeZero = B.tmp();
      B.line(`${result} = srem i64 ${a}, ${b}`);
      B.line(`${zero} = icmp eq i64 ${result}, 0`);
      B.line(`${negative} = icmp slt i64 ${a}, 0`);
      B.line(`${negativeZero} = and i1 ${zero}, ${negative}`);
      bail(negativeZero);
      return result;
    }
    case "unary": {
      if (e.op !== "-") break;
      const a = emitSpeculativeInteger(host, e.operand, bail, reads);
      const zero = B.tmp(),
        result = B.tmp();
      // -0 is not an integer result.
      B.line(`${zero} = icmp eq i64 ${a}, 0`);
      bail(zero);
      B.line(`${result} = sub nsw i64 0, ${a}`);
      return result;
    }
    default:
      break;
  }
  return speculativeLeaf(host, reads.get(e) ?? host.emitExpr(e), e, bail);
}

/** The safe i64 of an evaluated number: its proven integer, or a checked
 * conversion. */
function speculativeLeaf(
  host: LlvmEmitterContext,
  value: LlValue,
  e: IrExpr,
  bail: (condition: string) => void,
): string {
  const integer = exactInteger(host, value, e);
  if (integer && integer.type === "i64" && withinInt32(integer.range)) {
    // Only the low half is used, as by a double conversion of an int32:
    // LLVM then narrows the operation that produced it (a 64-bit remainder
    // by a constant costs a wide multiply).
    const narrow = host.B.tmp(),
      wide = host.B.tmp();
    host.B.line(`${narrow} = trunc i64 ${integer.name} to i32`);
    host.B.line(`${wide} = sext i32 ${narrow} to i64`);
    return wide;
  }
  if (integer && integer.range.min >= -SAFE && integer.range.max <= SAFE)
    return widenInteger(host, integer);
  const [wide, ok] = emitSafeIntegerCheck(host, value.name);
  const fail = host.B.tmp();
  host.B.line(`${fail} = xor i1 ${ok}, true`);
  bail(fail);
  return wide;
}
