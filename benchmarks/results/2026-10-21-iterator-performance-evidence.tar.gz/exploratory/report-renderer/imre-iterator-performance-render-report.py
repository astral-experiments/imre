"""Render a report only from completed, independently audited final evidence.

No builds, engines, measurements, profiles, or API writes run here. Output paths
and the eventual implementation PR are explicit; absent final data is an error,
not a placeholder result. A separate render record binds every consumed input.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shlex
import statistics
import sys

ENGINES = ('imre', 'rust', 'cpython')
SCENARIOS = ('report-mixed', 'alert-quiet', 'within-quiet', 'latest-quiet')
PILOT_NUMBERS = ('003', '005', '006', '007', '008', '009', '010')
GUARDS = {}


def require(value, message):
    if not value:
        raise ValueError(message)


def guard(path, expected=None):
    path = Path(path).resolve(strict=True)
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    require(expected is None or value == expected, 'unexpected input hash: ' + str(path))
    require(GUARDS.setdefault(str(path), value) == value, 'input changed: ' + str(path))
    return value


def load(path, expected=None):
    guard(path, expected)
    return json.loads(Path(path).read_text())


def ms(seconds):
    return f'{seconds * 1000:.3f}'


def ratio(value):
    return f'{value:.3f}×'


def interval(summary):
    return f"{ms(summary['median_seconds'])} [{ms(summary['p25_seconds'])}, {ms(summary['p75_seconds'])}]"


def main():
    require(sys.flags.optimize == 0, 'run without Python -O')
    self_sha = guard(__file__)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--prefix', required=True, help='Published result filename prefix, without directory/suffix')
    parser.add_argument('--implementation-pr', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--render-record', type=Path, required=True)
    for number in PILOT_NUMBERS:
        parser.add_argument(f'--pilot-{number}-audit', type=Path,
                            default=Path(f'/tmp/imre-telemetry-candidate-{number}-audit.json'))
    parser.add_argument('--branch-audit', type=Path, default=Path('/tmp/imre-telemetry-candidate-005-branch-audit.json'))
    parser.add_argument('--rename-closure', type=Path, default=Path('/tmp/imre-rename-public-closure.json'))
    parser.add_argument('--inspiration', type=Path, default=Path('/tmp/imre-compiler-inspiration/sources.json'))
    parser.add_argument('--toolchain-setup', type=Path, default=Path('/tmp/imre-pinned-ohm-setup.json'))
    parser.add_argument('--relocation-audit', type=Path, default=Path('/tmp/imre-telemetry-candidate-006-relocation-audit.json'))
    parser.add_argument('--aborted-pilot-status', type=Path, default=Path('/tmp/imre-telemetry-candidate-006-pinned/pilot-status.json'))
    args = parser.parse_args()
    require(re.fullmatch(r'[a-z0-9][a-z0-9-]+', args.prefix), 'unsafe published prefix')
    require(re.fullmatch(r'https://github.com/viarius-experiments/imre/pull/[1-9][0-9]*', args.implementation_pr), 'use the actual canonical implementation PR')
    require(not args.output.exists() and not args.render_record.exists(), 'preserve earlier reports')
    prefix = args.prefix
    audit = load(args.audit)
    require(audit['kind'] == 'telemetry-final-evidence-audit' and audit['status'] == 'passed'
            and audit['input_guards_passed'] and audit['validation_full_matrix_passed'] is True
            and audit['exploratory'] is False, 'completed independent final audit required')
    guard(audit['audit_script'], audit['audit_script_sha256'])
    revision = audit['revision']
    plan = load(audit['plan']['path'], audit['plan']['sha256'])
    require(plan['revision'] == revision and plan['validation_full_matrix_passed'] is True, 'final plan mismatch')
    index = load(audit['validation']['index'], audit['validation']['index_sha256'])
    validation = load(audit['validation']['audit'], audit['validation']['audit_sha256'])
    require(validation['counts'] == audit['validation']['counts'] and validation['validation_revision'] == revision
            and index['revision'] == revision and index['status'] == 'passed', 'validation identity mismatch')
    records, rows, baselines = {}, {}, {}
    for phase in ('full', 'early'):
        for mode in ('normal', 'thinlto'):
            key = phase + '-' + mode
            binding = audit['records'][key]
            record = load(binding['record'], binding['record_sha256'])
            require(record['revision'] == revision and record['samples'] == 12 and record['warmups'] == 8, 'schedule/revision mismatch')
            records[key] = record
            rows[key] = {row['label']: row for row in record['workloads']}
            require(len(rows[key]) == (12 if phase == 'full' else 9), 'incomplete workload matrix')
            for row in [record['startup_control'], *record['workloads']]:
                audited = binding['ratios_and_medians'][row['label']]
                require(row['summary'] == audited['summary'] and row['imre_over_rust'] == audited['imre_over_rust']
                        and row['cpython_over_imre'] == audited['cpython_over_imre'], 'audited timing summary mismatch')
                for engine in ENGINES:
                    samples = [sample[engine]['elapsed_ns'] / 1e9 for sample in row['samples']]
                    quartiles = statistics.quantiles(samples, n=4, method='inclusive')
                    require(statistics.median(samples) == row['summary'][engine]['median_seconds']
                            and quartiles[0] == row['summary'][engine]['p25_seconds']
                            and quartiles[2] == row['summary'][engine]['p75_seconds'], 'raw timing distribution mismatch')
            name = 'baseline:' + key
            baselines[key] = load(plan['protected_paths'][name], plan['protected_sha256'][name])
    machine = records['full-thinlto']
    require(machine['python']['gil_enabled'] and not machine['python']['jit_enabled']
            and machine['python']['pgo']['profile_use_flag_present'] and machine['python']['lto']['lto_flag_present'], 'Python build description mismatch')
    require(all(record['cpu']['model'] == machine['cpu']['model'] and record['python'] == machine['python']
                and record['compiler_version'] == machine['compiler_version'] and record['clang_version'] == machine['clang_version']
                for record in records.values()), 'cross-record machine/tool metadata mismatch')
    target = {scenario + '-4096': rows['full-thinlto'][scenario + '-4096']['imre_over_rust'] for scenario in SCENARIOS}
    require(target == audit['performance_target']['individual_imre_over_rust'], 'performance target mismatch')
    met = all(value < 2 for value in target.values())
    require(met == audit['performance_target']['all_four_below_two'], 'performance goal verdict mismatch')
    final_profile = audit['profile']
    summary = load(Path(final_profile['directory']) / 'summary.json', final_profile['summary_sha256'])
    require(summary['status'] == 'passed' and summary['complete'] and summary['exploratory'] is False, 'final profile mismatch')
    pilots = {}
    for number in PILOT_NUMBERS:
        path = getattr(args, f'pilot_{number}_audit')
        value = load(path)
        require(value['status'] == 'passed' and value['exploratory'] is True
                and value['pilot_audit']['status'] == 'passed'
                and value['pilot_audit']['raw_process_records_verified'] == 120
                and value['profiles_verified'] == 6 and value['raw_profile_counts_independently_reparsed'], 'incomplete exploratory audit')
        pilots[number] = value
    branch = load(args.branch_audit)
    require(branch['status'] == 'passed' and branch['exploratory'] is True
            and branch['source_audit_sha256'] == guard(args.pilot_005_audit)
            and branch['source_profile_sha256'] == pilots['005']['profile_summary_sha256'], 'exploratory branch evidence mismatch')
    closure = load(args.rename_closure)
    require(closure['status'] == 'passed' and closure['kind'] == 'public-imre-rename-closure', 'rename closure incomplete')
    setup = load(args.toolchain_setup)
    relocation = load(args.relocation_audit)
    aborted = load(args.aborted_pilot_status)
    require(relocation['status'] == 'passed' and relocation['exploratory'] is True
            and relocation['exact_plan_transform_verified'] and len(relocation['tools']) == 5,
            'tool relocation audit incomplete')
    guard(relocation['audit_script'], relocation['audit_script_sha256'])
    guard(relocation['plan'], relocation['plan_sha256'])
    guard(relocation['original_plan'], relocation['original_plan_sha256'])
    guard(relocation['relocation_record'], relocation['relocation_record_sha256'])
    require(aborted['status'] == 'failed' and aborted['phase'] == 'pilot' and aborted['runs'] == []
            and aborted['plan_sha256'] == relocation['plan_sha256']
            and aborted['revision'] == relocation['revision']
            and 'Stop concurrent build/profile/telemetry processes before timing' in aborted['error'],
            'recorded aborted pilot performed work or has a different cause')
    rustup = index['rustup_home']
    require(index['rustup_home_unchanged'] and index['rustup_home_after'] == rustup
            and rustup['home'] == setup['rustup_home'] and rustup['resolved_toolchain'] == setup['ohm_target']
            and rustup['settings_sha256'] == setup['settings_sha256'], 'task-local toolchain setup differs')
    for tool in relocation['tools']:
        require(index['tools'][tool['key'].removeprefix('build_tool:')] ==
                {'path': tool['retained_path'], 'sha256': tool['sha256']}, 'retained build tool bytes differ')
    sources = load(args.inspiration)
    source_urls = {}
    for entry in sources['sources']:
        require(entry['returncode'] == 0, 'inspiration source retrieval failed')
        guard(entry['local_path'], entry['sha256'])
        source_urls[(entry['project'], entry['path'])] = entry['url']
    scriptc_borrow = source_urls[('scriptc', 'packages/compiler/src/backend/llvm/borrowed-inputs.ts')]
    scriptc_effect = source_urls[('scriptc', 'packages/compiler/src/backend/llvm/reference-effects.ts')]
    scriptc_array = source_urls[('scriptc', 'packages/compiler/src/backend/llvm/dense-array-access.ts')]
    bun_types = source_urls[('bun', 'docs/bundler/aot-types.mdx')]
    bun_loops = source_urls[('webkit', 'Source/JavaScriptCore/b3/B3VersionLoops.cpp')]
    goal_sentence = ('All four cases meet the requested **below 2× Rust** target.' if met else
                     'The requested **below 2× Rust in every case** target is not met; the misses remain visible below.')
    lines = [
        '# Iterator performance against Rust', '',
        f'The unchanged [telemetry comparator](../../examples/telemetry_comparison/README.md) now takes **{min(target.values()):.3f}–{max(target.values()):.3f}× Rust\'s time** across the four 4,096-record full-scan ThinLTO cases. {goal_sentence} These are complete-program median comparisons on one shared host.', '',
        '| Full scan, 4,096 records | Imre ms [p25, p75] | Rust ms [p25, p75] | CPython / Imre | Imre / Rust | <2× |',
        '|---|---:|---:|---:|---:|:---:|',
    ]
    for scenario in SCENARIOS:
        row = rows['full-thinlto'][scenario + '-4096']
        lines.append(f"| `{scenario}` | {interval(row['summary']['imre'])} | {interval(row['summary']['rust'])} | {ratio(row['cpython_over_imre'])} | {ratio(row['imre_over_rust'])} | {'yes' if row['imre_over_rust'] < 2 else 'no'} |")
    lines += ['', f'The [implementation PR]({args.implementation_pr}) continues native Stack 4. The measured compiler/runtime revision is [`{revision}`](https://github.com/viarius-experiments/imre/commit/{revision}); the Python example and independent Rust reference are unchanged from the [previous comparison](2026-10-20-iterator-pipelines.md).', '',
        '## What changed', '',
        'The compiler carries integer-range facts through supported control flow, borrows scalar inputs and immutable reads while their owners remain rooted, and reuses list lengths and backing-buffer pointers only when effect analysis proves the source cannot change during iteration. Exact sequence types and cursor bounds justify narrower getters. Exact integer owners avoid nullable-object cleanup checks; heap-integer ownership paths stay in cold helpers.', '',
        'Recognized pure same-local integer absolute-value conditionals lower through a select with a checked overflow boundary. Small-integer fast paths expose their representation facts to LLVM after the overflow guard. For bounded pure integer functions used directly in comparisons, the compiler can guard the incoming tags once and keep the arithmetic unboxed through the final boolean. Interval proofs reject any intermediate that could overflow signed 64-bit arithmetic; the original arbitrary-precision call remains the fallback. Arguments are evaluated once in Python order, and the unboxed intermediate never escapes as a Python integer.', '',
        'These transformations preserve the checked fallback: arbitrary-precision integers, overflow behavior, left-to-right evaluation, exceptions, mutation through aliases, ownership, lazy iterator pulls, strict-zip exhaustion, and early exits. Unknown or potentially invalidating effects keep ordinary checked/owned operations. The workload has no benchmark-specific compiler entry point.', '',
        f'The useful design ideas from scriptc are [borrowed arguments]({scriptc_borrow}), explicit [reference effects]({scriptc_effect}), and [guarded dense array access]({scriptc_array}). Imre adapts those concepts to its own Python semantics and Rust runtime; no upstream implementation was copied.', '',
        f'We also inspected Bun\'s experimental [native-AOT draft PR 45631](https://github.com/oven-sh/bun/pull/45631), specifically its pinned [typed boundary design]({bun_types}) and JavaScriptCore [B3 loop versioning]({bun_loops}). That prototype targets JSC/B3. Released Bun [`--compile`](https://bun.com/docs/bundler/executables) packages code with the Bun runtime, and `--bytecode` moves parsing work to build time; neither is evidence that this Python workload was benchmarked against Bun or scriptc.', '',
        '## Workload and timing protocol', '',
        'Each process parses aligned timestamp/value files, validates complete alignment with strict zip once, then repeats queries. `report-mixed` performs signed, absolute and squared-error reductions, two threshold predicates, and a reverse search. Quiet cases inspect all records; early/recent cases stop after one pair. Full alignment is checked before those early exits. All engines render the final result once and produce a repetition checksum.', '',
        'Rust uses contiguous native records, checked `i128` arithmetic, and a `BigInt` fallback. Imre uses the typed Python object/container layout and arbitrary-precision integer runtime. Both preserve the same accepted input, errors and output/filesystem effects. Rust applies `black_box` to each repeated query and result. This is a comparison of those concrete implementations, not a universal language ranking.', '',
        'Canonical sizes are 16, 256 and 4,096 records per file, generated in that order. Full scans target 8,388,608 source-level inspected pairs per process; early exits target 2,097,152, rounded down to whole queries. Every condition has a complete correctness gate, eight warmup rounds and twelve measured rounds. All six engine permutations occur twice among measured rounds; warmups and cross-round transitions are not fully balanced. CPU affinity is fixed to CPU 0, timing runs outside ptrace, and build/profile processes are excluded by the recorded coactivity guards.', '',
        f"The host reports `{machine['cpu']['model']}` on `{machine['platform']}`. CPython is {machine['python']['version_number']} (PGO/LTO build, GIL enabled, JIT disabled); native compilation uses `{machine['clang_version'].splitlines()[0]}` and `{machine['preparation']['rust_build_record']['rustc_verbose'].splitlines()[0]}`. Exact binaries and target triples are hash-bound in each record.", '',
        'Values below are median milliseconds. CPython / Imre is a speedup; Imre / Rust is a time ratio. Raw samples and inclusive quartiles are retained. Ordinary and ThinLTO have independent interleaved baselines, with matching native linking modes and ThinLTO import/inline budgets of 1,000; differences between those batches do not isolate linking alone.', '',
    ]
    for mode, title in (('normal', 'Ordinary linking'), ('thinlto', 'ThinLTO')):
        lines += [f'### {title}', '', '| Workload / records | Imre ms | Rust ms | CPython ms | CPython / Imre | Imre / Rust |', '|---|---:|---:|---:|---:|---:|']
        for phase in ('full', 'early'):
            for row in records[phase + '-' + mode]['workloads']:
                values = row['summary']
                lines.append(f"| `{row['scenario']}` / {row['records']:,} | {ms(values['imre']['median_seconds'])} | {ms(values['rust']['median_seconds'])} | {ms(values['cpython']['median_seconds'])} | {ratio(row['cpython_over_imre'])} | {ratio(row['imre_over_rust'])} |")
        lines.append('')
    lines += ['### Empty controls', '', '| Batch / linking | Imre ms | Rust ms | CPython ms | Largest Imre control/workload fraction |', '|---|---:|---:|---:|---:|']
    for key, record in records.items():
        values = record['startup_control']['summary']
        maximum = audit['records'][key]['max_control_fractions']['imre']
        lines.append(f"| {key} | {ms(values['imre']['median_seconds'])} | {ms(values['rust']['median_seconds'])} | {ms(values['cpython']['median_seconds'])} | {maximum:.2%} |")
    fractions = audit['maximum_control_fractions']
    lines += ['', f"Across all conditions, maximum empty-control/workload fractions are {fractions['imre']:.2%} for Imre, {fractions['rust']:.2%} for Rust, and {fractions['cpython']:.2%} for CPython. Controls are not subtracted. Empty inputs omit nonempty parsing/alignment, so this control does not estimate all fixed cost. The ratios include process startup, parsing, alignment, queries and final output; warm caches and no `fsync` apply.", '',
        '## CPU and allocations', '',
        'The six profiles use the exact timed ThinLTO binaries and `alert-quiet-4096`: Callgrind at 128 queries, DHAT at 128 and 256 queries, for both native engines. Profiles run after all wall timing and pass the complete independent output/filesystem oracle. Callgrind counts guest instructions rather than CPU cycles; DHAT counts requested allocation bytes/blocks rather than RSS. Two-point allocation slopes do not prove behavior for other inputs.', '',
        '| Engine | Guest instructions, 128 queries | Allocated bytes, 128 queries | Allocation blocks | Additional bytes / query, 128→256 | Additional blocks / query |',
        '|---|---:|---:|---:|---:|---:|',
    ]
    for engine in ('imre', 'rust'):
        cpu, heap = final_profile['metrics'][engine + '-callgrind-128'], final_profile['metrics'][engine + '-dhat-128']
        growth = final_profile['allocation_growth'][engine]
        lines.append(f"| {engine.title()} | {cpu['instructions']:,} | {heap['allocated_bytes']:,} | {heap['allocated_blocks']:,} | {growth['allocated_bytes']['per_additional_query']:g} | {growth['allocated_blocks']['per_additional_query']:g} |")
    final_instructions = final_profile['metrics']['imre-callgrind-128']['instructions']
    old_instructions = pilots['003']['metrics']['imre-callgrind-128']['instructions']
    middle_instructions = pilots['005']['metrics']['imre-callgrind-128']['instructions']
    lines += ['', f"Whole-process Imre guest instructions changed from {old_instructions:,} in exploratory candidate 003 to {middle_instructions:,} in 005 and {final_instructions:,} in the final build ({(1-final_instructions/old_instructions):+.2%} reduction relative to 003). The final complete-process instruction ratio is {final_profile['whole_process_instruction_ratio_imre_over_rust']:.3f}× Rust. These observations do not assign wall-time savings to individual checks or transformations.", '',
        '## Exploratory trajectory and historical context', '',
        'The exploratory candidates are separate six-sample, one-warmup pilots with four 4,096-record workloads and an empty control. They guided optimization; final acceptance uses the twelve-sample matrix above. Each stage has its own interleaved Rust baseline, so changes across stages are contextual rather than an isolated causal estimate. The retained audits contain both native medians, not only their ratio.', '',
        '| Stage | Report / Rust | Alert / Rust | Within / Rust | Latest / Rust |', '|---|---:|---:|---:|---:|',
    ]
    original_rows = {row['label']: row for row in baselines['full-thinlto']['workloads']}
    trajectory = [('Historical original ThinLTO', [original_rows[scenario + '-4096']['elir_over_rust'] for scenario in SCENARIOS])]
    for number in PILOT_NUMBERS:
        trajectory.append(('Pilot ' + number, [pilots[number]['pilot_audit']['ratios_and_medians'][scenario + '-4096']['imre_over_rust'] for scenario in SCENARIOS]))
    trajectory.append(('Final', [target[scenario + '-4096'] for scenario in SCENARIOS]))
    for stage, values in trajectory:
        lines.append('| ' + stage + ' | ' + ' | '.join(map(ratio, values)) + ' |')
    branch_totals = branch['function_self_totals']
    miss = branch['largest_conditional_miss_site']
    lines += ['', f"The separate candidate-005 branch simulation recorded {branch_totals[1]:,} conditional branches and {branch_totals[2]:,} simulated misses in `fn_7`; {miss['self_events'][2]:,} misses were attributed to the verified `jle` at `{miss['address']}`. This motivated the pure absolute-value transformation. Those are simulated predictor events, not hardware counters, and no final speedup is attributed to them alone. The exploratory probe did not recapture every profiler tool hash at probe time; that limitation remains in its audit.", '',
        'An earlier candidate-006 pilot attempt stopped before timing when the coactivity guard detected another build workload; its run list is empty and it contributes no samples. The completed candidate-006 pilot shown above used a subsequent plan. A separate independent audit verifies that five mutable Ohm tool paths were rebound to retained files with the exact original hashes. Historical records stay unchanged. Final full validation uses a task-local Rustup home pointing to those retained tools; its before/after identity matches the archived setup record. The original tool-identity baseline, relocation audit and aborted status are retained as provenance.', '',
        '## Validation and evidence', '',
        f"The exact frozen implementation passed **{validation['counts']['passed_jobs']} full-validation jobs** with **{validation['counts']['rust_units']['total']} Rust unit tests**. All {validation['counts']['language_suites']} language suites ran under ordinary O0/O3, ThinLTO O3, and ASan/LSan O0/O1. Candidate compiler/runtime builds have fresh-invocation evidence. The benchmark reuses the unchanged, source-bound Rust reference binaries from renamed validation v2. Both exact timed binary pairs passed the full telemetry oracle during preparation, including huge integers, overflow, invalid input, alignment errors, aliases, hard links, output-device failure and complete file effects.", '',
        f"The final audit verified **{audit['executions']['total']:,} process executions**: {audit['executions']['gates']:,} correctness gates, {audit['executions']['warmups']:,} warmups and {audit['executions']['measured']:,} measured executions. Every complete stdout/stderr/status/filesystem result and balanced measured order was checked. Source, helper, tool, build, input and binary hashes are retained; timing and profiling use the same source revision with no post-validation source patch.", '',
        f"The [rename closure]({prefix}-rename-closure.json) separately records preserved repository/Stack identities and all {closure['counts']['successful_ci_heads']} CI-enabled renamed heads passing, with {closure['counts']['heads_without_ci_workflow']} workflow-free heads. That closure covers the pre-performance stack; later PR CI is separate.", '',
        f"Read the [independent final audit]({prefix}-audit.json), [full-validation audit]({prefix}-validation-audit.json), [profile summary]({prefix}-profile.json), and [evidence manifest]({prefix}-evidence-manifest.json). The [deterministic evidence archive]({prefix}-evidence.tar.gz) retains exact Git source, commands, preparation/oracle logs, raw timing outputs, profile data and reproduction helpers. Native binaries, toolchains, build caches, Git administrative data and previous archives are excluded by recorded type/hash/reason; no private rename inventory is published.", '',
        '| Raw complete measurement record | Uncompressed JSON SHA256 |', '|---|---|',
    ]
    for key in records:
        lines.append(f"| [{key}]({prefix}-{key}.json.gz) | `{audit['records'][key]['record_sha256']}` |")
    lines += ['', '### Exact measurement commands', '', 'The commands below describe the retained machine paths. The archive contains the exact sources and helper scripts; reproduction must select equivalent local paths and rerun all identity checks.', '']
    for phase in ('full', 'early'):
        lines += ['```sh', shlex.join([plan['protected_paths']['final_helper_python'], '-I', '-B', plan['protected_paths']['final_helper'], 'measure', '--plan', audit['plan']['path'], '--phase', phase]), '```', '']
    lines += ['The canonical planned engine/preparation argv, tool versions, optimization flags and target triples are preserved in the linked records. CPython/Clang identities and Python/Rust program sources match the historical input baseline; native Rust binaries are pinned to renamed validation v2; this is one machine and workload, not a portable performance guarantee.', '']
    text = '\n'.join(lines)
    require(not re.search(r'(?<![A-Za-z])(?:nan|inf)(?![A-Za-z])', text, re.IGNORECASE) and '[[TODO' not in text, 'invalid report content')
    for path, expected in list(GUARDS.items()):
        guard(path, expected)
    with args.output.open('x') as stream:
        stream.write(text)
    rendering = {'schema': 1, 'kind': 'iterator-performance-report-render', 'status': 'passed',
                 'created_at_utc': datetime.now(timezone.utc).isoformat(), 'revision': revision,
                 'implementation_pr': args.implementation_pr, 'published_prefix': prefix,
                 'report': str(args.output.resolve()), 'report_sha256': guard(args.output),
                 'renderer_sha256': self_sha, 'inputs': GUARDS, 'performance_target': audit['performance_target'],
                 'lines': len(lines), 'all_numbers_derived_from_passed_audits': True,
                 'scope': 'Report rendering only; no engine, build, measurement, profile, or API operation.'}
    with args.render_record.open('x') as stream:
        json.dump(rendering, stream, indent=2); stream.write('\n')
    print(json.dumps({'report': str(args.output), 'sha256': guard(args.output), 'render_record': str(args.render_record), 'target_met': met}))


if __name__ == '__main__':
    main()
