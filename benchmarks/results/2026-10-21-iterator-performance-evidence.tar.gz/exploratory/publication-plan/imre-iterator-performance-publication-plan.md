# Iterator performance publication and evidence plan

Prepared 2026-10-21. This is a plan only: no packaging, builds, measurements, Git writes, or GitHub writes are performed by this document. The two final helpers remain frozen.

## Publication shape

- Repository: `viarius-experiments/imre`, repository ID `1423429334` (`R_kgDOVNfO1g`). Preserve native Stack 4, node `PRS_kwDOVNfO1s4AIoYG`, and every existing entry ID/order.
- Current published top: PR #58, branch `charlie/codex-iterator-benchmarks`, renamed head `1cc6d47b1d21c523e5bcd701f180724b679014e8`.
- Implementation child: current local branch `charlie/codex-iterator-performance`, based on #58. Publish the frozen full-validation commit that the final measurements will use. Its PR is expected to be #59, but use the actual returned number everywhere.
- Evidence child: a new branch directly from that implementation commit, tentatively `charlie/codex-iterator-performance-benchmarks`. Add only the final report, retained evidence/auditors, and an index link. Its PR is expected to be #60; again use the actual returned number.
- Keep both as draft PRs, matching the existing stack. Do not modify historical PR heads, existing stack entries, or private branches. Keep each feature branch's upstream pointing to its parent, not its published remote branch.

## Freeze and acceptance gates

1. Choose one clean final implementation commit after the four-case pilot passes. Pilot evidence remains exploratory; the final performance claim comes from the complete final schedule.
2. Root performs fresh **full** validation at that exact commit using `/tmp/imre-iterator-performance-validation-pinned.py` with the task-local retained-toolchain Rustup home, without `--build-only`. The original runner and all completed records remain unchanged. Independently audit its terminal index, actual job/unit counts, raw command logs, ordinary/ThinLTO/ASan binaries, source-before/source-after snapshots, tool identities, and fresh compiler/runtime invocation evidence. A build-only result cannot satisfy this gate.
3. Prepare both ordinary and ThinLTO telemetry executables with the frozen candidate evidence helper. Audit both exact preparation commands and complete 258-case telemetry oracles (plus the separate output-device failure check), including arbitrary integers, overflow fallback, length/timestamp errors, and complete filesystem effects. Frozen renamed Rust references may be reused only through the existing source/flag/target/binary binding checks.
4. Generate the final measurement plan, then run `full` and `early` only on root's signal, CPU 0 outside ptrace, with builds/profiles/heavy audits stopped. Retain the unchanged Python/Rust programs and canonical size-generation order `[16, 256, 4096]`.
5. Independently audit both timing statuses and all four records before reporting. Each of the four 4,096-record full-scan ThinLTO median Imre/Rust ratios must be **strictly below 2**. Report each result and its distribution; do not average away a miss. Review all ordinary, smaller-size, and early-exit results for regressions. Keep a valid but missed performance target distinct from a failed measurement.
6. After **all** wall timing has stopped, run the frozen final profiler against the completed final `full` status. It accepts both completed ordinary/ThinLTO timing records and full validation, then profiles only the exact timed ThinLTO Imre/Rust binaries. Independently audit all six jobs.
7. Freeze every retained input and helper hash before packaging. Compiler, runtime, benchmark harness, validators, example, and Rust reference must have the same source identities across full validation, preparations, timing, and profiling. This final protocol permits no post-validation source overlay. Any substantive fix requires a new candidate and rerunning dependent evidence.

## Independent audits required before packaging

**Validation audit.** Bind the exact Git revision/tree, tracked source contents, full-validation mode/status, source/tool guards, raw job success and actual counts, compiler/runtime binary hashes, and fresh build evidence. Distinguish fresh candidate builds from source-bound reuse of the frozen Rust references. Confirm the new proof/borrowing fixtures run in ordinary O0/O3, ThinLTO O3, and ASan/LSan O0/O1; preserve integer fallback, mutation, ownership, exceptions, lazy pulls, and strict-zip behavior.

**Raw timing audit.** Check final-plan/candidate-plan/preparation/build/index SHA bindings and exact phase/mode commands. Recompute statistics from every raw sample, inclusive quartiles, CPython/Imre speedups, Imre/Rust ratios, and each individual target result. Verify 12 measured rounds, eight warmups, all six engine orders twice in measured rounds, CPU affinity `[0]`, all canonical inputs/repetitions, complete stdout/stderr/return status/filesystem results, and retained output directories. Recompute the 2,898 process records: 138 correctness gates, 1,104 warmups, and 1,656 measured executions. Verify all four empty controls; report control/workload fractions without subtraction. Eight warmups and cross-round transitions are not fully balanced.

**Profile audit.** Independently parse Callgrind self instruction rows/call edges and DHAT raw allocations; do not trust only the profiler's derived summary. Verify the six exact commands, original `alert-quiet-4096` input bytes, changed repeat counts 128/256, timed binary hashes, full stdout/checksum/filesystem oracle, profile tool hashes, and pre/post input guards. Recompute allocation slopes and retained artifact manifests. Callgrind instruction counts are not cycles or wall-time attribution; DHAT requested bytes/blocks are not RSS, and two-point slopes do not prove linearity.

**Archive/report audit.** Independently enumerate every archive member and exclusion, reject duplicate/traversal names and unexpected special files, recompute hashes/sizes/modes, verify source bytes against the frozen Git commit, and verify all four compressed JSON records decompress to the original measured bytes. Recompute every report table/ratio/count from the archived records. Verify report links, source revision links, exact commands/tool flags, provenance, and the evidence-only diff. Retain auditor source and output beside the report if generated after archive finalization.

Existing `/tmp/imre-telemetry-candidate-audit.py` is explicitly pilot-only (six samples/one warmup) and must not certify final evidence. The previous `/tmp/elir-iterator-package-evidence.py` and archive auditor assume old status schemas, `elir` engine keys, and an allowed harness patch; use separately named final adapters with explicit current bindings. Preserve the old helpers and evidence unchanged. Prefer explicit field/path bindings over accepting a hash merely because it appears somewhere in an audit.

## Evidence contents and exclusions

Use a new prefix, tentatively `benchmarks/results/2026-10-21-iterator-performance`, leaving all historical results intact.

Publish the Markdown report; four raw timing records as deterministic `.json.gz`; both timing statuses; final/candidate plans; preparation/build/full-validation summaries; independent validation/timing/profile audits; profile summary; a deterministic evidence archive and per-member manifest; and the archive/report auditor plus passed audit. Link the report from `benchmarks/README.md` only after numbers are final.

The archive should retain:

- Exact frozen Git source snapshot (all tracked source except the existing `benchmarks/results/` evidence tree), Cargo manifests/locks/toolchain settings, and the independently verified source file manifest.
- Full validation index/build record, raw command stdout/stderr, source-before/source-after snapshots, tool/freshness evidence, relevant regression fixture outputs, and reference build records with embedded unchanged source.
- Both preparations, their exact source/tool/binary identities, emitted LLVM, complete oracle outputs, and materialized canonical inputs/output effects.
- Both final status files, final/candidate plans, all four complete raw records, raw measured process records and retained final filesystem contents.
- All six final Callgrind/DHAT profiles, annotations, stdout/stderr, command records, snapshot/guard manifests, and independent audits.
- Exact reproduction helpers and imported dependencies: candidate evidence helper, final measurement helper, final profiler, pinned pilot metric parser source, validators, independent auditors, report renderer, and packager.
- A small exploratory index with each completed pilot's revision, ratios, source/helper hashes, and audit references, clearly excluded from final acceptance. The report now consumes completed candidate 003, 005, 006, 007, 008, 009 and 010 audits: retain each audit, its raw pilot record/status/plan/preparation and all six profiles/snapshots that the audit binds. Candidate 006's completed evidence is under `/tmp/imre-telemetry-final-candidate-v1`; its earlier aborted attempts remain distinct provenance. Do not nest previous evidence archives or relabel exploratory runs as full validation.

Exclude native executables, object/static libraries, LLVM bitcode, Python bytecode, interpreters/toolchains, build caches, Git administrative data, and prior evidence archives. Record each selected excluded artifact's path/logical role, size, SHA256, and reason; exclusions must explain how measured binaries and tools remain identity-bound. Use byte signatures rather than suffixes, so an ordinary input named `.bin` is not silently excluded. Never collect credentials or environment/config dumps. Guard selected file bytes **and directory membership** before/after packaging; normalize archive order/ownership/modes/timestamps and gzip timestamps.

A lightweight separate rename audit file can record repository/Stack IDs, 260 rewritten commits, 85 local heads/143 refs, 58 published heads, 19 moved worktrees, preserved upstreams, 34 metadata edits, final rename source/evidence/validation audit hashes, and terminal CI results. Use verified counts from the existing audit records, not assumptions. Do not publish the full preflight/config/worktree/private-ref inventory or history bundle. Historical measured SHA strings remain historical; navigational links use the mapped public commits. Include only public identity mappings needed for the report.

The candidate 005 branch simulation is an explicit exploratory extra: retain `/tmp/imre-telemetry-candidate-005-branches`, `/tmp/imre-telemetry-branch-probe.py`, and the separate independent `/tmp/imre-telemetry-branch-audit.py` result/source. The auditor recomputes raw Ir/Bc/Bcm/Bi/Bim self-event totals and the largest fn_7 miss location, checks complete output effects and the exact candidate-005 binary, and records read-only disassembly of the claimed `jle`. It must never import the probe helper because that file executes at module scope. These are simulated predictor events, not hardware counters or final wall-time evidence; the probe did not independently recapture all Valgrind tool hashes at probe time.

## Toolchain relocation and blocked pilot evidence

An external process moved the global `ohm` alias from retained `ohm-1.98.1-1` to `ohm-1.99.0-6`. The original candidate-006 pilot guard stopped before timing. A new plan rebound only the five old tool paths to retained files whose exact hashes match the original build/index; its subsequent pilot also stopped before timing because unrelated Cargo/rustc work was active. Neither attempt contributes measurements. Full validation uses a separate task-local Rustup home; global settings and aliases remain untouched.

Retain these small provenance extras, in addition to the ordinary final-validation tree and its runner/auditor:

- `/tmp/imre-iterator-performance-candidate-006/index.json`, SHA `dcecc02513c26dd12ae869206d14c6e37c7643a328a0c354bfdb510b62ff7f2b`, explicitly build-only and used solely to prove the same five tools and two linkers.
- `/tmp/imre-pinned-ohm-setup.json`, SHA `2c8adb3638b2df5721268fd3030394c80e32c89e70136e9f4caf9af5e08eaef5`; it records the task-local location and hashes, not global configuration contents.
- `/tmp/imre-telemetry-relocate-plan.py`, original/derived candidate-006 plans, exact-content relocation record, `/tmp/imre-telemetry-relocation-audit.py`, and `/tmp/imre-telemetry-candidate-006-relocation-audit.json` (SHA `1b4a17bbfc053e94bc2ec779a6a2559d68ade2a29012dc64d84f0e80fe404f51`).
- Both aborted pilot orchestration records/logs, with empty/no timing samples clearly identified; preserve the original byte identities.
- `/tmp/imre-rename-public-closure.json` and its small derivation helper; do not include the full private rename inventories.
- `/tmp/imre-compiler-inspiration/sources.json` and only the specifically cited primary source files/metadata, keeping exact upstream revisions/hashes and license notices.

The new full-validation auditor binds the original candidate-006 tool identity baseline but does not expand that historical build-only validation scope. The final timing/profile auditor and packager are unchanged; their selected final tool paths now resolve directly to the retained versioned binaries.

## Report content

Lead with the four actual 4,096-record ThinLTO time ratios and whether each met the <2× Rust goal. Explain the concrete final compiler transformations and their proof/fallback boundaries, including unchanged arbitrary-precision semantics. Show ordinary/ThinLTO full/early comparisons and startup controls, then CPU/allocation findings supported by the retained profiles. Compare against the frozen previous measurements with clear before/after source identities, while keeping the new interleaved Rust/CPython results as the primary comparison.

Disclose contiguous native Rust records and checked i128/BigInt fallback versus Imre's typed Python object/container layout, identical query algorithms and repeated-call `black_box`, complete-program timing scope, matched linking modes/optimization flags, original shared-host limitations, warm caches, no fsync, and empty controls excluding nonempty parsing/alignment. Report validation counts from the final index. Historical measurement bytes are never rewritten for display naming.

## Publication procedure (only after root authorizes this stage)

The implementation draft may be published immediately after full validation passes, while final timing proceeds separately, to overlap remote CI. Its body must state that final measurements are pending and avoid final performance claims. The evidence child waits for all final timing/profile/package audits. Publishing the implementation must not change the frozen measured source commit or run local heavy work during timing.

1. Refresh repository identity/account (`charliermarsh` through `gh-auto` in the canonical checkout), real checkout/common Git directory, clean branch/head/upstream, PR #58 head/base/draft state, and fully paginated Stack 4 entry IDs/order. Check no drift from the expected public ancestry.
2. Verify the implementation commit is the frozen fully validated commit selected for final measurements and descends from PR #58's current head. Push only that intended branch with ordinary `git push`, preserving its parent upstream. Open a draft PR with exact base/head refs and a concise problem/result/validation description. Attach its returned URL to the task.
3. Append **only the new PR number** to Stack 4 using `gh-auto api --method POST repos/viarius-experiments/imre/stacks/4/add --input <reviewed-json-file>`, with body `{"pull_requests":[ACTUAL_IMPLEMENTATION_PR]}`. The verified native API appends a delta; do not send the old entries. Re-read REST and paginated GraphQL, requiring the old entry IDs/order as an unchanged prefix and the new PR as the sole tail entry. If a transport error occurs, read state before retrying.
4. Finish the independently audited evidence-only child commit. Verify its diff contains only the planned report/evidence/index files, and archive sources bind the implementation parent. Push only that child branch, open its draft PR against the actual implementation branch, attach its URL, and append only that actual PR number using the same checked stack procedure.
5. Read back both PR title/body/base/head/draft identities and complete Stack 4 order. Confirm the two new entries form the expected parent-child chain, existing PR IDs/numbers/refs/draft states remain unchanged, and both task attachments use canonical Imre URLs.
6. Monitor the new PR CI runs to terminal on their exact published head SHAs, diagnosing failures before claiming completion. The older rename retry `39491300421`, attempt 2, completed successfully; `/tmp/imre-rename-public-closure.json` records the pre-performance 56 successful CI heads and two workflow-free heads. Publish a terminal evidence manifest/hash summary only after all checks and final readback pass.

## Frozen helper identities

| Helper | SHA256 |
|---|---|
| `/tmp/imre-iterator-performance-validation.py` (historical, unchanged) | `0b5b62b5a205e518b8b0853e7f687bf685a1cd517c7cb36ae85f899c63466973` |
| `/tmp/imre-iterator-performance-validation-pinned.py` | `9d9f2c4ecfba77ad6fbab5ccb8b26a0750ba83d623fb28db1c7607a24e69e8c9` |
| `/tmp/imre-iterator-performance-validation-pinned-audit.py` | `bf8a2ea270ecd893cb2a5f140e1ee673004f219dec88b6d4e1931a10a7c8b88e` |
| `/tmp/imre-iterator-performance-validation-010-audit.py` | `523d7e91e56b6e9faa3e7f74c2bb865141512eacbbe833ab781261ba842449fc` |
| `/tmp/imre-telemetry-evidence.py` | `6a203489299e5554b6f19a8c9b877a3a2d8fb45a8c34f9c693b3bb5b85107d01` |
| `/tmp/imre-telemetry-pilot.py` | `e69533dc27f14c6159dcb0d97f7778f633823d4a6cf0aec36a81b1e9b74c0c9d` |
| `/tmp/imre-telemetry-final-evidence.py` | `b8a824bbf58bfb5b97250b0d6110f77973cc7cbf887b086dd310303787dc2862` |
| `/tmp/imre-telemetry-final-profile.py` | `0ac7a494c318de634bb18495c39d19b89f0be31af0c9baa40f1e3635dc988ccf` |
| `/tmp/imre-telemetry-profile.py` (pinned metric parsers) | `61f2e8a59d092473ef1e8557fc40ce0033d9aeb59a5e8eff2cbe00f3ba53fa05` |

These are recorded identities from prior static reviews; rehash them at the final non-timing freeze. No current candidate is designated final by this plan.
