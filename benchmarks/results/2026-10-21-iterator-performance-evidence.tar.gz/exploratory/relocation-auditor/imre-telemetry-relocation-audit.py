"""Independently verify exact-content pilot tool-path relocation; run no workloads."""

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ADAPTER = Path('/tmp/imre-telemetry-relocate-plan.py')
ADAPTER_SHA256 = '6a4025aca7fa4ab21ccb60e1dcca78ebcf51a32a4d29a179a136c76e4cb3a0e4'
HELPER = Path('/tmp/imre-telemetry-evidence.py')
HELPER_SHA256 = '6a203489299e5554b6f19a8c9b877a3a2d8fb45a8c34f9c693b3bb5b85107d01'
NAMES = ('cargo', 'rustc', 'rustfmt', 'cargo-clippy', 'clippy-driver')
OLD = Path('/home/dev-user/.rustup/toolchains/ohm/bin')
RETAINED = Path('/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/bin')
GUARDS = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def guard(path, expected=None):
    path = Path(path).absolute()
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    if expected is not None:
        require(value == expected, 'content differs: ' + str(path))
    require(GUARDS.setdefault(str(path), value) == value, 'content changed: ' + str(path))
    return value


def read(path, expected=None):
    guard(path, expected)
    return json.loads(Path(path).read_text())


def main():
    require(sys.flags.optimize == 0, 'run without Python -O')
    script_sha = guard(__file__)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists() and not args.output.is_symlink(), 'use a new audit output')
    plan_path = args.plan.resolve(strict=True)
    plan = read(plan_path)
    new_output = Path(plan['output']).resolve(strict=True)
    require(plan_path == new_output / 'plan.json', 'derived plan location differs')
    require(not args.output.resolve().is_relative_to(new_output), 'keep the audit outside retained plan artifacts')
    record_path = Path(plan['protected_paths']['relocation:record']).resolve(strict=True)
    require(record_path == new_output / 'tool-path-relocation.json', 'relocation record location differs')
    record = read(record_path, plan['protected_sha256']['relocation:record'])
    require(record == plan['tool_path_relocation'] and record['schema'] == 1
            and record['kind'] == 'exact-content-tool-path-relocation'
            and record['historical_records_modified'] is False and record['tool_bytes_changed'] is False,
            'relocation metadata differs')
    require(datetime.fromisoformat(record['created_at']).tzinfo is not None, 'creation time is not timezone-aware')
    original_path = Path(record['original_plan']).resolve(strict=True)
    original = read(original_path, record['original_plan_sha256'])
    old_output = Path(original['output']).resolve(strict=True)
    require(original_path == old_output / 'plan.json' and record['old_output'] == str(old_output)
            and record['new_output'] == str(new_output), 'plan output ancestry differs')
    require(original['schema'] == 1 and original['status'] == 'planned' and original['input_guards_passed'], 'original plan is incomplete')
    require(original['protected_paths']['helper'] == str(HELPER)
            and original['protected_sha256']['helper'] == HELPER_SHA256, 'original evidence helper differs')
    require(record['adapter'] == str(ADAPTER) and record['adapter_sha256'] == ADAPTER_SHA256, 'adapter identity differs')
    guard(ADAPTER, ADAPTER_SHA256)
    guard(HELPER, HELPER_SHA256)
    require(record['build_record'] == original['protected_paths']['build_record']
            and record['build_record_sha256'] == original['protected_sha256']['build_record']
            and record['validation_index'] == original['protected_paths']['validation_index']
            and record['validation_index_sha256'] == original['protected_sha256']['validation_index'], 'original build/index binding differs')
    build = read(record['build_record'], record['build_record_sha256'])
    index = read(record['validation_index'], record['validation_index_sha256'])
    require(original['revision'] == plan['revision'] == record['revision'] == build['revision'] == index['revision'], 'source revision differs')
    require(index['status'] == 'passed' and index['input_guards_passed'] and index['source_unchanged']
            and build['input_guards_passed'] and build['source_matches_revision']
            and index['build_record']['sha256'] == record['build_record_sha256'], 'original build/validation proof differs')
    expected = copy.deepcopy(original)
    tools = {}
    for name in NAMES:
        key = 'build_tool:ohm-' + name
        previous = str(OLD / name)
        retained = RETAINED / name
        identity = original['protected_sha256'][key]
        require(original['protected_paths'][key] == previous, 'unexpected source tool path')
        require(build['tools']['ohm-' + name] == index['tools']['ohm-' + name]
                == {'path': previous, 'sha256': identity}, 'original tool identity differs')
        require(retained.resolve(strict=True) == retained, 'retained tool path is mutable through a symlink')
        guard(retained, identity)
        expected['protected_paths'][key] = str(retained)
        tools[key] = {'key': key, 'original_path': previous, 'retained_path': str(retained), 'sha256': identity}
    require(len(record['tools']) == len(NAMES) and {row['key']: row for row in record['tools']} == tools, 'five exact tool substitutions differ')
    changes = []
    for phase, commands in [('prepare', expected['commands']['prepare']), ('pilot', {'thinlto': expected['commands']['pilot']})]:
        for mode, command in commands.items():
            flags = ('--artifact-dir', '--output') if phase == 'prepare' else ('--artifact-dir', '--output', '--prepared-record')
            for flag in flags:
                require(command.count(flag) == 1, 'command path option is ambiguous')
                position = command.index(flag) + 1
                before = Path(command[position])
                require(before.is_relative_to(old_output), 'original command output escaped original directory')
                after = new_output / before.relative_to(old_output)
                command[position] = str(after)
                changes.append({'phase': phase, 'mode': mode, 'flag': flag, 'before': str(before), 'after': str(after)})
    canonical_changes = lambda rows: sorted(json.dumps(row, sort_keys=True) for row in rows)
    require(len(changes) == len(record['command_path_changes']) == 7
            and canonical_changes(changes) == canonical_changes(record['command_path_changes']), 'seven exact command path substitutions differ')
    expected.update(created_at=record['created_at'], output=str(new_output), tool_path_relocation=record)
    for name, path in {'relocation:original_plan': original_path, 'relocation:adapter': ADAPTER, 'relocation:record': record_path}.items():
        require(name not in original['protected_paths'] and name not in original['protected_sha256'], 'relocation key already existed')
        expected['protected_paths'][name] = str(path)
        expected['protected_sha256'][name] = guard(path)
    require(plan == expected, 'derived plan has an unauthorized extra change')
    for path, identity in list(GUARDS.items()):
        guard(path, identity)
    require(guard(__file__) == script_sha, 'auditor changed')
    report = {
        'schema': 1, 'kind': 'exact-content-tool-path-relocation-audit', 'status': 'passed',
        'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'revision': plan['revision'],
        'exploratory': True, 'plan': str(plan_path), 'plan_sha256': guard(plan_path),
        'original_plan': str(original_path), 'original_plan_sha256': guard(original_path),
        'relocation_record': str(record_path), 'relocation_record_sha256': guard(record_path),
        'adapter': str(ADAPTER), 'adapter_sha256': ADAPTER_SHA256,
        'audit_script': str(Path(__file__).resolve()), 'audit_script_sha256': script_sha,
        'tools': list(tools.values()), 'command_path_changes': changes,
        'guarded_files': GUARDS, 'exact_plan_transform_verified': True,
        'limits': [
            'Verifies exact plan transformation and retained tool bytes; it does not run preparations, benchmarks, profiles, or compiler checks.',
            'Original build and validation records remain byte-for-byte unchanged. Their former mutable tool aliases are historical paths, not claims about current alias resolution.',
            'Original build-only/full-validation scope is preserved; relocation does not expand validation claims.',
        ],
    }
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': 'passed', 'audit': str(args.output), 'sha256': guard(args.output)}))


if __name__ == '__main__':
    main()
