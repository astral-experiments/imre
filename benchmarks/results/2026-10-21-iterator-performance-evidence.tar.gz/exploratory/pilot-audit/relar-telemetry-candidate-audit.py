"""Independently audit retained telemetry profiles without executing workloads."""

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shlex
import itertools
import statistics
import subprocess


def require(condition, message):
    if not condition:
        raise ValueError(message)


DIGEST_CACHE = {}

def digest(path):
    path = Path(path).resolve(strict=True)
    stat = path.stat()
    key = (str(path), stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
    if key not in DIGEST_CACHE:
        with path.open('rb') as stream:
            DIGEST_CACHE[key] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return DIGEST_CACHE[key]


SOURCE_BINDINGS = {}

def guarded_identity(path, expected, repository, revision):
    path = Path(path).resolve(strict=True)
    try:
        relative = path.relative_to(repository.resolve(strict=True)).as_posix()
    except ValueError:
        require(digest(path) == expected, 'immutable artifact/tool/evidence changed: ' + str(path))
        return
    key = (relative, expected)
    if key not in SOURCE_BINDINGS:
        captured = subprocess.run(['git', '-C', str(repository), 'show', revision + ':' + relative], capture_output=True, check=True).stdout
        require(sha(captured) == expected, 'recorded revision source differs: ' + relative)
        SOURCE_BINDINGS[key] = {'path': relative, 'recorded_sha256': expected, 'live_sha256': digest(path),
                                'live_source_has_advanced': digest(path) != expected}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def decoded_file(value):
    data = base64.b64decode(value['base64'], validate=True)
    require(sha(data) == value['sha256'] and len(data) == value['bytes'], 'encoded file identity differs')
    return data


def parse_callgrind(path):
    """Separate self-event rows from the single event row following each call."""
    lines = path.read_text().splitlines()
    require([line for line in lines if line.startswith('positions:')] == ['positions: instr line'], 'unexpected positions')
    require([line for line in lines if line.startswith('events:')] == ['events: Ir'], 'unexpected events')
    summaries = [int(line.partition(':')[2].strip()) for line in lines if line.startswith('summary:')]
    require(len(summaries) == 1 and summaries[0] > 0, 'missing instruction summary')
    identities = {}
    for line in lines:
        match = re.fullmatch(r'(?:c?fn)=\((\d+)\) (.+)', line)
        if match:
            old = identities.setdefault(match[1], match[2])
            require(old == match[2], 'function identity changed')
    own, calls, incoming = Counter(), Counter(), Counter()
    current = callee = pending = None
    for line in lines:
        match = re.fullmatch(r'(c?fn)=\((\d+)\)(?: .+)?', line)
        if match:
            if match[1] == 'fn':
                require(pending is None, 'unfinished call edge')
                current = identities[match[2]]
            else:
                callee = identities[match[2]]
            continue
        if line.startswith('calls='):
            require(callee is not None and pending is None, 'invalid call setup')
            calls[callee] += int(line.split()[0].split('=')[1])
            pending = callee
            continue
        fields = line.split()
        if len(fields) not in (2, 3) or not re.fullmatch(r'(?:0x[0-9a-f]+|[+-]?\d+|\*)', fields[0]):
            continue
        if not re.fullmatch(r'(?:[+-]?\d+|\*)', fields[1]):
            continue
        count = int(fields[2]) if len(fields) == 3 else 0
        require(count >= 0, 'negative instruction count')
        if pending is not None:
            incoming[pending] += count
            pending = None
        else:
            require(current is not None, 'self count without function')
            own[current] += count
    require(pending is None and sum(own.values()) == summaries[0], 'raw self counts do not match total')
    functions = {
        name: {'self_instructions': count, 'calls': calls[name], 'incoming_inclusive_instructions': incoming[name]}
        for name, count in own.items()
    }
    return summaries[0], functions


def parse_dhat(path):
    heap = json.loads(path.read_text())
    require(heap['mode'] == 'heap' and heap['tu'] == 'instrs', 'unexpected DHAT mode')
    mapping = {
        'allocated_bytes': 'tb', 'allocated_blocks': 'tbk',
        'peak_live_bytes': 'gb', 'peak_live_blocks': 'gbk',
        'exit_live_bytes': 'eb', 'exit_live_blocks': 'ebk',
    }
    metrics = {}
    for name, field in mapping.items():
        require(all(isinstance(point[field], int) and point[field] >= 0 for point in heap['pps']), 'invalid DHAT count')
        metrics[name] = sum(point[field] for point in heap['pps'])
    metrics['top_allocation_stacks'] = [
        {'bytes': point['tb'], 'blocks': point['tbk'], 'frames': [heap['ftbl'][index] for index in point['fs']]}
        for point in sorted(heap['pps'], key=lambda point: point['tb'], reverse=True)[:20]
    ]
    return metrics


def independent_oracle(case):
    files = {name: decoded_file(value) for name, value in case['files'].items()}
    require(case['directories'] == [] and case['hardlinks'] == {}, 'unsupported pilot filesystem shape')
    operation, left_name, right_name, report_name, threshold_text, count_text = case['arguments']
    threshold, count = int(threshold_text), int(count_text)
    require(threshold >= 0 and count > 0, 'invalid pilot options')
    data = []
    for name in (left_name, right_name):
        lines = files[name].decode('utf-8').splitlines()
        rows = [tuple(map(int, row.split())) for row in lines[1:]]
        require(int(lines[0]) == len(rows) and all(len(row) == 2 for row in rows), 'invalid pilot input')
        require(all(rows[i - 1][0] < rows[i][0] for i in range(1, len(rows))), 'pilot timestamps not increasing')
        data.append(rows)
    left, right = data
    require(len(left) == len(right) and all(a[0] == b[0] for a, b in zip(left, right, strict=True)), 'pilot input alignment differs')
    differences = [b[1] - a[1] for a, b in zip(left, right, strict=True)]
    alerts = [left[i][0] for i, difference in enumerate(differences) if abs(difference) > threshold]
    latest = alerts[-1] if alerts else None
    if operation == 'report':
        signed = sum(differences)
        absolute = sum(abs(value) for value in differences)
        squared = sum(value * value for value in differences)
        report = ('TELEMETRY\nSAMPLES ' + str(len(left)) + '\nSIGNED_ERROR ' + str(signed)
                  + '\nABSOLUTE_ERROR ' + str(absolute) + '\nSQUARED_ERROR ' + str(squared)
                  + '\nALERT ' + str(bool(alerts)) + '\nWITHIN ' + str(not alerts)
                  + '\nLATEST ' + str(latest) + '\nEND\n')
        checksum = signed + absolute + squared
    elif operation == 'alert':
        report, checksum = str(bool(alerts)) + '\n', int(bool(alerts))
    elif operation == 'within':
        report, checksum = str(not alerts) + '\n', int(not alerts)
    else:
        require(operation == 'latest', 'unknown pilot operation')
        report, checksum = str(latest) + '\n', latest if latest is not None else 0
    files[report_name] = report.encode()
    return 'OK\n' + str(count * checksum) + '\n', files


def audit_pilot(record, timing, plan, prepared, binaries):
    engines = ('relar', 'cpython', 'rust')
    orders = [list(order) for order in itertools.permutations(engines)]
    require(record['engine_orders'] == orders and record['samples'] == 6 and record['warmups'] == 1, 'pilot sampling schedule changed')
    require(record['cpu']['affinity'] == [timing['timing_environment']['cpu']] == [0], 'CPU affinity differs')
    require(timing['timing_environment']['tracer_pid'] == 0 and not timing['timing_environment']['known_heavy_processes'], 'timing environment guard failed')
    selection = record['workload_selection']
    require(selection['input_guards_passed'] and selection['canonical_input_and_repetition_checks_passed'], 'input selection incomplete')
    require(selection['selected_sizes'] == [4096] and selection['generated_workload_count'] == 12 and selection['selected_workload_count'] == 4, 'pilot selection differs')
    require(selection['command'] == timing['runs'][0]['command'], 'pilot wrapper invocation differs')
    baseline_path = Path(plan['protected_paths']['baseline'])
    baseline = json.loads(baseline_path.read_text())
    require(digest(baseline_path) == selection['protected_sha256']['baseline'], 'historical baseline changed')
    canonical = {row['label']: row for row in baseline['workloads']}
    labels = [name + '-4096' for name in ('report-mixed', 'alert-quiet', 'within-quiet', 'latest-quiet')]
    require([row['label'] for row in record['workloads']] == labels == selection['selected_labels'], 'pilot workload matrix differs')
    for key, expected in selection['fixed_program_and_tool_sha256'].items():
        require(prepared['source_and_tool_sha256'][key] == expected == baseline['source_and_tool_sha256'][key], 'canonical program/tool differs: ' + key)
    require(record['batch_pairs'] == selection['batch_pairs'] == 8388608, 'batch size changed')
    command = timing['runs'][0]['command']
    directory = Path(command[command.index('--artifact-dir') + 1])
    bootstrap = "import runpy, sys; sys.path.insert(0, sys.argv[1]); sys.argv = ['telemetry_comparison', *sys.argv[2:]]; runpy.run_module('telemetry_comparison', run_name='__main__', alter_sys=True)"
    expected_commands = {'relar': [str(binaries['relar'])], 'rust': [str(binaries['rust'])],
                         'cpython': [prepared['source_and_tool_paths']['python'], '-I', '-B', '-c', bootstrap, str(Path(plan['root']) / 'examples')]}
    result, process_records = {}, 0
    for row in [record['startup_control'], *record['workloads']]:
        label = row['label']
        if label != 'empty-control':
            require(all(row[field] == canonical[label][field] for field in selection['matched_fields']), 'canonical workload changed: ' + label)
        stdout, files = independent_oracle(row['case'])
        require(stdout == row['expected_stdout'] and {name: decoded_file(value) for name, value in row['expected_files'].items()} == files, 'independent pilot oracle differs: ' + label)
        file_records = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in files.items()}
        require(len(row['warmups']) == 1 and len(row['samples']) == 6 and set(row['gates']) == set(engines), 'round count differs')
        for phase in ('warmups', 'samples'):
            for index, sample in enumerate(row[phase]):
                require(sample['index'] == index and sample['order'] == orders[index % 6], 'unbalanced engine order')
        groups = [row['gates'], *row['warmups'], *row['samples']]
        for group in groups:
            for engine in engines:
                item = group[engine]
                require(item['returncode'] == 0 and item['stderr'] == '' and item['stdout'] == stdout, 'complete pilot process output differs')
                require(item['files'] == file_records and item['directories'] == [], 'complete pilot recorded filesystem differs')
                require(item['command'] == expected_commands[engine] + row['case']['arguments'], 'pilot engine command differs')
                require(isinstance(item['elapsed_ns'], int) and item['elapsed_ns'] > 0, 'invalid raw duration')
                process_records += 1
        summaries = {}
        for engine in engines:
            durations = [sample[engine]['elapsed_ns'] / 1e9 for sample in row['samples']]
            quartiles = statistics.quantiles(durations, n=4, method='inclusive')
            summaries[engine] = {'median_seconds': statistics.median(durations), 'min_seconds': min(durations), 'max_seconds': max(durations), 'p25_seconds': quartiles[0], 'p75_seconds': quartiles[2]}
            require(summaries[engine] == row['summary'][engine], 'raw sample summary differs')
            work = directory / label / engine
            require(not any(path.is_symlink() for path in work.rglob('*')), 'pilot output has symlink')
            require({path.relative_to(work).as_posix(): path.read_bytes() for path in work.rglob('*') if path.is_file()} == files, 'retained pilot filesystem differs')
            require(not any(path.is_dir() for path in work.iterdir()), 'pilot output directories differ')
        ratios = {}
        for left, right in (('cpython', 'relar'), ('relar', 'rust'), ('cpython', 'rust')):
            name = left + '_over_' + right
            ratios[name] = summaries[left]['median_seconds'] / summaries[right]['median_seconds']
            require(row[name] == ratios[name], 'ratio of medians differs')
        if label != 'empty-control':
            require(row['startup_control_fraction'] == {engine: record['startup_control']['summary'][engine]['median_seconds'] / summaries[engine]['median_seconds'] for engine in engines}, 'startup-control fraction differs')
            require(timing['relar_over_rust'][label] == ratios['relar_over_rust'], 'timing status ratio differs')
        result[label] = {'median_seconds': {engine: summaries[engine]['median_seconds'] for engine in engines}, **ratios}
    require(timing['all_four_below_two'] == all(result[label]['relar_over_rust'] < 2 for label in labels), 'pilot threshold result differs')
    return {'status': 'passed', 'exploratory': True, 'workloads': 4, 'startup_controls': 1, 'raw_process_records_verified': process_records,
            'measured_rounds_per_workload': 6, 'warmup_rounds_per_workload': 1, 'independent_complete_oracle_verified': True,
            'ratios_and_medians': result, 'all_four_below_two': timing['all_four_below_two']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path('/tmp/relar-telemetry-candidate-003-profile'))
    parser.add_argument('--output', type=Path, default=Path('/tmp/relar-telemetry-candidate-003-audit.json'))
    args = parser.parse_args()
    root = args.directory.resolve(strict=True)
    read = lambda name: json.loads((root / name).read_text())
    summary = read('summary.json')
    summary_hash = digest(root / 'summary.json')
    require(summary['status'] == 'passed' and summary['complete'] and summary['input_guards_passed'], 'profile is incomplete')
    require(summary['thinlto'] and summary['label'] == 'alert-quiet-4096', 'wrong profile scope')
    manifest = read('manifest.json')
    require(set(manifest) == {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file() and path.name != 'manifest.json'}, 'retained file set differs')
    for name, expected in manifest.items():
        require(digest(root / name) == expected, 'artifact hash differs: ' + name)
    for name, expected in summary['snapshot_sha256'].items():
        require(digest(root / name) == expected, 'snapshot hash differs: ' + name)
    repository = Path(read('candidate-plan.json')['root'])
    for name, value in summary['guarded_inputs'].items():
        guarded_identity(value['path'], value['sha256'], repository, summary['timing_revision'])
    prepared, benchmark, timing = read('preparation.json'), read('benchmark-record.json'), read('timing-status.json')
    plan, preparation_status = read('candidate-plan.json'), read('preparation-status.json')
    build, rust_build, validation = read('relar-build-record.json'), read('rust-build-record.json'), read('validation-index.json')
    require(summary['exploratory'] is True and summary['profile_context'] == 'exploratory-pilot', 'profile is not exploratory')
    require(timing['phase'] == 'pilot' and timing['status'] == 'passed' and timing['exploratory'] is True and timing['input_guards_passed'], 'pilot incomplete')
    require(datetime.fromisoformat(summary['started_at_utc']) > datetime.fromisoformat(timing['completed_at']), 'profiling overlaps bound timing')
    require(digest(root / 'candidate-plan.json') == timing['plan_sha256'] == summary['candidate_plan_sha256'], 'plan identity differs')
    require(plan['status'] == 'planned' and plan['input_guards_passed'], 'plan incomplete')
    require(set(plan['protected_paths']) == set(plan['protected_sha256']), 'plan guards incomplete')
    for name, path in plan['protected_paths'].items():
        guarded_identity(path, plan['protected_sha256'][name], repository, summary['timing_revision'])
    require(digest(root / 'preparation.json') == summary['preparation_record_sha256'], 'preparation hash differs')
    require(digest(root / 'benchmark-record.json') == summary['benchmark_record_sha256'], 'benchmark hash differs')
    require(digest(root / 'timing-status.json') == summary['timing_status_sha256'], 'timing hash differs')
    runs = [run for run in timing['runs'] if run['mode'] == 'thinlto']
    require(len(runs) == len(timing['runs']) == 1, 'wrong pilot run count')
    run = runs[0]
    require(run['status'] == 'passed' and run['exit_code'] == 0 and run['command'] == plan['commands']['pilot'], 'pilot command differs')
    require(run['output_sha256'] == digest(run['output']) == summary['benchmark_record_sha256'], 'pilot output differs')
    for channel in ('stdout','stderr'):
        require(digest(run[channel]) == run[channel + '_sha256'], 'pilot log changed')
    require(Path(run['stderr']).read_bytes() == b'', 'pilot stderr is not empty')
    require(preparation_status['phase'] == 'prepare' and preparation_status['status'] == 'passed' and preparation_status['input_guards_passed'], 'preparation incomplete')
    require(preparation_status['plan_sha256'] == summary['candidate_plan_sha256'], 'preparation plan differs')
    prepared_runs = [item for item in preparation_status['runs'] if item['mode'] == 'thinlto']
    require(len(prepared_runs) == 1, 'missing ThinLTO preparation')
    prepared_run = prepared_runs[0]
    require(prepared_run['status'] == 'passed' and prepared_run['exit_code'] == 0 and prepared_run['command'] == plan['commands']['prepare']['thinlto'], 'preparation command differs')
    require(digest(prepared_run['output']) == prepared_run['output_sha256'] == summary['preparation_record_sha256'], 'preparation output differs')
    require(Path(run['command'][run['command'].index('--prepared-record') + 1]).resolve() == Path(prepared_run['output']).resolve(), 'pilot uses another preparation')
    require(benchmark['kind'] == 'telemetry-benchmark' and benchmark['input_guards_passed'] and benchmark['completed_at_utc'] and benchmark['thinlto'] and not benchmark['dirty'], 'invalid benchmark')
    require(benchmark['preparation'] == prepared and benchmark['preparation_record_sha256'] == summary['preparation_record_sha256'], 'benchmark preparation differs')
    require(prepared['kind'] == 'telemetry-preparation' and prepared['input_guards_passed'] and prepared['thinlto'] and not prepared['dirty'], 'invalid preparation')
    revision = summary['timing_revision']
    require(all(value == revision for value in (prepared['revision'], benchmark['revision'], timing['revision'], plan['revision'], preparation_status['revision'], build['revision'], validation['revision'], summary['build_revision'], summary['validation_revision'])), 'source revision differs')
    require(prepared['relar_build_record'] == build and prepared['rust_build_record'] == rust_build, 'build snapshot differs')
    require(build['input_guards_passed'] and build['source_matches_revision'], 'invalid compiler build')
    require(validation['status'] == 'passed' and validation['input_guards_passed'] and validation['source_unchanged'], 'validation incomplete')
    require(digest(root / 'validation-index.json') == plan['protected_sha256']['validation_index'], 'validation identity differs')
    require(summary['validation_mode'] == validation['mode'] == plan['validation_mode'], 'validation mode differs')
    require(summary['validation_scope'] == validation['scope'] == plan['validation_scope'], 'validation scope differs')
    require(summary['full_validation_passed'] == validation['full_validation_passed'] == plan['validation_full_matrix_passed'] == timing['validation_full_matrix_passed'], 'validation scope overclaimed')
    require(digest(root / 'relar-build-record.json') == validation['build_record']['sha256'] == prepared['source_and_tool_sha256']['relar_build_record'], 'compiler build provenance differs')
    require(rust_build['input_guards_passed'] and rust_build['thinlto'], 'invalid Rust build')
    require(digest(root / 'rust-build-record.json') == prepared['source_and_tool_sha256']['rust_build_record'], 'Rust build record differs')
    require(digest(root / 'native.ll') == prepared['llvm_sha256'], 'LLVM differs')
    require(read('prepared-validation.json') == prepared['validation'] and digest(root / 'prepared-validation.json') == prepared['validation_sha256'], 'prepared validation differs')
    require(benchmark['source_and_tool_sha256'] == prepared['source_and_tool_sha256'], 'timed source/tool identities differ')
    for name, expected in prepared['source_and_tool_sha256'].items():
        guard = summary['guarded_inputs'][name]
        require(guard['sha256'] == expected and Path(guard['path']).resolve() == Path(prepared['source_and_tool_paths'][name]).resolve(), 'prepared source/tool guard differs: ' + name)
    for name in ('validator', 'filesystem_validator', 'batch_validator', 'incremental_validator', 'shared_validator'):
        copied = root / ('oracle-' + Path(prepared['source_and_tool_paths'][name]).name)
        require(digest(copied) == prepared['source_and_tool_sha256'][name], 'oracle snapshot differs')
    require(digest(root / 'profiler.py') == summary['guarded_inputs']['profiler']['sha256'], 'profiler snapshot differs')
    binary_hashes = {'relar': prepared['binary_sha256'], 'rust': prepared['source_and_tool_sha256']['rust']}
    require(benchmark['binary_sha256'] == binary_hashes['relar'] and rust_build['binary_sha256'] == binary_hashes['rust'], 'native binary provenance differs')
    binaries = {'relar': Path(prepared['binary']).resolve(), 'rust': Path(prepared['source_and_tool_paths']['rust']).resolve()}
    for name, binary in binaries.items():
        require(digest(binary) == binary_hashes[name], 'exact timed binary changed')
    require(build['sha256']['compiler'] == prepared['source_and_tool_sha256']['compiler'] and build['sha256']['thinlto_runtime'] == prepared['source_and_tool_sha256']['runtime'], 'prepared compiler/runtime differs')
    pilot_audit = audit_pilot(benchmark, timing, plan, prepared, binaries)
    workloads = [workload for workload in benchmark['workloads'] if workload['label'] == summary['label']]
    require(len(workloads) == 1, 'workload missing or repeated')
    workload = workloads[0]
    require(workload['scenario'] == 'alert-quiet' and workload['label'] == 'alert-quiet-4096' and workload['inspected_pairs_per_call'] == 4096, 'unexpected workload')
    require(set(summary['cases']) == {'128', '256'}, 'wrong query counts')
    cases = {}
    for count in (128, 256):
        metadata = summary['cases'][str(count)]
        case = metadata['case']
        expected_case = json.loads(json.dumps(workload['case']))
        expected_case['arguments'][-1] = str(count)
        require(case == expected_case and metadata['pairs'] == count * 4096, 'profile inputs changed beyond repeat count')
        args_ = case['arguments']
        require(len(args_) == 6 and args_[0] == 'alert' and int(args_[-1]) == count, 'wrong invocation')
        files = {name: decoded_file(value) for name, value in case['files'].items()}
        reference, observed = [files[name].decode('utf-8').splitlines() for name in args_[1:3]]
        require(int(reference[0]) == int(observed[0]) == 4096 and len(reference) == len(observed) == 4097, 'sample counts differ')
        left = [tuple(map(int, row.split())) for row in reference[1:]]
        right = [tuple(map(int, row.split())) for row in observed[1:]]
        threshold = int(args_[4])
        require(all(len(a) == len(b) == 2 and a[0] == b[0] and abs(a[1] - b[1]) <= threshold for a, b in zip(left, right, strict=True)), 'quiet workload can alert')
        require(all(rows[i - 1][0] < rows[i][0] for rows in (left, right) for i in range(1, len(rows))), 'timestamps not increasing')
        require(metadata['expected_stdout'] == 'OK\n0\n', 'false-query repetition checksum is wrong')
        expected_files = {name: decoded_file(value) for name, value in metadata['expected_files'].items()}
        files[args_[3]] = b'False\n'
        require(expected_files == files and metadata['expected_directories'] == [], 'unexpected independent file oracle')
        require(case['directories'] == [] and case['hardlinks'] == {}, 'unexpected filesystem shape')
        cases[count] = (case, expected_files)
    expected_profiles = {(engine, tool, count) for engine in binaries for tool, count in (('callgrind', 128), ('dhat', 128), ('dhat', 256))}
    require({(item['engine'], item['tool'], item['repetitions']) for item in summary['profiles']} == expected_profiles and len(summary['profiles']) == 6, 'incomplete/duplicate profile runs')
    parsed = {}
    for item in summary['profiles']:
        engine, tool, count = item['engine'], item['tool'], item['repetitions']
        name = f'{engine}-{tool}-{count}'
        directory = root / name
        record = json.loads((directory / 'command.json').read_text())
        require(record == {key: value for key, value in item.items() if key != 'files'}, 'profile command record differs')
        require(item['returncode'] == 0 and item['status'] == 'validated' and item['binary_sha256'] == binary_hashes[engine], 'profile command did not validate')
        require(item['pairs'] == count * 4096 and Path(item['cwd']) == directory / 'work', 'profile workload/cwd differs')
        command = item['command']
        require(Path(command[0]).resolve() == Path(summary['guarded_inputs']['tool_valgrind']['path']).resolve(), 'different Valgrind executable')
        require('--num-callers=32' in command, 'different allocation stack depth')
        if tool == 'callgrind':
            require('--dump-instr=yes' in command and '--collect-jumps=yes' in command, 'different instruction collection')
        require('--tool=' + tool in command and '--command-line-only=yes' in command and '--error-exitcode=97' in command, 'unsafe/different profiler invocation')
        position = command.index(str(binaries[engine]))
        require(command[position + 1:] == cases[count][0]['arguments'], 'native arguments differ')
        require(item['environment'] == summary['environment'] and summary['environment']['LC_ALL'] == 'C' and summary['environment']['VALGRIND_OPTS'] == '', 'environment differs')
        require((directory / 'stdout.txt').read_bytes() == summary['cases'][str(count)]['expected_stdout'].encode(), 'complete stdout/checksum differs')
        require((directory / 'stderr.txt').read_bytes() == b'', 'native stderr is nonempty')
        require({path.relative_to(directory / 'work').as_posix(): path.read_bytes() for path in (directory / 'work').rglob('*') if path.is_file()} == cases[count][1], 'final filesystem differs')
        require(not any(path.is_dir() for path in (directory / 'work').iterdir()), 'unexpected output directory')
        require(set(item['files']) == {path.relative_to(directory).as_posix() for path in directory.rglob('*') if path.is_file()}, 'profile file inventory differs')
        for relative, expected in item['files'].items():
            require(digest(directory / relative) == expected, 'profile member hash differs')
        log = (directory / 'valgrind.log').read_text()
        require(not re.search(r'ERROR SUMMARY: [1-9]|Fatal error|unhandled instruction|Process terminating with', log), 'Valgrind failure marker')
        if tool == 'callgrind':
            total, functions = parse_callgrind(directory / 'profile.callgrind')
            raw_lines = (directory / 'profile.callgrind').read_text().splitlines()
            raw_commands = [line.partition(':')[2].strip() for line in raw_lines if line.startswith('cmd:')]
            require(len(raw_commands) == 1 and shlex.split(raw_commands[0]) == command[position:], 'Callgrind profiled another command')
            require([int(line.partition(':')[2]) for line in raw_lines if line.startswith('totals:')] == [total], 'Callgrind final totals differ')
            metrics = item['metrics']
            require(metrics['instructions'] == metrics['self_cost_sum'] == total, 'instruction summary differs')
            recorded = {row['name']: {key: row[key] for key in ('self_instructions', 'calls', 'incoming_inclusive_instructions')} for row in metrics['functions']}
            require(len(recorded) == len(metrics['functions']) and recorded == functions, 'raw function counts differ')
            require(all(row['self_fraction'] == row['self_instructions'] / total for row in metrics['functions']), 'function fraction differs')
            require(len(item['annotations']) == 2 and all(value['returncode'] == 0 for value in item['annotations']), 'annotation incomplete')
            for inclusive in ('no', 'yes'):
                require((directory / f'inclusive-{inclusive}-stderr.txt').read_bytes() == b'', 'annotation stderr nonempty')
            parsed[name] = {'instructions': total, 'instructions_per_inspected_pair': total / item['pairs'], 'top_self_functions': metrics['functions'][:15]}
        else:
            metrics = parse_dhat(directory / 'profile.json')
            raw_heap = json.loads((directory / 'profile.json').read_text())
            require(shlex.split(raw_heap['cmd']) == command[position:], 'DHAT profiled another command')
            require(metrics == item['metrics'], 'raw DHAT totals/stacks differ')
            parsed[name] = metrics
    slopes = {}
    for engine in binaries:
        slopes[engine] = {}
        for field in ('allocated_bytes', 'allocated_blocks'):
            a, b = [parsed[f'{engine}-dhat-{count}'][field] for count in (128, 256)]
            expected = {'at_128_queries': a, 'at_256_queries': b, 'per_additional_query': (b - a) / 128, 'two_point_fixed_estimate': 2 * a - b}
            require(summary['allocation_growth'][engine][field] == expected, 'allocation growth arithmetic differs')
            slopes[engine][field] = {**expected, 'per_additional_inspected_pair': (b - a) / (128 * 4096)}
    allocation_stack_growth = {}
    for engine in binaries:
        captures = []
        for count in (128, 256):
            heap = json.loads((root / f'{engine}-dhat-{count}/profile.json').read_text())
            totals = {}
            for point in heap['pps']:
                frames = tuple(heap['ftbl'][index] for index in point['fs'])
                item = totals.setdefault(frames, [0, 0])
                item[0] += point['tb']
                item[1] += point['tbk']
            captures.append(totals)
        differences = []
        for frames in captures[0].keys() | captures[1].keys():
            left, right = [capture.get(frames, [0, 0]) for capture in captures]
            delta = [right[index] - left[index] for index in (0, 1)]
            if any(delta):
                differences.append({'additional_bytes': delta[0], 'additional_blocks': delta[1], 'frames': list(frames)})
        require(sum(item['additional_bytes'] for item in differences) == slopes[engine]['allocated_bytes']['at_256_queries'] - slopes[engine]['allocated_bytes']['at_128_queries'], 'allocation stack byte deltas differ')
        require(sum(item['additional_blocks'] for item in differences) == slopes[engine]['allocated_blocks']['at_256_queries'] - slopes[engine]['allocated_blocks']['at_128_queries'], 'allocation stack block deltas differ')
        allocation_stack_growth[engine] = sorted(differences, key=lambda item: (item['additional_bytes'], item['frames']), reverse=True)
    require(digest(root / 'summary.json') == summary_hash, 'summary changed during audit')
    report = {
        'schema': 1, 'status': 'passed', 'audited_at_utc': datetime.now(timezone.utc).isoformat(),
        'profile_directory': str(root), 'profile_summary_sha256': summary_hash,
        'profile_manifest_sha256': digest(root / 'manifest.json'), 'audit_script_sha256': digest(__file__),
        'timing_revision': summary['timing_revision'], 'build_revision': summary['build_revision'],
        'validation_revision': summary['validation_revision'], 'full_validation_passed': summary['full_validation_passed'],
        'exploratory': True, 'profile_context': 'exploratory-pilot', 'pilot_audit': pilot_audit,
        'source_binding': {'method': 'Every source path beneath the checkout verified against its exact Git blob at timing_revision; immutable artifacts/tools/evidence verified live.',
                           'source_files_verified': len(SOURCE_BINDINGS), 'advanced_live_sources': [value for value in SOURCE_BINDINGS.values() if value['live_source_has_advanced']]},
        'benchmark_record_sha256': summary['benchmark_record_sha256'], 'timing_status_sha256': summary['timing_status_sha256'],
        'preparation_record_sha256': summary['preparation_record_sha256'], 'binary_sha256': binary_hashes,
        'llvm_sha256': prepared['llvm_sha256'], 'profiles_verified': 6, 'evidence_files_verified': len(manifest),
        'complete_stdout_checksum_and_files_verified': True, 'quiet_input_proved_independently': True,
        'raw_profile_counts_independently_reparsed': True, 'profiles_started_after_bound_timing_completed': True,
        'metrics': {name: ({key: value for key, value in metrics.items() if key not in ('top_allocation_stacks', 'top_self_functions')} | ({'top_self_functions': metrics['top_self_functions'][:5]} if 'top_self_functions' in metrics else {})) for name, metrics in parsed.items()},
        'allocation_growth': slopes, 'allocation_stack_growth': {name: [{**row, 'frames': row['frames'][:6]} for row in rows[:3]] for name, rows in allocation_stack_growth.items()},
        'whole_process_instruction_ratio_relar_over_rust': parsed['relar-callgrind-128']['instructions'] / parsed['rust-callgrind-128']['instructions'],
        'limits': [
            'Guest instructions are not CPU cycles or wall-time speedups; inclusive call edges overlap and must not be added as independent costs.',
            'Profiles cover whole processes including startup/loading; only allocation differences between query counts isolate descriptive query-dependent growth.',
            'DHAT requested heap bytes/blocks are not RSS. Global-peak and exit-live counts are different metrics; exit-live memory alone does not establish leaks.',
            'Two query counts support a descriptive allocation slope, not proof of linearity across workloads or counts.',
            'No engines, imported oracle programs, builds, tests, benchmark timing, or profiles were executed by this audit; pure input arithmetic independently reconstructs expected outputs.',
            'This is intermediate exploratory evidence at the recorded revision, not final performance or full-validation evidence.',
        ],
    }
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'audit': str(args.output), 'sha256': digest(args.output)}))


if __name__ == '__main__':
    main()
