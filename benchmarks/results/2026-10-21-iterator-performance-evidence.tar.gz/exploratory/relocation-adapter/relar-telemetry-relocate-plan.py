#!/usr/bin/env python3
"""Derive a fresh pilot plan using retained, byte-identical old Ohm tools.

This only validates inputs and writes a plan plus relocation record. It never
builds, prepares, profiles, or times anything. Run the unchanged evidence helper
against the derived plan for subsequent preparation and explicitly authorized
pilot timing. Original plans, records, artifacts and mutable aliases are untouched.
"""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HELPER = Path('/tmp/relar-telemetry-evidence.py')
HELPER_SHA = '6a203489299e5554b6f19a8c9b877a3a2d8fb45a8c34f9c693b3bb5b85107d01'
NAMES = ('cargo', 'rustc', 'rustfmt', 'cargo-clippy', 'clippy-driver')
OLD_ALIAS = Path('/home/dev-user/.rustup/toolchains/ohm/bin')
RETAINED = Path('/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/bin')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def write(path, data):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(data, indent=2) + '\n')


def main():
    if sys.flags.optimize:
        raise RuntimeError('Run guards without Python -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    script = Path(__file__).resolve(strict=True)
    script_sha = sha(script)
    source = args.plan.resolve(strict=True)
    source_sha = sha(source)
    original = load(source)
    output = args.output.resolve()
    old_output = Path(original['output']).resolve(strict=True)
    root = Path(original['root']).resolve(strict=True)
    assert original['schema'] == 1 and original['status'] == 'planned' and original['input_guards_passed']
    assert source == old_output / 'plan.json'
    assert not output.exists() and not output.is_relative_to(root) and not output.is_relative_to(old_output)
    assert original['protected_paths']['helper'] == str(HELPER)
    assert original['protected_sha256']['helper'] == sha(HELPER) == HELPER_SHA
    build_path = Path(original['protected_paths']['build_record'])
    index_path = Path(original['protected_paths']['validation_index'])
    assert not output.is_relative_to(build_path.parent)
    build, index = load(build_path), load(index_path)
    assert build['revision'] == index['revision'] == original['revision']
    assert build['input_guards_passed'] and build['source_matches_revision']
    assert index['status'] == 'passed' and index['input_guards_passed'] and index['source_unchanged']
    assert index['build_record']['sha256'] == sha(build_path)
    assert subprocess.check_output(['git', '-C', root, 'rev-parse', 'HEAD'], text=True).strip() == original['revision']
    assert not subprocess.check_output(['git', '-C', root, 'status', '--porcelain=v1', '--untracked-files=all'], text=True).strip()
    derived = copy.deepcopy(original)
    relocated = []
    keys = {'build_tool:ohm-' + name for name in NAMES}
    for key, path in original['protected_paths'].items():
        expected = original['protected_sha256'][key]
        if key in keys:
            name = key.removeprefix('build_tool:ohm-')
            retained = RETAINED / name
            assert path == str(OLD_ALIAS / name)
            assert build['tools']['ohm-' + name] == {'path': path, 'sha256': expected}
            assert retained.resolve(strict=True) == retained and sha(retained) == expected
            derived['protected_paths'][key] = str(retained)
            relocated.append({'key': key, 'original_path': path, 'retained_path': str(retained), 'sha256': expected})
        else:
            assert sha(path) == expected, key
    assert len(relocated) == len(NAMES)
    changes = []
    for phase, commands in (('prepare', derived['commands']['prepare']), ('pilot', {'thinlto': derived['commands']['pilot']})):
        for mode, command in commands.items():
            allowed = {'--artifact-dir', '--output'} | ({'--prepared-record'} if phase == 'pilot' else set())
            for flag in allowed:
                assert command.count(flag) == 1
                i = command.index(flag) + 1
                before = Path(command[i])
                assert before.is_relative_to(old_output)
                after = output / before.relative_to(old_output)
                command[i] = str(after)
                changes.append({'phase': phase, 'mode': mode, 'flag': flag, 'before': str(before), 'after': str(after)})
            assert all(not value.startswith(str(old_output) + '/') for value in command)
    created = datetime.now(timezone.utc).isoformat()
    relocation = {
        'schema': 1, 'kind': 'exact-content-tool-path-relocation', 'created_at': created,
        'purpose': 'Exploratory pilot after external mutable Ohm alias update; fresh preparation, unchanged source and candidate/reference binaries.',
        'original_plan': str(source), 'original_plan_sha256': source_sha,
        'build_record': str(build_path), 'build_record_sha256': sha(build_path),
        'validation_index': str(index_path), 'validation_index_sha256': sha(index_path),
        'adapter': str(script), 'adapter_sha256': script_sha,
        'revision': original['revision'], 'old_output': str(old_output), 'new_output': str(output),
        'tools': relocated, 'command_path_changes': changes,
        'historical_records_modified': False, 'tool_bytes_changed': False,
        'limitation': 'This preserves content identity of recorded build tools; it does not claim the mutable original aliases still resolve to those tools.',
    }
    derived.update(created_at=created, output=str(output), tool_path_relocation=relocation)
    output.mkdir(parents=True, exist_ok=False)
    relocation_path = output / 'tool-path-relocation.json'
    write(relocation_path, relocation)
    for key, path in {'relocation:original_plan': source, 'relocation:adapter': script, 'relocation:record': relocation_path}.items():
        assert key not in derived['protected_paths']
        derived['protected_paths'][key] = str(path)
        derived['protected_sha256'][key] = sha(path)
    assert sha(source) == source_sha and sha(script) == script_sha
    assert derived['protected_sha256'] == {key: sha(path) for key, path in derived['protected_paths'].items()}
    write(output / 'plan.json', derived)
    print(json.dumps({'plan': str(output / 'plan.json'), 'plan_sha256': sha(output / 'plan.json'),
                      'relocation': str(relocation_path), 'relocation_sha256': sha(relocation_path),
                      'relocated_tools': len(relocated), 'changed_command_paths': len(changes),
                      'prepare_command': [sys.executable, '-I', '-B', str(HELPER), 'prepare', '--plan', str(output / 'plan.json')],
                      'pilot_command': [sys.executable, '-I', '-B', str(HELPER), 'pilot', '--plan', str(output / 'plan.json')]}, indent=2))


if __name__ == '__main__':
    main()
