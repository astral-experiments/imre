"""Explore simulated branches in the already validated candidate-005 binary."""

import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
from types import SimpleNamespace


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


root = Path("/home/dev-user/code/oss/relar")
source = Path("/tmp/relar-telemetry-candidate-005-profile/summary.json")
summary = json.loads(source.read_text())
validator_path = root / "benchmarks/telemetry_validate.py"
assert digest(validator_path) == summary["guarded_inputs"]["validator"]["sha256"]
validator = SimpleNamespace(**runpy.run_path(str(validator_path)))
case = validator.case_from_record(summary["cases"]["128"]["case"])
oracle = validator.oracle(case)
out = Path("/tmp/relar-telemetry-candidate-005-branches")
out.mkdir(exist_ok=False)
work = out / "work"
work.mkdir()
validator.materialize(case, work)
(work / "report.txt").write_bytes(b"replace this complete report")
prior = next(
    item
    for item in summary["profiles"]
    if item["engine"] == "relar" and item["tool"] == "callgrind"
)
binary = Path(summary["guarded_inputs"]["binary"]["path"])
assert digest(binary) == prior["binary_sha256"]
command = [
    prior["command"][0],
    "--tool=callgrind",
    "--command-line-only=yes",
    "--num-callers=32",
    "--error-exitcode=97",
    "--branch-sim=yes",
    "--dump-instr=yes",
    "--collect-jumps=yes",
    f"--log-file={out / 'valgrind.log'}",
    f"--callgrind-out-file={out / 'profile.callgrind'}",
    str(binary),
    *case.arguments,
]
record = {
    "exploratory": True,
    "source_profile": str(source),
    "source_profile_sha256": digest(source),
    "helper_sha256": digest(__file__),
    "binary_sha256": prior["binary_sha256"],
    "command": command,
    "cwd": str(work),
    "environment": summary["environment"],
}
(out / "command.json").write_text(json.dumps(record, indent=2) + "\n")
process = subprocess.run(
    command,
    cwd=work,
    input=b"",
    capture_output=True,
    env={**os.environ, **summary["environment"]},
    timeout=60,
)
(out / "stdout.txt").write_bytes(process.stdout)
(out / "stderr.txt").write_bytes(process.stderr)
record["validation"] = validator.check_result(case, oracle, process, work)
assert digest(binary) == record["binary_sha256"]
record["profile_sha256"] = digest(out / "profile.callgrind")
record["status"] = "passed"
(out / "command.json").write_text(json.dumps(record, indent=2) + "\n")
print(out)
