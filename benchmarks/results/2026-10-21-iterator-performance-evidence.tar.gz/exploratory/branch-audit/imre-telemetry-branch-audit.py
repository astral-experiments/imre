"""Independently check exploratory Callgrind branch simulation; never run engines.

The only subprocess is read-only objdump on the exact already-profiled binary.
Simulated predictor misses are not hardware counters or wall-time attribution.
"""

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import runpy
import shlex
import shutil
import subprocess
import sys

PARSERS = Path('/tmp/imre-telemetry-candidate-audit.py')
PARSERS_SHA256 = 'e9481b4d29553e59ff179cb377bcee84f860f764060115ca797c5b2681992b9c'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def parse_branches(path):
    lines = path.read_text().splitlines()
    require([line for line in lines if line.startswith('positions:')] == ['positions: instr line'], 'unexpected positions')
    require([line for line in lines if line.startswith('events:')] == ['events: Ir Bc Bcm Bi Bim'], 'unexpected branch events')
    summaries = [list(map(int, line.split()[1:])) for line in lines if line.startswith('summary:')]
    totals = [list(map(int, line.split()[1:])) for line in lines if line.startswith('totals:')]
    require(len(summaries) == len(totals) == 1 and summaries == totals, 'incomplete branch profile')
    names = {}
    for line in lines:
        match = re.fullmatch(r'c?fn=\((\d+)\) (.+)', line)
        if match:
            require(names.setdefault(match[1], match[2]) == match[2], 'function ID changed')
    functions = defaultdict(lambda: [0] * 5)
    locations = defaultdict(lambda: [0] * 5)
    function = address = None
    edge = False
    for line in lines:
        match = re.fullmatch(r'fn=\((\d+)\)(?: .+)?', line)
        if match:
            require(not edge, 'unfinished call edge')
            function, address = names[match[1]], None
        elif line.startswith('calls='):
            require(not edge, 'nested pending call edge')
            edge = True
        else:
            fields = line.split()
            if len(fields) < 2 or not re.fullmatch(r'(?:0x[0-9a-f]+|[+-]?\d+|\*)', fields[0]):
                continue
            if not re.fullmatch(r'(?:[+-]?\d+|\*)', fields[1]):
                continue
            token = fields[0]
            if token.startswith('0x'):
                address = int(token, 16)
            elif token.startswith(('+', '-')):
                require(address is not None, 'relative instruction without base')
                address += int(token)
            elif token != '*':
                address = int(token)
            require(function is not None and address is not None and len(fields[2:]) <= 5, 'invalid branch event row')
            values = [int(value) for value in fields[2:]] + [0] * (5 - len(fields[2:]))
            require(all(value >= 0 for value in values), 'negative event count')
            if edge:
                edge = False
            else:
                for index, value in enumerate(values):
                    functions[function][index] += value
                    locations[(function, address)][index] += value
    require(not edge and [sum(values[index] for values in functions.values()) for index in range(5)] == totals[0], 'self branch events do not sum to totals')
    return totals[0], dict(functions), dict(locations)


def main():
    script_sha = sha(__file__)
    require(sys.flags.optimize == 0, 'run the audit without Python -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--helper', type=Path, default=Path('/tmp/imre-telemetry-branch-probe.py'))
    parser.add_argument('--source-audit', type=Path, required=True)
    parser.add_argument('--objdump', type=Path, default=Path(shutil.which('objdump') or '/usr/bin/objdump'))
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), 'preserve previous audits')
    root = args.directory.resolve(strict=True)
    files = {path.relative_to(root).as_posix(): sha(path) for path in root.rglob('*') if path.is_file()}
    require(not any(path.is_symlink() for path in root.rglob('*')), 'branch evidence contains symlink')
    command = json.loads((root / 'command.json').read_text())
    analysis = json.loads((root / 'analysis.json').read_text())
    source_path = Path(command['source_profile']).resolve(strict=True)
    require(sha(source_path) == command['source_profile_sha256'], 'source profile changed')
    summary = json.loads(source_path.read_text())
    source_audit_sha = sha(args.source_audit)
    audit = json.loads(args.source_audit.read_text())
    require(audit['status'] == 'passed' and audit['exploratory'] is True
            and audit['profile_summary_sha256'] == command['source_profile_sha256'], 'source profile lacks matching independent audit')
    require(command['status'] == 'passed' and command['exploratory'] is True and summary['status'] == 'passed'
            and summary['complete'] and summary['input_guards_passed'] and summary['exploratory'] is True, 'branch/source profile incomplete')
    require(sha(args.helper) == command['helper_sha256'] and sha(PARSERS) == PARSERS_SHA256, 'helper/parser changed')
    # The branch probe has top-level execution. It is only read/hashed, never imported.
    independent = runpy.run_path(str(PARSERS), run_name='branch_audit_independent_oracle')
    case = summary['cases']['128']['case']
    stdout, expected_files = independent['independent_oracle'](case)
    binary = Path(summary['guarded_inputs']['binary']['path']).resolve(strict=True)
    require(sha(binary) == command['binary_sha256'] == summary['guarded_inputs']['binary']['sha256'], 'exact exploratory binary differs')
    prior, = [item for item in summary['profiles'] if item['engine'] == 'imre' and item['tool'] == 'callgrind']
    expected_command = [prior['command'][0], '--tool=callgrind', '--command-line-only=yes', '--num-callers=32',
                        '--error-exitcode=97', '--branch-sim=yes', '--dump-instr=yes', '--collect-jumps=yes',
                        '--log-file=' + str(root / 'valgrind.log'), '--callgrind-out-file=' + str(root / 'profile.callgrind'),
                        str(binary), *case['arguments']]
    require(command['command'] == expected_command and command['environment'] == summary['environment']
            and Path(command['cwd']).resolve(strict=True) == root / 'work', 'branch probe command/environment differs')
    file_metadata = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in expected_files.items()}
    require(command['validation'] == {'returncode': 0, 'stdout': stdout, 'stderr': '', 'files': file_metadata, 'directories': []}, 'independent complete output differs')
    require((root / 'stdout.txt').read_bytes() == stdout.encode() and (root / 'stderr.txt').read_bytes() == b'', 'retained process output differs')
    require({path.relative_to(root / 'work').as_posix(): path.read_bytes() for path in (root / 'work').rglob('*') if path.is_file()} == expected_files, 'retained filesystem differs')
    require(not any(path.is_dir() for path in (root / 'work').iterdir()), 'unexpected output directory')
    profile = root / 'profile.callgrind'
    require(sha(profile) == command['profile_sha256'] == analysis['profile_sha256'], 'branch profile changed')
    raw_commands = [line.partition(':')[2].strip() for line in profile.read_text().splitlines() if line.startswith('cmd:')]
    require(len(raw_commands) == 1 and shlex.split(raw_commands[0]) == [str(binary), *case['arguments']], 'raw profile command differs')
    total, functions, locations = parse_branches(profile)
    function = analysis['function']
    require(function == 'fn_7' and analysis['records'] == 4096 and analysis['queries'] == 128 and analysis['inspected_pairs'] == 524288, 'unexpected branch analysis scope')
    require(functions[function][1:3] == [analysis['conditional_branches'], analysis['simulated_conditional_misses']], 'function branch counts differ')
    address = int(analysis['sign_branch']['relative_binary_address'], 16)
    require(locations[(function, address)][2] == analysis['sign_branch']['simulated_misses'], 'sign branch simulated misses differ')
    worst = max((values[2], location) for (name, location), values in locations.items() if name == function)
    require(worst == (analysis['sign_branch']['simulated_misses'], address), 'claimed sign branch is not the largest simulated miss site')
    tool = args.objdump.resolve(strict=True)
    tool_sha = sha(tool)
    disassemble = [str(tool), '-d', '--start-address=' + hex(address), '--stop-address=' + hex(address + 16), str(binary)]
    result = subprocess.run(disassemble, capture_output=True, text=True, check=True)
    require(not result.stderr, 'objdump stderr is nonempty')
    row, = [line for line in result.stdout.splitlines() if re.match(r'\s*' + format(address, 'x') + ':', line)]
    require(re.search(r'\bjle\b', row) and analysis['sign_branch']['instruction'] == 'jle', 'native instruction does not match claimed sign branch')
    require(sha(binary) == command['binary_sha256'] and sha(tool) == tool_sha and sha(args.helper) == command['helper_sha256'], 'probe/disassembly input changed')
    require(files == {path.relative_to(root).as_posix(): sha(path) for path in root.rglob('*') if path.is_file()}, 'branch evidence bytes/membership changed')
    require(sha(__file__) == script_sha and sha(PARSERS) == PARSERS_SHA256
            and sha(source_path) == command['source_profile_sha256'] and sha(args.source_audit) == source_audit_sha, 'audit/source evidence changed')
    report = {'schema': 1, 'kind': 'exploratory-branch-simulation-audit', 'status': 'passed', 'exploratory': True,
              'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'directory': str(root),
              'source_revision': summary['timing_revision'], 'source_profile_sha256': command['source_profile_sha256'],
              'source_audit': str(args.source_audit.resolve()), 'source_audit_sha256': source_audit_sha,
              'helper_sha256': command['helper_sha256'], 'binary_sha256': command['binary_sha256'],
              'profile_sha256': command['profile_sha256'], 'audit_script_sha256': script_sha,
              'parser_dependency_sha256': PARSERS_SHA256, 'files': files,
              'events': ['Ir', 'Bc', 'Bcm', 'Bi', 'Bim'], 'whole_process_self_totals': total,
              'function': function, 'function_self_totals': functions[function],
              'largest_conditional_miss_site': {'address': hex(address), 'self_events': locations[(function, address)]},
              'disassembly': {'command': disassemble, 'tool_sha256': tool_sha, 'stdout': result.stdout, 'matched_line': row},
              'complete_oracle_verified': True, 'raw_counts_independently_recomputed': True,
              'limits': 'Exploratory Callgrind predictor simulation, not hardware counters or final timing. Native disassembly identifies the instruction but does not establish its wall-time cost. The probe retained the prior Valgrind command path/environment but did not independently recapture all profiler tool hashes at probe time.'}
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'audit': str(args.output), 'sha256': sha(args.output), 'status': 'passed'}))


if __name__ == '__main__':
    main()
