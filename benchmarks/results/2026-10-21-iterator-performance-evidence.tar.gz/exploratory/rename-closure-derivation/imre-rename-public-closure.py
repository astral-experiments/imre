"""Write a compact public rename closure from retained audits; no API/Git writes."""
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

PATHS = {
    'source_audit': '/tmp/imre-rename-source-audit.json',
    'validation_audit': '/tmp/imre-rename-validation-audit.json',
    'metadata_plan_audit': '/tmp/imre-rename-metadata-plan-audit-v2.json',
    'metadata_publication': '/tmp/imre-rename-metadata-publication.json',
    'history_publication': '/tmp/imre-publication-progress.json',
    'local_installation': '/tmp/imre-local-install.json',
    'published_head_ci_inventory': '/tmp/imre-ci-current-heads-20261020T211759Z.json',
    'retry_terminal': '/tmp/imre-base45-ci-retry-status.json',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    script_sha = sha(__file__)
    identities = {name: sha(path) for name, path in PATHS.items()}
    values = {name: json.loads(Path(path).read_text()) for name, path in PATHS.items()}
    source, validation, metadata = [values[key] for key in ('source_audit', 'validation_audit', 'metadata_plan_audit')]
    publish, local, ci = [values[key] for key in ('history_publication', 'local_installation', 'published_head_ci_inventory')]
    journal, retry = [values[key] for key in ('metadata_publication', 'retry_terminal')]
    assert all(values[key]['status'] == 'passed' for key in PATHS if key not in ('history_publication', 'retry_terminal'))
    assert publish['status'] == 'pushed' and publish['atomic_push_passed'] and publish['remote_heads_verified']
    assert publish['repository_id'] == journal['repository_id'] == ci['repository_id'] == 1423429334
    assert source['tip'] == metadata['tip'] == validation['validation_revision'] == '1cc6d47b1d21c523e5bcd701f180724b679014e8'
    assert local['history_map_sha256'] == publish['history_map_sha256'] == metadata['history_map_sha256']
    assert local['refs_verified'] == source['counts']['refs'] == 143
    assert local['worktrees_verified'] == len(local['worktrees']) == 19 and local['upstreams_preserved']
    assert source['counts']['mapped_commits'] == 260 and source['counts']['heads'] == 85
    assert metadata['pr_count'] == 57 and metadata['changed_pr_count'] == len(journal['operations']) == 34
    assert journal['plan_sha256'] == metadata['plan_sha256']
    assert metadata['all_navigation_targets_verified_in_rewritten_git'] and metadata['bare_sha_mentions_preserved']
    assert ci['published_heads_stable'] and len(ci['heads']) == ci['published_head_count'] == 58
    assert {head['branch']: head['sha'] for head in ci['heads']} == publish['remote_heads'] == publish['expected_remote_heads']
    run = retry['run']
    assert run['id'] == 39491300421 and run['run_attempt'] == 2 and run['status'] == 'completed' and run['conclusion'] == 'success'
    assert not retry['execution_timeout']
    heads = []
    for head in ci['heads']:
        latest = head.get('latest')
        if latest and latest['id'] == run['id']:
            assert run['head_sha'] == head['sha'] and run['head_branch'] == head['branch']
            latest = run
        if latest:
            assert latest['head_sha'] == head['sha'] and latest['status'] == 'completed' and latest['conclusion'] == 'success'
            heads.append('success')
        else:
            assert head['branch'] in ('main', 'charlie/language-contract')
            heads.append('no_ci_workflow')
    assert Counter(heads) == {'success': 56, 'no_ci_workflow': 2}
    report = {
        'schema': 1, 'kind': 'public-imre-rename-closure', 'status': 'passed',
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'repository': 'viarius-experiments/imre', 'repository_id': 1423429334,
        'stack_number': 4, 'stack_node_id': journal['native_stack_id'],
        'renamed_public_tip': source['tip'],
        'counts': {'rewritten_commits': 260, 'local_heads': 85, 'local_and_tracking_refs': 143,
                   'published_heads': 58, 'preserved_stack_prs': 57, 'updated_pr_texts': 34,
                   'moved_worktrees': 19, 'successful_ci_heads': 56, 'heads_without_ci_workflow': 2,
                   'rename_validation_jobs': validation['counts']['passed_jobs'],
                   'rename_rust_unit_tests': validation['counts']['rust_units']['total']},
        'checks': {'atomic_publication': True, 'remote_head_shas_verified': True,
                   'upstreams_preserved': True, 'metadata_readback_passed': True,
                   'report_navigation_links_resolve': True, 'historical_bare_sha_mentions_preserved': True},
        'ci_retry': {key: run[key] for key in ('id', 'run_attempt', 'head_sha', 'status', 'conclusion', 'html_url')},
        'heads_without_ci_workflow': ['main', 'charlie/language-contract'],
        'input_audit_sha256': identities, 'closure_script_sha256': script_sha,
        'scope': 'Public identities, verified aggregate counts, audit hashes, and terminal CI linkage only. Local paths, private branch inventories, Git configuration, credentials, and backup bundles are excluded. CI closure covers the 58 renamed published heads before the subsequent performance PRs.',
    }
    assert identities == {name: sha(path) for name, path in PATHS.items()} and sha(__file__) == script_sha
    output = Path('/tmp/imre-rename-public-closure.json')
    with output.open('x') as stream:
        json.dump(report, stream, indent=2); stream.write('\n')
    print(json.dumps({'path': str(output), 'sha256': sha(output), 'counts': report['counts']}))


if __name__ == '__main__':
    main()
