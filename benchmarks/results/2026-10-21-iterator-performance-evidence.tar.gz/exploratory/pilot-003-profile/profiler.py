"""Profile the exact timed ThinLTO telemetry binaries; never build or time them.

Run only after all wall-time measurements have stopped:
  python3 -I -B /tmp/imre-telemetry-profile.py \
    --timing-status /tmp/imre-telemetry-candidate-002/pilot-status.json \
    --output /tmp/imre-telemetry-candidate-002-profile

This helper accepts completed exploratory pilots and labels them explicitly.

The six whole-process profiles are Callgrind and DHAT at 128 alert-quiet-4096
queries for each engine, plus DHAT at 256 queries. The latter pair distinguishes
allocation growth per query from fixed startup/input-loading work. Inputs come
from the completed timed workload; only its repeat argument changes. Every run
is checked by the independent telemetry oracle, including complete stdout,
checksum, stderr, and all filesystem effects. No program source is modified.
"""

import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import subprocess
import sys
from types import SimpleNamespace


CACHE = Path("/home/dev-user/.cache/onyx/profiling-tools/root/usr")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def now():
    return datetime.now(timezone.utc).isoformat()


def callgrind_metrics(path):
    """Count self instructions separately from overlapping inclusive call edges."""
    lines = path.read_text().splitlines()
    require(lines.count("positions: instr line") == lines.count("events: Ir") == 1,
            "unexpected Callgrind layout")
    totals = [int(line.split()[1]) for line in lines if line.startswith("summary:")]
    require(len(totals) == 1 and totals[0] > 0, "incomplete Callgrind profile")
    names = {}
    for line in lines:
        match = re.fullmatch(r"c?fn=\((\d+)\) (.+)", line)
        if match:
            require(match[1] not in names or names[match[1]] == match[2], "function ID changed")
            names[match[1]] = match[2]
    costs, calls, inclusive = Counter(), Counter(), Counter()
    function = callee = None
    edge = False
    for line in lines:
        match = re.fullmatch(r"(c?fn)=\((\d+)\)(?: .+)?", line)
        if match:
            if match[1] == "fn":
                function, edge = names[match[2]], False
            else:
                callee = names[match[2]]
        elif line.startswith("calls="):
            require(callee is not None, "call edge has no callee")
            calls[callee] += int(line.split()[0].split("=")[1])
            edge = True
        else:
            match = re.fullmatch(r"(?:0x[0-9a-f]+|[+-]\d+|\*|\d+)\s+(?:[+-]?\d+|\*)\s*(\d*)", line)
            if match:
                count = int(match[1] or 0)
                if edge:
                    inclusive[callee] += count
                    edge = False
                else:
                    require(function is not None, "instruction count has no function")
                    costs[function] += count
    require(sum(costs.values()) == totals[0], "self costs do not sum to instructions")
    return {"instructions": totals[0], "self_cost_sum": sum(costs.values()),
            "functions": [{"name": name, "self_instructions": count,
                           "self_fraction": count / totals[0], "calls": calls[name],
                           "incoming_inclusive_instructions": inclusive[name]}
                          for name, count in costs.most_common()]}


def dhat_metrics(path):
    heap = json.loads(path.read_text())
    require(heap["mode"] == "heap" and heap["tu"] == "instrs", "unexpected DHAT layout")
    points = heap["pps"]
    return {**{name: sum(point[key] for point in points) for name, key in (
        ("allocated_bytes", "tb"), ("allocated_blocks", "tbk"),
        ("peak_live_bytes", "gb"), ("peak_live_blocks", "gbk"),
        ("exit_live_bytes", "eb"), ("exit_live_blocks", "ebk"))},
        "top_allocation_stacks": [
            {"bytes": point["tb"], "blocks": point["tbk"],
             "frames": [heap["ftbl"][index] for index in point["fs"]]}
            for point in sorted(points, key=lambda point: point["tb"], reverse=True)[:20]]}


def main():
    require(sys.flags.optimize == 0, "Run profiles without Python -O; complete oracle checks use assertions")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preparation", type=Path, help="infer from the completed timing command by default")
    parser.add_argument("--record", type=Path, help="infer from the completed ThinLTO timing run by default")
    parser.add_argument("--plan", type=Path, help="infer from timing status by default")
    parser.add_argument("--timing-status", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--valgrind", type=Path, default=CACHE / "bin/valgrind")
    parser.add_argument("--valgrind-lib", type=Path, default=CACHE / "libexec/valgrind")
    parser.add_argument("--annotate", type=Path, default=CACHE / "bin/callgrind_annotate")
    parser.add_argument("--timeout", type=float, default=900)
    args = parser.parse_args()
    require(args.timeout > 0, "timeout must be positive")
    tracer = next(line.split(":")[1] for line in Path("/proc/self/status").read_text().splitlines()
                  if line.startswith("TracerPid:"))
    require(int(tracer) == 0, "run Valgrind outside the ptrace sandbox")
    timing = json.loads(args.timing_status.read_text())
    require(timing["status"] == "passed" and timing["input_guards_passed"], "timing is incomplete")
    require(timing.get("phase") == "pilot" and timing.get("exploratory") is True,
            "this helper requires a completed exploratory pilot")
    exploratory = True
    args.plan = (args.plan or Path(timing["plan"])).resolve(strict=True)
    require(args.plan == Path(timing["plan"]).resolve(strict=True)
            and sha(args.plan) == timing["plan_sha256"], "candidate plan differs from timing")
    plan = json.loads(args.plan.read_text())
    require(plan["status"] == "planned" and plan["input_guards_passed"]
            and plan["revision"] == timing["revision"], "candidate plan is incomplete")
    plan_paths = {name: Path(value) for name, value in plan["protected_paths"].items()}
    require({name: sha(path) for name, path in plan_paths.items()} == plan["protected_sha256"],
            "candidate source/build/tool evidence changed")
    run, = [item for item in timing["runs"] if item["mode"] == "thinlto"]
    args.record = (args.record or Path(run["output"])).resolve(strict=True)
    require(run["status"] == "passed" and run["exit_code"] == 0
            and Path(run["output"]).resolve() == args.record.resolve()
            and run["output_sha256"] == sha(args.record), "record differs from completed timing")
    require(run["command"] == plan["commands"]["pilot"], "pilot command differs from candidate plan")
    command_preparation = Path(run["command"][run["command"].index("--prepared-record") + 1]).resolve(strict=True)
    args.preparation = (args.preparation or command_preparation).resolve(strict=True)
    require(args.preparation == command_preparation, "preparation path differs from timing command")
    prepared = json.loads(args.preparation.read_text())
    record = json.loads(args.record.read_text())
    preparation_status_path = Path(plan["output"]) / "prepare-status.json"
    preparation_status = json.loads(preparation_status_path.read_text())
    require(preparation_status["status"] == "passed" and preparation_status["input_guards_passed"]
            and preparation_status["plan_sha256"] == sha(args.plan), "candidate preparation is incomplete")
    prepared_run, = [item for item in preparation_status["runs"] if item["mode"] == "thinlto"]
    require(prepared_run["status"] == "passed" and prepared_run["exit_code"] == 0
            and prepared_run["command"] == plan["commands"]["prepare"]["thinlto"]
            and Path(prepared_run["output"]).resolve() == args.preparation
            and prepared_run["output_sha256"] == sha(args.preparation), "preparation differs from completed preparation phase")
    require(record["kind"] == "telemetry-benchmark" and record["input_guards_passed"]
            and record["completed_at_utc"] and record["thinlto"] and not record["dirty"],
            "benchmark is incomplete or not clean ThinLTO")
    require(record["preparation"] == prepared
            and record["preparation_record_sha256"] == sha(args.preparation)
            and prepared["kind"] == "telemetry-preparation" and prepared["input_guards_passed"]
            and prepared["thinlto"] and not prepared["dirty"]
            and prepared["revision"] == record["revision"] == timing["revision"],
            "preparation does not match timing")
    require(record["workload_selection"]["input_guards_passed"]
            and record["workload_selection"]["canonical_input_and_repetition_checks_passed"],
            "pilot input selection guards did not pass")
    paths = {name: Path(value).absolute() for name, value in prepared["source_and_tool_paths"].items()}
    hashes = prepared["source_and_tool_sha256"]
    require(record["source_and_tool_sha256"] == hashes and set(paths) == set(hashes),
            "timed source/tool identities differ")
    require({name: sha(path) for name, path in paths.items()} == hashes, "timed input changed")
    binaries = {"imre": Path(prepared["binary"]).resolve(strict=True), "rust": paths["rust"]}
    require(sha(binaries["imre"]) == prepared["binary_sha256"] == record["binary_sha256"]
            and sha(binaries["rust"]) == hashes["rust"], "timed native binary changed")
    for key in ("llvm", "validation"):
        path = Path(prepared["validation_path" if key == "validation" else key])
        require(sha(path) == prepared[key + "_sha256"], f"prepared {key} changed")
        paths["prepared_" + key] = path
    require(json.loads(paths["prepared_validation"].read_text()) == prepared["validation"],
            "prepared validation snapshot changed")
    build = json.loads(paths["imre_build_record"].read_text())
    rust_build = json.loads(paths["rust_build_record"].read_text())
    require(build == prepared["imre_build_record"] and build["input_guards_passed"]
            and build["source_matches_revision"] and build["revision"] == timing["revision"]
            and build["sha256"]["compiler"] == hashes["compiler"]
            and build["sha256"]["thinlto_runtime"] == hashes["runtime"], "compiler/runtime build provenance differs")
    require(rust_build == prepared["rust_build_record"] and rust_build["input_guards_passed"]
            and rust_build["thinlto"] and rust_build["binary_sha256"] == hashes["rust"],
            "Rust build provenance differs")
    paths["validation_index"] = plan_paths["validation_index"]
    index = json.loads(paths["validation_index"].read_text())
    require(index["status"] == "passed" and index["input_guards_passed"] and index["source_unchanged"]
            and index["revision"] == build["revision"]
            and index["build_record"]["sha256"] == hashes["imre_build_record"]
            and sha(paths["validation_index"]) == plan["protected_sha256"]["validation_index"],
            "completed compiler validation differs")
    full_validation = index.get("full_validation_passed", index.get("mode") != "build-only")
    require(full_validation == plan["validation_full_matrix_passed"] == timing["validation_full_matrix_passed"],
            "validation scope differs from timing")
    validator = SimpleNamespace(**runpy.run_path(str(paths["validator"])))
    workload, = [value for value in record["workloads"] if value["label"] == "alert-quiet-4096"]
    require(workload["scenario"] == "alert-quiet" and int(workload["label"].rsplit("-", 1)[1]) == 4096
            and workload["inspected_pairs_per_call"] == 4096, "unexpected workload")
    baseline = json.loads(plan_paths["baseline"].read_text())
    baseline_workload, = [value for value in baseline["workloads"] if value["label"] == "alert-quiet-4096"]
    require(all(workload[field] == baseline_workload[field] for field in
                ("scenario", "inspected_pairs_per_call", "repetitions", "case", "expected_stdout", "expected_files")),
            "profile inputs or repetitions differ from the frozen canonical workload")
    original = validator.case_from_record(workload["case"])
    expected = validator.oracle(original)
    require(expected["stdout"] == workload["expected_stdout"]
            and validator.encoded_files(expected["files"]) == workload["expected_files"]
            and expected["files"]["report.txt"] == b"False\n", "independent timed oracle differs")
    cases = {}
    for repeats in (128, 256):
        value = deepcopy(workload["case"])
        require(len(value["arguments"]) == 6 and value["arguments"][0] == "alert", "unexpected query arguments")
        value["arguments"][-1] = str(repeats)
        case = validator.case_from_record(value)
        cases[repeats] = (case, validator.oracle(case))
    library = args.valgrind_lib.resolve(strict=True)
    tools = {"valgrind": args.valgrind.resolve(strict=True), "annotate": args.annotate.resolve(strict=True),
             "valgrind_binary": args.valgrind.parent.resolve(strict=True) / "valgrind.bin",
             "callgrind": library / "callgrind-amd64-linux", "dhat": library / "dhat-amd64-linux",
             "core_preload": library / "vgpreload_core-amd64-linux.so",
             "dhat_preload": library / "vgpreload_dhat-amd64-linux.so",
             "perl": Path("/usr/bin/perl").resolve(strict=True),
             "shell": Path("/bin/sh").resolve(strict=True), "python": Path(sys.executable).resolve(strict=True)}
    paths.update({"tool_" + name: path for name, path in tools.items()})
    paths.update(preparation=args.preparation.resolve(strict=True), benchmark=args.record.resolve(strict=True),
                 timing_status=args.timing_status.resolve(strict=True), binary=binaries["imre"],
                 profiler=Path(__file__).resolve(strict=True), candidate_plan=args.plan,
                 preparation_status=preparation_status_path)
    paths.update({"candidate_" + name: path for name, path in plan_paths.items()})
    guarded = {name: {"path": str(path), "sha256": sha(path)} for name, path in paths.items()}

    def guard():
        require(all(sha(paths[name]) == value["sha256"] for name, value in guarded.items()),
                "profile input changed")
        root = Path(plan["root"])
        head = subprocess.check_output(["git", "-C", root, "rev-parse", "HEAD"], text=True).strip()
        dirty = subprocess.check_output(["git", "-C", root, "status", "--porcelain=v1", "--untracked-files=all"], text=True).strip()
        require(head == record["revision"] and not dirty, "profile checkout changed")

    output = args.output.resolve()
    require(Path("/tmp") in output.parents, "profiles must be written under /tmp")
    output.mkdir(parents=True, exist_ok=False)
    snapshots = {"preparation.json": args.preparation, "benchmark-record.json": args.record,
                 "timing-status.json": args.timing_status, "imre-build-record.json": paths["imre_build_record"],
                 "rust-build-record.json": paths["rust_build_record"], "validation-index.json": paths["validation_index"],
                 "prepared-validation.json": paths["prepared_validation"], "native.ll": paths["prepared_llvm"],
                 "profiler.py": Path(__file__), "candidate-plan.json": args.plan,
                 "preparation-status.json": preparation_status_path}
    for name in ("validator", "filesystem_validator", "batch_validator", "incremental_validator", "shared_validator"):
        snapshots["oracle-" + paths[name].name] = paths[name]
    for name, path in snapshots.items():
        shutil.copyfile(path, output / name)
        require(sha(output / name) == sha(path), "profile snapshot copy differs")
    snapshot_hashes = {name: sha(output / name) for name in snapshots}
    environment = {"VALGRIND_LIB": str(library), "VALGRIND_OPTS": "", "LC_ALL": "C"}
    env = {**os.environ, **environment}
    summary = {"schema": 1, "status": "running", "complete": False, "input_guards_passed": False,
               "started_at_utc": now(), "label": "alert-quiet-4096", "thinlto": True,
               "exploratory": exploratory, "profile_context": "exploratory-pilot",
               "timing_revision": record["revision"], "build_revision": build["revision"],
               "validation_revision": index["revision"], "validation_mode": index.get("mode", "full-validation"),
               "validation_scope": index["scope"], "full_validation_passed": full_validation,
               "candidate_plan_sha256": sha(args.plan), "canonical_baseline_record_sha256": sha(plan_paths["baseline"]),
               "benchmark_record_sha256": sha(args.record), "preparation_record_sha256": sha(args.preparation),
               "timing_status_sha256": sha(args.timing_status), "snapshot_sha256": snapshot_hashes,
               "guarded_inputs": guarded, "environment": environment, "profiles": [],
               "cases": {str(repeats): {"case": validator.case_record(case), "pairs": repeats * 4096,
                                        "expected_stdout": oracle["stdout"],
                                        "expected_files": validator.encoded_files(oracle["files"]),
                                        "expected_directories": oracle["directories"]}
                         for repeats, (case, oracle) in cases.items()},
               "method": "Exact timed ThinLTO Imre/Rust binaries; whole-process Callgrind and DHAT at 128 queries, DHAT again at 256. Original timed input bytes, only repeat argument changed. Independent complete stdout/checksum/filesystem oracle after every process. No wall-time samples or builds.",
               "limits": "Callgrind Ir counts guest instructions, not CPU cycles or wall-time speedup. Inclusive costs overlap. DHAT counts requested heap bytes/blocks, not RSS; gb/gbk share the global peak. Exit-live counts alone do not establish leaks. Two-count allocation slopes are descriptive, not a proof of linearity."}
    write_json(output / "summary.json", summary)
    try:
        for engine, binary in binaries.items():
            for tool, repeats in (("callgrind", 128), ("dhat", 128), ("dhat", 256)):
                guard()
                directory = output / f"{engine}-{tool}-{repeats}"
                work = directory / "work"
                work.mkdir(parents=True)
                case, oracle = cases[repeats]
                validator.materialize(case, work)
                (work / "report.txt").write_bytes(b"replace this complete report")
                profile = directory / ("profile.callgrind" if tool == "callgrind" else "profile.json")
                command = [str(tools["valgrind"]), f"--tool={tool}", "--command-line-only=yes",
                           "--num-callers=32", "--error-exitcode=97", f"--log-file={directory / 'valgrind.log'}",
                           f"--{tool}-out-file={profile}"]
                if tool == "callgrind":
                    command += ["--dump-instr=yes", "--collect-jumps=yes"]
                command += [str(binary), *case.arguments]
                item = {"engine": engine, "tool": tool, "repetitions": repeats, "pairs": repeats * 4096,
                        "command": command, "cwd": str(work), "environment": environment,
                        "binary_sha256": sha(binary), "started_at_utc": now()}
                write_json(directory / "command.json", item)
                process = subprocess.run(command, input=b"", capture_output=True, cwd=work, env=env,
                                         timeout=args.timeout, check=False)
                (directory / "stdout.txt").write_bytes(process.stdout)
                (directory / "stderr.txt").write_bytes(process.stderr)
                item.update(returncode=process.returncode, completed_at_utc=now())
                write_json(directory / "command.json", item)
                item["validation"] = validator.check_result(case, oracle, process, work)
                item["metrics"] = callgrind_metrics(profile) if tool == "callgrind" else dhat_metrics(profile)
                if tool == "callgrind":
                    item["annotations"] = []
                    for inclusive in ("no", "yes"):
                        command = [str(tools["annotate"]), "--auto=no", f"--inclusive={inclusive}",
                                   "--threshold=100", str(profile)]
                        annotation = subprocess.run(command, capture_output=True, cwd=work, env=env,
                                                    timeout=args.timeout, check=False)
                        (directory / f"inclusive-{inclusive}.txt").write_bytes(annotation.stdout)
                        (directory / f"inclusive-{inclusive}-stderr.txt").write_bytes(annotation.stderr)
                        require(annotation.returncode == 0, "Callgrind annotation failed")
                        item["annotations"].append({"command": command, "returncode": annotation.returncode})
                item["status"] = "validated"
                write_json(directory / "command.json", item)
                item["files"] = {path.relative_to(directory).as_posix(): sha(path)
                                 for path in sorted(directory.rglob("*")) if path.is_file()}
                summary["profiles"].append(item)
                guard()
                write_json(output / "summary.json", summary)
                print(f"Validated {engine}/{tool}/{repeats}", flush=True)
        require(len(summary["profiles"]) == 6, "profile matrix is incomplete")
        summary["allocation_growth"] = {}
        for engine in binaries:
            values = {item["repetitions"]: item["metrics"] for item in summary["profiles"]
                      if item["engine"] == engine and item["tool"] == "dhat"}
            summary["allocation_growth"][engine] = {
                key: {"at_128_queries": values[128][key], "at_256_queries": values[256][key],
                      "per_additional_query": (values[256][key] - values[128][key]) / 128,
                      "two_point_fixed_estimate": 2 * values[128][key] - values[256][key]}
                for key in ("allocated_bytes", "allocated_blocks")}
        for item in summary["profiles"]:
            directory = output / f"{item['engine']}-{item['tool']}-{item['repetitions']}"
            require(all(sha(directory / name) == value for name, value in item["files"].items()),
                    "retained profile artifact changed")
        require(all(sha(output / name) == value for name, value in snapshot_hashes.items()),
                "retained provenance snapshot changed")
        guard()
        summary.update(status="passed", complete=True, input_guards_passed=True, completed_at_utc=now())
        write_json(output / "summary.json", summary)
        write_json(output / "manifest.json", {path.relative_to(output).as_posix(): sha(path)
                                              for path in sorted(output.rglob("*")) if path.is_file()})
    except BaseException as error:
        summary.update(status="failed", failure=f"{type(error).__name__}: {error}")
        write_json(output / "summary.json", summary)
        raise
    print(output / "summary.json", flush=True)


if __name__ == "__main__":
    main()
