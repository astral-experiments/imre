"""Build and validate one clean Relar revision; run outside ptrace for LeakSanitizer.

Every suite uses copied artifacts produced by this run's successful Cargo builds.
Reference builders also run against the frozen current sources. This is correctness
validation, not a timing experiment. No tracked repository file is modified.
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

SUITES = """differential imports classes containers comprehensions fstrings calls
inference iterables expressions floats bytes matching assignments truthiness
loop_else unpacking primitives string_reuse decoder_optimizations unions
module_values base45 luhn exceptions io files""".split()
assert len(SUITES) == 27
APPLICATIONS = {
    "route": ("route_planner.py", "validate.py"),
    "dependency": ("dependency_planner/__main__.py", "dependency_validate.py"),
    "incremental": ("incremental_planner/__main__.py", "incremental_validate.py"),
    "batch": ("batch_planner/__main__.py", "batch_validate.py"),
    "manifest": ("manifest_planner/__main__.py", "manifest_validate.py"),
    "inventory": ("inventory_reconciliation/__main__.py", "inventory_validate.py"),
}
REFERENCE_SPECS = [
    ("dependency", "dependency_planner", []),
    ("incremental", "incremental_planner", []),
    ("batch", "incremental_planner", ["--batch"]),
    ("manifest", "incremental_planner", ["--manifest"]),
    ("inventory", "inventory_reconciliation", []),
    ("base45-normal", "base45_codec", []),
    ("base45-thinlto", "base45_codec", ["--llvm-budget", "1000"]),
    ("luhn-normal", "luhn_checksum", []),
    ("luhn-thinlto", "luhn_checksum", ["--thinlto"]),
]
ENV_KEYS = """PATH CARGO_HOME CARGO_TARGET_DIR CARGO_BUILD_BUILD_DIR
CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST
RUSTFLAGS RUSTC_BOOTSTRAP ASAN_OPTIONS PYTHONDONTWRITEBYTECODE""".split()


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def executable(value):
    # Preserve linker argv[0]; gcc-ld/ld.lld selects its linker flavor by name.
    path = Path(value if "/" in str(value) else shutil.which(value) or value).absolute()
    if not path.is_file() or not os.access(path, os.X_OK):
        raise ValueError(f"not an executable: {path}")
    return path


class Validation:
    def __init__(self, args):
        self.args = args
        self.root = args.root.resolve(strict=True)
        required = [self.root / f"tests/{suite}.py" for suite in SUITES]
        required += [self.root / "tests/lto.py"]
        required += [self.root / f"benchmarks/reference/{package}/build.py" for _, package, _ in REFERENCE_SPECS]
        missing = [str(path) for path in required if not path.is_file()]
        if missing:
            raise ValueError("validation source files are missing: " + ", ".join(missing))
        self.output = args.output.resolve()
        self.target = args.target_dir.resolve()
        self.shared = args.build_cache.resolve()
        for generated in (self.output, self.target, self.shared):
            if generated == self.root or self.root in generated.parents:
                raise ValueError(f"validation outputs must be outside the checkout: {generated}")
        for left, right in ((self.output, self.target), (self.output, self.shared), (self.target, self.shared)):
            if left == right or left in right.parents or right in left.parents:
                raise ValueError("output, target, and shared-cache directories must be separate")
        self.output.mkdir(parents=True, exist_ok=False)
        self.lock = threading.Lock()
        self.tools = {name: executable(value) for name, value in {
            "python": args.python, "runner_python": sys.executable, "clang": args.clang,
            "git": "git", "cargo": "cargo", "rustc": "rustc", "rustup": "rustup",
            "ar": "ar", "nm": "nm",
        }.items()}
        self.environment = dict(os.environ)
        for name in list(self.environment):
            if name.startswith("CARGO_PROFILE_") or name.endswith("_RUSTFLAGS") or name in {
                "RUSTFLAGS", "RUSTDOCFLAGS", "RUSTC", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER",
                "RUSTC_BOOTSTRAP", "RUSTUP_TOOLCHAIN", "CARGO_BUILD_TARGET", "CARGO_BUILD_RUSTC",
                "CARGO_BUILD_RUSTC_WRAPPER", "CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER",
            }:
                self.environment.pop(name)
        self.environment.update(
            CARGO_HOME=str(args.cargo_home), CARGO_TARGET_DIR=str(self.target),
            CARGO_BUILD_BUILD_DIR=str(self.shared), CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST="all",
            CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST="all", RUSTFLAGS="",
            ASAN_OPTIONS="detect_leaks=1:halt_on_error=1", PYTHONDONTWRITEBYTECODE="1",
            GIT_OPTIONAL_LOCKS="0",
        )
        self.cargo = [self.tools["cargo"], "+ohm", "-Zohm-defaults=no"]
        self.frozen = {}
        self.references = {}
        self.before = self.source_identity()
        self.runner = self.output / "runner.py"
        shutil.copy2(Path(__file__), self.runner)
        write_json(self.output / "source-before.json", self.before)
        self.index = {
            "schema": 1, "status": "running", "started_at": now(),
            "revision": args.revision, "root": str(self.root), "invocation": sys.orig_argv,
            "runner_sha256": digest(self.runner), "source_manifest": "source-before.json",
            "source_manifest_sha256": digest(self.output / "source-before.json"),
            "scope": "27 suites: ordinary O0/O3, ThinLTO O3, ASan O0/O1; explicit LTO checks; six ordinary O3 application oracles; freshly built Rust references. No benchmark timings.",
            "environment": {name: self.environment.get(name) for name in ENV_KEYS},
            "workers": args.workers, "jobs": [], "artifacts": {}, "references": {},
        }
        self.save()

    def git(self, *args):
        return subprocess.check_output([self.tools["git"], "-C", self.root, *args], env=self.environment)

    def source_identity(self):
        revision = self.git("rev-parse", "HEAD").decode().strip()
        if revision != self.args.revision:
            raise RuntimeError(f"expected frozen revision {self.args.revision}, found {revision}")
        status = self.git("status", "--porcelain=v1", "--untracked-files=all").decode()
        if status:
            raise RuntimeError(f"frozen checkout is dirty:\n{status}")
        files = {}
        for name in self.git("ls-files", "-z").decode().split("\0"):
            if not name or name.startswith("benchmarks/results/"):
                continue
            path = self.root / name
            files[name] = ({"symlink": os.readlink(path)} if path.is_symlink() else {
                "sha256": digest(path), "executable": bool(path.stat().st_mode & 0o111),
            })
        return {"revision": revision, "tree": self.git("rev-parse", "HEAD^{tree}").decode().strip(),
                "status": status, "files": files,
                "scope": "All tracked paths except historical benchmarks/results evidence; clean Git tree identity covers that evidence too."}

    def guard(self):
        if self.source_identity() != self.before:
            raise RuntimeError("frozen source changed")
        if digest(self.runner) != self.index["runner_sha256"] or digest(Path(__file__)) != self.index["runner_sha256"]:
            raise RuntimeError("validation runner changed")
        for path, expected in self.frozen.items():
            if digest(path) != expected:
                raise RuntimeError(f"frozen tool/artifact changed: {path}")

    def save(self):
        write_json(self.output / "index.json", self.index)

    def command(self, name, command, *, environment=None, timeout=None):
        command = [str(value) for value in command]
        directory = self.output / "jobs" / name
        directory.mkdir(parents=True, exist_ok=False)
        env = {**self.environment, **(environment or {})}
        record = {"name": name, "command": command, "cwd": str(self.root),
                  "environment_overrides": environment or {}, "started_at": now(),
                  "stdout": str(directory / "stdout"), "stderr": str(directory / "stderr")}
        write_json(directory / "command.json", record)
        started = time.monotonic()
        error = None
        with (directory / "stdout").open("wb") as stdout, (directory / "stderr").open("wb") as stderr:
            try:
                child = subprocess.Popen(command, cwd=self.root, env=env, stdout=stdout, stderr=stderr,
                                         start_new_session=True)
                try:
                    record["exit_code"] = child.wait(timeout=timeout or self.args.timeout)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                    record["exit_code"] = child.returncode
                    error = "timeout"
                except BaseException:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                    raise
            except Exception:
                record["exit_code"] = None
                error = traceback.format_exc()
        record.update(completed_at=now(), elapsed_seconds=time.monotonic() - started,
                      error=error, stdout_sha256=digest(directory / "stdout"),
                      stderr_sha256=digest(directory / "stderr"))
        record["status"] = "passed" if record["exit_code"] == 0 and error is None else "failed"
        write_json(directory / "command.json", record)
        with self.lock:
            self.index["jobs"].append({**record, "record": str(directory / "command.json"),
                                       "record_sha256": digest(directory / "command.json")})
            self.save()
        print(f"{record['status']}: {name} ({record['elapsed_seconds']:.1f}s)", flush=True)
        if record["status"] != "passed":
            raise RuntimeError(f"job failed: {name}; see {directory}")
        return directory / "stdout"

    def python_command(self, script):
        return [self.tools["python"], "-I", "-B", self.root / script]

    def tools_and_builds(self):
        for name in ("cargo", "rustc", "rustfmt", "cargo-clippy", "clippy-driver"):
            output = self.command("select-" + name, [self.tools["rustup"], "which", "--toolchain", "ohm", name])
            self.tools["ohm-" + name] = executable(output.read_text().strip())
        verbose = self.command("rustc-version", [self.tools["rustc"], "+ohm", "--version", "--verbose"]).read_text()
        self.triple = re.search(r"^host: (.+)$", verbose, re.MULTILINE).group(1)
        sysroot = Path(self.command("rust-sysroot", [self.tools["rustc"], "+ohm", "--print", "sysroot"]).read_text().strip())
        linker_dir = sysroot / "lib/rustlib" / self.triple / "bin"
        self.tools["rust-lld"] = executable(linker_dir / "rust-lld")
        self.tools["lto-linker"] = executable(linker_dir / "gcc-ld/ld.lld")
        for name, command in {
            "cargo-version": [*self.cargo, "--version"],
            "python-version": [self.tools["python"], "--version"],
            "clang-version": [self.tools["clang"], "--version"],
            "linker-version": [self.tools["lto-linker"], "--version"],
        }.items():
            self.command(name, command)
        self.index["tools"] = {name: {"path": str(path), "sha256": digest(path)} for name, path in self.tools.items()}
        self.frozen.update({path: digest(path) for path in self.tools.values()})
        self.index["target"] = self.triple
        for name, args in [
            ("format", ["fmt", "--all", "--check"]),
            ("clippy", ["clippy", "--workspace", "--all-targets", "--locked", "--", "-D", "warnings"]),
            ("unit", ["test", "--workspace", "--locked"]),
        ]:
            self.command(name, [*self.cargo, *args])
            self.guard()
        unit = (self.output / "jobs/unit/stdout").read_text()
        counts = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed;", unit)
        if not counts or any(int(failed) for _, failed in counts):
            raise RuntimeError("cannot establish successful Rust unit counts")
        self.index["unit_tests_passed"] = sum(int(passed) for passed, _ in counts)
        profiles = {
            "ordinary": (["build", "--workspace", "--release", "--locked"], {},
                         {"compiler": self.target / "release/relar", "ordinary": self.target / "release/librelar_runtime.a"}),
            "thinlto": (["build", "-p", "relar-runtime", "--profile", "relar-luhn-validation-lto", "--config",
                         'profile.relar-luhn-validation-lto.inherits="release"', "--locked"],
                        {"RUSTFLAGS": "-Clinker-plugin-lto"},
                        {"thinlto": self.target / "relar-luhn-validation-lto/librelar_runtime.a"}),
            "asan": (["build", "-p", "relar-runtime", "--target", self.triple, "--profile", "relar-luhn-validation-asan", "--config",
                      'profile.relar-luhn-validation-asan.inherits="release"', "--locked"],
                     {"RUSTC_BOOTSTRAP": "1", "RUSTFLAGS": "-Zsanitizer=address -Cforce-frame-pointers=yes"},
                     {"asan": self.target / self.triple / "relar-luhn-validation-asan/librelar_runtime.a"}),
        }
        self.artifacts = {}
        for mode, (args, environment, outputs) in profiles.items():
            # Remove only these generated public outputs, never dependencies or shared cache.
            for source in outputs.values():
                source.unlink(missing_ok=True)
            self.command("build-" + mode, [*self.cargo, *args], environment=environment)
            self.guard()
            for label, source in outputs.items():
                destination = self.output / "artifacts" / ("relar" if label == "compiler" else label + "-runtime.a")
                destination.parent.mkdir(exist_ok=True)
                shutil.copy2(source, destination)
                expected = digest(source)
                if digest(destination) != expected:
                    raise RuntimeError(f"artifact copy mismatch: {label}")
                destination.chmod(0o555 if label == "compiler" else 0o444)
                self.artifacts[label] = destination
                self.frozen[destination] = expected
                self.index["artifacts"][label] = {"source": str(source), "path": str(destination),
                                                   "sha256": expected, "build_job": "build-" + mode}
        self.command("compiler-version", [self.artifacts["compiler"], "--version"])
        members = self.command("thinlto-members", [self.tools["ar"], "t", self.artifacts["thinlto"]]).read_text().splitlines()
        member = next(value for value in members if "relar_runtime" in value and value.endswith(".o"))
        bitcode = self.command("thinlto-member", [self.tools["ar"], "p", self.artifacts["thinlto"], member])
        if bitcode.read_bytes()[:4] not in (b"BC\xc0\xde", b"\xde\xc0\x17\x0b"):
            raise RuntimeError("ThinLTO runtime object is not LLVM bitcode")
        symbols = self.command("asan-symbols", [self.tools["nm"], "-u", self.artifacts["asan"]]).read_text()
        if "__asan_init" not in symbols:
            raise RuntimeError("ASan runtime has no ASan initialization reference")
        self.index["runtime_probes"] = {"thinlto_bitcode_member": member, "asan_init": True}
        self.guard()
        labels = {"compiler": "compiler", "normal_runtime": "ordinary",
                  "thinlto_runtime": "thinlto", "asan_runtime": "asan"}
        artifacts = {name: self.index["artifacts"][label] for name, label in labels.items()}
        source_hashes = {
            name: value["sha256"] for name, value in self.before["files"].items()
            if name in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml")
            or name.startswith("crates/")
        }
        build = {
            "schema": 1, "revision": self.args.revision, "source_matches_revision": True,
            "captured_at_utc": now(), "target": self.triple, "artifacts": artifacts,
            "sha256": {name: value["sha256"] for name, value in artifacts.items()},
            "source_sha256": source_hashes,
            "source_scope": "Workspace Cargo.toml, Cargo.lock, rust-toolchain.toml and every tracked file under crates; full clean-source manifest retained separately.",
            "source_manifest": str(self.output / "source-before.json"),
            "source_manifest_sha256": self.index["source_manifest_sha256"],
            "tools": self.index["tools"], "archive_probes": self.index["runtime_probes"],
            "build_jobs": {job["name"]: job for job in self.index["jobs"] if job["name"].startswith("build-")},
            "runner_sha256": self.index["runner_sha256"], "input_guards_passed": True,
            "build_note": "Copied from successful Cargo builds in this run with clean source/tool guards before and after; validation results are recorded separately in index.json.",
        }
        record = self.output / "build.json"
        write_json(record, build)
        record.chmod(0o444)
        self.frozen[record] = digest(record)
        self.index["build_record"] = {"path": str(record), "sha256": self.frozen[record]}
        self.save()

    def build_references(self):
        for name, package, flags in REFERENCE_SPECS:
            directory = self.output / "references" / name
            command = self.python_command(f"benchmarks/reference/{package}/build.py") + [
                "--toolchain", "ohm", "--artifact-dir", directory,
                "--target-dir", self.target / "luhn-validation-references" / name,
                "--build-cache", self.shared, *flags,
            ]
            environment = {"CARGO_PROFILE_RELEASE_LTO": "thin"} if name == "base45-thinlto" else {}
            self.command("reference-build-" + name, command, environment=environment)
            record_path = directory / "build-record.json"
            record = json.loads(record_path.read_text())
            for relative, expected in record["sources"].items():
                source = self.root / "benchmarks/reference" / package / relative
                if digest(source) != expected:
                    raise RuntimeError(f"reference source mismatch: {name}/{relative}")
            binaries = record.get("binaries", {"reference": {"name": "luhn-reference", "sha256": record.get("binary_sha256")}})
            selected = {}
            for label, value in binaries.items():
                binary = directory / value["name"]
                if digest(binary) != value["sha256"]:
                    raise RuntimeError(f"reference artifact mismatch: {binary}")
                binary.chmod(0o555)
                selected[label] = binary
                self.frozen[binary] = value["sha256"]
            self.frozen[record_path] = digest(record_path)
            self.references[name] = selected
            self.index["references"][name] = {"build_record": str(record_path), "sha256": digest(record_path),
                                               "binaries": {key: str(value) for key, value in selected.items()}}
            self.guard()
        self.save()

    def suite(self, mode, suite):
        flags = {"ordinary": ["--opt-levels", "0", "3"],
                 "thinlto": ["--target", self.triple, "--lto-linker", self.tools["lto-linker"], "--opt-levels", "3"],
                 "asan": ["--sanitize", "--opt-levels", "0", "1"]}[mode]
        self.command(f"suite-{mode}-{suite}", self.python_command(f"tests/{suite}.py") + [
            "--compiler", self.artifacts["compiler"], "--runtime", self.artifacts[mode],
            "--python", self.tools["python"], "--clang", self.tools["clang"], *flags,
        ])

    def application(self, name):
        source, validator = APPLICATIONS[name]
        directory = self.output / "applications" / name
        directory.mkdir(parents=True)
        binary, llvm, result = directory / name, directory / "source.ll", directory / "validation.json"
        self.command("application-build-" + name, [self.artifacts["compiler"], "build", self.root / "examples" / source,
                     "--module-root", self.root / "examples", "--runtime", self.artifacts["ordinary"],
                     "--clang", self.tools["clang"], "--opt-level", "3", "--emit-llvm", llvm, "-o", binary])
        before = {path: digest(path) for path in (binary, llvm)}
        command = self.python_command("benchmarks/" + validator) + ["--python", self.tools["python"], "--binary", binary]
        if name not in ("route", "dependency"):
            command += ["--rust-bigint", self.references[name]["bigint"], "--output", result]
            if name == "incremental":
                command += ["--rust-i64", self.references[name]["i64"]]
        stdout = self.command("application-oracle-" + name, command)
        if name in ("route", "dependency"):
            write_json(result, json.loads(stdout.read_text()))
        if name == "dependency":
            self.command("application-boundaries-dependency", self.python_command("benchmarks/reference/dependency_planner/check_boundaries.py") + [
                "--python", self.tools["python"], "--relar", binary,
                "--rust-bigint", self.references[name]["bigint"], "--rust-i64", self.references[name]["i64"],
                "--output", directory / "boundaries.json"])
        if before != {path: digest(path) for path in before}:
            raise RuntimeError(f"application artifacts changed: {name}")

    def matrix(self):
        self.guard()
        self.command("lto-linking", self.python_command("tests/lto.py") + [
            "--compiler", self.artifacts["compiler"], "--runtime", self.artifacts["thinlto"],
            "--clang", self.tools["clang"], "--target", self.triple,
            "--rust-lld", self.tools["rust-lld"], "--python", self.tools["python"],
        ])
        errors = []
        with ThreadPoolExecutor(max_workers=self.args.workers) as executor:
            futures = [executor.submit(self.suite, mode, suite) for mode in ("ordinary", "thinlto", "asan") for suite in SUITES]
            futures += [executor.submit(self.application, name) for name in APPLICATIONS]
            for name in ("base45-normal", "base45-thinlto", "luhn-normal", "luhn-thinlto"):
                codec = name.split("-")[0]
                futures.append(executor.submit(self.command, "reference-oracle-" + name,
                    self.python_command(f"benchmarks/{codec}_validate.py") + [
                        "--rust", self.references[name]["reference"], "--output", self.output / "references" / name / "validation.json"]))
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as error:
                    errors.append(str(error))
        if errors:
            raise RuntimeError("\n".join(errors))
        self.guard()

    def run(self):
        try:
            self.tools_and_builds()
            self.build_references()
            self.matrix()
            self.index["status"] = "passed"
        except BaseException:
            self.index["status"] = "failed"
            self.index["failure"] = traceback.format_exc()
            raise
        finally:
            try:
                after = self.source_identity()
                write_json(self.output / "source-after.json", after)
                self.index["source_unchanged"] = after == self.before
                self.guard()
                self.index["input_guards_passed"] = True
            except Exception:
                self.index["status"] = "failed"
                self.index["input_guards_passed"] = False
                self.index["guard_failure"] = traceback.format_exc()
            self.index["completed_at"] = now()
            self.index["job_counts"] = {status: sum(job["status"] == status for job in self.index["jobs"]) for status in ("passed", "failed")}
            evidence = {str(path.relative_to(self.output)): digest(path) for path in sorted(self.output.rglob("*"))
                        if path.is_file() and path.name != "index.json"}
            write_json(self.output / "evidence-sha256.json", evidence)
            self.index["evidence_manifest_sha256"] = digest(self.output / "evidence-sha256.json")
            self.save()
        if self.index["status"] != "passed":
            raise RuntimeError("validation input guard failed")
        print(f"Passed full validation: {self.output / 'index.json'}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--revision", required=True, help="full committed source SHA to freeze")
    parser.add_argument("--output", type=Path, required=True, help="new external evidence directory")
    parser.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/relar"))
    parser.add_argument("--target-dir", type=Path, default=Path("/home/dev-user/.cache/relar/main-target"))
    parser.add_argument("--build-cache", type=Path, default=Path("/home/dev-user/.cache/ohm/shared-build"))
    parser.add_argument("--cargo-home", type=Path, default=Path("/home/dev-user/.cache/relar/cargo-home"))
    parser.add_argument("--python", default="/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14")
    parser.add_argument("--clang", default="/usr/bin/clang-18")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=1200, help="per job timeout in seconds")
    args = parser.parse_args()
    if args.workers < 1 or args.timeout < 1 or not re.fullmatch(r"[0-9a-f]{40}", args.revision):
        parser.error("positive workers/timeout and a full lowercase source SHA are required")
    Validation(args).run()


if __name__ == "__main__":
    main()
