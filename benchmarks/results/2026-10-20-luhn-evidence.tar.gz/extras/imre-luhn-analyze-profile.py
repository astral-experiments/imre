"""Derive a partitioned explanation from immutable Luhn profile evidence."""

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path("/home/dev-user/code/oss/imre")
PROFILE = Path("/tmp/imre-luhn-profile-final")
OUTPUT = Path("/tmp/imre-luhn-profile-analysis.json")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


summary = json.loads((PROFILE / "summary.json").read_text())
manifest = json.loads((PROFILE / "manifest.json").read_text())
assert summary["status"] == "passed" and summary["complete"] and summary["input_guards_passed"]
assert all(sha(PROFILE / name) == value for name, value in manifest.items())
metrics = {(p["engine"], p["tool"]): p["metrics"] for p in summary["profiles"]}
calls = (PROFILE / "imre-callgrind/profile.callgrind").read_text().splitlines()
names = {}
for line in calls:
    match = re.fullmatch(r"c?fn=\((\d+)\) (.+)", line)
    if match:
        names[match[1]] = match[2]
edges, edge_calls = Counter(), Counter()
caller = callee = None
pending = False
for line in calls:
    match = re.fullmatch(r"(c?fn)=\((\d+)\)(?: .+)?", line)
    if match:
        if match[1] == "fn":
            caller, pending = names[match[2]], False
        else:
            callee = names[match[2]]
    elif line.startswith("calls="):
        edge_calls[caller, callee] += int(line.split()[0].split("=")[1])
        pending = True
    elif re.fullmatch(r"(?:0x[0-9a-f]+|[+-]\d+|\*|\d+)\s+(?:[+-]?\d+|\*)\s*(\d*)", line):
        if pending:
            edges[caller, callee] += int(line.split()[2]) if len(line.split()) == 3 else 0
            pending = False
char_roots = ["imre_mapping_iter_next", "imre_int_parse",
              "<alloc::rc::Rc<compact_str::CompactString>>::drop_slow"]
descendants = {}
for root in char_roots:
    seen, todo = set(), [b for (a, b), value in edges.items() if a == root and value]
    while todo:
        node = todo.pop()
        if node in seen:
            continue
        seen.add(node)
        todo.extend(b for (a, b), value in edges.items() if a == node and value)
    assert not set(char_roots) & seen
    descendants[root] = sorted(seen)
char_cost = sum(edges["fn_3", name] for name in char_roots)
heap = json.loads((PROFILE / "imre-dhat/profile.json").read_text())
categories = defaultdict(lambda: {"bytes": 0, "blocks": 0, "point_indices": []})
for index, point in enumerate(heap["pps"]):
    frames = [heap["ftbl"][frame] for frame in point["fs"]]
    if any("imre_mapping_iter_next" in frame for frame in frames):
        name = "one_character_string_owners"
    elif any("0x20EC5F:" in frame for frame in frames):
        name = "temporary_divmod_pairs"
    elif any("0x20E6BA:" in frame for frame in frames):
        name = "digit_list_buffers"
    elif any("0x20F2FB:" in frame for frame in frames):
        name = "comprehension_result_buffers"
    elif any("imre_list_slice" in frame for frame in frames):
        name = "two_slices"
    else:
        name = "other"
    category = categories[name]
    category["bytes"] += point["tb"]
    category["blocks"] += point["tbk"]
    category["point_indices"].append(index)
assert sum(item["bytes"] for item in categories.values()) == metrics["imre", "dhat"]["allocated_bytes"]
assert sum(item["blocks"] for item in categories.values()) == metrics["imre", "dhat"]["allocated_blocks"]
digits, repetitions = summary["digits"], summary["repetitions"]
assert categories["one_character_string_owners"]["blocks"] == digits * repetitions
assert categories["one_character_string_owners"]["bytes"] == digits * repetitions * 40
assert categories["temporary_divmod_pairs"]["blocks"] == digits * repetitions // 2
assert categories["temporary_divmod_pairs"]["bytes"] == digits * repetitions // 2 * 32
for item in categories.values():
    item["fraction_of_requested_bytes"] = item["bytes"] / metrics["imre", "dhat"]["allocated_bytes"]
    item["fraction_of_requested_blocks"] = item["blocks"] / metrics["imre", "dhat"]["allocated_blocks"]

binary = Path(summary["guarded_inputs"]["native_binary"]["path"])
assembly_command = ["/usr/bin/objdump", "-d", "--no-show-raw-insn", "--disassemble=fn_3", str(binary)]
assembly = subprocess.check_output(assembly_command, text=True)
assembly_lines = assembly.splitlines()
zeroed = [i for i, line in enumerate(assembly_lines) if "___rdl_alloc_zeroed>" in line]
assert len(zeroed) == 1 and "106c5b:" in assembly_lines[zeroed[0]]
allocation_excerpt = "\n".join(assembly_lines[zeroed[0] - 2:zeroed[0] + 12])
assert "$0x20,%edi" in allocation_excerpt and "$0x8,%esi" in allocation_excerpt
llvm = (PROFILE / "native.ll").read_text()
helper = re.search(r"^define internal ptr @fn_8\(.*?^\}", llvm, re.M | re.S)[0]
assert helper.count("call ptr @imre_record_new(ptr @layout_tuple_4)") == 1
assert "call i64 @int_floordiv" in helper and "call i64 @int_mod" in helper
assert "i32 0, i32 0" in helper and "i32 0, i32 1" in helper
functions = metrics["imre", "callgrind"]["functions"]
by_name = {item["name"]: item for item in functions}
assert sum(item["self_instructions"] for item in functions) == metrics["imre", "callgrind"]["instructions"]
timing = json.loads((PROFILE / "benchmark-record.json").read_text())
workload = next(item for item in timing["workloads"] if item["label"] == summary["label"])
result = {
    "schema": 1,
    "source_revision": summary["revision"],
    "build_revision": summary["build_revision"],
    "profile_summary_sha256": sha(PROFILE / "summary.json"),
    "profile_manifest_sha256": sha(PROFILE / "manifest.json"),
    "benchmark_record_sha256": sha(PROFILE / "benchmark-record.json"),
    "binary_sha256": sha(binary),
    "llvm_sha256": sha(PROFILE / "native.ll"),
    "derivation_script_sha256": sha(__file__),
    "raw_profile_sha256": {
        f"{engine}-{tool}": sha(PROFILE / f"{engine}-{tool}" / ("profile.callgrind" if tool == "callgrind" else "profile.json"))
        for engine in ("imre", "rust") for tool in ("callgrind", "dhat")
    },
    "workload": {key: summary[key] for key in ("label", "digits", "repetitions", "digits_per_process", "checksum_per_call", "expected_stdout")},
    "measurement_scope": "Whole-process instrumented guest instructions and requested heap allocations for 64 calls; not CPU time or an optimization speedup estimate. Timed results use a separate 4096-call batch.",
    "instruction_totals": {engine: metrics[engine, "callgrind"]["instructions"] for engine in ("imre", "rust")},
    "instruction_ratio_imre_over_rust": metrics["imre", "callgrind"]["instructions"] / metrics["rust", "callgrind"]["instructions"],
    "top_self_instruction_functions": functions[:18],
    "checksum_function": by_name["fn_3"],
    "character_pipeline": {
        "scope": "Only direct fn_3 outgoing inclusive call edges for character iteration/construction, integer parsing, and string destruction.",
        "functions": [
            {"name": name, "calls_from_checksum": edge_calls["fn_3", name],
             "inclusive_instructions_from_checksum": edges["fn_3", name],
             "self_instructions_all_callers": by_name[name]["self_instructions"]}
            for name in char_roots
        ],
        "inclusive_instructions": char_cost,
        "fraction_of_process_instructions": char_cost / metrics["imre", "callgrind"]["instructions"],
        "no_double_counting_check": "No selected root is reachable from another selected root through a positive-cost observed call edge.",
        "observed_descendants": descendants,
    },
    "temporary_tuple_allocation_edge": {
        "caller": "fn_3", "callee": "__rustc::__rdl_alloc_zeroed",
        "calls": edge_calls["fn_3", "__rustc::__rdl_alloc_zeroed"],
        "inclusive_instructions": edges["fn_3", "__rustc::__rdl_alloc_zeroed"],
        "fraction_of_process_instructions": edges["fn_3", "__rustc::__rdl_alloc_zeroed"] / metrics["imre", "callgrind"]["instructions"],
        "scope": "Allocation only; excludes tuple arithmetic, ownership checks and destruction in fn_3 or other calls.",
    },
    "allocation_totals": {
        engine: {key: value for key, value in metrics[engine, "dhat"].items() if key != "top_allocation_stacks"}
        for engine in ("imre", "rust")
    },
    "allocation_categories": dict(categories),
    "allocation_partition_check": "Every DHAT point belongs to exactly one category; bytes and blocks sum to the complete Imre process totals. Resizing requests remain attributed to their original allocation stack.",
    "allocation_attribution_evidence": {
        "character_owners": "All stacks containing imre_mapping_iter_next; sequences.rs StringIterator::next constructs Rc<Str>. Exactly 262144 blocks of 40 bytes, one per input character.",
        "divmod_pair": "DHAT fn_3 site 0x20ec5f is consistent with the sole native fn_3 zeroed 32-byte allocation at 0x106c5b (reported return-IP-minus-one plus PIE bias 0x108000). The emitted fn_8 helper constructs layout_tuple_4 then computes/stores floor quotient and remainder, reads both fields for sum, and releases the record. ThinLTO inlines that helper into fn_3. Exactly one pair per doubled digit.",
        "digit_list_buffers": "DHAT original allocation site 0x20e6ba; native fn_3 list-capacity growth after imre_int_parse and before storing the converted digit.",
        "comprehension_result_buffers": "DHAT original allocation site 0x20f2fb; native fn_3 list-capacity growth after the divmod pair is summed.",
        "slices": "Every DHAT stack containing imre_list_slice: both backing buffers and list owners for the two consumed slices.",
        "assembly_command": assembly_command,
        "objdump_sha256": sha("/usr/bin/objdump"),
        "assembly_sha256": hashlib.sha256(assembly.encode()).hexdigest(),
        "zeroed_allocation_excerpt": allocation_excerpt,
        "emitted_helper_sha256": hashlib.sha256(helper.encode()).hexdigest(),
    },
    "separate_wall_time_reference": {
        "repetitions": workload["repetitions"],
        "median_seconds": {engine: value["median_seconds"] for engine, value in workload["summary"].items()},
        "imre_over_rust": workload["imre_over_rust"], "cpython_over_imre": workload["cpython_over_imre"],
    },
    "conclusions": [
        "Character materialization/conversion/destruction is the largest separately identified CPU path: almost half of guest instructions and two thirds of allocated blocks.",
        "Temporary divmod pairs account for another third of allocated blocks. Their allocation alone consumes about one tenth of guest instructions, before tuple ownership and cleanup.",
        "Digit-list growth, comprehension-result growth and two slices account for most remaining requested heap bytes, but relatively few blocks.",
        "Signature inference is compile-time work; this gap is emitted representation and runtime work, including generic integer/ownership/error checks and eager materialization.",
        "Next targets are a semantic-preserving character-to-int consumer path, scalarized nonescaping divmod pairs, and then known-length allocation or safe elimination of consumed slice/comprehension buffers. These measurements do not establish any particular future speedup or Rust parity.",
    ],
}
assert all(sha(PROFILE / name) == value for name, value in manifest.items())
OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
print(OUTPUT)
