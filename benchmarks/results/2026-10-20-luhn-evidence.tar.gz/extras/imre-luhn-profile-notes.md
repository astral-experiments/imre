The separate Callgrind/DHAT comparison used the exact timed ThinLTO binaries for 64 checksum calls on the same 4,096 ASCII digits. Both produced the complete output `2` and accumulated checksum `128`. Imre executed **212,067,563 guest instructions versus Rust’s 5,125,141 (41.38×)** and requested **23,105,570 heap bytes in 395,039 blocks versus 8,155 bytes in 19 blocks**. These are whole-process instrumented instruction and allocation counts, not CPU time, RSS, or an estimate of future speedup. The separate wall-time benchmark used 4,096 calls and measured Imre at 39.49× Rust’s time for this workload. The [retained attribution](2026-10-20-luhn-profile-analysis.json) links these figures to the raw profiles, exact binaries, and output checks.

The largest identified path is **per-character string construction, integer parsing, and string destruction: 49.45% of Imre’s guest instructions**, using nonoverlapping inclusive call edges from the generated checksum function. Their contributions are 25.71%, 11.62%, and 12.11%, respectively. The generated checksum function itself accounts for another **25.92% in self instructions**, including inlined arithmetic, ownership, checks, and container handling; its 99.80% inclusive share also contains the helper costs and must not be added to them. Allocation stacks confirm exactly one 40-byte string owner per digit and one 32-byte temporary `divmod` pair per doubled digit. The pair allocation alone accounts for another 10.71% of process instructions, before its ownership and cleanup costs. The allocation categories below partition every Imre DHAT point without overlap.

| Allocation category | Requested bytes | Blocks |
|---|---:|---:|
| One-character string owners | 10,485,760 | 262,144 |
| Temporary `divmod` pairs | 4,194,304 | 131,072 |
| Digit-list buffers, including growth | 4,192,256 | 704 |
| Comprehension-result buffers, including growth | 2,095,104 | 640 |
| Two slices, including their list owners | 2,102,272 | 256 |
| Other runtime, startup, and I/O allocations | 35,874 | 223 |

The next optimization targets are therefore concrete: remove character objects from an immediate `map(int, text)` consumer while preserving Unicode conversion and error order; scalarize the nonescaping `divmod` pair consumed by `sum`; then avoid repeated buffer growth and, where proven safe, eliminate consumed slice/comprehension temporaries. Signature inference happens during compilation and is not a runtime cost here. The Rust reference already streams over the digits without these intermediates. Approaching its performance requires reducing emitted work; these measurements do not establish Rust parity.
