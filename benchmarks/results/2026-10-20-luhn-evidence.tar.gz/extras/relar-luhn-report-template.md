# Compiling unchanged Luhn with inferred function signatures

Relar now compiles the unchanged, unannotated [`mmcloughlin/luhn` 0.2.0 library](https://github.com/mmcloughlin/luhn/tree/d6f3fa71072f99334a4c1d2a3f062fa93982797f) for its four string APIs: `checksum`, `verify`, `generate`, and `append`. A separate typed driver supplies concrete call sites. The original functions retain their `list(map(int, string))`, slices, comprehension, `sum`, and `divmod` expressions.

__PERFORMANCE_HEADLINE__

The [implementation PR](https://github.com/viarius-experiments/relar/pull/53) adds concrete function-signature inference and iterable consumers without a Luhn intrinsic or source rewrite. Inference runs before code generation; every function has one exact signature and the completed source graph is checked again. Existing annotations remain enforced, and incompatible callers or insufficient type evidence are rejected.

## Comparison with CPython and Rust

Each process handles **16 MiB of ASCII digits** through repeated calls on the indicated input size. Six warmup rounds precede twelve measured rounds, balancing all six engine orders. Values are median milliseconds with inclusive quartiles in brackets. **CPython / Relar is a speedup ratio: higher is better. Relar / Rust is a time ratio: lower is better.**

### Ordinary linking

__NORMAL_TABLE__

### ThinLTO

__THINLTO_TABLE__

The [Rust reference](../reference/luhn_checksum/README.md) independently implements the same string API and file protocol. It streams validation and checksum arithmetic, uses a virtual trailing zero for `generate`, and avoids the Python algorithm's intermediate digit lists. Both implementations receive identical inputs and repetition counts and must produce the same complete output and accumulated checksum. Rust has a black-box barrier around each repeated call. This comparison includes differences in algorithm and storage strategy; it does not isolate language overhead.

Both native engines use their matching ordinary or ThinLTO configuration. ThinLTO uses matched LLVM import and inline budgets of 1,000. The two families ran separately, each with interleaved CPython and Rust baselines; their differences are not a randomized measurement of ThinLTO's isolated effect. Quartiles describe observed spread, not confidence intervals.

An empty-input, one-call control measures startup and protocol cost without subtracting it:

__CONTROL_TABLE__

__CONTROL_INTERPRETATION__

## Allocation and instruction profile

After timing finished, separate DHAT and Callgrind runs profiled the exact ThinLTO executables on **64 checksum calls of 4,096 digits**, or 262,144 digits per process. Every run checked the full output and checksum against an independent ASCII arithmetic oracle.

__PROFILE_TABLE__

__PROFILE_INTERPRETATION__

Callgrind reports instrumented guest instructions, not hardware cycles or CPU-time percentages. DHAT's cumulative allocation is distinct from peak live allocation and RSS. These profiles include process startup, input decoding, file I/O, checksum accumulation, and cleanup; they are separate from the wall-clock samples above. The [independent profile audit](2026-10-20-luhn-profile-audit.json) checks the raw counters, allocation stacks, complete outputs, and timed-binary identities.

## Compatibility and validation

The [upstream manifest](../../examples/luhn_checksum/UPSTREAM.json) pins the original module, ten tests, and MIT license by commit, Git blob, size, and SHA-256. The module and upstream files are byte-for-byte copies. The validator runs the ten original tests and five doctest examples through native adapters, then checks **1,144 cases against CPython 3.14.5**. Cases include all 760 Unicode 16 decimal characters, mixed digit families, empty/random/long inputs, invalid-character ordering, exact exception messages and metadata, malformed UTF-8, and output-file preservation. Separate native checks cover repeated recovery and import aliases. No Luhn diagnostic exclusions are used.

Each of **five configurations** passes the 15 upstream adapter calls and 1,144 differential cases: ordinary O0/O3, ThinLTO O3, and ASan/LSan O0/O1. The same corpus passes against both Rust reference builds. Separate exhaustive audits check all 1,114,112 Unicode code points for the runtime and independent Rust tables.

The complete local matrix passes **129 command jobs**, including **145 Rust unit tests**, formatting, strict workspace Clippy, and **81 suite invocations**: 27 suites each for ordinary O0/O3, ThinLTO O3, and ASan O0/O1, with the paired optimization levels grouped in one invocation. The 25 non-library suites report **4,196 checks**; the unchanged Base45 suites and all six existing application oracles also pass. The [independent validation audit](2026-10-20-luhn-validation-audit.json) records exact counts and scope. ASan/LSan instruments generated code and the custom runtime; the prebuilt Rust standard library and Rust reference are not sanitizer-instrumented. Full-matrix native library runs retain their commands, exit status, and suite summaries; detailed per-case JSON is retained for the timed O3 binaries and Rust references.

This establishes compatibility for the library's string APIs through the strict UTF-8 driver. It does not provide a Python-callable extension module or infer multiple specializations for arbitrary iterable or mixed-type callers. The new iterable surface is concrete `list(...)`, integer `sum(...)`, and immediate `list`/`sum` consumers of `map(int, ...)`; general escaping iterators and arbitrary callback values remain unsupported.

## Measurement and evidence

Compiler/runtime builds and the full validation matrix use clean commit **7d4011f0413c63d0a4d111817c37f460a0656cac**. Timing uses clean commit **6fa8681c1734513cc278511427029dea9dca471c**. Its sole change is a benchmark metadata fix that records an absent LLVM target line as null while retaining the requested target. Compiler, runtime, examples, tests, and reference sources are identical. The initial harness attempt failed before timing; its original evidence and the exact intervening patch are retained.

Measurements ran on an AMD EPYC-Milan host pinned to CPU 0, outside ptrace tracing. CPython 3.14.5 has PGO and LTO enabled, the GIL enabled, and JIT disabled. Relar uses Clang 18 at O3; the Rust reference uses Ohm 1.98.1-1 (rustc 1.98.1-dev, LLVM 22.1.8). The [build record](2026-10-20-luhn-build.json) identifies exact source, tools, commands, archives, and executables.

Timing includes startup, imports, one input read, repeated unchanged-library calls, checksum accumulation, one final complete output write, and exit. Preparation, compilation, hashing, and verification are outside the clock. OS caches are warm and output is not fsynced. Task-owned builds, tests, and profiles were paused during measurement. Host frequency and unrelated shared-host activity remain uncontrolled.

The records retain **936 measured executions, 468 warmups, and 78 correctness gates**, including the empty-input controls. The [benchmark audit](2026-10-20-luhn-benchmark-audit.json) independently recomputes summaries and ratios, checks engine-order balance and complete results, and verifies source/build/tool/binary identities.

Raw records: [ordinary linking](2026-10-20-luhn-normal.json.gz), [ThinLTO](2026-10-20-luhn-thinlto.json.gz), [validation index](2026-10-20-luhn-validation.json), and [profile summary](2026-10-20-luhn-profile.json). The [evidence archive](2026-10-20-luhn-evidence.tar.gz) and [member manifest](2026-10-20-luhn-evidence-manifest.json) retain measured sources, emitted LLVM, exact logs, raw timing and correctness records, profiles, audits, and reproduction helpers. Native binaries, runtime archives, interpreters, and toolchains remain external and hash-identified. Original commands retain host-specific paths; the [example guide](../../examples/luhn_checksum/README.md) and [Rust reference guide](../reference/luhn_checksum/README.md) provide portable entrypoints.
