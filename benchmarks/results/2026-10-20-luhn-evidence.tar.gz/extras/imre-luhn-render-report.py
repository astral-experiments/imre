"""Render the Luhn report from completed records and reviewed profile notes."""

import argparse
import json
import math
import re
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_text())


def spread(summary):
    return (
        f"{summary['median_seconds'] * 1000:.3f} "
        f"[{summary['p25_seconds'] * 1000:.3f}–"
        f"{summary['p75_seconds'] * 1000:.3f}]"
    )


def table(record):
    lines = [
        "| API / digits per call | Imre ms [Q1–Q3] | Rust ms [Q1–Q3] | CPython ms [Q1–Q3] | Imre / Rust | CPython / Imre |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for workload in record["workloads"]:
        values = [spread(workload["summary"][engine]) for engine in ("imre", "rust", "cpython")]
        lines.append(
            f"| `{workload['operation']}` / {workload['digits']:,} | "
            + " | ".join(values)
            + f" | {workload['imre_over_rust']:.3f}× | {workload['cpython_over_imre']:.3f}× |"
        )
    return "\n".join(lines)


def ratio_range(record, name, precision):
    values = [workload[name] for workload in record["workloads"]]
    return f"{min(values):.{precision}f}–{max(values):.{precision}f}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile-notes", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    records = {mode: read(f"/tmp/imre-luhn-v2-{mode}.json") for mode in ("normal", "thinlto")}
    audit = read("/tmp/imre-luhn-benchmark-audit.json")
    profile = read("/tmp/imre-luhn-profile-final/summary.json")
    assert audit["status"] == profile["status"] == "passed"
    assert profile["complete"] and profile["input_guards_passed"]
    for mode, record in records.items():
        assert record["input_guards_passed"] and not record["dirty"]
        assert len(record["workloads"]) == 12 and record["samples"] == 12 and record["warmups"] == 6
        assert record["thinlto"] == (mode == "thinlto") and record["batch_digits"] == 16 * 1024 * 1024
    normal, thin = records["normal"], records["thinlto"]
    replacements = {
        "__PERFORMANCE_HEADLINE__": (
            f"With ThinLTO, Imre is **{ratio_range(thin, 'cpython_over_imre', 2)}× faster than CPython** "
            f"and takes **{ratio_range(thin, 'imre_over_rust', 1)}× Rust's time** across these workloads. "
            f"Ordinary linking is {ratio_range(normal, 'cpython_over_imre', 2)}× faster than CPython. "
            "This completes the compatibility milestone; performance remains far from competitive with the streaming Rust implementation."
        ),
        "__NORMAL_TABLE__": table(normal),
        "__THINLTO_TABLE__": table(thin),
        "__PROFILE_INTERPRETATION__": args.profile_notes.read_text().strip(),
    }
    controls = [
        "| Build family | Imre ms | Rust ms | CPython ms |",
        "|---|---:|---:|---:|",
    ]
    for mode, label in (("normal", "Ordinary"), ("thinlto", "ThinLTO")):
        controls.append(
            f"| {label} | "
            + " | ".join(
                f"{records[mode]['startup_control']['summary'][engine]['median_seconds'] * 1000:.3f}"
                for engine in ("imre", "rust", "cpython")
            )
            + " |"
        )
    replacements["__CONTROL_TABLE__"] = "\n".join(controls)
    maxima = {
        engine: 100 * max(workload["startup_control_fraction"][engine]
                          for record in records.values() for workload in record["workloads"])
        for engine in ("imre", "rust", "cpython")
    }
    replacements["__CONTROL_INTERPRETATION__"] = (
        f"Across both families, this control is at most {math.ceil(maxima['imre'] * 100) / 100:.2f}% of Imre's median batch time, "
        f"{math.ceil(maxima['cpython'] * 100) / 100:.2f}% of CPython's, and {math.ceil(maxima['rust'] * 100) / 100:.2f}% of Rust's. "
        "Imre's gap is predominantly execution cost rather than startup. Controls are retained without subtraction."
    )
    profiles = {(item["engine"], item["tool"]): item["metrics"] for item in profile["profiles"]}
    rows = [
        "| Engine | Allocated bytes | Allocation blocks | Peak live bytes | Instructions |",
        "|---|---:|---:|---:|---:|",
    ]
    for engine, label in (("imre", "Imre"), ("rust", "Rust")):
        heap, instructions = profiles[engine, "dhat"], profiles[engine, "callgrind"]
        values = [heap["allocated_bytes"], heap["allocated_blocks"], heap["peak_live_bytes"], instructions["instructions"]]
        rows.append(f"| {label} | " + " | ".join(f"{value:,}" for value in values) + " |")
    replacements["__PROFILE_TABLE__"] = "\n".join(rows)
    report = Path("/tmp/imre-luhn-report-template.md").read_text()
    for marker, replacement in replacements.items():
        assert report.count(marker) == 1, marker
        report = report.replace(marker, replacement)
    assert re.search(r"__[A-Z][A-Z_]+__", report) is None, "unfilled report marker"
    args.output.write_text(report)
    print(args.output)


if __name__ == "__main__":
    main()
