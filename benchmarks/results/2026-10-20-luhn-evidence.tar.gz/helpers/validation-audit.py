"""Audit frozen validation records without rebuilding or running native workloads."""

import ast
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

DIRECTORY = Path("/tmp/relar-luhn-validation-v1")
OUTPUT = Path("/tmp/relar-luhn-validation-audit.json")
REVISION = "7d4011f0413c63d0a4d111817c37f460a0656cac"
INDEX_SHA256 = "0ea4e260b52165cc76deaaf6170c2ff2fc487b8822a4b88436ba75436d79a590"


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(name):
    return json.loads((DIRECTORY / name).read_text())


index = read("index.json")
before, after = read("source-before.json"), read("source-after.json")
build, evidence = read("build.json"), read("evidence-sha256.json")
assert digest(DIRECTORY / "index.json") == INDEX_SHA256
assert index["status"] == "passed" and index["input_guards_passed"]
assert index["source_unchanged"] and before == after and before["status"] == ""
assert before["revision"] == index["revision"] == build["revision"] == REVISION
assert digest(DIRECTORY / "source-before.json") == index["source_manifest_sha256"]
assert build["source_manifest_sha256"] == index["source_manifest_sha256"]
assert digest(DIRECTORY / "build.json") == index["build_record"]["sha256"]
assert digest(DIRECTORY / "runner.py") == index["runner_sha256"]
assert build["runner_sha256"] == index["runner_sha256"]
assert digest(DIRECTORY / "evidence-sha256.json") == index["evidence_manifest_sha256"]
assert all(
    before["files"][name]["sha256"] == value
    for name, value in build["source_sha256"].items()
)

# Resolve immutable Git objects, not the current worktree/HEAD. A later harness
# commit must neither invalidate nor inherit claims about this validation run.
repository = Path(index["root"])
tree = subprocess.check_output(
    ["git", "rev-parse", REVISION + "^{tree}"], cwd=repository, text=True
).strip()
assert tree == before["tree"]
entries = subprocess.check_output(
    ["git", "ls-tree", "-r", "-z", REVISION], cwd=repository
).split(b"\0")
blobs = []
for entry in entries:
    if not entry:
        continue
    header, name = entry.split(b"\t", 1)
    mode, kind, identity = header.split()
    name = name.decode()
    if name.startswith("benchmarks/results/"):
        continue
    assert kind == b"blob"
    blobs.append((name, mode, identity))
assert {name for name, _, _ in blobs} == set(before["files"])
objects = subprocess.check_output(
    ["git", "cat-file", "--batch"],
    cwd=repository,
    input=b"".join(identity + b"\n" for _, _, identity in blobs),
)
offset = 0
source_bytes = 0
for name, mode, identity in blobs:
    end = objects.index(b"\n", offset)
    got, kind, size = objects[offset:end].split()
    assert got == identity and kind == b"blob"
    offset = end + 1
    data = objects[offset : offset + int(size)]
    offset += int(size) + 1
    source_bytes += len(data)
    metadata = before["files"][name]
    if mode == b"120000":
        assert metadata == {"symlink": data.decode()}, name
    else:
        assert hashlib.sha256(data).hexdigest() == metadata["sha256"], name
        assert metadata["executable"] == (mode == b"100755"), name
assert offset == len(objects)

jobs = index["jobs"]
assert len(jobs) == len({job["name"] for job in jobs}) == 129
for job in jobs:
    assert job["status"] == "passed" and job["exit_code"] == 0
    assert job["error"] is None
    for field in ("record", "stdout", "stderr"):
        path = Path(job[field])
        expected = job[field + "_sha256"]
        assert evidence[str(path.relative_to(DIRECTORY))] == expected
        assert digest(path) == expected
for name in ("build.json", "runner.py", "source-before.json", "source-after.json"):
    assert evidence[name] == digest(DIRECTORY / name)
for record in index["references"].values():
    assert digest(record["build_record"]) == record["sha256"]
labels = {
    "compiler": "compiler",
    "normal_runtime": "ordinary",
    "thinlto_runtime": "thinlto",
    "asan_runtime": "asan",
}
for name, label in labels.items():
    assert build["artifacts"][name] == index["artifacts"][label]
    assert build["sha256"][name] == index["artifacts"][label]["sha256"]
for name, job in build["build_jobs"].items():
    assert job == next(value for value in jobs if value["name"] == name)

syntax = ast.parse((DIRECTORY / "runner.py").read_text())
node = next(
    statement.value
    for statement in syntax.body
    if isinstance(statement, ast.Assign)
    and any(isinstance(target, ast.Name) and target.id == "SUITES" for target in statement.targets)
)
assert isinstance(node, ast.Call) and node.func.attr == "split"
suites = ast.literal_eval(node.func.value).split()
levels = {"ordinary": ["0", "3"], "thinlto": ["3"], "asan": ["0", "1"]}
actual = set()
generic_checks = {}
special = {}
for job in jobs:
    if not job["name"].startswith("suite-"):
        continue
    _, mode, suite = job["name"].split("-", 2)
    actual.add((mode, suite))
    command = job["command"]
    assert command[command.index("--opt-levels") + 1 :] == levels[mode]
    assert command[command.index("--runtime") + 1] == index["artifacts"][mode]["path"]
    assert command[command.index("--compiler") + 1] == index["artifacts"]["compiler"]["path"]
    assert ("--sanitize" in command) == (mode == "asan")
    stdout = Path(job["stdout"]).read_text()
    matched = re.search(r"^Passed (\d+) .*checks", stdout, re.M) or re.search(
        r"^(\d+) import checks passed$", stdout, re.M
    )
    if matched:
        generic_checks[mode] = generic_checks.get(mode, 0) + int(matched[1])
    else:
        special[job["name"]] = stdout.splitlines()
        if suite == "luhn":
            assert special[job["name"]] == [
                f"O{level}: relar: 15 upstream calls, 1144 differential cases"
                for level in levels[mode]
            ]
        else:
            assert suite == "base45"
            assert special[job["name"]] == [
                f"O{level}: Passed 323 upstream native calls, 289 differential cases, and 2 compile-time type rejections"
                for level in levels[mode]
            ]
assert actual == {(mode, suite) for mode in levels for suite in suites}
assert len(suites) == 27 and len(actual) == 81
assert generic_checks == {"ordinary": 1524, "thinlto": 1148, "asan": 1524}
unit = (DIRECTORY / "jobs/unit/stdout").read_text()
unit_counts = [
    int(value)
    for value in re.findall(r"test result: ok\. (\d+) passed; 0 failed;", unit)
]
assert sorted(value for value in unit_counts if value) == [58, 87]
assert sum(unit_counts) == index["unit_tests_passed"] == 145
assert index["environment"]["ASAN_OPTIONS"] == "detect_leaks=1:halt_on_error=1"

applications = sorted(
    job["name"].removeprefix("application-oracle-")
    for job in jobs
    if job["name"].startswith("application-oracle-")
)
assert applications == ["batch", "dependency", "incremental", "inventory", "manifest", "route"]
assert any(job["name"] == "application-boundaries-dependency" for job in jobs)
assert len(index["references"]) == 9
reference_counts = {}
for name in ("luhn-normal", "luhn-thinlto", "base45-normal", "base45-thinlto"):
    result = read(f"references/{name}/validation.json")["rust"]
    reference_counts[name] = {
        "differential_cases": len(result["differential_cases"]),
        "exact_message_cases": result["exact_message_cases"],
    }
    if name.startswith("luhn"):
        assert result["native_adapter_calls"] == 15
        assert len(result["differential_cases"]) == result["exact_message_cases"] == 1144
        reference_counts[name]["upstream_adapter_calls"] = 15
    else:
        assert len(result["differential_cases"]) == 295
        assert result["exact_message_cases"] == 291
        assert len(result["diagnostic_boundaries"]) == 4
        reference_counts[name]["documented_diagnostic_boundaries"] = 4

report = {
    "schema": 1,
    "status": "passed",
    "audited_at_utc": datetime.now(timezone.utc).isoformat(),
    "revision": REVISION,
    "validation_revision": REVISION,
    "validation_tree": tree,
    "validation_index": str(DIRECTORY / "index.json"),
    "validation_index_sha256": INDEX_SHA256,
    "audit_script_sha256": digest(__file__),
    "counts": {
        "recorded_jobs": 129,
        "passed_jobs": 129,
        "failed_jobs": 0,
        "rust_units": {"compiler": 58, "runtime": 87, "total": 145},
        "language_suites": 27,
        "suite_invocations": 81,
        "optimization_configurations": levels,
        "generic_suite_count": 25,
        "generic_checks_by_mode": generic_checks,
        "generic_checks_total": sum(generic_checks.values()),
        "luhn_native": {
            "configurations": 5,
            "upstream_calls_per_configuration": 15,
            "differential_cases_per_configuration": 1144,
            "upstream_calls_total": 75,
            "differential_cases_total": 5720,
            "upstream_tests": 10,
            "upstream_doctest_examples": 5,
        },
        "base45_native": {
            "configurations": 5,
            "upstream_calls_per_configuration": 323,
            "differential_cases_per_configuration": 289,
            "compile_rejections_per_configuration": 2,
        },
        "application_oracles": applications,
        "dependency_boundary_checks": True,
        "reference_builds": len(index["references"]),
        "reference_oracles": reference_counts,
    },
    "guard_checks": {
        "before_after_source_manifests_identical": True,
        "clean_validation_source": True,
        "source_files_verified_against_original_git_commit": len(before["files"]),
        "source_bytes_verified": source_bytes,
        "build_source_hashes_match_source_manifest": len(build["source_sha256"]),
        "command_record_and_output_hashes_verified": len(jobs) * 3,
        "runner_build_source_manifest_hashes_verified": True,
        "reference_build_record_hashes_verified": len(index["references"]),
        "artifact_metadata_matches_build_record": True,
        "recorded_final_tool_artifact_guards_passed": index["input_guards_passed"],
        "independent_binary_archive_rehash_performed": False,
        "evidence_manifest_entries": len(evidence),
        "evidence_manifest_sha256": index["evidence_manifest_sha256"],
        "build_record_sha256": index["build_record"]["sha256"],
        "source_manifest_sha256": index["source_manifest_sha256"],
    },
    "limits": [
        "This audits the original validation at 7d4011f; later benchmark-harness commits did not run this full matrix.",
        "129 counts orchestration commands, including tool discovery/builds; it is not a count of independent test cases.",
        "The 4,196 generic suite checks exclude the separately reported Base45/Luhn corpus checks and application/reference oracles.",
        "ASan/LSan covers generated programs and the runtime at O0/O1 with leak detection enabled; the compiler and Rust references are not sanitizer-instrumented.",
        "Luhn comparison covers all four str APIs using CPython 3.14.5 / Unicode 16; no Luhn diagnostic exclusions.",
        "Native Base45/Luhn per-case JSON lived in temporary suite directories because --output was omitted; retained summaries, exit status, and guarded harness source establish completion. Detailed Rust-reference JSON is retained.",
        "No Ruff job occurs in this frozen index; earlier fixture Ruff checks were exploratory.",
        "Large compiler/runtime/reference binaries and archives were not independently rehashed during CPU-sensitive timings; recorded final guards cover their identities.",
        "Historical benchmarks/results paths are excluded from per-file source hashes; the clean committed Git tree identifies those paths.",
        "No builds, tests, profiling, or benchmark workloads were executed by this independent audit.",
    ],
}
OUTPUT.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "audit": str(OUTPUT), "sha256": digest(OUTPUT)}))
