"""Package completed Luhn evidence; never run builds, tests, or measurements.

Example (run only after timing, profiling, and their audits are complete):
    python3 -I -B /tmp/imre-luhn-package-evidence.py \
        --profile-dir /tmp/imre-luhn-profile-final \
        --prefix /tmp/2026-10-20-luhn

The archive contains normalized, sorted regular files. Its external manifest
hashes every member and the archive itself. Repeating with the same inputs and
this script produces identical archive bytes, regardless of the output prefix.
"""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile


VALIDATION_REVISION = "7d4011f0413c63d0a4d111817c37f460a0656cac"
TIMING_REVISION = "6fa8681c1734513cc278511427029dea9dca471c"
SOURCE_COUNT = 384


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def option(command, flag):
    require(command.count(flag) == 1, f"expected one {flag}: {command}")
    return Path(command[command.index(flag) + 1])


def relative_name(value):
    name = PurePosixPath(value)
    require(not name.is_absolute() and ".." not in name.parts and str(name) != ".",
            f"unsafe archive path: {value}")
    return str(name)


def native_kind(header):
    """Classify native code by bytes, preserving benchmark I/O named *.bin."""
    if header.startswith(b"\x7fELF"):
        return "ELF native executable, object, or shared library"
    if header.startswith((b"!<arch>\n", b"!<thin>\n")):
        return "native static archive"
    if header.startswith((b"BC\xc0\xde", b"\xde\xc0\x17\x0b")):
        return "LLVM bitcode"
    if header[:4] in (b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
                      b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe",
                      b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca"):
        return "Mach-O native code"
    if header.startswith(b"MZ"):
        return "PE native code"
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/home/dev-user/code/oss/imre"))
    parser.add_argument("--validation-dir", type=Path, default=Path("/tmp/imre-luhn-validation-v1"))
    parser.add_argument("--timing-prefix", type=Path, default=Path("/tmp/imre-luhn-v2"))
    parser.add_argument("--timing-audit", type=Path, default=Path("/tmp/imre-luhn-benchmark-audit.json"))
    parser.add_argument("--failed-attempt-dir", type=Path, default=Path("/tmp/imre-luhn-attempt1"))
    parser.add_argument("--profile-dir", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, required=True, help="fresh output prefix under /tmp")
    parser.add_argument("--extra", type=Path, action="append", default=[],
                        help="additional audit or launcher file, retained under extras/")
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    validation = args.validation_dir.resolve(strict=True)
    profile = args.profile_dir.resolve(strict=True)
    failed = args.failed_attempt_dir.resolve(strict=True)
    prefix = args.prefix.resolve()
    require(Path("/tmp") in prefix.parents, "outputs must be under /tmp")
    archive_path = Path(str(prefix) + "-evidence.tar.gz")
    manifest_path = Path(str(prefix) + "-evidence-manifest.json")
    require(not archive_path.exists() and not manifest_path.exists(),
            "output files already exist; use a fresh prefix")
    require(prefix.parent.is_dir(), "output parent directory does not exist")

    # Check terminal records before scanning or compressing evidence.
    index = read_json(validation / "index.json")
    build = read_json(validation / "build.json")
    audit_path = Path("/tmp/imre-luhn-validation-audit.json")
    audit = read_json(audit_path)
    timing_status_path = Path(str(args.timing_prefix) + "-timing-status.json")
    timing = read_json(timing_status_path)
    timing_audit = read_json(args.timing_audit)
    profiling = read_json(profile / "summary.json")
    require(index["status"] == audit["status"] == timing["status"]
            == timing_audit["status"] == profiling["status"] == "passed",
            "all validation, timing, profile, and audit records must be passed")
    require(index["source_unchanged"] and index["input_guards_passed"]
            and build["source_matches_revision"] and build["input_guards_passed"]
            and profiling["complete"] and profiling["input_guards_passed"],
            "a completion or input guard failed")
    require(index["revision"] == build["revision"] == audit["validation_revision"]
            == timing["build_revision"] == timing["validation_revision"]
            == profiling["build_revision"] == profiling["validation_revision"]
            == VALIDATION_REVISION, "validation/build revision mismatch")
    require(timing["head"] == timing["timing_revision"]
            == timing_audit["timing_revision"] == profiling["revision"]
            == profiling["timing_revision"] == TIMING_REVISION,
            "timing/profile revision mismatch")
    require(index["job_counts"] == {"passed": 129, "failed": 0}
            and len(index["jobs"]) == 129 and index["unit_tests_passed"] == 145,
            "unexpected validation coverage")
    require(audit["validation_index_sha256"] == sha(validation / "index.json"),
            "validation audit describes another index")
    require(timing_audit["timing_status_sha256"] == sha(timing_status_path),
            "timing audit describes another run")
    require(len(profiling["profiles"]) == 4
            and {(item["engine"], item["tool"]) for item in profiling["profiles"]}
            == {(engine, tool) for engine in ("imre", "rust") for tool in ("callgrind", "dhat")}
            and all(item["status"] == "validated" and item["returncode"] == 0
                    for item in profiling["profiles"]), "incomplete profile matrix")

    def git(*arguments):
        return subprocess.check_output(["git", "-C", str(root), *arguments])

    subprocess.run(["git", "-C", str(root), "merge-base", "--is-ancestor",
                    VALIDATION_REVISION, TIMING_REVISION], check=True)
    changes = git("diff", "--name-only", VALIDATION_REVISION, TIMING_REVISION).decode().splitlines()
    require(changes == ["benchmarks/luhn_benchmark.py"], "unexpected post-validation source changes")
    display_patch = git("diff", VALIDATION_REVISION, TIMING_REVISION,
                        "--", "benchmarks/luhn_benchmark.py").decode().strip()
    for record in (timing, timing_audit, profiling):
        change = record["post_validation_changes"]
        require(change["paths"] == changes and change["patch"] == display_patch
                and change["patch_sha256"] == digest(display_patch.encode()),
                "recorded post-validation patch differs")
    full_patch = git("diff", "--binary", "--full-index", VALIDATION_REVISION, TIMING_REVISION)

    members = {}
    exclusions = []
    guarded_files = {}

    def verify(path, expected):
        path = Path(path)
        actual = sha(path)
        require(actual == expected, f"hash changed: {path}")
        prior = guarded_files.setdefault(str(path), actual)
        require(prior == actual, f"input changed while packaging: {path}")
        return actual

    def add_bytes(name, data, mode=0o644):
        name = relative_name(name)
        require(name not in members, f"duplicate archive member: {name}")
        require(native_kind(data[:16]) is None, f"native data cannot be an archive member: {name}")
        members[name] = {"data": data, "sha256": digest(data), "bytes": len(data), "mode": mode}

    def add_file(name, path):
        name, path = relative_name(name), Path(path)
        require(not path.is_symlink() and path.is_file(), f"expected regular file: {path}")
        with path.open("rb") as stream:
            header = stream.read(16)
        reason = native_kind(header)
        if path.suffix == ".pyc" or "__pycache__" in path.parts:
            reason = "generated Python bytecode"
        value = sha(path)
        guarded_files.setdefault(str(path), value)
        if reason:
            exclusions.append({"would_be_member": name, "path": str(path),
                               "sha256": value, "bytes": path.stat().st_size,
                               "reason": reason, "hash_verified_during_packaging": True})
            return
        require(name not in members, f"duplicate archive member: {name}")
        members[name] = {"path": path, "sha256": value, "bytes": path.stat().st_size,
                         "mode": 0o644}

    def add_tree(name, directory):
        for path in sorted(directory.rglob("*")):
            require(not path.is_symlink(), f"unexpected symlink in evidence: {path}")
            if path.is_file():
                add_file(f"{name}/{path.relative_to(directory).as_posix()}", path)

    def verify_manifest(directory, filename):
        manifest = read_json(directory / filename)
        for relative, expected in manifest.items():
            verify(directory / relative_name(relative), expected)
        return len(manifest)

    # Original manifests include omitted native artifacts. Retain them unchanged,
    # and describe the omissions explicitly rather than rewriting prior evidence.
    require(verify_manifest(validation, "evidence-sha256.json") == 438,
            "unexpected validation evidence manifest size")
    verify(validation / "evidence-sha256.json", index["evidence_manifest_sha256"])
    verify(validation / "runner.py", index["runner_sha256"])
    verify(validation / "build.json", index["build_record"]["sha256"])
    for job in index["jobs"]:
        require(job["status"] == "passed" and job["exit_code"] == 0, f"failed job: {job['name']}")
        for key in ("record", "stdout", "stderr"):
            verify(job[key], job[key + "_sha256"])
    source = read_json(validation / "source-before.json")
    require(source == read_json(validation / "source-after.json")
            and source["revision"] == VALIDATION_REVISION and source["status"] == "",
            "validation source snapshots differ")
    require(source["tree"] == git("rev-parse", f"{VALIDATION_REVISION}^{{tree}}").decode().strip(),
            "validation source tree differs")
    require(len(source["files"]) == SOURCE_COUNT, "unexpected source snapshot size")

    # Read only committed Git objects. Later report/doc commits do not change the
    # measured source snapshot or falsely move the full validation to a new HEAD.
    names = sorted(source["files"])
    tree_names = git("ls-tree", "-r", "--name-only", TIMING_REVISION).decode().splitlines()
    require(sorted(name for name in tree_names if not name.startswith("benchmarks/results/"))
            == names, "measured source file set changed")
    source_contents = {}
    for revision in (VALIDATION_REVISION, TIMING_REVISION):
        data = git("archive", "--format=tar", revision, "--", *names)
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:") as archive:
            blobs = {item.name: (archive.extractfile(item).read(), item.mode)
                     for item in archive if item.isfile()}
        require(set(blobs) == set(names), "Git source archive is incomplete")
        if revision == VALIDATION_REVISION:
            require(all(digest(blobs[name][0]) == entry["sha256"]
                        and bool(blobs[name][1] & 0o111) == entry["executable"]
                        for name, entry in source["files"].items()), "validation source hashes differ")
            require(all(digest(blobs[name][0]) == expected
                        for name, expected in build["source_sha256"].items()), "build source hashes differ")
        else:
            source_contents = blobs
            for name, (data, mode) in blobs.items():
                add_bytes(f"source/{name}", data, 0o755 if mode & 0o111 else 0o644)
    add_bytes("provenance/post-validation-harness.patch", full_patch)
    add_tree("validation", validation)
    add_file("audits/validation.json", audit_path)
    add_file("helpers/validation-audit.py", "/tmp/imre-luhn-validation-audit.py")
    verify("/tmp/imre-luhn-validation-audit.py", audit["audit_script_sha256"])

    require(len(timing["runs"]) == 2 and {item["mode"] for item in timing["runs"]}
            == {"normal", "thinlto"}, "incomplete timing matrix")
    add_file("timing/status.json", timing_status_path)
    add_file("timing/launcher-command.json", "/tmp/imre-luhn-timing-command-v2.json")
    add_file("audits/timing.json", args.timing_audit)
    add_file("helpers/timing-audit.py", "/tmp/imre-luhn-audit-benchmarks.py")
    verify("/tmp/imre-luhn-audit-benchmarks.py", timing_audit["auditor_sha256"])
    for name, path in timing["protected_paths"].items():
        verify(path, timing["source_and_tool_sha256"][name])
    add_file("helpers/timing-launcher.py", timing["protected_paths"]["helper"])
    timing_records = {}
    for run in timing["runs"]:
        mode = run["mode"]
        record_path = Path(str(args.timing_prefix) + f"-{mode}.json")
        directory = Path(str(args.timing_prefix) + f"-{mode}")
        record = read_json(record_path)
        verify(record_path, run["record_sha256"])
        require(run["returncode"] == 0 and record["revision"] == TIMING_REVISION
                and not record["dirty"] and record["input_guards_passed"]
                and record["thinlto"] == (mode == "thinlto"), f"incomplete {mode} timing")
        require(record["imre_build_record"] == build, "timing used another compiler build")
        verify(option(record["compile_command"], "-o"), record["binary_sha256"])
        verify(option(record["compile_command"], "--emit-llvm"), record["llvm_sha256"])
        require(read_json(option(record["validation_command"], "--output")) == record["validation"],
                "timing validation snapshot changed")
        require(timing_audit["identities"][mode]["record_sha256"] == run["record_sha256"],
                "audit timing record mismatch")
        for key in ("stdout", "stderr"):
            verify(run[key], run[key + "_sha256"])
            add_file(f"timing/{mode}.{key}.log", run[key])
        source_keys = {
            "harness": "benchmarks/luhn_benchmark.py",
            "validator": "benchmarks/luhn_validate.py",
            "shared_harness": "benchmarks/benchmark.py",
            "shared_validator": "benchmarks/validate.py",
        }
        for name, expected in record["source_and_tool_sha256"].items():
            relative = source_keys.get(name)
            for key, base in (("imre_source:", ""), ("example:", "examples/luhn_checksum/"),
                              ("rust_source:", "benchmarks/reference/luhn_checksum/")):
                if name.startswith(key):
                    relative = base + name.removeprefix(key)
            if relative is not None:
                require(digest(source_contents[relative][0]) == expected,
                        f"timed source differs from the committed snapshot: {relative}")
        add_file(f"timing/{mode}.json", record_path)
        add_tree(f"timing/{mode}", directory)
        timing_records[mode] = record

    require(profiling["benchmark_record_sha256"] in
            {run["record_sha256"] for run in timing["runs"]}, "profile is not from this timing run")
    profile_manifest_count = verify_manifest(profile, "manifest.json")
    for name, expected in profiling["snapshot_sha256"].items():
        verify(profile / relative_name(name), expected)
    for value in profiling["guarded_inputs"].values():
        verify(value["path"], value["sha256"])
    add_tree("profile", profile)

    preservation = read_json(failed / "preservation.json")
    require(preservation["status"] == "failed_before_timing", "unexpected first-attempt state")
    for name, expected in preservation["files"].items():
        verify(failed / relative_name(name), expected)
    add_tree("failed-attempt-1", failed)
    add_file("helpers/package-evidence.py", Path(__file__).resolve())
    for path in args.extra:
        add_file(f"extras/{path.name}", path.resolve(strict=True))
    for name, path, source_name in (
        ("runtime", Path("/tmp/imre-luhn-tests-validation-dev/unicode-tables-audit.json"),
         "crates/imre-runtime/src/integer_text.rs"),
        ("reference", Path("/tmp/imre-luhn-unicode-table-validation.json"),
         "benchmarks/reference/luhn_checksum/src/unicode.rs"),
    ):
        unicode_audit = read_json(path)
        require(unicode_audit["status"] == "passed"
                and unicode_audit["unicode_version"] == "16.0.0"
                and unicode_audit["source_sha256"] == digest(source_contents[source_name][0]),
                f"Unicode {name} audit describes another source")
        add_file(f"audits/unicode-{name}.json", path)

    # Toolchains are identified but never copied or recursively scanned.
    external = []
    for name, value in sorted(index["tools"].items()):
        verify(value["path"], value["sha256"])
        external.append({"origin": f"validation.tools.{name}", **value,
                         "reason": "tool executable omitted", "hash_verified_during_packaging": True})
    for name, value in sorted(profiling["guarded_inputs"].items()):
        if name.startswith("tool_"):
            external.append({"origin": f"profile.guarded_inputs.{name}", **value,
                             "reason": "profiling tool omitted", "hash_verified_during_packaging": True})
    metadata = {
        "schema": 1,
        "validation_revision": VALIDATION_REVISION,
        "validation_tree": source["tree"],
        "timing_revision": TIMING_REVISION,
        "timing_tree": git("rev-parse", f"{TIMING_REVISION}^{{tree}}").decode().strip(),
        "source_files": SOURCE_COUNT,
        "post_validation_paths": changes,
        "post_validation_patch_sha256": digest(full_patch),
        "post_validation_display_patch_sha256": digest(display_patch.encode()),
        "validation_counts": audit["counts"],
        "validation_index_sha256": sha(validation / "index.json"),
        "validation_build_sha256": sha(validation / "build.json"),
        "profile_manifest_entries": profile_manifest_count,
        "limits": audit["limits"],
        "notes": [
            "Full validation and compiler/runtime builds ran at the validation revision, not the later timing revision.",
            "The only intervening change is the retained benchmark metadata patch; compiler, runtime, tests, and examples are unchanged.",
            "Attempt 1 failed during benchmark metadata collection before timing; its exact preserved logs and artifacts are retained.",
            "Original manifests include native files omitted from this package; exclusions.json identifies those omissions by hash.",
            "All tracked measured source files are included except historical benchmarks/results/ artifacts.",
            "LLVM text and benchmark binary input/output data are retained; executable native code, archives, bitcode, and toolchains are excluded.",
            "Archive members are sorted; timestamps, ownership, and modes are normalized. Gzip mtime is zero.",
        ],
    }
    add_bytes("provenance/package.json", json_bytes(metadata))
    add_bytes("provenance/exclusions.json",
              json_bytes({"artifacts": sorted(exclusions, key=lambda item: item["would_be_member"]),
                          "external_tools": external}))

    # Recheck every selected input, including omitted artifacts and tools, before
    # writing. Each archived file is also checked against its planned bytes.
    for path, expected in guarded_files.items():
        require(sha(path) == expected, f"input changed before archive write: {path}")
    temporary = Path(str(archive_path) + ".partial")
    require(not temporary.exists(), "partial archive already exists")
    with temporary.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, value in sorted(members.items()):
                    data = value["data"] if "data" in value else value["path"].read_bytes()
                    require(digest(data) == value["sha256"] and len(data) == value["bytes"],
                            f"member changed during archive write: {name}")
                    item = tarfile.TarInfo(name)
                    item.size, item.mode, item.mtime = len(data), value["mode"], 0
                    item.uid = item.gid = 0
                    item.uname = item.gname = ""
                    archive.addfile(item, io.BytesIO(data))
    temporary.rename(archive_path)
    with tarfile.open(archive_path, "r:gz") as archive:
        archived = archive.getmembers()
        require([item.name for item in archived] == sorted(members),
                "archive membership differs from the manifest")
        for item in archived:
            data = archive.extractfile(item).read()
            require(item.isfile() and item.size == members[item.name]["bytes"]
                    and digest(data) == members[item.name]["sha256"]
                    and native_kind(data[:16]) is None,
                    f"archive member verification failed: {item.name}")
    manifest = {
        "schema": 1, "status": "passed", **metadata,
        "archive": {"name": archive_path.name, "sha256": sha(archive_path),
                    "bytes": archive_path.stat().st_size},
        "member_count": len(members),
        "members": {name: {key: value[key] for key in ("sha256", "bytes", "mode")}
                    for name, value in sorted(members.items())},
        "excluded_artifact_count": len(exclusions),
        "packager_sha256": sha(Path(__file__).resolve()),
    }
    with manifest_path.open("xb") as stream:
        stream.write(json_bytes(manifest))
    print(json.dumps({"archive": str(archive_path), "manifest": str(manifest_path),
                      "members": len(members), "excluded_artifacts": len(exclusions),
                      "archive_sha256": manifest["archive"]["sha256"]}, indent=2))


if __name__ == "__main__":
    main()
