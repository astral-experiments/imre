"""Assemble deterministic concrete-layout evidence, excluding compiled binaries."""
import gzip
import hashlib
import io
import json
import runpy
import subprocess
import tarfile
from pathlib import Path

ROOT = Path.cwd().resolve()
LOCAL = ROOT / "benchmarks/local"
RESULTS = ROOT / "benchmarks/results"
PREFIX = "2026-10-18-concrete-layouts"
COMMIT = "4f60c860364e6f0d2cfbf9cc3a5b656f56988216"
driver = runpy.run_path(str(ROOT / "benchmarks/dependency_profile.py"))
layout = runpy.run_path(str(ROOT / "benchmarks/layout_benchmark.py"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def seal(path):
    data = path.read_bytes()
    return {"sha256": sha(data), "bytes": len(data)}


def compressed(path, data):
    with path.open("wb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0, compresslevel=9) as stream:
            stream.write(data)
    assert gzip.decompress(path.read_bytes()) == data
    return {**seal(path), "uncompressed_sha256": sha(data), "uncompressed_bytes": len(data)}


def verify_profile(path, recompute=False):
    provenance = read(path / "provenance.json")
    summary = read(path / "summary.json")
    for name, value in read(path / "manifest.json").items():
        assert seal(path / name) == value, path / name
    for item in provenance["runs"]:
        assert item["returncode"] == 0 and not item["timed_out"]
        assert item["output_matches"] and item["stderr_bytes"] == 0
        assert item["stdout_sha256"] == item["expected_stdout_sha256"]
        stem = f'{item["shape"]}-{item["tasks"]}.{item["engine"]}.{item["tool"]}'
        for suffix, key in (("trace", "trace"), ("log", "log"), ("stdout", "stdout"), ("stderr", "stderr")):
            assert seal(path / f"{stem}.{suffix}")["sha256"] == item[key + "_sha256"]
        assert seal(path / f'{item["shape"]}-{item["tasks"]}.stdin')["sha256"] == item["input_sha256"]
        assert seal(path / f'{item["shape"]}-{item["tasks"]}.expected.stdout')["sha256"] == item["expected_stdout_sha256"]
    if recompute:
        for item in summary["runs"]:
            trace = path / f'{item["workload"]}.{item["engine"]}.{item["tool"]}.trace'
            parsed = driver[item["tool"]](trace)
            if item["tool"] == "callgrind":
                assert parsed["total_instructions"] == item["total_instructions"]
                assert parsed["exclusive_sum_verified"]
            else:
                assert parsed["totals"] == item["totals"]
    return provenance, summary


members = {}
omitted = []


def add(name, data):
    assert name not in members, name
    assert not data.startswith((b"\x7fELF", b"!<arch>\n")), name
    members[name] = data


def tree(prefix, path):
    for file in sorted(path.rglob("*")):
        if file.is_file():
            name = prefix + "/" + str(file.relative_to(path))
            data = file.read_bytes()
            if data.startswith((b"\x7fELF", b"!<arch>\n")):
                omitted.append({"path": name, "sha256": sha(data), "bytes": len(data)})
            else:
                add(name, data)


timings = {}
compact = {
    "schema_version": 1,
    "method": driver["METHOD"],
    "source_commit": COMMIT,
    "implementation_commit": read(LOCAL / "layout-tools-v2/build-record.json")["git_head"],
    "hardware_counters": "No hardware CPU counters were collected; Callgrind Ir is not CPU cycles or elapsed-time share.",
    "selection": "Current-Imre application profiles use exact final timed binaries. Baseline/Rust application profiles and storage probes reuse exact unchanged artifacts from integration profiling. Superseded current-Imre integration profiles remain in the raw archive but are not used for final tables.",
    "all_instrumented_outputs_checked": True,
    "archive_profile_runs": 56,
    "selected_profile_runs": 48,
    "modes": {},
    "storage_mechanism": {
        "probe_source": "benchmarks/fixtures/layout_storage.py",
        "probe_source_sha256": seal(ROOT / "benchmarks/fixtures/layout_storage.py")["sha256"],
        "optional_wrappers": "At size N the present integer and present Leaf optionals lose exactly 2*N allocations. The remaining N Leaf records still allocate.",
        "object_requests": "Raw DHAT stacks show old generic object requests of 88 bytes; new Leaf requests are 24 bytes, four-field Record requests 48 bytes, and two-field tuple requests 32 bytes. Container capacity growth also affects total traffic.",
        "limits": "Requested allocator bytes and peak live heap are not RSS; the synthetic storage fixture is a mechanism probe, not an elapsed-time application benchmark.",
    },
}
for mode in ("normal", "lto"):
    raw_path = LOCAL / f"layout-{mode}-final.json"
    record = read(raw_path)
    assert record["git"] == {"revision": COMMIT, "dirty": False}
    timings[mode] = compressed(RESULTS / f"{PREFIX}-{mode}.json.gz", raw_path.read_bytes())
    old = LOCAL / f"layout-v2-profile-{mode}"
    final = LOCAL / f"layout-exact-final-profile-{mode}"
    old_prov, old_summary = verify_profile(old / "applications")
    probe_prov, probe_summary = verify_profile(old / "storage")
    final_prov, final_summary = verify_profile(final, recompute=True)
    bridge_path = LOCAL / f"layout-exact-final-{mode}-bridge.json"
    bridge = read(bridge_path)
    assert bridge["input_sha256"]["comparison"] == seal(raw_path)["sha256"]
    assert bridge["input_sha256"]["binary"] == record["sha256"]["incremental_binary"]
    assert bridge["input_sha256"]["ir"] == record["sha256"]["incremental_ir"]
    assert final_prov["binaries"]["imre"]["sha256"] == record["sha256"]["incremental_binary"]
    for engine, key in (("baseline", "baseline:incremental_binary"), ("rust_bigint", "baseline:rust_incremental")):
        assert old_prov["binaries"][engine]["sha256"] == record["sha256"][key]
    selected = [(item, old_prov, f"profiles/integration/{mode}/applications") for item in old_summary["runs"] if item["engine"] != "imre"]
    selected += [(item, final_prov, f"profiles/final/{mode}") for item in final_summary["runs"]]
    applications = []
    for workload in sorted({item[0]["workload"] for item in selected}):
        for engine in ("baseline", "imre", "rust_bigint"):
            pairs = {item[0]["tool"]: item for item in selected if item[0]["workload"] == workload and item[0]["engine"] == engine}
            cg, provenance, prefix = pairs["callgrind"]
            dhat = pairs["dhat"][0]
            runs = [item for item in provenance["runs"] if f'{item["shape"]}-{item["tasks"]}' == workload and item["engine"] == engine]
            applications.append({
                "workload": workload, "engine": engine,
                "binary": provenance["binaries"][engine],
                "instructions": cg["total_instructions"], "exclusive_sum_verified": cg["exclusive_sum_verified"],
                "allocations": dhat["totals"],
                "top_functions": cg["functions"][:20],
                "allocation_entries": dhat["by_nearest_runtime_entry"],
                "raw_evidence_prefix": prefix,
                "runs": runs,
            })
    probe = read(old / "provenance.json")["probe"]
    storage = [{key: item[key] for key in ("workload", "engine", "trace_sha256", "totals", "by_nearest_runtime_entry")} for item in probe_summary["runs"]]
    compact["modes"][mode] = {
        "timing_record": timings[mode],
        "identity_bridge": bridge,
        "tools": record["tools"],
        "tool_sha256": {key: value for key, value in record["sha256"].items() if key in ("compiler", "runtime", "clang", "lto_linker", "python", "imre_build_record", "baseline_index")},
        "source_sha256": record["sources"],
        "artifacts": {key: {"sha256": record["sha256"][key], **value} for key, value in record["artifacts"].items() if key in ("incremental_binary", "incremental_ir", "batch_binary", "batch_ir", "manifest_binary", "manifest_ir")},
        "applications": applications,
        "storage": {"source_sha256": probe["source_sha256"], "compilation": probe["compilation"], "validation": probe["validation"], "oracle": probe["oracle"], "binaries": probe_prov["binaries"], "runs": storage, "raw_evidence_prefix": f"profiles/integration/{mode}/storage"},
    }
    tree(f"profiles/integration/{mode}", old)
    tree(f"profiles/final/{mode}", final)
    add(f"profiles/final/{mode}-bridge.json", bridge_path.read_bytes())
    add(f"profiles/final/{mode}-inputs.json", (LOCAL / f"layout-exact-final-{mode}-inputs.json").read_bytes())
    add(f"profiles/integration/{mode}-comparison.json", (LOCAL / f"layout-v2-integration-{mode}.json").read_bytes())
    for name in ("incremental_planner", "batch_planner", "manifest_planner"):
        add(f"final-ir/{mode}/{name}.ll", (LOCAL / f"layout-{mode}-final/{name}.ll").read_bytes())

build_path = LOCAL / "layout-tools-v2/build-record.json"
(RESULTS / f"{PREFIX}-build.json").write_bytes(build_path.read_bytes())
tree("tools", LOCAL / "layout-tools-v2")
tree("baseline", LOCAL / "layout-baseline")
add("profiles/integration/audit.json", (LOCAL / "layout-v2-profile-audit.json").read_bytes())
add("helpers/final-profile.py", Path("/tmp/imre-layout-final-profile.py").read_bytes())
add("helpers/publish-evidence.py", Path(__file__).read_bytes())
source_names = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", COMMIT], cwd=ROOT, text=True).splitlines()
source_names = [name for name in source_names if not name.startswith("benchmarks/results/")]
source_tar = subprocess.check_output(["git", "archive", "--format=tar", COMMIT, *source_names], cwd=ROOT)
add("source/current.tar", source_tar)
add("source/current-manifest.json", encoded({"commit": COMMIT, "sha256": sha(source_tar), "files": source_names}))
add("README.md", b"# Concrete-layout raw evidence\n\nThe final timing JSON gzip files are published alongside this archive. Their exact hashes are in manifest.json and the compact profiles JSON. No compiled binaries or runtime archives are distributed here; omitted artifact identities remain recorded.\n\nprofiles/final contains refreshed profiles of the exact final timed Imre incremental executables. profiles/integration retains raw profiles of unchanged baseline/Rust executables and storage probes; its current-Imre application profiles are superseded. The final bridge JSONs tie final executable, IR, compiler/runtime, source, and comparison hashes together. Every profile preserves full stdout, expected stdout, stdin, log, raw trace, and collection command. Instrumented elapsed time is diagnostic only.\n\nsource/current.tar is the source snapshot at the clean benchmark commit; baseline/source.tar is the preserved baseline source snapshot. Full compiler/runtime and Rust source/build records are included. Absolute paths in original records identify the original local environment and need adaptation for reproduction. Rebuilds receive new identities rather than being relabeled as the measured binaries.\n\nThe outer tar uses sorted member names, zero timestamps/UIDs/GIDs, mode0644, and gzip mtime0 with no filename. Per-member SHA256 and byte lengths are listed in manifest.json.\n")
compact["evidence_archive"] = f"{PREFIX}-evidence.tar.gz"
compact["evidence_manifest"] = f"{PREFIX}-evidence-manifest.json"
compact["integration_profile_audit"] = seal(LOCAL / "layout-v2-profile-audit.json")
compact["build_record"] = seal(build_path)
profile_data = encoded(compact)
(RESULTS / f"{PREFIX}-profiles.json").write_bytes(profile_data)
add("profiles/selected-summary.json", profile_data)
manifest = {
    "schema_version": 1,
    "source_commit": COMMIT,
    "timing_records": timings,
    "profiles": {"sha256": sha(profile_data), "bytes": len(profile_data)},
    "build_record": seal(build_path),
    "members": {name: {"sha256": sha(data), "bytes": len(data)} for name, data in sorted(members.items())},
    "omitted_compiled_artifacts": omitted,
    "determinism": "Sorted tar members, mtime/uid/gid0, empty user/group names, mode0644, gzipmtime0 and empty filename.",
}
add("manifest.json", encoded(manifest))
archive = RESULTS / f"{PREFIX}-evidence.tar.gz"
with archive.open("wb") as output:
    with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0, compresslevel=9) as stream:
        with tarfile.open(fileobj=stream, mode="w|", format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo("concrete-layouts-evidence/" + name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, "r:gz") as tar:
    for member in tar:
        name = member.name.removeprefix("concrete-layouts-evidence/")
        assert tar.extractfile(member).read() == members[name], name
manifest["archive"] = {"filename": archive.name, **seal(archive), "member_count": len(members), "uncompressed_member_bytes": sum(map(len, members.values()))}
(RESULTS / f"{PREFIX}-evidence-manifest.json").write_bytes(encoded(manifest))
print(json.dumps({"timings": timings, "archive": manifest["archive"], "profiles": manifest["profiles"], "omitted_binary_count": len(omitted)}, indent=2))
