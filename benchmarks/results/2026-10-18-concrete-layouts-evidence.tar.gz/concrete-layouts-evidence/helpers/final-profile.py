"""Profile only the exact final Imre binaries; reuse unchanged control evidence."""
import argparse
import hashlib
import json
import runpy
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, default=Path.cwd())
args = parser.parse_args()
root = args.root.resolve()
local = root / "benchmarks/local"
layout = runpy.run_path(str(root / "benchmarks/layout_benchmark.py"))
driver = runpy.run_path(str(root / "benchmarks/dependency_profile.py"))
context = layout["runtime_context"]
before = context()
for mode in ("normal", "lto"):
    record_path = local / f"layout-{mode}-final.json"
    record = json.loads(record_path.read_text())
    prior = local / f"layout-v2-profile-{mode}"
    adapter = json.loads((prior / "applications-inputs.json").read_text())
    binary = local / f"layout-{mode}-final/incremental_planner"
    ir = binary.with_suffix(".ll")
    build_path = local / "layout-tools-v2/build-record.json"
    build = json.loads(build_path.read_text())
    paths = {
        "comparison": record_path,
        "binary": binary,
        "ir": ir,
        "build_record": build_path,
        "compiler": build_path.parent / "imre",
        "runtime": build_path.parent / ("libimre_runtime_lto.a" if mode == "lto" else "libimre_runtime.a"),
        "driver": root / "benchmarks/dependency_profile.py",
    }
    hashes = {name: digest(path) for name, path in paths.items()}
    for name, recorded in (("binary", "incremental_binary"), ("ir", "incremental_ir"), ("build_record", "imre_build_record"), ("compiler", "compiler"), ("runtime", "runtime")):
        assert hashes[name] == record["sha256"][recorded], name
    for name, expected in build["source_sha256"].items():
        assert digest(root / name) == expected, name
    for name, expected in record["sources"].items():
        assert digest(root / "examples" / name) == expected, name
    for case in adapter["workloads"]:
        final = next(item for item in record["workloads"]["incremental"] if item["label"] == case["label"])
        for key in ("input", "expected_stdout", "input_sha256", "expected_stdout_sha256", "expected_stdout_bytes"):
            assert final[key] == case[key], (case["label"], key)
    adapter.update({
        "program": "concrete_layouts_exact_final_incremental",
        "git": record["git"],
        "source_comparison_sha256": hashes["comparison"],
        "binaries": {"imre": {"sha256": hashes["binary"], "bytes": binary.stat().st_size}},
        "exact_final_provenance": {
            "sha256": hashes,
            "compilation": record["compilation"]["incremental"],
            "options": record["options"],
            "tools": record["tools"],
            "build": layout["build_provenance"](build),
            "execution_before": before,
            "reason": "Final executable differs from integration artifact; IR is byte-identical. Only current Imre is rerun. Baseline, Rust, and storage probe identities remain unchanged.",
        },
    })
    adapter_path = local / f"layout-exact-final-{mode}-inputs.json"
    save(adapter_path, adapter)
    driver["profile"](argparse.Namespace(
        record=adapter_path, binary=[("imre", binary)], build_record=[],
        output=local / f"layout-exact-final-profile-{mode}", sizes=None, shapes=None,
        tools=["callgrind", "dhat"], valgrind=None, valgrind_lib=None, cpu=0, timeout=300,
    ))
    assert all(digest(path) == hashes[name] for name, path in paths.items())
    save(local / f"layout-exact-final-{mode}-bridge.json", {
        "schema_version": 1, "mode": mode, "source_git": record["git"],
        "input_sha256": hashes, "adapter_sha256": digest(adapter_path),
        "profile_provenance_sha256": digest(local / f"layout-exact-final-profile-{mode}/provenance.json"),
        "profile_summary_sha256": digest(local / f"layout-exact-final-profile-{mode}/summary.json"),
        "profile_manifest_sha256": digest(local / f"layout-exact-final-profile-{mode}/manifest.json"),
        "execution_after": context(), "all_inputs_unchanged": True,
    })
