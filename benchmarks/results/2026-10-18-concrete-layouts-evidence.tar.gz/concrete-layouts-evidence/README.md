# Concrete-layout raw evidence

The final timing JSON gzip files are published alongside this archive. Their exact hashes are in manifest.json and the compact profiles JSON. No compiled binaries or runtime archives are distributed here; omitted artifact identities remain recorded.

profiles/final contains refreshed profiles of the exact final timed Imre incremental executables. profiles/integration retains raw profiles of unchanged baseline/Rust executables and storage probes; its current-Imre application profiles are superseded. The final bridge JSONs tie final executable, IR, compiler/runtime, source, and comparison hashes together. Every profile preserves full stdout, expected stdout, stdin, log, raw trace, and collection command. Instrumented elapsed time is diagnostic only.

source/current.tar is the source snapshot at the clean benchmark commit; baseline/source.tar is the preserved baseline source snapshot. Full compiler/runtime and Rust source/build records are included. Absolute paths in original records identify the original local environment and need adaptation for reproduction. Rebuilds receive new identities rather than being relabeled as the measured binaries.

The outer tar uses sorted member names, zero timestamps/UIDs/GIDs, mode0644, and gzip mtime0 with no filename. Per-member SHA256 and byte lengths are listed in manifest.json.
