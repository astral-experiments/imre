# Scalar f-string evidence

`source/` is the complete tracked source tree at measured commit e9c2a879ff258892ffe8d2c6862b5fa7688eea57, excluding historical result files. `retained/` preserves local evidence under its original repository-relative paths; the manifest maps and hashes every member. Final raw timing JSON and reviewed indices are also published as separate companions.

The 84 validation-index evidence paths are retained, including both superseded ordinary/ASan fixture failures and corrected replacements. The initial two changed test-file contents were not captured; their hashes and failure logs are preserved, with the correction rationale in the validation index. No missing source bytes are reconstructed.

Builds, commands, validators, generated LLVM, old renderer sources, raw validation records, and audit scripts are preserved. Native executable/runtime/toolchain bytes and raw native .text dumps are excluded. Audits that inspect those artifacts or Git history still require the original paths and measured commit; paths in original observations are not rewritten.

The report renderer expects scalar-fstrings-comparison-summary.json beside its script and template, as retained under benchmarks/local. It produces scalar-fstrings-report.md. The packaging script creates new output only and runs no compiler, native program, benchmark, or profiler.
