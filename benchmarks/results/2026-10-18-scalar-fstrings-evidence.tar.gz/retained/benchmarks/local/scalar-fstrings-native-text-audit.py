"""Compare retained ELF code sections without modifying or executing either binary."""

import hashlib
import json
import struct
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def sections(path):
    data = path.read_bytes()
    header = struct.unpack_from("<16sHHIQQQIHHHHHH", data, 0)
    assert header[0][:6] == b"\x7fELF\x02\x01", "requires ELF64 little-endian"
    offset, entry_size, count, strings_index = (
        header[6],
        header[11],
        header[12],
        header[13],
    )
    assert entry_size == 64 and count > 0 and 0 < strings_index < count
    table = [
        struct.unpack_from("<IIQQQQIIQQ", data, offset + index * entry_size)
        for index in range(count)
    ]
    strings = table[strings_index]
    names = data[strings[4] : strings[4] + strings[5]]
    found = {}
    for section in table:
        end = names.index(0, section[0])
        name = names[section[0] : end].decode()
        assert name not in found
        content = (
            None if section[1] == 8 else data[section[4] : section[4] + section[5]]
        )
        found[name] = {
            "section_type": section[1],
            "size_bytes": section[5],
            "sha256": None if content is None else sha(content),
            "content": content,
        }
    assert ".text" in found and found[".text"]["content"] is not None
    return {
        "path": str(path),
        "binary_sha256": sha(data),
        "binary_bytes": len(data),
    }, found


session = json.loads((LOCAL / "scalar-fstrings-final-session.json").read_text())
assert session["source_commit"] == "e9c2a879ff258892ffe8d2c6862b5fa7688eea57"
result = {
    "method": "Read-only ELF64 little-endian section-table parsing with Python struct; no files are modified. Compare complete native .text byte sequences and SHA-256. Also list sections whose type, size or content changed; SHT_NOBITS has no file bytes.",
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "source_commit": session["source_commit"],
    "modes": {},
    "audit_script_sha256": sha(Path(__file__).read_bytes()),
    "audit_script_source": Path(__file__).read_text(),
}
for mode in ("normal", "lto"):
    record_path = LOCAL / f"scalar-fstrings-{mode}-final.json"
    record = json.loads(record_path.read_text())
    assert record["git"] == {"revision": session["source_commit"], "dirty": False}
    assert sha(record_path.read_bytes()) == session["runs"][mode]["record_sha256"]
    commands = record["method"]["commands"]["inventory"]
    old, old_sections = sections(Path(commands["baseline"][0]))
    new, new_sections = sections(Path(commands["relar"][0]))
    assert old["binary_sha256"] == record["sha256"]["inventory_baseline"]
    assert new["binary_sha256"] == record["sha256"]["inventory_binary"]
    for item, table in ((old, old_sections), (new, new_sections)):
        item["section_bytes"] = table[".text"]["size_bytes"]
        item["section_sha256"] = table[".text"]["sha256"]
    changed = {
        name: {
            label: {
                key: value for key, value in table[name].items() if key != "content"
            }
            if name in table
            else None
            for label, table in (("baseline", old_sections), ("current", new_sections))
        }
        for name in sorted(old_sections.keys() | new_sections.keys())
        if old_sections.get(name) != new_sections.get(name)
    }
    result["modes"][mode] = {
        "record_sha256": sha(record_path.read_bytes()),
        "baseline": old,
        "current": new,
        "text_byte_identical": old_sections[".text"]["content"]
        == new_sections[".text"]["content"],
        "complete_binary_byte_identical": old["binary_sha256"] == new["binary_sha256"],
        "changed_sections": changed,
    }
    for item in (old, new):
        assert sha(Path(item["path"]).read_bytes()) == item["binary_sha256"]
    result["modes"][mode]["input_hashes_unchanged_after_read"] = True
output = LOCAL / "scalar-fstrings-native-text-audit.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            "audit_sha256": sha(output.read_bytes()),
            "modes": {
                mode: {
                    key: item[key]
                    for key in (
                        "text_byte_identical",
                        "complete_binary_byte_identical",
                        "changed_sections",
                    )
                }
                for mode, item in result["modes"].items()
            },
        },
        indent=2,
    )
)
