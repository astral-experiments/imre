#!/usr/bin/env python3
"""Audit retained validation records; never build, execute, or time native tests."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import subprocess
from pathlib import Path

COMMIT = "e9c2a879ff258892ffe8d2c6862b5fa7688eea57"
PREFIX = Path("benchmarks/local")
SUITES = {
    "classes", "comprehensions", "containers", "differential", "exceptions",
    "files", "fstrings", "imports", "io",
}
LEVELS = {"ordinary": ["0", "3"], "asan": ["0", "1"], "thinlto": ["3"]}
RUNTIMES = {"ordinary": "libimre_runtime.a", "asan": "libimre_runtime_asan.a",
            "thinlto": "libimre_runtime_lto.a"}
COUNTS = {
    "ordinary": {"classes": 58, "comprehensions": 65, "containers": 282,
                 "differential": 112, "exceptions": 48, "files": 74,
                 "fstrings": 50, "imports": 51, "io": 20},
    "thinlto": {"classes": 56, "comprehensions": 52, "containers": 212,
                "differential": 72, "exceptions": 32, "files": 52,
                "fstrings": 40, "imports": 47, "io": 10},
}
COUNTS["asan"] = COUNTS["ordinary"]
CHANGED_TESTS = {"tests/fstrings.py", "tests/fixtures/fstrings/scalars.py"}
SANITIZER = re.compile(r"(?:ERROR|SUMMARY): (?:Address|Leak|UndefinedBehavior)Sanitizer|"
                       r"AddressSanitizer:DEADLYSIGNAL|runtime error:")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: object, detail: object) -> None:
    if not condition:
        raise ValueError(detail)


class Audit:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.files: dict[str, dict] = {}
        self.committed: set[str] = set()

    def path(self, name: str | Path) -> Path:
        path = Path(name)
        return path if path.is_absolute() else self.root / path

    def file(self, name: str | Path, expected: str | None = None) -> dict:
        path = self.path(name)
        label = str(path.relative_to(self.root)) if path.is_relative_to(self.root) else str(path)
        if label not in self.files:
            with path.open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            self.files[label] = {"sha256": digest, "bytes": path.stat().st_size}
        item = self.files[label]
        require(expected is None or item["sha256"] == expected, (label, "hash mismatch"))
        return {"path": label, **item}

    def reference(self, item: dict) -> dict:
        return self.file(item["path"], item["sha256"])

    def record(self, name: str | Path) -> tuple[dict, dict]:
        return json.loads(self.path(name).read_text()), self.file(name)

    def sources(self, sources: dict[str, str]) -> None:
        for name, expected in sources.items():
            self.file(name, expected)
            if name not in self.committed:
                blob = subprocess.check_output(["git", "show", f"{COMMIT}:{name}"], cwd=self.root)
                require(sha(blob) == expected, (name, "source differs from measured commit"))
                self.committed.add(name)


def option(command: list[str], flag: str) -> str:
    return command[command.index(flag) + 1]


def audit_builds(audit: Audit) -> tuple[dict, dict]:
    records, summaries = {}, {}
    for stage in ("dev1", "final"):
        directory = PREFIX / f"scalar-fstrings-tools-{stage}"
        record, reference = audit.record(directory / "build-record.json")
        audit.sources(record["source_sha256"])
        require(set(record["source_contents"]) == set(record["source_sha256"]), stage)
        for name, contents in record["source_contents"].items():
            require(sha(contents.encode()) == record["source_sha256"][name], name)
        audit.file("/tmp/imre-cargo.sh", sha(record["cargo_wrapper"].encode()))
        artifacts = {Path(name).name: audit.file(name, digest)
                     for name, digest in record["sha256"].items()}
        require(set(artifacts) == {"imre", *RUNTIMES.values()}, stage)
        require(set(record["commands"]) == set(LEVELS), stage)
        for mode, command in record["commands"].items():
            require(command["returncode"] == 0, (stage, mode))
            audit.file(directory / f"{mode}.log", command["log_sha256"])
        require(record["commands"]["asan"]["environment"]["RUSTFLAGS"]
                == "-Zsanitizer=address -Cforce-frame-pointers=yes", stage)
        require(record["commands"]["thinlto"]["environment"]["RUSTFLAGS"]
                == "-Clinker-plugin-lto", stage)
        if stage == "final":
            require(record["git_head"] == COMMIT and record["compiled_sources_match_commit"]
                    and record["git_status"] == "", "final build provenance")
        records[stage] = record
        summaries[stage] = {"record": reference, "recorded_head": record["git_head"],
                            "artifacts": artifacts,
                            "compiled_source_count": len(record["source_sha256"]),
                            "embedded_build_script_sha256": sha(record["build_script"].encode()),
                            "embedded_cargo_wrapper_sha256": sha(record["cargo_wrapper"].encode())}
    require(records["dev1"]["source_sha256"] == records["final"]["source_sha256"],
            "compiled sources changed after development validation")
    for name, artifact in summaries["final"]["artifacts"].items():
        require(artifact["sha256"] == summaries["dev1"]["artifacts"][name]["sha256"], name)
    return records, summaries


def audit_suites(audit: Audit, builds: dict) -> tuple[dict, list, dict]:
    selected, superseded, source_changes = {}, [], {}
    current_sources = None
    original_sources = None
    for mode in LEVELS:
        directory = PREFIX / "scalar-fstrings-validation-dev1" / mode
        original, original_ref = audit.record(directory / "results.json")
        records = [(original, original_ref)]
        require(set(original["results"]) == SUITES, mode)
        if mode != "thinlto":
            replacement, replacement_ref = audit.record(
                PREFIX / "scalar-fstrings-validation-fstrings" / mode / "results.json")
            require(set(replacement["results"]) == {"fstrings"} and replacement["passed"], mode)
            require(original["passed"] is False, "initial failure must remain explicit")
            require(set(original["test_sources"]) == set(replacement["test_sources"]), mode)
            changed = {name for name, digest in original["test_sources"].items()
                       if replacement["test_sources"][name] != digest}
            require(changed == CHANGED_TESTS, (mode, changed))
            if original_sources is not None:
                require(original_sources == original["test_sources"], "initial source snapshots differ")
            original_sources = original["test_sources"]
            source_changes = {name: {"initial_sha256": original["test_sources"][name],
                                    "corrected_sha256": replacement["test_sources"][name]}
                              for name in sorted(changed)}
            failed = original["results"]["fstrings"]
            require(failed["returncode"] == 1, (mode, "unexpected initial result"))
            failure_text = audit.path(failed["stderr"]["path"]).read_text()
            require("('scalars', '0'" in failure_text and
                    "rebinding a builtin, definition, or imported module is unsupported" in failure_text,
                    (mode, "unexpected initial failure reason"))
            superseded.append({"mode": mode, "source_record": original_ref,
                               "suite": "fstrings", "returncode": failed["returncode"],
                               "stdout": audit.reference(failed["stdout"]),
                               "stderr": audit.reference(failed["stderr"]),
                               "replacement_record": replacement_ref,
                               "reason": "The accepted scalars fixture rebound builtin str, which the pre-existing language contract rejects. The fixture was corrected and builtin rebinding moved to an explicit rejection; compiler behavior was unchanged."})
            records.append((replacement, replacement_ref))
        else:
            require(original["passed"], mode)
        mode_suites = {}
        for record, reference in records:
            require(record["mode"] == mode and record["inputs_unchanged"] and record["finished_at_unix"], mode)
            require(record["head"] == builds["dev1"]["git_head"], "validation build head")
            for tool, artifact in (("compiler", "imre"), ("runtime", RUNTIMES[mode])):
                item = audit.reference(record[tool])
                require(item["sha256"] == builds["dev1"]["sha256"][str(
                    PREFIX / "scalar-fstrings-tools-dev1" / artifact)], (mode, tool))
            audit.reference(record["runner"])
            corrected = mode == "thinlto" or record is not original
            if corrected:
                require(current_sources is None or current_sources == record["test_sources"],
                        "corrected/final source snapshots differ")
                current_sources = record["test_sources"]
                audit.sources(current_sources)
            else:
                audit.sources({name: digest for name, digest in record["test_sources"].items()
                               if name not in CHANGED_TESTS})
            for suite, entry in record["results"].items():
                if not corrected and suite == "fstrings":
                    continue
                require(suite not in mode_suites and entry["returncode"] == 0, (mode, suite))
                command = entry["command"]
                require(command[:3] == ["/home/dev-user/.local/bin/python3.14", "-I",
                                       str(audit.root / f"tests/{suite}.py")], command)
                for flag, expected in (("--compiler", record["compiler"]["path"]),
                                       ("--runtime", record["runtime"]["path"]),
                                       ("--python", "/home/dev-user/.local/bin/python3.14"),
                                       ("--clang", "/usr/bin/clang-18")):
                    require(option(command, flag) == expected, command)
                start = command.index("--opt-levels") + 1
                end = next((i for i in range(start, len(command)) if command[i].startswith("--")), len(command))
                require(command[start:end] == LEVELS[mode], command)
                require(("--sanitize" in command) == (mode == "asan"), command)
                require(("--lto-linker" in command) == (mode == "thinlto"), command)
                if mode == "thinlto":
                    require(option(command, "--target") == "x86_64-unknown-linux-gnu", command)
                    audit.file(option(command, "--lto-linker"))
                stdout, stderr = audit.reference(entry["stdout"]), audit.reference(entry["stderr"])
                require(stderr["bytes"] == 0, (mode, suite, "unexpected stderr"))
                text = audit.path(stdout["path"]).read_text().strip()
                match = re.search(r"^(?:Passed (\d+) .*checks|(\d+) import checks passed)", text)
                require(match is not None, (mode, suite, text))
                count = int(match.group(1) or match.group(2))
                require(count == COUNTS[mode][suite], (mode, suite, count))
                mode_suites[suite] = {"reported_checks": count, "source_record": reference,
                                      "stdout": stdout, "stderr": stderr, "returncode": 0}
        require(set(mode_suites) == SUITES, mode)
        selected[mode] = {"optimization_levels": LEVELS[mode], "suites": mode_suites,
                          "reported_checks": sum(x["reported_checks"] for x in mode_suites.values())}
    require(current_sources is not None and len(current_sources) == 61, "source count")
    return selected, superseded, {"changed_paths": source_changes,
                                 "unchanged_captured_test_sources": 59,
                                 "current_captured_test_sources": len(current_sources),
                                 "current_sources_match_measured_commit": True,
                                 "selected_existing_suites_depend_only_on_unchanged_paths": True,
                                 "initial_changed_file_contents_retained": False,
                                 "initial_changed_file_evidence": "The initial runner recorded source hashes and failure logs, not copies of the two uncommitted test files."}


def audit_cargo(audit: Audit) -> dict:
    record, reference = audit.record(PREFIX / "scalar-fstrings-cargo-validation/record.json")
    require(set(record["commands"]) == {"unit", "clippy", "fmt"} and record["finished_at_unix"], "cargo record")
    commands = {}
    for name, entry in record["commands"].items():
        require(entry["returncode"] == 0 and entry["command"][:2] == ["sh", "/tmp/imre-cargo.sh"], name)
        commands[name] = {"command": entry["command"], "returncode": 0,
                          "log": audit.file(entry["log"], entry["log_sha256"])}
    text = audit.path(commands["unit"]["log"]["path"]).read_text()
    counts = [int(value) for value in re.findall(r"test result: ok\. (\d+) passed; 0 failed;", text)]
    require(sum(counts) == 65 and sorted(value for value in counts if value) == [25, 40], counts)
    return {"record": reference, "runner": audit.file(PREFIX / "scalar-fstrings-cargo-checks.py"),
            "commands": commands, "unit_tests": 65, "compiler_unit_tests": 25,
            "runtime_unit_tests": 40,
            "provenance_limit": "The Cargo runner retained exact command, exit status, and log hashes, but no per-command source snapshot. Development and final build records independently contain identical compiled-source snapshots matching the measured commit."}


def audit_inventory(audit: Audit, final_build: dict) -> dict:
    directory = PREFIX / "scalar-fstrings-inventory-asan"
    record, reference = audit.record(directory / "record.json")
    require(record["passed"] and record["inputs_unchanged"] and record["tracer_pid"] == 0
            and record["head"] == COMMIT and record["finished_at_unix"], "inventory receipt")
    require(record["build_record_sha256"] == final_build["record"]["sha256"], "inventory build binding")
    require(record["environment"] == {"ASAN_OPTIONS": "detect_leaks=1:halt_on_error=1",
                                      "LSAN_OPTIONS": "exitcode=23"}, "inventory sanitizer environment")
    audit.sources(record["sources"])
    for name, entry in record["steps"].items():
        require(entry["returncode"] == 0, name)
        audit.file(entry["log"], entry["log_sha256"])
    require(set(record["steps"]) == {"build", "validate"}, "inventory step coverage")
    build = record["steps"]["build"]["command"]
    require(option(build, "--opt-level") == "1" and "--sanitize" in build, build)
    require(option(build, "--runtime").endswith("scalar-fstrings-tools-final/libimre_runtime_asan.a"), build)
    for name, digest in record["artifacts"].items():
        audit.file(name, digest)
    oracle, oracle_ref = audit.record(directory / "validation.json")
    engines = {"cpython", "imre", "rust_bigint"}
    require(set(oracle["engines"]) == engines and oracle["cases"] == len(oracle["records"]) == 176, "oracle coverage")
    labels, successes = set(), 0
    for row in oracle["records"]:
        label = row["case"]["label"]
        require(label not in labels, (label, "duplicate case"))
        labels.add(label)
        expected = row["expected"]
        successes += expected["returncode"] == 0
        for files in (row["case"]["files"], row["expected_files"]):
            for name, entry in files.items():
                content = base64.b64decode(entry["base64"], validate=True)
                require(sha(content) == entry["sha256"] and len(content) == entry["bytes"], (label, name))
        expected_files = {name: {key: value[key] for key in ("sha256", "bytes")}
                          for name, value in row["expected_files"].items()}
        require(set(row["engines"]) == engines, label)
        for engine, actual in row["engines"].items():
            require(actual["returncode"] == expected["returncode"], (label, engine, "status"))
            output = expected["stdout"].encode()
            require(actual["stdout_sha256"] == sha(output) and actual["stdout_bytes"] == len(output), (label, engine, "stdout"))
            require(actual["files"] == expected_files and actual["directories"] == expected["directories"], (label, engine, "filesystem"))
            require(not SANITIZER.search(actual["stderr"]), (label, engine, "sanitizer"))
            if expected["error_category"] is None:
                require(not actual["stderr"], (label, engine, "stderr"))
            else:
                require(actual["stderr"].strip().splitlines()[-1] == expected["error_category"] + ": " + expected["error_message"], (label, engine, "error"))
    require(successes == oracle["successful"] == 127 and oracle["terminal_errors"] == 49, "oracle counts")
    device = oracle["device_check"]
    require(device["case"] == "terminal-report-device-error" and set(device["engines"]) == engines, "device coverage")
    expected_files = {name: {"sha256": sha(content), "bytes": len(content)} for name, content in
                      {"stock.txt": b"1\na 4\n", "orders.txt": b"1\n1\na 2\n"}.items()}
    for engine, actual in device["engines"].items():
        require(actual["returncode"] == 1 and actual["stdout_sha256"] == sha(b"")
                and actual["stdout_bytes"] == 0, (engine, "device output"))
        require(actual["stderr"].strip().splitlines()[-1] == "OSError: report: cannot write"
                and not SANITIZER.search(actual["stderr"]), (engine, "device error"))
        require(actual["files"] == expected_files and actual["directories"] == [], (engine, "device files"))
    rust_path = option(record["steps"]["validate"]["command"], "--rust-bigint")
    return {"record": reference, "oracle": oracle_ref,
            "runner": audit.file(PREFIX / "scalar-fstrings-inventory-asan.py"),
            "rust_reference_current_file": audit.file(rust_path),
            "cases": 176, "successful_cases": 127, "terminal_error_cases": 49,
            "device_checks": 1, "engines": oracle["engines"],
            "complete_output_status_filesystem_verified": True,
            "sanitizer_diagnostics_absent": True,
            "sanitizer_scope": "Generated Imre code and runtime dependencies; the prebuilt Rust standard library was not instrumented."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    args = parser.parse_args()
    audit = Audit(args.root)
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=audit.root, text=True).strip()
    status = subprocess.check_output(["git", "status", "--porcelain"], cwd=audit.root, text=True)
    require(head == COMMIT and status == "", "expected clean measured source checkout")
    builds, build_summary = audit_builds(audit)
    suites, superseded, source_changes = audit_suites(audit, builds)
    cargo = audit_cargo(audit)
    inventory = audit_inventory(audit, build_summary["final"])
    tools = [audit.file(path) for path in ("/home/dev-user/.local/bin/python3.14", "/usr/bin/clang-18")]
    audit_script = audit.file(Path(__file__))
    output = {
        "schema": "imre-scalar-fstrings-validation-audit-v1",
        "measured_source_commit": COMMIT, "clean_source_checkout_verified": True,
        "audit_script": audit_script, "builds": build_summary,
        "final_and_development_artifacts_byte_identical": True,
        "compiled_sources_match_measured_commit": True,
        "suite_modes": suites, "total_reported_suite_checks": sum(x["reported_checks"] for x in suites.values()),
        "suite_count_note": "Counts include compile-time rejection checks, and are not counts of native process executions. No separate ThinLTO CLI suite is included.",
        "superseded_failed_entries": superseded, "test_source_reconciliation": source_changes,
        "cargo_validation": cargo, "inventory_sanitizer_oracle": inventory,
        "external_tools_current_hash_observations": tools,
        "external_tool_provenance_note": "Suite receipts retained Python/Clang version strings, not executable hashes. These hashes describe the current files and do not retroactively establish a pre-run hash receipt.",
        "verified_committed_sources": sorted(audit.committed),
        "verified_file_hashes": dict(sorted(audit.files.items())),
        "retained_local_evidence_paths": sorted(name for name in audit.files
            if name.startswith(str(PREFIX) + "/") and not name.endswith(".a")
            and Path(name).name not in {"imre", "inventory_reconciliation", "inventory-bigint", "ld.lld"}),
    }
    require(output["total_reported_suite_checks"] == 2093, "aggregate count")
    destination = audit.root / PREFIX / "scalar-fstrings-validation.json"
    destination.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": str(destination), "sha256": sha(destination.read_bytes()),
                      "checks": output["total_reported_suite_checks"],
                      "files_verified": len(audit.files), "committed_sources_verified": len(audit.committed),
                      "retained_local_evidence_paths": len(output["retained_local_evidence_paths"])}))


if __name__ == "__main__":
    main()
