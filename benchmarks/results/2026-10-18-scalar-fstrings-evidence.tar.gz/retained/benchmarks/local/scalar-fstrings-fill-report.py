"""Render the scalar-fstring comparison tables from independently audited medians."""

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
summary = json.loads((HERE / "scalar-fstrings-comparison-summary.json").read_text())
assert summary["all_baseline_current_iqrs_overlap"] is True
tables = []
for mode, title in (("normal", "Ordinary"), ("lto", "ThinLTO")):
    lines = [
        "**" + title + "**",
        "",
        "| Input | CPython ms | Previous Imre ms | Current Imre ms | Rust BigInt ms | Imre time change |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    rows = [row for row in summary["rows"] if row["mode"] == mode]
    assert len(rows) == 6
    for row in rows:
        median = row["median_ms"]
        lines.append(
            f"| {row['workload']} | {median['cpython']:.3f} | {median['baseline']:.3f} | "
            f"{median['imre']:.3f} | {median['rust_bigint']:.3f} | {row['new_vs_baseline_percent']:+.2f}% |"
        )
    tables.append("\n".join(lines))
template = (HERE / "scalar-fstrings-report-template.md").read_text()
assert template.count("@@TABLES@@") == 1
report = template.replace("@@TABLES@@", "\n\n".join(tables))
(HERE / "scalar-fstrings-report.md").write_text(report)
print("Wrote scalar-fstrings-report.md")
