import hashlib, json, subprocess, time
from pathlib import Path
root = Path('/home/dev-user/code/oss/relar')
out = root / 'benchmarks/local/scalar-fstrings-cargo-validation'
out.mkdir(exist_ok=False)
record = {'commands': {}, 'started_at_unix': time.time()}
for name, args in [('unit', ['test', '--workspace', '--locked']), ('clippy', ['clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']), ('fmt', ['fmt', '--all', '--check'])]:
    command = ['sh', '/tmp/relar-cargo.sh', *args]
    result = subprocess.run(command, cwd=root, capture_output=True)
    log = out / (name + '.log')
    log.write_bytes(result.stdout + result.stderr)
    record['commands'][name] = {'command': command, 'returncode': result.returncode, 'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    (out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
    print(name, result.returncode, (result.stdout + result.stderr).decode()[-5000:], flush=True)
    result.check_returncode()
record['finished_at_unix'] = time.time()
(out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
