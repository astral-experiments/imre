import hashlib, json, os, subprocess, time
from pathlib import Path
root=Path('/home/dev-user/code/oss/relar')
out=root/'benchmarks/local/scalar-fstrings-inventory-asan'
out.mkdir(exist_ok=False)
tools=root/'benchmarks/local/scalar-fstrings-tools-final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracer=next(line.split(':',1)[1].strip() for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('TracerPid:'))
assert tracer=='0', tracer
sources=sorted((root/'examples/inventory_reconciliation').rglob('*.py'))+sorted((root/'benchmarks').glob('*.py'))
record={'started_at_unix':time.time(),'tracer_pid':0,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':{str(p.relative_to(root)):sha(p) for p in sources},'build_record_sha256':sha(tools/'build-record.json'),'steps':{}}
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',LSAN_OPTIONS='exitcode=23')
record['environment']={k:env[k] for k in ['ASAN_OPTIONS','LSAN_OPTIONS']}
binary=out/'inventory_reconciliation'
commands={
 'build':[str(tools/'relar'),'build',str(root/'examples/inventory_reconciliation/__main__.py'),'--module-root',str(root/'examples'),'--runtime',str(tools/'librelar_runtime_asan.a'),'--clang','/usr/bin/clang-18','--opt-level','1','--sanitize','--emit-llvm',str(out/'inventory_reconciliation.ll'),'-o',str(binary)],
 'validate':['/home/dev-user/.local/bin/python3.14','-I',str(root/'benchmarks/inventory_validate.py'),'--python','/home/dev-user/.local/bin/python3.14','--binary',str(binary),'--rust-bigint',str(root/'benchmarks/local/inventory-reference-final-normal/inventory-bigint'),'--output',str(out/'validation.json')]
}
for name,command in commands.items():
 result=subprocess.run(command,cwd=root,env=env,capture_output=True)
 log=out/(name+'.log'); log.write_bytes(result.stdout+result.stderr)
 record['steps'][name]={'command':command,'returncode':result.returncode,'log':str(log),'log_sha256':sha(log)}
 (out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
 print(name,result.returncode,(result.stdout+result.stderr).decode()[-4000:],flush=True)
 result.check_returncode()
record['artifacts']={str(p.relative_to(root)):sha(p) for p in [binary,out/'inventory_reconciliation.ll',out/'validation.json']}
assert record['sources']=={str(p.relative_to(root)):sha(p) for p in sources}
record.update(finished_at_unix=time.time(),inputs_unchanged=True,passed=True)
(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
