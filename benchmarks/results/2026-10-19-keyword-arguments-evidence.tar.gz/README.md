# Keyword-argument evidence

`source/` is the complete tracked source tree at measured commit 3b7377367a6c93b19aa8981ccd97131bc7442e83, excluding historical result files. `retained/` preserves local evidence under its original repository-relative paths; the manifest maps and hashes every member. Final raw timing JSON and reviewed indices are also published as separate companions.

All 110 validation-index evidence paths are retained, including the initial twelve general-suite sanitizer environment failures and the inventory sanitizer failure with its partial receipt. Successful retries preserve compiler/runtime/source inputs and keep leak detection enabled; the index records the execution-environment correction and provenance limits.

Builds, commands, validators, generated LLVM, previous package sources, raw validation records, and audit scripts are preserved. Native executable/runtime/toolchain bytes and raw native .text dumps are excluded. Audits that inspect those artifacts or Git history still require the original paths and measured commit; paths in original observations are not rewritten.

The report renderer expects keyword-arguments-comparison-summary.json beside its script and template, as retained under benchmarks/local. It produces keyword-arguments-report.md. The packaging script creates new output only and runs no compiler, native program, benchmark, or profiler.
