"""Rebuild unchanged reference code against the current licensing metadata."""

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
REFERENCE = ROOT / "benchmarks/reference/inventory_reconciliation"
OUTPUT = LOCAL / "keyword-arguments-reference-final-freeze.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not OUTPUT.exists(), "reference freeze record must be new"
expected_head = "3b7377367a6c93b19aa8981ccd97131bc7442e83"
assert subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip() == expected_head
assert not subprocess.check_output(["git", "-C", str(ROOT), "status", "--porcelain"])
snapshot = LOCAL / "keyword-arguments-baseline-source/manifest.json"
preserved = json.loads(snapshot.read_text())
source_hashes = {
    name: sha(REFERENCE / name) for name in ("Cargo.toml", "Cargo.lock", "src/main.rs")
}
unchanged = preserved["rust_reference_preparation"]["unchanged_source_sha256"]
assert all(source_hashes[name] == expected for name, expected in unchanged.items())
result = {
    "started_at_utc": datetime.now(timezone.utc).isoformat(),
    "clean_source_commit": expected_head,
    "runner_sha256": sha(Path(__file__)),
    "snapshot_manifest_sha256": sha(snapshot),
    "sources": source_hashes,
    "source_change": preserved["rust_reference_preparation"]["cargo_manifest_change"],
    "reference_algorithm_and_dependencies_unchanged": True,
    "builds": {},
}
for mode in ("normal", "lto"):
    artifacts = LOCAL / f"keyword-arguments-reference-final-{mode}"
    assert not artifacts.exists(), "reference artifact directory must be new"
    environment = dict(os.environ)
    for name in list(environment):
        if name.startswith("CARGO_PROFILE_RELEASE_"):
            environment.pop(name)
    if mode == "lto":
        environment["CARGO_PROFILE_RELEASE_LTO"] = "thin"
    command = [
        sys.executable,
        str(REFERENCE / "build.py"),
        "--toolchain",
        "ohm",
        "--cargo-wrapper",
        "/tmp/relar-cargo.sh",
        "--offline",
        "--artifact-dir",
        str(artifacts),
        "--target-dir",
        f"/home/dev-user/.cache/relar/inventory-reference-keyword-arguments-{mode}",
        "--build-cache",
        "/home/dev-user/.cache/ohm/shared-build",
    ]
    if mode == "lto":
        command += ["--llvm-budget", "1000"]
    log = LOCAL / f"keyword-arguments-reference-final-{mode}.log"
    print("Building reference " + mode, flush=True)
    started = datetime.now(timezone.utc).isoformat()
    with log.open("w") as output:
        process = subprocess.run(
            command,
            cwd=ROOT,
            env=environment,
            stdout=output,
            stderr=subprocess.STDOUT,
            check=False,
        )
    assert process.returncode == 0, f"reference build failed: {log}"
    record_path = artifacts / "build-record.json"
    record = json.loads(record_path.read_text())
    old = json.loads(
        (LOCAL / f"inventory-reference-final-{mode}/build-record.json").read_text()
    )
    assert record["sources"] == source_hashes
    assert record["tool_sha256"] == old["tool_sha256"]
    assert record["rustc_verbose"] == old["rustc_verbose"]
    assert record["cargo_version"] == old["cargo_version"]
    assert record["cargo_wrapper"] == old["cargo_wrapper"]
    assert record["llvm_budget"] == old["llvm_budget"]
    assert record["environment"] == old["environment"]
    binary = artifacts / "inventory-bigint"
    assert sha(binary) == record["binaries"]["bigint"]["sha256"]
    result["builds"][mode] = {
        "command": command,
        "started_at_utc": started,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "log_path": str(log),
        "log_sha256": sha(log),
        "returncode": process.returncode,
        "record_path": str(record_path),
        "record_sha256": sha(record_path),
        "binary_path": str(binary),
        "binary_sha256": sha(binary),
        "previous_binary_sha256": old["binaries"]["bigint"]["sha256"],
        "binary_byte_identical_to_previous": sha(binary)
        == old["binaries"]["bigint"]["sha256"],
        "tools_versions_wrapper_environment_and_budgets_match_previous": True,
    }
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["builds"][mode], indent=2), flush=True)
assert all(
    sha(REFERENCE / name) == expected for name, expected in source_hashes.items()
)
assert sha(Path(__file__)) == result["runner_sha256"]
assert subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip() == expected_head
assert not subprocess.check_output(["git", "-C", str(ROOT), "status", "--porcelain"])
result["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
print("Saved " + str(OUTPUT), flush=True)
