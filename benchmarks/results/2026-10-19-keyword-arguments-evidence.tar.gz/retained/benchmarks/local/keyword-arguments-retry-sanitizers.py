import concurrent.futures
import datetime
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
ORIGINAL = LOCAL / "keyword-arguments-suite-validation.json"
RECEIPT = LOCAL / "keyword-arguments-sanitizer-retry.json"
LOGS = LOCAL / "keyword-arguments-suites-unsandboxed"
LOGS.mkdir(exist_ok=True)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

original = json.loads(ORIGINAL.read_text())
jobs = [job for job in original["jobs"] if job["returncode"] != 0]
assert jobs and all(job["name"].startswith("asan") and "LeakSanitizer has encountered a fatal error" in job["tail"] for job in jobs)
hashes = original["tool_hashes"]
assert hashes == {path: digest(path) for path in hashes}

def run(job):
    start = time.monotonic()
    log = LOGS / f"{job['name']}.log"
    with log.open("wb") as stream:
        result = subprocess.run(job["command"], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    return {"name": job["name"], "command": job["command"], "returncode": result.returncode, "seconds": time.monotonic() - start, "log": str(log.relative_to(ROOT)), "log_sha256": digest(log), "tail": log.read_text()[-1800:]}

receipt = {
    "started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "original_receipt": str(ORIGINAL.relative_to(ROOT)),
    "original_sha256": digest(ORIGINAL),
    "reason": "Identical sanitizer commands rerun outside the execution sandbox after LeakSanitizer could not inspect traced threads; initial failures remain retained.",
    "asan_options": os.environ.get("ASAN_OPTIONS"),
    "lsan_options": os.environ.get("LSAN_OPTIONS"),
    "tool_hashes": hashes,
    "jobs": [],
}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for future in concurrent.futures.as_completed([pool.submit(run, job) for job in jobs]):
        result = future.result()
        receipt["jobs"].append(result)
        RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps({"name": result["name"], "returncode": result["returncode"], "tail": result["tail"][-400:]}), flush=True)
receipt["finished_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt["tools_unchanged"] = hashes == {path: digest(path) for path in hashes}
receipt["passed"] = receipt["tools_unchanged"] and all(job["returncode"] == 0 for job in receipt["jobs"])
RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n")
raise SystemExit(0 if receipt["passed"] else 1)
