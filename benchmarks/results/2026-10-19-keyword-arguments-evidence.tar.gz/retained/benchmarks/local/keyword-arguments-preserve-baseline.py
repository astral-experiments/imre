"""Preserve the complete pre-keyword package and verify frozen baseline evidence."""

import gzip
import hashlib
import json
import subprocess
import tomllib
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
SNAPSHOT = LOCAL / "keyword-arguments-baseline-source"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(path.read_bytes())


assert not SNAPSHOT.exists(), "snapshot destination must be new"
head = subprocess.check_output(
    ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
).strip()
sources = {
    str(path.relative_to(ROOT / "examples")): path.read_bytes()
    for path in sorted((ROOT / "examples/inventory_reconciliation").rglob("*.py"))
}
hashes = {name: digest(content) for name, content in sources.items()}
for name, content in sources.items():
    assert content == subprocess.check_output(
        ["git", "-C", str(ROOT), "show", f"{head}:examples/{name}"]
    )
published_manifest = json.loads(
    (
        ROOT / "benchmarks/results/2026-10-18-scalar-fstrings-evidence-manifest.json"
    ).read_text()
)
build_path = LOCAL / "scalar-fstrings-tools-final/build-record.json"
build = json.loads(build_path.read_text())
assert (
    sha(build_path)
    == published_manifest["companion_files"]["2026-10-18-scalar-fstrings-build.json"][
        "sha256"
    ]
)
for name, expected in build["sha256"].items():
    assert sha(ROOT / name) == expected, name
records = {}
for mode in ("normal", "lto"):
    record_path = LOCAL / f"scalar-fstrings-{mode}-final.json"
    record = json.loads(record_path.read_text())
    published_name = f"2026-10-18-scalar-fstrings-{mode}.json.gz"
    published = ROOT / "benchmarks/results" / published_name
    assert (
        sha(published)
        == published_manifest["companion_files"][published_name]["sha256"]
    )
    assert gzip.decompress(published.read_bytes()) == record_path.read_bytes()
    assert record["sources"] == hashes
    binary = LOCAL / f"scalar-fstrings-{mode}-final/inventory_reconciliation"
    llvm = binary.with_suffix(".ll")
    assert sha(binary) == record["sha256"]["inventory_binary"]
    assert sha(llvm) == record["sha256"]["inventory_ir"]
    assert record["sha256"]["compiler"] == sha(
        LOCAL / "scalar-fstrings-tools-final/relar"
    )
    runtime = "librelar_runtime_lto.a" if mode == "lto" else "librelar_runtime.a"
    assert record["sha256"]["runtime"] == sha(
        LOCAL / "scalar-fstrings-tools-final" / runtime
    )
    records[mode] = {
        "record_path": str(record_path),
        "record_sha256": sha(record_path),
        "binary_path": str(binary),
        "binary_sha256": sha(binary),
        "ir_path": str(llvm),
        "ir_sha256": sha(llvm),
        "sources_match": True,
        "published_record_bytes_match": True,
    }
reference = ROOT / "benchmarks/reference/inventory_reconciliation"
old_reference = json.loads(
    (LOCAL / "inventory-reference-final-normal/build-record.json").read_text()
)
for name in ("Cargo.lock", "src/main.rs"):
    assert sha(reference / name) == old_reference["sources"][name]
before_cargo = tomllib.loads(old_reference["source_contents"]["Cargo.toml"])
after_cargo = tomllib.loads((reference / "Cargo.toml").read_text())
assert "license" not in before_cargo["package"]
assert after_cargo["package"].pop("license") == "MIT OR Apache-2.0"
assert before_cargo == after_cargo, "reference manifest changed beyond licensing"
assert sha(reference / "build.py") == old_reference["build_script_sha256"]
for name, content in sources.items():
    destination = SNAPSHOT / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(content)
manifest = {
    "source_commit": head,
    "captured_at_utc": datetime.now(timezone.utc).isoformat(),
    "source_root": str(SNAPSHOT),
    "sources": hashes,
    "baseline_records": records,
    "frozen_tools": {
        "build_record_path": str(build_path),
        "build_record_sha256": sha(build_path),
        "files": build["sha256"],
        "published_build_record_hash_matches": True,
    },
    "rust_reference_preparation": {
        "previous_build_record": str(
            LOCAL / "inventory-reference-final-normal/build-record.json"
        ),
        "previous_build_record_sha256": sha(
            LOCAL / "inventory-reference-final-normal/build-record.json"
        ),
        "unchanged_source_sha256": {
            name: sha(reference / name) for name in ("Cargo.lock", "src/main.rs")
        },
        "cargo_manifest_change": "added package.license = MIT OR Apache-2.0; all other parsed fields identical",
        "fresh_builds_required_for_current_source_guards": True,
    },
    "snapshot_script_sha256": sha(Path(__file__)),
}
output = SNAPSHOT / "manifest.json"
output.write_text(json.dumps(manifest, indent=2) + "\n")
print(
    json.dumps(
        {
            "manifest": str(output),
            "sha256": sha(output),
            "source_count": len(sources),
            "baseline_modes": list(records),
        },
        indent=2,
    )
)
