"""Check rewritten CPython source against the oracle and preserved native programs."""

import hashlib
import json
import runpy
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
OUTPUT = LOCAL / "keyword-arguments-migration-oracle.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not OUTPUT.exists(), "migration oracle output must be new"
old_path = LOCAL / "scalar-fstrings-normal-final.json"
old = json.loads(old_path.read_text())
python = old["method"]["commands"]["inventory"]["cpython"][0]
validator_path = ROOT / "benchmarks/inventory_validate.py"
validator = SimpleNamespace(**runpy.run_path(str(validator_path)))
commands = {
    "cpython_keywords": validator.python_command(python),
    "relar_fstrings_baseline": [
        str(LOCAL / "scalar-fstrings-normal-final/inventory_reconciliation")
    ],
    "rust_bigint": [str(LOCAL / "keyword-arguments-reference-normal/inventory-bigint")],
}
paths = {
    "runner": Path(__file__),
    "validator": validator_path,
    "filesystem_oracle": ROOT / "benchmarks/manifest_validate.py",
    "baseline_record": old_path,
    "baseline_snapshot_manifest": LOCAL
    / "keyword-arguments-baseline-source/manifest.json",
    "rust_build_record": LOCAL / "keyword-arguments-reference-normal/build-record.json",
    **{engine: Path(command[0]) for engine, command in commands.items()},
    **{str(path.relative_to(ROOT)): path for path in validator.package_sources()},
}
before = {name: sha(path) for name, path in paths.items()}
started = datetime.now(timezone.utc).isoformat()
result = validator.validate_commands(commands)
assert {name: sha(path) for name, path in paths.items()} == before
assert (
    result["cases"] == 176
    and result["successful"] == 127
    and result["terminal_errors"] == 49
)
assert set(result["device_check"]["engines"]) == set(commands)
result["provenance"] = {
    "purpose": "pre-compiler migration validation; new CPython source vs preserved f-string Relar and current-provenance unchanged Rust",
    "started_at_utc": started,
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "commands": commands,
    "paths": {name: str(path) for name, path in paths.items()},
    "sha256_before_and_after": before,
    "no_timings": True,
}
OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print(
    json.dumps(
        {
            "cases": result["cases"],
            "successful": result["successful"],
            "terminal_errors": result["terminal_errors"],
            "engines": result["engines"],
            "device_checks": len(result["device_check"]["engines"]),
            "output": str(OUTPUT),
            "sha256": sha(OUTPUT),
        },
        indent=2,
    )
)
