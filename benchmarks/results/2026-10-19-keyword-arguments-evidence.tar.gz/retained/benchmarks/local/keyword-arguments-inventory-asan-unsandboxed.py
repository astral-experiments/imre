"""Instrument the migrated inventory program and check its complete I/O oracle."""

import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
OUTPUT = LOCAL / "keyword-arguments-inventory-asan-retry"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


OUTPUT.mkdir(exist_ok=False)
compiler = LOCAL / "keyword-arguments-tools-integration/relar"
runtime = LOCAL / "scalar-fstrings-tools-final/librelar_runtime_asan.a"
reference = LOCAL / "keyword-arguments-reference-normal/inventory-bigint"
integration = json.loads((LOCAL / "keyword-arguments-integration.json").read_text())
assert sha(compiler) == integration["frozen_tools"]["relar"]["sha256"]
snapshot = json.loads(
    (LOCAL / "keyword-arguments-baseline-source/manifest.json").read_text()
)
assert sha(runtime) == snapshot["frozen_tools"]["files"][str(runtime.relative_to(ROOT))]
baseline = json.loads((LOCAL / "scalar-fstrings-normal-final.json").read_text())
python = Path(baseline["method"]["commands"]["inventory"]["cpython"][0])
assert sha(python) == baseline["sha256"]["python"]
clang = Path("/usr/bin/clang-18")
assert sha(clang) == baseline["sha256"]["clang"]
assert (
    sha(reference)
    == json.loads((reference.parent / "build-record.json").read_text())["binaries"][
        "bigint"
    ]["sha256"]
)
tracer = next(
    line.split(":", 1)[1].strip()
    for line in Path("/proc/self/status").read_text().splitlines()
    if line.startswith("TracerPid:")
)
assert tracer == "0"
sources = [
    Path(__file__),
    *sorted((ROOT / "examples/inventory_reconciliation").rglob("*.py")),
    *sorted((ROOT / "benchmarks").glob("*.py")),
]
inputs = [
    compiler,
    runtime,
    reference,
    reference.parent / "build-record.json",
    python,
    clang,
    *sources,
]
hashes = {str(path): sha(path) for path in inputs}
record = {
    "started_at_unix": time.time(),
    "tracer_pid": 0,
    "head": subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
    ).strip(),
    "inputs_sha256": hashes,
    "steps": {},
    "retry_reason": "Original default-sandbox run reached a LeakSanitizer ptrace restriction at the empty oracle case; retry with the same compiler/runtime/reference hashes outside that sandbox.",
    "instrumentation_scope": "Generated Relar code and runtime dependencies; prebuilt Rust standard library is not instrumented.",
}
environment = dict(
    os.environ,
    ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",
    LSAN_OPTIONS="exitcode=23",
)
record["environment"] = {
    name: environment[name] for name in ("ASAN_OPTIONS", "LSAN_OPTIONS")
}
binary = OUTPUT / "inventory_reconciliation"
commands = {
    "build": [
        str(compiler),
        "build",
        str(ROOT / "examples/inventory_reconciliation/__main__.py"),
        "--module-root",
        str(ROOT / "examples"),
        "--runtime",
        str(runtime),
        "--clang",
        str(clang),
        "--target",
        "x86_64-unknown-linux-gnu",
        "--opt-level",
        "1",
        "--sanitize",
        "--emit-llvm",
        str(binary.with_suffix(".ll")),
        "-o",
        str(binary),
    ],
    "validate": [
        str(python),
        "-I",
        str(ROOT / "benchmarks/inventory_validate.py"),
        "--python",
        str(python),
        "--binary",
        str(binary),
        "--rust-bigint",
        str(reference),
        "--output",
        str(OUTPUT / "validation.json"),
    ],
}
for name, command in commands.items():
    result = subprocess.run(
        command, cwd=ROOT, env=environment, capture_output=True, check=False
    )
    log = OUTPUT / (name + ".log")
    log.write_bytes(result.stdout + result.stderr)
    record["steps"][name] = {
        "command": command,
        "returncode": result.returncode,
        "log": str(log),
        "log_sha256": sha(log),
    }
    (OUTPUT / "record.json").write_text(json.dumps(record, indent=2) + "\n")
    print(name, result.returncode, (result.stdout + result.stderr).decode(), flush=True)
    result.check_returncode()
assert all(sha(path) == hashes[str(path)] for path in inputs)
record["artifacts"] = {
    str(path.relative_to(ROOT)): sha(path)
    for path in (binary, binary.with_suffix(".ll"), OUTPUT / "validation.json")
}
record.update(finished_at_unix=time.time(), inputs_unchanged=True, passed=True)
(OUTPUT / "record.json").write_text(json.dumps(record, indent=2) + "\n")
print("record_sha256", sha(OUTPUT / "record.json"), flush=True)
