"""Exercise source-snapshot guards with mocked processes; no native runs or timing."""

import contextlib
import copy
import hashlib
import io
import json
import runpy
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
SOURCE = ROOT / "benchmarks/inventory_benchmark.py"
SNAPSHOT = LOCAL / "keyword-arguments-baseline-source"
TOOLS = LOCAL / "scalar-fstrings-tools-final"
OLD_PATH = LOCAL / "scalar-fstrings-normal-final.json"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


initial_hashes = {
    str(path.relative_to(ROOT)): digest(path) for path in (SOURCE, Path(__file__))
}
module = runpy.run_path(str(SOURCE))
benchmark = module["benchmark"]
shared, validator, prior = module["shared"], module["validator"], module["prior"]
old = json.loads(OLD_PATH.read_text())
build = json.loads((TOOLS / "build-record.json").read_text())
build["source_sha256"] = {"Cargo.toml": digest(ROOT / "Cargo.toml")}
current = {
    str(path.relative_to(validator.PACKAGE_ROOT)): digest(path)
    for path in validator.package_sources()
}
expected_old = {
    name: value
    for name, value in old["sources"].items()
    if name.startswith("inventory_reconciliation/")
}
expected_changes = {
    "inventory_reconciliation/__main__.py",
    "inventory_reconciliation/load.py",
    "inventory_reconciliation/model.py",
    "inventory_reconciliation/reconcile.py",
    "inventory_reconciliation/render.py",
}
assert {
    name for name in current if current[name] != expected_old[name]
} == expected_changes
checks = ["exact five-file keyword migration from preserved inventory baseline"]
python = old["method"]["commands"]["inventory"]["cpython"][0]
tool_hash_cache = {}
original_sha = shared.sha256


def sha(path):
    path = Path(path)
    if (
        path.suffix in {".a"}
        or path.name in {"imre", "clang-18", "python3.14", "inventory-bigint"}
        or path == LOCAL / "scalar-fstrings-normal-final/inventory_reconciliation"
    ):
        if path not in tool_hash_cache:
            tool_hash_cache[path] = original_sha(path)
        return tool_hash_cache[path]
    return original_sha(path)


def fake_run(command, stdin, timeout):
    del stdin, timeout
    if command[0] == python and command[1:3] == ["-I", "-c"]:
        info = copy.deepcopy(old["tools"]["cpython"])
        info["executable"] = python
        output = json.dumps(info)
    elif command[-1] == "-dumpmachine":
        output = "x86_64-unknown-linux-gnu\n"
    elif command[-1] == "--version":
        output = "mocked tool version\n"
    elif command[-2:] == ["rev-parse", "HEAD"]:
        output = "0" * 40 + "\n"
    elif command[-2:] == ["status", "--porcelain"]:
        output = ""
    elif len(command) > 1 and command[1] == "build":
        Path(command[command.index("-o") + 1]).write_bytes(b"mock executable\n")
        Path(command[command.index("--emit-llvm") + 1]).write_text("; mock IR\n")
        output = ""
    else:
        raise AssertionError("unexpected process attempt: " + repr(command))
    return {"stdout": output, "stderr": "", "returncode": 0}


with tempfile.TemporaryDirectory(prefix="keyword-arguments-preflight-") as temporary:
    base = Path(temporary)
    build_path = base / "build-record.json"
    build_path.write_text(json.dumps(build))
    case_number = 0

    def run_case(
        label,
        setup=lambda args, record, snapshot: None,
        mutation=None,
        expected=None,
        message=None,
        check=None,
    ):
        global case_number
        case_number += 1
        directory = base / str(case_number)
        snapshot = directory / "snapshot"
        shutil.copytree(SNAPSHOT, snapshot)
        record = copy.deepcopy(old)
        record["workloads"]["inventory"] = record["workloads"]["inventory"][:1]
        record_path = directory / "old.json"
        args = SimpleNamespace(
            compiler=TOOLS / "imre",
            runtime=TOOLS / "libimre_runtime.a",
            imre_build_record=build_path,
            rust_bigint=LOCAL / "keyword-arguments-reference-normal/inventory-bigint",
            rust_build_record=LOCAL
            / "keyword-arguments-reference-normal/build-record.json",
            rust_source_root=ROOT / "benchmarks/reference/inventory_reconciliation",
            inventory_baseline=LOCAL
            / "scalar-fstrings-normal-final/inventory_reconciliation",
            inventory_baseline_record=record_path,
            inventory_baseline_source_root=snapshot,
            baseline=None,
            baseline_record=None,
            python=python,
            clang="/usr/bin/clang-18",
            target="x86_64-unknown-linux-gnu",
            lto_linker=None,
            artifact_dir=directory / "artifacts",
            output=directory / "output.json",
            workloads=["empty"],
            control_workloads=None,
            samples=48,
            warmups=2,
            cpu=0,
            timeout=120,
            validate_only=True,
        )
        setup(args, record, snapshot)
        record_path.write_text(json.dumps(record))

        def fake_measure(value, commands, arguments):
            assert arguments is args
            assert list(commands) == ["cpython", "imre", "rust_bigint", "baseline"]
            if mutation:
                mutation(snapshot)
            return {**value, "gates": {}, "samples": [], "warmups": [], "summary": {}}

        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(shared, "run", fake_run))
            stack.enter_context(patch.object(shared, "sha256", sha))
            stack.enter_context(
                patch.object(shared, "pin_cpu", lambda _: {"selected_cpu": 0})
            )
            stack.enter_context(patch.object(prior, "runtime_context", dict))
            stack.enter_context(
                patch.object(validator, "validate_commands", lambda *_: {})
            )
            stack.enter_context(
                patch.dict(benchmark.__globals__, {"measure": fake_measure})
            )
            try:
                result = benchmark(args)
            except Exception as error:
                if expected is None or not isinstance(error, expected):
                    raise
                assert message is None or message in str(error), (label, error)
            else:
                assert expected is None, "unexpectedly accepted " + label
                if check:
                    check(result)
        checks.append(label)

    def inspect_result(result):
        snapshot = result["inventory_baseline_source"]
        assert snapshot["recorded_sources"] == expected_old
        assert snapshot["current_sources"] == current
        assert snapshot["changed_sources"] == {
            name: {
                "baseline_sha256": expected_old[name],
                "current_sha256": current[name],
            }
            for name in sorted(expected_changes)
        }
        assert {
            key.removeprefix("inventory_baseline_source:"): value
            for key, value in result["sha256"].items()
            if key.startswith("inventory_baseline_source:")
        } == expected_old

    run_case(
        "accept exact old snapshot and preserve old/current source provenance",
        check=inspect_result,
    )
    run_case(
        "reject source change without explicit snapshot",
        setup=lambda a, r, s: setattr(a, "inventory_baseline_source_root", None),
        expected=ValueError,
        message="unchanged source",
    )

    def unchanged(args, record, snapshot):
        args.inventory_baseline_source_root = None
        record["sources"] = current.copy()

    run_case(
        "accept unchanged-source baseline without snapshot",
        setup=unchanged,
        check=lambda r: (
            None
            if r["inventory_baseline_source"] is None
            else (_ for _ in ()).throw(AssertionError())
        ),
    )
    run_case(
        "reject missing old source file",
        setup=lambda a, r, s: (s / "inventory_reconciliation/render.py").unlink(),
        expected=ValueError,
        message="complete recorded package",
    )
    run_case(
        "reject added old source file",
        setup=lambda a, r, s: (s / "inventory_reconciliation/extra.py").write_text(
            "pass\n"
        ),
        expected=ValueError,
        message="complete recorded package",
    )
    run_case(
        "reject modified old source file",
        setup=lambda a, r, s: (s / "inventory_reconciliation/render.py").write_text(
            "pass\n"
        ),
        expected=ValueError,
        message="complete recorded package",
    )
    run_case(
        "reject nested unrecorded Python source",
        setup=lambda a, r, s: (
            (s / "inventory_reconciliation/extra").mkdir(),
            (s / "inventory_reconciliation/extra/nested.py").write_text("pass\n"),
        ),
        expected=ValueError,
        message="complete recorded package",
    )
    run_case(
        "reject record with missing source hash",
        setup=lambda a, r, s: r["sources"].pop("inventory_reconciliation/render.py"),
        expected=ValueError,
        message="complete recorded package",
    )
    run_case(
        "reject wrong preserved binary hash",
        setup=lambda a, r, s: r["sha256"].__setitem__("inventory_binary", "0" * 64),
        expected=ValueError,
        message="exact saved binary",
    )
    run_case(
        "reject mismatched baseline target",
        setup=lambda a, r, s: r["options"].__setitem__(
            "target", "aarch64-unknown-linux-gnu"
        ),
        expected=ValueError,
        message="target/linking mode",
    )
    run_case(
        "reject mismatched baseline linking mode",
        setup=lambda a, r, s: r["options"].__setitem__("lto", "thin"),
        expected=ValueError,
        message="target/linking mode",
    )
    run_case(
        "reject mismatched baseline LLVM budget",
        setup=lambda a, r, s: r["options"].__setitem__("llvm_budget", 1000),
        expected=ValueError,
        message="target/linking mode",
    )
    run_case(
        "reject mismatched baseline Clang hash",
        setup=lambda a, r, s: r["sha256"].__setitem__("clang", "0" * 64),
        expected=ValueError,
        message="current tool differ",
    )
    run_case(
        "reject snapshot output overwrite",
        setup=lambda a, r, s: setattr(
            a, "output", s / "inventory_reconciliation/render.py"
        ),
        expected=ValueError,
        message="must not overwrite inputs",
    )
    run_case(
        "reject source bytes changed during comparison",
        mutation=lambda s: (s / "inventory_reconciliation/render.py").write_text(
            "pass\n"
        ),
        expected=RuntimeError,
        message="input/tool/artifact changed",
    )
    run_case(
        "reject source added during comparison",
        mutation=lambda s: (s / "inventory_reconciliation/extra.py").write_text(
            "pass\n"
        ),
        expected=RuntimeError,
        message="source set changed",
    )
    run_case(
        "reject source removed during comparison",
        mutation=lambda s: (s / "inventory_reconciliation/render.py").unlink(),
        expected=RuntimeError,
        message="source set changed",
    )

    required = [
        item
        for name in [
            "compiler",
            "runtime",
            "imre-build-record",
            "rust-bigint",
            "rust-build-record",
        ]
        for item in ["--" + name, "unused"]
    ]
    error = io.StringIO()
    with (
        patch.object(
            sys,
            "argv",
            [
                "inventory_benchmark.py",
                *required,
                "--inventory-baseline-source-root",
                "unused",
            ],
        ),
        contextlib.redirect_stderr(error),
    ):
        try:
            module["main"]()
        except SystemExit as status:
            assert (
                status.code == 2
                and "requires an inventory baseline" in error.getvalue()
            )
        else:
            raise AssertionError("source snapshot accepted without baseline pair")
    checks.append("reject CLI snapshot without inventory baseline")

assert initial_hashes == {
    str(path.relative_to(ROOT)): digest(path) for path in (SOURCE, Path(__file__))
}
result = {
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "command": [sys.executable, *sys.argv],
    "source_sha256": initial_hashes,
    "baseline_record_sha256": digest(OLD_PATH),
    "baseline_snapshot_manifest_sha256": digest(SNAPSHOT / "manifest.json"),
    "checks_passed": len(checks),
    "checks": checks,
    "native_runs": 0,
    "builds": 0,
    "profiles": 0,
    "timing_samples": 0,
    "scope": "Pure-Python source snapshot/CLI guards. Tool probes, compilation, CPU pinning, native validation, and measurement are mocked. Synthetic temporary records never replace retained observations. This does not test process execution or ptrace refusal.",
}
output = LOCAL / "keyword-arguments-harness-checks.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(f"{len(checks)} checks passed; saved {output}")
