"""Join retained keyword-call validation receipts without executing native work."""

import hashlib
import json
import re
import runpy
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
COMMIT = "3b7377367a6c93b19aa8981ccd97131bc7442e83"
COMBINED_SHA = "63720b2c2893e6b037189f3f624edfe9e80ba6325ee94c25cd1d0da3e7a1be72"
FILES = {}
COMMITTED = set()
RETAINED = set()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def path_at(name):
    path = Path(name)
    return path if path.is_absolute() else ROOT / path


def reference(name, expected=None, retain=False):
    path = path_at(name)
    label = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
    if label not in FILES:
        with path.open("rb") as stream:
            sha = hashlib.file_digest(stream, "sha256").hexdigest()
        FILES[label] = {"sha256": sha, "bytes": path.stat().st_size}
    info = FILES[label]
    require(expected is None or info["sha256"] == expected, (label, "hash changed"))
    if retain:
        require(path.is_relative_to(LOCAL), (label, "retained root"))
        RETAINED.add(label)
    return {"path": label, **info}


def receipt(name, expected=None):
    path = LOCAL / name
    item = reference(path, expected, retain=True)
    return json.loads(path.read_text()), item


def source_hashes(hashes):
    for name, expected in hashes.items():
        reference(name, expected)
        if name not in COMMITTED:
            data = subprocess.check_output(
                ["git", "show", f"{COMMIT}:{name}"], cwd=ROOT
            )
            require(digest(data) == expected, (name, "measured source differs"))
            COMMITTED.add(name)


def item_reference(item, retain=False):
    result = reference(item["path"], item["sha256"], retain)
    if "bytes" in item:
        require(result["bytes"] == item["bytes"], "recorded size differs")
    return result


def check_count(log):
    text = path_at(log).read_text()
    match = re.search(r"(?:Passed (\d+) .*checks|(\d+) import checks passed)", text)
    require(match is not None, (log, "missing successful count"))
    return int(match.group(1) or match.group(2))


def main():
    head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip()
    status = subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=ROOT, text=True
    )
    require(
        head == COMMIT and status == "",
        "validation reconciliation needs clean measured HEAD",
    )
    combined, combined_ref = receipt(
        "keyword-arguments-validation-combined.json", COMBINED_SHA
    )
    require(combined["passed"] and combined["head"] == COMMIT, "combined receipt")
    for name, sha in combined["receipts"].items():
        reference(LOCAL / name, sha, retain=True)

    build, build_ref = receipt("keyword-arguments-tools-final/build-record.json")
    require(build["git_head"] == COMMIT and not build["git_status"], "final build head")
    require(build["compiled_sources_match_commit"], "final build source reconciliation")
    source_hashes(build["source_sha256"])
    require(
        set(build["source_contents"]) == set(build["source_sha256"]),
        "embedded build sources",
    )
    for name, contents in build["source_contents"].items():
        require(digest(contents.encode()) == build["source_sha256"][name], name)
    artifacts = {
        Path(name).name: reference(name, sha) for name, sha in build["sha256"].items()
    }
    reference(
        LOCAL / "keyword-arguments-build.py",
        digest(build["build_script"].encode()),
        True,
    )
    reference("/tmp/relar-cargo.sh", digest(build["cargo_wrapper"].encode()))
    for mode, command in build["commands"].items():
        require(command["returncode"] == 0, (mode, "build failed"))
        reference(
            LOCAL / f"keyword-arguments-tools-final/{mode}.log",
            command["log_sha256"],
            True,
        )

    focused, focused_ref = receipt("keyword-calls-validation-dev1/results.json")
    require(focused["passed"] and focused["inputs_unchanged"], "focused suite inputs")
    require(
        item_reference(focused["compiler"])["sha256"] == artifacts["relar"]["sha256"],
        "focused compiler",
    )
    runtime_names = {
        "ordinary": "librelar_runtime.a",
        "thinlto": "librelar_runtime_lto.a",
        "asan": "librelar_runtime_asan.a",
    }
    for mode, item in focused["runtimes"].items():
        require(
            item_reference(item)["sha256"] == artifacts[runtime_names[mode]]["sha256"],
            "focused runtime",
        )
    for key in ("python", "clang", "linker"):
        item_reference(focused[key])
    item_reference(focused["runner"], True)
    source_hashes(focused["test_sources"])
    require(len(focused["test_sources"]) == 70, "focused test source count")
    selected = {}
    for name, result in focused["results"].items():
        require(result["returncode"] == 0, name)
        stdout = item_reference(result["stdout"], True)
        require(item_reference(result["stderr"], True)["bytes"] == 0, name)
        selected[name] = {
            "checks": check_count(stdout["path"]),
            "log": stdout,
            "receipt": focused_ref,
        }
    require(sum(item["checks"] for item in selected.values()) == 224, "focused total")

    original, original_ref = receipt("keyword-arguments-suite-validation.json")
    retry, retry_ref = receipt("keyword-arguments-sanitizer-retry.json")
    require(
        original["passed"] is False and retry["passed"] is True, "original/retry status"
    )
    require(
        original["tools_unchanged"] and retry["tools_unchanged"], "suite tools changed"
    )
    require(retry["original_sha256"] == original_ref["sha256"], "retry receipt join")
    require(original["tool_hashes"] == retry["tool_hashes"], "retry changed tools")
    for name, sha in original["tool_hashes"].items():
        observed = reference(name, sha)
        require(
            observed["sha256"] == artifacts[Path(name).name]["sha256"],
            "suite/final artifact differs",
        )
    retry_jobs = {job["name"]: job for job in retry["jobs"]}
    superseded = []
    for job in original["jobs"]:
        name = job["name"]
        old_log = reference(job["log"], job["log_sha256"], True)
        source_record = original_ref
        if job["returncode"]:
            replacement = retry_jobs.pop(name)
            require(
                replacement["returncode"] == 0
                and replacement["command"] == job["command"],
                (name, "retry changed command"),
            )
            failure = path_at(job["log"]).read_text()
            require(
                "LeakSanitizer" in failure and "ptrace" in failure,
                (name, "unexpected initial failure"),
            )
            superseded.append(
                {
                    "name": name,
                    "returncode": job["returncode"],
                    "log": old_log,
                    "source_record": original_ref,
                    "replacement_record": retry_ref,
                    "reason": retry["reason"],
                }
            )
            job, source_record = replacement, retry_ref
        require(name not in selected and job["returncode"] == 0, name)
        log = reference(job["log"], job["log_sha256"], True)
        selected[name] = {
            "checks": check_count(log["path"]),
            "log": log,
            "receipt": source_record,
        }
    require(not retry_jobs and len(superseded) == 12, "retry coverage")
    require(
        set(selected) == {row["name"] for row in combined["rows"]},
        "combined selection differs",
    )
    for row in combined["rows"]:
        expected = selected[row["name"]]
        require(
            row["checks"] == expected["checks"]
            and row["log"] == expected["log"]["path"]
            and row["log_sha256"] == expected["log"]["sha256"],
            row["name"],
        )
    total = sum(item["checks"] for item in selected.values())
    require(total == combined["native_suite_checks"] == 2376, "semantic total")

    cargo, cargo_ref = receipt("keyword-arguments-rust-checks.json")
    require(len(cargo) == 3, "cargo validation coverage")
    for row in cargo:
        require(
            row["returncode"] == 0
            and row["command"][:2] == ["sh", "/tmp/relar-cargo.sh"],
            "cargo command",
        )
        reference(row["log"], row["sha256"], True)
    units = sum(
        map(
            int,
            re.findall(
                r"test result: ok\. (\d+) passed;", path_at(cargo[2]["log"]).read_text()
            ),
        )
    )
    require(units == combined["rust_unit_tests"] == 66, "unit count")

    failed_asan, failed_ref = receipt("keyword-arguments-inventory-asan/record.json")
    asan, asan_ref = receipt("keyword-arguments-inventory-asan-retry/record.json")
    require(
        asan["passed"] and asan["inputs_unchanged"] and asan["head"] == COMMIT,
        "inventory sanitizer status",
    )
    require("finished_at_unix" not in failed_asan, "initial partial receipt changed")
    require(
        asan["environment"]
        == failed_asan["environment"]
        == {
            "ASAN_OPTIONS": "detect_leaks=1:halt_on_error=1",
            "LSAN_OPTIONS": "exitcode=23",
        },
        "sanitizer options changed",
    )
    common = set(asan["inputs_sha256"]) & set(failed_asan["inputs_sha256"])
    require(
        len(common) == 31
        and all(
            asan["inputs_sha256"][name] == failed_asan["inputs_sha256"][name]
            for name in common
        ),
        "inventory retry inputs changed",
    )
    for data in (failed_asan, asan):
        for name, sha in data["inputs_sha256"].items():
            reference(name, sha)
        for name, step in data["steps"].items():
            expected = 1 if data is failed_asan and name == "validate" else 0
            require(step["returncode"] == expected, "unexpected inventory step status")
            reference(step["log"], step["log_sha256"], True)
    initial_log = reference(
        LOCAL / "keyword-arguments-inventory-asan/validate.log", retain=True
    )
    failure = path_at(initial_log["path"]).read_text()
    require(
        "LeakSanitizer" in failure and "ptrace" in failure,
        "initial inventory failure reason",
    )
    superseded.append(
        {
            "name": "inventory-asan",
            "returncode": failed_asan["steps"]["validate"]["returncode"],
            "status": "validation aborted; original receipt is partial",
            "log": initial_log,
            "source_record": failed_ref,
            "replacement_record": asan_ref,
            "reason": asan["retry_reason"],
        }
    )
    for name, sha in asan["artifacts"].items():
        reference(name, sha)

    audit_module = runpy.run_path(str(LOCAL / "keyword-arguments-final-audit.py"))
    sys.path.insert(0, str(ROOT / "benchmarks"))
    validator = runpy.run_path(str(ROOT / "benchmarks/inventory_validate.py"))
    oracles = {}
    for name in (
        "keyword-arguments-migration-oracle.json",
        "keyword-arguments-integration-oracle.json",
        "keyword-arguments-inventory-asan-retry/validation.json",
    ):
        value, item = receipt(name)
        audit_module["ENGINES"]["inventory"] = tuple(value["engines"])
        counts = audit_module["correctness"](
            {"validation": {"inventory": value}}, validator
        )
        oracles[name] = {
            "receipt": item,
            "cases": value["cases"],
            "engines": value["engines"],
            "process_outcomes": counts["inventory"],
            "device_outcomes": counts["inventory_device"],
        }
    integration, integration_ref = receipt("keyword-arguments-integration.json")
    for item in integration["frozen_tools"].values():
        require(
            item_reference(item)["sha256"]
            == artifacts[Path(item["path"]).name]["sha256"],
            "integration/final tool mismatch",
        )
    source_hashes(
        {
            name: sha
            for name, sha in integration["source_hashes"].items()
            if not name.startswith("benchmarks/local/")
        }
    )
    for name, sha in integration["source_hashes"].items():
        if name.startswith("benchmarks/local/"):
            reference(name, sha, True)
    for name, item in integration["builds"].items():
        require(item["returncode"] == 0, name)
        reference(item["binary_path"], item["binary_sha256"])
        reference(item["ir_path"], item["ir_sha256"], True)
        require(
            integration["comparisons"][name]["llvm_byte_identical_to_previous_baseline"]
            and integration["comparisons"][name][
                "native_text_byte_identical_to_previous_baseline"
            ],
            name,
        )
    item_reference(integration["oracle"])

    for name in (
        "keyword-arguments-run-suites.py",
        "keyword-arguments-retry-sanitizers.py",
        "keyword-arguments-inventory-asan.py",
        "keyword-arguments-inventory-asan-unsandboxed.py",
        "keyword-arguments-integration.py",
        "keyword-arguments-validate-migration.py",
        "keyword-arguments-build-references.py",
        "keyword-arguments-build-references-final.py",
        "keyword-arguments-reference-freeze.json",
        "keyword-arguments-reference-final-freeze.json",
        "keyword-arguments-preserve-baseline.py",
        "keyword-arguments-harness-checks.py",
        "keyword-arguments-harness-checks.json",
        "keyword-arguments-final-audit.py",
    ):
        reference(LOCAL / name, retain=True)
    for pattern in (
        "keyword-arguments-integration-*/*.log",
        "keyword-arguments-inventory-asan*/*.ll",
        "keyword-arguments-reference*/build-record.json",
        "keyword-arguments-reference*.log",
    ):
        for path in sorted(LOCAL.glob(pattern)):
            reference(path, retain=True)
    reference(Path(__file__), retain=True)
    result = {
        "schema": "relar-keyword-arguments-validation-v1",
        "measured_source_commit": COMMIT,
        "clean_source_checkout_verified": True,
        "compiled_sources_match_measured_commit": True,
        "final_and_development_artifacts_byte_identical": True,
        "build": build_ref,
        "combined_receipt": combined_ref,
        "total_reported_suite_checks": total,
        "suite_count_note": "Includes compile-time rejection checks and multiple optimization levels; this is not a process-execution count. Rust unit tests and application oracles are counted separately.",
        "selected_suites": selected,
        "cargo_validation": {
            "receipt": cargo_ref,
            "unit_tests": units,
            "fmt_clippy_tests_passed": True,
        },
        "inventory_oracles": oracles,
        "inventory_integration": integration_ref,
        "inventory_sanitizer": asan_ref,
        "superseded_failed_entries": superseded,
        "sanitizer_note": "Initial sandbox runs failed because LeakSanitizer could not use ptrace. The 12 general-suite commands were repeated unchanged outside the sandbox. The inventory retry used the same source/compiler/runtime/reference inputs and changed only its runner/output location. Leak detection stayed enabled. Its initial receipt is partial and the failure log is retained. Generated code and runtime dependencies are instrumented; prebuilt Rust standard library is not.",
        "provenance_limits": [
            "General-suite receipts capture commands, logs and compiler/runtime hashes before/after, but not pre-run test-source or external Python/Clang hashes. The focused receipt captures all 70 test-source hashes and tool hashes; these sources match the measured commit.",
            "Cargo validation retains commands, exit statuses and log hashes, without a per-command source snapshot. The subsequent clean final compiler/runtime build records its source hashes and embedded contents.",
            "The development integration compiler was initially copied and hashed, without its own build-source receipt. Its bytes match the final clean-commit compiler; the runtime artifacts also match.",
        ],
        "verified_committed_sources": sorted(COMMITTED),
        "verified_file_hashes": dict(sorted(FILES.items())),
        "retained_local_evidence_paths": sorted(RETAINED),
        "audit_script": reference(Path(__file__)),
    }
    output = LOCAL / "keyword-arguments-validation.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": "passed",
                "semantic_suite_checks": total,
                "rust_unit_tests": units,
                "retained_paths": len(RETAINED),
                "sha256": digest(output.read_bytes()),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
