"""Summarize the saved, independently audited keyword-call measurements."""

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
audit_path = HERE / "keyword-arguments-final-audit.json"
audit = json.loads(audit_path.read_text())
assert audit["status"] == "passed"
rows = []
for mode in audit["modes"]:
    for row in mode["rows"]:
        stats = row["statistics"]
        rows.append(
            {
                "mode": mode["mode"],
                "workload": row["workload"],
                "median_ms": row["median_ms"],
                "statistics_ns": stats,
                "new_vs_baseline_percent": row["new_vs_baseline_time_change_percent"],
                "cpython_speedup": row["ratios_of_medians"]["cpython_over_imre"],
                "imre_over_rust": row["ratios_of_medians"]["imre_over_rust_bigint"],
                "baseline_current_iqrs_overlap": max(
                    stats["imre"]["p25_ns"], stats["baseline"]["p25_ns"]
                )
                <= min(stats["imre"]["p75_ns"], stats["baseline"]["p75_ns"]),
            }
        )
counts = {
    "assertions": audit["assertions_passed"],
    "distinct_files_hashed": audit["distinct_files_hashed"],
    "measured": sum(mode["measured_process_runs"] for mode in audit["modes"]),
    "warmups": sum(mode["warmup_process_runs"] for mode in audit["modes"]),
    "gates": sum(mode["inventory_gate_runs"] for mode in audit["modes"]),
    "oracle_cases": sum(
        mode["validation_process_results"]["inventory"] for mode in audit["modes"]
    ),
    "device_cases": sum(
        mode["validation_process_results"]["inventory_device"]
        for mode in audit["modes"]
    ),
}
summary = {
    "schema": "imre-keyword-arguments-comparison-summary-v1",
    "audit_sha256": hashlib.sha256(audit_path.read_bytes()).hexdigest(),
    "source_commit": "3b7377367a6c93b19aa8981ccd97131bc7442e83",
    "counts": counts,
    "rows": rows,
    "all_baseline_current_iqrs_overlap": all(
        row["baseline_current_iqrs_overlap"] for row in rows
    ),
    "interpretation": "Same generated LLVM and native .text; this is a capability milestone, with no native speedup claim. IQR describes sample spread, not confidence.",
    "summary_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(HERE / "keyword-arguments-comparison-summary.json").write_text(
    json.dumps(summary, indent=2) + "\n"
)
print(
    json.dumps(
        {
            "counts": counts,
            "all_iqrs_overlap": summary["all_baseline_current_iqrs_overlap"],
        },
        indent=2,
    )
)
