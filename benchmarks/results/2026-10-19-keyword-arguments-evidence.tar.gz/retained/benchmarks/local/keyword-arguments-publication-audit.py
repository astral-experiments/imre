"""Independently check the published bytes, tar metadata, source snapshot, and links."""

import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
RESULTS = ROOT / "benchmarks/results"
PREFIX = "2026-10-19-keyword-arguments"


def digest(data):
    return hashlib.sha256(data).hexdigest()


manifest_path = RESULTS / f"{PREFIX}-evidence-manifest.json"
manifest = json.loads(manifest_path.read_text())
assert manifest["measured_source_commit"] == "3b7377367a6c93b19aa8981ccd97131bc7442e83"
archive_path = RESULTS / manifest["archive"]["file"]
archive_bytes = archive_path.read_bytes()
assert digest(archive_bytes) == manifest["archive"]["sha256"]
assert len(archive_bytes) == manifest["archive"]["bytes"]
assert archive_bytes[4:8] == b"\0" * 4 and archive_bytes[3] & 8 == 0
members = {}
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as archive:
    entries = archive.getmembers()
    assert [entry.name for entry in entries] == sorted(manifest["members"])
    assert len(entries) == manifest["archive"]["member_count"]
    for entry in entries:
        assert (
            entry.isfile()
            and not entry.name.startswith("/")
            and ".." not in Path(entry.name).parts
        )
        assert entry.mode == 0o644 and entry.uid == entry.gid == entry.mtime == 0
        assert entry.uname == entry.gname == ""
        data = archive.extractfile(entry).read()
        expected = manifest["members"][entry.name]
        assert digest(data) == expected["sha256"] and len(data) == expected["bytes"]
        assert not data.startswith((b"\x7fELF", b"!<arch>\n", b"BC\xc0\xde"))
        assert Path(entry.name).suffix not in {
            ".a",
            ".o",
            ".so",
            ".bc",
            ".rlib",
            ".exe",
            ".pyc",
            ".text",
        }
        data.decode("utf-8")
        members[entry.name] = data
sources = {
    name.removeprefix("source/"): data
    for name, data in members.items()
    if name.startswith("source/")
}
assert len(sources) == manifest["source_snapshot_file_count"]
assert not any(name.startswith("benchmarks/results/") for name in sources)
tracked = subprocess.check_output(
    [
        "git",
        "-C",
        str(ROOT),
        "ls-tree",
        "-r",
        "--name-only",
        manifest["measured_source_commit"],
    ],
    text=True,
).splitlines()
assert set(sources) == {
    name for name in tracked if not name.startswith("benchmarks/results/")
}
source_stream = subprocess.run(
    ["git", "-C", str(ROOT), "cat-file", "--batch"],
    input="".join(
        f"{manifest['measured_source_commit']}:{name}\n" for name in sources
    ).encode(),
    capture_output=True,
    check=True,
).stdout
position = 0
for name, expected in sources.items():
    end = source_stream.index(b"\n", position)
    header = source_stream[position:end].split()
    assert len(header) == 3 and header[1] == b"blob"
    size = int(header[2])
    position = end + 1
    assert source_stream[position : position + size] == expected
    position += size
    assert source_stream[position : position + 1] == b"\n"
    position += 1
assert position == len(source_stream)
for name, expected in manifest["companion_files"].items():
    data = (RESULTS / name).read_bytes()
    assert digest(data) == expected["sha256"] and len(data) == expected["bytes"]
    if name.endswith(".json.gz"):
        assert data[4:8] == b"\0" * 4 and data[3] & 8 == 0
        raw = gzip.decompress(data)
        assert digest(raw) == expected["decompressed_sha256"]
        mode = "normal" if "-normal." in name else "lto"
        assert raw == (LOCAL / f"keyword-arguments-{mode}-final.json").read_bytes()
for name, expected in manifest["external_baseline_records"].items():
    data = (RESULTS / name).read_bytes()
    assert digest(data) == expected["sha256"] and len(data) == expected["bytes"]
    assert digest(gzip.decompress(data)) == expected["decompressed_sha256"]
validation = json.loads((RESULTS / f"{PREFIX}-validation.json").read_text())
assert (
    len(validation["retained_local_evidence_paths"])
    == manifest["retained_validation_evidence_count"]
    == 110
)
for name in validation["retained_local_evidence_paths"]:
    assert members["retained/" + name] == (ROOT / name).read_bytes()
assert len(validation["superseded_failed_entries"]) == 13
for failure in validation["superseded_failed_entries"]:
    assert failure["returncode"] == 1 and failure["reason"]
    for field in ("source_record", "replacement_record", "log"):
        item = failure[field]
        data = members["retained/" + item["path"]]
        assert digest(data) == item["sha256"] and len(data) == item["bytes"]
report_path = RESULTS / f"{PREFIX}.md"
report = report_path.read_bytes()
links = []
for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", report.decode()):
    target = match.group(1)
    if "://" not in target:
        path, _, anchor = target.partition("#")
        resolved = (RESULTS / path).resolve()
        assert resolved.is_file(), target
        if anchor:
            headings = re.findall(r"^#+ (.*)$", resolved.read_text(), re.MULTILINE)
            assert anchor in [
                re.sub(r"[^\w -]", "", heading.lower()).replace(" ", "-")
                for heading in headings
            ]
    links.append(target)
with tempfile.TemporaryDirectory(
    prefix="keyword-arguments-report-reproduce-"
) as temporary:
    directory = Path(temporary)
    for name in (
        "keyword-arguments-fill-report.py",
        "keyword-arguments-report-template.md",
        "keyword-arguments-comparison-summary.json",
    ):
        (directory / name).write_bytes(members["retained/benchmarks/local/" + name])
    subprocess.run(
        [sys.executable, str(directory / "keyword-arguments-fill-report.py")],
        capture_output=True,
        check=True,
    )
    assert (directory / "keyword-arguments-report.md").read_bytes() == report
repeat = LOCAL / "keyword-arguments-publication-repeat"
expected_names = set(manifest["companion_files"]) | {
    archive_path.name,
    manifest_path.name,
}
assert {path.name for path in repeat.iterdir()} == expected_names
assert all(
    (repeat / name).read_bytes() == (RESULTS / name).read_bytes()
    for name in expected_names
)
assert f"results/{PREFIX}.md" in (ROOT / "benchmarks/README.md").read_text()
readme = (ROOT / "README.md").read_text()
assert f"benchmarks/results/{PREFIX}.md" in readme
assert (
    "| Dense inventory reconciliation | 16,384 | 21.32 ms | 76.65 ms | 3.60× |"
    in readme
)
assert (
    "| Sparse inventory reconciliation | 16,384 | 40.98 ms | 111.09 ms | 2.71× |"
    in readme
)
assert "Imre takes 4.6–9.8% more" in readme
result = {
    "status": "passed",
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "publication_files": {
        name: {
            "sha256": digest((RESULTS / name).read_bytes()),
            "bytes": (RESULTS / name).stat().st_size,
        }
        for name in sorted(expected_names)
    },
    "archive_members_verified": len(members),
    "source_files_verified_at_measured_commit": len(sources),
    "retained_validation_evidence_files": len(
        validation["retained_local_evidence_paths"]
    ),
    "compressed_raw_bytes_equal_original": True,
    "second_packaging_byte_identical": True,
    "archived_report_renderer_reproduces_published_bytes": True,
    "report_links_checked": links,
    "no_native_or_cache_payloads": True,
    "audit_script_sha256": digest(Path(__file__).read_bytes()),
}
output = LOCAL / "keyword-arguments-publication-audit.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            key: value
            for key, value in result.items()
            if key not in {"publication_files", "report_links_checked"}
        },
        indent=2,
    )
)
print("audit_sha256", digest(output.read_bytes()))
