import concurrent.futures
import datetime
import hashlib
import json
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
PYTHON = "/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14"
COMPILER = LOCAL / "keyword-arguments-tools-validation/imre"
RUNTIMES = LOCAL / "scalar-fstrings-tools-final"
TARGET = "x86_64-unknown-linux-gnu"
LLD_DIR = Path("/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib") / TARGET / "bin"
LOGS = LOCAL / "keyword-arguments-suites"
LOGS.mkdir(exist_ok=True)
RECEIPT = LOCAL / "keyword-arguments-suite-validation.json"
SUITES = ["differential", "imports", "classes", "containers", "comprehensions", "fstrings", "exceptions", "io", "files"]

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

tools = [COMPILER, *(RUNTIMES / name for name in ["libimre_runtime.a", "libimre_runtime_lto.a", "libimre_runtime_asan.a"])]
hashes = {str(path): digest(path) for path in tools}
jobs = []
for mode, suites, runtime, flags in [
    ("ordinary", [suite for suite in SUITES if suite != "classes"], "libimre_runtime.a", []),
    ("thinlto", SUITES, "libimre_runtime_lto.a", ["--target", TARGET, "--lto-linker", str(LLD_DIR / "gcc-ld/ld.lld"), "--opt-levels", "3"]),
    ("asan", SUITES, "libimre_runtime_asan.a", ["--sanitize", "--opt-levels", "1"]),
    ("asan-o0", ["containers", "fstrings", "files"], "libimre_runtime_asan.a", ["--sanitize", "--opt-levels", "0"]),
]:
    for suite in suites:
        command = [PYTHON, "-I", str(ROOT / f"tests/{suite}.py"), "--compiler", str(COMPILER), "--runtime", str(RUNTIMES / runtime), "--python", PYTHON, "--clang", "/usr/bin/clang-18", *flags]
        jobs.append((f"{mode}-{suite}", command))

def run(job):
    name, command = job
    start = time.monotonic()
    log = LOGS / f"{name}.log"
    with log.open("wb") as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    return {"name": name, "command": command, "returncode": result.returncode, "seconds": time.monotonic() - start, "log": str(log.relative_to(ROOT)), "log_sha256": digest(log), "tail": log.read_text()[-1800:]}

receipt = {"started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "tool_hashes": hashes, "jobs": []}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for future in concurrent.futures.as_completed([pool.submit(run, job) for job in jobs]):
        result = future.result()
        receipt["jobs"].append(result)
        RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps({"name": result["name"], "returncode": result["returncode"], "tail": result["tail"][-400:]}), flush=True)

receipt["finished_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt["tools_unchanged"] = hashes == {str(path): digest(path) for path in tools}
receipt["passed"] = receipt["tools_unchanged"] and all(job["returncode"] == 0 for job in receipt["jobs"])
RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n")
raise SystemExit(0 if receipt["passed"] else 1)
