"""Build both source forms and check full oracle behavior; no benchmark timing."""

import hashlib
import json
import runpy
import shutil
import struct
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
TOOLS = LOCAL / "keyword-arguments-tools-integration"
OUTPUT = LOCAL / "keyword-arguments-integration.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def native_text(path):
    data = path.read_bytes()
    header = struct.unpack_from("<16sHHIQQQIHHHHHH", data)
    assert header[0][:6] == b"\x7fELF\x02\x01"
    offset, width, count, names_index = header[6], header[11], header[12], header[13]
    assert width == 64
    sections = [
        struct.unpack_from("<IIQQQQIIQQ", data, offset + index * width)
        for index in range(count)
    ]
    names_section = sections[names_index]
    names = data[names_section[4] : names_section[4] + names_section[5]]
    for section in sections:
        if names[section[0] : names.index(0, section[0])] == b".text":
            return data[section[4] : section[4] + section[5]]
    raise AssertionError("missing native .text")


assert not TOOLS.exists() and not OUTPUT.exists(), "integration artifacts must be new"
TOOLS.mkdir()
source_tools = {
    "imre": Path("/home/dev-user/.cache/imre/target/release/imre"),
    "libimre_runtime.a": Path(
        "/home/dev-user/.cache/imre/target/release/libimre_runtime.a"
    ),
}
source_hashes = {name: sha(path) for name, path in source_tools.items()}
for name, path in source_tools.items():
    shutil.copy2(path, TOOLS / name)
    assert sha(TOOLS / name) == sha(path) == source_hashes[name]
validator_path = ROOT / "benchmarks/inventory_validate.py"
validator = SimpleNamespace(**runpy.run_path(str(validator_path)))
tracked = {
    str(path.relative_to(ROOT)): sha(path)
    for path in [
        Path(__file__),
        validator_path,
        ROOT / "benchmarks/manifest_validate.py",
        *validator.package_sources(),
    ]
}
snapshot = LOCAL / "keyword-arguments-baseline-source"
snapshot_hashes = {
    str(path.relative_to(snapshot)): sha(path)
    for path in sorted(snapshot.rglob("*.py"))
}
manifest = json.loads((snapshot / "manifest.json").read_text())
assert snapshot_hashes == manifest["sources"]
result = {
    "started_at_utc": datetime.now(timezone.utc).isoformat(),
    "no_timings": True,
    "git_head": subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True
    ).strip(),
    "git_status": subprocess.check_output(
        ["git", "-C", str(ROOT), "status", "--porcelain"], text=True
    ),
    "frozen_tools": {
        name: {
            "source_path": str(source_tools[name]),
            "path": str(TOOLS / name),
            "sha256": expected,
        }
        for name, expected in source_hashes.items()
    },
    "source_hashes": tracked,
    "baseline_package_hashes": snapshot_hashes,
    "source_provenance_note": "Development compiler executable frozen by hash after root supplied it; this receipt does not independently attest its compilation source snapshot.",
    "builds": {},
    "comparisons": {},
}
commands = {}
for mode in ("normal", "lto"):
    baseline_path = LOCAL / f"scalar-fstrings-{mode}-final.json"
    baseline = json.loads(baseline_path.read_text())
    if not commands:
        python = baseline["method"]["commands"]["inventory"]["cpython"][0]
        commands["cpython_keywords"] = validator.python_command(python)
    baseline_binary = LOCAL / f"scalar-fstrings-{mode}-final/inventory_reconciliation"
    baseline_ir = baseline_binary.with_suffix(".ll")
    assert sha(baseline_binary) == baseline["sha256"]["inventory_binary"]
    assert sha(baseline_ir) == baseline["sha256"]["inventory_ir"]
    commands[f"previous_imre_{mode}"] = [str(baseline_binary)]
    commands[f"rust_bigint_{mode}"] = [
        str(LOCAL / f"keyword-arguments-reference-{mode}/inventory-bigint")
    ]
    for source_form, module_root in (
        ("previous_source", snapshot),
        ("keyword_source", ROOT / "examples"),
    ):
        directory = LOCAL / f"keyword-arguments-integration-{mode}-{source_form}"
        assert not directory.exists()
        directory.mkdir()
        binary = directory / "inventory_reconciliation"
        llvm = binary.with_suffix(".ll")
        runtime = (
            (LOCAL / "scalar-fstrings-tools-final/libimre_runtime_lto.a")
            if mode == "lto"
            else TOOLS / "libimre_runtime.a"
        )
        command = list(baseline["method"]["compile_commands"]["inventory"])
        command[0] = str(TOOLS / "imre")
        command[2] = str(module_root / "inventory_reconciliation/__main__.py")
        for flag, value in (
            ("--module-root", module_root),
            ("--runtime", runtime),
            ("-o", binary),
            ("--emit-llvm", llvm),
        ):
            command[command.index(flag) + 1] = str(value)
        runtime_hash = sha(runtime)
        process = subprocess.run(
            command, cwd=ROOT, capture_output=True, text=True, check=False
        )
        (directory / "stdout.log").write_text(process.stdout)
        (directory / "stderr.log").write_text(process.stderr)
        key = mode + ":" + source_form
        result["builds"][key] = {
            "command": command,
            "returncode": process.returncode,
            "stdout": process.stdout,
            "stderr": process.stderr,
            "runtime_sha256": runtime_hash,
            "compiler_sha256": source_hashes["imre"],
        }
        OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
        assert process.returncode == 0, f"compile failed: {key}: {process.stderr}"
        assert (
            sha(runtime) == runtime_hash
            and sha(TOOLS / "imre") == source_hashes["imre"]
        )
        result["builds"][key].update(
            binary_path=str(binary),
            binary_sha256=sha(binary),
            ir_path=str(llvm),
            ir_sha256=sha(llvm),
        )
        result["comparisons"][key] = {
            "previous_baseline_record_sha256": sha(baseline_path),
            "previous_baseline_ir_sha256": sha(baseline_ir),
            "current_ir_sha256": sha(llvm),
            "llvm_byte_identical_to_previous_baseline": llvm.read_bytes()
            == baseline_ir.read_bytes(),
            "native_text_byte_identical_to_previous_baseline": native_text(binary)
            == native_text(baseline_binary),
            "native_text_sha256": hashlib.sha256(native_text(binary)).hexdigest(),
            "native_text_bytes": len(native_text(binary)),
        }
        commands[f"current_imre_{mode}_{source_form}"] = [str(binary)]
        OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
        print(key, json.dumps(result["comparisons"][key]), flush=True)
result["commands"] = commands
oracle = validator.validate_commands(commands)
oracle_path = LOCAL / "keyword-arguments-integration-oracle.json"
assert not oracle_path.exists()
oracle_path.write_text(json.dumps(oracle, indent=2, ensure_ascii=False) + "\n")
assert oracle["cases"] == 176
assert all(sha(ROOT / name) == expected for name, expected in tracked.items())
assert {
    str(path.relative_to(snapshot)): sha(path)
    for path in sorted(snapshot.rglob("*.py"))
} == snapshot_hashes
assert all(sha(TOOLS / name) == expected for name, expected in source_hashes.items())
result["oracle"] = {
    "path": str(oracle_path),
    "sha256": sha(oracle_path),
    "cases": oracle["cases"],
    "successful": oracle["successful"],
    "terminal_errors": oracle["terminal_errors"],
    "engines": oracle["engines"],
    "device_checks": len(oracle["device_check"]["engines"]),
}
result["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {"receipt": str(OUTPUT), "sha256": sha(OUTPUT), "oracle": result["oracle"]},
        indent=2,
    ),
    flush=True,
)
