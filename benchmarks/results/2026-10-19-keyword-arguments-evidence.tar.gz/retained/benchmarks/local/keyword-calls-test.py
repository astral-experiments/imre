"""Record focused keyword-call native checks without Cargo or benchmark timings."""

import concurrent.futures
import hashlib
import json
import shutil
import subprocess
import threading
import time
from pathlib import Path

ROOT = Path("/home/dev-user/code/oss/imre")
OUT = ROOT / "benchmarks/local/keyword-calls-validation-dev1"
PYTHON = "/home/dev-user/.local/bin/python3.14"


def sha(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def file(path: Path) -> dict:
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


def main() -> None:
    OUT.mkdir(exist_ok=False)
    tracer = next(line.split(":", 1)[1].strip() for line in Path("/proc/self/status").read_text().splitlines()
                  if line.startswith("TracerPid:"))
    assert tracer == "0", tracer
    original = Path("/home/dev-user/.cache/imre/target/release/imre")
    compiler = OUT / "imre"
    before = file(original)
    shutil.copy2(original, compiler)
    assert sha(compiler) == before["sha256"] == sha(original)
    rustc = subprocess.check_output(["rustc", "+ohm", "-vV"], text=True)
    target = next(line.removeprefix("host: ") for line in rustc.splitlines() if line.startswith("host: "))
    sysroot = Path(subprocess.check_output(["rustc", "+ohm", "--print", "sysroot"], text=True).strip())
    linker = sysroot / "lib/rustlib" / target / "bin/gcc-ld/ld.lld"
    assert linker.is_file(), linker
    runtimes = {
        "ordinary": Path("/home/dev-user/.cache/imre/target/release/libimre_runtime.a"),
        "thinlto": ROOT / "benchmarks/local/scalar-fstrings-tools-final/libimre_runtime_lto.a",
        "asan": ROOT / "benchmarks/local/scalar-fstrings-tools-final/libimre_runtime_asan.a",
    }
    sources = {str(path.relative_to(ROOT)): sha(path) for path in sorted((ROOT / "tests").rglob("*.py"))}
    record = {
        "schema": "imre-keyword-calls-native-validation-v1", "started_at_unix": time.time(),
        "tracer_pid": 0, "runner": file(Path(__file__)), "original_compiler": before,
        "compiler": file(compiler), "runtimes": {name: file(path) for name, path in runtimes.items()},
        "python": file(Path(PYTHON)), "clang": file(Path("/usr/bin/clang-18")),
        "rustc_verbose": rustc, "target": target, "linker": file(linker),
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "test_sources": sources, "results": {},
    }
    lock = threading.Lock()

    def save() -> None:
        (OUT / "results.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")

    def run(case: tuple[str, str, str, list[str]]) -> None:
        name, suite, mode, levels = case
        command = [PYTHON, "-I", str(ROOT / f"tests/{suite}.py"), "--compiler", str(compiler),
                   "--runtime", str(runtimes[mode]), "--python", PYTHON,
                   "--clang", "/usr/bin/clang-18", "--opt-levels", *levels]
        if mode == "thinlto":
            command += ["--target", target, "--lto-linker", str(linker)]
        if mode == "asan":
            command.append("--sanitize")
        stdout, stderr = OUT / (name + ".stdout"), OUT / (name + ".stderr")
        started = time.time()
        with stdout.open("wb") as out, stderr.open("wb") as err:
            result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, timeout=1800)
        with lock:
            record["results"][name] = {"suite": suite, "mode": mode, "optimization_levels": levels,
                                       "command": command, "returncode": result.returncode,
                                       "started_at_unix": started, "finished_at_unix": time.time(),
                                       "stdout": file(stdout), "stderr": file(stderr)}
            save()
        print(name, result.returncode, stdout.read_text().strip(), flush=True)
        if result.returncode:
            print(stderr.read_text()[-7000:], flush=True)

    save()
    cases = [("calls-ordinary", "calls", "ordinary", ["0", "3"]),
             ("calls-thinlto", "calls", "thinlto", ["3"]),
             ("calls-asan", "calls", "asan", ["0", "1"]),
             ("classes-ordinary", "classes", "ordinary", ["0", "3"])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        list(executor.map(run, cases))
    assert sources == {str(path.relative_to(ROOT)): sha(path) for path in sorted((ROOT / "tests").rglob("*.py"))}
    assert sha(compiler) == record["compiler"]["sha256"]
    for mode, runtime in runtimes.items():
        assert sha(runtime) == record["runtimes"][mode]["sha256"]
    record["inputs_unchanged"] = True
    record["finished_at_unix"] = time.time()
    record["passed"] = all(entry["returncode"] == 0 for entry in record["results"].values())
    save()
    print(json.dumps({"record": str(OUT / "results.json"), "sha256": sha(OUT / "results.json"),
                      "passed": record["passed"]}), flush=True)
    raise SystemExit(0 if record["passed"] else 1)


if __name__ == "__main__":
    main()
