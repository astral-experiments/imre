"""Package retained keyword-argument observations without executing native work."""

import argparse
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / "benchmarks/local"
RESULTS = ROOT / "benchmarks/results"
PREFIX = "2026-10-19-keyword-arguments"
REVISION = "3b7377367a6c93b19aa8981ccd97131bc7442e83"
VALIDATION_SHA = "a25df0380f86af79525c453249415501268e7ded5b4763af08c4b3e17f94006d"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def info(data):
    return {"sha256": digest(data), "bytes": len(data)}


def compressed(data):
    output = io.BytesIO()
    with gzip.GzipFile(
        fileobj=output, mode="wb", filename="", mtime=0, compresslevel=9
    ) as stream:
        stream.write(data)
    return output.getvalue()


class Package:
    def __init__(self):
        self.payloads = {}
        self.members = {}

    def add(self, name, data, source):
        require(name not in self.payloads, "duplicate evidence member: " + name)
        require(
            not Path(name).is_absolute() and ".." not in Path(name).parts,
            "unsafe member path",
        )
        require(
            not data.startswith((b"\x7fELF", b"!<arch>\n", b"BC\xc0\xde")),
            "native artifact is excluded: " + name,
        )
        require(
            Path(name).suffix
            not in {".a", ".o", ".so", ".rlib", ".bc", ".exe", ".pyc", ".text"},
            "native/cache artifact is excluded: " + name,
        )
        data.decode("utf-8")
        self.payloads[name] = data
        self.members[name] = {**info(data), "source": source}

    def file(self, path, expected=None):
        path = path.absolute()
        require(
            path.is_relative_to(ROOT) and path.is_file() and not path.is_symlink(),
            "invalid retained file: " + str(path),
        )
        name = str(path.relative_to(ROOT))
        data = path.read_bytes()
        if expected is not None:
            require(info(data) == expected, "retained evidence changed: " + name)
        member = "retained/" + name
        if member in self.payloads:
            require(self.payloads[member] == data, "duplicate source differs: " + name)
        else:
            self.add(member, data, name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=LOCAL / "keyword-arguments-publication-stage"
    )
    args = parser.parse_args()
    destination = args.output.resolve()
    require(
        destination.is_relative_to(LOCAL) and not destination.exists(),
        "output must be a new ignored local directory",
    )
    session_path = LOCAL / "keyword-arguments-final-session.json"
    session = load(session_path)
    build_path = LOCAL / "keyword-arguments-tools-final/build-record.json"
    build = load(build_path)
    audit_path = LOCAL / "keyword-arguments-final-audit.json"
    audit = load(audit_path)
    validation_path = LOCAL / "keyword-arguments-validation.json"
    validation = load(validation_path)
    native_path = LOCAL / "keyword-arguments-native-text-audit.json"
    native = load(native_path)
    summary_path = LOCAL / "keyword-arguments-comparison-summary.json"
    summary = load(summary_path)
    require(
        digest(validation_path.read_bytes()) == VALIDATION_SHA,
        "validation index differs from reviewed receipt",
    )
    require(
        session["source_commit"]
        == build["git_head"]
        == validation["measured_source_commit"]
        == REVISION,
        "measured source commit differs",
    )
    require(
        not session["git_status_before"]
        and not session["git_status_after"]
        and not build["git_status"],
        "measured checkout was dirty",
    )
    require(
        build["compiled_sources_match_commit"] is True
        and validation["compiled_sources_match_measured_commit"] is True,
        "compiled source reconciliation failed",
    )
    require(
        validation["final_and_development_artifacts_byte_identical"] is True,
        "validated/final tools differ",
    )
    require(
        session["before"]["build_record_sha256"] == digest(build_path.read_bytes()),
        "timing/build join differs",
    )
    require(
        audit["status"] == "passed" and audit["assertions_passed"] == 28002,
        "timing audit incomplete",
    )
    require(
        summary["audit_sha256"] == digest(audit_path.read_bytes()),
        "summary refers to another audit",
    )
    require(
        summary["counts"]
        == {
            "assertions": 28002,
            "distinct_files_hashed": 109,
            "measured": 2304,
            "warmups": 96,
            "gates": 48,
            "oracle_cases": 1408,
            "device_cases": 8,
        },
        "timing accounting differs",
    )
    require(
        validation["total_reported_suite_checks"] == 2376
        and validation["cargo_validation"]["unit_tests"] == 66,
        "validation accounting differs",
    )
    require(
        len(validation["superseded_failed_entries"]) == 13,
        "superseded sanitizer environment failures missing",
    )
    package = Package()
    tracked = subprocess.check_output(
        ["git", "-C", str(ROOT), "ls-tree", "-r", "--name-only", REVISION], text=True
    ).splitlines()
    selected = [name for name in tracked if not name.startswith("benchmarks/results/")]
    archive_bytes = subprocess.check_output(
        ["git", "-C", str(ROOT), "archive", "--format=tar", REVISION, "--", *selected]
    )
    sources = {}
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:") as archive:
        for member in archive:
            if member.isdir():
                continue
            require(member.isfile(), "source snapshot contains a non-file")
            data = archive.extractfile(member).read()
            sources[member.name] = data
            package.add("source/" + member.name, data, f"git:{REVISION}:{member.name}")
    require(set(sources) == set(selected), "source snapshot file set differs")
    for name, expected in build["source_sha256"].items():
        require(
            digest(sources[name]) == expected,
            "compiled source snapshot differs: " + name,
        )
    for name in validation["verified_committed_sources"]:
        require(
            info(sources[name]) == validation["verified_file_hashes"][name],
            "validated source snapshot differs: " + name,
        )
    evidence_paths = validation["retained_local_evidence_paths"]
    require(
        len(evidence_paths) == len(set(evidence_paths)) == 110,
        "validation evidence list differs",
    )
    for name in evidence_paths:
        require(
            name.startswith("benchmarks/local/"), "unexpected validation evidence root"
        )
        package.file(ROOT / name, validation["verified_file_hashes"].get(name))
    for name in (
        "keyword-arguments-build.py",
        "keyword-arguments-final-launch.py",
        "keyword-arguments-final-audit.py",
        "keyword-arguments-final-audit.json",
        "keyword-arguments-final-audit.md",
        "keyword-arguments-final-session.json",
        "keyword-arguments-validation.json",
        "keyword-arguments-native-text-audit.py",
        "keyword-arguments-native-text-audit.json",
        "keyword-arguments-comparison-summary.json",
        "keyword-arguments-summary.py",
        "keyword-arguments-harness-checks.py",
        "keyword-arguments-harness-checks.json",
        "keyword-arguments-fill-report.py",
        "keyword-arguments-report-template.md",
        "keyword-arguments-report.md",
        "keyword-arguments-publication-audit.py",
        "scalar-fstrings-tools-final/build-record.json",
    ):
        package.file(LOCAL / name)
    package.file(Path(__file__))
    for path in sorted((LOCAL / "keyword-arguments-baseline-source").rglob("*")):
        if path.is_file():
            package.file(path)
    require(
        digest((LOCAL / "keyword-arguments-final-launch.py").read_bytes())
        == session["launcher_sha256"],
        "timing launcher changed",
    )
    require(
        digest((LOCAL / "keyword-arguments-final-audit.py").read_bytes())
        == audit["audit_script_sha256"],
        "timing audit source changed",
    )
    require(
        digest((LOCAL / "keyword-arguments-native-text-audit.py").read_bytes())
        == native["audit_script_sha256"],
        "native audit source changed",
    )
    require(
        digest((LOCAL / "keyword-arguments-validation-audit.py").read_bytes())
        == validation["audit_script"]["sha256"],
        "validation audit source changed",
    )
    package.add(
        "commands/cargo.sh",
        build["cargo_wrapper"].encode(),
        "embedded final frozen build record",
    )
    package.add(
        "README.md",
        (
            "# Keyword-argument evidence\n\n"
            "`source/` is the complete tracked source tree at measured commit "
            + REVISION
            + ", excluding historical result files. `retained/` preserves local evidence under its original repository-relative paths; the manifest maps and hashes every member. Final raw timing JSON and reviewed indices are also published as separate companions.\n\n"
            "All 110 validation-index evidence paths are retained, including the initial twelve general-suite sanitizer environment failures and the inventory sanitizer failure with its partial receipt. Successful retries preserve compiler/runtime/source inputs and keep leak detection enabled; the index records the execution-environment correction and provenance limits.\n\n"
            "Builds, commands, validators, generated LLVM, previous package sources, raw validation records, and audit scripts are preserved. Native executable/runtime/toolchain bytes and raw native .text dumps are excluded. Audits that inspect those artifacts or Git history still require the original paths and measured commit; paths in original observations are not rewritten.\n\n"
            "The report renderer expects keyword-arguments-comparison-summary.json beside its script and template, as retained under benchmarks/local. It produces keyword-arguments-report.md. The packaging script creates new output only and runs no compiler, native program, benchmark, or profiler.\n"
        ).encode(),
        "publication reproduction notes",
    )
    companions = {}
    external_baselines = {}
    for mode in ("normal", "lto"):
        record_path = LOCAL / f"keyword-arguments-{mode}-final.json"
        data = record_path.read_bytes()
        record = json.loads(data)
        require(
            record["git"] == {"revision": REVISION, "dirty": False},
            "timing source differs",
        )
        require(
            session["runs"][mode]["record_sha256"] == digest(data)
            and session["runs"][mode]["returncode"] == 0,
            "timing session join differs",
        )
        require(
            set(record["inventory_baseline_source"]["changed_sources"])
            == {
                "inventory_reconciliation/__main__.py",
                "inventory_reconciliation/load.py",
                "inventory_reconciliation/model.py",
                "inventory_reconciliation/reconcile.py",
                "inventory_reconciliation/render.py",
            },
            "unexpected application source change",
        )
        for name, expected in record["sources"].items():
            require(
                digest(sources["examples/" + name]) == expected,
                "application snapshot differs",
            )
        require(
            native["modes"][mode]["text_byte_identical"] is True, "native code changed"
        )
        require(
            session["runs"][mode]["generated_ir_comparison"]["byte_identical"] is True,
            "generated IR changed",
        )
        companions[f"{PREFIX}-{mode}.json.gz"] = compressed(data)
        package.file(record_path.with_suffix(".log"))
        for name in ("inventory_reconciliation.ll",):
            for prefix in ("keyword-arguments", "scalar-fstrings"):
                path = LOCAL / f"{prefix}-{mode}-final" / name
                package.file(path)
                key = "inventory_ir"
                expected = (
                    record["sha256"][key]
                    if prefix == "keyword-arguments"
                    else record["inventory_baseline_provenance"]["sha256"][key]
                )
                require(
                    digest(path.read_bytes()) == expected,
                    "retained generated IR differs",
                )
        package.file(LOCAL / f"inventory-reference-final-{mode}/build-record.json")
        published_name = f"2026-10-18-scalar-fstrings-{mode}.json.gz"
        published = (RESULTS / published_name).read_bytes()
        old = (LOCAL / f"scalar-fstrings-{mode}-final.json").read_bytes()
        require(
            gzip.decompress(published) == old,
            "previously published baseline bytes differ",
        )
        external_baselines[published_name] = {
            **info(published),
            "decompressed_sha256": digest(old),
            "role": "Previous f-string inventory executable/source/build provenance, with its original samples.",
        }
    for suffix, path in (
        ("build.json", build_path),
        ("session.json", session_path),
        ("audit.json", audit_path),
        ("validation.json", validation_path),
        ("native-text.json", native_path),
        ("summary.json", summary_path),
    ):
        companions[f"{PREFIX}-{suffix}"] = path.read_bytes()
    companions[f"{PREFIX}.md"] = (LOCAL / "keyword-arguments-report.md").read_bytes()
    archive_buffer = io.BytesIO()
    with tarfile.open(
        fileobj=archive_buffer, mode="w", format=tarfile.PAX_FORMAT
    ) as archive:
        for name, data in sorted(package.payloads.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(data), 0o644
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            archive.addfile(entry, io.BytesIO(data))
    archive_name = f"{PREFIX}-evidence.tar.gz"
    archive_data = compressed(archive_buffer.getvalue())
    companion_info = {}
    for name, data in companions.items():
        companion_info[name] = info(data)
        if name.endswith(".json.gz"):
            raw = gzip.decompress(data)
            mode = "normal" if "-normal." in name else "lto"
            require(
                raw == (LOCAL / f"keyword-arguments-{mode}-final.json").read_bytes(),
                "gzip changed raw record bytes",
            )
            companion_info[name]["decompressed_sha256"] = digest(raw)
    manifest = {
        "schema": "relar-keyword-arguments-evidence-v1",
        "measured_source_commit": REVISION,
        "source_snapshot_file_count": len(sources),
        "retained_validation_evidence_count": len(evidence_paths),
        "timing_session_completed_at_utc": session["completed_at_utc"],
        "archive": {
            "file": archive_name,
            **info(archive_data),
            "member_count": len(package.members),
        },
        "members": dict(sorted(package.members.items())),
        "companion_files": dict(sorted(companion_info.items())),
        "external_baseline_records": external_baselines,
        "scope": [
            "Only existing observations are packaged; no native build, execution, profiling, or timing is performed.",
            "The measured source snapshot comes from Git commit 3b7377367a6c93b19aa8981ccd97131bc7442e83, independently of later documentation edits. Historical results are excluded.",
            "All 110 retained local evidence paths from the validation index are included, with source/log hashes, initial sandbox sanitizer failures, successful identical-input retries, and explicit provenance limits.",
            "Native executables, runtime archives, interpreters, toolchains, bytecode caches, and native .text dumps are excluded. Their paths/hashes remain in the original records.",
            "Raw timing JSON is separately gzip-compressed without byte changes. Previous baseline timing records remain separately published and are referenced by exact compressed/decompressed hashes.",
            "Tar members are sorted regular files with mode 0644, uid/gid/mtime 0, empty owner names, and gzip filename empty/mtime 0. Metadata uses the recorded timing completion time, not packaging time.",
            "Audits using executable/toolchain files and Git objects need those preserved external artifacts; published JSON, source, logs, and LLVM support independent review and recomputation.",
        ],
    }
    # Resolve local report links as they will appear in benchmarks/results.
    for match in re.finditer(
        r"\[[^\]]+\]\(([^)]+)\)", companions[f"{PREFIX}.md"].decode()
    ):
        target = match.group(1)
        if "://" in target:
            continue
        relative = target.split("#", 1)[0]
        require(
            relative in companions
            or relative in {archive_name, f"{PREFIX}-evidence-manifest.json"}
            or (RESULTS / relative).resolve().is_file(),
            "report link target missing: " + target,
        )
    destination.mkdir(parents=True, exist_ok=False)
    for name, data in companions.items():
        (destination / name).write_bytes(data)
    (destination / archive_name).write_bytes(archive_data)
    manifest_path = destination / f"{PREFIX}-evidence-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode="r:gz") as archive:
        members = archive.getmembers()
        require(
            [item.name for item in members] == sorted(package.members),
            "archive order/inventory differs",
        )
        for member in members:
            data = archive.extractfile(member).read()
            require(
                info(data)
                == {
                    key: package.members[member.name][key]
                    for key in ("sha256", "bytes")
                },
                "member bytes differ",
            )
            require(
                member.isfile()
                and member.mode == 0o644
                and member.uid == member.gid == member.mtime == 0
                and member.uname == member.gname == "",
                "archive metadata differs",
            )
    for name, expected in companion_info.items():
        require(
            info((destination / name).read_bytes())
            == {key: expected[key] for key in ("sha256", "bytes")},
            "companion bytes differ",
        )
    print(
        json.dumps(
            {
                "output": str(destination),
                "archive": manifest["archive"],
                "source_files": len(sources),
                "retained_validation_paths": len(evidence_paths),
                "manifest_sha256": digest(manifest_path.read_bytes()),
                "companion_count": len(companions),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
