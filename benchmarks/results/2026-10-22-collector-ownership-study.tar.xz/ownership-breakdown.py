"""Recompute observed shapes, generated-code allocation stacks and ordinary profile totals."""
from collections import Counter,defaultdict
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,re,runpy
root=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_bytes())
src=root/'sources/after';i=root/'inputs';p=i/'changed-github';m=load(p/'manifest.json')
texts={f:(i/'suite'/Path(f).name).read_text() for f in m['test_files']}
val=runpy.run_path(str(src/'benchmarks/conformance_validate.py'))
helper=runpy.run_path(str(src/'benchmarks/conformance_classification_upstream.py'))
w=val['Workload'](*(p/(k+'.json')for k in ('manifest','old','new')))
_,paths,source,old,new=val['_inputs'](w,texts)
up=val['upstream']();cases=helper['load_cases'](SimpleNamespace(paths=paths,sources=source,old=old,new=new),up)
pairs=Counter((len(tc.old),len(tc.new)) for tc in cases if tc.old and tc.new)
equal=Counter({a:n for (a,b),n in pairs.items() if a==b})
assert (len(cases),equal)==(1269,{1:972,2:37,3:2})
parsers=runpy.run_path(str(src/'benchmarks/dependency_profile.py'));result={'groups':len(cases),'both_nonempty':sum(pairs.values()),'equal_lengths':dict(equal),'unequal_lengths':sum(n for (a,b),n in pairs.items() if a!=b),'modes':{}}
def summarize(path):
 trace=load(path)
 by_stack=defaultdict(Counter)
 for point in trace['pps']:
  frames=[v.partition(': ')[2].split(' (',1)[0]for v in (trace['ftbl'][id]for id in point['fs'])]
  tags=[f for f in frames if re.fullmatch(r'fn_\d+',f) or (f.startswith('relar_') and '::' not in f) or f=='main']
  if tags==['main'] or not tags:tags=[next((f for f in frames[::-1]if 'conformance_report' in f or 'Vec<' in f),'other'),*tags]
  stk=' > '.join(tags)
  by_stack[stk].update({'blocks':point['tbk'],'bytes':point['tb']})
 return by_stack
for engine in ['before','after','rust']:
 stats={};stacks={}
 for n in (0,64):
  d=root/'profiles'/(engine+'-'+str(n))
  a=d/(engine+'.dhat.trace');b=d/(engine+'.callgrind.trace');stacks[n]=summarize(a)
  cg=parsers['callgrind'](b); dh=parsers['dhat'](a)
  stats[n]={'instructions':cg['total_instructions'],'blocks':dh['totals']['tbk'],'bytes':dh['totals']['tb']}
  assert all(sum(v[k]for v in stacks[n].values())==stats[n][k]for k in ('blocks','bytes'))
 total={k:(stats[64][k]-stats[0][k])/64 for k in stats[0]}
 groups={};ranked=[]
 for stack in sorted(stacks[0].keys()|stacks[64].keys()):
  v={k:(stacks[64][stack][k]-stacks[0][stack][k])/64 for k in ('blocks','bytes')}
  if v['blocks']==0 and abs(v['bytes'])<.0001:continue
  tags=set(stack.split(' > '))
  if engine=='rust': bucket='Rust native'
  elif tags&{'fn_38','fn_7'}:bucket='diagnostic equivalence'
  elif tags&{'fn_43','fn_66'}:bucket='classification'
  elif 'fn_28' in tags:bucket='title strings'
  elif tags&{'relar_sort_by_keys','relar_sort_detach'}:bucket='entry sort'
  elif tags&{'relar_record_new','relar_seq_new','relar_seq_append'}:bucket='inlined collector and sort keys'
  else:bucket='other'
  if bucket not in groups:groups[bucket]={'blocks':0,'bytes':0}
  for k in v:groups[bucket][k]+=v[k]
  ranked.append({'stack':stack,**v})
 assert all(sum(v[k]for v in groups.values())==total[k]for k in ('blocks','bytes'))
 result['modes'][engine]={'per_pass':total,'by_site':groups,'ranked_stacks':sorted(ranked,key=lambda v:(-v['blocks'],-v['bytes'],v['stack']))}
print(json.dumps(result,indent=2))
