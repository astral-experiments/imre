"""Offline, rehash and reconstruct all classification/report observations and both Rust controls."""

from collections import Counter
from pathlib import Path
from statistics import median
import hashlib, json, runpy, subprocess, sys

if sys.flags.optimize:
    raise RuntimeError("replay requires assertions")
r = Path(__file__).resolve().parent
idx = json.loads((r / "manifest.json").read_bytes())
load = lambda p: json.loads(Path(p).read_bytes())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert set(idx["files"]) == {
    str(p.relative_to(r))
    for p in r.rglob("*")
    if p.is_file() and p != r / "manifest.json" and "__pycache__" not in p.parts
}
for k, v in idx["files"].items():
    p = r / k
    assert p.stat().st_size == v["bytes"] and sha(p) == v["sha256"], k
src = r / "sources/after"
checks = load(r / "validation/checks.json")
kbuild = load(r / "builds/kernel-builds.json")
verify = load(r / "builds/verified-builds.json")
modes = {}
compiled = 0
assert (
    idx["revision"] == verify["revision"] == checks["revision"]
    and idx["baseline_revision"] == verify["baseline_revision"]
    and sha(r / "builds/changes.bundle") == verify["bundle"]["sha256"]
)
cli_src = (src / "benchmarks/conformance_classification.py").read_text()
for mode in ["normal", "thinlto"]:
    path = r / mode / "results.json"
    m = load(path)
    config = m["config"]
    assert (
        not m["pilot"]
        and m["kernel"] == "entry-ownership"
        and config == load(r / mode / "config.json")
        and m["cpu"] == (31 if mode == "normal" else 15)
        and config["mode"] == mode
        and config["source_locked"]
        and m["revision"] == idx["revision"]
        and m["baseline_revision"] == idx["baseline_revision"]
    )
    audit = json.loads(
        subprocess.check_output(
            [
                sys.executable,
                "-B",
                src / "benchmarks/conformance_regex_audit.py",
                path,
                "--source-root",
                src,
                "--retained",
                r / "inputs",
            ]
        )
    )
    strict = load(r / mode / "audit-strict.json")
    assert strict["strict_files_checked"] > 0 and audit["strict_files_checked"] == 0
    assert {k: v for k, v in audit.items() if k != "strict_files_checked"} == {
        k: v for k, v in strict.items() if k != "strict_files_checked"
    } and audit["time_target_met"]
    modes[mode] = audit
    for label in ["before", "after"]:
        b = kbuild[label + "-" + mode]
        driver = cli_src
        assert (
            b["source_hashes"]["conformance_report/benchmark_kernel.py"]
            == hashlib.sha256(driver.encode()).hexdigest()
        )
        assert b["driver_revision"] == idx["revision"] and b["parser_revision"] == (
            idx["baseline_revision"] if label == "before" else idx["revision"]
        )
        assert sha(r / "builds/ir" / (label + "-" + mode + ".ll")) == b["llvm"][
            "sha256"
        ] and config["engines"][label]["entries"] == [b["executable"]["path"], "--entries"]
    prior = load(r/"builds/port-kernel-builds.json")["before-"+mode]
    assert prior["parser_revision"] == config["port_revision"] == "490ff91eb4ac3d9af47e790259a7441bf8a6fa00"
    assert config["engines"]["port"]["entries"] == [prior["executable"]["path"],"--entries"]
    assert sha(r/"builds/ir"/("port-"+mode+".ll")) == prior["llvm"]["sha256"]
    guards = {it["path"]: it["sha256"] for it in config["guarded_inputs"]}
    for label in ("before", "after", "port", "codon", "rust"):
        record = load(r/"builds"/(label+"-"+mode)/"build-record.json")
        commands = config["engines"][label]
        for op in ("entries", "report", "compute", "live"):
            if op == "entries" and label in ("before", "after", "port"):
                comp = prior if label == "port" else kbuild[label+"-"+mode]
                expect = comp["executable"]["sha256"]
            else:
                key = "reference" if label == "rust" else {"report":"conformance_report", "live":"conformance_report",
                      "compute":"conformance_report-compute", "entries":"conformance_report-classification"}[op]
                expect = record["binaries"][key]["sha256"]
            assert guards[commands[op][0]] == expect, (mode,label,op)
    for e, v in config["engines"].items():
        assert (
            config["build_records"][e]["sha256"]
            == sha(r / "builds" / (e + "-" + mode) / "build-record.json")
            if e in config["build_records"]
            else e in ["upstream", "cpython"]
        )
        assert (
            sha(r / "validation" / mode / (e + ".captures"))
            == checks["oracle_sha256"]
            == sha(r / "inputs/corpus.captures")
        )
        for panel, outputs in checks["targets"].items():
            assert (
                sha(r / "inputs" / (panel + ".md"))
                == outputs[e + "-" + mode]
                == sha(r / "validation" / mode / (e + "-" + panel + ".md"))
            )
for original, item in verify["guarded"].items():
    path = Path(original)
    for name, base in [
        ("before", config["baseline_source_root"]),
        ("after", config["source_root"]),
    ]:
        if path.is_relative_to(base):
            retained = r / "sources" / name / path.relative_to(base)
            if retained.is_file():
                assert sha(retained) == item["sha256"]
                compiled += 1
assert compiled >= 60 and sha(r / "validation/expected.captures") == checks["oracle_sha256"] == sha(
    r / "validation/asan.captures"
)
for name, outputs in checks["targets"].items():
    assert (
        sha(r / "validation" / ("asan-" + name + ".md"))
        == outputs["asan"]
        == sha(r / "inputs" / (name + ".md"))
    )
env_out = subprocess.check_output(
    [
        sys.executable,
        "-B",
        "-c",
        'import sys,runpy;sys.path.insert(0,sys.argv[1]);runpy.run_path(sys.argv[2],run_name="__main__")',
        src / "examples",
        src / "benchmarks/codon_native/enum_probe.py",
    ]
)
assert (r / "validation/members.txt").read_bytes() == env_out
for mode in modes:
    assert (r / "validation" / mode / "members.txt").read_bytes() == env_out
valid = load(r / "validation/boundaries/record.json")
assert (
    valid["status"] == "passed"
    and valid["guards_passed"]
    and valid["parser_differentials"] == 30000
    and valid["report_differentials"] == 400
)
n, score = map(int, (r / "inputs/corpus.captures").read_bytes().splitlines()[-1].split())
references=load(r/"builds/comparator-reuse.json")
assert references["study_revision"]==idx["revision"] and references["native_source_revision"]=="918e77728b7afdadb5ab1d63f785cb2c291482b8"
assert all(sha(src/k)==v for k,v in references["identical_source_hashes"].items())
assert (n, score) == (1269, 10247030) and checks["distribution"]["entries"] == 249
parsers = runpy.run_path(str(src / "benchmarks/dependency_profile.py"))
prof = {}
for engine in ["before", "after", "rust"]:
    prof[engine] = {}
    for cnt in [0, 64]:
        d = r / "profiles" / (engine + "-" + str(cnt))
        prov = load(d / "provenance.json")
        summ = load(d / "summary.json")
        assert prov["status"] == "passed" and prov["input_guards_passed"]
        out = prof[engine][str(cnt)] = {}
        for item in summ["runs"]:
            name = item["tool"]
            trace = d / (engine + "." + name + ".trace")
            assert (
                sha(trace) == item["trace_sha256"]
                and sha(d / (engine + "." + name + ".log")) == item["log_sha256"]
                and item["returncode"] == 0
                and item["command"][-2:] == [str(cnt), "checksum"]
            )
            parsed = parsers[name](trace)
            assert all(item[k] == v for k, v in parsed.items())
            if name == "callgrind":
                out["instructions"] = parsed["total_instructions"]
            else:
                out.update(
                    allocated_blocks=parsed["totals"]["tbk"], allocated_bytes=parsed["totals"]["tb"]
                )
print(
    json.dumps(
        {
            "revision": idx["revision"],
            "baseline_revision": idx["baseline_revision"],
            "indexed_files": len(idx["files"]),
            "validated_build_sources": compiled,
            "timed": sum(a["timed"] for a in modes.values()),
            "warmups": sum(a["warmups"] for a in modes.values()),
            "groups": n,
            "distribution": checks["distribution"],
            "boundary_counts": valid["counts"],
            "specified_rust_time_target_met": True,
            "profiles": prof,
            "modes": modes,
        },
        indent=2,
    )
)
