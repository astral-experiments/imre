//! Assignment targets consume one owned RHS, with a snapshot at each unpacking
//! level so target mutation cannot change values already removed from a sequence.

use super::*;

/// Builds a checked-count constant without introducing a source-level binding.
fn integer(value: impl ToString) -> Expr {
    Expr {
        ty: Type::Int,
        kind: ExprKind::Int(value.to_string()),
    }
}

/// Calls an existing typed primitive from compiler-generated unpacking code.
fn builtin(ty: Type, kind: Builtin, args: Vec<Expr>) -> Expr {
    Expr {
        ty,
        kind: ExprKind::Builtin(kind, args),
    }
}

/// Tests sequence length before any user target can observe a partial unpack.
fn comparison(left: Expr, op: Compare, right: Expr) -> Expr {
    Expr {
        ty: Type::Bool,
        kind: ExprKind::Compare(vec![left, right], vec![op]),
    }
}

/// Materializes a constant fragment of Python's unpacking diagnostics.
pub(super) fn string(value: impl Into<String>) -> Expr {
    Expr {
        ty: Type::Str,
        kind: ExprKind::Str(value.into()),
    }
}

/// Joins diagnostic fragments only on the corresponding failure path.
pub(super) fn concat(left: Expr, right: Expr) -> Expr {
    Expr {
        ty: Type::Str,
        kind: ExprKind::Binary(Binary::Concat, Box::new(left), Box::new(right)),
    }
}

/// Uses the sealed ValueError category so ordinary handlers catch arity errors.
fn unpack_error(message: Expr) -> Statement {
    Statement::Raise(Some(Expr {
        ty: Type::Exception,
        kind: ExprKind::Exception {
            kind: exception_kind("ValueError").unwrap(),
            message: Some(Box::new(message)),
        },
    }))
}

impl Checker<'_> {
    /// Finds a target's storage without executing its receiver or index.
    fn target_context(&self, target: &ast::Expr) -> Option<Type> {
        if let ast::Expr::Name(name) = target {
            self.names
                .get(name.id.as_str())
                .map(|&slot| self.locals[slot])
        } else {
            self.assignment_context(target)
        }
    }

    /// Transfers a compiler-owned root before evaluating the next user target.
    /// Returning the value retains an independent reference before cleanup.
    fn take_temporary(&self, slot: usize) -> Expr {
        Expr {
            ty: self.locals[slot],
            kind: ExprKind::Scope {
                body: Vec::new(),
                value: Box::new(self.local(slot)),
                clear: vec![slot],
            },
        }
    }

    /// A chain shares one RHS object and visits targets in source order. A later
    /// annotated target can supply the type of an otherwise empty literal.
    pub(super) fn assignment_statement(
        &mut self,
        assignment: &ast::StmtAssign,
    ) -> Result<Vec<Statement>, String> {
        if let [target] = assignment.targets.as_slice() {
            if pattern_elements(target).is_some() {
                let value = self.unpacking_value(target, &assignment.value)?;
                return self.bind_pattern(target, value);
            }
            let value = if let Some(expected) = self.target_context(target) {
                self.expr_expected(&assignment.value, expected)?
            } else {
                self.typed_expr(&assignment.value)?
            };
            return Ok(vec![self.assign_value(target, value)?]);
        }
        let context = assignment
            .targets
            .iter()
            .find_map(|target| self.target_context(target));
        let value = if let Some(expected) = context {
            assignments::unpromoted(self.expr_expected(&assignment.value, expected)?)
        } else {
            let target = assignment
                .targets
                .iter()
                .find(|target| pattern_elements(target).is_some())
                .unwrap_or(&assignment.targets[0]);
            self.unpacking_value(target, &assignment.value)?
        };
        let captured = self.hidden(value.ty);
        let mut body = vec![Statement::Assign(captured, value)];
        for (index, target) in assignment.targets.iter().enumerate() {
            let value = if index + 1 == assignment.targets.len() {
                self.take_temporary(captured)
            } else {
                self.local(captured)
            };
            body.extend(self.bind_pattern(target, value)?);
        }
        Ok(vec![Statement::Scope {
            body,
            clear: vec![captured],
        }])
    }

    /// Receivers and indices are checked after the RHS and preceding targets.
    /// SetItem/SetField preserve this same RHS-first order in generated code.
    pub(super) fn assign_value(
        &mut self,
        target: &ast::Expr,
        value: Expr,
    ) -> Result<Statement, String> {
        match target {
            ast::Expr::Name(_) => self.assign(target, value),
            ast::Expr::Subscript(subscript) => {
                let receiver = self.expr(&subscript.value)?;
                let (key, element) = self
                    .types
                    .mapping(receiver.ty)
                    .or_else(|| {
                        self.types
                            .element(receiver.ty)
                            .map(|element| (Type::Int, element))
                    })
                    .ok_or_else(|| {
                        error(
                            self.source,
                            target,
                            "indexed assignment requires a mutable typed list or dictionary",
                        )
                    })?;
                let index = self.expr_expected(&subscript.slice, key)?;
                let value = self.coerce(value, element, target)?;
                Ok(Statement::SetItem(receiver, index, value))
            }
            ast::Expr::Attribute(attribute) => {
                let (receiver, field, ty) = self.field(attribute)?;
                let value = self.coerce(value, ty, target)?;
                Ok(Statement::SetField(receiver, field, value))
            }
            _ => Err(error(self.source, target, "unsupported assignment target")),
        }
    }

    /// Literal context is discovered before any target binding is published.
    /// Optional promotions belong to stores rather than the shared RHS object.
    fn unpacking_value(&mut self, target: &ast::Expr, value: &ast::Expr) -> Result<Expr, String> {
        if let Some(targets) = pattern_elements(target) {
            let star = targets
                .iter()
                .position(|target| matches!(target, ast::Expr::Starred(_)));
            let fixed = targets.len() - usize::from(star.is_some());
            let literal = match value {
                ast::Expr::Tuple(tuple) => Some((&tuple.elts, false)),
                ast::Expr::List(list)
                    if targets
                        .iter()
                        .any(|target| pattern_elements(target).is_some()) =>
                {
                    Some((&list.elts, true))
                }
                _ => None,
            };
            if let Some((elements, is_list)) = literal
                && !elements
                    .iter()
                    .any(|value| matches!(value, ast::Expr::Starred(_)))
                && (elements.len() == fixed || star.is_some() && elements.len() >= fixed)
            {
                let mut values = Vec::with_capacity(elements.len());
                for (index, value) in elements.iter().enumerate() {
                    let target_index = star.map_or(Some(index), |star| {
                        let suffix = targets.len() - star - 1;
                        if index < star {
                            Some(index)
                        } else if index >= elements.len() - suffix {
                            Some(targets.len() - (elements.len() - index))
                        } else {
                            None
                        }
                    });
                    values.push(if let Some(index) = target_index {
                        self.unpacking_value(&targets[index], value)?
                    } else if let ast::Expr::Starred(starred) = &targets[star.unwrap()]
                        && let Some(context) = self.target_context(&starred.value)
                        && let Some(element) = self
                            .types
                            .element(self.types.payload(context).unwrap_or(context))
                    {
                        assignments::unpromoted(self.expr_expected(value, element)?)
                    } else {
                        self.expr(value)?
                    });
                }
                if is_list {
                    let mut element = values[0].ty;
                    for item in &values {
                        element = self.types.join(element, item.ty).ok_or_else(|| {
                            error(
                                self.source,
                                value,
                                "list unpacking requires one concrete element type",
                            )
                        })?;
                    }
                    let values = values
                        .into_iter()
                        .map(|item| self.coerce(item, element, value))
                        .collect::<Result<Vec<_>, _>>()?;
                    return Ok(Expr {
                        ty: self.types.list(element),
                        kind: ExprKind::List(values),
                    });
                }
                return Ok(Expr {
                    ty: self
                        .types
                        .tuple(values.iter().map(|value| value.ty).collect()),
                    kind: ExprKind::Tuple(values),
                });
            }
            if let ast::Expr::List(list) = value {
                let context = targets
                    .iter()
                    .filter_map(|target| match target {
                        ast::Expr::Starred(starred) => {
                            let context = self.target_context(&starred.value)?;
                            self.types
                                .element(self.types.payload(context).unwrap_or(context))
                        }
                        _ => self.target_context(target),
                    })
                    .reduce(|left, right| {
                        // Every destination must accept the shared element
                        // layout, so nullable targets cannot widen exact ones.
                        if self.types.join(left, right) == Some(left) {
                            right
                        } else {
                            left
                        }
                    });
                if let Some(element) = context {
                    if !list
                        .elts
                        .iter()
                        .any(|value| matches!(value, ast::Expr::Starred(_)))
                    {
                        let values = list
                            .elts
                            .iter()
                            .map(|value| {
                                self.expr_expected(value, element)
                                    .map(assignments::unpromoted)
                            })
                            .collect::<Result<Vec<_>, _>>()?;
                        let mut actual = values.first().map_or(element, |value| value.ty);
                        for value in &values {
                            actual = self.types.join(actual, value.ty).ok_or_else(|| {
                                error(
                                    self.source,
                                    list,
                                    "list unpacking requires one concrete element type",
                                )
                            })?;
                        }
                        let values = values
                            .into_iter()
                            .map(|value| self.coerce(value, actual, list))
                            .collect::<Result<Vec<_>, _>>()?;
                        return Ok(Expr {
                            ty: self.types.list(actual),
                            kind: ExprKind::List(values),
                        });
                    }
                    return self.expr_expected(value, self.types.list(element));
                }
            }
        }
        if let Some(expected) = self.target_context(target) {
            return self
                .expr_expected(value, expected)
                .map(assignments::unpromoted);
        }
        self.expr(value)
    }

    /// Each sequence level is checked and captured before its target stores;
    /// nested levels are entered only when their target is reached.
    pub(super) fn bind_pattern(
        &mut self,
        target: &ast::Expr,
        value: Expr,
    ) -> Result<Vec<Statement>, String> {
        self.bind_pattern_with_root(target, value, None)
    }

    /// An iterator's private fixed tuple cannot be rebound by source targets.
    /// Reuse that root while snapshotting all fields before user stores, making
    /// the aggregate projection-only and eligible for scalar replacement.
    pub(super) fn bind_iterator_pattern(
        &mut self,
        target: &ast::Expr,
        source: usize,
    ) -> Result<Vec<Statement>, String> {
        let stable = matches!(self.locals[source], Type::Tuple(_)).then_some(source);
        self.bind_pattern_with_root(target, self.local(source), stable)
    }

    /// A supplied root belongs exclusively to compiler iteration state; ordinary
    /// source assignments retain a separate snapshot through target effects.
    fn bind_pattern_with_root(
        &mut self,
        target: &ast::Expr,
        value: Expr,
        stable: Option<usize>,
    ) -> Result<Vec<Statement>, String> {
        let Some(targets) = pattern_elements(target) else {
            return Ok(vec![self.assign_value(target, value)?]);
        };
        let mut stars = targets
            .iter()
            .enumerate()
            .filter(|(_, target)| matches!(target, ast::Expr::Starred(_)));
        let star = stars.next().map(|(index, _)| index);
        if stars.next().is_some() {
            return Err(error(
                self.source,
                target,
                "an unpacking target may contain only one starred target",
            ));
        }
        let fixed = targets.len() - usize::from(star.is_some());
        let fields = self.types.fields(value.ty);
        let element = self.types.element(value.ty).or(match value.ty {
            Type::Str => Some(Type::Str),
            Type::Bytes => Some(Type::Int),
            _ => None,
        });
        if fields.is_none() && element.is_none() {
            return Err(error(
                self.source,
                target,
                "unpacking requires a fixed tuple, list, string, or bytes value",
            ));
        }
        if let Some(fields) = &fields
            && (fields.len() < fixed || star.is_none() && fields.len() != fixed)
        {
            return Err(error(
                self.source,
                target,
                "unpacking target has the wrong number of fields",
            ));
        }
        let (captured, mut body) = if let Some(captured) = stable {
            (captured, Vec::new())
        } else {
            let captured = self.hidden(value.ty);
            (captured, vec![Statement::Assign(captured, value)])
        };
        let mut clear = vec![captured];
        if fields.is_none() && (fixed != 0 || star.is_none()) {
            let length = self.hidden(Type::Int);
            clear.push(length);
            body.push(Statement::Assign(
                length,
                builtin(Type::Int, Builtin::Len, vec![self.local(captured)]),
            ));
            if fixed != 0 {
                let expected = if star.is_some() {
                    format!("at least {fixed}")
                } else {
                    fixed.to_string()
                };
                let message = concat(
                    concat(
                        string(format!(
                            "not enough values to unpack (expected {expected}, got "
                        )),
                        builtin(Type::Str, Builtin::Str, vec![self.local(length)]),
                    ),
                    string(")"),
                );
                body.push(Statement::If(
                    comparison(self.local(length), Compare::Less, integer(fixed)),
                    vec![unpack_error(message)],
                    Vec::new(),
                ));
            }
            if star.is_none() {
                body.push(Statement::If(
                    comparison(self.local(length), Compare::Greater, integer(fixed)),
                    vec![unpack_error(string(format!(
                        "too many values to unpack (expected {fixed})"
                    )))],
                    Vec::new(),
                ));
            }
        }
        let mut items = Vec::with_capacity(targets.len());
        for (index, target) in targets.iter().enumerate() {
            let item = if let ast::Expr::Starred(starred) = target {
                let suffix = targets.len() - index - 1;
                if let Some(fields) = &fields {
                    self.tuple_rest(self.local(captured), fields, index, suffix, &starred.value)?
                } else {
                    self.sequence_rest(
                        self.local(captured),
                        element.unwrap(),
                        index,
                        suffix,
                        &starred.value,
                    )?
                }
            } else if let Some(fields) = &fields {
                let position = if star.is_some_and(|star| index > star) {
                    fields.len() - (targets.len() - index)
                } else {
                    index
                };
                Expr {
                    ty: fields[position],
                    kind: ExprKind::Field(Box::new(self.local(captured)), position),
                }
            } else {
                let position = if star.is_some_and(|star| index > star) {
                    -(targets.len() as i64 - index as i64)
                } else {
                    index as i64
                };
                let kind = match self.locals[captured] {
                    Type::Str => Builtin::StringGet,
                    Type::Bytes => Builtin::BytesGet,
                    _ => Builtin::ListGet,
                };
                builtin(
                    element.unwrap(),
                    kind,
                    vec![self.local(captured), integer(position)],
                )
            };
            let slot = self.hidden(item.ty);
            body.push(Statement::Assign(slot, item));
            clear.push(slot);
            items.push(slot);
        }
        body.push(Statement::Clear(captured));
        for (target, item) in targets.iter().zip(items) {
            let target = if let ast::Expr::Starred(starred) = target {
                &starred.value
            } else {
                target
            };
            body.extend(self.bind_pattern(target, self.take_temporary(item))?);
        }
        Ok(vec![Statement::Scope { body, clear }])
    }

    /// A tuple remainder has one concrete element layout, including optional
    /// promotion. Empty remainders inherit a declared destination list type.
    fn tuple_rest(
        &mut self,
        value: Expr,
        fields: &[Type],
        start: usize,
        suffix: usize,
        target: &ast::Expr,
    ) -> Result<Expr, String> {
        let remaining = &fields[start..fields.len() - suffix];
        let context = self
            .target_context(target)
            .and_then(|ty| self.types.element(self.types.payload(ty).unwrap_or(ty)));
        let mut element = context.or(remaining.first().copied()).unwrap_or(Type::Int);
        if context.is_none() {
            for &ty in remaining {
                element = self.types.join(element, ty).ok_or_else(|| {
                    error(
                        self.source,
                        target,
                        "starred unpacking requires one concrete remainder element type",
                    )
                })?;
            }
        }
        let values = remaining
            .iter()
            .enumerate()
            .map(|(offset, &ty)| {
                self.coerce(
                    Expr {
                        ty,
                        kind: ExprKind::Field(Box::new(value.clone()), start + offset),
                    },
                    element,
                    target,
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(Expr {
            ty: self.types.list(element),
            kind: ExprKind::List(values),
        })
    }

    /// List slicing supplies a fresh shallow remainder. Other sequence types
    /// and optional promotions copy through the shared linear iteration lowering.
    fn sequence_rest(
        &mut self,
        value: Expr,
        element: Type,
        start: usize,
        suffix: usize,
        target: &ast::Expr,
    ) -> Result<Expr, String> {
        let bound = |value: Option<i64>| Expr {
            ty: self.types.optional(Type::Int),
            kind: match value {
                Some(value) => ExprKind::Present(Box::new(integer(value))),
                None => ExprKind::Absent(Box::new(Expr {
                    ty: Type::None,
                    kind: ExprKind::None,
                })),
            },
        };
        let slice = builtin(
            value.ty,
            Builtin::Slice,
            vec![
                value,
                bound(Some(start as i64)),
                bound((suffix > 0).then_some(-(suffix as i64))),
                bound(None),
            ],
        );
        let expected = self
            .target_context(target)
            .and_then(|ty| self.types.element(self.types.payload(ty).unwrap_or(ty)))
            .unwrap_or(element);
        if self.types.element(slice.ty) == Some(expected) {
            return Ok(slice);
        }
        let list = self.types.list(expected);
        let result = self.hidden(list);
        let name = format!("@unpacking{}", self.locals.len());
        let item_target = ast::Expr::Name(ast::ExprName {
            node_index: ast::AtomicNodeIndex::NONE,
            range: target.range(),
            id: name.clone().into(),
            ctx: ast::ExprContext::Store,
        });
        let input = Iteration::Container {
            iterable: slice,
            items: false,
            start: None,
        };
        let (iteration, _) = self.lower_iteration(&item_target, input, &[], |checker| {
            let item = checker.local(checker.names[&name]);
            let item = checker.coerce(item, expected, target)?;
            Ok(vec![Statement::Expr(builtin(
                Type::None,
                Builtin::Append,
                vec![checker.local(result), item],
            ))])
        })?;
        let item = self.names.remove(&name).unwrap();
        let mut body = vec![Statement::Assign(
            result,
            Expr {
                ty: list,
                kind: ExprKind::List(Vec::new()),
            },
        )];
        body.extend(iteration);
        Ok(Expr {
            ty: list,
            kind: ExprKind::Scope {
                body,
                value: Box::new(self.local(result)),
                clear: vec![result, item],
            },
        })
    }
}
