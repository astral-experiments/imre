//! Nominal member identity and the finite set of values accepted by a match.

use super::*;

impl Checker<'_> {
    pub(super) fn assert_never(&mut self, call: &ast::ExprCall) -> Result<Statement, String> {
        let [arg @ ast::Expr::Name(name)] = call.arguments.args.as_ref() else {
            return Err(error(
                self.source,
                call,
                "assert_never requires one StrEnum local",
            ));
        };
        let val = self.expr(arg)?;
        if !call.arguments.keywords.is_empty()
            || !self.names.contains_key(name.id.as_str())
            || !matches!(
                self.types.payload(val.ty).unwrap_or(val.ty),
                Type::StrEnum(_)
            )
        {
            return Err(error(
                self.source,
                call,
                "assert_never requires one StrEnum local",
            ));
        }
        // A finally suite also receives pending returns, breaks and exceptions.
        // ty's ordinary fallthrough narrowing does not cover all those entries.
        if self.in_finally {
            return Err(error(
                self.source,
                call,
                "assert_never inside finally is unsupported",
            ));
        }
        if !self.graph.session.is_never(self.module, arg) {
            return Err(error(
                self.source,
                arg,
                "assert_never requires an exhausted StrEnum domain",
            ));
        }
        // Keep the defensive Python exception even when the checker proves the
        // argument uninhabited. typing truncates repr at 100 Unicode code points.
        let repr = Expr {
            ty: Type::Str,
            kind: ExprKind::Builtin(Builtin::Repr, vec![val]),
        };
        let slot = self.hidden(Type::Str);
        let limit = pipelines::integer(100);
        let index_type = self.types.optional(Type::Int);
        let absent = self.coerce(
            Expr {
                ty: Type::None,
                kind: ExprKind::None,
            },
            index_type,
            call,
        )?;
        let stop = self.coerce(limit.clone(), index_type, call)?;
        let len = Expr {
            ty: Type::Int,
            kind: ExprKind::Builtin(Builtin::Len, vec![self.local(slot)]),
        };
        let prefix = Expr {
            ty: Type::Str,
            kind: ExprKind::Builtin(
                Builtin::Slice,
                vec![self.local(slot), absent.clone(), stop, absent],
            ),
        };
        let clipped = Expr {
            ty: Type::Str,
            kind: ExprKind::Conditional(
                Box::new(pipelines::compare(Compare::Greater, len, limit)),
                Box::new(unpacking::concat(prefix, unpacking::string("..."))),
                Box::new(self.local(slot)),
            ),
        };
        let message = Expr {
            ty: Type::Str,
            kind: ExprKind::Scope {
                body: vec![Statement::Assign(slot, repr)],
                value: Box::new(unpacking::concat(
                    unpacking::string("Expected code to be unreachable, but got: "),
                    clipped,
                )),
                clear: vec![slot],
            },
        };
        Ok(Statement::Raise(Some(Expr {
            ty: Type::Exception,
            kind: ExprKind::Exception {
                kind: exception_kind("AssertionError").unwrap(),
                message: Some(Box::new(message)),
            },
        })))
    }

    pub(super) fn enum_member(&self, class: usize, name: &str) -> Option<Expr> {
        let members = self.classes.declarations.definitions[class]
            .enum_members
            .as_ref()?;
        let &member = members.names.get(name)?;
        Some(Expr {
            ty: Type::StrEnum(class),
            kind: ExprKind::Builtin(Builtin::StrEnumMember { class, member }, Vec::new()),
        })
    }

    pub(super) fn qualified_member(&self, value: &ast::Expr) -> Option<Expr> {
        let ast::Expr::Attribute(attr) = value else {
            return None;
        };
        self.enum_member(self.class_reference(&attr.value)?, attr.attr.as_str())
    }

    pub(super) fn enum_text(value: Expr) -> Expr {
        if matches!(value.ty, Type::StrEnum(_)) {
            Expr {
                ty: Type::Str,
                kind: ExprKind::Builtin(Builtin::StrEnumValue, vec![value]),
            }
        } else {
            value
        }
    }

    /// Only use where the operation observes string contents, never nominal identity.
    pub(super) fn string_value(value: Expr) -> Expr {
        if matches!(value.ty, Type::StrLiteral(_)) {
            literals::view(value, Type::Str)
        } else {
            Self::enum_text(value)
        }
    }

    pub(super) fn enum_identity(
        &mut self,
        left: &ast::Expr,
        right: &ast::Expr,
        op: ast::CmpOp,
        node: &impl Ranged,
    ) -> Result<Expr, String> {
        let left = self.expr(left)?;
        let right = self.expr(right)?;
        if ![left.ty, right.ty]
            .into_iter()
            .all(|ty| matches!(self.types.payload(ty).unwrap_or(ty), Type::StrEnum(_)))
        {
            return Err(error(
                self.source,
                node,
                "identity comparisons require None or nominal StrEnum members",
            ));
        }
        Ok(Self::identity_result(
            vec![left, right],
            op == ast::CmpOp::IsNot,
        ))
    }

    pub(super) fn identity_result(values: Vec<Expr>, negate: bool) -> Expr {
        let identity = Expr {
            ty: Type::Bool,
            kind: ExprKind::Builtin(Builtin::StrEnumIdentity, values),
        };
        if negate {
            Expr {
                ty: Type::Bool,
                kind: ExprKind::Not(Box::new(identity)),
            }
        } else {
            identity
        }
    }

    /// Guards can fail. Only unconditional cases count toward a finite match.
    pub(super) fn enum_exhaustive(&self, ty: Type, cases: &[ast::MatchCase]) -> bool {
        let payload = self.types.payload(ty);
        let Type::StrEnum(class) = payload.unwrap_or(ty) else {
            return false;
        };
        let members = self.classes.declarations.definitions[class]
            .enum_members
            .as_ref()
            .unwrap();
        let mut remaining = vec![true; members.values.len()];
        let mut none = payload.is_some();
        let mut patterns: Vec<_> = cases
            .iter()
            .filter(|case| case.guard.is_none())
            .map(|case| &case.pattern)
            .collect();
        while let Some(pattern) = patterns.pop() {
            match pattern {
                ast::Pattern::MatchValue(value) => {
                    if let Some(Expr {
                        kind:
                            ExprKind::Builtin(
                                Builtin::StrEnumMember {
                                    class: owner,
                                    member,
                                },
                                _,
                            ),
                        ..
                    }) = self.qualified_member(&value.value)
                        && class == owner
                    {
                        remaining[member] = false;
                    }
                }
                ast::Pattern::MatchSingleton(value) if value.value == ast::Singleton::None => {
                    none = false
                }
                ast::Pattern::MatchAs(value) if let Some(inner) = &value.pattern => {
                    patterns.push(inner)
                }
                ast::Pattern::MatchOr(or) => patterns.extend(&or.patterns),
                _ => {}
            }
        }
        !none && !remaining.contains(&true)
    }
}

#[cfg(test)]
mod tests {
    const PREFIX: &str = "from enum import StrEnum, auto\nclass State(StrEnum):\n    OPEN = auto()\n    ALIAS = OPEN\n    SAME = 'open'\n    CLOSED = 'off'\n";

    fn check(body: &str) -> Result<(), String> {
        crate::check(&format!("{PREFIX}{body}"))
    }

    #[test]
    fn exhaustive_unguarded_members_and_none_close_only_the_actual_domain() {
        check("def result(value: State | None) -> int:\n    match value:\n        case None:\n            return 0\n        case State.ALIAS | State.CLOSED:\n            return 1\n").unwrap();
        check("def narrowed(value: State | None) -> int:\n    if value is None:\n        return 0\n    match value:\n        case State.OPEN | State.CLOSED:\n            return 1\n").unwrap();
        for body in [
            "def missing(value: State) -> int:\n    match value:\n        case State.OPEN | State.ALIAS:\n            return 1\n",
            "def guarded(value: State, ready: bool) -> int:\n    match value:\n        case State.OPEN if ready:\n            return 1\n        case State.CLOSED:\n            return 2\n",
            "def nullable(value: State | None) -> int:\n    match value:\n        case State.OPEN | State.CLOSED:\n            return 2\n",
        ] {
            assert!(check(body).is_err(), "{body}");
        }
    }

    #[test]
    fn assert_never_requires_a_semantic_proof_even_when_ty_diagnostics_are_ignored() {
        let imported = "from typing import assert_never as exhausted\n";
        let skipped = "  # ty: ignore[type-assertion-failure]\n";
        for body in [
            "def f(v: State) -> None:\n    if v == State.OPEN or v == State.ALIAS:\n        return\n    exhausted(v)",
            "def f(v: State | None) -> None:\n    if v == State.OPEN or v == State.CLOSED:\n        return\n    exhausted(v)",
            "def f(v: State, set_open: bool) -> None:\n    if v == State.OPEN:\n        return\n    if set_open:\n        v = State.OPEN\n    if v == State.CLOSED:\n        return\n    exhausted(v)",
            "def f(v: State, next_state: State, steps: list[int]) -> None:\n    if v == State.OPEN:\n        return\n    for i in steps:\n        if v == State.CLOSED:\n            v = next_state\n            continue\n        exhausted(v)",
        ] {
            let err = crate::check(&format!("{imported}{PREFIX}{body}{skipped}")).unwrap_err();
            assert!(
                err.contains("assert_never requires an exhausted StrEnum domain"),
                "{err}"
            );
        }
        let body = "def f(v: State) -> None:\n    try:\n        if v == State.OPEN:\n            return\n    finally:\n        if v == State.CLOSED:\n            return\n        exhausted(v)\n";
        let two_members = "from enum import StrEnum\nclass State(StrEnum):\n    OPEN = 'open'\n    CLOSED = 'closed'\n";
        let err = crate::check(&format!("{imported}{two_members}{body}")).unwrap_err();
        assert!(
            err.contains("assert_never inside finally is unsupported"),
            "{err}"
        );
    }

    #[test]
    fn nominal_stores_preserve_identity_and_require_explicit_string_projection() {
        let echo = "def echo(value: str) -> str:\n    return repr(value)\n";
        let rejected = check(&format!("{echo}print(echo(State.OPEN))\n")).unwrap_err();
        assert!(
            rejected.contains("str(member) or member.value"),
            "{rejected}"
        );
        check(&format!(
            "{echo}print(echo(State.OPEN.value))\nprint(echo(str(State.CLOSED)))\n"
        ))
        .unwrap();
        for source in [
            "def wrong() -> State:\n    return 'open'\n",
            "class Other(StrEnum):\n    OPEN = 'open'\ndef wrong() -> State:\n    return Other.OPEN\n",
            "def mutate(value: State) -> None:\n    value.name = 'different'\n",
            "def wrong(value: State) -> bool:\n    return value is 'open'\n",
            "def bad(value: str) -> State:\n    return State(value)\n",
        ] {
            assert!(check(source).is_err(), "{source}");
        }
    }

    #[test]
    fn rejects_dynamic_class_definitions_and_shadowed_auto() {
        for declaration in [
            "class Invalid(StrEnum):\n    ITEM = 1\n",
            "class Invalid(StrEnum):\n    ITEM = 'a' + 'b'\n",
            "class Invalid(StrEnum):\n    ITEM = auto(1)\n",
            "class Invalid(StrEnum):\n    mro = 'reserved'\n",
            "class Invalid(StrEnum):\n    ITEM = auto()\n    ITEM = 'other'\n",
            "class Invalid(StrEnum):\n    auto = 'member'\n    ITEM = auto()\n",
            "class Invalid(StrEnum):\n    ITEM = 'x'\n    def __str__(self) -> str:\n        return 'y'\n",
            "class Invalid(StrEnum):\n    pass\n",
        ] {
            assert!(
                crate::check(&format!("from enum import StrEnum, auto\n{declaration}")).is_err(),
                "{declaration}"
            );
        }
    }
}
