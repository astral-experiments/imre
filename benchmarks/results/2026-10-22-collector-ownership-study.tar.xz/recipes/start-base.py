from pathlib import Path
import hashlib,shlex,subprocess,tarfile
c=Path(__file__).resolve().parent.parent;r=Path('/home/dev-user/code/oss/imre-collector-ownership');ssh='/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh';ref='refs/heads/charlie/codex-entry-sort';p=c/'base.bundle';old='53172f1c02e282b51af8436262ea38fb5751b1ae'
def g(*args):return subprocess.check_output(['git','-C',r,*map(str,args)],text=True).strip()
assert g('rev-parse','--show-toplevel')==str(r) and g('rev-parse','--path-format=absolute','--git-common-dir')=='/home/dev-user/code/oss/imre/.git' and g('config','user.email')=='charlie.r.marsh@gmail.com' and g('rev-parse',ref)==old
g('bundle','create',p,ref,'^918e777');digest=hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(c/'send-base.tar','w')as t:
 for file in (p,c/'recipes/base.py'):t.add(file,arcname=file.relative_to(c))
def remote(*args,**kwargs):return subprocess.run([ssh,'charlie-oss-8','--',*map(str,args)],check=True,**kwargs)
remote('mkdir','-p',c)
with (c/'send-base.tar').open('rb')as f:remote('tar','-xf','-','-C',c,stdin=f)
cmd=shlex.join(['/home/dev-user/.local/bin/python3.14','-u',str(c/'recipes/base.py'),digest])+' > '+str(c/'base.log')+' 2>&1';remote('tmux','new-session','-d','-s','collector-base',cmd)
