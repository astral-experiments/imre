from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
c=Path('/home/dev-user/.cache/imre/collector-ownership-20261022');prior=c.parent/'entry-sort-20261022/final-918e777';r=Path('/home/dev-user/code/oss/imre-collector-base-20261022');seed=r.parent/'imre-entries-final-918e777';d=c/'base';d.mkdir(exist_ok=True);old='53172f1c02e282b51af8436262ea38fb5751b1ae';frozen='918e77728b7afdadb5ab1d63f785cb2c291482b8';ref='refs/heads/charlie/codex-entry-sort'
def git(root,*args):return subprocess.check_output(['git','-C',root,*map(str,args)],text=True).strip()
def check(x):return subprocess.run(list(map(str,x)),check=True)
p=c/'base.bundle';assert hashlib.sha256(p.read_bytes()).hexdigest()==sys.argv[1]
assert git(seed,'rev-parse','HEAD')==frozen and git(seed,'config','user.email')=='charlie.r.marsh@gmail.com'
if not r.exists():check(['git','clone','--shared','--no-checkout',seed,r])
assert git(r,'rev-parse','--path-format=absolute','--git-common-dir')==str(r/'.git') and git(r,'config','user.email')=='charlie.r.marsh@gmail.com'
git(r,'remote','set-url','origin','https://github.com/astral-sh/imre.git');git(r,'bundle','verify',p);git(r,'fetch','--no-tags',p,ref);git(r,'sparse-checkout','set','--no-cone','/*','!/benchmarks/results/');git(r,'checkout','--detach',old)
assert not git(r,'status','--porcelain') and git(r,'rev-parse','HEAD')==old
inputs=['Cargo.toml','Cargo.lock','crates','stdlib','examples/conformance_report','benchmarks/conformance_classification.py','benchmarks/reference','benchmarks/codon_native','benchmarks/native_platform']
assert not git(r,'diff','--name-only',frozen,old,'--',*inputs)
oldrec=json.loads((prior/'build/core/build-record.json').read_bytes());e=oldrec['environment'];env={**os.environ,**{k:e[k] for k in ('RUSTUP_HOME','RUSTC','CARGO_BUILD_BUILD_DIR')},'CARGO_TARGET_DIR':str(c/'target-base'),'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all'}
py='/home/dev-user/.local/bin/python3.14'
def run(k,cmd):
 print('start',k,flush=True)
 with (d/(k+'.log')).open('wb') as f:subprocess.run(list(map(str,cmd)),cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('done',k,flush=True)
run('core',[py,'benchmarks/native_tools_build.py','--toolchain','ohm','--modes','normal','thinlto','--target-dir',c/'target-base','--shared-build-dir',env['CARGO_BUILD_BUILD_DIR'],'--rustup-home',env['RUSTUP_HOME'],'--jobs',e['CARGO_BUILD_JOBS'],'--output',d/'core'])
from concurrent.futures import ThreadPoolExecutor
src=d/'driver';shutil.copytree(r/'examples/conformance_report',src/'conformance_report',ignore=shutil.ignore_patterns('__pycache__'));shutil.copy2(r/'benchmarks/conformance_classification.py',src/'conformance_report/benchmark_kernel.py')
def native(mode):
 extra=['--lto-linker','/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld'] if mode=='thinlto' else []
 run('program-'+mode,[py,'benchmarks/live_conformance_build.py','--application','conformance_report','--core-build-record',d/'core/build-record.json','--mode',mode,'--clang','/usr/lib/llvm-18/bin/clang','--output',d/mode,*extra])
 run('kernel-'+mode,[d/'core/imre','build',src/'conformance_report/benchmark_kernel.py','--module-root',src,'--runtime',d/'core'/(mode+'_runtime.a'),'--clang','/usr/lib/llvm-18/bin/clang','--target',oldrec['target'],'--opt-level','3','--emit-llvm',d/(mode+'.ll'),'-o',d/('kernel-'+mode),*extra])
 oldir=prior/'build'/('after-'+mode+'-kernel.ll');assert oldir.read_bytes()==(d/(mode+'.ll')).read_bytes(),mode
with ThreadPoolExecutor(2)as pool:list(pool.map(native,['normal','thinlto']))
(d/'ready').write_text(old);print('source matched #95',flush=True)
