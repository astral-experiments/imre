from pathlib import Path
import hashlib,re,subprocess,sys,tarfile,shlex
c=Path(__file__).resolve().parent.parent;tag=sys.argv[1];assert re.fullmatch(r'[a-z0-9-]+',tag);p=Path(sys.argv[2]).resolve(strict=True);sha=hashlib.sha256(p.read_bytes()).hexdigest();f=c/('transfer-ir-'+tag+'.tar');ssh='/home/dev-user/.codex/skills/applied/applied-devbox/scripts/devbox_ssh'
with tarfile.open(f,'w')as t:t.add(p,arcname=tag+'.ll');t.add(c/'recipes/ir-service.py',arcname='recipes/ir-service.py')
with f.open('rb')as h:subprocess.run([ssh,'charlie-oss-8','--','tar','-xf','-','-C',c],stdin=h,check=True)
cmd=shlex.join(['/home/dev-user/.local/bin/python3.14','-u',str(c/'recipes/ir-service.py'),tag,sha,*sys.argv[3:]])+' > '+str(c/('ir-'+tag+'.log'))+' 2>&1';subprocess.run([ssh,'charlie-oss-8','--','tmux','new-session','-d','-s','collector-ir-'+tag,cmd],check=True);print(tag,sha)
