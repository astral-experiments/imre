"""Add the serial native control, reproducible ownership attribution, and QA receipts to the audited archive."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib,json,shutil,subprocess,sys,tarfile
s=Path(sys.argv[1]).resolve();recipes=Path(__file__).parent;qa=Path(sys.argv[2]).resolve(strict=True);qa_digest=sys.argv[3]
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(qa)==qa_digest
with TemporaryDirectory(dir=s)as temp:
 root=Path(temp)
 with tarfile.open(s/'evidence.tar.xz')as t:t.extractall(root,filter='data')
 (root/'replay.py').rename(root/'formal_replay.py')
 shutil.copy2(s/'serial-check.json',root/'validation/serial-check.json')
 shutil.copy2(qa,root/'validation/local-qa.tar.gz')
 for name in ['serial-check.py','dispatch-ir.py','ir-service.py','test-gate.py','pr-bundles.py','extend.py']:
  shutil.copy2(recipes/name,root/'recipes'/name)
 for name in ['audit-serial.py','ownership-breakdown.py']:shutil.copy2(recipes/name,root/name)
 for tag in ['single-projection','single-production']:
  p=s.parent/('ir-'+tag)/'results.json'
  if p.is_file():
   ir=s.parent/'local'/('projected-pilot.ll' if tag=='single-projection' else 'projected-production.ll')
   assert h(ir)==json.loads(p.read_bytes())['ir'];shutil.copy2(ir,root/'builds/ir'/('pilot-'+tag+'.ll'));shutil.copy2(p,root/'validation'/('pilot-'+tag+'.json'))
 (root/'replay.py').write_text('''from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
p=Path(__file__).resolve().parent
assert not sys.flags.optimize
run=lambda n:json.loads(subprocess.check_output([sys.executable,"-B",p/n],cwd=p))
base=run("formal_replay.py")
base["serial"]=run("audit-serial.py")
ownership=run("ownership-breakdown.py")
assert ownership==json.loads((p/"profiles/allocation-groups.json").read_bytes())
base["allocation_profile"]={k:{"per_pass":v["per_pass"],"by_site":v["by_site"]}for k,v in ownership["modes"].items()}
base["real_equivalence_group_lengths"]=ownership["equal_lengths"]
qa=p/"validation/local-qa.tar.gz"
with tarfile.open(qa)as t:
 members={m.name:m for m in t.getmembers() if m.isfile()}
 manifest=next(name for name in members if name.endswith("qa-index.json"))
 index=json.load(t.extractfile(manifest))
 assert index["revision"]==base["revision"]
 guard=index["llvm_before_first_sorted_list"]["collector"]
 assert guard["string_equality"]==4 and guard["python_integer_equality"]==2 and all(guard[k]==0 for k in ("record_allocation","record_retain","record_release"))
 for name,v in index["files"].items():
  blob=t.extractfile(name).read();assert len(blob)==v["bytes"] and hashlib.sha256(blob).hexdigest()==v["sha256"]
 base["local_qa"]={"sha256":hashlib.sha256(qa.read_bytes()).hexdigest(),"indexed":len(index["files"])}
print(json.dumps(base,indent=2))
''')
 stats=subprocess.check_output([sys.executable,'-B',root/'ownership-breakdown.py'],cwd=root);(root/'profiles/allocation-groups.json').write_bytes(stats)
 (root/'README.md').write_text((root/'README.md').read_text().replace('The #93 port is `refs/pull/93/head` at 490ff91eb4ac3d9af47e790259a7441bf8a6fa00; the #95 baseline is `refs/pull/95/head` at 53172f1c02e282b51af8436262ea38fb5751b1ae.', 'Fetch `refs/pull/93/head` and select the port at 490ff91eb4ac3d9af47e790259a7441bf8a6fa00. Fetch `refs/pull/95/head` and select the baseline at 53172f1c02e282b51af8436262ea38fb5751b1ae. The pull refs may advance with documentation or lint repairs.').replace('six or seven', 'seven')+'\nThe serial control runs both native modes and Rust on CPU 31 alone for eight balanced rounds including a 512-pass collector and all three complete/repeated reports. The offline audit replays this control, the frozen local QA manifest, and the nonoverlapping allocation stack rankings in profiles/allocation-groups.json. recipes/pr-bundles.py can recreate the source bundles from persistent GitHub pull refs.\n')
 idx=json.loads((root/'manifest.json').read_bytes());idx['source_export_sha256']=h(s/'evidence.tar.xz')
 idx['files']={str(f.relative_to(root)):{'bytes':f.stat().st_size,'sha256':h(f)}for f in sorted(root.rglob('*'))if f.is_file() and f!=root/'manifest.json' and '__pycache__' not in f.parts}
 (root/'manifest.json').write_text(json.dumps(idx,indent=2)+'\n')
 final=s/'publication-study.tar.xz'
 with tarfile.open(final,'w:xz',preset=6)as t:
  for f in sorted(root.rglob('*')):
   if f.is_file() and '__pycache__' not in f.parts:t.add(f,arcname=str(f.relative_to(root)),recursive=False)
 audit=subprocess.check_output([sys.executable,'-B',root/'replay.py'],cwd=root);(s/'publication-audit.json').write_bytes(audit);print(final.stat().st_size,h(final),flush=True)
