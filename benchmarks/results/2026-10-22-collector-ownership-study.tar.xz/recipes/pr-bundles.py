"""Recreate exact study Git bundles from permanent pull refs in a new temporary bare repository."""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse,subprocess
p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();a.output.mkdir(exist_ok=True,parents=True)
old='53172f1c02e282b51af8436262ea38fb5751b1ae';new='b12109581c90c5608fb52c26bcf6eb3e4c7adece'
with TemporaryDirectory()as tmp:
 def git(*args):return subprocess.check_output(['git','-C',tmp,*map(str,args)],text=True).strip()
 git('init','--bare');refs=['refs/pull/'+str(n)+'/head:refs/study/pr'+str(n)for n in [93,95,96]];git('fetch','--no-tags','https://github.com/astral-sh/imre.git',*refs)
 git('merge-base','--is-ancestor','490ff91eb4ac3d9af47e790259a7441bf8a6fa00','refs/study/pr93');git('merge-base','--is-ancestor',old,'refs/study/pr95');git('merge-base','--is-ancestor',new,'refs/study/pr96')
 for sha,branch,name,pre in [(old,'charlie/codex-entry-sort','base.bundle','918e77728b7afdadb5ab1d63f785cb2c291482b8'),(new,'charlie/codex-collector-ownership',new+'.bundle',old)]:
  name=a.output.resolve()/name;assert not name.exists();git('branch',branch,sha);git('bundle','create',name,'refs/heads/'+branch,'^'+pre);assert git('bundle','list-heads',name)==sha+' refs/heads/'+branch;print(name)
