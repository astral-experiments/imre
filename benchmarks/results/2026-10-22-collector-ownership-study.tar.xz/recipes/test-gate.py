"""Regression control for independent auditing of the combined kernel and report release threshold."""
from pathlib import Path
from statistics import median
import copy,json,runpy,subprocess,sys
c=Path(__file__).resolve().parent.parent;root=Path('/home/dev-user/code/oss/imre-collector-ownership');prev=c.parent/'entry-sort-20261022/final-918e777';audit=root/'benchmarks/conformance_regex_audit.py';m=json.loads((prev/'normal/results.json').read_bytes());b=runpy.run_path(str(root/'benchmarks/conformance_regex_benchmark.py'));es=(*b['ENGINES'],'port');orders=b['orders'](es);m['orders']=orders;m['samples']=14;m['kernel']='entry-ownership';cfg=m['config'];cfg['port_revision']=m['baseline_revision'];cfg['baseline_revision']=m['baseline_revision']='53172f1c02e282b51af8436262ea38fb5751b1ae';cfg['engines']['port']=cfg['engines']['before'];m['capture_validation']['corpus']['port']=m['capture_validation']['corpus']['before'];cases=m['cases'];cases['entry-ownership']=cases.pop('entries');cases['entry-ownership-preload']=cases.pop('entries-preload');m['per_round_ns']['entry-ownership']=m['per_round_ns'].pop('entries')
for name,case in cases.items():
 rows=case['runs'];new=[]
 for index,ordering in enumerate([orders[0][::-1],*orders]):
  original={v['engine']:v for v in (case['warmup'] if index==0 else rows[(index-1)%12])};records=[]
  for engine in ordering:
   x=original['before' if engine=='port' else engine].copy();x['engine']=engine
   if engine=='after':x['elapsed_ns']=int(original['rust']['elapsed_ns']*1.4)
   records.append(x)
  new.append(records)
 case['warmup']=new[0];case['runs']=new[1:]
def update():
 for case in cases.values():
  v={e:median(v['elapsed_ns'] for row in case['runs'] for v in row if v['engine']==e)for e in es};case['medians_ns']=v;case['after_over_rust']=v['after']/v['rust'];case['after_over_before']=v['after']/v['before']
 for name in m['per_round_ns']:
  early='entry-ownership-preload' if name=='entry-ownership' else name.split('/')[0]+'/report-preload'
  m['per_round_ns'][name]={e:(cases[name]['medians_ns'][e]-cases[early]['medians_ns'][e])/cases[name]['rounds'] for e in es}
def verify(label,expected):
 update();m['time_target_met']=expected;p=c/('check-'+label+'.json');p.write_text(json.dumps(m));r=subprocess.run([sys.executable,'-B',audit,p,'--source-root',root,'--retained',c/'baseline919/inputs'],capture_output=True);assert (r.returncode==0)==expected,(label,r.stderr[-500:]);assert expected or b'exceeds 2x Rust' in r.stderr;print(label,'passed')
verify('gate-success',True)
for r in cases['entry-ownership']['runs']:
 by={x['engine']:x for x in r};by['after']['elapsed_ns']=int(by['rust']['elapsed_ns']*2.5)
verify('gate-isolated-failure',False)
