"""Link a candidate LLVM module in both frozen modes and interleave native zero/repeated controls."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from statistics import median
import fcntl,hashlib,json,os,subprocess,sys,time
c=Path('/home/dev-user/.cache/relar/collector-ownership-20261022');prev=c.parent/'entry-sort-20261022/final-918e777';stage=c/('ir-'+sys.argv[1]);stage.mkdir();ir=c/(sys.argv[1]+'.ll');assert hashlib.sha256(ir.read_bytes()).hexdigest()==sys.argv[2]
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); old=c/'base';clang='/usr/lib/llvm-18/bin/clang';lld='/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld';core=c/'base/core';runtime=Path(sys.argv[3])if len(sys.argv)>3 else core
lock=(c/'native-pilot.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
while not (old/'ready').is_file():time.sleep(.5)
opts={}
def make(mode):
 rt=runtime/(mode+'_runtime.a');out=stage/mode;cmd=[clang,'-O3','-Wno-override-module',ir,rt,'-ldl','-lpthread','-lm','-lrt','-lutil','-o',out]
 if mode=='thinlto':cmd+=['-flto=thin','-fuse-ld='+lld,'-Wl,-mllvm,-import-instr-limit=1000,-mllvm,-inline-threshold=1000']
 cmd+=['--target='+read(core/'build-record.json')['target']]
 subprocess.run(list(map(str,cmd)),check=True)
 opts[mode]={'binary':sha(out),'runtime':sha(rt),'argv':list(map(str,cmd))}
with ThreadPoolExecutor(2)as p:list(p.map(make,['normal','thinlto']))
os.sched_setaffinity(0,{31});data={};cfgs={m:read(prev/('config-'+m+'.json')) for m in ('normal','thinlto')};dr=read(prev/'normal/results.json');fx=dr['inputs']['fixtures']['corpus'];args=fx['arguments'];gold=Path(fx['capture_oracle']['path']).read_bytes();count,score=map(int,gold.splitlines()[-1].split())
cmds={k+'-'+m:([str(stage/m),'--entries']if k=='candidate'else [str(old/('kernel-'+m)),'--entries']if k=='before'else cfgs[m]['engines']['rust']['entries'])for m in cfgs for k in ('candidate','before','rust')};labels=list(cmds);rows=[[labels[(i+j)%6]for j in [0,1,-1,2,-2,3]]for i in range(6)];env=dr['environment']
def run(k,n,action):
 st=time.perf_counter_ns();p=subprocess.run(cmds[k]+args+[str(n),action],env=env,cwd=stage,capture_output=True);dt=time.perf_counter_ns()-st;assert p.returncode==0 and not p.stderr and p.stdout==(gold if action=='dump' else f'{count} {score*n}\n'.encode()),(k,action,n,p.stderr[-500:]);return {'rounds':n,'elapsed_ns':dt,'sha256':hashlib.sha256(p.stdout).hexdigest()}
for k in cmds: run(k,1,'dump')
samples=[]
for i,row in enumerate([rows[0][::-1],*rows]):
 obs=[]
 for j,k in enumerate(row):
  v=[run(k,n,'checksum') for n in ([0,128]if (i+j)%2 else[128,0])];tot={x['rounds']:x['elapsed_ns']for x in v};obs.append({'engine':k,'runs':v,'net_ns':(tot[128]-tot[0])/128})
 samples.append(obs)
med={k:median(v['net_ns']for r in samples[1:]for v in r if v['engine']==k)for k in cmds}
d={'tag':sys.argv[1],'ir':sys.argv[2],'builds':opts,'commands':cmds,'input_sha256':{p:sha(Path(p))for p in args},'transcript_sha256':hashlib.sha256(gold).hexdigest(),'binary_sha256':{k:sha(Path(v[0]))for k,v in cmds.items()},'cpu':31,'orders':rows,'warmup':samples[0],'samples':samples[1:],'medians_ns':med,'ratios':{m:med['candidate-'+m]/med['rust-'+m]for m in cfgs}}
(stage/'results.json').write_text(json.dumps(d,indent=2)+'\n');print(med,d['ratios'],flush=True)
