from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
p=Path(__file__).resolve().parent
assert not sys.flags.optimize
run=lambda n:json.loads(subprocess.check_output([sys.executable,"-B",p/n],cwd=p))
base=run("formal_replay.py")
base["serial"]=run("audit-serial.py")
ownership=run("ownership-breakdown.py")
assert ownership==json.loads((p/"profiles/allocation-groups.json").read_bytes())
base["allocation_profile"]={k:{"per_pass":v["per_pass"],"by_site":v["by_site"]}for k,v in ownership["modes"].items()}
base["real_equivalence_group_lengths"]=ownership["equal_lengths"]
qa=p/"validation/local-qa.tar.gz"
with tarfile.open(qa)as t:
 members={m.name:m for m in t.getmembers() if m.isfile()}
 manifest=next(name for name in members if name.endswith("qa-index.json"))
 index=json.load(t.extractfile(manifest))
 assert index["revision"]==base["revision"]
 guard=index["llvm_before_first_sorted_list"]["collector"]
 assert guard["string_equality"]==4 and guard["python_integer_equality"]==2 and all(guard[k]==0 for k in ("record_allocation","record_retain","record_release"))
 for name,v in index["files"].items():
  blob=t.extractfile(name).read();assert len(blob)==v["bytes"] and hashlib.sha256(blob).hexdigest()==v["sha256"]
 base["local_qa"]={"sha256":hashlib.sha256(qa.read_bytes()).hexdigest(),"indexed":len(index["files"])}
print(json.dumps(base,indent=2))
