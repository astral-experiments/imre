"""Verify the interleaved native catalog rerun (Python standard library only)."""
import gzip
import hashlib
import json
import statistics
import sys
from collections import Counter
from pathlib import Path


rows = json.loads(Path(sys.argv[1]).read_bytes())
assert rows["completed"]
engines = {"before", "after", "rust", "before_thin", "after_thin", "rust_thin"}
labels = {"1x-plain", "1x-gzip", "10x-plain", "10x-gzip"}
assert set(rows["paths"]) == engines | labels | {"monitor", "oracle"}
assert len({rows["paths"][e]["sha256"] for e in engines}) == len(engines)
if len(sys.argv) == 4:
    for i, prefix in [(2, "before"), (3, "after")]:
        raw = Path(sys.argv[i]).read_bytes()
        if raw.startswith(b"\x1f\x8b"):
            raw = gzip.decompress(raw)
        if prefix == "before":
            assert hashlib.sha256(raw).hexdigest() == rows["baseline_sha256"]
        full = json.loads(raw)["hashes"]
        for label, engine in [(prefix, "imre"), (prefix + "_thin", "imre_thin"), ("rust", "rust"), ("rust_thin", "rust_thin")]:
            assert rows["paths"][label]["sha256"] == full[engine]["sha256"]
            assert rows["paths"][label]["bytes"] == full[engine]["bytes"]
orders = rows["orders"]
assert len(orders) >= len(engines) and len(orders) % len(engines) == 0
positions = [Counter(col) for col in zip(*orders, strict=True)]
assert all(set(c) == engines and set(c.values()) == {len(orders) // len(engines)} for c in positions)
edges = Counter((a, b) for order in orders for a, b in zip(order[:-1], order[1:], strict=True))
assert len(edges) == len(engines) * (len(engines) - 1)
assert all(edges[(a, b)] == len(orders) // len(engines) for a in engines for b in engines if a != b)
accepted = "753cd906307c1b4f830e9348703e0110ba38fddd97293780f146f78f0ed9a3f6"
assert rows["paths"]["oracle"]["sha256"] == accepted
assert set(rows["cases"]) == labels
summary = {}
for name, case in rows["cases"].items():
    assert len(case["samples"]) == len(orders)
    for order, samples in zip(orders, case["samples"], strict=True):
        assert [r["engine"] for r in samples] == order
    for samples in [case["warmup"], *case["samples"]]:
        assert len(samples) == len(engines) and {r["engine"] for r in samples} == engines
        assert all(r["output_sha256"] == accepted and r["elapsed_ns"] > 0 and r["peak_rss_kib"] > 0 for r in samples)
    m = {
        engine: {
            field: statistics.median(r[field] for samples in case["samples"] for r in samples if r["engine"] == engine)
            for field in ("elapsed_ns", "peak_rss_kib")
        }
        for engine in sorted(engines)
    }
    assert m == case["medians"]
    summary[name] = {
        mode: {
            "before_ms": m[before]["elapsed_ns"] / 1e6,
            "after_ms": m[after]["elapsed_ns"] / 1e6,
            "rust_ms": m[rust]["elapsed_ns"] / 1e6,
            "elapsed_reduction": 1 - m[after]["elapsed_ns"] / m[before]["elapsed_ns"],
            "before_over_rust": m[before]["elapsed_ns"] / m[rust]["elapsed_ns"],
            "after_over_rust": m[after]["elapsed_ns"] / m[rust]["elapsed_ns"],
        }
        for mode, before, after, rust in (
            ("ordinary", "before", "after", "rust"),
            ("thinlto", "before_thin", "after_thin", "rust_thin"),
        )
    }
print(json.dumps(summary, indent=2))
