from pathlib import Path
import argparse, hashlib, itertools, json, os, platform, statistics, subprocess, sys, time
parser=argparse.ArgumentParser()
parser.add_argument('names',nargs='+')
parser.add_argument('--output',required=True)
parser.add_argument('--samples',type=int,default=8)
parser.add_argument('--rounds',type=int,default=1500)
args=parser.parse_args()
p=Path(__file__).parent
os.sched_setaffinity(0,{29})
sha=lambda b:hashlib.sha256(b).hexdigest()
def identity(path):return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
ph=dict(os.environ,PYTHONPATH='/home/dev-user/code/oss/imre-catalog-json-perf/stdlib')
orders=list(itertools.permutations(args.names))
assert args.samples%len(orders)==0
orders=(orders+orders[::-1])*(args.samples//len(orders)//2)+ (orders if args.samples//len(orders)%2 else [])
receipt={'toolchains':{'clang':subprocess.check_output(['clang-18','--version'],text=True).splitlines()[0]},
  'host':platform.node(),'cpu':list(os.sched_getaffinity(0)),
  'input_program':identity(p/'tiny.py'),'llvm':identity(p/'tiny.ll'),'runner':identity(Path(__file__)),
  'binaries':{k:identity(p/k) for k in args.names},'orders':orders,'rounds':args.rounds,'cases':{}}
for case in ['counters','labels','tagged']:
 f=p/f'{case}.ndjson'
 inputs=f.read_bytes().splitlines()
 def cpython(n):return subprocess.check_output([sys.executable,p/'tiny.py',case,f,str(n)],env=ph)
 one=cpython(1); expected_score, records=one.split(b'\n',1)
 assert cpython(2)==str(int(expected_score)*2).encode()+b'\n'+records
 expected=str(int(expected_score)*args.rounds).encode()+b'\n'+records
 samples={k:[] for k in args.names}
 def observe(name):
  start=time.perf_counter_ns()
  child=subprocess.run([p/name,case,f,str(args.rounds)],capture_output=True)
  elapsed=time.perf_counter_ns()-start
  assert child.returncode==0 and child.stderr==b'' and child.stdout==expected,(case,name,child.stderr,child.stdout[:70],expected[:70])
  return elapsed
 warm={k:observe(k) for k in args.names}
 for order in orders:
  for k in order:samples[k].append(observe(k))
 med={k:statistics.median(v) for k,v in samples.items()}
 ratios={k:v/med[args.names[0]] for k,v in med.items() if k!=args.names[0]}
 receipt['cases'][case]={'input':identity(f),'rows':len(inputs),'min_bytes':min(map(len,inputs)),'max_bytes':max(map(len,inputs)),
 'timed_decodes':len(inputs)*args.rounds,'expected_stdout_sha256':sha(expected),'expected_stdout_bytes':len(expected),'checksum':int(expected_score)*args.rounds,
 'warmups_ns':warm,'samples_ns':samples,'medians_ns':med,'relative_to_first':ratios}
 print(case,med,ratios,flush=True)
(p/args.output).write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
