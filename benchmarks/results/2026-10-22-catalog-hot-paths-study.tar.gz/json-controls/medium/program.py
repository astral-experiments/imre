import sys

from imre.json import decode, encode


class Counts:
    id: int
    active: bool
    samples: list[int]

    def __init__(self, id: int, active: bool, samples: list[int]) -> None:
        self.id = id
        self.active = active
        self.samples = samples


class Label:
    name: str

    def __init__(self, name: str) -> None:
        self.name = name


class Tagged:
    name: str
    priority: int
    counters: list[int]

    def __init__(self, name: str, priority: int, counters: list[int]) -> None:
        self.name = name
        self.priority = priority
        self.counters = counters


def counts(texts: list[str], rounds: int) -> None:
    total = 0
    for _ in range(rounds):
        for text in texts:
            event = decode(text, Counts)
            if event.active:
                total += event.samples[-1] + event.id
    print(total)
    for text in texts:
        print(encode(decode(text, Counts)))


def labels(texts: list[str], rounds: int) -> None:
    total = 0
    for _ in range(rounds):
        for text in texts:
            entry = decode(text, Label)
            total += len(entry.name)
    print(total)
    for text in texts:
        print(encode(decode(text, Label)))


def tagged(texts: list[str], rounds: int) -> None:
    total = 0
    for _ in range(rounds):
        for text in texts:
            entry = decode(text, Tagged)
            total += len(entry.name) + entry.priority + entry.counters[-1]
    print(total)
    for text in texts:
        print(encode(decode(text, Tagged)))


with open(sys.argv[2], "r", encoding="utf-8") as resource:
    rows = resource.read().splitlines()
count = int(sys.argv[3])
if sys.argv[1] == "counters":
    counts(rows, count)
elif sys.argv[1] == "labels":
    labels(rows, count)
else:
    tagged(rows, count)
