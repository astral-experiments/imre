import sys

from imre.json import decode, encode


class Event:
    id: int
    enabled: bool

    def __init__(self, id: int, enabled: bool) -> None:
        self.id = id
        self.enabled = enabled


class Label:
    name: str

    def __init__(self, name: str) -> None:
        self.name = name


class Repeated:
    category: str
    tags: list[str]

    def __init__(self, category: str, tags: list[str]) -> None:
        self.category = category
        self.tags = tags


class Config:
    name: str
    enabled: bool

    def __init__(self, name: str, enabled: bool = True) -> None:
        self.name = name
        self.enabled = enabled


def events(texts: list[str], rounds: int) -> None:
    total = 0
    for _ in range(rounds):
        for text in texts:
            event = decode(text, Event)
            if event.enabled:
                total += event.id
    print(total)
    for text in texts:
        print(encode(decode(text, Event)))


def labels(texts: list[str], rounds: int) -> None:
    total = 0
    for _ in range(rounds):
        for text in texts:
            label = decode(text, Label)
            total += len(label.name)
    print(total)
    for text in texts:
        print(encode(decode(text, Label)))


def repeated(texts: list[str], rounds: int) -> None:
    total = 0
    for _ in range(rounds):
        for text in texts:
            entry = decode(text, Repeated)
            for tag in entry.tags:
                if tag == entry.category:
                    total += len(tag)
    print(total)
    for text in texts:
        print(encode(decode(text, Repeated)))


def configs(texts: list[str], rounds: int) -> None:
    total = 0
    for _ in range(rounds):
        for text in texts:
            entry = decode(text, Config)
            if entry.enabled:
                total += len(entry.name)
    print(total)
    for text in texts:
        print(encode(decode(text, Config)))


with open(sys.argv[2], "r", encoding="utf-8") as resource:
    rows = resource.read().splitlines()
count = int(sys.argv[3])
if sys.argv[1] == "events":
    events(rows, count)
elif sys.argv[1] == "labels":
    labels(rows, count)
elif sys.argv[1] == "repeated":
    repeated(rows, count)
else:
    configs(rows, count)
