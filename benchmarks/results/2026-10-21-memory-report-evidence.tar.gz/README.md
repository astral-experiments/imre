# Memory-report evidence

This archive contains original capture bytes, not rewritten measurements.
`provenance/logical-index.json` maps original absolute artifact paths to shared
`blobs/sha256/*` members. Its source snapshots additionally preserve Git blob IDs
and index modes for each recorded revision. Restore a source tree by copying each
source entry's member bytes to its relative path and applying its recorded mode.
Repeated raw inputs and outputs share members without losing logical identities.

Native executables, archives, bitcode, and bytecode are deliberately omitted and
hash-identified in `provenance/exclusions.json`. Toolchains/build caches and
unrelated historical result archives are not included. Full source manifests
identify omitted historical results by Git blob IDs. Raw stdout/stderr/status and
per-execution file hashes remain in the timing/preparation records; retained final
filesystem bytes are indexed for every engine/workload/mode. Instrumented traces
are diagnostic, not wall timing evidence.

Run the published `2026-10-21-memory-report-audit.py` beside the public evidence
archive/manifest/index and raw JSON gzip sidecars for portable data-only replay.
No native executable or local developer path is required for that replay.
