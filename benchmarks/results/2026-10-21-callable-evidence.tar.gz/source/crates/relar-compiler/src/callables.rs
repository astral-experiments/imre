//! Closed target sets for exact callable signatures in the final typed program.

use std::collections::HashMap;

use crate::ir::{self, ExprKind, Module, Type};

/// Bound targets use the callable record's receiver as the first native argument.
/// Their effects still come from the ordinary function, never a fresh initializer.
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(crate) struct Target {
    pub function: usize,
    pub bound: bool,
}

#[derive(Default)]
pub(crate) struct Targets(HashMap<Type, Vec<Target>>);

impl Targets {
    /// Every callable originates at an explicit construction in this closed IR.
    /// Joining all constructions of a signature deliberately ignores value flow,
    /// so returning, forwarding, or conditionally selecting one cannot hide a target.
    pub(crate) fn analyze(module: &Module) -> Self {
        let mut targets = Self::default();
        for function in module.functions.iter().chain([&module.entry]) {
            ir::walk_expressions(&function.body, &mut |value| {
                if let ExprKind::Callable { function, receiver } = &value.kind {
                    targets.0.entry(value.ty).or_default().push(Target {
                        function: *function,
                        bound: receiver.is_some(),
                    });
                }
            });
        }
        for values in targets.0.values_mut() {
            values.sort_unstable();
            values.dedup();
        }
        targets
    }

    /// An empty set is unknown, not proof that an invocation is unreachable.
    pub(crate) fn get(&self, ty: Type) -> &[Target] {
        self.0.get(&ty).map_or(&[], Vec::as_slice)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ir::{Expr, Function, Statement};

    fn function(body: Vec<Statement>) -> Function {
        Function {
            params: Vec::new(),
            returns: Type::None,
            locals: Vec::new(),
            body,
        }
    }

    #[test]
    fn nested_and_entry_constructions_join_by_exact_signature() {
        let callable = |ty, function, receiver| Expr {
            ty,
            kind: ExprKind::Callable { function, receiver },
        };
        let first = Type::Callable(0);
        let second = Type::Callable(1);
        let module = Module {
            types: Default::default(),
            class_fields: Vec::new(),
            globals: Vec::new(),
            functions: vec![function(vec![Statement::Expr(Expr {
                ty: first,
                kind: ExprKind::Scope {
                    body: vec![Statement::Expr(callable(first, 3, None))],
                    value: Box::new(callable(first, 1, None)),
                    clear: Vec::new(),
                },
            })])],
            entry: function(vec![
                Statement::Expr(callable(first, 3, None)),
                Statement::Expr(callable(
                    first,
                    1,
                    Some(Box::new(Expr {
                        ty: Type::Class(0),
                        kind: ExprKind::Scope {
                            body: vec![Statement::Expr(callable(second, 2, None))],
                            value: Box::new(Expr {
                                ty: Type::Class(0),
                                kind: ExprKind::Local(0),
                            }),
                            clear: Vec::new(),
                        },
                    })),
                )),
            ]),
        };
        let targets = Targets::analyze(&module);
        assert_eq!(
            targets.get(first),
            [
                Target {
                    function: 1,
                    bound: false
                },
                Target {
                    function: 1,
                    bound: true
                },
                Target {
                    function: 3,
                    bound: false
                },
            ]
        );
        assert_eq!(
            targets.get(second),
            [Target {
                function: 2,
                bound: false
            }]
        );
        assert!(targets.get(Type::Callable(2)).is_empty());
    }
}
