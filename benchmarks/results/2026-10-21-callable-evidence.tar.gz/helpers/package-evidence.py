"""Verify and package frozen callback measurements without running native programs.

This utility rechecks source/tool/build identities, regenerates the frozen Python
oracles and canonical workload descriptions, verifies every retained execution,
recomputes medians/ratios, and emits deterministic portable source/raw evidence.
No native executable, static archive, bitcode, or Python bytecode is published.
"""

import argparse
import base64
import gzip
import hashlib
import importlib.util
import io
import itertools
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import runpy
import stat
import statistics
import subprocess
import sys
import tarfile
from datetime import datetime
from types import SimpleNamespace

def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def relative_name(value):
    name = PurePosixPath(value)
    require(not name.is_absolute() and ".." not in name.parts and str(name) != ".",
            f"unsafe archive member: {value}")
    return str(name)


def native_kind(header):
    """Inspect bytes, preserving data files merely named *.bin, *.a, or *.pyc."""
    if header.startswith(b"\x7fELF"):
        return "ELF executable, object, or shared library"
    if header.startswith((b"!<arch>\n", b"!<thin>\n")):
        return "static archive"
    if header.startswith((b"BC\xc0\xde", b"\xde\xc0\x17\x0b")):
        return "LLVM bitcode"
    if header[:4] in {b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
                      b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe",
                      b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",
                      b"\xca\xfe\xba\xbf", b"\xbf\xba\xfe\xca"}:
        return "Mach-O native code or Java bytecode"
    if header.startswith(b"MZ"):
        return "PE executable or object"
    if header.startswith(b"\0asm"):
        return "WebAssembly bytecode"
    magic = int.from_bytes(header[:2], "little")
    if (header[:4] == importlib.util.MAGIC_NUMBER
            or header[2:4] == b"\r\n" and (3000 <= magic < 4000 or magic == 62211)):
        return "Python bytecode"
    return None


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def hash_values(value):
    """Collect audit hash bindings without depending on its presentation layout."""
    if isinstance(value, str):
        return {value} if re.fullmatch(r"[0-9a-f]{64}", value) else set()
    if isinstance(value, dict):
        return set().union(*(hash_values(item) for item in value.values()))
    if isinstance(value, list):
        return set().union(*(hash_values(item) for item in value))
    return set()


def command_option(command, name):
    require(command.count(name) == 1, f"expected exactly one {name} in command")
    return Path(command[command.index(name) + 1]).resolve(strict=True)


class Package:
    def __init__(self):
        self.files = {}
        self.trees = {}
        self.members = {}
        self.exclusions = []

    def guard(self, path, expected=None):
        path = Path(path).absolute()
        require(path.is_file(), f"missing regular input: {path}")
        value = {"sha256": sha(path), "bytes": path.stat().st_size,
                 "resolved": str(path.resolve(strict=True)),
                 "symlink": os.readlink(path) if path.is_symlink() else None}
        require(expected is None or value["sha256"] == expected,
                f"input hash mismatch: {path}")
        prior = self.files.setdefault(path, value)
        require(prior == value, f"input changed while packaging: {path}")
        return value["sha256"]

    def read_json(self, path):
        self.guard(path)
        data = Path(path).read_bytes()
        require(digest(data) == self.files[Path(path).absolute()]["sha256"],
                f"JSON changed while reading: {path}")
        return json.loads(data)

    def add_bytes(self, name, data, mode=0o644):
        name = relative_name(name)
        require(name not in self.members, f"duplicate archive member: {name}")
        require(native_kind(data[:16]) is None, f"native bytes in source member: {name}")
        self.members[name] = {"data": data, "sha256": digest(data),
                              "bytes": len(data), "mode": mode}

    def add_file(self, name, path, *, omit=None):
        name, path = relative_name(name), Path(path).absolute()
        value = self.guard(path)
        with path.open("rb") as stream:
            reason = omit or native_kind(stream.read(16))
        if reason:
            self.exclusions.append({"would_be_member": name, "path": str(path),
                                    "sha256": value, "bytes": path.stat().st_size,
                                    "reason": reason})
            return
        require(not path.is_symlink(), f"symlink cannot be archived: {path}")
        require(name not in self.members, f"duplicate archive member: {name}")
        self.members[name] = {"path": path, "sha256": value,
                              "bytes": path.stat().st_size, "mode": 0o644}

    @staticmethod
    def tree_entries(directory):
        require(directory.is_dir() and not directory.is_symlink(),
                f"expected regular input directory: {directory}")
        entries = {}
        for path in sorted(directory.rglob("*")):
            mode = path.lstat().st_mode
            require(stat.S_ISDIR(mode) or stat.S_ISREG(mode),
                    f"special file or symlink in evidence: {path}")
            entries[path.relative_to(directory).as_posix()] = stat.S_ISDIR(mode)
        return entries

    def add_tree(self, name, directory):
        directory = Path(directory).absolute()
        entries = self.tree_entries(directory)
        require(self.trees.setdefault(directory, entries) == entries,
                f"directory changed while packaging: {directory}")
        for relative, is_directory in entries.items():
            if not is_directory:
                self.add_file(f"{name}/{relative}", directory / relative)

    def check(self):
        for path in list(self.files):
            self.guard(path)
        for directory, entries in self.trees.items():
            require(self.tree_entries(directory) == entries,
                    f"directory membership changed: {directory}")

    def write(self, prefix, metadata):
        archive_path = Path(str(prefix) + "-evidence.tar.gz")
        manifest_path = Path(str(prefix) + "-evidence-manifest.json")
        temporary = Path(str(archive_path) + ".partial")
        require(not any(path.exists() for path in (archive_path, manifest_path, temporary)),
                "output already exists; choose a fresh prefix")
        require(all(directory != prefix.parent and directory not in prefix.parents
                    for directory in self.trees), "outputs overlap an input directory")
        self.add_bytes("provenance/package.json", json_bytes(metadata))
        self.add_bytes("provenance/exclusions.json", json_bytes(sorted(
            self.exclusions, key=lambda item: item["would_be_member"])))
        self.check()
        with temporary.open("xb") as raw:
            with gzip.GzipFile(filename="", mode="wb", fileobj=raw,
                               mtime=0, compresslevel=9) as compressed:
                with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                    for name, value in sorted(self.members.items()):
                        data = value["data"] if "data" in value else value["path"].read_bytes()
                        require(digest(data) == value["sha256"] and len(data) == value["bytes"],
                                f"member changed during write: {name}")
                        member = tarfile.TarInfo(name)
                        member.size, member.mode, member.mtime = len(data), value["mode"], 0
                        member.uid = member.gid = 0
                        member.uname = member.gname = ""
                        archive.addfile(member, io.BytesIO(data))
        with tarfile.open(temporary, "r:gz") as archive:
            require(archive.getnames() == sorted(self.members), "archive member set differs")
            for member in archive:
                require(member.isfile(), f"non-regular archive member: {member.name}")
                data = archive.extractfile(member).read()
                expected = self.members[member.name]
                require(digest(data) == expected["sha256"] and len(data) == expected["bytes"]
                        and member.mode == expected["mode"] and member.mtime == 0
                        and member.uid == member.gid == 0 and not member.uname and not member.gname
                        and native_kind(data[:16]) is None, f"bad archive member: {member.name}")
        self.check()
        manifest = {"schema": 1, "status": "passed", **metadata,
                    "archive": {"name": archive_path.name, "sha256": sha(temporary),
                                "bytes": temporary.stat().st_size},
                    "member_count": len(self.members),
                    "members": {name: {key: value[key] for key in ("sha256", "bytes", "mode")}
                                for name, value in sorted(self.members.items())},
                    "excluded_artifact_count": len(self.exclusions),
                    "guarded_input_files": len(self.files), "guarded_input_trees": len(self.trees)}
        # Exclusive creation never overwrites evidence from an earlier run.
        os.link(temporary, archive_path)
        temporary.unlink()
        with manifest_path.open("xb") as stream:
            stream.write(json_bytes(manifest))
        print(json.dumps({"archive": str(archive_path), "manifest": str(manifest_path),
                          "archive_sha256": manifest["archive"]["sha256"],
                          "members": len(self.members), "excluded": len(self.exclusions)}, indent=2))


REVISION = "848477f3d06fb1afe6d4bdd93dae4b107c90229a"
ENGINES = ("relar", "cpython", "rust")
MODES = ("normal", "thinlto")


def close(actual, expected, label):
    require(isinstance(actual, (int, float)) and math.isfinite(actual)
            and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-15),
            "numeric result differs: " + label)


def decoded_files(encoded):
    result = {}
    for name, item in encoded.items():
        relative_name(name)
        data = base64.b64decode(item["base64"], validate=True)
        require(len(data) == item["bytes"] and digest(data) == item["sha256"],
                "encoded file identity differs: " + name)
        result[name] = data
    return result


def expected_result(expected):
    return {"returncode": 0, "stdout": expected["stdout"], "stderr": "",
            "files": {name: {"sha256": digest(data), "bytes": len(data)}
                      for name, data in sorted(expected["files"].items())},
            "directories": expected["directories"]}


def verify_execution(actual, expected, command=None):
    result = expected_result(expected)
    require(all(actual.get(key) == value for key, value in result.items()),
            "complete execution result differs")
    if command is not None:
        require(actual["command"] == command, "execution command differs")
        require(type(actual["elapsed_ns"]) is int and actual["elapsed_ns"] > 0,
                "invalid elapsed time")


def summaries(samples):
    result = {}
    for engine in ENGINES:
        values = [sample[engine]["elapsed_ns"] / 1e9 for sample in samples]
        quartiles = statistics.quantiles(values, n=4, method="inclusive")
        result[engine] = {"median_seconds": statistics.median(values),
                          "min_seconds": min(values), "max_seconds": max(values),
                          "p25_seconds": quartiles[0], "p75_seconds": quartiles[2]}
    return result


def verify_workload(workload, description, record, validator, commands, directory):
    require({key: workload[key] for key in description} == description,
            "canonical workload changed: " + description["label"])
    case = validator.case_from_record(workload["case"])
    require(decoded_files(workload["case"]["files"]) == case.files, "case files differ")
    expected = validator.oracle(case)
    condition = directory / workload["label"]
    require({path.name for path in condition.iterdir()} == set(ENGINES),
            "retained condition engine directory set differs")
    require(workload["expected_stdout"] == expected["stdout"]
            and decoded_files(workload["expected_files"]) == expected["files"],
            "recorded expectation differs from independent oracle")
    require(set(workload["gates"]) == set(ENGINES), "gate engine set differs")
    for engine in ENGINES:
        verify_execution(workload["gates"][engine], expected,
                         [*commands[engine], *case.arguments])
    for phase in ("warmups", "samples"):
        rounds = workload[phase]
        require(len(rounds) == record[phase], "round count differs")
        for index, current in enumerate(rounds):
            require(current["index"] == index
                    and current["order"] == record["engine_orders"][index % 6]
                    and set(current) == {"index", "order", *ENGINES},
                    "round order or engine set differs")
            for engine in ENGINES:
                verify_execution(current[engine], expected,
                                 [*commands[engine], *case.arguments])
    measured = summaries(workload["samples"])
    require(set(workload["summary"]) == set(ENGINES), "summary engines differ")
    for engine in ENGINES:
        require(set(workload["summary"][engine]) == set(measured[engine]),
                "summary statistics differ")
        for key, number in measured[engine].items():
            close(workload["summary"][engine][key], number, engine + ":" + key)
        if workload["records"]:
            close(workload["startup_control_fraction"][engine],
                  record["startup_control"]["summary"][engine]["median_seconds"]
                  / measured[engine]["median_seconds"], "control fraction")
        current = directory / workload["label"] / engine
        actual = {path.relative_to(current).as_posix(): path.read_bytes()
                  for path in current.rglob("*") if path.is_file()}
        require(actual == expected["files"] and not any(path.is_dir() for path in current.rglob("*")),
                "retained final filesystem differs: " + str(current))
    for left, right in (("cpython", "relar"), ("relar", "rust"), ("cpython", "rust")):
        close(workload[left + "_over_" + right],
              measured[left]["median_seconds"] / measured[right]["median_seconds"],
              left + "/" + right)
    return {"label": workload["label"], "records": workload["records"],
            "repetitions": workload["repetitions"], "summary": measured,
            "relar_over_rust": workload["relar_over_rust"],
            "cpython_over_relar": workload["cpython_over_relar"]}


def report_text(records, audit, prefix):
    large = {row["label"]: row["relar_over_rust"] for row in records["thinlto"]["workloads"]
             if row["records"] == 4096}
    full = [large[mode + "-full-4096"] for mode in ("gross", "net")]
    selective = [large[mode + "-selective-4096"] for mode in ("gross", "net")]
    require(all(value > 2 for value in full), "full-selection headline needs a different target conclusion")
    lines = ["# Typed callbacks: payout pipeline", "",
             "The [callback payout program](../../examples/record_pipeline/README.md) takes "
             f"**{min(full):.2f}–{max(full):.2f}× Rust's time** on the two 4,096-record full-selection ThinLTO cases. "
             f"Selective cases take **{min(selective):.2f}–{max(selective):.2f}×**. The full-selection cases remain above 2× Rust. "
             "This is a separate workload from the telemetry and memory-report comparisons.", "",
             "The measured compiler/runtime source is [`" + REVISION + "`](https://github.com/viarius-experiments/relar/commit/" + REVISION + "). "
             "The same Python source runs under Relar and CPython. It passes and returns typed "
             "function values, retains receivers in bound methods, uses a noncapturing lambda, "
             "and composes lazy `map`/`filter` pipelines without an intermediate payout list.", "",
             "## Results", "",
             "All values are whole-process median milliseconds. CPython / Relar is a speedup; "
             "Relar / Rust is a time ratio. Raw samples, inclusive quartiles and empty controls "
             "are retained in the linked measurement records.", ""]
    for mode in MODES:
        lines += ["### " + ("Ordinary linking" if mode == "normal" else "ThinLTO"), "",
                  "| Workload / records | Relar ms | Rust ms | CPython ms | CPython / Relar | Relar / Rust |",
                  "|---|---:|---:|---:|---:|---:|"]
        for row in records[mode]["workloads"]:
            values = row["summary"]
            lines.append(f"| `{row['label']}` | {values['relar']['median_seconds']*1000:.3f} | "
                         f"{values['rust']['median_seconds']*1000:.3f} | {values['cpython']['median_seconds']*1000:.3f} | "
                         f"{row['cpython_over_relar']:.3f}× | {row['relar_over_rust']:.3f}× |")
        lines += [""]
    lines += ["## Workload and method", "",
              "Each process parses one record file, repeatedly selects eligible records by a bound "
              "risk-policy callback, computes either gross amounts or net amounts after a fee, "
              "and filters out nonpositive payouts. It writes one complete count/total/largest "
              "report and a repetition checksum. Full selection uses a risk limit of 99; selective "
              "selection uses 9. Both inspect every input record; selective cases perform fewer "
              "transforms and reductions, rather than exiting the scan early.", "",
              "Inputs use a fixed random seed, with 32 or 4,096 records. Each process inspects "
              "8,388,608 input records across 262,144 or 2,048 complete queries respectively. "
              "Each condition has a correctness gate, two warmup rounds and twelve measured rounds. "
              "All six permutations of Relar, CPython and Rust occur twice among measured rounds; "
              "warmups and cross-round transitions are not balanced. CPU affinity is fixed to CPU 31 "
              "on an AMD EPYC-Milan host. These are shared-host measurements, not isolated-hardware guarantees.", "",
              "Timing includes startup, parsing, all queries, checksum formatting and the final report "
              "write/close. Complete result and filesystem checks run outside the timed interval. "
              "Warm filesystem caches apply and no `fsync` is requested. Empty controls are not "
              "subtracted and omit nonempty parsing costs.", "",
              "| Linking | Empty Relar ms | Empty Rust ms | Empty CPython ms | Maximum Relar control/workload |",
              "|---|---:|---:|---:|---:|"]
    for mode in MODES:
        control = records[mode]["startup_control"]["summary"]
        fraction = max(row["startup_control_fraction"]["relar"] for row in records[mode]["workloads"])
        lines.append(f"| {mode} | {control['relar']['median_seconds']*1000:.3f} | "
                     f"{control['rust']['median_seconds']*1000:.3f} | {control['cpython']['median_seconds']*1000:.3f} | {fraction:.2%} |")
    lines += ["", "CPython is 3.14.5 with PGO/LTO, the GIL enabled and JIT disabled. Native builds "
              "use Clang 18 and the pinned Ohm Rust 1.98.1-dev toolchain (LLVM 22.1.8), at optimization "
              "level 3. Both native engines use the named ordinary or ThinLTO mode; ThinLTO uses "
              "import/inline budgets of 1,000. Separate batches have separate interleaved baselines, "
              "so their differences do not isolate linking alone.", "",
              "Rust stores records contiguously and uses native `i64` arithmetic with checked "
              "overflow and a `BigInt` retry over retained arbitrary-precision input. Its iterator "
              "closures can inline; each query and result passes through `black_box`. Relar uses "
              "typed records and first-class callback values. Closed-target analysis preserves "
              "safe borrowing and removes some dispatch/error checks, but this example still has "
              "multiple possible transform callbacks. The measurements compare these concrete "
              "implementations and storage/dispatch costs, not a universal language ranking.", "",
              "## Validation and retained evidence", "",
              "Each exact native pair passed all **122 independent application cases** against "
              "CPython, including huge integers, overflow, malformed inputs, Unicode separators, "
              "output preservation, overwritten inputs, hard links and invalid paths. Across both "
              "link modes that is 732 preparation executions. The measurement records contain "
              "54 correctness gates, 108 warmup executions and 648 measured executions. Every "
              "recorded return status, stdout, stderr and complete filesystem result was rechecked "
              "against the frozen independent oracle during packaging; medians, quartiles, ratios "
              "and measured engine order were recomputed. This evidence package is an application "
              "benchmark record, not a claim that a separate full compiler validation matrix ran here.", "",
              "The [audit](" + prefix.name + "-audit.json), [manifest](" + prefix.name + "-evidence-manifest.json) "
              "and [deterministic archive](" + prefix.name + "-evidence.tar.gz) retain frozen source, "
              "LLVM, build/preparation records, exact commands, all raw process results, final "
              "input/output files and verification helpers. Original paths and hashes remain intact. "
              "Native binaries, static archives, bytecode, toolchains and prior result archives "
              "are excluded; executable/tool identities remain hash-recorded. Reproduction requires "
              "rebuilding the frozen source and selecting equivalent local tool paths.", "",
              "| Raw record | Uncompressed SHA256 |", "|---|---|"]
    for mode in MODES:
        lines.append(f"| [{mode}]({prefix.name}-{mode}.json.gz) | `{audit['timing'][mode]['sha256']}` |")
    lines += ["", "The ordinary and ThinLTO batches completed on 2026-10-21. No profile counts "
              "or instrumented durations are used as timing samples in this report.", ""]
    return "\n".join(lines).encode()


def main():
    require(not sys.flags.optimize, "run packaging without Python -O")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--prefix", type=Path, required=True)
    parser.add_argument("--normal", type=Path, required=True)
    parser.add_argument("--thinlto", type=Path, required=True)
    parser.add_argument("--normal-preparation", type=Path, required=True)
    parser.add_argument("--thinlto-preparation", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--timing-log", type=Path, required=True)
    args = parser.parse_args()
    root, prefix = args.root.resolve(strict=True), args.prefix.absolute()
    require(prefix.parent.is_dir(), "output parent is missing")
    require(prefix.name == "2026-10-21-callable", "unexpected publication prefix")
    outputs = [Path(str(prefix) + suffix) for suffix in
               ("-benchmarks.md", "-normal.json.gz", "-thinlto.json.gz", "-audit.json",
                "-evidence.tar.gz", "-evidence-manifest.json")]
    require(not any(path.exists() for path in outputs), "publication outputs already exist")
    package = Package()
    self_hash = package.guard(__file__)
    package.add_file("helpers/package-evidence.py", __file__)

    def git(*arguments):
        return subprocess.check_output(["git", "-C", str(root), *arguments])

    require(git("rev-parse", "HEAD").decode().strip() == REVISION
            and not git("status", "--porcelain").strip(), "frozen source checkout changed")
    common_git = git("rev-parse", "--git-common-dir").decode().strip()
    tracked = git("ls-tree", "-r", "-z", REVISION).split(b"\0")
    source_modes = {}
    for entry in filter(None, tracked):
        metadata, name = entry.split(b"\t", 1)
        mode, kind, object_id = metadata.split()
        if name.startswith(b"benchmarks/results/"):
            continue
        require(kind == b"blob" and mode in (b"100644", b"100755"), "unsupported tracked source kind")
        source_modes[name.decode()] = int(mode, 8) & 0o777
    names = sorted(source_modes)
    source = {}
    with tarfile.open(fileobj=io.BytesIO(git("archive", "--format=tar", REVISION, "--", *names))) as archive:
        for member in archive:
            if member.isdir():
                continue
            require(member.isfile() and member.name in names, "unexpected source member")
            data = archive.extractfile(member).read()
            mode = source_modes[member.name]
            source[member.name] = {"sha256": digest(data), "bytes": len(data), "mode": mode}
            package.guard(root / member.name, digest(data))
            package.add_bytes("source/" + member.name, data, mode)
    require(set(source) == set(names), "source inventory differs")
    package.add_bytes("provenance/source-manifest.json", json_bytes(source))
    build = package.read_json(args.build)
    require(build["revision"] == REVISION and build["input_guards_passed"]
            and build["source_matches_revision"], "compiler build identity differs")
    package.add_file("build/relar.json", args.build)
    for name, path in build["paths"].items():
        package.guard(path, build["sha256"][name])
        package.add_file("excluded/build/" + name, path)
    package.add_file("timing/launcher.log", args.timing_log)
    records = {}
    audit = {"schema": 1, "kind": "callable-benchmark-evidence-audit", "status": "passed",
             "revision": REVISION, "packager_sha256": self_hash,
             "source_tree": git("rev-parse", REVISION + "^{tree}").decode().strip(),
             "source_files": len(source), "source_checkout": str(root), "common_git_directory": common_git,
             "build_record_sha256": package.guard(args.build), "timing": {}, "preparations": {},
             "execution_counts": {"preparation": 0, "gates": 0, "warmups": 0, "measured": 0},
             "scope": "Independent oracle recheck of retained application executions; no new native runs or full compiler matrix",
             "input_guards_passed": False}
    benchmark = SimpleNamespace(**runpy.run_path(str(root / "benchmarks/record_benchmark.py"), run_name="frozen_record_benchmark"))
    validator = benchmark.validator
    canonical = benchmark.workloads([32, 4096], 8388608)
    control = benchmark.describe(validator.case("empty-control", [], repetitions=1), 0)
    source_cases = validator.cases()
    for mode in MODES:
        record_path = getattr(args, mode)
        preparation_path = getattr(args, mode + "_preparation")
        record, prepared = package.read_json(record_path), package.read_json(preparation_path)
        records[mode] = record
        require(record["schema"] == prepared["schema"] == 1
                and record["kind"] == "record-benchmark" and prepared["kind"] == "record-preparation"
                and record["preparation"] == prepared and record["input_guards_passed"]
                and prepared["input_guards_passed"] and not record["dirty"] and not prepared["dirty"]
                and record["revision"] == prepared["revision"] == REVISION
                and prepared["thinlto"] == (mode == "thinlto"), "record/preparation identity differs")
        package.guard(preparation_path, record["preparation_record_sha256"])
        require(record["samples"] == 12 and record["warmups"] == 2 and record["batch_records"] == 8388608
                and record["engine_orders"] == list(map(list, itertools.permutations(ENGINES)))
                and record["cpu"]["affinity"] == [31]
                and record["cpu"]["model"] == "AMD EPYC-Milan Processor", "measurement protocol differs")
        python = record["python"]
        require(python["implementation"] == "cpython" and python["version_number"] == "3.14.5"
                and python["gil_enabled"] is True and python["free_threaded_build"] is False
                and python["jit_enabled"] is False and python["debug_build"] is False
                and python["pgo"]["configure_enable_optimizations"] is True
                and python["pgo"]["profile_use_flag_present"] is True
                and python["lto"]["lto_flag_present"] is True, "reported CPython configuration differs")
        require(datetime.fromisoformat(record["started_at_utc"]) < datetime.fromisoformat(record["completed_at_utc"]), "invalid timing interval")
        require(datetime.fromisoformat(prepared["completed_at_utc"]) <= datetime.fromisoformat(record["started_at_utc"]), "preparation did not precede timing")
        require(set(prepared["source_and_tool_paths"]) == set(prepared["source_and_tool_sha256"]), "source/tool key sets differ")
        for name, path_text in prepared["source_and_tool_paths"].items():
            path = Path(path_text)
            expected_hash = prepared["source_and_tool_sha256"][name]
            package.guard(path, expected_hash)
            if path.is_relative_to(root):
                relative = path.relative_to(root).as_posix()
                require(relative in source and source[relative]["sha256"] == expected_hash, "source differs from frozen Git blob")
            else:
                package.add_file("external/" + mode + "/" + name.replace(":", "_") + "/" + path.name,
                                 path, omit="external tool executable" if name in ("python", "clang", "lto_linker") else None)
        require(Path(prepared["source_and_tool_paths"]["relar_build_record"]).resolve() == args.build.resolve(), "compiler build record path differs")
        require(prepared["source_and_tool_sha256"]["compiler"] == build["sha256"]["compiler"]
                and prepared["source_and_tool_sha256"]["runtime"] == build["sha256"][mode + "_runtime"], "prepared compiler/runtime differs")
        for name in ("binary", "llvm", "validation"):
            package.guard(prepared[name], prepared[name + "_sha256"])
        directory = Path(prepared["binary"]).parent
        require(Path(prepared["llvm"]).parent == directory and Path(prepared["validation"]).parent == directory, "preparation artifacts split across directories")
        require(set(Package.tree_entries(directory)) == {"record-pipeline", "record-pipeline.ll", "validation.json"}, "preparation directory membership differs")
        package.add_file("preparation/" + mode + ".json", preparation_path)
        package.add_tree("preparation/" + mode, directory)
        rust = package.read_json(prepared["source_and_tool_paths"]["rust_build_record"])
        require(rust == prepared["rust_build_record"] and rust["input_guards_passed"]
                and rust["thinlto"] == prepared["thinlto"]
                and rust["binary_sha256"] == prepared["source_and_tool_sha256"]["rust"]
                and rust["llvm_budget"] == (1000 if prepared["thinlto"] else None), "Rust build binding differs")
        require(rust["environment"]["CARGO_PROFILE_RELEASE_OPT_LEVEL"] == "3"
                and rust["environment"]["CARGO_PROFILE_RELEASE_CODEGEN_UNITS"] == "16"
                and rust["environment"]["CARGO_PROFILE_RELEASE_LTO"] == ("thin" if mode == "thinlto" else "off")
                and "rustc 1.98.1-dev" in rust["rustc_verbose"]
                and "LLVM version: 22.1.8" in rust["rustc_verbose"]
                and "ohm-1.98.1-1" in build["toolchain"], "reported native build configuration differs")
        for name, content in rust["source_contents"].items():
            require(digest(content.encode()) == rust["sources"][name]
                    == source["benchmarks/reference/record_pipeline/" + name]["sha256"], "Rust source contents differ")
        for tool, expected_hash in rust["tool_sha256"].items():
            path = Path("/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/bin") / tool
            package.guard(path, expected_hash)
            package.add_file("excluded/rust-tools/" + mode + "/" + tool, path)
        paths = prepared["source_and_tool_paths"]
        compile_command = [paths["compiler"], "build", str(root / "examples/record_pipeline/__main__.py"),
                           "--module-root", str(root / "examples"), "-o", prepared["binary"],
                           "--runtime", paths["runtime"], "--clang", paths["clang"], "--opt-level", "3",
                           "--emit-llvm", prepared["llvm"], "--target", prepared["effective_target"]]
        if mode == "thinlto":
            compile_command += ["--lto-linker", paths["lto_linker"]]
        require(prepared["compile_command"] == compile_command, "compiler argv differs")
        require(prepared["native_elf"] == benchmark.targets.elf_target(Path(prepared["binary"]))
                == benchmark.targets.elf_target(Path(paths["rust"]))
                and prepared["effective_target"] == benchmark.targets.rust_host(rust), "native target differs")
        validation = package.read_json(prepared["validation"])
        require(validation["engines"] == list(ENGINES) and validation["cases"] == len(source_cases)
                == prepared["validation_cases"] == len(validation["results"]) == 122, "validation case set differs")
        for case, actual in zip(source_cases, validation["results"], strict=True):
            require(actual["case"] == validator.case_record(case) and set(actual["engines"]) == set(ENGINES), "validation input differs")
            expected = validator.oracle(case)
            for engine in ENGINES:
                verify_execution(actual["engines"][engine], expected)
        commands = {"relar": [prepared["binary"]], "cpython": validator.python_command(paths["python"]), "rust": [paths["rust"]]}
        timing_directory = record_path.with_suffix("")
        descriptions = [control, *canonical]
        workloads = [record["startup_control"], *record["workloads"]]
        require(len(workloads) == len(descriptions), "workload count differs")
        expected_names = {description["label"] for description in descriptions}
        require({path.name for path in timing_directory.iterdir()} == expected_names, "timing condition directory set differs")
        rows = [verify_workload(workload, description, record, validator, commands, timing_directory)
                for workload, description in zip(workloads, descriptions, strict=True)]
        package.add_file("timing/" + mode + ".json", record_path)
        package.add_tree("timing/" + mode, timing_directory)
        audit["timing"][mode] = {"path": str(record_path), "sha256": package.guard(record_path), "rows": rows}
        audit["preparations"][mode] = {"path": str(preparation_path), "sha256": package.guard(preparation_path),
                                        "binary_sha256": prepared["binary_sha256"], "validation_cases": 122}
        audit["execution_counts"]["preparation"] += 122 * 3
        audit["execution_counts"]["gates"] += len(workloads) * 3
        audit["execution_counts"]["warmups"] += len(workloads) * 3 * 2
        audit["execution_counts"]["measured"] += len(workloads) * 3 * 12
    require(datetime.fromisoformat(records["normal"]["completed_at_utc"]) <= datetime.fromisoformat(records["thinlto"]["started_at_utc"]), "link-mode intervals overlap")
    require(records["normal"]["python"] == records["thinlto"]["python"], "Python metadata differs")
    package.check()
    require(git("rev-parse", "HEAD").decode().strip() == REVISION
            and not git("status", "--porcelain").strip(), "source changed during audit")
    audit["input_guards_passed"] = True
    audit_bytes = json_bytes(audit)
    report = report_text(records, audit, prefix)
    package.add_bytes("audit.json", audit_bytes)
    package.add_bytes("REPORT.md", report)
    package.add_bytes("provenance/guarded-inputs.json", json_bytes({str(path): value for path, value in sorted(package.files.items())}))
    package.write(prefix, {"kind": "callable-benchmark-evidence", "revision": REVISION,
                          "packager_sha256": self_hash, "audit_sha256": digest(audit_bytes),
                          "source_tree": audit["source_tree"], "source_files": len(source),
                          "execution_counts": audit["execution_counts"], "input_guards_passed": True,
                          "scope": audit["scope"]})
    for mode in MODES:
        data = Path(getattr(args, mode)).read_bytes()
        require(digest(data) == audit["timing"][mode]["sha256"], "raw record changed before compression")
        with Path(str(prefix) + "-" + mode + ".json.gz").open("xb") as stream:
            with gzip.GzipFile(filename="", fileobj=stream, mode="wb", mtime=0, compresslevel=9) as compressed:
                compressed.write(data)
    for suffix, data in (("-audit.json", audit_bytes), ("-benchmarks.md", report)):
        with Path(str(prefix) + suffix).open("xb") as stream:
            stream.write(data)
    package.check()


if __name__ == "__main__":
    main()

