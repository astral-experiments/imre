"""Read-only audit of frozen inventory publication inputs; writes one local index."""

import ast
import base64
import collections
import hashlib
import itertools
import json
import math
import re
import statistics
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/dev-user/code/oss/relar')
LOCAL = ROOT / 'benchmarks/local'
COMMIT = 'edbbab93b26ccca638c7bf74336baef0d0fab4cd'
checks = 0
verified = {}


def require(condition, message):
    global checks
    checks += 1
    assert condition, message


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(Path(path).read_bytes())


def public(value):
    if isinstance(value, dict):
        return {public(k): public(v) for k, v in value.items()}
    if isinstance(value, list):
        return [public(v) for v in value]
    if not isinstance(value, str):
        return value
    return (value.replace(str(ROOT) + '/', '')
            .replace('/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/', '<ohm-toolchain>/')
            .replace('/home/dev-user/.cache/relar/', '<relar-cache>/')
            .replace('/home/dev-user/.cache/ohm/', '<ohm-cache>/')
            .replace('/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/', '<cpython-install>/')
            .replace('/home/dev-user/.local/bin/', '<local-bin>/')
            .replace('/tmp/', '<scratch>/'))


def file_record(path):
    path = Path(path)
    return {'path': public(str(path)), 'sha256': digest(path), 'bytes': path.stat().st_size}


def verify(path, expected):
    path = Path(path)
    require(digest(path) == expected, f'hash mismatch: {path}')
    verified[public(str(path))] = expected


def read(relative):
    return json.loads((LOCAL / relative).read_text())


def source_map(values, prefix=ROOT, commit=None):
    for name, expected in values.items():
        path = prefix / name
        verify(path, expected)
        if commit:
            relative = str(path.relative_to(ROOT))
            data = subprocess.check_output(['git', 'show', f'{commit}:{relative}'], cwd=ROOT)
            require(sha(data) == expected, f'committed source mismatch: {relative}')


def encoded_files(values):
    result = {}
    for name, evidence in values.items():
        data = base64.b64decode(evidence['base64'], validate=True)
        require(sha(data) == evidence['sha256'] and len(data) == evidence['bytes'], name)
        result[name] = {'sha256': sha(data), 'bytes': len(data)}
    return result


def output(result, expected_stdout, returncode=0, category=None, message=None, files=None, directories=None):
    data = expected_stdout.encode()
    require(result['returncode'] == returncode, 'status')
    require(result['stdout_sha256'] == sha(data) and result['stdout_bytes'] == len(data), 'stdout')
    if returncode == 0:
        require(result['stderr'] == '', 'successful stderr')
    else:
        last = result['stderr'].strip().splitlines()[-1]
        require(last == category or last.startswith(category + ':'), 'error category')
        if message is not None:
            require(last == category + ': ' + message, 'normalized error message')
    if files is not None:
        require(result['files'] == files and result['directories'] == directories, 'filesystem')
    require('AddressSanitizer' not in result['stderr'] and 'LeakSanitizer' not in result['stderr'], 'sanitizer diagnostic')


def inventory_validation(record):
    require((record['cases'], record['successful'], record['terminal_errors']) == (176, 127, 49), 'inventory counts')
    require(len(record['records']) == 176, 'inventory record count')
    successes = 0
    for row in record['records']:
        encoded_files(row['case']['files'])
        files = encoded_files(row['expected_files'])
        expected = row['expected']
        successes += expected['returncode'] == 0
        require(set(row['engines']) == {'cpython', 'relar', 'rust_bigint'}, 'inventory engines')
        for result in row['engines'].values():
            output(result, expected['stdout'], expected['returncode'], expected['error_category'], expected['error_message'], files, expected['directories'])
    require(successes == 127, 'inventory success total')
    device = record['device_check']
    require(set(device['engines']) == {'cpython', 'relar', 'rust_bigint'}, 'device engines')
    for result in device['engines'].values():
        output(result, '', 1, 'OSError', 'report: cannot write')
        require(result['files'] == device['engines']['cpython']['files'] and result['directories'] == [], 'device inputs retained')
    return {'filesystem_cases': 176, 'successful_cases': 127, 'terminal_error_cases': 49,
            'engines': record['engines'], 'filesystem_executions': 528, 'device_cases': 1, 'device_executions': 3}


def control_validation(record):
    require(record['oracle_cases'] == len(record['checks']) == 155, 'graph cases')
    require(record['parser_cases'] == len(record['parser_checks']) == 17, 'parser cases')
    for row in record['checks']:
        require(set(row['results']) == {'cpython', 'baseline', 'relar'}, 'control engines')
        for result in row['results'].values():
            output(result, row['expected_stdout'])
    for row in record['parser_checks']:
        for result in row['results'].values():
            output(result, row['expected_stdout'], row['expected_returncode'], row['expected_error_category'])
    return {'graph_cases': 155, 'parser_cases': 17, 'engines': ['cpython', 'baseline', 'relar'], 'executions': 516,
            'note': 'No checked-i64 engine participates; shared-validator i64 exclusion metadata does not exclude any of these engines.'}


build = read('comprehension-tools-final/build-record.json')
build_path = LOCAL / 'comprehension-tools-final/build-record.json'
source_map(build['source_sha256'], commit=build['git_head'])
source_map(build['source_sha256'], commit=COMMIT)
for name, data in build['source_contents'].items():
    require(sha(data.encode()) == build['source_sha256'][name], 'frozen source contents')
for name, expected in build['sha256'].items():
    verify(ROOT / name, expected)
for mode, record in build['commands'].items():
    require(record['returncode'] == 0, 'tool build returncode')
    verify(LOCAL / 'comprehension-tools-final' / (mode + '.log'), record['log_sha256'])

session = read('inventory-final-session.json')
require(session['source_commit'] == COMMIT and session['git_status_before'] == session['git_status_after'] == '', 'clean timing source')
require(session['bytecode_before'] == session['bytecode_after'], 'cache stability')
cache_records = session['bytecode_before']['files']
require(len(cache_records) == 12, 'cache file count')
for path, row in cache_records.items():
    verify(Path(path), row['source_sha256'])
    verify(Path(row['cache_path']), row['cache_sha256'])
    data = Path(row['cache_path']).read_bytes()
    require(data[:4].hex() == session['bytecode_before']['magic'], 'cache magic')
    require(row['valid_header'] and int.from_bytes(data[4:8], 'little') == row['flags'] == 0, 'timestamp cache flags')
    require(int.from_bytes(data[8:12], 'little') == (int(Path(path).stat().st_mtime) & 0xffffffff), 'cache timestamp')
    require(int.from_bytes(data[12:16], 'little') == Path(path).stat().st_size, 'cache source length')

freeze = read('inventory-reference-final-freeze.json')
require(freeze['source_commit'] == COMMIT and freeze['tree_clean'], 'reference freeze')
references = {}
comparisons = {}
total_runs = 0
for mode in ('normal', 'lto'):
    folder = LOCAL / f'inventory-reference-final-{mode}'
    reference = read(f'inventory-reference-final-{mode}/build-record.json')
    verify(folder / 'build-record.json', freeze['references'][mode]['build_record_sha256'])
    verify(folder / 'inventory-bigint', reference['binaries']['bigint']['sha256'])
    source_map(reference['sources'], ROOT / 'benchmarks/reference/inventory_reconciliation', COMMIT)
    verify(ROOT / 'benchmarks/reference/inventory_reconciliation/build.py', reference['build_script_sha256'])
    require(sha(reference['build_script'].encode()) == reference['build_script_sha256'], 'reference helper snapshot')
    for name, data in reference['source_contents'].items():
        require(sha(data.encode()) == reference['sources'][name], 'reference source snapshot')
    for name, expected in reference['tool_sha256'].items():
        verify(Path('/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/bin') / name, expected)
    verify('/tmp/relar-cargo.sh', reference['cargo_wrapper']['sha256'])
    require(sha(reference['cargo_wrapper']['source'].encode()) == reference['cargo_wrapper']['sha256'], 'wrapper contents')
    require(reference['environment'].get('CARGO_PROFILE_RELEASE_LTO') == (None if mode == 'normal' else 'thin'), 'reference LTO mode')
    require(reference['llvm_budget'] == (None if mode == 'normal' else 1000), 'reference budget')
    require(reference['environment']['RUSTFLAGS'] == ('' if mode == 'normal' else '-Cllvm-args=-import-instr-limit=1000 -Cllvm-args=-inline-threshold=1000'), 'reference LLVM flags')
    references[mode] = {'build_record': file_record(folder / 'build-record.json'), 'binary': file_record(folder / 'inventory-bigint'),
                        'rustc_verbose': reference['rustc_verbose'], 'environment': reference['environment'],
                        'build_command': reference['binaries']['bigint']['command']}

    path = LOCAL / f'inventory-{mode}-final.json'
    data = read(path.name)
    verify(path, session['runs'][mode]['record_sha256'])
    verify(LOCAL / f'inventory-{mode}-final.log', session['runs'][mode]['log_sha256'])
    require(session['runs'][mode]['returncode'] == 0, 'benchmark returncode')
    require(data['git'] == {'revision': COMMIT, 'dirty': False}, 'comparison git')
    source_map(data['sources'], ROOT / 'examples', COMMIT)
    require(data['rust_sources'] == reference['sources'], 'selected Rust sources')
    source_paths = {
        'compiler': LOCAL / 'comprehension-tools-final/relar',
        'runtime': LOCAL / ('comprehension-tools-final/librelar_runtime_lto.a' if mode == 'lto' else 'comprehension-tools-final/librelar_runtime.a'),
        'relar_build_record': build_path, 'clang': Path('/usr/lib/llvm-18/bin/clang'),
        'python': Path(data['method']['commands']['inventory']['cpython'][0]),
        'rust_bigint': folder / 'inventory-bigint', 'rust_record': folder / 'build-record.json',
        'rust_build_script': ROOT / 'benchmarks/reference/inventory_reconciliation/build.py',
        'tracked_rust_build_script': ROOT / 'benchmarks/reference/inventory_reconciliation/build.py',
        'baseline': LOCAL / f'layout-{mode}-final/incremental_planner',
        'baseline_record': LOCAL / f'layout-{mode}-final.json',
        'inventory_binary': LOCAL / f'inventory-{mode}-final/inventory_reconciliation',
        'inventory_ir': LOCAL / f'inventory-{mode}-final/inventory_reconciliation.ll',
        'control_binary': LOCAL / f'inventory-{mode}-final/incremental_planner',
        'control_ir': LOCAL / f'inventory-{mode}-final/incremental_planner.ll',
        'guard_helpers': ROOT / 'benchmarks/reference/dependency_planner/check_boundaries.py',
    }
    if mode == 'lto':
        source_paths['lto_linker'] = LOCAL / 'batch-linker/ld.lld'
    for name, expected in data['sha256'].items():
        if name.startswith('harness:'):
            selected = ROOT / 'benchmarks' / name.removeprefix('harness:')
        elif name.startswith('relar_source:'):
            selected = ROOT / name.removeprefix('relar_source:')
        else:
            selected = source_paths[name]
        verify(selected, expected)
    old_ir = LOCAL / f'layout-{mode}-final/incremental_planner.ll'
    require(old_ir.read_bytes() == source_paths['control_ir'].read_bytes(), 'identical control IR')
    old = read(f'layout-{mode}-final.json')
    require(old['sha256']['incremental_ir'] == digest(old_ir), 'old recorded IR')
    require(old['sha256']['runtime'] == data['sha256']['runtime'], 'unchanged control runtime archive')
    require(data['options']['samples'] == 30 and data['options']['warmups'] == 2 and not data['options']['validation_only'], 'sample options')
    require(data['options']['target'] == data['options']['requested_target'] == 'x86_64-unknown-linux-gnu', 'target')
    require(data['options']['lto'] == ('thin' if mode == 'lto' else None), 'Relar LTO')
    require(data['options']['llvm_budget'] == (1000 if mode == 'lto' else None), 'Relar budget')
    require(data['host']['cpu']['affinity'] == [0], 'affinity')
    for context in data['execution'].values():
        require(context['tracer_pid'] == 0, 'ptrace')
    inv_validation = inventory_validation(data['validation']['inventory'])
    ctl_validation = control_validation(data['validation']['control'])
    rows = {}
    for group, workloads in data['workloads'].items():
        engines = ['cpython', 'baseline', 'relar'] if group == 'control' else ['cpython', 'relar', 'rust_bigint']
        permutations = list(itertools.permutations(engines))
        require(data['method']['order_cycles'][group] == [list(p) for p in permutations], 'order cycle')
        require(len(workloads) == (5 if group == 'control' else 6), 'workload count')
        rows[group] = []
        for work in workloads:
            expected = work['expected_stdout']
            files = None
            if group == 'inventory':
                initial = encoded_files(work['case']['files'])
                changed = encoded_files(work['expected_changed_files'])
                files = work['expected_file_inventory']
                require(files == {**initial, **changed}, 'inventory expected bytes')
                for result in work['gates'].values():
                    output(result, expected, files=files, directories=work['case']['directories'])
            else:
                require(sha(work['input'].encode()) == work['input_sha256'], 'control input')
                require(sha(expected.encode()) == work['expected_stdout_sha256'] and len(expected.encode()) == work['expected_stdout_bytes'], 'control expected output')
            for phase, count in [('warmups', 2), ('samples', 30)]:
                require(len(work[phase]) == count, 'raw round count')
                for i, row in enumerate(work[phase]):
                    require(row['index'] == i and row['order'] == list(permutations[i % 6]), 'raw order')
                    for engine in engines:
                        output(row[engine], expected, files=files, directories=[] if files is not None else None)
                        require(row[engine]['elapsed_ns'] > 0, 'elapsed time')
                        total_runs += 1
            require(collections.Counter(tuple(r['order']) for r in work['samples']) == dict.fromkeys(permutations, 5), 'six orders five times')
            for engine in engines:
                values = [r[engine]['elapsed_ns'] / 1e9 for r in work['samples']]
                require(math.isclose(statistics.median(values), work['summary'][engine]['median_seconds'], rel_tol=1e-14), 'median')
                require(min(values) == work['summary'][engine]['min_seconds'] and max(values) == work['summary'][engine]['max_seconds'], 'spread')
            rows[group].append({'label': work['label'], 'medians_seconds': {engine: work['summary'][engine]['median_seconds'] for engine in engines}})
    comparisons[mode] = {'record': file_record(path), 'log': file_record(LOCAL / f'inventory-{mode}-final.log'),
                         'command': session['runs'][mode]['command'], 'options': data['options'],
                         'source_commit': data['git']['revision'], 'runtime_sha256': data['sha256']['runtime'],
                         'control_ir': {'sha256': digest(old_ir), 'byte_identical_to_layout_baseline': True,
                                        'executable_identity_claimed': False},
                         'inventory_validation': inv_validation, 'control_validation': ctl_validation,
                         'measured_executions': 990, 'warmup_executions': 66, 'inventory_gate_executions': 18,
                         'workloads': rows, 'tools': data['tools'], 'host': data['host']}

validation_dir = LOCAL / 'comprehension-validation-final'
new_suite = {}
for mode, checks_total, native in [('normal', 65, 26), ('thinlto', 52, 13), ('asan', 52, 13)]:
    record = read(f'comprehension-validation-final/{mode}-validation.json')
    require(record['returncode'] == 0 and record['source_hashes_unchanged'], 'comprehension suite status')
    verify(validation_dir / f'{mode}.log', record['log_sha256'])
    require(f'Passed {checks_total} comprehension checks (39 rejections;' in (validation_dir / f'{mode}.log').read_text(), 'comprehension count log')
    source_map(record['sources'], commit=COMMIT)
    require(record['build_record_sha256'] == digest(build_path), 'comprehension build identity')
    verify(Path(record['command'][record['command'].index('--compiler') + 1]), record['compiler_sha256'])
    verify(Path(record['command'][record['command'].index('--runtime') + 1]), record['runtime_sha256'])
    new_suite[mode] = {'total_checks': checks_total, 'compiler_rejection_checks': 39, 'native_runtime_executions': native,
                       'record': file_record(validation_dir / f'{mode}-validation.json'), 'command': record['command'],
                       'log': file_record(validation_dir / f'{mode}.log')}

old_suite = {}
rejections = {'classes': 54, 'exceptions': 16, 'imports': 43, 'io': 0, 'differential': 32, 'files': 30, 'containers': 142}
for mode, expected_total in [('normal', 641), ('lto', 479), ('asan', 479)]:
    record = read(f'comprehension-validation-final/regression-{mode}/results.json')
    require(record['passed'], 'regression status')
    source_map(record['test_sources'], commit=COMMIT)
    for tool in ['compiler', 'runtime']:
        verify(Path(record[tool]['path']), record[tool]['sha256'])
    verify(Path(record['runner']['path']), record['runner']['sha256'])
    summaries = {}
    for name, row in record['results'].items():
        require(row['returncode'] == 0, 'regression exit')
        for stream in ['stdout', 'stderr']:
            verify(Path(row[stream]['path']), row[stream]['sha256'])
        text = Path(row['stdout']['path']).read_text()
        total = int(re.search(r'(?:Passed )?(\d+) (?:import |class |exception |I/O |file/argument |container )?checks', text)[1])
        summaries[name] = {'checks': total, 'compiler_or_cli_rejection_checks': rejections[name],
                           'native_runtime_executions': total - rejections[name],
                           'stdout': file_record(row['stdout']['path']), 'stderr': file_record(row['stderr']['path'])}
    require(sum(s['checks'] for s in summaries.values()) == expected_total, 'regression aggregate')
    old_suite[mode] = {'total_checks': expected_total, 'compiler_or_cli_rejection_checks': sum(rejections.values()),
                       'native_runtime_executions': expected_total - sum(rejections.values()),
                       'record': file_record(validation_dir / f'regression-{mode}/results.json'), 'suites': summaries}

tool_checks = read('comprehension-validation-final/tool-checks/results.json')
for name, row in tool_checks['checks'].items():
    require(row['returncode'] == 0, 'tool check status')
    verify(validation_dir / 'tool-checks' / f'{name}.log', row['log_sha256'])
unit_log = (validation_dir / 'tool-checks/unit.log').read_text()
unit_counts = [int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', unit_log)]
require(unit_counts == [25, 0, 36, 0, 0], 'unit counts')
require((validation_dir / 'tool-checks/lto-cli.log').read_text().strip() == 'Passed 10 ThinLTO CLI checks', 'LTO CLI count')

asan_build = read('inventory-asan-final/build-record.json')
require(asan_build['git_head'] == COMMIT and asan_build['git_status'] == '', 'ASan clean source')
require(asan_build['build_returncode'] == asan_build['validation_returncode'] == 0, 'ASan status')
require(asan_build['outside_ptrace'] and asan_build['source_hashes_unchanged'], 'ASan provenance')
require(asan_build['compiler_build_record_sha256'] == digest(build_path), 'ASan tool record')
source_map(asan_build['sources'], commit=COMMIT)
for name, key in [('inventory_reconciliation', 'binary_sha256'), ('inventory_reconciliation.ll', 'llvm_ir_sha256'),
                  ('build.log', 'build_log_sha256'), ('validation.log', 'validation_log_sha256'),
                  ('validation.json', 'validation_sha256'), ('run.py', 'driver_sha256')]:
    verify(LOCAL / 'inventory-asan-final' / name, asan_build[key])
asan_summary = inventory_validation(read('inventory-asan-final/validation.json'))

for relative in ['validation.json', 'cpython-validation.json', 'ruff-validation.json', 'normal-command.json', 'thinlto-command.json', 'asan-command.json']:
    require((validation_dir / relative).exists(), relative)
cpython = read('comprehension-validation-final/cpython-validation.json')
require(len(cpython['results']) == 26, 'independent CPython reference count')
for path, row in cpython['pythons'].items():
    verify(Path(path), row['sha256'])
for row in read('comprehension-validation-final/ruff-validation.json'):
    require(row['returncode'] == 0, 'Ruff status')
    verify(validation_dir / (row['name'] + '.log'), row['log_sha256'])

require(total_runs == 2112, 'all timing and warmup executions')
independent_audit = {}
for suffix, expected in {
    'py': '6fc15ddaa38e6fd12dbace4e434c264cb43a2447d57ad22bc11fcc648df03d21',
    'json': 'b07fc9f853561baac7720f109b974d5bfe258ae221d27d6aed278b74bc42909b',
    'md': 'c40de6352737521318faed93e051a8f86a791009d44a7714094c5c403e9b27b2',
}.items():
    path = LOCAL / ('inventory-publication-audit.' + suffix)
    verify(path, expected)
    independent_audit[suffix] = file_record(path)
index = {
    'schema': 'relar-inventory-publication-validation-v1',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'audit': {'script': file_record(Path(__file__)), 'assertions_passed': checks,
              'scope': 'Read-only record, source, artifact, log, raw-output, cache, count, and median verification; no builds, native executions, or timings rerun.',
              'findings': []},
    'source': {'measurement_commit': COMMIT, 'implementation_commit': build['git_head'],
               'compiled_sources_equal_both_commits': True,
               'tool_build_git_status': build['git_status'],
               'tool_build_scope': 'Compiler/runtime source bytes match the implementation commit; then-untracked example/harness files made the whole checkout non-clean at tool-build time. Measurement and ASan application runs used the clean example commit.',
               'compiler_build_record': file_record(build_path), 'compiled_source_sha256': build['source_sha256']},
    'references': references,
    'reference_freeze': file_record(LOCAL / 'inventory-reference-final-freeze.json'),
    'independent_numeric_audit': independent_audit,
    'comparisons': comparisons,
    'validation': {
        'new_comprehension_suite': new_suite, 'seven_existing_suites': old_suite,
        'count_scope': 'Harness checks count one native program execution or one compiler/CLI rejection; CPython reference executions and successful compilation subprocesses are additional and are not included in these totals.',
        'suite_totals_all_modes': {'checks': 1768, 'compiler_or_cli_rejection_checks': 1068, 'native_runtime_executions': 700},
        'thinlto_cli': {'checks': 10, 'compiler_cli_rejection_checks': 9, 'native_runtime_executions': 1},
        'combined_suite_and_cli_checks': 1778,
        'unit_tests': {'compiler': 25, 'runtime': 36, 'total': 61, 'doc_tests': 0},
        'tool_checks': {'record': file_record(validation_dir / 'tool-checks/results.json'), 'checks': tool_checks['checks']},
        'separate_cpython_reference_runs': {'count': 26, 'cases_per_version': 13, 'versions': ['3.12.13', '3.14.5'], 'record': file_record(validation_dir / 'cpython-validation.json')},
        'asan_application': {**asan_summary, 'build_record': file_record(LOCAL / 'inventory-asan-final/build-record.json'),
                             'validation_record': file_record(LOCAL / 'inventory-asan-final/validation.json'),
                             'environment': asan_build['validation_environment'], 'build_command': asan_build['build_command'],
                             'validation_command': asan_build['validation_command'],
                             'limits': asan_build['limits']},
    },
    'cache_and_process_scope': {
        'session_record': file_record(LOCAL / 'inventory-final-session.json'),
        'valid_unchanged_cpython_package_caches': len(cache_records),
        'cache_kind': 'Twelve existing timestamp-based CPython 3.14 caches have valid headers and unchanged source/cache hashes before and after both runs.',
        'fresh_process': 'Each measured engine run starts a fresh subprocess; filesystem fixture cwd is fresh per inventory run.',
        'not_isolated': 'CPU affinity is [0], but the shared devbox is not dedicated or kernel-isolated. No cache flush, cold-page-cache guarantee, fsync, fixed hash seed, or identical allocator/representation is claimed.',
        'timing': 'Whole subprocess wall time includes startup/imports, parsing, eager collections, fulfillment, complete report I/O, flush/close, and exit. Fixture setup, oracle checks, full-output verification/hashing, compilation, warmups, and cleanup are outside retained samples.',
        'order': 'Thirty retained rounds use all six permutations five times. Within-round positions and directed adjacent pairs balance; cross-round predecessors and the two warmups do not balance.',
        'samples_filtered': 0,
    },
    'contract_and_fairness': [
        'Zero-based original batch/row positions; positive requests only; duplicate stock last value wins while first insertion controls report order; requested order comes from a dict, never set traversal.',
        'Unknown SKUs have zero availability and never create remaining-stock rows. The requested set selects the untouched-stock section.',
        'Both inputs are read and closed before report open. Stock parse precedes opening orders. Output may truncate or partially write; it is not atomic.',
        'Malformed input and device output failures are validated but are not timed workloads. The boundary workload exercises successful arbitrary-precision quantities.',
        'All three inventory engines implement the same eager algorithm and arbitrary-precision quantities. Rust uses borrowed SKU/request references, native collections, and direct formatting, so allocation and ownership representation differ.',
        'Supported common input domain uses ASCII decimal digits with permitted signs/underscores, valid UTF-8 argv, and the documented normalized errors. CPython tracebacks/context/chaining are not matched.',
        'Ordinary and matched ThinLTO comparisons are separate; Rust LLVM 22.1.8 differs from Clang 18.1.3 generating Relar IR. ThinLTO uses Rust LLD 22.1.8 and explicit 1000 import/inline budgets on both native implementations.',
        'The old-source control has byte-identical emitted IR and runtime archive bytes, but executable hashes differ. Small timing differences do not establish a comprehension overhead regression or gain.',
    ],
    'verified_file_sha256': verified,
}
destination = LOCAL / 'inventory-publication-validation.json'
destination.write_text(json.dumps(public(index), indent=2) + '\n')
print(json.dumps({'output': str(destination), 'sha256': digest(destination), 'bytes': destination.stat().st_size,
                  'assertions': checks, 'verified_files': len(verified), 'timed_and_warmup_runs': total_runs}))
