| Mode | Inventory workload | CPython ms | Relar ms | Rust BigInt ms | CPython / Relar | Relar / Rust |
|---|---|---:|---:|---:|---:|---:|
| normal | empty | 26.994 | 2.190 | 2.257 | 12.326x | 0.970x |
| normal | boundary-128 | 27.977 | 3.030 | 2.704 | 9.233x | 1.121x |
| normal | dense-2048 | 33.074 | 8.153 | 5.978 | 4.057x | 1.364x |
| normal | sparse-2048 | 36.561 | 12.648 | 8.352 | 2.891x | 1.514x |
| normal | dense-16384 | 72.492 | 45.991 | 23.032 | 1.576x | 1.997x |
| normal | sparse-16384 | 104.386 | 80.636 | 42.372 | 1.295x | 1.903x |
| lto | empty | 26.714 | 2.120 | 2.138 | 12.599x | 0.992x |
| lto | boundary-128 | 29.368 | 3.092 | 2.744 | 9.498x | 1.127x |
| lto | dense-2048 | 33.848 | 7.228 | 5.662 | 4.683x | 1.277x |
| lto | sparse-2048 | 36.062 | 10.009 | 7.632 | 3.603x | 1.312x |
| lto | dense-16384 | 74.340 | 33.171 | 21.274 | 2.241x | 1.559x |
| lto | sparse-16384 | 106.256 | 59.283 | 37.834 | 1.792x | 1.567x |

| Mode | Unchanged control | Baseline ms | Current ms | Current time change |
|---|---|---:|---:|---:|
| normal | layered-16384-sparse | 50.324 | 50.244 | -0.160% |
| normal | layered-16384-all | 74.861 | 75.066 | +0.273% |
| normal | wide-16384-sparse | 26.281 | 26.482 | +0.764% |
| normal | wide-16384-all | 44.518 | 44.689 | +0.384% |
| normal | boundary-128-all | 3.660 | 3.654 | -0.141% |
| lto | layered-16384-sparse | 42.294 | 42.305 | +0.026% |
| lto | layered-16384-all | 63.851 | 63.570 | -0.441% |
| lto | wide-16384-sparse | 21.509 | 21.472 | -0.172% |
| lto | wide-16384-all | 35.956 | 35.638 | -0.885% |
| lto | boundary-128-all | 3.506 | 3.483 | -0.633% |
