import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('/home/dev-user/code/oss/imre')
destination = root / 'benchmarks/results'
prefix = '2026-10-18-comprehensions'
revision = 'edbbab93b26ccca638c7bf74336baef0d0fab4cd'
digest = lambda data: hashlib.sha256(data).hexdigest()
payloads = {}
entries = {}

def add(name, data, source):
    assert name not in payloads, name
    assert not name.startswith('/') and '..' not in Path(name).parts
    payloads[name] = data
    entries[name] = {'sha256': digest(data), 'bytes': len(data), 'source': source}

def local(source, name):
    path = Path(source)
    if not path.is_absolute():
        path = root / path
    add(name, path.read_bytes(), str(path))

for name in ('audit', 'validation'):
    shutil.copyfile(root / f'benchmarks/local/inventory-publication-{name}.json', destination / f'{prefix}-{name}.json')

tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', revision], cwd=root, text=True).splitlines()
roots = ('crates/', 'tests/', 'examples/inventory_reconciliation/', 'examples/incremental_planner/', 'benchmarks/reference/inventory_reconciliation/', '.github/workflows/')
top = {'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'docs/design.md', 'docs/subset.md'}
selected = [name for name in tracked if name.startswith(roots) or name in top or (name.startswith('benchmarks/') and name.count('/') == 1 and name.endswith('.py'))]
snapshot = subprocess.check_output(['git', 'archive', '--format=tar', revision, '--', *selected], cwd=root)
with tarfile.open(fileobj=io.BytesIO(snapshot), mode='r:') as source:
    for member in source.getmembers():
        if member.isfile():
            add('source/' + member.name, source.extractfile(member).read(), f'git:{revision}:{member.name}')

for path in sorted((root / 'benchmarks/local/comprehension-validation-final').rglob('*')):
    if path.is_file():
        assert path.suffix in {'.json', '.py', '.log', '.stdout', '.stderr'}, path
        local(path, 'validation/comprehensions/' + str(path.relative_to(root / 'benchmarks/local/comprehension-validation-final')))
for name in ('build-record.json', 'ordinary.log', 'thinlto.log', 'asan.log'):
    local('benchmarks/local/comprehension-tools-final/' + name, 'build/imre/' + name)
for mode in ('normal', 'lto'):
    local(f'benchmarks/local/inventory-reference-final-{mode}/build-record.json', f'build/rust-{mode}/build-record.json')
    local(f'benchmarks/local/inventory-{mode}-final.log', f'timing/{mode}.log')
    for program in ('inventory_reconciliation', 'incremental_planner'):
        local(f'benchmarks/local/inventory-{mode}-final/{program}.ll', f'generated/{mode}/{program}.ll')
    local(f'benchmarks/local/layout-{mode}-final/incremental_planner.ll', f'generated/preserved-{mode}/incremental_planner.ll')
local('benchmarks/local/inventory-reference-final-freeze.json', 'build/rust-reference-freeze.json')
for name in ('build-record.json', 'run.py', 'build.log', 'validation.log', 'validation.json', 'inventory_reconciliation.ll'):
    local('benchmarks/local/inventory-asan-final/' + name, 'validation/inventory-asan/' + name)
for source, name in (
    ('/tmp/imre-comprehensions-build-final.py', 'commands/build-tools.py'),
    ('/tmp/imre-comprehension-validation-final.py', 'commands/regression-checks.py'),
    ('/tmp/imre-comprehension-tool-checks.py', 'commands/tool-checks.py'),
    ('/tmp/imre-cargo.sh', 'commands/cargo.sh'),
    ('/tmp/imre-inventory-final-bench.py', 'commands/timing.py'),
    ('/tmp/imre-audit-inventory-publication.py', 'audit/validation-index.py'),
    ('benchmarks/local/inventory-publication-audit.py', 'audit/samples.py'),
    ('benchmarks/local/inventory-publication-audit.json', 'audit/samples.json'),
    ('benchmarks/local/inventory-publication-audit.md', 'audit/tables.md'),
    ('benchmarks/local/inventory-publication-validation.json', 'audit/validation-index.json'),
    ('benchmarks/local/inventory-final-session.json', 'timing/session.json'),
    (__file__, 'commands/package-evidence.py'),
):
    local(source, name)

buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for name, data in sorted(payloads.items()):
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = 0o644
        member.mtime = member.uid = member.gid = 0
        member.uname = member.gname = ''
        archive.addfile(member, io.BytesIO(data))
archive_path = destination / f'{prefix}-evidence.tar.gz'
archive_path.write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
manifest = {
    'schema_version': 1,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_snapshot_commit': revision,
    'source_snapshot_file_count': len(selected),
    'archive': {'file': archive_path.name, 'sha256': digest(archive_path.read_bytes()), 'bytes': archive_path.stat().st_size, 'member_count': len(entries)},
    'members': dict(sorted(entries.items())),
    'companion_files': {},
    'external_control_records': {
        f'2026-10-18-concrete-layouts-{mode}.json.gz': {
            'decompressed_sha256': digest((root / f'benchmarks/local/layout-{mode}-final.json').read_bytes()),
            'role': 'Original preserved control provenance; already published in the preceding stack layer.'
        } for mode in ('normal', 'lto')
    },
    'scope': [
        'Archive source files come from the committed measured revision, not the later documentation checkout.',
        'Native binaries, runtime archives, interpreter binaries, and toolchains are not included. Their frozen paths and SHA256 identities remain in the original records and audits.',
        'The complete local audit verifies those original artifacts and needs their recorded local paths; the published raw data independently supports recomputing statistics and checking retained hashes.',
        'All included timestamps/owners are normalized; gzip mtime is zero. Raw timing JSON is published separately without byte changes.',
    ],
}
for path in sorted(destination.glob(prefix + '*')):
    if path.name in {archive_path.name, f'{prefix}-evidence-manifest.json'}:
        continue
    data = path.read_bytes()
    info = {'sha256': digest(data), 'bytes': len(data)}
    if path.name.endswith('.json.gz'):
        info['decompressed_sha256'] = digest(gzip.decompress(data))
    manifest['companion_files'][path.name] = info
manifest_path = destination / f'{prefix}-evidence-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(archive_path, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(entries)
    for member in archive:
        assert digest(archive.extractfile(member).read()) == entries[member.name]['sha256']
print(json.dumps({'archive': manifest['archive'], 'source_files': len(selected), 'companions': len(manifest['companion_files']), 'manifest_sha256': digest(manifest_path.read_bytes())}, indent=2))
