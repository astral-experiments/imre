import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/home/dev-user/code/oss/imre')
python = '/home/dev-user/code/oss/penguin-uv-benchmark/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
record_path = root / 'benchmarks/local/inventory-final-session.json'
cache_probe = r'''
import hashlib, importlib.util, json, pathlib, struct, sys
records = {}
for package in sys.argv[1:]:
    for source in sorted(pathlib.Path(package).rglob('*.py')):
        cached = pathlib.Path(importlib.util.cache_from_source(str(source)))
        data = cached.read_bytes()
        content = source.read_bytes()
        assert data[:4] == importlib.util.MAGIC_NUMBER, source
        flags = int.from_bytes(data[4:8], 'little')
        if flags & 1:
            assert data[8:16] == importlib.util.source_hash(content), source
        else:
            timestamp, size = struct.unpack('<II', data[8:16])
            assert timestamp == (int(source.stat().st_mtime) & 0xffffffff), source
            assert size == (len(content) & 0xffffffff), source
        records[str(source)] = {'source_sha256': hashlib.sha256(content).hexdigest(), 'cache_path': str(cached), 'cache_sha256': hashlib.sha256(data).hexdigest(), 'cache_bytes': len(data), 'flags': flags, 'source_mtime_ns': source.stat().st_mtime_ns, 'valid_header': True}
print(json.dumps({'python': sys.version, 'cache_tag': sys.implementation.cache_tag, 'magic': importlib.util.MAGIC_NUMBER.hex(), 'pycache_prefix': sys.pycache_prefix, 'dont_write_bytecode': sys.dont_write_bytecode, 'files': records}))
'''

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, text=True).strip()

def caches():
    command = [python, '-I', '-c', cache_probe, str(root / 'examples/inventory_reconciliation'), str(root / 'examples/incremental_planner')]
    return json.loads(subprocess.check_output(command, cwd=root, text=True))

record = {'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_commit': git('rev-parse', 'HEAD'), 'git_status_before': git('status', '--porcelain'), 'runner_source': Path(__file__).read_text(), 'runs': {}, 'bytecode_before': caches()}
assert not record['git_status_before'], 'Measured source checkout must be clean'
assert record['source_commit'] == 'edbbab93b26ccca638c7bf74336baef0d0fab4cd'

def save():
    record_path.write_text(json.dumps(record, indent=2) + '\n')

save()
for mode in ('normal', 'lto'):
    command = ['python3', 'benchmarks/inventory_benchmark.py',
        '--compiler', 'benchmarks/local/comprehension-tools-final/imre',
        '--runtime', 'benchmarks/local/comprehension-tools-final/' + ('libimre_runtime_lto.a' if mode == 'lto' else 'libimre_runtime.a'),
        '--imre-build-record', 'benchmarks/local/comprehension-tools-final/build-record.json',
        '--rust-bigint', f'benchmarks/local/inventory-reference-final-{mode}/inventory-bigint',
        '--rust-build-record', f'benchmarks/local/inventory-reference-final-{mode}/build-record.json',
        '--baseline', f'benchmarks/local/layout-{mode}-final/incremental_planner',
        '--baseline-record', f'benchmarks/local/layout-{mode}-final.json',
        '--python', python, '--clang', 'clang-18', '--target', 'x86_64-unknown-linux-gnu',
        '--samples', '30', '--warmups', '2', '--cpu', '0',
        '--artifact-dir', f'benchmarks/local/inventory-{mode}-final',
        '--output', f'benchmarks/local/inventory-{mode}-final.json']
    if mode == 'lto':
        command += ['--lto-linker', str(root / 'benchmarks/local/batch-linker/ld.lld')]
    record['runs'][mode] = {'command': command, 'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    save()
    print('Starting ' + mode + ' inventory and unchanged-control measurements', flush=True)
    result = subprocess.run(command, cwd=root, capture_output=True, text=True)
    output = result.stdout + result.stderr
    log = root / f'benchmarks/local/inventory-{mode}-final.log'
    log.write_text(output)
    print(output, end='', flush=True)
    record['runs'][mode].update(returncode=result.returncode, completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    save()
    result.check_returncode()
    result_path = root / f'benchmarks/local/inventory-{mode}-final.json'
    record['runs'][mode]['record_sha256'] = hashlib.sha256(result_path.read_bytes()).hexdigest()
    assert caches() == record['bytecode_before'], 'Python package caches changed during measurement'
    assert git('rev-parse', 'HEAD') == record['source_commit']
    assert not git('status', '--porcelain')
    save()
record['bytecode_after'] = caches()
record['git_status_after'] = git('status', '--porcelain')
record['completed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print('Both modes complete; source, bytecode caches, and build identities preserved', flush=True)
