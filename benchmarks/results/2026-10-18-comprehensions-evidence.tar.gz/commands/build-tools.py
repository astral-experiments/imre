import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path('/home/dev-user/code/oss/relar')
out=root/'benchmarks/local/comprehension-tools-final'
out.mkdir(parents=True,exist_ok=True)
hash_bytes=lambda b:hashlib.sha256(b).hexdigest()
paths=[root/'Cargo.toml',root/'Cargo.lock']+sorted((root/'crates').rglob('Cargo.toml'))+sorted((root/'crates').rglob('*.rs'))
sources={str(p.relative_to(root)):p.read_text() for p in paths}
record={'stage':'eager_comprehensions','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'git_status':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'rustc_verbose':subprocess.check_output(['rustc','+ohm','-vV'],text=True),'cargo_wrapper':Path('/tmp/relar-cargo.sh').read_text(),'source_sha256':{k:hash_bytes(v.encode()) for k,v in sources.items()},'source_contents':sources,'build_environment':{},'commands':{},'sha256':{},'build_script':Path(__file__).read_text()}
record['compiled_sources_match_commit']=all(subprocess.check_output(['git','show',record['git_head']+':'+name],cwd=root).decode()==contents for name,contents in sources.items())
assert record['compiled_sources_match_commit'], 'Compile sources differ from committed HEAD'
env=os.environ.copy()
for key in list(env):
 if key in {'RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS'} or key.startswith('CARGO_PROFILE_RELEASE_'):del env[key]
record['build_environment']={key:env.get(key) for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_LTO','CARGO_PROFILE_RELEASE_OPT_LEVEL','CARGO_PROFILE_RELEASE_CODEGEN_UNITS')}
base=['sh','/tmp/relar-cargo.sh']
normal_dir=Path('/home/dev-user/.cache/relar/target')
lto_dir=Path('/home/dev-user/.cache/relar/lto-target')
asan_dir=Path('/home/dev-user/.cache/relar/asan-target')
steps=[('ordinary',base+['build','--workspace','--release','--locked'],env,[(normal_dir/'release/relar','relar'),(normal_dir/'release/librelar_runtime.a','librelar_runtime.a')]),('thinlto',base+['build','-p','relar-runtime','--release','--locked','--target-dir',str(lto_dir)],dict(env,RUSTFLAGS='-Clinker-plugin-lto'),[(lto_dir/'release/librelar_runtime.a','librelar_runtime_lto.a')]),('asan',base+['build','-p','relar-runtime','--release','--locked','--target','x86_64-unknown-linux-gnu','--target-dir',str(asan_dir)],dict(env,RUSTC_BOOTSTRAP='1',RUSTFLAGS='-Zsanitizer=address -Cforce-frame-pointers=yes'),[(asan_dir/'x86_64-unknown-linux-gnu/release/librelar_runtime.a','librelar_runtime_asan.a')])]
def save():
 (out/'build-record.json').write_text(json.dumps(record,indent=2)+'\n')
for name,command,environment,artifacts in steps:
 for p in paths:
  if p.suffix=='.rs' and (name=='ordinary' or 'relar-runtime' in str(p)):p.touch()
 print('Building '+name,flush=True)
 p=subprocess.run(command,cwd=root,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/(name+'.log')).write_text(p.stdout)
 print(p.stdout,end='',flush=True)
 record['commands'][name]={'command':command,'environment':{k:environment.get(k) for k in ('RUSTFLAGS','RUSTC_BOOTSTRAP')},'returncode':p.returncode,'log_sha256':hash_bytes(p.stdout.encode())}
 save();p.check_returncode()
 assert sources=={str(p.relative_to(root)):p.read_text() for p in paths},'Sources changed during build'
 for source,name_out in artifacts:
  shutil.copy2(source,out/name_out)
  record['sha256'][str((out/name_out).relative_to(root))]=hash_bytes((out/name_out).read_bytes())
 if name=='thinlto':record['runtime_lto_rustflags']='-Clinker-plugin-lto'
 save()
 print('Frozen '+name,flush=True)
record['freshness']='Touched relevant Rust source mtimes before each mode; all source contents remained identical.'
record['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print(json.dumps({'artifacts':record['sha256'],'build_record_sha256':hash_bytes((out/'build-record.json').read_bytes())}),flush=True)
