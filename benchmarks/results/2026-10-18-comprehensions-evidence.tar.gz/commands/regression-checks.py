#!/usr/bin/env python3
"""Record paired-tool native suite validation without changing tracked files."""

import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import threading
import time


def digest(path: Path) -> str:
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True)
    parser.add_argument("--compiler", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--opt-levels", nargs="+", default=["0", "3"])
    parser.add_argument("--sanitize", action="store_true")
    parser.add_argument("--lto-linker", type=Path)
    parser.add_argument("--target")
    parser.add_argument("--jobs", type=int, default=3)
    parser.add_argument("--suites", nargs="+", default=[
        "containers", "classes", "exceptions", "differential", "imports", "io", "files"
    ])
    args = parser.parse_args()
    repo = Path("/home/dev-user/code/oss/relar")
    destination = repo / "benchmarks/local/comprehension-validation-final" / args.mode
    destination.mkdir(parents=True, exist_ok=False)
    python = "/home/dev-user/.local/bin/python3.14"
    compiler = args.compiler.absolute()
    runtime = args.runtime.absolute()
    record = {
        "schema": "relar-comprehension-native-validation-v1",
        "mode": args.mode,
        "started_at_unix": time.time(),
        "repository": str(repo),
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip(),
        "compiler": {"path": str(compiler), "sha256": digest(compiler)},
        "runtime": {"path": str(runtime), "sha256": digest(runtime)},
        "python": subprocess.check_output([python, "-VV"], text=True).strip(),
        "clang": subprocess.check_output(["/usr/bin/clang-18", "--version"], text=True).strip(),
        "runner": {"path": str(Path(__file__).absolute()), "sha256": digest(Path(__file__))},
        "test_sources": {
            str(path.relative_to(repo)): digest(path)
            for path in sorted((repo / "tests").rglob("*.py"))
            if "comprehensions" in args.suites or (path.name != "comprehensions.py" and "comprehensions" not in path.parts)
        },
        "results": {},
    }
    lock = threading.Lock()

    def save() -> None:
        (destination / "results.json").write_text(json.dumps(record, indent=2) + "\n")

    def run(suite: str) -> None:
        command = [python, "-I", str(repo / f"tests/{suite}.py"),
                   "--compiler", str(compiler), "--runtime", str(runtime),
                   "--python", python, "--clang", "/usr/bin/clang-18",
                   "--opt-levels", *args.opt_levels]
        if args.sanitize:
            command.append("--sanitize")
        if args.lto_linker is not None:
            command += ["--lto-linker", str(args.lto_linker.absolute())]
        if args.target:
            command += ["--target", args.target]
        stdout_path = destination / f"{suite}.stdout"
        stderr_path = destination / f"{suite}.stderr"
        started = time.time()
        with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
            result = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr, timeout=7200)
        entry = {
            "command": command,
            "returncode": result.returncode,
            "started_at_unix": started,
            "finished_at_unix": time.time(),
            "stdout": {"path": str(stdout_path), "sha256": digest(stdout_path)},
            "stderr": {"path": str(stderr_path), "sha256": digest(stderr_path)},
        }
        with lock:
            record["results"][suite] = entry
            save()
        print(suite, result.returncode, stdout_path.read_text().strip(), flush=True)
        if result.returncode:
            print(stderr_path.read_text()[-6000:], flush=True)

    save()
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        list(pool.map(run, args.suites))
    record["finished_at_unix"] = time.time()
    record["passed"] = all(result["returncode"] == 0 for result in record["results"].values())
    save()
    print(json.dumps({"record": str(destination / "results.json"),
                      "sha256": digest(destination / "results.json"),
                      "passed": record["passed"]}), flush=True)
    raise SystemExit(0 if record["passed"] else 1)


if __name__ == "__main__":
    main()
