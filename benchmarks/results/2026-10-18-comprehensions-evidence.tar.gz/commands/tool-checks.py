import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/home/dev-user/code/oss/relar')
out = root / 'benchmarks/local/comprehension-validation-final/tool-checks'
out.mkdir(parents=True, exist_ok=True)
tools = root / 'benchmarks/local/comprehension-tools-final'
toolchain = Path('/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1')
commands = [
    ('format', ['sh', '/tmp/relar-cargo.sh', 'fmt', '--all', '--check']),
    ('clippy', ['sh', '/tmp/relar-cargo.sh', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('unit', ['sh', '/tmp/relar-cargo.sh', 'test', '--workspace', '--locked']),
    ('lto-cli', ['/home/dev-user/.local/bin/python3.14', 'tests/lto.py', '--compiler', str(tools / 'relar'), '--runtime', str(tools / 'librelar_runtime_lto.a'), '--clang', '/usr/bin/clang-18', '--target', 'x86_64-unknown-linux-gnu', '--rust-lld', str(toolchain / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld'), '--python', '/home/dev-user/.local/bin/python3.14']),
]
record = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'checks': {}}
for name, command in commands:
    result = subprocess.run(command, cwd=root, capture_output=True, text=True)
    log = result.stdout + result.stderr
    (out / (name + '.log')).write_text(log)
    record['checks'][name] = {'command': command, 'returncode': result.returncode, 'log_sha256': hashlib.sha256(log.encode()).hexdigest()}
    (out / 'results.json').write_text(json.dumps(record, indent=2) + '\n')
    print(name + ': ' + str(result.returncode), flush=True)
    print(log[-2200:], flush=True)
    result.check_returncode()
record['completed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(out / 'results.json').write_text(json.dumps(record, indent=2) + '\n')
