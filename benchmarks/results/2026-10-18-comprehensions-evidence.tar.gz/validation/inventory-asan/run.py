from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
tools = root / 'benchmarks/local/comprehension-tools-final'
compiler = tools / 'imre'
runtime = tools / 'libimre_runtime_asan.a'
binary = out / 'inventory_reconciliation'
rust = root / 'benchmarks/local/inventory-reference-dev/inventory-bigint'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sources = [*sorted((root / 'examples/inventory_reconciliation').rglob('*.py')), root / 'benchmarks/inventory_validate.py', root / 'benchmarks/manifest_validate.py']
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
status = subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
assert head.startswith('edbbab9'), head
assert not status, status
command = [str(compiler),'build',str(root / 'examples/inventory_reconciliation/__main__.py'),'--module-root',str(root / 'examples'),'-o',str(binary),'--runtime',str(runtime),'--clang','clang-18','--sanitize','--opt-level','1','--emit-llvm',str(out / 'inventory_reconciliation.ll')]
record = {'started_at_utc':datetime.now(timezone.utc).isoformat(),'git_head':head,'git_status':status,'build_command':command,'sources':{str(path.relative_to(root)):digest(path) for path in sources},'compiler_sha256':digest(compiler),'runtime_sha256':digest(runtime),'compiler_build_record_sha256':digest(tools / 'build-record.json'),'rust_binary_sha256':digest(rust)}
with (out / 'build.log').open('w') as log:
    built=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=False)
record['build_returncode']=built.returncode
record['build_log_sha256']=digest(out/'build.log')
if built.returncode:
    (out/'build-record.json').write_text(json.dumps(record,indent=2)+'\n')
    print((out/'build.log').read_text(),flush=True)
    raise SystemExit(built.returncode)
record['binary_sha256']=digest(binary)
record['llvm_ir_sha256']=digest(out/'inventory_reconciliation.ll')
validate=['python3','benchmarks/inventory_validate.py','--binary',str(binary),'--python','/home/dev-user/.local/bin/python3.14','--rust-bigint',str(rust),'--output',str(out/'validation.json')]
environment={**os.environ,'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','LSAN_OPTIONS':'exitcode=23'}
record['validation_command']=validate
record['validation_environment']={key:environment[key] for key in ('ASAN_OPTIONS','LSAN_OPTIONS')}
record['outside_ptrace']=True
with (out/'validation.log').open('w') as log:
    result=subprocess.run(validate,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT,check=False)
record['validation_returncode']=result.returncode
record['validation_log_sha256']=digest(out/'validation.log')
record['source_hashes_unchanged']=all(digest(root/name)==sha for name,sha in record['sources'].items())
record['completed_at_utc']=datetime.now(timezone.utc).isoformat()
record['limits']=['Generated LLVM and runtime sources are instrumented; the prebuilt Rust standard library is not rebuilt with ASan.']
if (out/'validation.json').exists():
    record['validation_sha256']=digest(out/'validation.json')
    validation=json.loads((out/'validation.json').read_text())
    record['summary']={key:validation[key] for key in ('cases','successful','terminal_errors','engines')}
record['driver_sha256']=digest(Path(__file__))
(out/'build-record.json').write_text(json.dumps(record,indent=2)+'\n')
print('validation returncode',result.returncode,flush=True)
print((out/'validation.log').read_text(),flush=True)
print('build-record.json SHA256',digest(out/'build-record.json'),flush=True)
assert record['source_hashes_unchanged']
raise SystemExit(result.returncode)
