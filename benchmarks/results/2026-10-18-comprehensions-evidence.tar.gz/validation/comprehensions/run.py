from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
tools = root / 'benchmarks/local/comprehension-tools-final'
mode = sys.argv[1]
compiler = tools / 'imre'
archive = {'normal':'libimre_runtime.a', 'thinlto':'libimre_runtime_lto.a', 'asan':'libimre_runtime_asan.a'}[mode]
runtime = tools / archive

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert digest(compiler) == 'b45610eb0e6b10f8009204c0cffa3c93053dc50bf6520200003b88800820d196'
assert digest(tools / 'build-record.json') == 'cab3b5a462e9f3447ca3bbca75203113b7c4654e5d6e5f287bd54c708f99342f'
build = json.loads((tools / 'build-record.json').read_text())
for name, expected in build['source_sha256'].items():
    assert digest(root / name) == expected, name
command = ['python3', 'tests/comprehensions.py', '--compiler', str(compiler), '--runtime', str(runtime), '--python', '/home/dev-user/.local/bin/python3.14', '--clang', 'clang-18', '--opt-levels', *({'normal':['0','3'], 'thinlto':['3'], 'asan':['1']}[mode])]
if mode == 'thinlto':
    command += ['--target', 'x86_64-unknown-linux-gnu', '--lto-linker', str(root / 'benchmarks/local/batch-linker/ld.lld')]
if mode == 'asan':
    command += ['--sanitize']
sources = [root / 'tests/comprehensions.py', *sorted((root / 'tests/fixtures/comprehensions').rglob('*.py'))]
record = {'mode': mode, 'command': command, 'cwd': str(root), 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': '615aa41', 'build_record_sha256': digest(tools / 'build-record.json'), 'compiler_sha256': digest(compiler), 'runtime_sha256': digest(runtime), 'sources': {str(p.relative_to(root)): digest(p) for p in sources}, 'sanitizer_environment_set_by_harness': {'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1', 'LSAN_OPTIONS':'exitcode=23'}, 'asan_outside_ptrace':mode == 'asan'}
(out / (mode + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
with (out / (mode + '.log')).open('w') as output:
    result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT, check=False)
record.update(returncode=result.returncode, completed_at_utc=datetime.now(timezone.utc).isoformat(), log_sha256=digest(out / (mode + '.log')), source_hashes_unchanged=all(digest(root / p) == value for p, value in record['sources'].items()))
(out / (mode + '-validation.json')).write_text(json.dumps(record, indent=2) + '\n')
print(mode, 'returncode', result.returncode, flush=True)
print((out / (mode + '.log')).read_text(), flush=True)
raise SystemExit(result.returncode)
