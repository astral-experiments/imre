from pathlib import Path
import hashlib,os,subprocess,json,shutil
c=Path('/home/dev-user/.cache/imre/grouping-study-20261023/allocator-choice-e483582'); bundle=c/'install';bundle.mkdir(parents=True,exist_ok=True)
repo=Path('/home/dev-user/code/oss/imre-analysis-allocator-choice'); p=c.parent/'static-allocator-aa24071'; core=p/'build-final/core'
revision='e48358285c1240ef30b0583b32252d653a613e30'; assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==revision
def identity(f):return {'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
for target,f in [('imre',Path('/home/dev-user/.cache/imre/analysis-allocator-choice-target/release/imre')),('libimre_runtime.a',core/'normal_system_runtime.a'),('libimre_runtime_jemalloc.a',core/'normal_jemalloc_runtime.a')]:
 dest=bundle/target
 if not dest.is_file():os.link(f,dest)
 assert identity(dest)==identity(f)
env={k:v for k,v in os.environ.items() if k not in {'LD_PRELOAD','MALLOC_CONF','JEMALLOC_OVERRIDE','JEMALLOC_SYS_WITH_MALLOC_CONF','PYTHONPATH'}};env['PYTHONPATH']=str(repo/'examples')
def run(cmd):r=subprocess.run(list(map(str,cmd)),cwd=repo,env=env,capture_output=True,timeout=90);assert r.returncode==0 and not r.stderr,(cmd,r.returncode,r.stderr[-1000:]);return r
flags=[]
for name in ('manifest','old','new'): flags+=['--'+name,c.parent/'fixtures/1x/changed'/(name+'.json')]
flags+=['--format','github']
entry=repo/'examples/conformance_report/__main__.py'
oracle=c/'cpython.md'; py=Path.home()/'.cache/imre-live-conformance-20261022/python-venv/bin/python'
if not py.exists():py=Path('/home/dev-user/.local/bin/python3.14')
expected=run([py,'-B',repo/'examples/conformance_report/original.py',*flags,'--output',oracle])
modes={}
for mode in ('default','system','jemalloc'):
 ll=c/(mode+'.ll'); report=c/(mode+'.md')
 argv=[bundle/'imre','run',entry,'--module-root',repo/'examples','--clang','/usr/lib/llvm-18/bin/clang','--emit-llvm',ll]
 if mode!='default':argv+=['--allocator',mode]
 r=run([*argv,'--',*flags,'--output',report])
 assert report.read_bytes()==oracle.read_bytes() and r.stdout==expected.stdout
 assert not b'imre_init_native_heap' in ll.read_bytes()
 modes[mode]={'report':identity(report),'llvm':identity(ll),'stdout':hashlib.sha256(r.stdout).hexdigest(),'args':[str(x) for x in argv]}
assert len({r['llvm']['sha256'] for r in modes.values()})==1
prior=c.parent/'final-7178431/build-final/programs/normal/conformance-report.ll'
assert (c/'system.ll').read_bytes()==prior.read_bytes()
r={'source':revision,'runtime_source':'aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5','runtime_core':identity(core/'build-record.json'),'installation':{f.name:identity(f) for f in sorted(bundle.iterdir())},'python':subprocess.check_output([py,'-VV'],text=True).strip(),'oracle':identity(oracle),'pre_heap_ir':identity(prior),'modes':modes}
(c/'reporter.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'report':r['oracle'],'ir':r['pre_heap_ir'],'installation':r['installation']}),flush=True)

