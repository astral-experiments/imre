#!/usr/bin/python3
from pathlib import Path
import hashlib,json,os,subprocess,sys
args=sys.argv[1:]; implicit=Path(args[2]); assert implicit.name.startswith('imre-') and implicit.suffix=='.ll'
fixed=Path('/tmp') / os.environ['IMRE_CONFIRMED_ELF_IR_BASENAME']; assert fixed.parent==Path('/tmp') and fixed.name.startswith('imre-') and fixed.suffix=='.ll'
raw=implicit.read_bytes()
with fixed.open('xb') as fd:fd.write(raw)
try:
 args[2]=str(fixed); runtime=Path(args[3])
 with runtime.open('rb') as fd:rhash=hashlib.file_digest(fd,'sha256').hexdigest()
 assert rhash==os.environ['IMRE_EXPECTED_RUNTIME_SHA256']
 record={'llvm_sha256':hashlib.sha256(raw).hexdigest(),'runtime':str(runtime),'runtime_sha256':rhash,'canonical_llvm_basename':fixed.name,'clang':'/usr/lib/llvm-18/bin/clang','command':args}
 Path(os.environ['IMRE_CANONICAL_LINK_RECEIPT']).write_text(json.dumps(record,indent=2)+'\n')
 sys.exit(subprocess.run([record['clang'],*args]).returncode)
finally:fixed.unlink()

