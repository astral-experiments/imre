from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,os,subprocess
c=Path(__file__).resolve().parent;repo=Path('/home/dev-user/code/oss/imre-analysis-allocator-choice');p=c.parent/'static-allocator-aa24071';cli=c/'install/imre';py='/home/dev-user/.local/bin/python3.14';env=dict(os.environ)
env.update({'CARGO_HOME':'/home/dev-user/.cache/imre/cargo-home','CARGO_TARGET_DIR':'/home/dev-user/.cache/imre/analysis-allocator-choice-target','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/imre/ohm-build-1.99.0-7','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1'})
args=[py,'-B',str(repo/'tests/io.py'),'--compiler',str(cli),'--clang','/usr/lib/llvm-18/bin/clang','--python',py,'--opt-levels','0','3','--runtime'];cargo=['cargo','+ohm','-Zohm-defaults=no']
tests={'io':args+[str(p/'build-system/core/normal_runtime.a')],'io_asan':args+[str(p/'asan-core/asan_runtime.a'),'--sanitize'],'compiler_tests':cargo+['test','--locked','--release','-p','imre-compiler'],'clippy':cargo+['clippy','--locked','-p','imre-compiler','--all-targets','--','-D','warnings'],'fmt':cargo+['fmt','--all','--','--check']}
def run(k):
 r=subprocess.run(tests[k],env=env,cwd=repo,capture_output=True,timeout=600);out=r.stdout+r.stderr;log=c/(k+'.log');log.write_bytes(out);assert r.returncode==0,(k,r.returncode,out[-800:]);print(k,out[-300:],flush=True)
 return {'case':k,'command':tests[k],'log':{'path':str(log),'sha256':hashlib.sha256(out).hexdigest(),'bytes':len(out)},'returncode':r.returncode}
with ThreadPoolExecutor(max_workers=3) as x: records=list(x.map(run,tests))
for k in ('io','io_asan'):assert (c/(k+'.log')).read_text().startswith('Passed 30 I/O checks ')
(c/'cli-qa.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'tests':records,'sanitizer':'ASAN_OPTIONS=detect_leaks=1:halt_on_error=1, execution outside ptrace'},indent=2)+'\n')

