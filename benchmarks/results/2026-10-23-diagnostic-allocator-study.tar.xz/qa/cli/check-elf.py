from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,os,subprocess,re,sys
c=Path(__file__).resolve().parent;p=c.parent/'static-allocator-aa24071';repo=Path('/home/dev-user/code/oss/imre-analysis-allocator-choice');cli=c/'install/imre'
head='e48358285c1240ef30b0583b32252d653a613e30'; final=subprocess.check_output(['git','rev-parse','e78c84a^{commit}'],cwd=repo,text=True).strip()
def id(f):
 with f.open('rb') as fd:sh=hashlib.file_digest(fd,'sha256').hexdigest()
 return {'sha256':sh,'bytes':f.stat().st_size}
def run(args,**kw):return subprocess.check_output(args,text=True,**kw)
assert run(['git','rev-parse','HEAD'],cwd=repo).strip()==head and not run(['git','diff','--name-status',head,final,'--','crates','Cargo.toml','Cargo.lock','tests','stdlib'],cwd=repo)
def one(cell):
 mode,allocator,family,name=cell; shipping=(p/'build-final' if allocator=='jemalloc' or mode=='asan' else p/'build-system')/family/mode
 record=json.loads((shipping/'build-record.json').read_bytes());llvm_ref=shipping/(name+'.ll'); official=shipping/name
 original=(record['command'] if family=='kernels' else next(step['command'] for step in record['steps'] if step['name']==('conformance_report' if name=='conformance-report' else 'conformance_report-compute')))
 template=list(original);template[0]=str(cli); template[template.index('--clang')+1]=str(c/'canonical-clang.py')
 output=c/'matching-binaries'/allocator/mode/name;output.parent.mkdir(parents=True,exist_ok=True)
 llvm=output.with_suffix('.ll');template[template.index('-o')+1]=str(output);template[template.index('--emit-llvm')+1]=str(llvm)
 if mode=='normal':
    pos=template.index('--runtime');del template[pos:pos+2];template+=['--allocator',allocator]
 receipt=output.with_suffix('.json')
 temp=re.findall(r'\bFILE\s+LOCAL\s+DEFAULT\s+ABS\s+(imre-[a-zA-Z0-9]{6}\.ll)\b',run(['readelf','-Ws',official]));assert len(temp)==1
 env={**record['environment'],'IMRE_CONFIRMED_ELF_IR_BASENAME':temp[0],'IMRE_CANONICAL_LINK_RECEIPT':str(receipt),'IMRE_EXPECTED_RUNTIME_SHA256':record['runtime']['sha256']}
 subprocess.run(template,cwd=repo,env=env,check=True,timeout=300)
 assert llvm.read_bytes()==llvm_ref.read_bytes()
 assert id(output)==id(official),(cell,id(output),id(official))
 link=json.loads(receipt.read_bytes());assert link['llvm_sha256']==id(llvm_ref)['sha256']
 return {'allocator':allocator,'mode':mode,'name':name,'official_record':id(shipping/'build-record.json'),'llvm':id(llvm),'exact_elf':id(output),'official_elf':str(official),'compiler_command':template,'link':link}
jobs=[(m,a,f,n) for a,m in [('jemalloc','normal'),('jemalloc','thinlto'),('system','asan'),('system','normal'),('system','thinlto')] for f,n in [('kernels','grouping'),('programs','conformance-report'),('programs','conformance-report-compute')]]
with ThreadPoolExecutor(max_workers=3) as ex:
 values=[]
 for value in ex.map(one,jobs):
    values.append(value);print(value['allocator'],value['mode'],value['name'],value['exact_elf']['sha256'],flush=True)
r={'cli_revision':head,'integrated_revision':final,'application_runtime_revision':'aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5','matching_final_paths':['Cargo.toml','Cargo.lock','crates','stdlib','tests'],'compiler':id(cli),'linker_replay':id(c/'canonical-clang.py'),'inputs':{'build_package':'--allocator for ordinary; explicit matching --runtime for ThinLTO or ASan','normalization':'only the input LLVM temporary filename changes; reuse the exact previously observed executable STT_FILE basename in /tmp, including diagnostic source locations','output_comparison':'independent compiler-generated raw LLVM and complete linked ELF, byte-for-byte'},'results':values}
(c/'binary-equivalence.json').write_text(json.dumps(r,indent=2)+'\n')

