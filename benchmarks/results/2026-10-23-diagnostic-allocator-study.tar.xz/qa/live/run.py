from hashlib import sha256
import itertools
import json
import os
from pathlib import Path
import statistics
import subprocess
import tempfile
import time

repo = Path("/home/dev-user/code/oss/imre-diagnostic-pipeline")
cache = Path("/home/dev-user/.cache")
study = cache / "imre/grouping-study-20261023/static-allocator-aa24071"
receipt = cache / "imre/diagnostic-pipeline-20261023/aa24071/live"
receipt.mkdir(exist_ok=True)
git = lambda root: subprocess.check_output(["git", "-C", root, "rev-parse", "HEAD"], text=True).strip()
digest = lambda path: sha256(path.read_bytes()).hexdigest()
source = git(repo)
assert source == "e78c84acecc568ae3267aea07cab243ae2647f4f"
checkout = Path("/home/dev-user/code/oss/typing-imre-diagnostic-20261023")
assert git(checkout) == "835b70f3f795f8e061b1f7621178515b0a77a0ad"
old = cache / "imre-native-tools-20261021/input-tools/ty-0.0.60/bin/ty"
new = cache / "imre/memory-uv/archive-v0/YYGFTbINyot7UutP/bin/ty"
assert [digest(old), digest(new)] == [
    "c4982eb6c39576b0277a20ab2522de1f76ded9279c43e9738e3a63619b95e560",
    "e56df0042c10ae481d80e155386f732a67994bf41af94c164d2bd1ec68797211",
]
target = cache / "imre/diagnostic-pipeline-target/release"
compiler = target / "imre"
roles = ("upstream", "system", "jemalloc", "rust")
commands = {
    "upstream": [Path("/home/dev-user/.local/bin/python3.14"), "-s", "-B", repo / "examples/conformance_report/original_live.py"],
    "rust": [cache / "imre/grouping-study-20261023/final-7178431/build-rust/normal/conformance-report-reference"],
}
for allocator, opts in (("system", []), ("jemalloc", ["--allocator", "jemalloc"])):
    binary = receipt / ("report-" + allocator)
    ir = receipt / (allocator + ".ll")
    subprocess.run([compiler, "build", "examples/conformance_report/__main__.py", "--module-root", "examples", *opts,
                    "--emit-llvm", ir, "-o", binary], cwd=repo, check=True)
    assert ir.read_bytes() == (study / "build-final/programs/normal/conformance-report.ll").read_bytes()
    commands[allocator] = [binary]
env = {**os.environ, "RAYON_NUM_THREADS": "2", "PYTHONHASHSEED": "0", "PYTHONPATH": str(repo / "examples/conformance_report")}
oracle_dir = cache / "imre/diagnostic-pipeline-20261023/production-gather-validation/live"
def invoke(role, suite, analyzer, fmt, output, expected):
    output.unlink(missing_ok=True)
    args = ["--suite", suite, "--old-ty", analyzer, "--new-ty", new, "--timeout", "30", "--format", fmt, "--output", output]
    start = time.perf_counter_ns()
    result = subprocess.run(commands[role] + args, capture_output=True, env=env, timeout=120)
    ns = time.perf_counter_ns() - start
    assert not (result.returncode or result.stderr or result.stdout), (role, result.returncode, result.stderr)
    assert output.read_bytes() == expected, (role, suite, fmt)
    return ns
records = {}
for state, analyzer in (("changed", old), ("unchanged", new)):
    for fmt in ("github", "diff"):
        name = f"{state}-{fmt}"
        expected = (oracle_dir / f"{name}-upstream.md").read_bytes()
        for role in roles:
            invoke(role, checkout / "conformance", analyzer, fmt, receipt / f"{name}-{role}.md", expected)
        records[name] = {"bytes": len(expected), "sha256": sha256(expected).hexdigest()}
        print(name, records[name], flush=True)
oracle = (oracle_dir / "changed-github-upstream.md").read_bytes()
with tempfile.TemporaryDirectory(prefix="imre-102-symlink-final-") as directory:
    alias = Path(directory) / "typing sources δ"
    alias.symlink_to(checkout, target_is_directory=True)
    for role in roles:
        invoke(role, alias / "conformance", old, "github", Path(directory) / f"{role} report 𝔘.md", oracle)
rows = []
# Three balanced repetitions. Each role appears equally often in each position.
latin = ((0, 1, 3, 2), (1, 2, 0, 3), (2, 3, 1, 0), (3, 0, 2, 1))
with tempfile.TemporaryDirectory(prefix="imre-102-live-final-") as directory:
    path = Path(directory) / "report.md"
    for i, order in enumerate([range(4), *latin, *reversed(latin), *latin]):
        row = {roles[index]: invoke(roles[index], checkout / "conformance", old, "github", path, oracle) for index in order}
        if i:
            rows.append(row)
medians = {role: statistics.median(row[role] for row in rows) / 1e6 for role in roles}
summary = {
    "source": source, "suite_source": git(checkout), "suite": str(checkout), "analyzer_sha256": [digest(old), digest(new)],
    "commands": {role: list(map(str, value)) for role, value in commands.items()},
    "engine_sha256": {role: digest(value[0]) for role, value in commands.items()},
    "upstream_driver_sha256": digest(commands["upstream"][-1]), "cli_sha256": digest(compiler),
    "static_archives_sha256": {name: digest(target / name) for name in ("libimre_runtime.a", "libimre_runtime_jemalloc.a")},
    "llvm_sha256": digest(receipt / "jemalloc.ll"), "reports": records, "unicode_symlink_matched": list(roles),
    "cpu_affinity": sorted(os.sched_getaffinity(0)), "rayon_threads": 2, "samples_ns": rows,
    "median_ms": medians, "system_over_rust": medians["system"] / medians["rust"], "jemalloc_over_rust": medians["jemalloc"] / medians["rust"],
}
(receipt / "receipt.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({k:summary[k] for k in ("source", "median_ms", "system_over_rust", "jemalloc_over_rust")}), flush=True)
