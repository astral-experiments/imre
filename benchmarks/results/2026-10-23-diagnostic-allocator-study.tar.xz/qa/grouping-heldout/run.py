"""Check the real grouping and alias transcript under both Linux allocators."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import subprocess

repo = Path("/home/dev-user/code/oss/imre-diagnostic-pipeline")
cache = Path("/home/dev-user/.cache/imre")
study = cache / "grouping-study-20261023/static-allocator-aa24071"
root = cache / "diagnostic-pipeline-20261023/aa24071/grouping-heldout"
root.mkdir(exist_ok=False)
validator = runpy.run_path(str(repo / "benchmarks/conformance_grouping_validate.py"))
env = validator["VALIDATION"]["environment"](root)
env["ASAN_OPTIONS"] = "detect_leaks=1:halt_on_error=1"
assert "LD_PRELOAD" not in env
options = {
    "upstream": ["/home/dev-user/.local/bin/python3.14", "-s", "-B", str(repo / "benchmarks/conformance_grouping_upstream.py")],
    "system": [str(study / "build-system/kernels/normal/grouping")],
    "jemalloc": [str(study / "build-final/kernels/normal/grouping")],
    "asan": [str(study / "build-final/kernels/asan/grouping")],
    "rust": [str(cache / "grouping-study-20261023/final-7178431/build-rust/normal/conformance-report-reference"), "--grouping"],
}
for cmd in options.values():
    assert os.access(cmd[0], os.X_OK), cmd
cases = []
start = 917704
for seed in range(start, start + 96):
    folder = root / f"seed-{seed}"
    folder.mkdir()
    inputs = validator["fixture"](folder, seed)
    for mode in ("dump", "aliases"):
        suffix = [mode, *inputs, "1"]
        error, oracle = validator["observation"](options["upstream"], suffix, folder, env)
        assert error is None, (seed,mode)
        for role, command in options.items():
            if role != "upstream":
                err, value = validator["observation"](command, suffix, folder, env)
                assert (err, value) == (error, oracle), (seed, mode, role)
        cases.append({"seed":seed, "mode":mode, "bytes":len(oracle), "sha256":sha256(oracle).hexdigest()})
result = {"runtime":"aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5","checkout":subprocess.check_output(["git","-C",repo,"rev-parse","HEAD"],text=True).strip(),
          "commands":options,"engine_sha256":{k:sha256(Path(v[0]).read_bytes()).hexdigest() for k,v in options.items()},
          "start":start,"count":96,"asan_options":env["ASAN_OPTIONS"],"observations":cases}
(root / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
print(f"{len(cases)} transcript and alias comparisons × {len(options)} engines against upstream CPython")
