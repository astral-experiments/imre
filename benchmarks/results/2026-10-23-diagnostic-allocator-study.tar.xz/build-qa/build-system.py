from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os,subprocess,json,sys
p=Path(__file__).resolve().parent;root=p/'build-system';repo=Path('/home/dev-user/code/oss/relar-analysis-runtime-archives')
target=Path('/home/dev-user/.cache/relar/analysis-runtime-archives-target');shared=Path('/home/dev-user/.cache/relar/ohm-build-1.99.0-7');clang='/usr/lib/llvm-18/bin/clang'
linker=Path('/home/dev-user/.local/share/ohm/toolchains/ohm-1.99.0-7/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5'
env={k:v for k,v in os.environ.items() if k not in {'LD_PRELOAD','MALLOC_CONF','JEMALLOC_OVERRIDE','JEMALLOC_SYS_WITH_MALLOC_CONF'}};env['CARGO_HOME']='/home/dev-user/.cache/relar/cargo-home'
subprocess.run([sys.executable,'-B','-u',str(repo/'benchmarks/native_tools_build.py'),'--toolchain','ohm','--target-dir',target,'--shared-build-dir',shared,'--jobs','5','--modes','normal','thinlto','--output',root/'core'],cwd=repo,env=env,check=True)
core=root/'core/build-record.json';record=json.loads(core.read_bytes());jem=json.loads((p/'build-final/core/build-record.json').read_bytes())
for mode in ('normal','thinlto'): assert record['sha256'][mode+'_runtime']==jem['sha256'][mode+'_system_runtime']
def build(mode):
      programs=root/'programs'/mode;kernel=root/'kernels'/mode
      cmd=[sys.executable,'-B','-u',str(repo/'benchmarks/live_conformance_build.py'),'--application','conformance_report','--core-build-record',core,'--mode',mode,'--clang',clang,'--output',programs]
      if mode=='thinlto':cmd+=['--lto-linker',linker]
      subprocess.run(cmd,check=True,cwd=repo,env=env)
      subprocess.run([sys.executable,'-B','-u',p/'build-grouping.py','--study',repo,'--application',repo,'--program-record',programs/'build-record.json','--output',kernel],check=True,cwd=repo,env=env)
with ThreadPoolExecutor(max_workers=2) as pool:
    for f in [pool.submit(build,mode) for mode in ('normal','thinlto')]:f.result()

