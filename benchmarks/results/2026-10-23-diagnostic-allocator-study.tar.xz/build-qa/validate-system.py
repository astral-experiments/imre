from pathlib import Path
import hashlib,json,os,subprocess,tempfile
p=Path(__file__).resolve().parent;src=Path('/home/dev-user/code/oss/imre-analysis-runtime-archives')
ref=json.loads((p/'transcript-validation.json').read_bytes());assert len(ref['panels'])==8
env={k:v for k,v in os.environ.items() if k not in ('LD_PRELOAD','MALLOC_CONF','PYTHONPATH')}
def payload(v):return {'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
count=0; outputs={}
with tempfile.TemporaryDirectory() as tmp:
 out=Path(tmp)/'report.md'
 for panel, row in ref['panels'].items():
  which,scale,change=panel.split('/');root=(p.parent/'fixtures' if which=='long' else Path('/tmp/rl23'))
  ins=[root/scale/change/(n+'.json') for n in ('manifest','old','new')];flags=['--manifest',ins[0],'--old',ins[1],'--new',ins[2]]
  assert {i.name:payload(i.read_bytes())['sha256'] for i in ins}==row['inputs']
  outputs[panel]={}
  for case,name,kind,args in [('dump','grouping','kernels',['dump',*ins,'0']),('aliases','grouping','kernels',['aliases',*ins,'0']),('github','conformance-report','programs',[*flags,'--format','github','--force-summary-table','--output',out]),('diff','conformance-report','programs',[*flags,'--format','diff','--force-summary-table','--output',out]),('compute','conformance-report-compute','programs',[*flags,'--format','github','--force-summary-table','--rounds','1','--output',out])]:
   for mode in ('normal','thinlto'):
    if out.exists():out.unlink()
    exe=p/'build-system'/kind/mode/name;r=subprocess.run([exe,*map(str,args)],capture_output=True,timeout=120,env=env,cwd=src);assert r.returncode==0 and not r.stderr
    values=[payload(r.stdout),None if kind=='kernels' else payload(out.read_bytes())]
    assert values==row['cases'][case]['oracle'],(panel,case,mode,values)
    count+=1
   outputs[panel][case]={'oracle':values,'modes':['normal','thinlto']}
  print(panel,flush=True)
assert count==80
(p/'system-transcript-validation.json').write_text(json.dumps({'revision':ref['revision'],'cp_python_receipt':payload((p/'transcript-validation.json').read_bytes()),'executions':count,'panels':outputs},indent=2)+'\n')

