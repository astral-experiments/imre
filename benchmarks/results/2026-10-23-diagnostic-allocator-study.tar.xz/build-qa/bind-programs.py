from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,runpy,subprocess,re,tempfile
p=Path(__file__).resolve().parent; reference=p.parent/'final-7178431'; sa=p.parent/'packed-admission-c806b9e'; repo=Path('/home/dev-user/code/oss/imre-analysis-runtime-archives'); rev='aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5'
def out(*cmd):return subprocess.check_output(cmd,text=True)
def ident(f):
    with f.open('rb') as fd:h=hashlib.file_digest(fd,'sha256').hexdigest()
    return {'path':str(f),'bytes':f.stat().st_size,'sha256':h}
def read(f):return json.loads(f.read_bytes())
def write(f,obj):f.write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
def short_ids(m):return {k:v['sha256'] for k,v in m.items()}
assert out('git','-C',repo,'rev-parse','HEAD').strip()==rev
assert not out('git','-C',repo,'diff','7178431',rev,'--','crates/imre-compiler')
assert not out('git','-C',repo,'diff','7178431','c806b9e','--','crates/imre-compiler')
tree=out('git','-C',repo,'rev-parse','HEAD^{tree}').strip();primary=p/'build-final/core';pm=read(primary/'build-record.json')
modes=[('jemalloc','normal'),('jemalloc','thinlto'),('system','asan'),('system','normal'),('system','thinlto')]
def bind(pair):
    heap,mode=pair; final=(p/'build-final' if heap=='jemalloc' or mode=='asan' else p/'build-system'); core=(p/'asan-core' if mode=='asan' else final/'core'); src=(p/'measurement-source' if heap=='jemalloc' else repo); ref=sa if mode=='asan' else reference
    checker=runpy.run_path(str(src/'benchmarks/live_conformance_benchmark.py'))['verify_build_record']
    crfile=core/'build-record.json'; c=read(crfile); prfile=final/'programs'/mode/'build-record.json'; kfile=final/'kernels'/mode/'build-record.json'; pr=checker(prfile,{});k=read(kfile)
    for j in (pr,k,c):assert j['revision']==rev and j['input_guards_passed'] and j['status']=='passed'
    for name,digest in c['source_sha256'].items():assert ident(repo/name)['sha256']==digest
    baseline=read(ref/'build-final/programs'/mode/'build-record.json'); kr=read(ref/'build-final/kernels'/mode/'build-record.json')
    assert short_ids(k['application_inputs'])==short_ids(kr['application_inputs']) and k['driver']['sha256']==kr['driver']['sha256'] and short_ids(pr['retained_sources'])==short_ids(baseline['retained_sources'])
    for v in (pr,k):assert v['tools']==baseline['tools'] and v['environment']==baseline['environment'] and not {'LD_PRELOAD','MALLOC_CONF'} & v['environment'].keys()
    assert k['runtime']==pr['runtime'] and k['compiler']==pr['compiler']
    if mode!='asan':assert pr['runtime']['sha256']==pm['sha256'][mode+'_'+heap+'_runtime']
    assert c['sha256'][mode+'_runtime']==pr['runtime']['sha256']
    result={'core_record':ident(crfile),'group_record':ident(kfile),'program_record':ident(prfile),'core_steps':[{n:st[n] for n in ('name','command','overrides')} for st in c['steps']],'driver':ident(src/'benchmarks/conformance_grouping.py'),'compiler':pr['compiler'],'runtime':pr['runtime'],'runtime_heap':heap,'tools':pr['tools'],'link_environment':pr['environment'],'programs':{}}
    for family,name in [('kernels','grouping'),('programs','conformance-report'),('programs','conformance-report-compute')]:
        dest=final/family/mode; old=ref/'build-final'/family/mode; elf=dest/name; ll=dest/(name+'.ll'); before=old/(name+'.ll')
        assert ll.read_bytes()==before.read_bytes() and b'imre_init_native_heap' not in ll.read_bytes()
        s=out('llvm-nm-18','--defined-only',elf); symbols=[line.split()[-1] for line in s.splitlines() if ' _rjem_' in line]
        assert bool(symbols)==(heap=='jemalloc') and ' imre_init_native_heap' not in s and (' __asan_init' in s)==(mode=='asan'),(mode,heap,name)
        needed=re.findall(r'Shared library: \[(.+?)\]',out('readelf','-d',elf));assert all('jemalloc' not in n for n in needed)
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp); strip=tmp/'strip';subprocess.run(['llvm-strip-18','--strip-all','-o',strip,elf],check=True)
            machine=tmp/'text';subprocess.run(['llvm-objcopy-18','--dump-section','.text='+str(machine),elf,tmp/'copied'],check=True)
            machine_ids={'stripped_bytes':strip.stat().st_size,'stripped_sha256':ident(strip)['sha256'],'text_bytes':machine.stat().st_size,'text_sha256':ident(machine)['sha256']}
        result['programs'][name]={'binary':ident(elf),'llvm':ident(ll),'baseline_llvm':ident(before),'llvm_identical':True,'machine':machine_ids,'jemalloc_defined_symbol_count':len(symbols),'selected_symbols':[q for q in symbols if q in {'_rjem_malloc','_rjem_free','_rjem_mallocx','_rjem_rallocx','_rjem_sdallocx','_rjem_mallctl'}],'asan_init_defined':mode=='asan','needed':needed,'compile_command':k['command'] if family=='kernels' else next(step['command'] for step in pr['steps'] if step['name']==('conformance_report' if name=='conformance-report' else 'conformance_report-compute'))}
    return mode,heap,result
with ThreadPoolExecutor(max_workers=3) as pool:bound=list(pool.map(bind,modes))
meta={'revision':rev,'tree':tree,'baseline_revision':read(reference/'build-final/core/build-record.json')['revision'],'source_archive':ident(p/'source-aa24071.tar.gz'),'compiler_tree':out('git','-C',repo,'rev-parse','HEAD:crates/imre-compiler').strip(),'llvm_matches_revision':'7178431','toolchain':pm['toolchain'],'tool_hashes':pm['tool_sha256'],'external_dual_archive_build_recipe':ident(p/'measurement-source/benchmarks/native_tools_build.py')}
native={k:v for k,h,v in bound if h=='jemalloc' or k=='asan'};controls={k:v for k,h,v in bound if h=='system'}
write(p/'admission-build-all.json',{**meta,'modes':native});write(p/'admission-build.json',{**meta,'modes':{k:native[k] for k in ('normal','thinlto')}});write(p/'system-control-build.json',{**meta,'modes':controls})
for k,h,v in bound:print(k,h,v['programs']['grouping']['binary']['sha256'],v['programs']['grouping']['jemalloc_defined_symbol_count'],v['programs']['grouping']['machine']['stripped_bytes'],flush=True)

