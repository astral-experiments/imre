from pathlib import Path
import hashlib,json,os,subprocess,tempfile
p=Path(__file__).resolve().parent
s=p.parent
repo=Path('/home/dev-user/code/oss/imre-analysis-runtime-archives')
py=Path.home()/'.cache/imre-live-conformance-20261022/python-venv/bin/python'
if not py.exists():py=Path('/home/dev-user/.local/bin/python3.14')
env={k:v for k,v in os.environ.items() if k not in ('LD_PRELOAD','MALLOC_CONF','PYTHONPATH')}
env.update({'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','LSAN_OPTIONS':'exitcode=19','PYTHONPATH':str(repo/'examples')})
def sha(b):return hashlib.sha256(b).hexdigest()
def inv(cmd,output=None):
 if output is not None and output.exists():output.unlink()
 z=subprocess.run(list(map(str,cmd)),env=env,cwd=repo,capture_output=True,check=False)
 assert z.returncode==0 and not z.stderr,(cmd,z.returncode,z.stderr[-1200:])
 rendered=None if output is None else output.read_bytes()
 return z.stdout,rendered
def payload(result):return [{'bytes':len(v),'sha256':sha(v)} if v is not None else None for v in result]
records={};mode_names=('normal','thinlto','asan');rootmap={'long':s/'fixtures','short':Path('/tmp/rl23')}
with tempfile.TemporaryDirectory(prefix='imre-allocator-check-') as tmp:
 output=Path(tmp)/'report.md'
 for key,root in rootmap.items():
  for scale in ('1x','10x'):
   for change in ('unchanged','changed'):
    sample=key+'/'+scale+'/'+change;ins=[root/scale/change/(i+'.json') for i in ('manifest','old','new')]
    row={'inputs':{path.name:sha(path.read_bytes()) for path in ins},'cases':{}}
    flags=['--manifest',ins[0],'--old',ins[1],'--new',ins[2]]
    for name,kind,args in [('dump','kernel',['dump',*ins,'0']),('aliases','kernel',['aliases',*ins,'0']),('github','report',[*flags,'--format','github','--force-summary-table','--output',output]),('diff','report',[*flags,'--format','diff','--force-summary-table','--output',output]),('compute','compute',[*flags,'--format','github','--force-summary-table','--rounds','1','--output',output])]:
     pipe=None if kind=='kernel' else output
     if kind=='kernel':
      reference=[py,'-B',repo/'benchmarks/conformance_grouping_upstream.py',*args]
     else:
      reference=[py,'-B',repo/'examples/conformance_report/original.py',*(['--compute'] if kind=='compute' else []),*args]
     expected=inv(reference,pipe)
     for mode in mode_names:
      exe=p/(f'build-final/kernels/{mode}/grouping' if kind=='kernel' else f'build-final/programs/{mode}/conformance-report'+('-compute' if kind=='compute' else ''))
      actual=inv([exe,*args],pipe);assert actual==expected,(sample,mode,name,payload(actual),payload(expected))
     row['cases'][name]={'oracle':payload(expected),'modes':mode_names}
    records[sample]=row;print(sample,len(row['cases']),flush=True)
    (p/'transcript-validation.json').write_text(json.dumps({'revision':'aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5','asan_lsan':'detect_leaks=1:halt_on_error=1','linked_modes':mode_names,'python':subprocess.check_output([py,'-VV'],text=True).strip(),'inherited_preload':False,'panels':records},indent=2)+'\n')
