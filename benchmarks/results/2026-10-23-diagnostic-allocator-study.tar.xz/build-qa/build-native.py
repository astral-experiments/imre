from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,json,hashlib,shutil,sys,os
p=Path('/home/dev-user/.cache/imre/grouping-study-20261023/static-allocator-aa24071'); official=Path('/home/dev-user/code/oss/imre-analysis-runtime-archives'); head='aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5'; root=p/'build-final'; repo=p/'measurement-source'; core=root/'core/build-record.json'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=official,text=True).strip()==head
subprocess.run(['git','clone','--quiet','--shared','--no-checkout',str(official),str(repo)],check=True)
subprocess.run(['git','checkout','--quiet','--detach',head],cwd=repo,check=True)
record=json.loads(core.read_bytes()); recipe=core.parent/'build.py'
assert record['revision']==head and record['status']=='passed' and hashlib.sha256(recipe.read_bytes()).hexdigest()==record['driver_sha256']
shutil.copy2(recipe,repo/'benchmarks/native_tools_build.py')
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)==' M benchmarks/native_tools_build.py\n'
linker=Path('/home/dev-user/.local/share/ohm/toolchains/ohm-1.99.0-7/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld')
def run(mode):
    programs=root/'programs'/mode; kernel=root/'kernels'/mode
    cmd=[sys.executable,'-B','-u',str(repo/'benchmarks/live_conformance_build.py'),'--application','conformance_report','--core-build-record',str(core),'--mode',mode,'--clang','/usr/lib/llvm-18/bin/clang','--output',str(programs)]
    if mode=='thinlto':cmd+=['--lto-linker',str(linker)]
    subprocess.run(cmd,check=True,cwd=repo)
    subprocess.run([sys.executable,'-B','-u',str(p/'build-grouping.py'),'--study',str(repo),'--application',str(repo),'--program-record',str(programs/'build-record.json'),'--output',str(kernel)],check=True,cwd=repo)
with ThreadPoolExecutor(max_workers=2) as pool:
    for f in [pool.submit(run,mode) for mode in ('normal','thinlto')]:f.result()

