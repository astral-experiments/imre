from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parent
def ident(f):
 raw=f.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(name):return json.loads((root/name).read_bytes())
for name,obj in read('manifest.json').items():assert ident(root/name)==obj,name
measured=read('admission-build-all.json');controls=read('system-control-build.json');cli=read('cli/binary-equivalence.json');ci=read('cli/cli-qa.json');rep=read('cli/reporter.json')
rev=measured['revision'];assert rev==controls['revision']==cli['application_runtime_revision']==rep['runtime_source']
assert ci['source']==rep['source']==cli['cli_revision'] and len(cli['results'])==15
for cell in cli['results']:
 m=cell['mode'];heap=cell['allocator'];current=measured if heap=='jemalloc' or m=='asan' else controls
 group=current['modes'][m];candidate=group['programs'][cell['name']]
 assert group['runtime_heap']==heap and candidate['binary']['sha256']==cell['exact_elf']['sha256']
 assert candidate['llvm']['sha256']==candidate['baseline_llvm']['sha256']==cell['llvm']['sha256']==cell['link']['llvm_sha256']
 assert cell['link']['runtime_sha256']==group['runtime']['sha256'] and bool(candidate['jemalloc_defined_symbol_count'])==(heap=='jemalloc')
 assert candidate['asan_init_defined']==(m=='asan')
 assert all('jemalloc' not in name for name in candidate['needed'])
 stem=('build-final' if heap=='jemalloc' or m=='asan' else 'build-system')
 core=('asan-core' if m=='asan' else stem+'/core')
 assert ident(root/core/'build-record.json')['sha256']==group['core_record']['sha256']
 assert ident(root/stem/'kernels'/m/'build-record.json')['sha256']==group['group_record']['sha256']
 assert ident(root/stem/'programs'/m/'build-record.json')['sha256']==group['program_record']['sha256']
for name in ('default','system','jemalloc'):assert rep['modes'][name]['report']==rep['oracle'] and rep['modes'][name]['llvm']==rep['pre_heap_ir']
raw=read('transcript-validation.json');sys=read('system-transcript-validation.json')
assert sys['cp_python_receipt']==ident(root/'transcript-validation.json') and raw['revision']==sys['revision']==rev and len(raw['panels'])==len(sys['panels'])==8
total=0
for k,panel in raw['panels'].items():
 assert len(panel['cases'])==len(sys['panels'][k])==5
 for case,data in panel['cases'].items():
  control=sys['panels'][k][case]; assert data['oracle']==control['oracle'] and data['modes']==['normal','thinlto','asan'] and control['modes']==['normal','thinlto']
  total+=len(data['modes'])+len(control['modes'])
assert total==200
for test in ci['tests']:
 logfile=root/'cli'/(test['case']+'.log');assert test['returncode']==0 and ident(logfile)['sha256']==test['log']['sha256']
 if test['case'].startswith('io'):assert 'Passed 30 I/O checks' in logfile.read_text()
print(f'Verified 15 full ELF and raw LLVM bindings, 200 workload transcripts, 3 CLI reporter runs, 60 I/O/sanitizer controls and {len(read("manifest.json"))} file hashes.')

