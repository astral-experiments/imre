"""Bind an otherwise unchanged Rust reference to its vendored allocator and full output oracles."""

import json
import re
import runpy
import subprocess
from hashlib import sha256
from pathlib import Path

import tomllib


def read(p):
    return json.loads(p.read_bytes())


def sha(data):
    return sha256(data).hexdigest()


def run(cmd, **kwargs):
    cp = subprocess.run(cmd, check=True, capture_output=True, **kwargs)
    assert not cp.stderr, cp.stderr
    return cp.stdout


root = Path(__file__).resolve().parent
c = root.parent / "final-7178431"
ref = root / "source/benchmarks/reference/conformance_report"
oldsrc = c / "source/benchmarks/reference/conformance_report"
val = runpy.run_path(str(c / "source/benchmarks/conformance_validate.py"))
report = {
    "preparation": read(root / "preparation.json"),
    "modes": {},
    "sources": {},
    "inputs": {},
    "lock_delta": {},
}
env = val["environment"](root)
assert all(
    k not in env
    for k in [
        "LD_PRELOAD",
        "MALLOC_CONF",
        "JEMALLOC_OVERRIDE",
        "JEMALLOC_SYS_WITH_MALLOC_CONF",
    ]
)
for name in [
    "Cargo.toml",
    "Cargo.lock",
    "build.py",
    *(str(p.relative_to(ref)) for p in sorted((ref / "src").rglob("*.rs"))),
]:
    b = (ref / name).read_bytes()
    orig = (oldsrc / name).read_bytes()
    report["sources"][name] = {"measured": sha(b), "original": sha(orig)}
    if name not in {"Cargo.toml", "Cargo.lock", "src/main.rs"}:
        assert b == orig
    if name == "src/main.rs":
        assert (
            b.replace(
                b'#[cfg(target_os = "linux")]\n#[global_allocator]\nstatic GLOBAL: tikv_jemallocator::Jemalloc = tikv_jemallocator::Jemalloc;\n\n',
                b"",
            )
            == orig
        )
m = tomllib.loads((ref / "Cargo.toml").read_text())
assert m.pop("target") == {
    'cfg(target_os = "linux")': {
        "dependencies": {
            "tikv-jemallocator": {
                "version": "=0.6.1",
                "default-features": False,
                "features": ["background_threads_runtime_support"],
            }
        }
    }
}
assert m == tomllib.loads((oldsrc / "Cargo.toml").read_text())
lock = lambda d: {
    (r["name"], r["version"]): r
    for r in tomllib.loads((d / "Cargo.lock").read_text())["package"]
}
old, new = lock(oldsrc), lock(ref)
assert not (old.keys() - new.keys())
assert {n for n, v in new.keys() - old.keys()} == {
    "cc",
    "shlex",
    "find-msvc-tools",
    "tikv-jemallocator",
    "tikv-jemalloc-sys",
}
for key in old:
    if key[0] == "relar-conformance-report-reference":
        assert set(new[key]["dependencies"]) == set(old[key]["dependencies"]) | {
            "tikv-jemallocator"
        }
    else:
        assert new[key] == old[key]
report["lock_delta"] = {n: v for n, v in sorted(new.keys() - old.keys())}
report["allocator_crate_sha256"] = new["tikv-jemallocator", "0.6.1"]["checksum"]
report["sys_crate_sha256"] = next(
    r["checksum"] for (n, v), r in new.items() if n == "tikv-jemalloc-sys"
)
assert (
    report["allocator_crate_sha256"]
    == "0359b4327f954e0567e69fb191cf1436617748813819c94b8cd4a431422d053a"
)
assert (
    report["sys_crate_sha256"]
    == "cd8aa5b2ab86a2cefa406d889139c162cbb230092f7d1d7cbc1716405d852a3b"
)
for mode in ("normal", "thinlto"):
    f = root / mode / "conformance-report-reference"
    oldbin = c / "build-rust" / mode / "conformance-report-reference"
    r = read(root / mode / "build-record.json")
    oldr = read(c / "export" / mode / "records/rust.json")
    assert r["thinlto"] == oldr["thinlto"] == (mode == "thinlto")
    assert (
        r["llvm_budget"] == oldr["llvm_budget"]
        and r["tool_sha256"] == oldr["tool_sha256"]
        and r["rustc_verbose"] == oldr["rustc_verbose"]
    )
    assert sha(f.read_bytes()) == r["binary_sha256"]
    assert sha(oldbin.read_bytes()) == oldr["binary_sha256"]
    dyn = run(["readelf", "-d", str(f)]).decode()
    needed = re.findall(r"Shared library: \[([^]]+)\]", dyn)
    assert "libc.so.6" in needed and all("jemalloc" not in n for n in needed)
    nm = run(["nm", "-C", "--defined-only", str(f)]).decode()
    original = run(["nm", "-C", "--defined-only", str(oldbin)]).decode()
    assert all(
        re.search(r"^\w+ T " + fn + r"$", nm, re.M)
        for fn in ("_rjem_malloc", "_rjem_mallocx", "_rjem_sdallocx")
    )
    assert "_rjem_malloc" not in original
    listing = run(["objdump", "-d", "-C", "--no-show-raw-insn", str(f)]).decode()
    calls = []
    labels = {
        int(addr, 16): name
        for addr, name in re.findall(
            r"^(\w+) [Tt] (_rjem_(?:malloc|mallocx|dallocx|sdallocx|realloc|free))$",
            nm,
            re.M,
        )
    }
    relocations = run(["readelf", "-rW", str(f)]).decode()
    target = {
        int(slot, 16): labels[int(addr, 16)]
        for slot, addr in re.findall(
            r"^(\w+)\s+\w+\s+R_X86_64_RELATIVE\s+([0-9a-f]+)$", relocations, re.M
        )
        if int(addr, 16) in labels
    }
    label = ""
    for line in listing.splitlines():
        m = re.match(r"^\w+ <(.+)>:$", line)
        if m:
            label = m[1]
            continue
        if (
            "::" not in label
            or "jemalloc" in label.lower()
            or not re.search(r"\b(call|jmp)\w*\s+", line)
        ):
            continue
        direct = re.search(
            r" <(_rjem_(?:malloc|mallocx|dallocx|sdallocx|realloc|free))>$", line
        )
        indirect = re.search(r"#\s*([0-9a-f]+) <", line)
        name = (
            direct[1]
            if direct
            else target.get(int(indirect[1], 16))
            if indirect
            else None
        )
        if name and len(calls) < 18:
            calls.append(
                {
                    "from": label,
                    "to": name,
                    "via": "direct" if direct else "ELF relative relocation",
                }
            )
    assert calls, mode
    casechecks = {}
    output = root / mode / "verified-output.md"
    for scale in (1, 10):
        for state in ("changed", "unchanged"):
            panel = c / "fixtures" / f"{scale}x" / state
            args = [
                str(panel / (name + ".json")) for name in ("manifest", "old", "new")
            ]
            for op in ("aliases", "dump"):
                out = run([str(f), "--grouping", op, *args, "1"], env=env)
                gold = (c / "export" / mode / f"{scale}x-{state}-{op}.txt").read_bytes()
                assert out == gold
                casechecks[f"{scale}-{state}-{op}"] = sha(out)
            for fmt in ("github", "diff"):
                work = val["Workload"](*(Path(name) for name in args), fmt)
                output.unlink(missing_ok=True)
                assert not run(
                    [str(f), *work.arguments(), "--output", str(output)], env=env
                )
                gold = (c / "export" / mode / f"{scale}x-{state}-{fmt}.md").read_bytes()
                assert output.read_bytes() == gold
                casechecks[f"{scale}-{state}-{fmt}"] = sha(gold)
    report["modes"][mode] = {
        "binary_sha256": sha(f.read_bytes()),
        "system_binary_sha256": sha(oldbin.read_bytes()),
        "build_record_sha256": sha((root / mode / "build-record.json").read_bytes()),
        "needed": needed,
        "allocator_symbols": ["T _rjem_malloc", "T _rjem_mallocx", "T _rjem_sdallocx"],
        "rust_to_allocator_calls": calls,
        "output_sha256": casechecks,
    }
    print(
        mode,
        "verified",
        report["modes"][mode]["binary_sha256"],
        len(casechecks),
        needed,
        flush=True,
    )
(root / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
