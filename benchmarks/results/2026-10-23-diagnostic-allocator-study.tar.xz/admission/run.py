"""Compare the static jemalloc runtime with the shipping runtime and Rust on both allocators."""

import argparse
import contextlib
import hashlib
import json
import os
import runpy
import shutil
import subprocess
import time
from pathlib import Path
from statistics import median


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    stage = path.with_suffix(".tmp")
    stage.write_text(json.dumps(value, indent=2) + "\n")
    stage.replace(path)


@contextlib.contextmanager
def shorter_root(path, canonical):
    assert path.parent == Path("/tmp") and not path.exists()
    path.mkdir(mode=0o700)
    try:
        for directory in ("10x/tests", "10x/changed", "10x/unchanged"):
            (path / directory).mkdir(parents=True)
        for source in (canonical / "10x/tests").iterdir():
            dest = path / "10x/tests" / source.name
            try:
                os.link(source, dest)
            except OSError:
                shutil.copy2(source, dest)
            assert source.read_bytes() == dest.read_bytes()
        for state in ("changed", "unchanged"):
            for role in ("manifest", "old", "new"):
                source = canonical / "10x" / state / (role + ".json")
                dest = path / "10x" / state / source.name
                previous = source.read_bytes()
                altered = previous.replace(str(canonical).encode(), str(path).encode())
                dest.write_bytes(altered)
                assert (
                    altered.replace(str(path).encode(), str(canonical).encode())
                    == previous
                )
        yield path
    finally:
        shutil.rmtree(path)


def sample(command, expected, env, output=None):
    if output:
        output.unlink(missing_ok=True)
    t = time.perf_counter_ns()
    run = subprocess.run(
        command,
        capture_output=True,
        stdin=subprocess.DEVNULL,
        env=env,
        timeout=180,
        check=True,
    )
    elapsed = time.perf_counter_ns() - t
    assert not run.stderr
    if output:
        assert not run.stdout
        body = output.read_bytes()
    else:
        body = run.stdout
    assert body == expected, (command, sha(body), sha(expected))
    return {"ns": elapsed, "output_sha256": sha(body)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frozen", required=True, type=Path)
    parser.add_argument("--staged", required=True, type=Path)
    parser.add_argument("--cpu", type=int, default=31)
    args = parser.parse_args()
    frozen = args.frozen.resolve()
    candidate = args.staged.resolve()
    out = candidate / "admission"
    out.mkdir(exist_ok=False)
    result_file = out / "results.json"
    dest = out / "publication.md"
    os.sched_setaffinity(0, {args.cpu})
    src = frozen / "source/benchmarks"
    shared = runpy.run_path(str(src / "conformance_regex_benchmark.py"))
    val = shared["VALIDATION"]
    env = val["environment"](out)
    previous = read(frozen / "path-sensitivity/comparison.json")
    canonical = Path(previous["input_root"])
    short = Path(previous["short_root"])
    new_meta = read(candidate / "candidate.json")
    record = {
        "schema": 1,
        "source": new_meta,
        "baseline_revision": previous["revision"],
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "host": os.uname().nodename,
        "samples": 16,
        "warmups": 1,
        "repeats": 12,
        "grouping_limit": 2.0,
        "full_candidate_over_rust_limit": 2.0,
        "full_candidate_over_previous_limit": 1.05,
        "roots": {"long": str(canonical), "short": str(short)},
        "cases": {},
        "preflight": {},
        "completed": False,
    }
    modes = ("normal", "thinlto")
    roles = ("base", "candidate", "rust", "matched_rust")
    variants = ("long", "short")
    keys = tuple(f"{role}-{variant}" for variant in variants for role in roles)
    # Williams design for eight treatments. Sixteen samples repeat every position and every directed neighbor twice.
    first = (0, 1, -1, 2, -2, 3, -3, 4)
    schedule = [[keys[(i + j) % 8] for j in first] for i in range(8)]
    assert len({(a, b) for row in schedule for a, b in zip(row, row[1:])}) == 56
    record["schedule"] = schedule
    cfg = {mode: read(frozen / "configs" / mode / "config.json") for mode in modes}
    for mode in modes:
        assert cfg[mode]["revision"] == record["baseline_revision"]
        new_cmd = new_meta["modes"][mode]
        matched = candidate / mode / "matched-rust"
        assert sha(matched.read_bytes()) == new_cmd["matched_rust"]["sha256"]
        for operation in ["analysis", "report"]:
            path = candidate / mode / operation
            assert sha(path.read_bytes()) == new_cmd[operation]["sha256"]
            for engine in ("after", "rust"):
                exe = Path(cfg[mode]["engines"][engine][operation][0])
                assert sha(exe.read_bytes()) == next(
                    i["sha256"]
                    for i in cfg[mode]["guarded_inputs"]
                    if i["path"] == str(exe)
                )

    def cmd(mode, engine, kind):
        if engine == "matched_rust":
            return [
                str(candidate / mode / "matched-rust"),
                *(["--grouping"] if kind == "analysis" else []),
            ]
        if engine == "candidate":
            return [str(candidate / mode / kind)]
        return cfg[mode]["engines"]["after" if engine == "base" else "rust"][kind]

    with shorter_root(short, canonical):
        roots = {"long": canonical, "short": short}
        suites = {}
        for var, path in roots.items():
            for state in ("changed", "unchanged"):
                panel = path / "10x" / state
                suites[var, state] = [
                    str(panel / (k + ".json")) for k in ("manifest", "old", "new")
                ]

        def gold(mode, var, filename):
            data = (frozen / "measurements" / mode / filename).read_bytes()
            return data.replace(str(canonical).encode(), str(roots[var]).encode())

        for mode in modes:
            for var, path in roots.items():
                checked = record["preflight"][f"{mode}/{var}"] = {}
                for state in ("changed", "unchanged"):
                    arguments = suites[var, state]
                    for role in roles:
                        pointer = cmd(mode, role, "analysis")
                        for op in ("dump", "aliases"):
                            body = gold(mode, var, f"10x-{state}-{op}.txt")
                            obs = sample([*pointer, op, *arguments, "1"], body, env)
                            checked[f"{role}-{state}-{op}"] = obs["output_sha256"]
                        for fmt in ("github", "diff"):
                            body = gold(mode, var, f"10x-{state}-{fmt}.md")
                            w = val["Workload"](*(Path(p) for p in arguments), fmt)
                            obs = sample(
                                [
                                    *cmd(mode, role, "report"),
                                    *w.arguments(),
                                    "--output",
                                    str(dest),
                                ],
                                body,
                                env,
                                dest,
                            )
                            checked[f"{role}-{state}-{fmt}"] = obs["output_sha256"]
        save(result_file, record)
        for operation in ("group", "changed-github", "unchanged-github"):
            panels = {
                mode: {"samples": [], "rounds": 12 if operation == "group" else 1}
                for mode in modes
            }
            for mode, panel in panels.items():
                record["cases"][f"{mode}/{operation}"] = panel
            for i in range(-1, 16):
                for m, mode in enumerate(modes if i % 2 == 0 else modes[::-1]):
                    row = []
                    for pos, key in enumerate(
                        schedule[(i + (3 if mode == "thinlto" else 0)) % len(schedule)]
                    ):
                        role, var = key.split("-")
                        obs = {"engine": key}
                        reps = panels[mode]["rounds"]
                        if operation == "group":
                            obs["order"] = (
                                [0, reps] if (i + pos + m) % 2 == 0 else [reps, 0]
                            )
                            # The frozen Ruff transcript independently gives this checked per-pass score.
                            for n in obs["order"]:
                                body = f"{799131362 * n}\n".encode()
                                obs["repeat" if n else "zero"] = sample(
                                    [
                                        *cmd(mode, role, "analysis"),
                                        "group",
                                        *suites[var, "changed"],
                                        str(n),
                                    ],
                                    body,
                                    env,
                                )
                        else:
                            state, fmt = operation.split("-")
                            work = val["Workload"](
                                *(Path(p) for p in suites[var, state]), fmt
                            )
                            body = gold(mode, var, f"10x-{operation}.md")
                            obs["repeat"] = sample(
                                [
                                    *cmd(mode, role, "report"),
                                    *work.arguments(),
                                    "--output",
                                    str(dest),
                                ],
                                body,
                                env,
                                dest,
                            )
                        row.append(obs)
                    if i < 0:
                        panels[mode]["warmup"] = row
                    else:
                        panels[mode]["samples"].append(row)
                save(result_file, record)
            for mode, panel in panels.items():
                med = {
                    k: median(
                        (
                            v["repeat"]["ns"]
                            - (v["zero"]["ns"] if operation == "group" else 0)
                        )
                        / panel["rounds"]
                        for row in panel["samples"]
                        for v in row
                        if v["engine"] == k
                    )
                    for k in keys
                }
                assert min(med.values()) > 0
                panel["median_ns"] = med
                panel["ratios"] = {
                    var: {
                        "candidate_over_rust": med["candidate-" + var]
                        / med["rust-" + var],
                        "candidate_over_matched_rust": med["candidate-" + var]
                        / med["matched_rust-" + var],
                        "matched_rust_over_system_rust": med["matched_rust-" + var]
                        / med["rust-" + var],
                        "candidate_over_base": med["candidate-" + var]
                        / med["base-" + var],
                        "base_over_rust": med["base-" + var] / med["rust-" + var],
                    }
                    for var in variants
                }
                print(
                    mode,
                    operation,
                    {k: round(v / 1e6, 4) for k, v in med.items()},
                    panel["ratios"],
                    flush=True,
                )
            save(result_file, record)
            if operation == "group":
                record["kernel_gate"] = all(
                    max(
                        p["ratios"][var]["candidate_over_rust"],
                        p["ratios"][var]["candidate_over_matched_rust"],
                    )
                    <= 2
                    for p in panels.values()
                    for var in variants
                )
        record["full_gate"] = all(
            max(vals["candidate_over_rust"], vals["candidate_over_matched_rust"]) <= 2
            and vals["candidate_over_base"] <= 1.05
            for name, p in record["cases"].items()
            if not name.endswith("/group")
            for vals in p["ratios"].values()
        )
        record["admitted"] = record["full_gate"] and record["kernel_gate"]
        record["completed"] = True
        save(result_file, record)
    print("admitted", record["admitted"], flush=True)


if __name__ == "__main__":
    main()
