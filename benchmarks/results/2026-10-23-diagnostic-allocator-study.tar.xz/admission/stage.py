"""Bind the frozen static-allocator candidate and the otherwise identical Rust allocator control."""

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from pathlib import Path


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def strip_init(b):
    return b"".join(
        line
        for line in b.splitlines(keepends=True)
        if b"@imre_init_native_heap" not in line
    )


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("revision")
a = p.parse_args()
c = Path(__file__).resolve().parents[1]
old = c / "final-7178431"
f = c / ("final-" + a.revision[:7])
r = c / "rust-jemalloc-control"
src = c / ("static-allocator-" + a.revision[:7])
dst = c / ("native-allocator-" + a.revision[:7])
dst.mkdir(exist_ok=False)
ref = read(r / "validation.json")
assert (
    len(ref["modes"]) == 2
    and ref["preparation"]["base_revision"]
    == read(old / "source/checkout.json")["revision"]
)
shutil.copy2(r / "validation.json", dst / "matched-validation.json")
shutil.copy2(
    (src / ("candidate-" + a.revision[:7] + ".tar.gz") if a.revision.startswith("a91b337") else src / ("source-" + a.revision[:7] + ".tar.gz")), dst / "candidate-source.tar.gz"
)
shutil.copy2(c / "allocator-tools/run.py", dst / "run.py")
record = {
    "revision": a.revision,
    "baseline_revision": read(old / "source/checkout.json")["revision"],
    "allocator": "tikv-jemallocator 0.6.1 (vendored), default-features=false, background_threads_runtime_support",
    "source_archive_sha256": sha(dst / "candidate-source.tar.gz"),
    "recipe_sha256": sha(dst / "run.py"),
    "matched_validation_sha256": sha(r / "validation.json"),
    "modes": {},
}
for mode in ("normal", "thinlto"):
    out = dst / mode
    out.mkdir()
    entries = {}
    record["modes"][mode] = entries
    for op, sub, role in [
        ("analysis", "kernels", "kernel-after"),
        ("report", "programs", "program-after"),
    ]:
        newrec = src / "build-final" / sub / mode / "build-record.json"
        oldrec = old / "export" / mode / "records" / (role + ".json")
        n = read(newrec)
        b = read(oldrec)
        assert (
            n["status"] == "passed"
            and n["revision"] == a.revision
            and n["mode"] == b["mode"] == mode
            and n["tools"] == b["tools"]
        )
        bv = n["binary"] if op == "analysis" else n["binaries"]["conformance_report"]
        llvm = n["llvm"] if op == "analysis" else n["llvm"]["conformance_report"]
        old_llvm = b["llvm"] if op == "analysis" else b["llvm"]["conformance_report"]
        ir = Path(llvm["path"])
        content = ir.read_bytes()
        assert (
            sha(ir) == llvm["sha256"]
            and content.count(b"@imre_init_native_heap") == (2 if a.revision.startswith("a91b337") else 0)
            and strip_init(content) == Path(old_llvm["path"]).read_bytes()
        )
        binary = Path(bv["path"])
        assert sha(binary) == bv["sha256"]
        lib = subprocess.check_output(["readelf", "-d", binary], text=True)
        assert not any(
            "jemalloc" in line and "(NEEDED)" in line for line in lib.splitlines()
        )
        symbols = subprocess.check_output(
            ["nm", "--defined-only", str(binary)], text=True
        )
        assert re.search(r"^\w+ [Tt] _rjem_mallocx$", symbols, re.M)
        shutil.copy2(binary, out / op)
        shutil.copy2(newrec, out / (op + "-build.json"))
        entries[op] = {
            "sha256": sha(out / op),
            "llvm_sha256": sha(ir),
            "original_llvm_sha256": old_llvm["sha256"],
            "build_receipt_sha256": sha(newrec),
        }
    rust = r / mode / "conformance-report-reference"
    rec = r / mode / "build-record.json"
    assert (
        sha(rust) == ref["modes"][mode]["binary_sha256"] == read(rec)["binary_sha256"]
    )
    shutil.copy2(rust, out / "matched-rust")
    shutil.copy2(rec, out / "matched-rust-build.json")
    entries["matched_rust"] = {"sha256": sha(rust), "build_receipt_sha256": sha(rec)}
(dst / "candidate.json").write_text(json.dumps(record, indent=2) + "\n")
shutil.copy2(Path(__file__), dst / "stage.py")
arc = c / (dst.name + ".tar.gz")
with tarfile.open(arc, "w:gz", compresslevel=3) as tar:
    tar.add(dst, arcname=dst.name)
print(arc, arc.stat().st_size, sha(arc), flush=True)
subprocess.run(
    [
        "python3.14",
        "-B",
        str(f / "stage-builds.py"),
        "--cache",
        str(src),
        "--stage",
        "candidate",
        "--revision",
        a.revision,
    ],
    check=True,
)
