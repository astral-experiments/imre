"""Seal only the completed intermediate-selector panels, with source, independently checkable observations and limits."""

import argparse, hashlib, json, runpy, shutil, subprocess, sys, tarfile, tempfile
from pathlib import Path


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def cp(s, d):
    d.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(s, d)


def norm(i):
    i.mtime = i.uid = i.gid = 0
    i.uname = i.gname = ""
    i.mode = 0o755 if i.isdir() else 0o644
    return i


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("cache", type=Path)
a = p.parse_args()
f = a.cache.resolve()
c = f.parent
g = c / "native-allocator-a91b337"
build = c / "static-allocator-a91b337"
prev = c / "final-7178431/portable-audited"
source = f / "source"
mode = f / "export/normal"
src = source / "benchmarks"
artifact = f / "measured-selector.tar.xz"
assert not artifact.exists()
review = runpy.run_path(str(src / "conformance_grouping_audit.py"))["audit"](mode)
assert (
    review == read(mode / "strict-audit.json")
    and review["observations"] == 1872
    and review["time_target_met"]
)
raw = read(mode / "results.json")
bind = runpy.run_path(str(f / "bind-builds.py"))["dissect"]
assert bind(raw["config"], mode / "records") == read(mode / "binding.json")
entries = [
    x for x in mode.iterdir() if x.suffix in (".md", ".txt") and x.name != "report.md"
]
assert len(entries) == 16 and all(
    e.read_bytes() == (prev / "modes/normal" / e.name).read_bytes() for e in entries
)
gate = json.loads(
    subprocess.check_output(
        [
            sys.executable,
            "-B",
            str(c / "allocator-tools/gate-audit.py"),
            "--study",
            str(prev),
            "--raw",
            str(g / "results.json"),
        ]
    )
)
assert (
    gate == read(g / "audit.json") and gate["admitted"] and gate["observations"] == 1088
)
with tempfile.TemporaryDirectory(dir=f) as td:
    d = Path(td)
    m = d / "mode-normal"
    m.mkdir()
    for n in ("results.json", "strict-audit.json", "validation.json", "binding.json"):
        cp(mode / n, m / n)
    shutil.copytree(mode / "records", m / "records")
    cp(source / "checkout.json", d / "checkout.json")
    for n in (
        "results.json",
        "audit.json",
        "candidate.json",
        "candidate-source.tar.gz",
        "run.py",
        "stage.py",
    ):
        cp(g / n, d / "admission" / n)
    for n in ("admission-build-all.json", "build-qa.json", "build-qa.tar.gz"):
        cp(build / n, d / "build-qa" / n)
    for label in ("relar", "rust-identical-flags"):
        shutil.copytree(f / "profiles" / label, d / "profiles" / label)
    info = {
        "revision": review["revision"],
        "completed": "six-engine ordinary 16 cases and held-out native normal/Thin grouping plus changed and unchanged reports on two roots",
        "unmeasured": [
            "six-engine ThinLTO",
            "six-engine process RSS",
            "all-workload matched-Rust supplement",
        ],
        "six_engine": review,
        "native": gate,
        "canonical_full_output_sha256": {e.name: sha(e) for e in entries},
        "source_and_builds": read(source / "checkout.json")["files"],
        "files": {
            str(e.relative_to(d)): sha(e) for e in sorted(d.rglob("*")) if e.is_file()
        },
    }
    (d / "index.json").write_text(json.dumps(info, indent=2) + "\n")
    with tarfile.open(artifact, "w:xz", preset=6) as tar:
        for e in sorted(d.rglob("*")):
            tar.add(e, arcname=str(e.relative_to(d)), filter=norm, recursive=False)
print(artifact, artifact.stat().st_size, sha(artifact), flush=True)
