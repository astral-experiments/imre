"""Verify the static allocator candidate against both Rust allocators, including all held-out outputs and timings."""

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
from statistics import median


def read(path):
    return json.loads(path.read_bytes())


def digest(b):
    return hashlib.sha256(b).hexdigest()


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--study", type=Path, required=True)
p.add_argument("--raw", type=Path, required=True)
args = p.parse_args()
study = args.study.resolve()
raw = read(args.raw)
assert (
    raw["completed"]
    and raw["samples"] == 16
    and raw["warmups"] == 1
    and raw["repeats"] == 12
)
assert raw["kernel_gate"] == (
    all(
        max(vals["candidate_over_rust"], vals["candidate_over_matched_rust"]) <= 2
        for key, case in raw["cases"].items()
        if key.endswith("/group")
        for vals in case["ratios"].values()
    )
)
assert raw["cpu_affinity"] == [31] and raw["host"] == "charlie-oss-8"
assert (
    raw["source"]["baseline_revision"]
    == raw["baseline_revision"]
    == read(study / "index.json")["revision"]
)
assert (
    raw["grouping_limit"] == raw["full_candidate_over_rust_limit"] == 2
    and raw["full_candidate_over_previous_limit"] == 1.05
)
modes = ("normal", "thinlto")
variants = ("long", "short")
roles = ("base", "candidate", "rust", "matched_rust")
schedule = raw["schedule"]
assert len(schedule) == 8
assert all(
    set(perm) == {f"{e}-{v}" for e in roles for v in variants} for perm in schedule
)
assert all(len({perm[i] for perm in schedule}) == 8 for i in range(8))
assert len(Counter((a, b) for perm in schedule for a, b in zip(perm, perm[1:]))) == 56
sensitivity = read(study / "path-sensitivity.json")
assert raw["roots"] == {
    "long": sensitivity["input_root"],
    "short": sensitivity["short_root"],
}
observed = 0
ratios = {}
assert set(raw["cases"]) == {
    f"{m}/{op}" for m in modes for op in ("group", "changed-github", "unchanged-github")
}
for mode in modes:
    folder = study / "modes" / mode
    for variant in variants:

        def bytes_for(f):
            return (
                (folder / f)
                .read_bytes()
                .replace(raw["roots"]["long"].encode(), raw["roots"][variant].encode())
            )

        expected = {
            f"{engine}-{state}-{kind}": digest(
                bytes_for(
                    f"10x-{state}-{kind}.{'txt' if kind in ('dump', 'aliases') else 'md'}"
                )
            )
            for engine in roles
            for state in ("changed", "unchanged")
            for kind in ("dump", "aliases", "github", "diff")
        }
        assert raw["preflight"][f"{mode}/{variant}"] == expected
    for op in ("group", "changed-github", "unchanged-github"):
        case = raw["cases"][f"{mode}/{op}"]
        n = case["rounds"]
        assert len(case["samples"]) == 16 and n == (12 if op == "group" else 1)
        elapsed = {k: [] for k in schedule[0]}
        for i, row in enumerate([case["warmup"], *case["samples"]], -1):
            assert [s["engine"] for s in row] == schedule[
                (i + (3 if mode == "thinlto" else 0)) % 8
            ]
            mode_index = (modes if i % 2 == 0 else modes[::-1]).index(mode)
            for position, v in enumerate(row):
                key = v["engine"]
                role, var = key.split("-")
                measured = v["repeat"]
                assert measured["ns"] > 0
                if op == "group":
                    assert v["order"] == (
                        [0, 12] if (i + position + mode_index) % 2 == 0 else [12, 0]
                    )
                    assert v["zero"]["output_sha256"] == digest(b"0\n") and measured[
                        "output_sha256"
                    ] == digest(f"{799131362 * n}\n".encode())
                    elapsed_ns = (measured["ns"] - v["zero"]["ns"]) / n
                    assert v["zero"]["ns"] > 0
                    observed += 2
                else:
                    original = (
                        (folder / f"10x-{op}.md")
                        .read_bytes()
                        .replace(
                            raw["roots"]["long"].encode(), raw["roots"][var].encode()
                        )
                    )
                    assert measured["output_sha256"] == digest(original)
                    elapsed_ns = measured["ns"]
                    observed += 1
                if i >= 0:
                    elapsed[key].append(elapsed_ns)
        med = {key: median(ns) for key, ns in elapsed.items()}
        assert med == case["median_ns"] and min(med.values()) > 0
        calc = {
            v: {
                "candidate_over_rust": med["candidate-" + v] / med["rust-" + v],
                "candidate_over_base": med["candidate-" + v] / med["base-" + v],
                "candidate_over_matched_rust": med["candidate-" + v]
                / med["matched_rust-" + v],
                "matched_rust_over_system_rust": med["matched_rust-" + v]
                / med["rust-" + v],
                "base_over_rust": med["base-" + v] / med["rust-" + v],
            }
            for v in variants
        }
        assert calc == case["ratios"]
        ratios[f"{mode}/{op}"] = calc
assert observed == 1088
kernel = all(
    max(vals["candidate_over_rust"], vals["candidate_over_matched_rust"]) <= 2
    for key, rat in ratios.items()
    if key.endswith("/group")
    for vals in rat.values()
)
full = all(
    max(vals["candidate_over_rust"], vals["candidate_over_matched_rust"]) <= 2
    and vals["candidate_over_base"] <= 1.05
    for key, rat in ratios.items()
    if not key.endswith("/group")
    for vals in rat.values()
)
assert (
    raw["kernel_gate"] == kernel
    and raw["full_gate"] == full
    and raw["admitted"] == (kernel and full)
)
print(
    json.dumps(
        {
            "admitted": kernel and full,
            "kernel_gate": kernel,
            "full_gate": full,
            "observations": observed,
            "preflight_processes": 128,
            "revision": raw["source"]["revision"],
            "raw_sha256": digest(args.raw.read_bytes()),
            "ratios": ratios,
        },
        indent=2,
    )
)
