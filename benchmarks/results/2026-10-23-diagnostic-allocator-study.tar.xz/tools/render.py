"""Render all native, CPython and Codon comparisons from the independently replayed observations."""

import argparse
import json
import tarfile
from pathlib import Path


def read(path):
    return json.loads(path.read_bytes())


def dec(n):
    return f"{n / 1e6:,.3f}"


def ratio(x):
    return f"{x:.3f}×"


def row(*vals):
    return "| " + " | ".join(map(str, vals)) + " |"


def table(head, rows):
    return [row(*head), row(*["---" for _ in head]), *[row(*r) for r in rows], ""]


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("study", type=Path)
p.add_argument("output", type=Path)
p.add_argument("audit", type=Path)
a = p.parse_args()
d = a.study
q = read(a.audit)
rev = q["revision"]
modes = ("normal", "thinlto")
names = {"normal": "Ordinary", "thinlto": "ThinLTO"}
gate = read(d / "admission/results.json")
pri = {m: read(d / "modes" / m / "results.json") for m in modes}
strong = {m: read(d / "matched" / m / "results.json") for m in modes}
with tarfile.open(d / "previous-study.tar.xz") as old:
    loads = lambda name: json.load(old.extractfile(name))
    old_rss = {m: loads(f"modes/{m}/rss.json") for m in modes}
    old_profile = {
        e: loads(f"profiles/{e}/callgrind-summary.json")["net_per_pass"]["instructions"]
        for e in ("after", "rust")
    }
    old_allocations = {
        e: loads(f"profiles/{e}/dhat-summary.json")["net_per_pass"]
        for e in ("after", "rust")
    }
    old_paths = loads("path-sensitivity.json")
label = {
    "group": "Group diagnostic records",
    "equivalent": "Compare diagnostics",
    "files": "Collect file statistics",
    "compute": "Repeat full report computation",
    "report": "Complete report",
}
with tarfile.open(d / "experiments/other-programs.tar.gz") as f:
    collateral = json.load(f.extractfile("explicit-system/split-summary.json"))[
        "controls"
    ]
heading = a.output.name[:-3]
max_primary = max(v["largest_ratio"] for v in q["primary"].values())
max_strong = max(v["worst_matched"] for v in q["matched_rust"].values())
primary_max = max((v, m, n) for m in modes for n, v in pri[m]["ratios"].items())
matched_max = max(
    (v["ratios"]["after_over_matched_rust"], m, n)
    for m in modes
    for n, v in strong[m]["cases"].items()
)
assert primary_max[0] == max_primary and matched_max[0] == max_strong


def case_title(item):
    _, mode, panel = item
    scale, state, op = panel.split("/")
    name = {
        "group": "grouping",
        "equivalent": "diagnostic equivalence",
        "files": "per-file statistics",
        "compute": "repeated report computation",
        "report": state.replace("-", " ") + " reporting",
    }[op]
    return f"{name} on {int(scale[:-1]) * 146:,} files ({names[mode]})"


vals = [
    v
    for k, x in q["admission"]["ratios"].items()
    if k.endswith("/group")
    for v in x.values()
]
lines = [
    "# Native allocation in Ruff’s diagnostic grouping",
    "",
    f"For Ruff’s isolated grouping pass over 1,460 files, Relar built with `--allocator jemalloc` used {ratio(min(v['candidate_over_matched_rust'] for v in vals))}–{ratio(max(v['candidate_over_matched_rust'] for v in vals))} the time of Rust with the same allocator in the four ordinary/ThinLTO and short/long checkout combinations. That is {100 * min(v['candidate_over_base'] for v in vals):.1f}–{100 * max(v['candidate_over_base'] for v in vals):.1f}% of the time taken by the same Relar application compiled from identical LLVM IR with the System heap. The largest ratio in the six-engine matrix was {ratio(max_primary)} for {case_title(primary_max)} against system-allocator Rust. The largest against matched jemalloc Rust was {ratio(max_strong)} for {case_title(matched_max)}.",
    "",
    f"The measured Relar source is `{rev}`. The Python reporter, pinned Ruff upstream and both original comparator programs retain the preceding study’s 56 source identities. Linux native builds default to the System archive. `relar build script.py --allocator jemalloc` selects the separate self-contained archive used for the performance results below. The System archive contains the ordinary Rust system allocator. The separate jemalloc archive uses `tikv-jemallocator 0.6.1` with the same `background_threads_runtime_support` feature as the matched Rust reference. The application’s complete emitted grouping, report and compute LLVM modules are byte-identical to the preceding system-heap build in both link modes. ASan and macOS use the System archive. These timing measurements were taken on Linux x86-64. [Previous grouping study](2026-10-23-diagnostic-grouping.md) · [Pinned native allocator source](https://github.com/astral-sh/relar/blob/aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5/crates/relar-runtime-jemalloc/src/lib.rs)",
    "",
    "The release CLI was checked at `e483582`. Its relevant source trees match the integrated `e78c84a` checkout used for the live reporter. Rebuilding the 15 System, jemalloc and ASan program combinations with the recorded temporary LLVM filename reproduced their complete ELF bytes and emitted IR. The recorded filename preserves the ELF input-file metadata.",
    "",
    "## Checkout path and allocation control",
    "",
    "The same-host admission compares the preceding Ruff program on the System heap, the current program, original Rust and Rust using the identical allocator. The input has 12,690 diagnostic groups, 1,460 distinct source filenames and a separately checked, fully ordered diagnostic stream. The long and short checkouts have 71 and 24 shared path-prefix bytes respectively at this scale. Every median is the in-process work per pass from a fresh paired zero/12-round process observation. The eight engine/path treatments rotate through 16 balanced orders.",
    "",
]
r = []
for m in modes:
    for path in ("long", "short"):
        g = gate["cases"][m + "/group"]
        t = g["median_ns"]
        v = g["ratios"][path]
        r.append(
            [
                names[m],
                path,
                *[
                    dec(t[e + "-" + path])
                    for e in ("base", "candidate", "rust", "matched_rust")
                ],
                ratio(v["candidate_over_rust"]),
                ratio(v["candidate_over_matched_rust"]),
            ]
        )
lines += table(
    [
        "Link",
        "Checkout",
        "Prior Relar ms",
        "Relar ms",
        "Rust System ms",
        "Rust jemalloc ms",
        "Relar / Rust System",
        "Relar / Rust jemalloc",
    ],
    r,
)
orig = [
    v
    for k, panel in old_paths["panels"].items()
    if k.endswith("/10")
    for v in panel["ratios"].values()
]
whole = [
    v["candidate_over_base"]
    for key, vs in q["admission"]["ratios"].items()
    if not key.endswith("/group")
    for v in vs.values()
]
lines += [
    f"The default System heap reached {ratio(max(orig))} on the prior short-root ThinLTO treatment, above the 2× target. The current default reproduces every file-backed mapped ELF section of all six prior grouping, report and compute binaries except the 20-byte GNU build ID. Packed-record and borrowed-key experiments retained that limit and were excluded. The opt-in allocator’s 1,460-file complete report times in the eight same-schedule change-state, root and mode combinations were {ratio(min(whole))}–{ratio(max(whole))} the time of the prior system-heap Relar. The archive contains that earlier candidate’s failed admission, the intermediate selector’s completed ordinary panel, four grouping comparisons and eight full-report comparisons across both checkout roots and link modes.",
    "",
    "The prior typed-string port skipped filesystem resolution in `collect_file_stats`. With two path aliases for one source its validator produces five file rows where Ruff, current Relar and Rust produce four. The current grouping and statistics implementations and the Rust comparator resolve the filesystem paths on each measured pass. [Codon adapters](../codon_native/README.md) · [Ruff grouping comparison](2026-10-23-diagnostic-grouping.md)",
    "",
    "## Six engines across both link modes",
    "",
    "Times are milliseconds. CPython runs the original Ruff implementations and the current typed port. Relar before uses the genuine prior typed-string program at `1784527`. Native Codon 0.20.4 uses concrete lists and dictionaries, native JSON, RE2, native `Path` resolution and signed 64-bit integers. The original Rust implementation uses its normal System heap. Changed runs compare ty 0.0.60 with 0.0.90, and unchanged runs compare 0.0.90 with itself. All engines process the same source and analyzer records. Every complete report and ordered diagnostic dump is checked against Ruff. Each panel includes a warmup and 12 balanced measured observations per implementation. The two six-engine matrices retain 3,744 individual process runs, the matched three-engine matrices 1,872, and the two-root admission another 1,088. Kernel/repeated-compute timings subtract interleaved input/preload controls. Complete reports start a fresh CLI, read the saved analyzer outputs and source files, and publish the report. The live-checkout panel below measures running both ty analyzers as well. The matched-Rust ratio in the last column comes from an independent three-engine panel, with a fresh Relar numerator and both Rust heap choices.",
    "",
]
for m in modes:
    lines += ["### " + names[m], ""]
    cases = pri[m]["cases"]
    r = []
    for key, item in cases.items():
        scale, state, op = key.split("/")
        n = item["median_ns"]
        rat = strong[m]["cases"][key]["ratios"]
        pretty = label[op] + (" " + state.replace("-", " ") if op == "report" else "")
        r.append(
            [
                scale.replace("x", "×"),
                pretty,
                *[
                    dec(n[e])
                    for e in ("upstream", "cpython", "before", "after", "codon", "rust")
                ],
                ratio(n["after"] / n["rust"]),
                ratio(rat["after_over_matched_rust"]),
            ]
        )
    lines += table(
        [
            "Scale",
            "Workload",
            "Upstream CPython",
            "Typed CPython",
            "Relar before",
            "Relar",
            "Codon",
            "Rust System",
            "Relar / Rust System",
            "Relar / Rust jemalloc",
        ],
        r,
    )
lines += [
    "The primary and matched panels ran serially on CPU 31 of the same AMD EPYC-Milan Linux x86-64 host. Relar and Rust used clang 18.1.3 and Rust 1.99.0-dev (Ohm 1.99.0-7). The comparison engines included CPython 3.14.5 and AOT-native Codon 0.20.4. The matched three-engine panels retained the exact paired sample ordering, executable identities and both absolute native Rust denominators.",
    "",
]
for m in modes:
    keys = [
        "1x/changed-github/group",
        "10x/changed-github/group",
        "10x/changed-github/compute",
        "10x/changed-github/report",
    ]
    r = []
    for key in keys:
        z = strong[m]["cases"][key]
        n = z["median_ns"]
        r.append(
            [
                key,
                *[dec(n[e]) for e in ("after", "rust", "matched_rust")],
                ratio(z["ratios"]["after_over_matched_rust"]),
            ]
        )
    lines += ["**" + names[m] + " matched native milliseconds**", ""] + table(
        ["Case", "Relar", "Rust System", "Rust jemalloc", "Relar / Rust jemalloc"], r
    )
lines += [
    "## Memory, CPU and the live reporter",
    "",
    "Peak process RSS was measured separately for the complete changed GitHub report. Every engine published the same file in each of six measured fresh processes plus a warmup per input and link mode. Values below are MiB (KiB / 1,024).",
    "",
]
r = []
for m in modes:
    for scale in (1, 10):
        n = q["full_report_peak_kib"][f"{m}/{scale}"]
        old = old_rss[m]["cases"][str(scale)]["median_kib"]
        r.append(
            [
                names[m],
                f"{scale}×",
                f"{n['before'] / 1024:.1f}",
                f"{old['after'] / 1024:.1f}",
                *[
                    f"{n[e] / 1024:.1f}"
                    for e in ("after", "rust", "upstream", "cpython", "codon")
                ],
            ]
        )
lines += table(
    [
        "Link",
        "Scale",
        "Older typed port",
        "Prior Relar System",
        "Relar jemalloc",
        "Rust System",
        "Upstream CPython",
        "Typed CPython",
        "Codon",
    ],
    r,
)
lines += [
    "In the separate three-engine native RSS panel, all 84 published files matched the upstream oracle. Each cell is the median of six fresh processes after one warmup, using the same GNU time executable and isolated CPU.",
    "",
]
r = []
for mode in modes:
    for scale in ("1", "10"):
        cell = q["matched_native_peak"]["median_kib"][mode + "/" + scale]
        r.append(
            [
                names[mode],
                scale + "×",
                *[f"{cell[e] / 1024:.1f}" for e in ("after", "rust", "matched_rust")],
            ]
        )
lines += table(
    ["Native RSS, MiB", "Scale", "Relar jemalloc", "Rust System", "Rust jemalloc"], r
)
u = q["quality"]["live_median_ms"]
prof = q["callgrind"]
lines += [
    f"On a separate Linux host, all four live programs and their subprocesses shared the same two cores. The genuine 146-file checkout ran both pinned ty versions, 0.0.60 and 0.0.90, for each complete process. Across 12 balanced measurements per engine, upstream CPython took {u['upstream']:.2f} ms, default System Relar took {u['system']:.2f} ms, Relar with jemalloc took {u['jemalloc']:.2f} ms and Rust took {u['rust']:.2f} ms ({ratio(u['system'] / u['rust'])} and {ratio(u['jemalloc'] / u['rust'])} respectively). Each of the 52 warmup/measured runs published the complete 109,258-byte changed GitHub output. All four genuine changed/unchanged GitHub/diff files also matched by byte across the four programs.",
    "",
    f"On the separate profiling host, ordinary Callgrind counted {old_profile['after']:,.0f} guest instructions per 10× grouping pass on the old Relar System build and {prof['relar']['instructions_per_group']:,.0f} on this Relar jemalloc build. The unchanged Rust System and matched Rust jemalloc took {old_profile['rust']:,.0f} and {prof['rust']['instructions_per_group']:,.0f}. The zero/four-round profiles directly count zero/four calls to the grouping function. The profiles count instructions and the RSS study measures process high-water. Statically linked jemalloc serves allocations internally, beyond libc-based DHAT interception. In the preceding System-heap DHAT runs the same pass allocated {old_allocations['after']['tbk']:,.0f} blocks and {old_allocations['after']['tb'] / 1048576:.2f} MiB in Relar, versus {old_allocations['rust']['tbk']:,.0f} blocks and {old_allocations['rust']['tb'] / 1048576:.2f} MiB in Rust.",
    "",
    "## Effects on other programs",
    "",
    "The allocator trade-off depends on the program. On a separate pinned core, unchanged Base45 decoding was about 9% slower with direct jemalloc and a minimal startup about 20% slower, with roughly 1 MiB additional peak RSS. The uv gzip catalog was about 3% faster with approximately 27% higher peak RSS. Selecting the separate System archive gives the original program sizes and startup RSS. Paired System decoding was within 0.1% of the preceding version. All outputs were checked against CPython. The raw source-bound control ships in the evidence archive.",
    "",
    "## Reproduction",
    "",
    f"Extract the [offline study]({heading}-study.tar.xz) and run `python3.14 -B tools/replay.py .`. The replay compares the pinned upstream outputs, reconstructs all 1×/10× checks, recomputes the 32 six-engine medians and checks all 32 matched native cases. It verifies both checkout roots, CPU and RSS controls, source and native binary hashes, retained complete outputs and the two-archive build identities. The individual modality records and the fresh-replay audit are available separately. [Ordinary raw]({heading}-ordinary.json.gz) · [ThinLTO raw]({heading}-thinlto.json.gz) · [Audit]({heading}-audit.json)",
    "",
]
section = lines.index("## Reproduction")
collateral_names = {
    "startup": "Minimal process startup",
    "route-96x96-8": "Route planner, 96×96 grid",
    "Base45-encode-16384x128": "Base45 encoding, 16 KiB × 128",
    "Base45-decode-bytes-16384x128": "Base45 decoding, 16 KiB × 128",
    "catalog-gzip-1x": "uv catalog, gzip, 1×",
}
rows = []
for key, description in collateral_names.items():
    ratios = [
        collateral[v]["cases"][key]["timing"]["median_paired_ratio"]
        for v in ("system", "jemalloc")
    ]
    count = collateral["system"]["cases"][key]["timing"]["pairs"]
    rows.append([description, count, *[f"{(v - 1) * 100:+.1f}%" for v in ratios]])
lines[section:section] = table(
    [
        "Control program",
        "Pairs per arm",
        "New System vs prior System",
        "jemalloc vs prior System",
    ],
    rows,
)
a.output.write_text("\n".join(lines))
