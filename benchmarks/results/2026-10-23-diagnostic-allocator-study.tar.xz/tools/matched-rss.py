"""Measure the final reporter's peak RSS against equal-allocator and stock Rust after all wall timing."""

import argparse
import hashlib
import json
import os
import runpy
import subprocess
import sys
import time
from pathlib import Path
from statistics import median


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def run(f):
    os.sched_setaffinity(0, {7})
    last = f / "matched/thinlto/results.json"
    while not last.exists() or not read(last)["completed"]:
        time.sleep(1)
    target = f / "matched-memory"
    target.mkdir(exist_ok=False)
    os.sched_setaffinity(0, {31})
    clock = Path("/usr/bin/time")
    source = f / "source/benchmarks"
    fixture = runpy.run_path(str(source / "conformance_validate.py"))
    order = runpy.run_path(str(source / "conformance_regex_benchmark.py"))["orders"](
        ("after", "rust", "matched_rust")
    )
    env = fixture["environment"](target)
    dest = target / "report.md"
    peak = target / "rss.out"
    result = {
        "scope": "complete changed GitHub report",
        "unit": "KiB, Linux per-child ru_maxrss",
        "cpu": 31,
        "clock_sha256": sha(clock.read_bytes()),
        "order": order,
        "revision": read(f / "source/checkout.json")["revision"],
        "modes": {},
    }
    for mode in ("normal", "thinlto"):
        refs = read(f / "matched" / mode / "results.json")
        assert refs["completed"] and refs["revision"] == result["revision"]
        cmds = {
            n: refs["engines"][n]["report"] for n in ("after", "rust", "matched_rust")
        }
        ids = {n: sha(Path(cmd[0]).read_bytes()) for n, cmd in cmds.items()}
        assert ids == refs["binary_sha256"]
        record = {"binaries": ids, "cases": {}}
        result["modes"][mode] = record
        for scale in (1, 10):
            d = f / "fixtures" / f"{scale}x/changed"
            work = fixture["Workload"](
                *(d / (k + ".json") for k in ("manifest", "old", "new")), "github"
            )
            gold = fixture["oracle"](work).report.encode()
            assert (
                gold
                == (
                    f / "measurements" / mode / f"{scale}x-changed-github.md"
                ).read_bytes()
            )
            fingerprint = sha(gold)
            args = [*work.arguments(), "--output", str(dest)]
            rows = []
            for rnd in range(-1, 6):
                cells = []
                for engine in order[rnd % 6]:
                    dest.unlink(missing_ok=True)
                    peak.unlink(missing_ok=True)
                    proc = subprocess.run(
                        [str(clock), "-f", "%M", "-o", str(peak), *cmds[engine], *args],
                        env=env,
                        capture_output=True,
                        stdin=subprocess.DEVNULL,
                        timeout=120,
                        check=True,
                    )
                    assert (
                        proc.stdout == proc.stderr == b"" and dest.read_bytes() == gold
                    )
                    value = int(peak.read_text())
                    assert value > 0
                    cells.append(
                        {
                            "engine": engine,
                            "peak_kib": value,
                            "output_sha256": fingerprint,
                        }
                    )
                rows.append(cells)
            record["cases"][str(scale)] = {
                "warmup": rows[0],
                "samples": rows[1:],
                "median_kib": {
                    n: median(
                        v["peak_kib"] for r in rows[1:] for v in r if v["engine"] == n
                    )
                    for n in cmds
                },
            }
    out = target / "results.json"
    out.write_text(json.dumps(result, indent=2) + "\n")
    sys.stdout.buffer.write(out.read_bytes())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cache", type=Path)
    run(parser.parse_args().cache.resolve())
