"""Repeat all canonical panels with both system and jemalloc Rust references."""

import argparse
import hashlib
import json
import os
import runpy
import subprocess
import time
from pathlib import Path
from statistics import median


def read(p):
    return json.loads(p.read_bytes())


def sha(b):
    return hashlib.sha256(b).hexdigest()


def save(p, d):
    s = p.with_suffix(".tmp")
    s.write_text(json.dumps(d, indent=2) + "\n")
    s.replace(p)


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--cache", type=Path, required=True)
p.add_argument("--staged", type=Path, required=True)
p.add_argument("--cpu", type=int, default=31)
a = p.parse_args()
c = a.cache.resolve()
stage = a.staged.resolve()
os.sched_setaffinity(0, {a.cpu})
src = c / "source/benchmarks"
shared = runpy.run_path(str(src / "conformance_regex_benchmark.py"))
work = runpy.run_path(str(src / "conformance_grouping_benchmark.py"))
val = shared["VALIDATION"]
names = ("after", "rust", "matched_rust")
orders = shared["orders"](names)
out = c / "matched"
out.mkdir(exist_ok=False)
env = val["environment"](out)
staged = read(stage / "candidate.json")
for mode in ("normal", "thinlto"):
    dest = out / mode
    dest.mkdir()
    raw = read(c / "measurements" / mode / "results.json")
    cfg = raw["config"]
    matched = stage / mode / "matched-rust"
    assert sha(matched.read_bytes()) == staged["modes"][mode]["matched_rust"]["sha256"]
    assert cfg["revision"] == staged["revision"]
    assert raw["completed"] and raw["time_target_met"]
    engines = {
        **{name: cfg["engines"][name] for name in ("after", "rust")},
        "matched_rust": {
            "analysis": [str(matched), "--grouping"],
            "report": [str(matched)],
            "compute": [str(matched), "--compute"],
        },
    }
    rec = {
        "schema": 1,
        "revision": cfg["revision"],
        "cpu": a.cpu,
        "mode": mode,
        "engines": engines,
        "binary_sha256": {
            name: sha(Path(v["report"][0]).read_bytes()) for name, v in engines.items()
        },
        "primary_raw_sha256": sha(
            (c / "measurements" / mode / "results.json").read_bytes()
        ),
        "schedule": orders,
        "samples_per_engine": 12,
        "cases": {},
        "completed": False,
    }
    result = dest / "results.json"
    output = dest / "run.md"
    for name, control in raw["cases"].items():
        scale, cond, op = name.split("/")
        state, fmt = cond.split("-")
        panel = c / "fixtures" / scale / state
        args = [str(panel / (n + ".json")) for n in ("manifest", "old", "new")]
        w = val["Workload"](*(Path(s) for s in args), fmt)
        n = control["rounds"]
        paired = control["paired"]
        case = {"rounds": n, "paired": paired, "samples": []}
        rec["cases"][name] = case
        for i in range(-1, 12):
            row = []
            for pos, role in enumerate(orders[i % 6]):
                observation = {"engine": role}
                sequence = ([0, n] if (i + pos) % 2 == 0 else [n, 0]) if paired else [n]
                observation["execution_order"] = sequence
                for reps in sequence:
                    cmd, outfile = work["invocation"](
                        engines[role], op, args, w, output, reps
                    )
                    if outfile:
                        outfile.unlink(missing_ok=True)
                    t = time.perf_counter_ns()
                    cp = subprocess.run(
                        cmd,
                        env=env,
                        capture_output=True,
                        stdin=subprocess.DEVNULL,
                        timeout=180,
                        check=True,
                    )
                    elapsed = time.perf_counter_ns() - t
                    assert not cp.stderr
                    content = outfile.read_bytes() if outfile else cp.stdout
                    identity = [sha(cp.stdout), sha(content)]
                    assert identity == control["oracle"][str(reps)]
                    if outfile:
                        golden = (
                            (
                                c / "measurements" / mode / f"{scale}-{cond}.md"
                            ).read_bytes()
                            if reps
                            else b""
                        )
                        assert content == golden
                    observation["measure" if reps else "zero"] = {
                        "ns": elapsed,
                        "stdout": identity[0],
                        "output": identity[1],
                    }
                row.append(observation)
            if i == -1:
                case["warmup"] = row
            else:
                case["samples"].append(row)
        times = {
            e: median(
                (v["measure"]["ns"] - v["zero"]["ns"]) / n
                if paired
                else v["measure"]["ns"]
                for r in case["samples"]
                for v in r
                if v["engine"] == e
            )
            for e in names
        }
        assert min(times.values()) > 0
        case["median_ns"] = times
        case["ratios"] = {
            "after_over_rust": times["after"] / times["rust"],
            "after_over_matched_rust": times["after"] / times["matched_rust"],
        }
        save(result, rec)
        print(
            "matched",
            mode,
            name,
            round(case["ratios"]["after_over_matched_rust"], 4),
            flush=True,
        )
    rec["time_target_met"] = all(
        max(v["ratios"].values()) <= 2 for v in rec["cases"].values()
    )
    rec["completed"] = True
    save(result, rec)
    assert rec["time_target_met"], mode
