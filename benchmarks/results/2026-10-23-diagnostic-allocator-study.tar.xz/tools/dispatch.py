"""Run the release study only after the preregistered four-way admission has passed."""

import json
import subprocess
import sys
import time
from pathlib import Path

f = Path(sys.argv[1]).resolve()
root = f.parent
sha = json.loads((f / "source/checkout.json").read_bytes())["revision"]
candidate = root / ("native-allocator-" + sha[:7])
held = candidate / "admission/results.json"
p = Path(sys.executable).resolve()
cpu = "31"
for name in ("build-base", "build-rust", "build-platform", "build-codon", "fixtures"):
    target = f / name
    if not target.exists():
        target.symlink_to(root / name, target_is_directory=True)
    assert target.resolve() == (root / name).resolve()
while True:
    if held.is_file():
        d = json.loads(held.read_bytes())
        if d["completed"]:
            assert d["source"]["revision"] == sha
            if not d["admitted"]:
                print("admission did not pass; six-engine matrix held", flush=True)
                sys.exit(4)
            break
    time.sleep(1)
subprocess.run(
    [
        str(p),
        "-B",
        "-u",
        str(f / "run-formal.py"),
        "--cache",
        str(f),
        "--cpu",
        cpu,
        "--python",
        str(p),
    ],
    check=True,
)
subprocess.run(
    [
        str(p),
        "-B",
        "-u",
        str(f / "path-sensitivity.py"),
        "--cache",
        str(f),
        "--cpu",
        cpu,
    ],
    check=True,
)
for mode in ("normal", "thinlto"):
    subprocess.run(
        [
            str(p),
            "-B",
            "-u",
            str(f / "peak-rss.py"),
            "--cache",
            str(f),
            "--cpu",
            cpu,
            "--mode",
            mode,
        ],
        check=True,
    )
subprocess.run(
    [
        str(p),
        "-B",
        "-u",
        str(f / "matched-panels.py"),
        "--cache",
        str(f),
        "--staged",
        str(candidate),
        "--cpu",
        cpu,
    ],
    check=True,
)
print("formal, root sensitivity, RSS and matched Rust panel complete", flush=True)
