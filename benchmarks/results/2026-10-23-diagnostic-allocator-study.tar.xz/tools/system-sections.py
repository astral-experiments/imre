"""Compare every file-backed ELF section loaded into a System-allocator program against its prior release."""

import argparse
import hashlib
import json
import struct
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def sections(data):
    header = struct.unpack_from("<16sHHIQQQIHHHHHH", data)
    assert header[0][:6] == b"\x7fELF\x02\x01"
    spans = [
        struct.unpack_from("<IIQQQQIIQQ", data, header[6] + header[11] * i)
        for i in range(header[12])
    ]
    string = spans[header[13]]
    names = data[string[4] : string[4] + string[5]]
    return {
        names[span[0] :].split(b"\0", 1)[0].decode(): data[span[4] : span[4] + span[5]]
        for span in spans
        if span[2] & 2 and span[1] != 8
    }


def compare(before, after):
    records = {}
    for mode in ("normal", "thinlto"):
        for role, program in [
            ("kernels", "grouping"),
            ("programs", "conformance-report"),
            ("programs", "conformance-report-compute"),
        ]:
            old = (before / role / mode / program).read_bytes()
            new = (after / role / mode / program).read_bytes()
            x, y = sections(old), sections(new)
            changed = sorted(
                name for name in x.keys() | y.keys() if x.get(name) != y.get(name)
            )
            assert (
                set(x) == set(y)
                and changed == [".note.gnu.build-id"]
                and x[changed[0]][:16] == y[changed[0]][:16]
                and len(x[changed[0]]) == len(y[changed[0]]) == 36
            )
            records[mode + "/" + program] = {
                "system_original_elf_sha256": sha(old),
                "system_current_elf_sha256": sha(new),
                "mapped_sections_with_differences": changed,
                "sections": {
                    key: {"baseline": sha(value), "current": sha(y[key])}
                    for key, value in x.items()
                },
            }
    return records


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("before", type=Path)
    p.add_argument("after", type=Path)
    p.add_argument("output", type=Path)
    a = p.parse_args()
    r = compare(a.before, a.after)
    a.output.write_text(json.dumps(r, indent=2) + "\n")
    print(
        "Verified all six prior+current System ELF executable payloads; only their GNU build IDs differ."
    )
