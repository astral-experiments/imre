"""Independently verify the matched system and jemalloc Rust panels from complete raw observations."""

import hashlib
import json
from collections import Counter
from itertools import pairwise
from statistics import median


def read(p):
    return json.loads(p.read_bytes())


def audit(primary_file, supplement_file, matched_validation):
    primary = read(primary_file)
    raw = read(supplement_file)
    names = {"after", "rust", "matched_rust"}
    mode = raw["mode"]
    record = read(matched_validation)["modes"][mode]
    assert (
        primary["completed"]
        and raw["completed"]
        and raw["revision"] == primary["config"]["revision"]
        and raw["cpu"] == primary["cpu"] == 31
    )
    assert (
        raw["primary_raw_sha256"]
        == hashlib.sha256(primary_file.read_bytes()).hexdigest()
    )
    assert (
        raw["binary_sha256"]["matched_rust"] == record["binary_sha256"]
        and raw["binary_sha256"]["rust"] == record["system_binary_sha256"]
    )
    for engine in ("after", "rust"):
        assert raw["binary_sha256"][engine] == next(
            o["sha256"]
            for o in primary["config"]["guarded_inputs"]
            if o["path"] == primary["config"]["engines"][engine]["report"][0]
        )
    assert set(raw["engines"]) == names
    for e in ("after", "rust"):
        assert raw["engines"][e] == primary["config"]["engines"][e]
        assert all(
            any(g["path"] == command[0] for g in primary["config"]["guarded_inputs"])
            for command in raw["engines"][e].values()
        )
    same = raw["engines"]["matched_rust"]
    assert set(same) == {"analysis", "compute", "report"}
    assert (
        len(same["report"]) == 1
        and same["analysis"] == [*same["report"], "--grouping"]
        and same["compute"] == [*same["report"], "--compute"]
    )
    schedule = raw["schedule"]
    assert len(schedule) == 6 and all(set(row) == names for row in schedule)
    assert all(
        Counter(row[i] for row in schedule) == {e: 2 for e in names} for i in range(3)
    )
    assert Counter(p for r in schedule for p in pairwise(r)) == {
        (a, b): 2 for a in names for b in names if a != b
    }
    observations = 0
    assert (
        set(raw["cases"]) == set(primary["cases"])
        and len(raw["cases"]) == 16
        and raw["samples_per_engine"] == 12
    )
    ratios = {}
    for name, c in raw["cases"].items():
        oracle = primary["cases"][name]
        assert c["rounds"] == oracle["rounds"] and c["paired"] == oracle["paired"]
        n = c["rounds"]
        assert len(c["samples"]) == 12
        t = {e: [] for e in names}
        for i, row in enumerate([c["warmup"], *c["samples"]], start=-1):
            assert [s["engine"] for s in row] == schedule[i % 6]
            for pos, sample in enumerate(row):
                seq = ([0, n] if (i + pos) % 2 == 0 else [n, 0]) if c["paired"] else [n]
                assert sample["execution_order"] == seq
                for count in seq:
                    observation = sample["measure" if count else "zero"]
                    assert (
                        observation["ns"] > 0
                        and [observation["stdout"], observation["output"]]
                        == oracle["oracle"][str(count)]
                    )
                    observations += 1
                if i >= 0:
                    t[sample["engine"]].append(
                        (sample["measure"]["ns"] - sample["zero"]["ns"]) / n
                        if c["paired"]
                        else sample["measure"]["ns"]
                    )
        med = {e: median(values) for e, values in t.items()}
        assert med == c["median_ns"] and min(med.values()) > 0
        ratios[name] = {
            "after_over_rust": med["after"] / med["rust"],
            "after_over_matched_rust": med["after"] / med["matched_rust"],
        }
        assert ratios[name] == c["ratios"]
    assert observations == 936 and raw["time_target_met"] == all(
        max(r.values()) <= 2 for r in ratios.values()
    )
    return {
        "mode": mode,
        "observations": observations,
        "cases": 16,
        "time_target_met": raw["time_target_met"],
        "worst_system": max(v["after_over_rust"] for v in ratios.values()),
        "worst_matched": max(v["after_over_matched_rust"] for v in ratios.values()),
        "sha256": hashlib.sha256(supplement_file.read_bytes()).hexdigest(),
    }
