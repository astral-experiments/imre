"""Collect the portable static allocator comparison alongside the original verified study."""

import argparse
import hashlib
import json
import shutil
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def copy(file, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(file, dest)


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--cache", type=Path, required=True)
p.add_argument("--output", type=Path, required=True)
p.add_argument("--original", type=Path, required=True)
p.add_argument("--qa", type=Path, required=True)
p.add_argument("--other-programs", type=Path, required=True)
p.add_argument("--ffi", type=Path)
p.add_argument("--cli", type=Path)
p.add_argument("--live-recipe", type=Path)
p.add_argument("--new-seeds-recipe", type=Path)
args = p.parse_args()
f = args.cache.resolve()
c = f.parent
out = args.output.resolve()
out.mkdir(exist_ok=False)
tools = Path(__file__).resolve().parent
sha_new = read(f / "source/checkout.json")["revision"]
ref = c / "rust-jemalloc-control"
gate = c / ("native-allocator-" + sha_new[:7])
build = c / ("static-allocator-" + sha_new[:7])
assert (
    sha(args.original)
    == "f631001212e7e242a204e6c2113919abd7a64e82a814acf5e5687f858c82a7bf"
)
copy(args.original, out / "previous-study.tar.xz")
shutil.copytree(
    f / "source", out / "source", ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
)
for mode in ("normal", "thinlto"):
    d = out / "modes" / mode
    shutil.copytree(
        f / "export" / mode,
        d,
        ignore=shutil.ignore_patterns("report.md", "results.tmp"),
    )
    copy(f / "memory" / mode / "rss.json", d / "rss.json")
    copy(f / "matched" / mode / "results.json", out / "matched" / mode / "results.json")
    copy(ref / mode / "build-record.json", out / "matched" / mode / "build-record.json")
    for op, sub in [
        ("grouping", "kernels"),
        ("conformance-report", "programs"),
        ("conformance-report-compute", "programs"),
    ]:
        k = read(build / "build-final" / sub / mode / "build-record.json")
        ir = (
            k["llvm"]
            if sub == "kernels"
            else k["llvm"][op.replace("conformance-report", "conformance_report", 1)]
        )
        assert sha(Path(ir["path"])) == ir["sha256"]
        copy(Path(ir["path"]), out / "ir" / mode / (op + ".ll"))
copy(f / "path-sensitivity/comparison.json", out / "path-sensitivity.json")
copy(f / "matched-rss.json", out / "matched/rss.json")
for name in ("preparation.json", "validation.json", "validate.py"):
    copy(ref / name, out / "matched" / name)
for name in ("Cargo.toml", "Cargo.lock", "src/main.rs"):
    copy(
        ref / "source/benchmarks/reference/conformance_report" / name,
        out / "matched/source" / name,
    )
for name in (
    "results.json",
    "audit.json",
    "candidate.json",
    "candidate-source.tar.gz",
    "stage.py",
    "matched-validation.json",
    "run.py",
):
    copy(gate / name, out / "admission" / name)
for n in (
    "admission-build.json",
    "admission-build-all.json",
    "build-qa.json",
    "build-qa.tar.gz",
):
    copy(build / n, out / "build-qa" / n)
copy(
    c / "native-admission-c806b9e/packed-candidate-study.tar.xz",
    out / "experiments/rejected-packed.tar.xz",
)
copy(args.other_programs, out / "experiments/other-programs.tar.gz")
if args.other_programs.with_name("fresh-replay.json").is_file():
    copy(
        args.other_programs.with_name("fresh-replay.json"),
        out / "experiments/other-programs-fresh-replay.json",
    )
for n in (
    "ordinary-integrated/record.json",
    "asan-integrated/record.json",
):
    copy(args.qa / n, out / "qa" / n)
for f_live in sorted((args.qa / "live").iterdir()):
    if f_live.suffix in (".md", ".json"):
        copy(f_live, out / "qa/live" / f_live.name)
if (args.qa / "live-timing.json").is_file():
    copy(args.qa / "live-timing.json", out / "qa/live-timing.json")
if args.live_recipe:
    copy(args.live_recipe, out / "qa/live/run.py")
if args.new_seeds_recipe:
    held = args.qa / "grouping-heldout"
    copy(held / "receipt.json", out / "qa/grouping-heldout/receipt.json")
    copy(args.new_seeds_recipe, out / "qa/grouping-heldout/run.py")
    (out / "qa/grouping-heldout/recorded-path.json").write_text(
        json.dumps(
            {
                "absolute_directory": str(held.resolve()),
                "recipe_sha256": sha(args.new_seeds_recipe),
            },
            indent=2,
        )
        + "\n"
    )
if args.ffi:
    copy(args.ffi, out / "qa/heap-ffi/receipt.json")
    ffi_source = args.ffi.with_name("relar-102-runtime-heap.c")
    if ffi_source.is_file():
        copy(ffi_source, out / "qa/heap-ffi" / ffi_source.name)
if args.cli:
    copy(args.cli, out / "qa/cli/reporter.json")
    for filename in (
        "reporter.py",
        "binary-equivalence.json",
        "canonical-clang.py",
        "check-elf.py",
        "cli-qa.json",
        "cli-qa.py",
    ):
        copy(args.cli.with_name(filename), out / "qa/cli" / filename)
if not sha_new.startswith("a91b337"):
    copy(
        f / "previous-system-elf-sections.json",
        out / "build-qa/previous-system-elf-sections.json",
    )
    copy(
        c / "final-a91b337/measured-selector.tar.xz",
        out / "experiments/measured-selector.tar.xz",
    )
    for file in (
        "system-control-build.json",
        "transcript-validation.json",
        "system-transcript-validation.json",
        "verify-evidence.py",
        "build-native.py",
        "bind-programs.py",
        "build-system.py",
        "validate-system.py",
        "differential.py",
    ):
        copy(build / file, out / "build-qa" / file)
    copy(build / "build-final/core/build.py", out / "build-qa/produce-core.py")
    copy(build / "asan-core/build-record.json", out / "build-qa/asan-core.json")
    for mode in ("normal", "thinlto"):
        for kind in ("kernels", "programs"):
            copy(
                build / "build-system" / kind / mode / "build-record.json",
                out / "build-qa/system" / mode / (kind + ".json"),
            )
for label, source in [("relar", "relar"), ("rust", "rust-identical-flags")]:
    shutil.copytree(f / "profiles" / source, out / "profiles" / label)
for n in (
    "gate-audit.py",
    "matched-audit.py",
    "matched-rss.py",
    "matched-memory-audit.py",
    "package.py",
    "replay.py",
    "render.py",
    "dispatch.py",
    "matched-panels.py",
    "stage-gate.py",
    "prepare-final.py",
    "launch-production.py",
    "close-intermediate.py",
    "pack-intermediate.py",
    "publish.py",
    "system-sections.py",
    "README.md",
):
    copy(tools / n, out / ("README.md" if n == "README.md" else "tools/" + n))
for n in (
    "run-formal.py",
    "bind-builds.py",
    "make-config.py",
    "stage-builds.py",
    "path-sensitivity.py",
    "peak-rss.py",
    "build-grouping.py",
    "profile-native.py",
):
    copy(f / n, out / "tools" / n)
index = {
    "revision": sha_new,
    "previous_study_sha256": sha(out / "previous-study.tar.xz"),
    "files": {
        str(p.relative_to(out)): sha(p)
        for p in sorted(out.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts
    },
}
(out / "index.json").write_text(json.dumps(index, indent=2) + "\n")
print("indexed", len(index["files"]), "files", out, flush=True)
