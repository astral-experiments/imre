"""Release CPU31 immediately after the completed intermediate ordinary panel has been verified and retained."""
import hashlib,json,os,signal,sys,time
from pathlib import Path
f=Path(sys.argv[1]).resolve(); owner=int(sys.argv[2]); assert f.name=='final-a91b337' and os.getpgid(owner)==owner
cmd=(Path('/proc')/str(owner)/'cmdline').read_bytes().split(b'\0');assert str(f/'dispatch.py').encode() in cmd
os.sched_setaffinity(0,{7});mode=f/'measurements/normal';audit=mode/'strict-audit.json';raw=mode/'results.json'
while not (mode/'records/python.json').is_file():time.sleep(.05)
assert len(list((mode/'records').glob('*.json')))==11 and json.loads(raw.read_bytes())['completed'];h=hashlib.sha256(raw.read_bytes()).hexdigest();a=json.loads(audit.read_bytes());assert a['results_sha256']==h and a['observations']==1872
record={'reason':'intermediate replaced by separate link-time allocator archives after its ordinary six-engine panel and all four held-out native gates','revision':a['revision'],'retained':'normal full 16 cases plus both link modes of held-out native grouping and four full-report roots','raw_sha256':h,'monotonic_ns':time.monotonic_ns()}
(f/'phase-closed.json').write_text(json.dumps(record,indent=2)+'\n'); assert str(f/'dispatch.py').encode() in (Path('/proc')/str(owner)/'cmdline').read_bytes().split(b'\0');os.killpg(owner,signal.SIGTERM);print(json.dumps(record),flush=True)
