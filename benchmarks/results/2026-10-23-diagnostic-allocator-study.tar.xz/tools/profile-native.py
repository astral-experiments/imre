"""Profile the matched native kernels, including the identical zero-round preload."""
import argparse,hashlib,json,os,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--label',required=True);p.add_argument('--exe',type=Path,required=True);p.add_argument('--rust',action='store_true');p.add_argument('--cpu',type=int,required=True);p.add_argument('--rounds',type=int,default=4);p.add_argument('--scale',type=int,default=10);a=p.parse_args()
root=a.cache/'profiles'/a.label;root.mkdir(parents=True,exist_ok=True)
fixture=a.cache/'fixtures'/f'{a.scale}x'/'changed';vg=Path.home()/'.cache/onyx/profiling-tools/root';debug=Path.home()/'.cache/ignore-hillclimb/callgrind/usr/lib/debug'
env={**os.environ,'VALGRIND_LIB':str(vg/'usr/libexec/valgrind'),'LANG':'C.UTF-8'};env.pop('VALGRIND_OPTS',None)
def identity(f):
 b=f.read_bytes();return {'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def one(tool):
 rows=[]
 for n in (0,a.rounds):
  prefix=root/f'{tool}-{n}';out=prefix.with_suffix('.out' if tool=='callgrind' else '.json')
  cmd=['taskset','-c',str(a.cpu),str(vg/'usr/bin/valgrind'),f'--tool={tool}','--vgdb=no','--num-callers=35','--read-inline-info=yes','--extra-debuginfo-path='+str(debug),'--log-file='+str(prefix.with_suffix('.log')),f'--{tool}-out-file='+str(out),str(a.exe),*(['--grouping'] if a.rust else []),'group',*[str(fixture/(k+'.json')) for k in ('manifest','old','new')],str(n)]
  proc=subprocess.run(cmd,capture_output=True,env=env,timeout=900,check=True);expected=subprocess.run([*cmd[cmd.index(str(a.exe)):]],capture_output=True,check=True).stdout;prefix.with_suffix('.stderr').write_bytes(proc.stderr);assert proc.stdout==expected, (proc.stdout,expected);assert not proc.stderr, repr(proc.stderr[:2048]);(prefix.with_suffix('.stdout')).write_bytes(proc.stdout)
  if tool=='callgrind':
   values={'instructions':int(re.search(r'^summary: (\d+)',out.read_text(),re.M)[1])}
  else:
   data=json.loads(out.read_bytes());values={k:sum(x[k] for x in data['pps']) for k in ('tb','tbk','gb','gbk','eb','ebk')}
  rows.append({'rounds':n,'command':cmd,'trace':identity(out),'stdout':identity(prefix.with_suffix('.stdout')),'log':identity(prefix.with_suffix('.log')),'total':values})
 return {'runs':rows,'net_per_pass':{k:(rows[-1]['total'][k]-rows[0]['total'][k])/a.rounds for k in rows[0]['total'] if k in ('instructions','tb','tbk')}}
# DHAT's libc interception omits allocations served by statically linked jemalloc.
for t in ['callgrind']:
 row=one(t);record={'label':a.label,'probe':t,'binary':identity(a.exe),'tool':identity(vg/'usr/bin/valgrind'),'fixture':[identity(fixture/(k+'.json')) for k in ('manifest','old','new')],'scale':a.scale,**row};(root/f'{t}-summary.json').write_text(json.dumps(record,indent=2)+'\n');print(a.label,t,row['net_per_pass'],flush=True)
