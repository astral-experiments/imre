"""Verify both Rust allocator references, all native comparisons and the upstream oracles offline."""

import argparse
import hashlib
import itertools
import json
import re
import runpy
import statistics
import subprocess
import sys
import tarfile
import tempfile
import tomllib
from pathlib import Path


def read(path):
    return json.loads(path.read_bytes())


def digest(b):
    return hashlib.sha256(b).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def subprocess_json(args):
    p = subprocess.run([sys.executable, "-B", *map(str, args)], capture_output=True)
    if p.returncode:
        raise RuntimeError(p.stderr.decode()[-5000:] + p.stdout.decode()[-2000:])
    return json.loads(p.stdout)


def native_artifacts(root, previous, mode, candidate, receipt, matched):
    here, old = (p / "modes" / mode / "records" for p in (root, previous))
    build = receipt["modes"][mode]
    new_prog, old_prog = (read(p / "program-after.json") for p in (here, old))
    new_kernel, old_kernel = (read(p / "kernel-after.json") for p in (here, old))
    assert all(
        v["revision"] == candidate["revision"] and v["mode"] == mode
        for v in (new_prog, new_kernel)
    )
    assert (
        read(here / "rust.json")["binary_sha256"]
        == read(old / "rust.json")["binary_sha256"]
        == matched["modes"][mode]["system_binary_sha256"]
    )
    rust = read(root / "matched" / mode / "build-record.json")
    ref = matched["modes"][mode]
    assert (
        rust["binary_sha256"]
        == ref["binary_sha256"]
        == candidate["modes"][mode]["matched_rust"]["sha256"]
    )
    assert (
        sha(root / "matched" / mode / "build-record.json") == ref["build_record_sha256"]
    )
    assert rust["thinlto"] == (mode == "thinlto")
    assert len(ref["output_sha256"]) == 16 and len(ref["rust_to_allocator_calls"]) > 0
    assert {"T _rjem_malloc", "T _rjem_mallocx", "T _rjem_sdallocx"} <= set(
        ref["allocator_symbols"]
    )
    assert all("jemalloc" not in dep for dep in ref["needed"])
    for op, key in [
        ("grouping", None),
        ("conformance-report", "conformance_report"),
        ("conformance-report-compute", "conformance_report-compute"),
    ]:
        ir = (root / "ir" / mode / (op + ".ll")).read_bytes()
        rows = ir.splitlines(keepends=True)
        record = new_kernel["binary"] if key is None else new_prog["binaries"][key]
        old_llvm = old_kernel["llvm"] if key is None else old_prog["llvm"][key]
        new_llvm = new_kernel["llvm"] if key is None else new_prog["llvm"][key]
        assert digest(ir) == new_llvm["sha256"]
        if key is None:
            assert candidate["modes"][mode]["analysis"]["sha256"] == record["sha256"]
        elif op == "conformance-report":
            assert candidate["modes"][mode]["report"]["sha256"] == record["sha256"]
        if candidate["revision"].startswith("a91b337"):
            assert sum(b"@relar_init_native_heap" in line for line in rows) == 2
            ir = b"".join(
                line for line in rows if b"@relar_init_native_heap" not in line
            )
        else:
            assert b"@relar_init_native_heap" not in ir
        assert digest(ir) == old_llvm["sha256"]
        if key is None:
            assert ir == (previous / "ir" / mode / "after.ll").read_bytes()
        proved = build["programs"][op]
        assert (
            proved["binary"]["sha256"] == record["sha256"]
            and proved["llvm"]["sha256"] == new_llvm["sha256"]
        )
    return {
        "kernel_sha256": new_kernel["binary"]["sha256"],
        "runtime_sha256": new_kernel["runtime"]["sha256"],
        "matched_rust_sha256": ref["binary_sha256"],
    }


def audit_rust_source(root, previous, validation):
    original = root / "source/benchmarks/reference/conformance_report"
    overrides = root / "matched/source"
    changed = set()
    strong = {}
    for filename, item in validation["sources"].items():
        old = original / filename
        new = overrides / filename if (overrides / filename).exists() else old
        assert sha(old) == item["original"] and sha(new) == item["measured"], filename
        strong[filename] = sha(new)
        if old.read_bytes() != new.read_bytes():
            changed.add(filename)
    assert changed == {"Cargo.toml", "Cargo.lock", "src/main.rs"}
    block = '\n#[cfg(target_os = "linux")]\n#[global_allocator]\nstatic GLOBAL: tikv_jemallocator::Jemalloc = tikv_jemallocator::Jemalloc;\n'
    new_main = (overrides / "src/main.rs").read_text()
    assert (
        new_main.count(block) == 1
        and new_main.replace(block, "") == (original / "src/main.rs").read_text()
    )
    manifest = tomllib.loads((overrides / "Cargo.toml").read_text())
    target = manifest.pop("target")
    assert manifest == tomllib.loads((original / "Cargo.toml").read_text())
    assert target == {
        'cfg(target_os = "linux")': {
            "dependencies": {
                "tikv-jemallocator": {
                    "version": "=0.6.1",
                    "default-features": False,
                    "features": ["background_threads_runtime_support"],
                }
            }
        }
    }

    def lock(folder):
        return {
            p["name"]: p
            for p in tomllib.loads((folder / "Cargo.lock").read_text())["package"]
        }

    base, patched = lock(original), lock(overrides)
    assert base.keys() < patched.keys()
    assert {
        n: patched[n]["version"] for n in patched.keys() - base.keys()
    } == validation["lock_delta"]
    edit = [k for k in base if base[k] != patched[k]]
    assert edit == [manifest["package"]["name"]]
    ref = patched[edit[0]].copy()
    ref["dependencies"] = [d for d in ref["dependencies"] if d != "tikv-jemallocator"]
    assert ref == base[edit[0]]
    for filename in (
        "../../native_platform/Cargo.toml",
        "../../native_platform/src/lib.rs",
    ):
        strong[filename] = sha(original / filename)
    for mode in ("normal", "thinlto"):
        old = read(previous / "modes" / mode / "records/rust.json")
        new = read(root / "matched" / mode / "build-record.json")
        assert (
            new["sources"] == strong
            and new["tool_sha256"] == old["tool_sha256"]
            and new["target"] == old["target"]
            and new["rustc_verbose"] == old["rustc_verbose"]
        )
        assert {
            k
            for k in old["environment"].keys() | new["environment"].keys()
            if old["environment"].get(k) != new["environment"].get(k)
        } == {"CARGO_TARGET_DIR"}
    return sorted(changed)


def audit_seeded(root, recs, configs, previous, skip):
    source = root / "source/benchmarks"
    r = runpy.run_path(str(source / "conformance_grouping_validate.py"))
    envfn = runpy.run_path(str(source / "conformance_validate.py"))["environment"]
    origin = recs["normal"]
    pair = {(x["case"], x["mode"]): x for x in origin["comparisons"]}
    assert origin["seeds"] == 96 and len(origin["fixed"]) == 12 and len(pair) == 211
    for mode, receipt in recs.items():
        assert (
            list(receipt["fixed"]) == list(origin["fixed"])
            and receipt["start"] == origin["start"]
            and receipt["seeds"] == origin["seeds"]
        )
        assert {(v["case"], v["mode"]) for v in receipt["comparisons"]} == set(pair)
        for row in receipt["comparisons"]:
            assert set(row["engines"]) == set(configs[mode]["engines"])
            for e, v in row["engines"].items():
                historic = e == "before" and (row["case"], row["mode"]) == (
                    "symlink-dedup",
                    "dump",
                )
                assert v == (
                    "historical fifth file row"
                    if historic
                    else row["error"] or row["oracle_sha256"]
                )
    if not skip:
        with tempfile.TemporaryDirectory() as temp:
            seed_dir = Path(temp) / "differentials"
            seed_dir.mkdir()
            env = envfn(Path(temp))
            for case in [
                *origin["fixed"],
                *range(origin["start"], origin["start"] + origin["seeds"]),
            ]:
                named = case if isinstance(case, str) else None
                seed = origin["start"] if named else case
                d = seed_dir / (named or f"seed-{seed}")
                d.mkdir()
                args = r["fixture"](d, seed, named)
                for case_name, role in pair:
                    if case_name != case:
                        continue
                    err, output = r["observation"](
                        [
                            sys.executable,
                            "-B",
                            str(source / "conformance_grouping_upstream.py"),
                        ],
                        [role, *args, "1"],
                        d,
                        env,
                    )
                    for mode, cfg in configs.items():
                        oracle = next(
                            o
                            for o in recs[mode]["comparisons"]
                            if (o["case"], o["mode"]) == (case, role)
                        )
                        assert (
                            oracle["error"] == err
                            and digest(
                                output.replace(
                                    str(seed_dir).encode(),
                                    cfg["validation_directory"].encode(),
                                )
                            )
                            == oracle["oracle_sha256"]
                        ), (mode, case, role)
    return len(pair)


def cpu_profiles(root, identities, controls):
    out = {}
    for label, funcs in {
        "relar": ("fn_6", "fn_11"),
        "rust": (r".*::grouping_benchmark::run", r".*::model::group_diagnostics::<.*>"),
    }.items():
        p = root / "profiles" / label
        summary = read(p / "callgrind-summary.json")
        counts = []
        events = []
        assert (
            summary["binary"]["sha256"]
            == identities["normal"][
                "kernel_sha256" if label == "relar" else "matched_rust_sha256"
            ]
        )
        assert summary["scale"] == 10 and [
            rec["rounds"] for rec in summary["runs"]
        ] == [0, 4]
        for rec in summary["runs"]:
            n = rec["rounds"]
            raw = p / f"callgrind-{n}.out"
            stdout = p / f"callgrind-{n}.stdout"
            assert (
                sha(raw) == rec["trace"]["sha256"]
                and sha(stdout) == rec["stdout"]["sha256"]
            )
            events.append(
                int(re.search(rb"^summary: (\d+)", raw.read_bytes(), re.M)[1])
            )
            assert events[-1] == rec["total"]["instructions"]
            counts.append(controls["count_calls"](raw, *funcs))
        assert counts[1] - counts[0] == 4, (label, counts)
        net = (events[1] - events[0]) / 4
        assert net == summary["net_per_pass"]["instructions"]
        out[label] = {"instructions_per_group": net, "grouping_calls_zero_four": counts}
    return out


def qa(root, previous, revision):
    out = {}
    for role in ("ordinary-integrated", "asan-integrated"):
        rec = read(root / "qa" / role / "record.json")
        assert rec["status"] == "passed" and rec["guards_passed"]
        assert rec["counts"] == {
            "application": 96,
            "compute": 120,
            "stdout": 3,
            "output-error": 6,
        }
        assert (rec["parser_differentials"], rec["report_differentials"]) == (
            30000,
            400,
        )
        out[role] = rec["counts"]
    live = root / "qa/live"
    receipt = read(live / "receipt.json")
    roles = list(receipt.get("engines", receipt.get("unicode_symlink_matched", [])))
    assert roles in (
        ["upstream", "relar", "rust"],
        ["upstream", "system", "jemalloc", "rust"],
    ) or set(roles) == {"upstream", "system", "jemalloc", "rust"}
    for name in (
        "changed-github",
        "unchanged-github",
        "changed-diff",
        "unchanged-diff",
    ):
        data = (previous / "qa/live" / (name + "-upstream.md")).read_bytes()
        for engine in roles:
            assert (live / (name + "-" + engine + ".md")).read_bytes() == data
        if len(roles) == 4:
            assert receipt["reports"][name] == {
                "bytes": len(data),
                "sha256": digest(data),
            }
    if len(roles) == 4:
        timing = receipt
        assert (
            (root / "qa/live/run.py").is_file()
            and timing["source"] == "e78c84acecc568ae3267aea07cab243ae2647f4f"
            and timing["suite_source"] == "835b70f3f795f8e061b1f7621178515b0a77a0ad"
        )
        assert (
            timing["cpu_affinity"] == [20, 21]
            and timing["rayon_threads"] == 2
            and len(timing["samples_ns"]) == 12
        )
        assert all(
            set(row) == set(roles) and min(row.values()) > 0
            for row in timing["samples_ns"]
        )
        assert all(
            sorted(list(row)[i] for row in timing["samples_ns"]) == sorted(roles * 3)
            for i in range(4)
        )
        med = {
            e: statistics.median(row[e] for row in timing["samples_ns"]) / 1e6
            for e in roles
        }
        assert (
            med == timing["median_ms"]
            and med["system"] / med["rust"] == timing["system_over_rust"]
            and med["jemalloc"] / med["rust"] == timing["jemalloc_over_rust"]
        )
        assert (
            set(timing["static_archives_sha256"])
            == {"librelar_runtime.a", "librelar_runtime_jemalloc.a"}
            and len(set(timing["static_archives_sha256"].values())) == 2
        )
        assert timing["upstream_driver_sha256"] == sha(
            root / "source/examples/conformance_report/original_live.py"
        )
        out["live_programs"] = 4
        out["live_source"] = timing["source"]
        out["live_observations"] = 52
    else:
        timing = read(root / "qa/live-timing.json")
        assert (
            timing["relar_revision"] == revision
            and timing["suite_revision"] == receipt["suite_revision"]
            and timing["report_sha256"] == sha(live / "changed-github-relar.md")
        )
        assert (
            timing["cpu_affinity"] == [20, 21]
            and len(timing["samples"]) == 12
            and len(timing["warmup"]) == 1
        )
        med = {
            e: statistics.median(
                s["ns"] for row in timing["samples"] for s in row if s["engine"] == e
            )
            / 1e6
            for e in roles
        }
        assert (
            med == timing["median_ms"]
            and med["relar"] / med["rust"] == timing["relar_over_rust"]
        )
        out["live_programs"] = 3
        out["live_source"] = revision
        out["live_observations"] = 39
    out["live_median_ms"] = med
    return out


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("study", type=Path)
p.add_argument("--skip-seeded-replay", action="store_true")
a = p.parse_args()
assert not sys.flags.optimize
root = a.study.resolve()
read_index = read(root / "index.json")
revision = read_index["revision"]
actual = {
    str(f.relative_to(root)): sha(f)
    for f in root.rglob("*")
    if f.is_file() and f != root / "index.json" and "__pycache__" not in f.parts
}
assert read_index["files"] == actual
old = "7178431490cd6d8838b67daca89ccbdf03e7ce34"
original = root / "previous-study.tar.xz"
assert (
    sha(original)
    == read_index["previous_study_sha256"]
    == "f631001212e7e242a204e6c2113919abd7a64e82a814acf5e5687f858c82a7bf"
)
with tempfile.TemporaryDirectory() as t:
    prev = Path(t)
    tarfile.open(original, "r:xz").extractall(prev, filter="data")
    prior = subprocess_json(
        [
            prev / "tools/replay.py",
            prev,
            *(["--skip-seeded-replay"] if a.skip_seeded_replay else []),
        ]
    )
    assert (
        prior["status"] == "passed"
        and prior["revision"] == old
        and prior["real_outputs_reexecuted"] == 32
    )
    src = root / "source"
    checkout = read(src / "checkout.json")
    assert (
        checkout["revision"] == revision
        and checkout["files"] == read(prev / "source/checkout.json")["files"]
        and len(checkout["files"]) == 56
    )
    assert all(sha(src / k) == v for k, v in checkout["files"].items())
    analytic = runpy.run_path(str(src / "benchmarks/conformance_grouping_audit.py"))[
        "audit"
    ]
    bind = runpy.run_path(str(root / "tools/bind-builds.py"))["dissect"]
    controls = runpy.run_path(str(prev / "tools/controls-audit.py"))
    orders = runpy.run_path(str(src / "benchmarks/conformance_regex_benchmark.py"))[
        "orders"
    ]
    match_audit = runpy.run_path(str(root / "tools/matched-audit.py"))["audit"]
    gate = root / "admission"
    gate_r = subprocess_json(
        [root / "tools/gate-audit.py", "--study", prev, "--raw", gate / "results.json"]
    )
    assert (
        gate_r == read(gate / "audit.json")
        and gate_r["admitted"]
        and gate_r["revision"] == revision
    )
    candidate = read(gate / "candidate.json")
    assert (
        candidate["revision"] == revision
        and candidate["baseline_revision"] == old
        and candidate["source_archive_sha256"] == sha(gate / "candidate-source.tar.gz")
    )
    assert sha(gate / "run.py") == candidate["recipe_sha256"]
    native = read(root / "build-qa/admission-build-all.json")
    assert native["revision"] == revision and native["baseline_revision"] == old
    matched = read(root / "matched/validation.json")
    assert (
        native["source_archive"]["sha256"] == candidate["source_archive_sha256"]
        and read(gate / "results.json")["source"] == candidate
    )
    rust_source_edits = audit_rust_source(root, prev, matched)
    assert (
        candidate["matched_validation_sha256"]
        == sha(root / "matched/validation.json")
        == sha(gate / "matched-validation.json")
    )
    assert (
        set(matched["lock_delta"])
        == {"cc", "find-msvc-tools", "shlex", "tikv-jemalloc-sys", "tikv-jemallocator"}
        and matched["lock_delta"]["tikv-jemallocator"] == "0.6.1"
    )
    assert (
        b"#[global_allocator]" in (root / "matched/source/src/main.rs").read_bytes()
        and 'target_os = "linux"' in (root / "matched/source/Cargo.toml").read_text()
    )
    configs = {}
    reviews = {}
    strong = {}
    seed = {}
    identities = {}
    canonical = 0
    for mode in ("normal", "thinlto"):
        d = root / "modes" / mode
        original_d = prev / "modes" / mode
        new = read(d / "results.json")
        prevraw = read(original_d / "results.json")
        cfg = new["config"]
        configs[mode] = cfg
        assert (
            cfg["revision"] == revision
            and new["fixtures"] == prevraw["fixtures"]
            and cfg["baseline_revision"] == prevraw["config"]["baseline_revision"]
        )
        reviews[mode] = analytic(d)
        assert (
            reviews[mode] == read(d / "strict-audit.json")
            and reviews[mode]["observations"] == 1872
        )
        assert bind(cfg, d / "records") == read(d / "binding.json")
        strong[mode] = match_audit(
            d / "results.json",
            root / "matched" / mode / "results.json",
            root / "matched/validation.json",
        )
        identities[mode] = native_artifacts(
            root, prev, mode, candidate, native, matched
        )
        files = [f for f in d.iterdir() if f.suffix in (".md", ".txt")]
        assert len(files) == 16
        for f in files:
            assert f.read_bytes() == (original_d / f.name).read_bytes()
            canonical += 1
        seed[mode] = read(d / "validation.json")
    nseed = audit_seeded(root, seed, configs, prev, a.skip_seeded_replay)
    paths = controls["audit_paths"](root, configs, orders)
    rss = controls["audit_rss"](root, configs, orders)
    matched_memory = runpy.run_path(str(root / "tools/matched-memory-audit.py"))[
        "audit"
    ](root, orders)
    cpu = cpu_profiles(root, identities, controls)
    valid = qa(root, prev, revision)
    if revision.startswith("a91b337"):
        ffi = read(root / "qa/heap-ffi/receipt.json")
        assert ffi["relar_revision"] == revision and ffi["source_sha256"] == sha(
            root / "qa/heap-ffi/relar-102-runtime-heap.c"
        )
        assert [(row["case"], row["expected"]) for row in ffi["checks"]] == [
            ("system", 1024),
            ("native", 0),
            ("early", 1024),
            ("", None),
        ]
    packed = root / "experiments/rejected-packed.tar.xz"
    assert (
        sha(packed)
        == "44434f084db6c029412cb4f63f25bc360166237f5fe26076fcf57ed0036961c6"
    )
    scratch = Path(t) / "packed"
    scratch.mkdir()
    with tarfile.open(packed, "r:xz") as tar:
        tar.extractall(scratch, filter="data")
    packed_review = subprocess_json(
        [scratch / "audit.py", "--study", prev, "--raw", scratch / "results.json"]
    )
    assert not packed_review["admitted"] and packed_review == read(
        scratch / "audit.json"
    )
    special = {}
    if not revision.startswith("a91b337"):
        selector = root / "experiments/measured-selector.tar.xz"
        assert (
            sha(selector)
            == "7116084037638631a734eda8f1444229dcf86efad889f3000ede8d737042f7fe"
        )
        stage = Path(t) / "selector"
        stage.mkdir()
        with tarfile.open(selector, "r:xz") as tar:
            tar.extractall(stage, filter="data")
        ix = read(stage / "index.json")
        assert ix["files"] == {
            str(f.relative_to(stage)): sha(f)
            for f in stage.rglob("*")
            if f.is_file() and f != stage / "index.json"
        }
        assert (
            ix["revision"] == "a91b337d4619eac71f557ba66a6ed1f8ef23645e"
            and ix["source_and_builds"] == checkout["files"]
            and len(ix["canonical_full_output_sha256"]) == 16
        )
        base_normal = prev / "modes/normal"
        temp_normal = stage / "mode-normal"
        for filename, digest_ in ix["canonical_full_output_sha256"].items():
            assert sha(base_normal / filename) == digest_
            (temp_normal / filename).symlink_to(base_normal / filename)
        assert (
            analytic(temp_normal)
            == ix["six_engine"]
            == read(temp_normal / "strict-audit.json")
        )
        assert bind(
            read(temp_normal / "results.json")["config"], temp_normal / "records"
        ) == read(temp_normal / "binding.json")
        assert (
            subprocess_json(
                [
                    root / "tools/gate-audit.py",
                    "--study",
                    prev,
                    "--raw",
                    stage / "admission/results.json",
                ]
            )
            == ix["native"]
        )
        special["intermediate_selector"] = {
            "normal_raw_sha256": ix["six_engine"]["results_sha256"],
            "ordinary_observations": ix["six_engine"]["observations"],
            "two_mode_admission_observations": ix["native"]["observations"],
            "excluded_unmeasured_panels": ix["unmeasured"],
        }
        assert (
            sha(root / "experiments/other-programs.tar.gz")
            == "e4c0b1af12bc9783f167548cb553e73d15e63e3cfca21cb97d9ab26152027298"
        )
        cross = Path(t) / "controls"
        cross.mkdir()
        with tarfile.open(root / "experiments/other-programs.tar.gz", "r:gz") as tar:
            tar.extractall(cross, filter="data")
        for line in (cross / "SHA256SUMS").read_text().splitlines():
            hex_, n = line.split(maxsplit=1)
            assert sha(cross / n.lstrip("*")) == hex_
        control = read(cross / "explicit-system/split-summary.json")
        assert (
            control["runtime_revision"] == revision
            and control["baseline_717_revision"] == old
            and len(control["regular_ffi"]) == 227
        )
        special["collateral_capsule_sha256"] = sha(
            root / "experiments/other-programs.tar.gz"
        )
        collateral_replay = root / "experiments/other-programs-fresh-replay.json"
        assert (
            sha(collateral_replay)
            == "a85f53de177314c9097f5da1883cf3dfc450b117a6f04ef375d08888807df8b0"
        )
        rebuilt = read(collateral_replay)
        assert rebuilt["archive_sha256"] == special["collateral_capsule_sha256"]
        assert (
            rebuilt["checked_manifest_entries"],
            rebuilt["production_elves_rebuilt_byte_identically"],
            rebuilt["sanitized_route_reruns"],
            rebuilt["fully_rebuilt_cpython_oracles"],
        ) == (23, 8, 2, 5)
        cli = read(root / "qa/cli/binary-equivalence.json")
        system = read(root / "build-qa/system-control-build.json")
        assert (
            cli["application_runtime_revision"] == revision
            and cli["integrated_revision"] == valid["live_source"]
            and len(cli["results"]) == 15
            and system["revision"] == revision
        )
        for value in cli["results"]:
            mode = value["mode"]
            group = (
                system if value["allocator"] == "system" and mode != "asan" else native
            )
            entry = group["modes"][mode]["programs"][value["name"]]
            assert (
                value["exact_elf"]["sha256"] == entry["binary"]["sha256"]
                and value["llvm"]["sha256"] == entry["llvm"]["sha256"]
            )
            assert entry["llvm_identical"] and not any(
                "jemalloc" in dep for dep in entry["needed"]
            )
            assert (entry["jemalloc_defined_symbol_count"] > 0) == (
                value["allocator"] == "jemalloc" and mode != "asan"
            )
        system_sections = read(root / "build-qa/previous-system-elf-sections.json")
        assert len(system_sections) == 6
        for key, rec in system_sections.items():
            mode, program = key.split("/")
            original_records = prev / "modes" / mode / "records"
            before = (
                read(original_records / "kernel-after.json")["binary"]
                if program == "grouping"
                else read(original_records / "program-after.json")["binaries"][
                    program.replace("conformance-report", "conformance_report", 1)
                ]
            )
            assert (
                rec["system_original_elf_sha256"] == before["sha256"]
                and rec["system_current_elf_sha256"]
                == system["modes"][mode]["programs"][program]["binary"]["sha256"]
            )
            assert (
                rec["mapped_sections_with_differences"]
                == [
                    name
                    for name, h in rec["sections"].items()
                    if h["baseline"] != h["current"]
                ]
                == [".note.gnu.build-id"]
                and ".text" in rec["sections"]
                and len(rec["sections"]) >= 20
            )
            assert (
                rec["sections"][".text"]["current"]
                == system["modes"][mode]["programs"][program]["machine"]["text_sha256"]
            )
        special["unchanged_system_mapped_payloads"] = len(system_sections)
        special["final_cli_matching_elf_files"] = len(cli["results"])
        special["final_cli_revision"] = cli["integrated_revision"]
        live_receipt = read(root / "qa/live/receipt.json")
        assert live_receipt["analyzer_sha256"] == [
            e["sha256"] for e in read(prev / "qa/live-checkout.json")["analyzers"]
        ]
        assert live_receipt["llvm_sha256"] == sha(
            root / "ir/normal/conformance-report.ll"
        )
        shadow = root / "qa/grouping-heldout"
        held = read(shadow / "receipt.json")
        bound = read(shadow / "recorded-path.json")
        assert (
            sha(shadow / "run.py") == bound["recipe_sha256"]
            and held["runtime"] == revision
            and held["checkout"] == cli["integrated_revision"]
            and held["asan_options"] == "detect_leaks=1:halt_on_error=1"
        )
        assert (
            held["start"] == 917704
            and held["count"] == 96
            and len(held["observations"]) == 192
            and set(held["commands"])
            == {"upstream", "system", "jemalloc", "asan", "rust"}
        )
        assert (
            held["engine_sha256"]["jemalloc"] == identities["normal"]["kernel_sha256"]
            and held["engine_sha256"]["system"]
            == system["modes"]["normal"]["programs"]["grouping"]["binary"]["sha256"]
            and held["engine_sha256"]["asan"]
            == native["modes"]["asan"]["programs"]["grouping"]["binary"]["sha256"]
            and held["engine_sha256"]["rust"]
            == matched["modes"]["normal"]["system_binary_sha256"]
        )
        case_rows = {(r["seed"], r["mode"]): r for r in held["observations"]}
        assert set(case_rows) == set(
            itertools.product(
                range(held["start"], held["start"] + held["count"]), ("dump", "aliases")
            )
        )
        if not a.skip_seeded_replay:
            newdir = Path(t) / "heldout"
            newdir.mkdir()
            val = runpy.run_path(
                str(src / "benchmarks/conformance_grouping_validate.py")
            )
            env = val["VALIDATION"]["environment"](newdir)
            for seedno in range(held["start"], held["start"] + held["count"]):
                folder = newdir / f"seed-{seedno}"
                folder.mkdir()
                args = val["fixture"](folder, seedno)
                for role in ("dump", "aliases"):
                    err, data = val["observation"](
                        [
                            sys.executable,
                            "-B",
                            str(src / "benchmarks/conformance_grouping_upstream.py"),
                        ],
                        [role, *args, "1"],
                        folder,
                        env,
                    )
                    assert err is None
                    raw = data.replace(
                        str(newdir).encode(), bound["absolute_directory"].encode()
                    )
                    saved = case_rows[seedno, role]
                    assert len(raw) == saved["bytes"] and digest(raw) == saved["sha256"]
        special["additional_held_out_seed_streams"] = len(case_rows)
        proof_src = root / "build-qa/build-qa.tar.gz"
        assert proof_src.is_file()
        build_archive = Path(t) / "proof"
        build_archive.mkdir()
        with tarfile.open(proof_src, "r:gz") as tar:
            tar.extractall(build_archive, filter="data")
        assert (
            sha(proof_src)
            == read(root / "build-qa/build-qa.json")["sha256"]
            == "6ec076d10ae0e52d7009a23255056c7597980cc9bd7e04a734ab5ef15d8639dd"
        )
        check = subprocess.check_output(
            [sys.executable, "-B", str(build_archive / "verify-evidence.py")], text=True
        )
        assert "15" in check and "200" in check and "60" in check
        special["build_and_cli_replay"] = check.strip()
        assert (build_archive / "admission-build-all.json").read_bytes() == (
            root / "build-qa/admission-build-all.json"
        ).read_bytes() and (
            build_archive / "cli/binary-equivalence.json"
        ).read_bytes() == (root / "qa/cli/binary-equivalence.json").read_bytes()
        assert read(root / "build-qa/build-qa.json")["file_count"] == 58
    ok = all(
        v["time_target_met"] for v in [*reviews.values(), *strong.values()]
    ) and all(max(r.values()) <= 2 for r in paths.values())
    result = {
        "status": "passed" if ok else "timing target missed",
        "revision": revision,
        "indexed_files": len(actual),
        "unchanged_application_and_reference_sources": len(checkout["files"]),
        "previous_original_revision": old,
        "previous_real_oracle_streams": prior["real_outputs_reexecuted"],
        "canonical_outputs_rechecked": canonical,
        "seeded_oracle_streams": nseed,
        "seeded_replayed": not a.skip_seeded_replay,
        "primary": reviews,
        "matched_rust": strong,
        "admission": gate_r,
        "path_sensitivity": paths,
        "full_report_peak_kib": rss,
        "matched_native_peak": matched_memory,
        "callgrind": cpu,
        "matched_rust_source_edits": rust_source_edits,
        "native": identities,
        "source_and_intermediates": special,
        "quality": valid,
        "time_target_met": ok,
    }
    print(json.dumps(result, indent=2))
    sys.exit(0 if ok else 1)
