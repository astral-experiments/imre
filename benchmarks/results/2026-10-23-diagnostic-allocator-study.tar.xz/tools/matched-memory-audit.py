"""Validate every separate three-engine process RSS observation against the frozen six-engine oracle."""

import hashlib
import json
from statistics import median


def read(p):
    return json.loads(p.read_bytes())


def audit(root, scheduling):
    raw = read(root / "matched/rss.json")
    names = ("after", "rust", "matched_rust")
    order = scheduling(names)
    assert (
        raw["cpu"] == 31
        and raw["order"] == order
        and set(raw["modes"]) == {"normal", "thinlto"}
    )
    observations = 0
    medians = {}
    for mode, mode_data in raw["modes"].items():
        matched = read(root / "matched" / mode / "results.json")
        primary_rss = read(root / "modes" / mode / "rss.json")
        assert (
            raw["revision"] == matched["revision"]
            and raw["clock_sha256"] == primary_rss["time_sha256"]
        )
        assert mode_data["binaries"] == matched["binary_sha256"] and set(
            mode_data["cases"]
        ) == {"1", "10"}
        for scale, case in mode_data["cases"].items():
            assert len(case["samples"]) == 6
            gold = hashlib.sha256(
                (root / "modes" / mode / f"{scale}x-changed-github.md").read_bytes()
            ).hexdigest()
            for i, row in enumerate([case["warmup"], *case["samples"]], start=-1):
                assert [o["engine"] for o in row] == order[i % 6] and all(
                    v["peak_kib"] > 0 and v["output_sha256"] == gold for v in row
                )
                observations += len(row)
            r = {
                e: median(
                    sample["peak_kib"]
                    for row in case["samples"]
                    for sample in row
                    if sample["engine"] == e
                )
                for e in names
            }
            assert r == case["median_kib"]
            medians[mode + "/" + scale] = r
    assert observations == 84
    return {"observations": observations, "median_kib": medians}
