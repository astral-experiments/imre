"""Prepare filesystem and immutable application/reference inputs for the allocator study."""
import argparse,json,shutil,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('revision');p.add_argument('checkout',type=Path);a=p.parse_args();c=Path(__file__).resolve().parents[1];d=c/('final-'+a.revision[:7]);d.mkdir(exist_ok=False)
for s in ('run-formal.py','make-config.py','bind-builds.py','stage-builds.py','path-sensitivity.py','peak-rss.py','build-grouping.py'):shutil.copy2(c/'final-7178431'/s,d/s)
for key in ('build-base','build-rust','build-platform','fixtures'):(d/key).symlink_to(c/key,target_is_directory=True)
(d/'build-final').symlink_to(c/('static-allocator-'+a.revision[:7])/'build-final',target_is_directory=True)
subprocess.run(['python3.14','-B',str(d/'stage-builds.py'),'--cache',str(d),'--stage','sources','--repo',str(a.checkout),'--revision',a.revision],check=True)
with tarfile.open(d/('sources-'+a.revision[:8]+'.tar.gz'),'r:gz') as t:t.extractall(d,filter='data')
old=json.loads((c/'final-7178431/source/checkout.json').read_bytes())['files'];new=json.loads((d/'source/checkout.json').read_bytes())['files'];assert old==new;print(d,len(new),'unchanged input sources')
