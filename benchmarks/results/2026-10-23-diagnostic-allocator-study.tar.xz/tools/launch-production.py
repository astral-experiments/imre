"""Bind source-locked two-archive ELFs and sequence the official runs on CPU31."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
f=Path(sys.argv[1]).resolve();c=f.parent;revision=json.loads((f/'source/checkout.json').read_bytes())['revision'];assert revision=='aa24071e3bd7d2ad7b0051a7d873d0b405ac70e5';src=c/('static-allocator-'+revision[:7]);g=c/('native-allocator-'+revision[:7]);prior=c/'final-a91b337';assert not (f/'measurements').exists() and not (g/'admission').exists();marker=f/'launch';marker.mkdir(exist_ok=False);os.sched_setaffinity(0,{7})
for name in ('candidate.json','thinlto/analysis','thinlto/report','thinlto/matched-rust'):
    assert (g/name).is_file()
(f/'build-final').symlink_to(src/'build-final',target_is_directory=True)
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ident=read(g/'candidate.json');assert ident['revision']==revision
bound={}
for mode in ('normal','thinlto'):
    groups=read(f/'build-final/kernels'/mode/'build-record.json');progs=read(f/'build-final/programs'/mode/'build-record.json');assert groups['revision']==progs['revision']==revision
    for role,path,entry in [('analysis',Path(groups['binary']['path']),groups['binary']),('report',Path(progs['binaries']['conformance_report']['path']),progs['binaries']['conformance_report']),('compute',Path(progs['binaries']['conformance_report-compute']['path']),progs['binaries']['conformance_report-compute'])]:
        assert sha(path)==entry['sha256'];bound[mode+'/'+role]=sha(path)
        if role!='compute':assert sha(g/mode/role)==entry['sha256']==ident['modes'][mode][role]['sha256']
    assert sha(g/mode/'matched-rust')==ident['modes'][mode]['matched_rust']['sha256']
(marker/'host-bindings.json').write_text(json.dumps(bound,indent=2)+'\n');print('final 6 canonical ELFs and 6 gate copies verified',json.dumps(bound),flush=True)
while not (prior/'phase-closed.json').exists():time.sleep(.25)
assert read(prior/'phase-closed.json')['revision'].startswith('a91b337');p=Path(sys.executable).resolve()
os.sched_setaffinity(0,{31});subprocess.run([str(p),'-B','-u',str(g/'run.py'),'--frozen',str(c/'final-7178431'),'--staged',str(g),'--cpu','31'],check=True)
assert read(g/'admission/results.json')['admitted'];subprocess.run([str(p),'-B','-u',str(f/'dispatch.py'),str(f)],check=True);print('completed final audited primary + secondary comparisons',flush=True)
