"""Publish exact raw records after a fresh independent offline replay."""

import argparse, gzip, hashlib, json, shutil, subprocess, sys, tarfile, tempfile
from pathlib import Path


def normalized(info):
    info.uid = info.gid = info.mtime = 0
    info.uname = info.gname = ""
    info.mode = 0o755 if info.isdir() else 0o644
    return info


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("study", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--name", default="2026-10-23-diagnostic-allocator")
a = p.parse_args()
assert not sys.flags.optimize and sys.version_info >= (3, 14)
src = a.study.resolve()
a.output.mkdir(parents=True, exist_ok=True)
assert (src / "index.json").is_file()
with tempfile.TemporaryDirectory(dir=src.parent, prefix="fresh-allocator-replay-") as d:
    tmp = Path(d)
    dest = tmp / "publish"
    dest.mkdir()
    archive = dest / (a.name + "-study.tar.xz")
    rest = tmp / "fresh"
    rest.mkdir()
    with tarfile.open(archive, "w:xz", preset=6) as tar:
        for f in sorted(src.rglob("*")):
            if "__pycache__" not in f.parts and f.suffix != ".pyc":
                tar.add(
                    f,
                    arcname=str(f.relative_to(src)),
                    recursive=False,
                    filter=normalized,
                )
    with tarfile.open(archive, "r:xz") as tar:
        tar.extractall(rest, filter="data")
    result = subprocess.run(
        [sys.executable, "-B", str(rest / "tools/replay.py"), str(rest)],
        capture_output=True,
        timeout=3600,
    )
    if result.returncode:
        raise RuntimeError(
            result.stderr.decode()[-9000:] + result.stdout.decode()[-2500:]
        )
    receipt = json.loads(result.stdout)
    assert (
        receipt["time_target_met"]
        and receipt["status"] == "passed"
        and receipt["seeded_replayed"]
        and receipt["canonical_outputs_rechecked"] == 32
    )
    (dest / (a.name + "-audit.json")).write_bytes(result.stdout)
    for mode, display in [("normal", "ordinary"), ("thinlto", "thinlto")]:
        raw = rest / "modes" / mode / "results.json"
        assert sha(raw) == receipt["primary"][mode]["results_sha256"]
        out = dest / (a.name + "-" + display + ".json.gz")
        with (
            out.open("wb") as f,
            gzip.GzipFile(
                filename="", fileobj=f, mode="wb", mtime=0, compresslevel=9
            ) as gz,
        ):
            gz.write(raw.read_bytes())
        assert gzip.decompress(out.read_bytes()) == raw.read_bytes()
    subprocess.run(
        [
            sys.executable,
            "-B",
            str(rest / "tools/render.py"),
            str(rest),
            str(dest / (a.name + ".md")),
            str(dest / (a.name + "-audit.json")),
        ],
        check=True,
    )
    for f in sorted(dest.iterdir()):
        target = a.output / f.name
        assert not target.exists(), target
        shutil.copy2(f, target)
        assert sha(f) == sha(target)
        print(f.name, target.stat().st_size, sha(target), flush=True)
