"""Bounded 959 dataclasses original-suite capture using the repository finite runner/probe."""
import collections,hashlib,json,os,pathlib,shutil,signal,subprocess,sys,tarfile,time
R=pathlib.Path(__file__).resolve().parent; W=pathlib.Path('/workspace/scratch/imre-dataclasses-959'); B=W/'benchmarks/compatibility'; sys.path.insert(0,str(B))
from collect_unittest_results import parse
import raw_control,scorecard
P=pathlib.Path('/workspace/scratch/imre-95908-transferred-config-v1/product'); PY=pathlib.Path('/workspace/scratch/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'); SOURCE=pathlib.Path('/workspace/scratch/configparser-959-explore-v1/fixtures'); TAR=pathlib.Path('/workspace/scratch/cpython-3.14.5.tar.gz'); REV='95908fb0acadc2a67304a8080e584deaef395746'; COMMIT='5607950ef232dad16d75c0cf53101d9649d89115'
RAW=R/'raw';L=R/'launch/launcher.py';EXT=R/'fixtures/Lib';CWD=R/'empty';TMP=R/'tmp';ARCH=L.parent/'stock.source.py';PROBE=R/'probe'
BASE={'PYTHONPATH':str(EXT),'PYTHONDONTWRITEBYTECODE':'1','PYTHON_COLORS':'0','NO_COLOR':'1','TMPDIR':str(TMP),'PATH':str(P/'imre-toolchain/bin')};BUILD={**BASE,'PATH':str(P/'imre-toolchain/bin')+':/usr/bin:/bin','HOME':str(R/'home')}
MODULES=['test.test_dataclasses']+['test.test_dataclasses.'+s for s in ('dataclass_module_1','dataclass_module_1_str','dataclass_module_2','dataclass_module_2_str','dataclass_textanno')]
SYSCALLS='execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,statx,rename,renameat,renameat2,wait4,exit_group,chdir,fchdir,close,dup,dup2,dup3,fcntl,clone,clone3,fork,vfork,write,writev,unlink,unlinkat'
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def keys(rows):return [(r['id'],r['occurrence']) for r in rows]
def stat(s):return {'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mode':s.st_mode,'ctime_ns':s.st_ctime_ns,'mtime_ns':s.st_mtime_ns}
def fdrecord(fd,path):
 a=os.fstat(fd);os.lseek(fd,0,os.SEEK_SET);h=hashlib.file_digest(os.fdopen(os.dup(fd),'rb'),'sha256').hexdigest();z=os.fstat(fd);return {'fd':fd,'path':str(path),'canonical_path':os.path.realpath(path),'fstat_before_read':stat(a),'fstat_after_read':stat(z),'path_stat':stat(os.stat(path)),'sha256':h}
def manifest():
 return {str(p.relative_to(R/'fixtures')):sha(p) for p in sorted((R/'fixtures').rglob('*')) if p.is_file()}
def command(tier,out):
 a=[str(P/'imre'),'build',str(L),'--module-root',str(L.parent),'--extension-path',str(EXT),'--no-cache','--quiet','--opt-level',tier[1:],'--runtime',str(P/'libimre_runtime.a'),'--clang',str(P/'imre-toolchain/bin/clang')]
 for m in MODULES:a+=['--include-module',m]
 return a+['-o',str(out)]
def capture(name,target,env,cap,held,trace_calls=SYSCALLS):
 tr=RAW/(name+'.trace');argv=['/usr/bin/strace','-f','-yy','-v','-qq','-s','512','-e','trace='+trace_calls,'-o',str(tr),*target];fds={k:os.open(str(p),os.O_RDONLY) for k,p in held.items()};before={k:fdrecord(fds[k],p) for k,p in held.items()};start=time.monotonic();deadline=start+cap;samples=[]; proc=None
 try:
  proc=subprocess.Popen(argv,cwd=CWD,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);seen=set()
  while proc.poll() is None and time.monotonic()<min(deadline,start+2):
   try:children=pathlib.Path(f'/proc/{proc.pid}/task/{proc.pid}/children').read_text().split()
   except OSError:children=[]
   for pid in children:
    if pid in seen:continue
    try:
     fd=os.open('/proc/'+pid+'/exe',os.O_RDONLY);s=os.fstat(fd);targetpath=os.readlink('/proc/'+pid+'/exe');os.close(fd)
     matches=[k for k,x in before.items() if s.st_dev==x['fstat_before_read']['dev'] and s.st_ino==x['fstat_before_read']['ino']]
     if matches:samples.append({'pid':int(pid),'target':targetpath,'fstat':stat(s),'held_matches':matches});seen.add(pid)
    except OSError:pass
   time.sleep(.005)
  timed=False
  try:out,err=proc.communicate(timeout=max(.001,deadline-time.monotonic()))
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(proc.pid,signal.SIGKILL);out,err=proc.communicate(timeout=10)
  after={k:fdrecord(fds[k],p) for k,p in held.items()};(RAW/(name+'.stdout')).write_bytes(out);(RAW/(name+'.stderr')).write_bytes(err)
  v={'target_argv':target,'trace_argv':argv,'cwd':str(CWD),'environment':env,'timeout_seconds':cap,'seconds':time.monotonic()-start,'exit_code':proc.returncode,'timed_out':timed,'held_before':before,'held_after':after,'live_samples':samples,'trace_sha256':sha(tr),'stdout_sha256':sha(RAW/(name+'.stdout')),'stderr_sha256':sha(RAW/(name+'.stderr')),'controller_sha256':sha(__file__)}
  assert before==after;dump(RAW/(name+'.json'),v);return v,err
 finally:
  for fd in fds.values():os.close(fd)
def prep():
 for d in (RAW,L.parent,R/'empty',TMP,R/'home'):d.mkdir(parents=True,exist_ok=True)
 shutil.copytree(SOURCE,R/'fixtures');subprocess.run([sys.executable,'-B',str(B/'generate_unittest_runner.py'),'--module',MODULES[0],'--output',str(L)],check=True);orig=[json.loads(x) for x in (B/'stdlib/dataclasses.jsonl').read_bytes().splitlines()];assert len(orig)==276 and len(set(keys(orig)))==276;dump(R/'originals.json',[{'id':x['id'],'occurrence':x['occurrence']} for x in orig]);s=orig[0]['source'];leaf=EXT/pathlib.Path(s['path']).relative_to('Lib')
 with tarfile.open(TAR) as t:
  assert t.pax_headers.get('comment')==COMMIT;data=t.extractfile('cpython-'+COMMIT+'/'+s['path']).read();assert data==leaf.read_bytes();ARCH.write_bytes(data)
 assert sha(leaf)==s['sha256'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==s['git_blob'];src=B/'extensions/successor959_v1/evidence/json/gate-correction-v2/probe-source.c';shutil.copyfile(src,R/'probe.c');subprocess.run(['/usr/bin/cc','-O2','-Wall','-Wextra','-o',str(PROBE),str(R/'probe.c')],check=True)
 dump(R/'fixtures.before.json',manifest());v={'revision':REV,'source_tree':'e6405a3243de706adcab772bf16942808d6ca6fb','source':s,'fixture_files':len(manifest()),'fixture_manifest_sha256':sha(R/'fixtures.before.json'),'launcher_sha256':sha(L),'source_archive_sha256':sha(TAR),'source_capture_sha256':sha(ARCH),'products':{k:sha(p) for k,p in {'cli':P/'imre','runtime':P/'libimre_runtime.a','clang':P/'imre-toolchain/bin/clang','stock':PY,'cli_depfile':P/'imre.d','runtime_depfile':P/'libimre_runtime.d','probe':PROBE,'probe_source':R/'probe.c','cc':pathlib.Path('/usr/bin/cc')}.items()},'compiler_environment':BUILD,'suite_environment':BASE};dump(R/'identity.json',v);print('prepared',v['fixture_files'],v['products'],flush=True)
def suite(tier):
 leaf=EXT/'test/test_dataclasses/__init__.py';tree=EXT/'test';stash=EXT/'test.raw-control-stash';image=R/(tier+'.exe')
 env=BASE.copy();target=[str(PY),'-B',str(L)] if tier=='stock' else [str(PROBE),'withdraw',str(tree),str(stash),str(leaf),str(image)]
 if tier!='stock':env.update(IMRE_WITHDRAW_LAUNCHER=str(L),IMRE_WITHDRAW_ARCHIVE=str(ARCH))
 try:v,err=capture(tier,target,env,240,{'stock':PY} if tier=='stock' else {'image':image})
 finally:
  for p in (ARCH,L):
   q=pathlib.Path(str(p)+'.raw-control-stash')
   if q.exists() and not p.exists():q.rename(p)
  if stash.exists() and not tree.exists():stash.rename(tree)
 assert sha(L)==json.loads((R/'identity.json').read_text())['launcher_sha256'] and manifest()==json.loads((R/'fixtures.before.json').read_text())
 res=parse(err,v['timed_out']);dump(RAW/(tier+'.originals.json'),res);canon=json.loads((R/'originals.json').read_text());report={'tier':tier,'collection':res['collection'],'inventory_exact':keys(canon)==keys(res['originals']),'outcomes':dict(collections.Counter(x['outcome'] for x in res['originals'])),'exit_code':v['exit_code'],'timeout':v['timed_out'],'seconds':v['seconds'],'fixture_restored':True};dump(RAW/(tier+'.summary.json'),report);print(json.dumps(report),flush=True)
def gate(tier,mode):
 positive=L.read_bytes();line=(b'status: int = True\n' if mode=='direct' else b'import dataclasses_gate_poison\n');parts=positive.splitlines(keepends=True);negative=(positive.replace(b'import unittest\n',b'import unittest\n'+line,1) if mode=='direct' else parts[0]+line+b''.join(parts[1:]));poison=L.parent/'dataclasses_gate_poison.py';image=R/(tier+'.'+mode+'.no-image');assert not image.exists();L.write_bytes(negative)
 if mode=='imported':poison.write_bytes(b'status: int = True\n')
 try:v,err=capture('gate.'+tier+'.'+mode,[str(PROBE),'gate',str(image),*command(tier,image)],BUILD,120,{'cli':P/'imre','runtime':P/'libimre_runtime.a','clang':P/'imre-toolchain/bin/clang'});text=(RAW/('gate.'+tier+'.'+mode+'.trace')).read_text();diagnostic=err.decode();getattr(raw_control,'trace_direct_gate' if mode=='direct' else 'trace_gate')(text,command(tier,image),str(PROBE),*(([str(poison),diagnostic,scorecard.require]) if mode=='imported' else [diagnostic,scorecard.require]),expected_exit=1);assert v['exit_code']==0 and not image.exists() and 'expected int, got bool' in diagnostic;print('gate',tier,mode,'PASS',round(v['seconds'],3),flush=True)
 finally:L.write_bytes(positive);poison.unlink(missing_ok=True)
def build(tier):
 image=R/(tier+'.exe');v,err=capture(tier+'.build',command(tier,image),BUILD,360,{'cli':P/'imre','runtime':P/'libimre_runtime.a','clang':P/'imre-toolchain/bin/clang'},'execve,execveat,wait4,exit_group,open,openat,openat2,creat');v['image_sha256']=sha(image) if image.exists() else None;v['image_bytes']=image.stat().st_size if image.exists() else None;dump(RAW/(tier+'.build.json'),v);print('build',tier,v['exit_code'],v['timed_out'],round(v['seconds'],2),v['image_sha256'],flush=True)
if __name__=='__main__':
 a=sys.argv[1]
 if a=='prep':prep()
 elif a=='stock' or a in ('O0-run','O3-run'):suite(a.split('-')[0])
 elif a.endswith('-build'):build(a.split('-')[0])
 else:t,m=a.split('-');gate(t,m)
