import hashlib,json,os,pathlib,re,sys,time
r=pathlib.Path(__file__).resolve().parent;tier=sys.argv[1];role=sys.argv[2];p=pathlib.Path('/workspace/scratch/imre-95908-transferred-config-v1/product')/('imre' if role=='cli' else 'imre-toolchain/bin/clang');tr=r/'raw'/(tier+'.build.trace');lines=tr.read_text().splitlines();candidates=[int(x.split()[0]) for x in lines if re.match(r'^\d+\s+execve\("'+re.escape(str(p))+'"',x)];records=[]
for pid in reversed(candidates):
 try:
  f=os.open('/proc/'+str(pid)+'/exe',os.O_RDONLY);g=os.open(p,os.O_RDONLY);a=os.fstat(f);b=os.fstat(g);record=lambda s:{'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'ctime_ns':s.st_ctime_ns,'mode':s.st_mode};v={'scope':'independent after-exec sample, not atomic FD exec','role':role,'pid':pid,'sample_time_ns':time.time_ns(),'proc_target':os.readlink('/proc/'+str(pid)+'/exe'),'proc_stat':record(a),'product_stat':record(b),'matches':record(a)==record(b),'observer_source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()};os.close(f);os.close(g)
  if v['matches']:records.append(v);break
 except OSError:pass
if not records:raise SystemExit('no live matched '+role+' process')
q=r/'raw'/(tier+'.'+role+'-live.json');q.write_text(json.dumps(records[0],indent=2)+'\n');print(role,records[0]['pid'],records[0]['matches'])
