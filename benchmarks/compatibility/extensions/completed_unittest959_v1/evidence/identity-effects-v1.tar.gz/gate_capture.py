"""Four bounded poison controls; hold the exact product FDs and sample live compiler exe."""
import hashlib,importlib.util,json,os,pathlib,re,signal,subprocess,time
D=pathlib.Path(__file__).resolve().parent;P=D/'gates';P.mkdir(exist_ok=True)
p=pathlib.Path('/workspace/scratch/dataclasses-959-replay-v1/controller.py');spec=importlib.util.spec_from_file_location('frozen_controller',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.R=D;m.RAW=P
held={'cli':m.P/'imre','runtime':m.P/'libimre_runtime.a','clang':m.P/'imre-toolchain/bin/clang'}
fds={k:os.open(v,os.O_RDONLY|os.O_CLOEXEC) for k,v in held.items()}
def record():return {k:m.fdrecord(fds[k],v) for k,v in held.items()}
def dump(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def capture(name,target,env,cap,unused,trace_calls=m.SYSCALLS):
 tr=P/(name+'.trace');argv=['/usr/bin/strace','-f','-yy','-v','-qq','-s','65535','-e','trace='+trace_calls,'-o',str(tr),'--',*target];pre=record();startns=time.time_ns();start=time.monotonic();deadline=start+cap;sample=None;proc=None;timed=False;out=err=b'';image=pathlib.Path(target[2]);assert not image.exists()
 try:
  proc=subprocess.Popen(argv,cwd=m.CWD,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  while proc.poll() is None and sample is None and time.monotonic()<deadline:
   if tr.exists():
    with tr.open() as f:
     for line in f:
      x=re.match(r'^(\d+)\s+execve\('+re.escape(json.dumps(str(held['cli'])))+r',',line)
      if not x:continue
      try:
       fd=os.open('/proc/'+x[1]+'/exe',os.O_RDONLY|os.O_CLOEXEC)
       try:s=m.stat(os.fstat(fd));path=os.readlink('/proc/'+x[1]+'/exe')
       finally:os.close(fd)
       if s==pre['cli']['fstat_before_read']:sample={'pid':int(x[1]),'target':path,'fstat':s,'sample_utc_ns':time.time_ns()}
      except OSError:pass
      break
   if sample is None:time.sleep(.002)
  try:out,err=proc.communicate(timeout=max(.001,deadline-time.monotonic()))
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(proc.pid,signal.SIGTERM)
   try:out,err=proc.communicate(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);out,err=proc.communicate(timeout=5)
 finally:post=record()
 (P/(name+'.stdout')).write_bytes(out);(P/(name+'.stderr')).write_bytes(err);lines=tr.read_text().splitlines();first,child=m.raw_control.execs(lines,m.scorecard.require);exit_code=m.raw_control.child_exit_code(lines,child[1],m.scorecard.require)
 v={'schema':'imre.compatibility.held-gate-live.v1','target_argv':target,'trace_argv':argv,'cwd':str(m.CWD),'environment':env,'timeout_seconds':cap,'seconds':time.monotonic()-start,'start_utc_ns':startns,'finish_utc_ns':time.time_ns(),'exit_code':proc.returncode,'compiler_child_exit_code':exit_code,'timed_out':timed,'held_before':pre,'held_after':post,'live_compiler_sample':sample,'trace_sha256':m.sha(tr),'stdout_sha256':m.sha(P/(name+'.stdout')),'stderr_sha256':m.sha(P/(name+'.stderr')),'controller_sha256':m.sha(__file__),'frozen_controller_sha256':m.sha(p),'negative_launcher_sha256':m.sha(m.L),'poison_sha256':m.sha(m.L.parent/'dataclasses_gate_poison.py') if (m.L.parent/'dataclasses_gate_poison.py').exists() else None,'image_absent_before':True,'image_absent_after':not image.exists(),'identity_limit':'After-exec sample, not atomic FD exec.'};dump(P/(name+'.json'),v)
 assert not timed and pre==post and sample and sample['pid']==int(child[1]) and child[2]==str(held['cli']) and sample['target']==str(held['cli']) and exit_code==1 and proc.returncode==0 and not image.exists();return v,err
m.capture=capture
positive=m.L.read_bytes();baseline=record()
try:
 for t in ('O0','O3'):
  for mode in ('direct','imported'):
   assert m.L.read_bytes()==positive and not (m.L.parent/'dataclasses_gate_poison.py').exists();m.gate(t,mode);assert m.L.read_bytes()==positive and not (m.L.parent/'dataclasses_gate_poison.py').exists()
 assert baseline==record();dump(P/'bracket.json',{'schema':'imre.compatibility.held-gate-bracket.v1','controller_sha256':m.sha(__file__),'frozen_controller_sha256':m.sha(p),'held_before':baseline,'held_after':record(),'launcher_sha256':hashlib.sha256(positive).hexdigest(),'gates':[t+'.'+k for t in ('O0','O3') for k in ('direct','imported')],'credit':0})
finally:
 for f in fds.values():os.close(f)
 assert m.L.read_bytes()==positive and not (m.L.parent/'dataclasses_gate_poison.py').exists()
