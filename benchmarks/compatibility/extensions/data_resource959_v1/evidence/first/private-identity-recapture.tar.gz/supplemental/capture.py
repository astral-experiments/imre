import os,subprocess,pathlib,stat,hashlib,json,time
D=pathlib.Path(__file__).resolve().parent;P=pathlib.Path('/workspace/scratch/imre-95908-transferred-config-v1/product');targets={'compiler':P/'imre','clang':P/'imre-toolchain/bin/clang'};rows=[]; ps=subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines()
for role,path in targets.items():
 for line in ps:
  bits=line.strip().split(None,1)
  if len(bits)<2 or not bits[1].startswith(str(path)+' '):continue
  pid=int(bits[0]); fd=None; live=None
  try:
   live=os.open(f'/proc/{pid}/exe',os.O_RDONLY|os.O_CLOEXEC);fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC);a=os.fstat(live);b=os.fstat(fd)
   attrs=lambda x:{'dev':x.st_dev,'ino':x.st_ino,'size':x.st_size,'ctime_ns':x.st_ctime_ns,'mtime_ns':x.st_mtime_ns,'mode':stat.S_IMODE(x.st_mode)};assert attrs(a)==attrs(b);h=hashlib.sha256()
   while chunk:=os.read(fd,1024*1024):h.update(chunk)
   rows.append({'role':role,'pid':pid,'observed_utc_ns':time.time_ns(),'proc_exe_target':os.readlink(f'/proc/{pid}/exe'),'product_path':str(path),'proc_fstat':attrs(a),'product_fstat':attrs(b),'product_sha256':h.hexdigest(),'actual_argv':pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')[:-1] and [x.decode() for x in pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')[:-1]]});break
  except (OSError,AssertionError):pass
  finally:
   if fd is not None:os.close(fd)
   if live is not None:os.close(live)
report={'schema':'imre.configparser959.live-exe-observer.v1','captured_utc_ns':time.time_ns(),'capture_source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'samples':rows,'credit':0,'limitations':'Sampled running process image after exec; no process environment was read, path-based exec is not atomic FD execution.'};p=D/'report.json';p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({'samples':[{'role':r['role'],'pid':r['pid'],'hash':r['product_sha256']} for r in rows],'report_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'credit':0}))