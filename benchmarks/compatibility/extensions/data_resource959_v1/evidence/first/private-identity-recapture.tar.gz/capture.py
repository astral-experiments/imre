"""Private bounded identity recapture. No ambient child environment."""
import collections,datetime,fcntl,hashlib,json,os,pathlib,signal,stat,subprocess,sys,threading,time
O=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/scratch/configparser-959-explore-v1');BENCH=pathlib.Path('/workspace/scratch/imre-scorecard-test-drift/benchmarks/compatibility');sys.path.insert(0,str(BENCH));from collect_unittest_results import parse
P=pathlib.Path('/workspace/scratch/imre-95908-transferred-config-v1/product');PYTHON=pathlib.Path('/workspace/scratch/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14')
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):
 with open(p,'rb') as h:return hashlib.file_digest(h,'sha256').hexdigest()
def fdsha(fd):
 h=hashlib.sha256();offset=0
 while data:=os.pread(fd,1024*1024,offset):h.update(data);offset+=len(data)
 return h.hexdigest()
def fdrecord(fd,path):
 st=os.fstat(fd);return {'path':str(path),'canonical_path':str(path.resolve()),'fd':fd,'flags':fcntl.fcntl(fd,fcntl.F_GETFL),'sha256':fdsha(fd),'dev':st.st_dev,'ino':st.st_ino,'ctime_ns':st.st_ctime_ns,'mtime_ns':st.st_mtime_ns,'mode':oct(stat.S_IMODE(st.st_mode)),'bytes':st.st_size,'nlink':st.st_nlink}
def children(pid):
 try:return [int(i) for i in pathlib.Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
 except (OSError,ValueError):return []
def monitor(root,held,stop,records,trace):
 sampled=set();reported=set();offset=0
 while not stop.is_set():
  try:
   with trace.open() as f:
    f.seek(offset);lines=f.readlines();offset=f.tell()
   for line in lines:
    import re
    m=re.match(r'^(\d+)\s+execve\("([^"]+)"',line)
    if not m:continue
    pid=int(m[1]);target=m[2];role='cli' if target==held.get('cli',{}).get('path') else 'clang' if target==held.get('clang',{}).get('path') else None
    if not role:continue
    try:
     fd=os.open(f'/proc/{pid}/exe',os.O_RDONLY|os.O_CLOEXEC);st=os.fstat(fd);os.close(fd);cmd=pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0');args=[os.fsdecode(v) for v in cmd if v];tag=role+('-link' if role=='clang' and '-c' not in args else '')
     if tag in sampled:continue
     ref=held[role];records.append({'role':tag,'pid':pid,'proc_exe':f'/proc/{pid}/exe','target':os.readlink(f'/proc/{pid}/exe'),'dev':st.st_dev,'ino':st.st_ino,'bytes':st.st_size,'held_fd_matches':(st.st_dev,st.st_ino,st.st_size)==(ref['dev'],ref['ino'],ref['bytes']),'argv':args,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});sampled.add(tag)
    except OSError as e:
     if role not in reported:records.append({'role':role,'pid':pid,'sample_error_errno':e.errno,'sample_error':str(e)});reported.add(role)
  except OSError:pass
  stop.wait(.01)
def run(name,cmd,env,cwd,bound,paths,syscalls):
 d=O/name;d.mkdir();fds={k:os.open(v,os.O_RDONLY|os.O_CLOEXEC) for k,v in paths.items()}
 try:
  before={k:fdrecord(fd,paths[k]) for k,fd in fds.items()};baseline=json.loads((O/'before.json').read_text())['inputs']
  for k,v in before.items():assert v['sha256']==baseline[str(paths[k])]['sha256'] and (v['flags']&os.O_ACCMODE)==os.O_RDONLY,k
  trace=d/'run.trace';argv=['/usr/bin/strace','-f','-yy','-v','-qq','-s','512','-e','trace='+syscalls,'-o',str(trace),'/usr/bin/timeout','--signal=TERM','--kill-after=5s',str(bound)+'s',*cmd]
  begin=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic();proc=subprocess.Popen(argv,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);stop=threading.Event();samples=[];t=threading.Thread(target=monitor,args=(proc.pid,before,stop,samples,trace),daemon=True);t.start();outer_timeout=False
  try:stdout,stderr=proc.communicate(timeout=bound+12)
  except subprocess.TimeoutExpired:
   outer_timeout=True;os.killpg(proc.pid,signal.SIGTERM)
   try:stdout,stderr=proc.communicate(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);stdout,stderr=proc.communicate(timeout=5)
  stop.set();t.join(timeout=2);after={k:fdrecord(fd,paths[k]) for k,fd in fds.items()};end=datetime.datetime.now(datetime.timezone.utc).isoformat();(d/'stdout').write_bytes(stdout);(d/'stderr').write_bytes(stderr)
  info={'name':name,'capture_controller_sha256':sha(__file__),'trace_argv':argv,'target_argv':cmd,'cwd':cwd,'environment':env,'suite_or_build_cap_seconds':bound,'utc_start':begin,'utc_finish':end,'seconds':round(time.monotonic()-start,3),'exit_code':proc.returncode,'outer_timeout':outer_timeout,'held_fd_before':before,'held_fd_after':after,'fd_records_identical':before==after,'live_exe_samples':samples,'trace_sha256':sha(trace),'trace_bytes':trace.stat().st_size,'stdout_sha256':sha(d/'stdout'),'stderr_sha256':sha(d/'stderr')}
  dump(d/'capture.json',info)
  if name=='stock':
   res=parse(stderr,outer_timeout or proc.returncode==124);dump(d/'originals.json',res);original=json.loads((R/'raw/stock.originals.json').read_text());print('stock',round(info['seconds'],3),collections.Counter(x['outcome'] for x in res['originals']),'exact',res['originals']==original['originals'],'fdstable',info['fd_records_identical'],flush=True)
  else:
   image=pathlib.Path(cmd[cmd.index('-o')+1]);info.update(image_sha256=sha(image) if image.exists() else None,image_bytes=image.stat().st_size if image.exists() else None,original_image_sha256=json.loads((R/'raw'/f'{name}.build.json').read_text())['image_sha256']);info['image_matches_original']=info['image_sha256']==info['original_image_sha256'];dump(d/'capture.json',info);print(name,'exit',info['exit_code'],'seconds',info['seconds'],'fdstable',info['fd_records_identical'],'image_matches',info['image_matches_original'],'samples',[(x['role'],x['pid']) for x in samples],flush=True)
 finally:
  for fd in fds.values():os.close(fd)
def main():
 name=sys.argv[1]
 if name=='stock':
  m=json.loads((R/'raw/stock.json').read_text());syscalls='execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,statx,rename,renameat,renameat2,wait4,waitid,exit,exit_group,chdir,fchdir,close,close_range,dup,dup2,dup3,fcntl,clone,clone3,fork,vfork,write,writev,unlink,unlinkat,link,linkat,symlink,symlinkat';run(name,m['argv'],m['environment'],m['cwd'],240,{'stock':PYTHON},syscalls)
 elif name in {'O0','O3'}:
  m=json.loads((R/'raw'/f'{name}.build.json').read_text());cmd=list(m['argv']);cmd[cmd.index('-o')+1]=str(O/(name+'.exe'));run(name,cmd,m['environment'],m['cwd'],360,{'cli':P/'imre','runtime':P/'libimre_runtime.a','clang':P/'imre-toolchain/bin/clang'},'execve,execveat,clone,clone3,fork,vfork,wait4,waitid,exit,exit_group')
if __name__=='__main__':main()
