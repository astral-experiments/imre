// Small traced supervisor for gate and saved-image source withdrawal controls.
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>

static int absent(const char *path) {
    struct stat st;
    errno = 0;
    return fstatat(AT_FDCWD, path, &st, AT_SYMLINK_NOFOLLOW) == -1 && errno == ENOENT;
}
static int kind(const char *path, int directory) {
    struct stat st;
    return !fstatat(AT_FDCWD, path, &st, AT_SYMLINK_NOFOLLOW)
        && (directory ? S_ISDIR(st.st_mode) : S_ISREG(st.st_mode));
}
static int child(char **argv) {
    pid_t pid = fork(); int status;
    if (pid < 0) return -1;
    if (!pid) { execv(argv[0], argv); _exit(127); }
    if (waitpid(pid, &status, 0) != pid || !WIFEXITED(status)) return -1;
    return WEXITSTATUS(status);
}
static volatile sig_atomic_t wrapped_pid;
static void stop_wrapped(int sig) {
    (void)sig;
    if (wrapped_pid > 0) kill(-(pid_t)wrapped_pid, SIGKILL);
}
static int reap_adopted(void) {
    struct timespec start, now, pause = {0, 10000000};
    if (clock_gettime(CLOCK_MONOTONIC, &start)) return 0;
    for (;;) {
        int status; pid_t p = waitpid(-1, &status, WNOHANG);
        if (p > 0) continue;
        if (p < 0) return errno == ECHILD;
        if (clock_gettime(CLOCK_MONOTONIC, &now) || now.tv_sec - start.tv_sec >= 2) return 0;
        nanosleep(&pause, NULL);
    }
}
static int child_bounded(char **argv, unsigned seconds) {
    if (prctl(PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0)) return -1;
    struct sigaction action = {0}, previous[3];
    const int signals[] = {SIGALRM, SIGTERM, SIGINT};
    sigset_t blocked, oldmask;
    sigemptyset(&blocked);
    for (int i = 0; i < 3; i++) sigaddset(&blocked, signals[i]);
    if (sigprocmask(SIG_BLOCK, &blocked, &oldmask)) return -1;
    action.sa_handler = stop_wrapped;
    sigemptyset(&action.sa_mask);
    for (int i = 0; i < 3; i++)
        if (sigaction(signals[i], &action, &previous[i])) return -1;
    pid_t pid = fork(); int status = 0, waited;
    if (!pid) {
        for (int i = 0; i < 3; i++) sigaction(signals[i], &previous[i], NULL);
        sigprocmask(SIG_SETMASK, &oldmask, NULL);
        if (setpgid(0, 0)) _exit(126);
        execv(argv[0], argv); _exit(127);
    }
    if (pid < 0) { sigprocmask(SIG_SETMASK, &oldmask, NULL); return -1; }
    wrapped_pid = pid;
    if (setpgid(pid, pid) && errno != EACCES && errno != ESRCH) kill(pid, SIGKILL);
    alarm(seconds);
    sigprocmask(SIG_SETMASK, &oldmask, NULL);
    do { waited = waitpid(pid, &status, 0); } while (waited < 0 && errno == EINTR);
    alarm(0); wrapped_pid = 0;
    for (int i = 0; i < 3; i++) sigaction(signals[i], &previous[i], NULL);
    int reaped = reap_adopted();
    return waited == pid && WIFEXITED(status) && reaped ? WEXITSTATUS(status) : -1;
}
static int wrap_withdraw(int argc, char **argv) {
    if (argc < 7) return 64;
    char *end = NULL; unsigned long seconds = strtoul(argv[2], &end, 10);
    if (!*argv[2] || *end || !seconds || seconds > 3600) return 64;
    const char *tree = argv[3], *stash = argv[4], *leaf = argv[5];
    if (!kind(tree, 1) || !kind(leaf, 0) || !absent(stash) || rename(tree, stash)) return 72;
    int before = absent(tree) && absent(leaf);
    int code = before ? child_bounded(argv + 6, (unsigned)seconds) : -1;
    int after = absent(tree) && absent(leaf);
    int restored = after && kind(stash, 1) && !rename(stash, tree)
        && kind(tree, 1) && kind(leaf, 0) && absent(stash);
    return !before || !after || !restored || code < 0 ? 73 : code;
}
static int absent_exec(int argc, char **argv) {
    int i = 2;
    while (i < argc && strcmp(argv[i], "--")) {
        if (!absent(argv[i++])) return 74;
    }
    if (i == 2 || i + 2 != argc || unsetenv("PWD")) return 64;
    execv(argv[i+1], argv+i+1);
    return 127;
}

int main(int argc, char **argv) {
    if (argc > 1 && !strcmp(argv[1], "withdraw-wrap")) return wrap_withdraw(argc, argv);
    if (argc > 1 && !strcmp(argv[1], "absent-exec")) return absent_exec(argc, argv);
    if (argc >= 5 && !strcmp(argv[1], "gate")) {
        if (!absent(argv[2])) return 70;
        int code = child(argv + 3);
        if (code <= 0 || !absent(argv[2])) return 71;
        return 0;
    }
    if (argc == 6 && !strcmp(argv[1], "withdraw")) {
        const char *tree = argv[2], *stash = argv[3], *leaf = argv[4];
        if (!kind(tree, 1) || !kind(leaf, 0) || !absent(stash) || rename(tree, stash)) return 72;
        int before = absent(tree) && absent(leaf);
        char *args[] = {argv[5], NULL};
        int code = before ? child(args) : -1;
        int after = absent(tree) && absent(leaf);
        int restored = after && kind(stash, 1) && !rename(stash, tree)
        && kind(tree, 1) && kind(leaf, 0) && absent(stash);
        if (!before || !after || !restored || code < 0) return 73;
        return code;
    }
    return 64;
}
