"""Seal compact private artifacts; never include workload/product images or archives."""
from __future__ import annotations
import hashlib,json,os,pathlib,shutil,stat,sys,tarfile,time
O=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/scratch/configparser-959-explore-v1');F=pathlib.Path('/workspace/scratch/configparser-959-fake-controls-v2');B=pathlib.Path('/workspace/scratch/imre-scorecard-test-drift/benchmarks/compatibility');sys.path.insert(0,str(B));import raw_control,scorecard
A=O/'as-used';A.mkdir(exist_ok=False)
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def copy(p,d):d=A/d;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d);return {'original_path':str(p),'archive_path':str(d.relative_to(O)),'sha256':sha(d),'bytes':d.stat().st_size}
identity=json.loads((R/'identity.json').read_text()); copies=[]
for p,d in [(R/'identity.json','original/identity.json'),(R/'canonical-inventory.json','original/canonical-inventory.json'),(R/'launch/launcher.py','original/launcher.py'),(R/'raw/stock.version.stdout','original/stock.version.stdout'),(R/'raw/stock.json','original/stock.json'),(R/'raw/stock.originals.json','original/stock.originals.json'),(R/'raw/O0.json','original/O0.json'),(R/'raw/O0.build.json','original/O0.build.json'),(R/'raw/O0.originals.json','original/O0.originals.json'),(R/'raw/O3.json','original/O3.json'),(R/'raw/O3.build.json','original/O3.build.json'),(R/'raw/O3.originals.json','original/O3.originals.json'),(R/'withdrawal-source/controller.py','reviewed/controller.py'),(R/'withdrawal-source/data-only.policy.json','reviewed/data-only.policy.json'),(R/'withdrawal-source/raw-control-probe-data','reviewed/raw-control-probe-data'),(R/'withdrawal-source/raw_control_probe_data.c','reviewed/raw_control_probe_data.c'),(R/'withdrawal-source/probe.patch','reviewed/probe.patch'),(F/'build-and-controls.json','reviewed/build-and-controls.json'),(R/'gates/raw-control-probe','gate/raw-control-probe'),(R/'gates/raw_control_probe.c','gate/raw_control_probe.c'),(R/'gates/O0.direct.launcher.py','gate/O0.direct.launcher.py'),(R/'gates/O0.imported.launcher.py','gate/O0.imported.launcher.py'),(R/'gates/poison.source.py','gate/poison.source.py')]:copies.append(copy(p,pathlib.Path(d)))
for p in sorted((R/'custody').iterdir()):
 if p.is_file():copies.append(copy(p,pathlib.Path('donor')/p.name))
for rel in identity['resources']:
 p=R/'preimages'/rel;copies.append(copy(p,pathlib.Path('preimages')/rel))
proof=[]
with tarfile.open(identity['source_archive'],'r:gz') as tar:
 for rel,v in identity['resources'].items():
  member=tar.getmember(v['member']);file=tar.extractfile(member);data=file.read();digest=hashlib.sha256(data).hexdigest();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();pre=R/'preimages'/rel;proof.append({'path':rel,'archive_member':v['member'],'bytes':len(data),'sha256':digest,'git_blob':blob,'matches_source_authority':digest==v['sha256'] and blob==v['git_blob'],'matches_captured_preimage':sha(pre)==digest})
dump(A/'archive-proof.json',{'source_commit':identity['source']['commit'],'archive_path':identity['source_archive'],'archive_sha256':identity['source_archive_sha256'],'members':proof})
resources=[]; skel=O/'withdrawal/O0/workspace'
for p in sorted(skel.rglob('*')):
 st=p.lstat();resources.append({'path':str(p.relative_to(skel)),'kind':'directory' if stat.S_ISDIR(st.st_mode) else 'regular' if stat.S_ISREG(st.st_mode) else 'other','mode':oct(stat.S_IMODE(st.st_mode)),'bytes':st.st_size if stat.S_ISREG(st.st_mode) else None,'sha256':sha(p) if stat.S_ISREG(st.st_mode) else None})
dump(A/'withdrawal-skeleton.json',resources)
inst={}
for p in [pathlib.Path('/usr/bin/strace'),pathlib.Path('/usr/bin/timeout'),pathlib.Path('/usr/bin/bwrap'),pathlib.Path((F/'cc.path').read_text().strip()),B/'raw_control.py',B/'scorecard.py',B/'collect_unittest_results.py']:
 inst[str(p)]={'canonical_path':str(p.resolve()),'sha256':sha(p),'bytes':p.stat().st_size}
dump(A/'instrumentation.json',inst)
g=json.loads((O/'gates/O0.json').read_text());positive=json.loads((O/'O0/capture.json').read_text());comp=[]
for c in g['controls']:
 lines=(O/'gates'/('O0.'+c['mode']+'.trace')).read_text().splitlines();seq=raw_control.execs(lines,scorecard.require);cmd=seq[1][3];ok=scorecard.comparable_build(cmd)==scorecard.comparable_build(positive['target_argv']);release=positive['held_fd_before'];scorecard.matched_build(cmd,'O0',release['cli']['path'],release['runtime']['path']);comp.append({'mode':c['mode'],'comparable_build':ok,'matched_build':True,'compiler_child_pid':seq[1][1],'compiler_environment_matches_positive':raw_control.exec_environment(lines[seq[1][0]],scorecard.require)==positive['environment'],'compiler_exit':c['compiler_exit'],'no_image':not c['image_exists'],'stderr_sha256':c['stderr_sha256']})
dump(A/'gate-comparability.json',comp)
dump(A/'copies.json',copies)
# Explicit evidence selection, avoiding the large fresh images and the mount skeleton itself.
roots=[O/'before.json',O/'after.json',O/'fixture.before.json',O/'fixture.after.json',O/'report.json',O/'capture.O0.py',O/'capture.py',O/'audit.py',O/'seal.py',O/'as-used',O/'stock',O/'O0',O/'O3',O/'gates',O/'controllers',O/'supplemental',O/'withdrawal/O0']
files=[]
for root in roots:
 if root.is_file():files.append(root)
 else:
  for p in root.rglob('*'):
   if p.is_file() and not p.is_relative_to(skel):files.append(p)
files=sorted(set(files));assert all(p.stat().st_size<2*1024*1024 for p in files); entries=[{'path':p.relative_to(O).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files];manifest=O/'seal-members.json';dump(manifest,{'members':entries,'excluded_large_images':['O0.exe','O3.exe'],'credit':0});archive=O/'private-identity-recapture.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
 for p in files+[manifest]:tf.add(p,arcname=p.relative_to(O).as_posix(),recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 names=tf.getnames();assert names==[e['path'] for e in entries]+['seal-members.json']
seal={'archive_path':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'member_count':len(names),'member_list_path':str(manifest),'member_list_sha256':sha(manifest),'report_sha256':sha(O/'report.json'),'excluded_image_sha256':{t:json.loads((O/t/'capture.json').read_text())['image_sha256'] for t in ['O0','O3']},'credit':0}
dump(O/'seal.json',seal);print(json.dumps(seal));print('source archive proof',all(x['matches_source_authority'] and x['matches_captured_preimage'] for x in proof),'gate comparability',all(x['comparable_build'] and x['matched_build'] and x['compiler_environment_matches_positive'] for x in comp))
