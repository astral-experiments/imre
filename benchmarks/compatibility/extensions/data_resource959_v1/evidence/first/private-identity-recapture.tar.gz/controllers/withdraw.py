"""SOURCE DRAFT. Do not execute before independent source review of the JSON extension."""
from __future__ import annotations
import hashlib, importlib.util, json, os, pathlib, shutil, signal, stat, subprocess, sys, time
R=pathlib.Path('/workspace/scratch/configparser-959-explore-v1'); I=pathlib.Path(__file__).resolve().parent.parent; SOURCE=R/'withdrawal-source'
sys.path.insert(0,str(R))
from controller import effects, sha, dump
spec=importlib.util.spec_from_file_location('configparser_gate_capture',R/'gates/controller.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
POLICY=SOURCE/'data-only.policy.json'; PROBE=SOURCE/'raw-control-probe-data'; BWRAP=pathlib.Path('/usr/bin/bwrap')
TREE=R/'fixtures/Lib/test'; STASH=pathlib.Path(str(TREE)+'.data-withdraw-stash'); LEAF=TREE/'test_configparser.py'; LAUNCH=R/'launch/launcher.py'; CWD=R/'empty'; TMP=R/'tmp'
CALLS='execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,statx,rename,renameat,renameat2,wait4,waitid,exit,exit_group,chdir,fchdir,close,close_range,dup,dup2,dup3,fcntl,clone,clone3,fork,vfork,write,writev,unlink,unlinkat,link,linkat,symlink,symlinkat,unshare,mount,umount2,pivot_root,mount_setattr,open_tree,move_mount,setpgid,kill,prctl'
def read(p):return json.loads(p.read_text())
def under(root,path):return root/path.relative_to('/workspace')
def nofollow(path):
 try:return pathlib.Path(path).lstat()
 except FileNotFoundError:return None
def restoration(tree,stash,leaf,expected_leaf_sha):
 ts,ss,ls=nofollow(tree),nofollow(stash),nofollow(leaf)
 restored=bool(ts and stat.S_ISDIR(ts.st_mode) and ss is None and ls and stat.S_ISREG(ls.st_mode) and sha(leaf)==expected_leaf_sha)
 return {'tree_is_real_directory':bool(ts and stat.S_ISDIR(ts.st_mode)),'stash_absent':ss is None,'leaf_is_real_regular_file':bool(ls and stat.S_ISREG(ls.st_mode)),'leaf_sha256':sha(leaf) if ls and stat.S_ISREG(ls.st_mode) else None,'restored':restored}
def communicate_bounded(argv,cwd,env,timeout,tree,stash,leaf,expected_leaf_sha):
 proc=subprocess.Popen(argv,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 timed=False;escalated=False;wait_error=None
 try:stdout,stderr=proc.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  timed=True
  try:os.killpg(proc.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:stdout,stderr=proc.communicate(timeout=5)
  except subprocess.TimeoutExpired:
   escalated=True
   try:os.killpg(proc.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   try:stdout,stderr=proc.communicate(timeout=5)
   except subprocess.TimeoutExpired as exc:
    wait_error='process group did not finish after SIGKILL';stdout=exc.output or b'';stderr=exc.stderr or b''
    if proc.stdout:proc.stdout.close()
    if proc.stderr:proc.stderr.close()
 state=restoration(tree,stash,leaf,expected_leaf_sha)
 return {'exit_code':proc.returncode,'timed_out':timed,'sigkill_escalated':escalated,'wait_error':wait_error,'restoration':state,'process_group':proc.pid},stdout,stderr
def capture(tier):
 if tier not in {'O0','O3'}:raise ValueError('tier must be O0 or O3')
 policy=read(POLICY);family=policy['families']['configparser'];identity=read(R/'identity.json');capture=read(R/'raw'/f'{tier}.json');build=read(I/tier/'capture.json');image=I/f'{tier}.exe'
 if not PROBE.is_file():raise RuntimeError('reviewed data-withdraw probe has not been built')
 tree_st,leaf_st,stash_st=nofollow(TREE),nofollow(LEAF),nofollow(STASH)
 if not tree_st or not stat.S_ISDIR(tree_st.st_mode) or not leaf_st or not stat.S_ISREG(leaf_st.st_mode) or stash_st is not None:raise RuntimeError('tree/leaf/stash is symlinked, missing, or unsafe')
 if sha(image)!=build['image_sha256'] or sha(LEAF)!=identity['source']['sha256'] or sha(LAUNCH)!=identity['launcher_sha256'] or sha(identity['source_archive'])!=identity['source_archive_sha256']:raise RuntimeError('source/image preimage differs')
 if STASH.exists():raise RuntimeError('withdrawal stash already exists')
 stage=I/'withdrawal'/tier;stage.mkdir(parents=True,exist_ok=False);skeleton=stage/'workspace';skeleton.mkdir()
 # A read-only replacement for /workspace contains only these empty directories,
 # three exact data preimages, and zero-byte targets for the image/probe mounts.
 for p in [CWD,TMP,LAUNCH.parent,TREE,TREE/'support',TREE/'configdata',image.parent,PROBE.parent]:under(skeleton,p).mkdir(parents=True,exist_ok=True)
 for p in [image,PROBE]:under(skeleton,p).touch()
 for item in family['readonly_data_files']:
  target=pathlib.Path(item['runtime']);source=item['source']
  resource_st=nofollow(target)
  if target.parent!=TREE/'configdata' or not resource_st or not stat.S_ISREG(resource_st.st_mode) or sha(target)!=source['sha256'] or resource_st.st_size!=source['bytes']:raise RuntimeError('resource preimage differs')
  dest=under(skeleton,target);shutil.copyfile(target,dest);dest.chmod(0o444)
  if sha(dest)!=source['sha256']:raise RuntimeError('resource copy differs')
 if sorted(x.name for x in under(skeleton,TREE/'configdata').iterdir())!=sorted(pathlib.Path(x['runtime']).name for x in family['readonly_data_files']):raise RuntimeError('unexpected data resource')
 archive=pathlib.Path(identity['source_archive']);source_copy=R/'preimages/Lib/test/test_configparser.py'
 blocked=[LEAF,TREE/'__pycache__',LAUNCH,archive,source_copy,STASH,R/'gates/positive.launcher.py']
 bargs=[str(BWRAP),'--ro-bind','/','/','--ro-bind',str(skeleton),'/workspace','--ro-bind',str(image),str(image),'--ro-bind',str(PROBE),str(PROBE),'--bind',str(CWD),str(CWD),'--bind',str(TMP),str(TMP),'--chdir',str(CWD),'--die-with-parent','--',str(PROBE),'absent-exec',*map(str,blocked),'--',str(image)]
 trace=stage/'run.trace';argv=['/usr/bin/strace','-f','-yy','-v','-qq','-s','512','-e','trace='+CALLS,'-o',str(trace),str(PROBE),'withdraw-wrap','240',str(TREE),str(STASH),str(LEAF),*bargs]
 before={'launcher':sha(LAUNCH),'leaf':sha(LEAF),'archive':sha(archive),'image':sha(image),'fixture_manifest':gate.manifest(),'effects':effects()};dump(stage/'before.json',before)
 start=time.monotonic()
 # The supervisor owns the 240-second child-group deadline and restores the host
 # tree after waitpid. The extra 15 seconds permit trace flush and restoration.
 cleanup,stdout,stderr=communicate_bounded(argv,capture['cwd'],capture['environment'],255,TREE,STASH,LEAF,identity['source']['sha256'])
 dump(stage/'cleanup.json',cleanup)
 if cleanup['wait_error'] or not cleanup['restoration']['restored']:
  (stage/'stdout').write_bytes(stdout);(stage/'stderr').write_bytes(stderr)
  raise RuntimeError('bounded supervisor cleanup failed; preserve stash/trace and inspect cleanup.json')
 (stage/'stdout').write_bytes(stdout);(stage/'stderr').write_bytes(stderr)
 after={'launcher':sha(LAUNCH),'leaf':sha(LEAF) if LEAF.is_file() else None,'archive':sha(archive),'image':sha(image),'fixture_manifest':gate.manifest() if TREE.is_dir() else None,'effects':effects()};dump(stage/'after.json',after)
 report={'source_controller_sha256':sha(__file__),'policy_sha256':sha(POLICY),'probe_sha256':sha(PROBE),'bwrap_sha256':sha(BWRAP),'argv':argv,'cwd':capture['cwd'],'environment':capture['environment'],'seconds':round(time.monotonic()-start,3),'exit_code':cleanup['exit_code'],'trace_sha256':sha(trace),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'source_withdrawal_claim':None,'credit':0}
 dump(stage/'capture.json',report)
if __name__=='__main__':capture(sys.argv[1])
