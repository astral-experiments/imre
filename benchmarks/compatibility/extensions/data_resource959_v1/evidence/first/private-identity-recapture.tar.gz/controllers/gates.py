"""Exact fresh workload graph negative controls; held product descriptors span both gates."""
import hashlib,json,os,pathlib,subprocess,sys,time
O=pathlib.Path(__file__).resolve().parent.parent;R=pathlib.Path('/workspace/scratch/configparser-959-explore-v1');P=pathlib.Path('/workspace/scratch/imre-95908-transferred-config-v1/product');sys.path.insert(0,str(O));from capture import fdrecord,sha,dump
sys.path.insert(0,'/workspace/scratch/imre-scorecard-test-drift/benchmarks/compatibility');import scorecard,raw_control
def main(tier):
 m=json.loads((O/tier/'capture.json').read_text());assert not m['image_matches_original'];L=R/'launch/launcher.py';poison=L.parent/'configparser_gate_poison.py';positive=L.read_bytes();assert hashlib.sha256(positive).hexdigest()==json.loads((R/'identity.json').read_text())['launcher_sha256'] and not poison.exists();paths={'cli':P/'imre','runtime':P/'libimre_runtime.a','clang':P/'imre-toolchain/bin/clang'};fds={k:os.open(p,os.O_RDONLY|os.O_CLOEXEC) for k,p in paths.items()};before={k:fdrecord(v,paths[k]) for k,v in fds.items()};results=[]
 try:
  for mode in ('direct','imported'):
   name=tier+'.'+mode;out=O/'gates'/(name+'.no-image');assert not out.exists();cmd=list(m['target_argv']);cmd[cmd.index('-o')+1]=str(out);assert scorecard.comparable_build(cmd)==scorecard.comparable_build(m['target_argv']);scorecard.matched_build(cmd,tier,paths['cli'].as_posix(),paths['runtime'].as_posix());negative=(R/'gates'/(tier+'.'+mode+'.launcher.py')).read_bytes();trace=O/'gates'/(name+'.trace');probe=R/'gates/raw-control-probe'
   try:
    L.write_bytes(negative)
    if mode=='imported':poison.write_bytes((R/'gates/poison.source.py').read_bytes())
    argv=['/usr/bin/strace','-f','-yy','-v','-qq','-s','512','-e','trace=execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,rename,wait4,exit_group','-o',str(trace),str(probe),'gate',str(out),*cmd];start=time.monotonic();p=subprocess.run(argv,cwd=m['cwd'],env=m['environment'],capture_output=True,timeout=120);(O/'gates'/(name+'.stdout')).write_bytes(p.stdout);(O/'gates'/(name+'.stderr')).write_bytes(p.stderr);text=trace.read_text();sq=raw_control.execs(text.splitlines(),scorecard.require);assert raw_control.exec_environment(text.splitlines()[sq[1][0]],scorecard.require)==m['environment']
    if mode=='direct':raw_control.trace_direct_gate(text,cmd,str(probe),p.stderr.decode(),scorecard.require,expected_exit=1)
    else:raw_control.trace_gate(text,cmd,str(probe),str(poison),p.stderr.decode(),scorecard.require,expected_exit=1)
    assert p.returncode==0 and not out.exists();results.append({'mode':mode,'supervisor_exit':p.returncode,'compiler_exit':1,'image_exists':False,'seconds':round(time.monotonic()-start,3),'trace_sha256':sha(trace),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'positive_sha256':hashlib.sha256(positive).hexdigest(),'negative_sha256':hashlib.sha256(negative).hexdigest(),'poison_sha256':sha(poison) if mode=='imported' else None,'argv':argv,'compiler_environment':m['environment']})
   finally:
    L.write_bytes(positive)
    if poison.exists():poison.unlink()
  after={k:fdrecord(v,paths[k]) for k,v in fds.items()};assert before==after and L.read_bytes()==positive and not poison.exists();dump(O/'gates'/(tier+'.json'),{'tier':tier,'controller_sha256':sha(__file__),'fd_before':before,'fd_after':after,'stable':before==after,'controls':results,'image_sha256':sha(O/(tier+'.exe')),'credit':0});print(tier,'two gates passed, bracket stable',flush=True)
 finally:
  for fd in fds.values():os.close(fd)
if __name__=='__main__':main(sys.argv[1])
