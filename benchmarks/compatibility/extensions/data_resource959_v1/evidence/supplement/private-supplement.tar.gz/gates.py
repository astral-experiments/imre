"""Exactly two fresh O3 no-image gates, with continuous hashed product FD custody."""
from __future__ import annotations
import datetime,hashlib,importlib.util,json,os,pathlib,re,signal,stat,subprocess,sys,threading,time
S=pathlib.Path(__file__).resolve().parent;O=pathlib.Path('/workspace/scratch/configparser-959-identity-recapture-v1');R=pathlib.Path('/workspace/scratch/configparser-959-explore-v1');P=pathlib.Path('/workspace/scratch/imre-95908-transferred-config-v1/product');sys.path.insert(0,str(O));from capture import fdrecord,sha,dump
sys.path.insert(0,'/workspace/scratch/imre-scorecard-test-drift/benchmarks/compatibility');import raw_control,scorecard
spec=importlib.util.spec_from_file_location('gate_original',R/'gates/controller.py');original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
FIRST=O/'private-identity-recapture.tar.gz';EXPECTED={'cli':'e2d0886948f766332df6370a2e3140a5be5c8b0fc108224ef7242fc38fc58bd4','runtime':'33ae5dfef5eff3c1fac5e0a5e19263daa980d7d80a5917979b426e85fa128c5c','clang':'8ef402d453d1ba4902e4ee0f0f847f6cfa01400c95aa43c24e97818b9c0e3f45'}
def snap():
 fixture=original.manifest();return {'first_archive_sha256':sha(FIRST),'first_archive_bytes':FIRST.stat().st_size,'launcher':sha(R/'launch/launcher.py'),'old_images':{t:sha(R/(t+'.exe')) for t in ('O0','O3')},'fresh_images':{t:sha(O/(t+'.exe')) for t in ('O0','O3')},'fixture':fixture,'donor_transfer_archive_sha256':sha('/workspace/scratch/imre-95908-transferred-config-v1/product.tar.zst')}
def monitor(trace,cli,stop,out):
 while not stop.is_set():
  try:
   for l in trace.read_text().splitlines():
    m=raw_control.EXEC.fullmatch(l)
    if not m or json.loads(m[2])!=cli['path']:continue
    pid=int(m[1]);fd=os.open(f'/proc/{pid}/exe',os.O_RDONLY|os.O_CLOEXEC)
    try:
     st=os.fstat(fd);sample={'pid':pid,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'proc_exe':f'/proc/{pid}/exe','resolved_target':os.readlink(f'/proc/{pid}/exe'),'dev':st.st_dev,'ino':st.st_ino,'bytes':st.st_size,'ctime_ns':st.st_ctime_ns,'mtime_ns':st.st_mtime_ns,'mode':oct(stat.S_IMODE(st.st_mode))};sample['matches_held_cli_fd']=all(sample[k]==cli[k] for k in ('dev','ino','bytes','ctime_ns','mtime_ns','mode'));out.append(sample);return
    finally:os.close(fd)
  except (OSError,ValueError):pass
  stop.wait(.002)
def main():
 b=snap();assert b['first_archive_sha256']=='0aaf6be3143875bfcf63262c8c0ecdee05911f21919d8100c63fbcefcf0fdfbd' and b['first_archive_bytes']==544471;assert b['fixture']==json.loads((O/'fixture.after.json').read_text());dump(S/'before.json',b)
 positive=json.loads((O/'O3/capture.json').read_text());assert positive['image_sha256']==b['fresh_images']['O3']==b['old_images']['O3'];L=R/'launch/launcher.py';poison=L.parent/'configparser_gate_poison.py';src=L.read_bytes()
 assert hashlib.sha256(src).hexdigest()==b['launcher'] and not poison.exists();paths={'cli':P/'imre','runtime':P/'libimre_runtime.a','clang':P/'imre-toolchain/bin/clang'};fds={k:os.open(p,os.O_RDONLY|os.O_CLOEXEC) for k,p in paths.items()};records=[]
 try:
  pre={k:fdrecord(fd,paths[k]) for k,fd in fds.items()};assert all(v['sha256']==EXPECTED[k] and (v['flags']&os.O_ACCMODE)==os.O_RDONLY for k,v in pre.items());dump(S/'fd.before.json',pre)
  for mode in ('direct','imported'):
   image=S/('O3.'+mode+'.no-image');assert not image.exists();negative=(R/'gates'/('O3.'+mode+'.launcher.py')).read_bytes();delta=b'status: int = True\n' if mode=='direct' else b'import configparser_gate_poison\n';assert negative.count(delta)==1 and negative.replace(delta,b'',1)==src
   output=S/('O3.'+mode);cmd=list(positive['target_argv']);cmd[cmd.index('-o')+1]=str(image);assert scorecard.comparable_build(cmd)==scorecard.comparable_build(positive['target_argv']);scorecard.matched_build(cmd,'O3',str(paths['cli']),str(paths['runtime']));probe=R/'gates/raw-control-probe';trace=output.with_suffix(output.suffix+'.trace');argv=['/usr/bin/strace','-f','-yy','-v','-qq','-s','512','-e','trace=execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,rename,wait4,exit_group','-o',str(trace),str(probe),'gate',str(image),*cmd];stop=threading.Event();samples=[];start=time.monotonic();timed=False;proc=None
   try:
    L.write_bytes(negative)
    if mode=='imported':poison.write_bytes(b'status: int = True\n');assert poison.stat().st_size==19
    proc=subprocess.Popen(argv,cwd=positive['cwd'],env=positive['environment'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);thread=threading.Thread(target=monitor,args=(trace,pre['cli'],stop,samples),daemon=True);thread.start()
    try:stdout,stderr=proc.communicate(timeout=120)
    except subprocess.TimeoutExpired:
     timed=True;os.killpg(proc.pid,signal.SIGTERM)
     try:stdout,stderr=proc.communicate(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);stdout,stderr=proc.communicate(timeout=5)
    finally:stop.set();thread.join(timeout=2)
    output.with_suffix(output.suffix+'.stdout').write_bytes(stdout);output.with_suffix(output.suffix+'.stderr').write_bytes(stderr);lines=trace.read_text().splitlines();sq=raw_control.execs(lines,scorecard.require);assert sq[1][2]==str(paths['cli']) and sq[1][3]==cmd and raw_control.exec_environment(lines[sq[1][0]],scorecard.require)==positive['environment']
    if mode=='direct':raw_control.trace_direct_gate('\n'.join(lines),cmd,str(probe),stderr.decode(),scorecard.require,expected_exit=1)
    else:raw_control.trace_gate('\n'.join(lines),cmd,str(probe),str(poison),stderr.decode(),scorecard.require,expected_exit=1)
    assert proc.returncode==0 and not timed and not image.exists() and stdout==b'' and b'expected int, got bool' in stderr;assert all(x['pid']==int(sq[1][1]) and x['matches_held_cli_fd'] for x in samples)
    records.append({'tier':'O3','mode':mode,'seconds':round(time.monotonic()-start,3),'source_controller_sha256':sha(__file__),'positive_metadata_sha256':sha(O/'O3/capture.json'),'positive_launcher_sha256':hashlib.sha256(src).hexdigest(),'negative_launcher_sha256':hashlib.sha256(negative).hexdigest(),'delta':delta.decode(),'poison_path':str(poison) if mode=='imported' else None,'poison_bytes':19 if mode=='imported' else None,'poison_sha256':sha(poison) if mode=='imported' else None,'cwd':positive['cwd'],'environment':positive['environment'],'argv':argv,'compiler_argv':cmd,'compiler_pid':int(sq[1][1]),'compiler_exit':1,'supervisor_exit':proc.returncode,'timed_out':timed,'image_absent_before':True,'image_absent_after':not image.exists(),'diagnostic':stderr.decode().strip(),'comparable_build':True,'matched_build':True,'probe_sha256':sha(probe),'trace_sha256':sha(trace),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'live_cli_samples':samples})
   finally:
    L.write_bytes(src)
    if poison.exists():poison.unlink()
    assert L.read_bytes()==src and not poison.exists()
  post={k:fdrecord(fd,paths[k]) for k,fd in fds.items()};dump(S/'fd.after.json',post);assert pre==post;dump(S/'O3.gates.json',{'credit':0,'first_archive_sha256':b['first_archive_sha256'],'controller_sha256':sha(__file__),'fd_records_identical':pre==post,'controls':records})
 finally:
  for fd in fds.values():os.close(fd)
 a=snap();dump(S/'after.json',a);assert b==a and not poison.exists();print(json.dumps({'gates':[(x['mode'],x['compiler_exit'],x['seconds'],len(x['live_cli_samples'])) for x in records],'fd_stable':pre==post,'fixture_files':sum(x['kind']=='file' for x in a['fixture']),'preserved':b==a}))
if __name__=='__main__':main()
