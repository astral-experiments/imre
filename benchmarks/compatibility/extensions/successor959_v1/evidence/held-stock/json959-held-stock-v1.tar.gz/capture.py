import hashlib,json,os,pathlib,re,signal,stat,subprocess,time
R=pathlib.Path('/workspace/scratch/json-decode-959-replay-v1');D=pathlib.Path(__file__).resolve().parent;M=json.loads((R/'raw/stock.json').read_text());A={'NO_COLOR','PATH','PYTHONDONTWRITEBYTECODE','PYTHONPATH','PYTHON_COLORS','TMPDIR'};assert set(M['environment'])==A and M['argv'][1:]==['-B',str(R/'launch/launcher.py')]
def h(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def st(s):return {'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'ctime_ns':s.st_ctime_ns,'mtime_ns':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
def hashfd(fd):
 os.lseek(fd,0,os.SEEK_SET);a=st(os.fstat(fd));v=hashlib.sha256()
 while b:=os.read(fd,1024*1024):v.update(b)
 z=st(os.fstat(fd));assert a==z;return {'sha256':v.hexdigest(),'fstat':a}
def effects():return {str(p):sorted(str(x.relative_to(p)) for x in p.rglob('*')) for p in map(pathlib.Path,[M['cwd'],M['environment']['TMPDIR']])}
py=M['argv'][0];fd=os.open(py,os.O_RDONLY|os.O_CLOEXEC);pre=hashfd(fd);assert pre['sha256']=='c27397da5541f67655be462e128ca3d3eb6e0a8eb0d39036896c9042529f4304' and st(os.stat(py))==pre['fstat'];before=effects();tr=D/'stock.trace';syscall='execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,rename,wait4,waitid,exit,exit_group,chdir,fchdir,close,close_range,dup,dup2,dup3,fcntl,clone,clone3,fork,vfork';argv=['/usr/bin/strace','-f','-yy','-v','-qq','-s','65535','-e','trace='+syscall,'-o',str(tr),'--',*M['argv']];start=time.time_ns();p=subprocess.Popen(argv,cwd=M['cwd'],env=M['environment'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);sample=None;sample_error=None
while p.poll() is None and (time.time_ns()-start)<90_000_000_000:
 if sample is None and tr.exists():
  line=tr.open().readline();m=re.match(r'^(\d+)\s+execve\(',line)
  if m:
   try:
    with open('/proc/'+m[1]+'/exe','rb') as f:sample={'pid':m[1],'target':os.readlink('/proc/'+m[1]+'/exe'),'fstat':st(os.fstat(f.fileno()))}
   except OSError as e:sample_error=type(e).__name__
 if sample is not None:break
 time.sleep(.005)
try:out,err=p.communicate(timeout=90)
except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate();raise
finish=time.time_ns();post=hashfd(fd);path_post=st(os.stat(py));os.close(fd);after=effects();assert p.returncode==0 and pre==post and path_post==post['fstat'] and before==after and out==(R/'raw/stock.stdout').read_bytes() and err==(R/'raw/stock.stderr').read_bytes();(D/'stock.stdout').write_bytes(out);(D/'stock.stderr').write_bytes(err);dump(D/'effects.before.json',before);dump(D/'effects.after.json',after);assert sample is None or sample['fstat']==pre['fstat'];trace=tr.read_bytes();meta={'schema':'imre.json959.held-stock.v1','controller_sha256':h(pathlib.Path(__file__).read_bytes()),'start_utc_ns':start,'finish_utc_ns':finish,'argv':M['argv'],'capture_argv':argv,'cwd':M['cwd'],'environment':M['environment'],'exit_code':p.returncode,'held_fd_pre':pre,'held_fd_post':post,'path_post_fstat':path_post,'proc_exe_sample':sample,'proc_exe_sample_error':sample_error if sample is None else None,'stdout_sha256':h(out),'stderr_sha256':h(err),'trace_sha256':h(trace),'effects_before_sha256':h((D/'effects.before.json').read_bytes()),'effects_after_sha256':h((D/'effects.after.json').read_bytes()),'original_stock_metadata_sha256':h((R/'raw/stock.json').read_bytes()),'ordered_streams_and_effects_equal':True,'limits':'The process-exe sample narrows the path-exec race when present; it is not atomic fd-exec.'};dump(D/'stock.json',meta);files={x.name:{'sha256':h(x.read_bytes()),'bytes':x.stat().st_size} for x in sorted(D.iterdir()) if x.is_file()};dump(D/'COMPLETE.json',{'schema':'imre.json959.held-stock-seal.v1','credit':0,'files':files});print(json.dumps({'dir':str(D),'complete_sha256':h((D/'COMPLETE.json').read_bytes()),'proc_sample':sample is not None,'stock_exit':p.returncode,'ordered_streams_equal':True,'credit':0}))
