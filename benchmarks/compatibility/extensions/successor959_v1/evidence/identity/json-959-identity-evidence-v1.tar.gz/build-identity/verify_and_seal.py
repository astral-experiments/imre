"""Offline verification and deterministic private packaging for JSON959 identity recapture."""
import collections,gzip,hashlib,io,json,pathlib,re,sys,tarfile,time
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/scratch/json-decode-959-replay-v1');S=pathlib.Path('/workspace/scratch/json-959-stock-identity-v1');SELECTED=pathlib.Path('/workspace/scratch/json-decode-959-selected-v1.tar.gz');ARCHIVE=pathlib.Path('/workspace/scratch/json-959-identity-evidence-v1.tar.gz');ALLOW={'NO_COLOR','PATH','PYTHONDONTWRITEBYTECODE','PYTHONPATH','PYTHON_COLORS','TMPDIR'};sys.path.insert(0,'/workspace/scratch/imre-959-activation/benchmarks/compatibility');import raw_control,scorecard
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert not ARCHIVE.exists() and sha(SELECTED)=='fae5b50a20c65bb58f960fc230491469b8e7266e6ff53f25e39305b4b72fe91b';original_members=0
with tarfile.open(SELECTED,'r:gz') as f:
 for m in f:
  if m.isfile():
   original_members+=1;assert hashlib.sha256(f.extractfile(m).read()).hexdigest()==sha(R/m.name),m.name
seal=json.loads((S/'COMPLETE.json').read_text());assert all(sha(S/name)==x['sha256'] and (S/name).stat().st_size==x['bytes'] for name,x in seal['files'].items());stock=json.loads((S/'stock.json').read_text());lines=(S/'stock.trace').read_text().splitlines();s=raw_control.exec_sequence(lines,scorecard.require,1)[0];assert s[2]==stock['argv'][0] and s[3]==stock['argv'] and raw_control.exec_environment(lines[s[0]],scorecard.require)==stock['environment'] and stock['stock_before']==stock['stock_after'] and stock['version']=='Python 3.14.5';builds={};images={}
for t in ('O0','O3'):
 b=json.loads((D/'raw'/f'{t}.json').read_text());assert b['fd_before']==b['fd_after'] and b['compiler_exit_code']==0 and b['actual_compiler_path']==b['build_argv'][0] and b['actual_compiler_argv']==b['build_argv'] and b['environment']==b['actual_compiler_environment'] and set(b['environment'])==ALLOW and sha(D/'images'/f'{t}.exe')==b['new_image_sha256'] and sha(R/'images'/f'{t}.exe')==b['old_image_sha256'];execs=collections.Counter();partial=0
 for line in (D/'raw'/f'{t}.trace').read_text().splitlines():
  m=raw_control.EXEC.fullmatch(line)
  if m:execs[json.loads(m[2])]+=1;assert raw_control.exec_environment(line,scorecard.require)==b['environment']
  elif re.search(r'\bexecve(?:at)?\(',line):partial+=1
 assert execs[b['actual_compiler_path']]==1 and execs[b['fd_before']['clang']['path']]>0
 builds[t]={'build_seconds':b['build_seconds'],'total_seconds':b['total_seconds'],'image_identical_to_old':b['elf_identical'],'new_image_sha256':b['new_image_sha256'],'old_image_sha256':b['old_image_sha256'],'complete_successful_exec_paths':dict(execs),'other_exec_trace_lines':partial,'all_complete_exec_envs_match_six_vars':True,'fd_identity_unchanged':True};images[t]={'path':str(D/'images'/f'{t}.exe'),'bytes':(D/'images'/f'{t}.exe').stat().st_size,'sha256':b['new_image_sha256'],'old_path':str(R/'images'/f'{t}.exe'),'old_sha256':b['old_image_sha256']}
assert not builds['O0']['image_identical_to_old'] and builds['O3']['image_identical_to_old'] and not (D/'raw/O3.native.json').exists();n=json.loads((D/'raw/O0.native.json').read_text());assert n['strict_source_content_pass'] and n['same_ordered_stock_streams_and_effects'] and n['image_sha256']==images['O0']['sha256'];g=json.loads((D/'raw/gates/bracket.json').read_text());assert g['fd_before']==g['fd_after'] and len(g['controls'])==4 and sha(R/'launch/launcher.py')=='55367f06f64b7441708387dba7625753f4312e0a70fdf5b37208e40dd35fee0b' and not (R/'launch/json_decode_gate_poison.py').exists()
for x in g['controls']:
 p=D/'raw/gates'/f"{x['tier']}.{x['kind']}.json";m=json.loads(p.read_text());assert sha(p)==x['record_sha256'] and m['compiler_child_exit_code']==1 and m['image_absent_before'] and m['image_absent_after'] and m['fd_fstat_before']==m['fd_fstat_after'] and m['environment']==m['actual_compiler_environment'];scorecard.require(scorecard.comparable_build(m['build_argv'])==scorecard.comparable_build(json.loads((D/'raw'/f"{x['tier']}.json").read_text())['build_argv']),'gate graph differs')
audit={'schema':'imre.json959.identity-offline-audit.v1','credit':0,'original_selected_archive_sha256':sha(SELECTED),'original_member_bytes_unchanged':original_members,'stock_identity_seal_sha256':sha(S/'COMPLETE.json'),'stock_raw_exec_env_argv_exact':True,'stock_fd_identity_unchanged':True,'builds':builds,'O0_new_image_native_seconds':n['seconds'],'O0_new_image_strict_trace_pass':True,'O3_original_image_content_join':True,'gate_batch_fd_identity_unchanged':True,'gate_controls':4,'launcher_restored_sha256':sha(R/'launch/launcher.py'),'gate_supplement_sha256':sha(R/'gate-correction-v2/COMPLETE.json'),'limits':['FD brackets surround path-based exec; no atomic FD-exec or universal TOCTOU proof','Partial/resumed exec trace records remain raw; complete exec records were independently checked','O0 ELF differs; its new image was run and separately verified','O3 ELF matches; original proven native controls are joined by content','Historical identities measured retrospectively are labeled as such','Effects are limited to original empty and tmp roots; syscall capture does not establish universal confinement']};dump(D/'audit.json',audit)
assets={}
for p in sorted(S.iterdir()):
 if p.is_file():assets['stock-identity/'+p.name]=p
for p in sorted(D.rglob('*')):
 if p.is_file() and not p.is_relative_to(D/'images') and p.name not in {'MANIFEST.json','COMPLETE.json'}:assets['build-identity/'+p.relative_to(D).as_posix()]=p
assets['inputs/selected-v1.tar.gz']=SELECTED;manifest={'schema':'imre.json959.identity-archive-manifest.v1','credit':0,'files':{k:{'bytes':p.stat().st_size,'sha256':sha(p)} for k,p in sorted(assets.items())},'external_images':images,'external_product_archive_sha256':'c9cfcd02e0cc62dc7928119d68a4c4da5125f8030657c1c52b2cd3d49cb554b0','stock_identity_seal_sha256':sha(S/'COMPLETE.json'),'audit_sha256':sha(D/'audit.json')};dump(D/'MANIFEST.json',manifest);complete={'schema':'imre.json959.sealed-identity-archive.v1','credit':0,'manifest_sha256':sha(D/'MANIFEST.json'),'files':len(assets),'selected_archive_sha256':sha(SELECTED),'stock_seal_sha256':sha(S/'COMPLETE.json')};dump(D/'COMPLETE.json',complete);assets['build-identity/MANIFEST.json']=D/'MANIFEST.json';assets['build-identity/COMPLETE.json']=D/'COMPLETE.json'
with open(ARCHIVE,'xb') as out, gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0,compresslevel=6) as gz, tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
 for name,p in sorted(assets.items()):
  info=tarfile.TarInfo(name);info.size=p.stat().st_size;info.mode=0o600;info.mtime=0;info.uid=0;info.gid=0
  with open(p,'rb') as f:tar.addfile(info,f)
print('original members unchanged',original_members,'manifest',sha(D/'MANIFEST.json'),'seal',sha(D/'COMPLETE.json'),'archive',str(ARCHIVE),ARCHIVE.stat().st_size,sha(ARCHIVE),'assets',len(assets),flush=True)
