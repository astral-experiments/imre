"""Run only a non-identical newly captured JSON959 saved image under exact withdrawal controls."""
import hashlib,json,os,pathlib,signal,stat,subprocess,sys,time
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/scratch/json-decode-959-replay-v1');PROBE=pathlib.Path('/workspace/scratch/fnmatch-95908-replay-v1/correction-v2/raw-control-probe-child-env');SYS='execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,rename,wait4,waitid,exit,exit_group,chdir,fchdir,close,close_range,dup,dup2,dup3,fcntl,clone,clone3,fork,vfork';sys.path.insert(0,'/workspace/scratch/imre-959-activation/benchmarks/compatibility');import scorecard,raw_control
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
def effects(cwd,tmp):
 out=[]
 for root in map(pathlib.Path,(cwd,tmp)):
  for p in sorted(root.rglob('*')):
   st=p.lstat();x={'root':root.name,'path':str(p.relative_to(root)),'mode':stat.S_IMODE(st.st_mode),'kind':'file' if p.is_file() else 'directory' if p.is_dir() else 'other'}
   if p.is_file():x['sha256']=sha(p)
   out.append(x)
 return out
t=sys.argv[1];assert t in {'O0','O3'};b=json.loads((D/'raw'/f'{t}.json').read_text());assert not b['elf_identical'];old=json.loads((R/'raw'/f'{t}.json').read_text());image=D/'images'/f'{t}.exe';L=R/'launch/launcher.py';A=R/'launch/stock.source.py';tree=R/'fixtures/Lib/test';leaf=tree/'test_json/test_decode.py';stash=pathlib.Path(str(tree)+'.raw-control-stash');before={str(p):sha(p) for p in (image,L,A,leaf)};assert before[str(image)]==b['new_image_sha256'] and before[str(L)]==b['launcher_sha256'] and before[str(leaf)]==b['source_sha256'];assert not stash.exists();trace=D/'raw'/f'{t}.native.trace';child=old['environment'];parent={**child,'IMRE_WITHDRAW_LAUNCHER':str(L),'IMRE_WITHDRAW_ARCHIVE':str(A)};argv=['/usr/bin/strace','-f','-y','-v','-qq','-s','512','-e','trace='+SYS,'-o',str(trace),str(PROBE),'withdraw',str(tree),str(stash),str(leaf),str(image)];effects_before=effects(old['cwd'],child['TMPDIR']);start=time.monotonic();p=subprocess.Popen(argv,cwd=old['cwd'],env=parent,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,close_fds=True);timed=False
try:
 try:stdout,stderr=p.communicate(timeout=90)
 except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
finally:
 for path in (A,L,tree):
  s=pathlib.Path(str(path)+'.raw-control-stash')
  if s.exists() and not path.exists():s.rename(path)
seconds=round(time.monotonic()-start,3);(D/'raw'/f'{t}.native.stdout').write_bytes(stdout);(D/'raw'/f'{t}.native.stderr').write_bytes(stderr);effects_after=effects(old['cwd'],child['TMPDIR']);dump(D/'raw'/f'{t}.native.effects.before.json',effects_before);dump(D/'raw'/f'{t}.native.effects.after.json',effects_after);after={str(x):sha(x) for x in (image,L,A,leaf)};txt=trace.read_text();first,target=raw_control.execs(txt.splitlines(),scorecard.require);actual=raw_control.exec_environment(txt.splitlines()[target[0]],scorecard.require);policy=json.loads((R/'native-open-policy.json').read_text());raw_control.trace_withdraw(scorecard,txt,str(image),str(PROBE),str(tree),str(stash),str(leaf),old['cwd'],scorecard.require,extra_sources=(str(L),str(A)),strict_payloads=True,content_policy=(policy,'json',str(L),str(R/'fixtures/Lib')));assert actual==child and p.returncode==0 and not timed and before==after and stdout==(R/'raw/stock.stdout').read_bytes() and stderr==(R/'raw/stock.stderr').read_bytes() and effects_before==effects_after==json.loads((R/'raw/stock.effects.before.json').read_text());gates={}
for k in ('direct','imported'):
 g=json.loads((R/'gate-correction-v2/raw'/f'{t}.{k}.json').read_text());assert scorecard.comparable_build(g['build_argv'])==scorecard.comparable_build(b['build_argv']);gates[k]={'record_sha256':sha(R/'gate-correction-v2/raw'/f'{t}.{k}.json'),'comparable_build':True,'compiler_child_exit_code':g['compiler_child_exit_code'],'image_absent_after':g['image_absent_after']}
meta={'schema':'imre.json959.new-image-withdrawal.v1','tier':t,'controller_sha256':sha(__file__),'image_sha256':before[str(image)],'image_identity_before_after':before==after,'source_before':before,'source_after':after,'capture_argv':argv,'argv':[str(image)],'cwd':old['cwd'],'environment':child,'actual_child_environment':actual,'timeout_seconds':90,'seconds':seconds,'exit_code':p.returncode,'timed_out':timed,'stdout_sha256':sha(D/'raw'/f'{t}.native.stdout'),'stderr_sha256':sha(D/'raw'/f'{t}.native.stderr'),'trace_sha256':sha(trace),'trace_bytes':trace.stat().st_size,'effects_before_sha256':sha(D/'raw'/f'{t}.native.effects.before.json'),'effects_after_sha256':sha(D/'raw'/f'{t}.native.effects.after.json'),'same_ordered_stock_streams_and_effects':True,'strict_source_content_policy_sha256':sha(R/'native-open-policy.json'),'strict_source_content_pass':True,'probe_sha256':sha(PROBE),'probe_source_sha256':sha(R/'gate-correction-v2/probe-source.c'),'corrected_gate_supplement_sha256':sha(R/'gate-correction-v2/COMPLETE.json'),'corrected_gate_graph_join':gates,'limits':'Finite single-PID syscall census; inherited descriptors, mmap/IPC, TOCTOU, and namespace races remain outside the proof.'};dump(D/'raw'/f'{t}.native.json',meta);print(t,'native',seconds,'30/30 exact streams/effects; strict source/content PASS',flush=True)
