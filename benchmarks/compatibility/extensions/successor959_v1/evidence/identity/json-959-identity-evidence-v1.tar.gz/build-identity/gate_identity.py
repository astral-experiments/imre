"""A held-FD identity bracket around the four already-corrected same-graph JSON gates."""
import hashlib,json,os,pathlib,signal,stat,subprocess,sys,time
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/scratch/json-decode-959-replay-v1');G=R/'gate-correction-v2';L=R/'launch/launcher.py';POISON=L.parent/'json_decode_gate_poison.py';PROBE=pathlib.Path('/workspace/scratch/fnmatch-95908-replay-v1/correction-v2/raw-control-probe-child-env');SYS='execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,rename,wait4,waitid,exit,exit_group,chdir,fchdir,close,close_range,dup,dup2,dup3,fcntl,clone,clone3,fork,vfork';sys.path.insert(0,'/workspace/scratch/imre-959-activation/benchmarks/compatibility');import raw_control,scorecard
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
def statfd(fd):
 s=os.fstat(fd);return {'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'ctime_ns':s.st_ctime_ns,'mtime_ns':s.st_mtime_ns}
def measure(fd,path):
 os.lseek(fd,0,os.SEEK_SET);a=statfd(fd);h=hashlib.sha256()
 while b:=os.read(fd,1024*1024):h.update(b)
 assert statfd(fd)==a and os.stat(path).st_ino==a['ino'];return {'path':str(path),'fd_realpath':os.readlink(f'/proc/self/fd/{fd}'),'fstat':a,'sha256':h.hexdigest()}
def effects():
 out=[]
 for root in (R/'empty',R/'tmp'):
  for p in sorted(root.rglob('*')):
   st=p.lstat();x={'root':root.name,'path':str(p.relative_to(root)),'kind':'file' if p.is_file() else 'directory' if p.is_dir() else 'other','mode':stat.S_IMODE(st.st_mode)}
   if p.is_file():x['sha256']=sha(p)
   out.append(x)
 return out
records=[];B=json.loads((D/'raw/O0.json').read_text());paths={k:pathlib.Path(v['path']) for k,v in B['fd_before'].items()};fds={k:os.open(p,os.O_RDONLY|os.O_CLOEXEC) for k,p in paths.items()};original=L.read_bytes();assert hashlib.sha256(original).hexdigest()==B['launcher_sha256'] and not POISON.exists();outdir=D/'raw/gates';outdir.mkdir(exist_ok=False);before={k:measure(fds[k],p) for k,p in paths.items()};assert all(before[k]['sha256']==B['fd_before'][k]['sha256'] for k in before)
try:
 for tier in ('O0','O3'):
  build=json.loads((D/'raw'/f'{tier}.json').read_text())
  for kind in ('direct','imported'):
   assert L.read_bytes()==original and not POISON.exists();old=json.loads((G/'raw'/f'{tier}.{kind}.json').read_text());negative=(G/'negative'/f'{kind}.launcher.py').read_bytes();assert hashlib.sha256(negative).hexdigest()==old['negative_launcher_sha256'];L.write_bytes(negative)
   if kind=='imported':POISON.write_bytes((G/'negative/poison.py').read_bytes());assert sha(POISON)==old['poison_sha256']
   stem=f'{tier}.{kind}';output=D/'images'/f'{stem}.invalid.exe';assert not output.exists();cmd=list(build['build_argv']);cmd[cmd.index('-o')+1]=str(output);assert scorecard.comparable_build(cmd)==scorecard.comparable_build(build['build_argv'])==scorecard.comparable_build(old['build_argv']);scorecard.matched_build(cmd,tier,str(paths['cli']),str(paths['runtime']));env=build['environment'];fpre={k:statfd(fd) for k,fd in fds.items()};effpre=effects();trace=outdir/f'{stem}.trace';argv=['/usr/bin/strace','-f','-y','-v','-qq','-s','512','-e','trace='+SYS,'-o',str(trace),str(PROBE),'gate',str(output),*cmd];start=time.monotonic();p=subprocess.Popen(argv,cwd=build['cwd'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,close_fds=True);timed=False
   try:stdout,stderr=p.communicate(timeout=90)
   except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
   seconds=round(time.monotonic()-start,3);(outdir/f'{stem}.stdout').write_bytes(stdout);(outdir/f'{stem}.stderr').write_bytes(stderr);effpost=effects();dump(outdir/f'{stem}.effects.before.json',effpre);dump(outdir/f'{stem}.effects.after.json',effpost);txt=trace.read_text();first,child=raw_control.execs(txt.splitlines(),scorecard.require);actual=raw_control.exec_environment(txt.splitlines()[child[0]],scorecard.require);diagnostic=stderr.decode();
   if kind=='direct':raw_control.trace_direct_gate(txt,cmd,str(PROBE),diagnostic,scorecard.require,expected_exit=1)
   else:raw_control.trace_gate(txt,cmd,str(PROBE),str(POISON),diagnostic,scorecard.require,expected_exit=1)
   fpost={k:statfd(fd) for k,fd in fds.items()};assert p.returncode==0 and not timed and not output.exists() and actual==env and fpre==fpost and effpre==effpost;L.write_bytes(original)
   if POISON.exists():POISON.unlink()
   assert L.read_bytes()==original and not POISON.exists();m={'tier':tier,'kind':kind,'controller_sha256':sha(__file__),'corrected_gate_record_sha256':sha(G/'raw'/f'{tier}.{kind}.json'),'source_negative_sha256':hashlib.sha256(negative).hexdigest(),'poison_sha256':old['poison_sha256'],'build_argv':cmd,'capture_argv':argv,'cwd':build['cwd'],'environment':env,'actual_compiler_path':child[2],'actual_compiler_argv':child[3],'actual_compiler_environment':actual,'fd_fstat_before':fpre,'fd_fstat_after':fpost,'supervisor_exit_code':p.returncode,'compiler_child_exit_code':1,'image_absent_before':True,'image_absent_after':not output.exists(),'seconds':seconds,'stdout_sha256':sha(outdir/f'{stem}.stdout'),'stderr_sha256':sha(outdir/f'{stem}.stderr'),'trace_sha256':sha(trace),'effects_before_sha256':sha(outdir/f'{stem}.effects.before.json'),'effects_after_sha256':sha(outdir/f'{stem}.effects.after.json'),'launcher_restored_sha256':sha(L),'poison_absent':not POISON.exists()};assert child[2]==str(paths['cli']) and child[3]==cmd;dump(outdir/f'{stem}.json',m);records.append(m);print(stem,'child exit 1; no image; same graph',seconds,flush=True)
finally:
 if L.read_bytes()!=original:L.write_bytes(original)
 if POISON.exists():POISON.unlink()
 after={k:measure(fds[k],p) for k,p in paths.items()}
 for fd in fds.values():os.close(fd)
assert before==after and len(records)==4;dump(outdir/'bracket.json',{'schema':'imre.json959.gate-identity-bracket.v1','controller_sha256':sha(__file__),'fd_before':before,'fd_after':after,'fd_unchanged':before==after,'corrected_gate_supplement_sha256':sha(G/'COMPLETE.json'),'controls':[{'tier':m['tier'],'kind':m['kind'],'record_sha256':sha(outdir/f"{m['tier']}.{m['kind']}.json")} for m in records],'gate_identity_scope':'One contemporaneous held-FD hash bracket spans all four sequential negative builds; per-gate fstat and raw compiler exec/exit evidence are included. Path-based exec is not atomically bound to the measured FD.'});print('gate bracket unchanged',flush=True)
