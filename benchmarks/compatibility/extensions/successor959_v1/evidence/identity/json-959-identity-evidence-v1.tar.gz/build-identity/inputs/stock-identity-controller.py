import hashlib, io, json, os, pathlib, stat, subprocess, tarfile, time
R=pathlib.Path('/workspace/scratch/json-decode-959-replay-v1')
D=pathlib.Path('/workspace/scratch/json-959-stock-identity-v1')
P=pathlib.Path('/workspace/scratch/imre-95908-transferred-stdlib-v1')
O=R/'raw/stock.json'; stock=json.loads(O.read_text()); builds={t:json.loads((R/'raw'/f'{t}.build.json').read_text()) for t in ('O0','O3')}
ALLOW={'NO_COLOR','PATH','PYTHONDONTWRITEBYTECODE','PYTHONPATH','PYTHON_COLORS','TMPDIR'}
assert set(stock['environment'])==ALLOW and set(builds['O0']['environment'])==ALLOW
D.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def measured(path):
 p=pathlib.Path(path); fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC)
 try:
  before=os.fstat(fd); h=hashlib.sha256()
  while b:=os.read(fd,1024*1024):h.update(b)
  after=os.fstat(fd); assert (before.st_dev,before.st_ino,before.st_size,before.st_ctime_ns,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_ctime_ns,after.st_mtime_ns)
  return {'path':str(p),'fd_realpath':os.readlink(f'/proc/self/fd/{fd}'),'sha256':h.hexdigest(),'stat':{'dev':before.st_dev,'ino':before.st_ino,'size':before.st_size,'ctime_ns':before.st_ctime_ns,'mtime_ns':before.st_mtime_ns,'mode':stat.S_IMODE(before.st_mode)},'fstat_unchanged':True}
 finally:os.close(fd)
def write(name,obj): (D/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def effects():
 a=[]
 for root in map(pathlib.Path,[stock['cwd'],stock['environment']['TMPDIR']]):
  for p in sorted(root.rglob('*')):
   st=p.lstat();x={'root':root.name,'path':str(p.relative_to(root)),'mode':stat.S_IMODE(st.st_mode),'kind':'file' if p.is_file() else 'directory' if p.is_dir() else 'other'}
   if p.is_file():x['sha256']=measured(p)['sha256']
   a.append(x)
 return a
paths={'stock':stock['argv'][0],'cli':builds['O0']['argv'][0],'runtime':builds['O0']['argv'][builds['O0']['argv'].index('--runtime')+1],'clang':builds['O0']['argv'][builds['O0']['argv'].index('--clang')+1]}
for t in ('O0','O3'):
 a=builds[t]['argv'];assert a[0]==paths['cli'] and a[a.index('--runtime')+1]==paths['runtime'] and a[a.index('--clang')+1]==paths['clang']
pre={k:measured(v) for k,v in paths.items()}; assert pre['stock']['sha256']=='c27397da5541f67655be462e128ca3d3eb6e0a8eb0d39036896c9042529f4304'
transfer=json.loads((P/'transfer-provenance.json').read_text()); assert all(pre[k]['sha256']==transfer[k+'_sha256'] for k in ('cli','runtime','clang'))
archive=measured(P/'product.tar.zst');assert archive['sha256']==transfer['sha256']
proc=subprocess.Popen(['zstd','-dc',str(P/'product.tar.zst')],stdout=subprocess.PIPE,stderr=subprocess.PIPE); archive_hashes={}
with tarfile.open(fileobj=proc.stdout,mode='r|') as tar:
 for member in tar:
  key={'product/imre':'cli','product/libimre_runtime.a':'runtime'}.get(member.name.removeprefix('./'))
  if key:
   stream=tar.extractfile(member);h=hashlib.sha256()
   while b:=stream.read(1024*1024):h.update(b)
   archive_hashes[key]=h.hexdigest()
assert proc.wait()==0 and archive_hashes=={k:pre[k]['sha256'] for k in ('cli','runtime')}
receipt={}
with tarfile.open('/workspace/scratch/json-decode-959-selected-v1.tar.gz') as selected:
 for name in ('raw/stock.json','raw/O0.build.json','raw/O3.build.json'):
  member=selected.getmember(name); data=selected.extractfile(member).read(); p=R/name;assert data==p.read_bytes();receipt[name]={'sha256':sha(data),'sealed_archive_member_mtime':member.mtime,'observed_fstat':measured(p)['stat']}
sealed=measured('/workspace/scratch/json-decode-959-selected-v1.tar.gz'); assert sealed['sha256']=='fae5b50a20c65bb58f960fc230491469b8e7266e6ff53f25e39305b4b72fe91b'
version=subprocess.run([paths['stock'],'-I','-B','--version'],env={'LANG':'C.UTF-8'},capture_output=True,check=True,text=True).stdout.strip();assert version=='Python 3.14.5'
write('retrospective.json',{'schema':'imre.json959.retrospective-identity.v1','observed_utc_ns':time.time_ns(),'scope':'retrospective path-byte measurement and OS inode metadata, not contemporaneous positive build identity','paths':pre,'transfer_sha256':sha((P/'transfer-provenance.json').read_bytes()),'archive':archive,'archive_member_sha256':archive_hashes,'selected_archive':sealed,'receipts':receipt,'stock_version':version})
stock_before=measured(paths['stock']); before=effects(); tr=D/'stock.trace'; syscall='execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,rename,wait4,waitid,exit,exit_group,chdir,fchdir,close,close_range,dup,dup2,dup3,fcntl,clone,clone3,fork,vfork'; argv=['/usr/bin/strace','-f','-y','-v','-qq','-s','512','-e','trace='+syscall,'-o',str(tr),*stock['argv']];start=time.time_ns();q=subprocess.run(argv,cwd=stock['cwd'],env=stock['environment'],capture_output=True,timeout=90);finish=time.time_ns();after=effects();stock_after=measured(paths['stock']);(D/'stock.stdout').write_bytes(q.stdout);(D/'stock.stderr').write_bytes(q.stderr);write('stock.effects.before.json',before);write('stock.effects.after.json',after)
assert q.returncode==0 and before==after and q.stdout==(R/'raw/stock.stdout').read_bytes() and q.stderr==(R/'raw/stock.stderr').read_bytes() and stock_before==stock_after
write('stock.json',{'schema':'imre.json959.stock-identity-rerun.v1','argv':stock['argv'],'capture_argv':argv,'cwd':stock['cwd'],'environment':stock['environment'],'timeout_seconds':90,'start_utc_ns':start,'finish_utc_ns':finish,'exit_code':q.returncode,'stdout_sha256':sha(q.stdout),'stderr_sha256':sha(q.stderr),'trace_sha256':sha(tr.read_bytes()),'effects_before_sha256':sha((D/'stock.effects.before.json').read_bytes()),'effects_after_sha256':sha((D/'stock.effects.after.json').read_bytes()),'stock_before':stock_before,'stock_after':stock_after,'version':version,'old_stock_metadata_sha256':sha(O.read_bytes()),'same_ordered_streams_and_effects':True})
files={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(D.iterdir()) if p.is_file()}; write('COMPLETE.json',{'schema':'imre.json959.identity-supplement.v1','credit':0,'files':files}); print(json.dumps({'dir':str(D),'complete_sha256':sha((D/'COMPLETE.json').read_bytes()),'stock_exit':q.returncode,'same_streams_effects':True,'files':len(files),'credit':0}))
