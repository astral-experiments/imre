"""Bounded second positive builds for the existing finite identity join."""
import fcntl,hashlib,importlib.util,json,os,pathlib,signal,stat,subprocess,sys,threading,time
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/scratch/dataclasses-959-replay-v1');P=pathlib.Path('/workspace/scratch/imre-95908-transferred-config-v1/product');W=pathlib.Path('/workspace/scratch/imre-dataclasses-959-identity-effects');sys.path.insert(0,str(W/'benchmarks/compatibility'));import raw_control,scorecard
spec=importlib.util.spec_from_file_location('effects_capture','/workspace/scratch/dataclasses-959-identity-effects-v1/capture.py');effects=importlib.util.module_from_spec(spec);spec.loader.exec_module(effects)
def sha(p):return effects.h(p)
def dump(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def st(s):return {'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mode':s.st_mode,'ctime_ns':s.st_ctime_ns,'mtime_ns':s.st_mtime_ns}
def fdrecord(fd,path):
 a=st(os.fstat(fd));os.lseek(fd,0,os.SEEK_SET);h=hashlib.sha256()
 while b:=os.read(fd,1024*1024):h.update(b)
 z=st(os.fstat(fd));return {'path':str(path),'fd':fd,'fd_realpath':os.readlink('/proc/self/fd/'+str(fd)),'flags':fcntl.fcntl(fd,fcntl.F_GETFL),'fstat':a,'path_stat':st(os.stat(path)),'read_fstat_unchanged':a==z,'sha256':h.hexdigest()}
def children(pid):
 try:return [int(p) for p in pathlib.Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
 except (OSError,ValueError):return []
def monitor(trace,pre,stop,samples):
 import re
 seen=set();pending={};offset=0
 while not stop.wait(.005):
  try:
   with trace.open() as f:
    f.seek(offset)
    for line in f:
     x=re.match(r'^(\d+)\s+execve\(("(?:[^"\\]|\\.)*")',line)
     if x:
      try:path=json.loads(x[2])
      except ValueError:continue
      for role in ('cli','clang'):
       if path==pre[role]['path']:pending[(role,int(x[1]))]=path
    offset=f.tell()
  except OSError:pass
  for (role,pid),path in list(pending.items()):
   if (role,pid) in seen:continue
   try:
    f=os.open(f'/proc/{pid}/exe',os.O_RDONLY|os.O_CLOEXEC)
    try:stated=st(os.fstat(f));target=os.readlink(f'/proc/{pid}/exe')
    finally:os.close(f)
    if stated==pre[role]['fstat']:
     argv=[os.fsdecode(x) for x in pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\x00') if x];samples.append({'role':role,'pid':pid,'target':target,'fstat':stated,'argv':argv,'sample_utc_ns':time.time_ns()});seen.add((role,pid))
   except OSError:pass
def build(t):
 d=D/t;d.mkdir();priorpath=R/'raw'/(t+'.build.json');prior=json.loads(priorpath.read_bytes());cmd=list(prior['target_argv']);image=D/(t+'.exe');assert not image.exists();cmd[cmd.index('-o')+1]=str(image);paths={'cli':P/'imre','runtime':P/'libimre_runtime.a','clang':P/'imre-toolchain/bin/clang'};fds={k:os.open(p,os.O_RDONLY|os.O_CLOEXEC) for k,p in paths.items()};pre={k:fdrecord(fds[k],p) for k,p in paths.items()};baseline=json.loads((R/'identity.json').read_bytes());assert all(v['sha256']==baseline['products'][k] and v['read_fstat_unchanged'] and v['fstat']==v['path_stat'] for k,v in pre.items());bef=effects.effects(prior);dump(d/'effects.before.json',bef);trace=d/'positive.trace';argv=['/usr/bin/strace','-f','-yy','-v','-qq','-s','65535','-e','trace=execve,execveat,clone,clone3,fork,vfork,wait4,waitid,exit,exit_group','-o',str(trace),'--',*cmd];start_ns=time.time_ns();started=time.monotonic();deadline=started+360;proc=None;stop=threading.Event();samples=[];timed=False;out=err=b''
 try:
  proc=subprocess.Popen(argv,cwd=prior['cwd'],env=prior['environment'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);thread=threading.Thread(target=monitor,args=(trace,pre,stop,samples),daemon=True);thread.start()
  try:out,err=proc.communicate(timeout=max(.001,deadline-time.monotonic()))
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(proc.pid,signal.SIGTERM)
   try:out,err=proc.communicate(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);out,err=proc.communicate(timeout=5)
  finally:stop.set();thread.join(timeout=2)
  post={k:fdrecord(fds[k],p) for k,p in paths.items()};finish_ns=time.time_ns();aft=effects.effects(prior);dump(d/'effects.after.json',aft);(d/'stdout').write_bytes(out);(d/'stderr').write_bytes(err);text=trace.read_text();events=raw_control.successful_exec_events(text.splitlines(),scorecard.require);compiler=next(e for e in events if e[2]==cmd[0]);child_exit=raw_control.child_exit_code(text.splitlines(),compiler[1],scorecard.require);newsha=sha(image) if image.exists() else None;v={'schema':'imre.compatibility.positive-identity.v1','build_argv':cmd,'cwd':prior['cwd'],'environment':prior['environment'],'timeout_seconds':360,'timeout_policy':'absolute-monotonic-from-before-popen','start_utc_ns':start_ns,'finish_utc_ns':finish_ns,'seconds':time.monotonic()-started,'fd_before':pre,'fd_after':post,'compiler_pid':int(compiler[1]),'actual_compiler_path':compiler[2],'actual_compiler_argv':compiler[3],'actual_compiler_environment':raw_control.exec_environment(compiler[4],scorecard.require),'compiler_exit_code':child_exit,'strace_exit_code':proc.returncode,'timed_out':timed,'trace_argv':argv,'trace_sha256':sha(trace),'controller_sha256':sha(__file__),'positive_build_metadata_sha256':sha(priorpath),'source_sha256':baseline['source']['sha256'],'launcher_sha256':sha(R/'launch/launcher.py'),'new_image_sha256':newsha,'old_image_sha256':prior['image_sha256'],'elf_identical':newsha==prior['image_sha256'],'stdout_sha256':sha(d/'stdout'),'stderr_sha256':sha(d/'stderr'),'effects_before_sha256':sha(d/'effects.before.json'),'effects_after_sha256':sha(d/'effects.after.json'),'live_exe_samples':samples,'identity_limit':'After-exec samples do not provide atomic FD exec.'};dump(d/'positive.json',v);print(t,'exit',child_exit,'elapsed',round(v['seconds'],3),'sha',newsha,'identical',v['elf_identical'],'live',[(x['role'],x['pid']) for x in samples],flush=True);assert not timed and proc.returncode==child_exit==0 and pre==post and bef==aft and newsha
 finally:
  for f in fds.values():os.close(f)
if __name__=='__main__':build(sys.argv[1])
