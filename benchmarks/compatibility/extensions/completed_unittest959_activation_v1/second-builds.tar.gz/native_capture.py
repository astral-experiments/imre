"""Bounded direct source withdrawal of the exact newly built saved image."""
import hashlib,json,os,pathlib,re,signal,stat,subprocess,sys,time
D=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/scratch/dataclasses-959-replay-v1');W=pathlib.Path('/workspace/scratch/imre-dataclasses-959');sys.path.insert(0,str(W/'benchmarks/compatibility'));from collect_unittest_results import parse
def h(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def st(x):return {'dev':x.st_dev,'ino':x.st_ino,'size':x.st_size,'ctime_ns':x.st_ctime_ns,'mtime_ns':x.st_mtime_ns,'mode':stat.S_IMODE(x.st_mode)}
def hashfd(fd):
 os.lseek(fd,0,os.SEEK_SET);a=st(os.fstat(fd));v=hashlib.sha256()
 while b:=os.read(fd,1024*1024):v.update(b)
 z=st(os.fstat(fd));assert a==z;return {'sha256':v.hexdigest(),'fstat':a}
def effects(meta):
 out={}
 for root in map(pathlib.Path,(meta['cwd'],meta['environment']['TMPDIR'])):
  items=[]
  for p in sorted(root.rglob('*')):
   s=p.lstat();v={'path':p.relative_to(root).as_posix(),'mode':stat.S_IMODE(s.st_mode)}
   if stat.S_ISREG(s.st_mode):v.update(kind='regular',bytes=s.st_size,sha256=h(p))
   elif stat.S_ISDIR(s.st_mode):v['kind']='directory'
   elif stat.S_ISLNK(s.st_mode):v.update(kind='symlink',target=os.readlink(p))
   else:v['kind']='other'
   items.append(v)
  out[str(root)]=items
 return out
def fixture():return {str(p.relative_to(R/'fixtures')):h(p) for p in sorted((R/'fixtures').rglob('*')) if p.is_file()}
def custody():
 return {'launcher':h(R/'launch/launcher.py'),'original_source':h(R/'launch/stock.source.py'),'fixture_manifest_sha256':h(R/'fixtures.before.json'),'probe':h(R/'probe'),'images':{t:h(R/(t+'.exe')) for t in ('O0','O3')},'fixture_files':len(fixture()),'fixture_equal':fixture()==json.loads((R/'fixtures.before.json').read_bytes()),'cli':h('/workspace/scratch/imre-95908-transferred-config-v1/product/imre'),'runtime':h('/workspace/scratch/imre-95908-transferred-config-v1/product/libimre_runtime.a'),'stock':h('/workspace/scratch/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14')}
def restore():
 tree=R/'fixtures/Lib/test';stash=pathlib.Path(str(tree)+'.raw-control-stash');rest=[]
 for p in (R/'launch/stock.source.py',R/'launch/launcher.py',tree):
  q=stash if p==tree else pathlib.Path(str(p)+'.raw-control-stash')
  if q.exists() and not p.exists():q.rename(p);rest.append(str(p))
 return rest
def run(tier):
 m=json.loads((R/'raw'/(tier+'.json')).read_bytes());target=list(m['target_argv']);assert tier in {'O0','O3'};target[-1]=str(D/(tier+'.exe'));exe=target[-1];cap=m['timeout_seconds'];assert cap==240;outdir=D/(tier+'.native');outdir.mkdir();fd=os.open(exe,os.O_RDONLY|os.O_CLOEXEC);pre=hashfd(fd);assert pre['fstat']==st(os.stat(exe));before=effects(m);dump(outdir/'effects.before.json',before);tr=outdir/'run.trace';calls='execve,execveat,open,openat,openat2,creat,io_uring_setup,newfstatat,statx,rename,renameat,renameat2,wait4,waitid,exit,exit_group,chdir,fchdir,close,close_range,dup,dup2,dup3,fcntl,clone,clone3,fork,vfork,write,writev,unlink,unlinkat,link,linkat,symlink,symlinkat';cmd=['/usr/bin/strace','-f','-yy','-v','-qq','-s','65535','-e','trace='+calls,'-o',str(tr),'--',*target];startns=time.time_ns();start=time.monotonic();deadline=start+cap;p=None;sample=None;sample_error=None;timed=False;restored=[];out=err=b''
 try:
  p=subprocess.Popen(cmd,cwd=m['cwd'],env=m['environment'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  while p.poll() is None and time.monotonic()<deadline and sample is None:
   if tr.exists():
    for line in tr.open():
     x=re.match(r'^(\d+)\s+execve\('+re.escape(json.dumps(exe))+r',',line)
     if x:
      try:
       f=os.open('/proc/'+x[1]+'/exe',os.O_RDONLY|os.O_CLOEXEC);sample={'pid':x[1],'target':os.readlink('/proc/'+x[1]+'/exe'),'fstat':st(os.fstat(f)),'sample_utc_ns':time.time_ns()};os.close(f)
      except OSError as e:sample_error=repr(e)
      break
   if sample is None:time.sleep(.002)
  try:out,err=p.communicate(timeout=max(.001,deadline-time.monotonic()))
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGTERM)
   try:out,err=p.communicate(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate(timeout=5)
 finally:
  restored=restore();post=hashfd(fd);path_post=st(os.stat(exe));os.close(fd)
 finish=time.time_ns();after=effects(m);dump(outdir/'effects.after.json',after);(outdir/'stdout').write_bytes(out);(outdir/'stderr').write_bytes(err);res=parse(err,timed);original=parse((R/'raw'/(tier+'.stderr')).read_bytes(),False);identical=res['originals']==original['originals'] and res['summary']==original['summary'];v={'schema':'imre.compatibility.held-executable-effects.v1','tier':tier,'controller_sha256':h(__file__),'argv':target,'capture_argv':cmd,'cwd':m['cwd'],'environment':m['environment'],'timeout_seconds':cap,'timeout_policy':'absolute-monotonic-from-before-popen','start_utc_ns':startns,'finish_utc_ns':finish,'observed_elapsed_seconds':time.monotonic()-start,'exit_code':p.returncode,'timed_out':timed,'held_fd_pre':pre,'held_fd_post':post,'path_post_fstat':path_post,'proc_exe_sample':sample,'proc_exe_sample_error':sample_error if sample is None else None,'stdout_sha256':h(outdir/'stdout'),'stderr_sha256':h(outdir/'stderr'),'trace_sha256':h(tr),'effects_before_sha256':h(outdir/'effects.before.json'),'effects_after_sha256':h(outdir/'effects.after.json'),'original_metadata_sha256':h(R/'raw'/(tier+'.json')),'same_ordered_originals_and_outcomes':identical,'stdout_identical':out==(R/'raw'/(tier+'.stdout')).read_bytes(),'stderr_identical':err==(R/'raw'/(tier+'.stderr')).read_bytes(),'collection':res['collection'],'summary':res['summary'],'counts':dict(__import__('collections').Counter(x['outcome'] for x in res['originals'])),'emergency_restores':restored,'limits':'Live after-exec sample is not atomic FD exec.'};dump(outdir/'result.json',v);assert fixture()==json.loads((R/'fixtures.before.json').read_bytes()) and h(R/'launch/launcher.py')==json.loads((R/'identity.json').read_bytes())['launcher_sha256'];assert not timed and not restored and pre==post and path_post==post['fstat'] and sample is not None and sample['fstat']==pre['fstat'] and before==after and identical and v['stdout_identical'] and v['stderr_identical'] and p.returncode==m['exit_code'];print(tier,'exit',p.returncode,v['counts'],'live_pid',sample['pid'],'effects_equal',before==after,'elapsed',round(v['observed_elapsed_seconds'],3),flush=True)
if __name__=='__main__':
 a=sys.argv[1]
 if a in ('before','after'):v=custody();dump(D/(a+'.json'),v);print(a,v['fixture_files'],v['fixture_equal'],v['images'])
 else:run(a)
