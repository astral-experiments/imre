import sys
if len(sys.argv)>1 and sys.argv[1]=='observed':
    from test.support import script_helper
    run_until_end=script_helper.run_python_until_end
    def observed(*args,**kwargs):
        item=run_until_end(*args,**kwargs)
        res,argv=item
        print("NESTED_ARGV",repr(argv),flush=True)
        print("NESTED_RC",res.rc,flush=True)
        print("NESTED_OUT",repr(res.out),flush=True)
        print("NESTED_ERR",repr(res.err),flush=True)
        return item
    script_helper.run_python_until_end=observed
import checkpoint_test_weakref
