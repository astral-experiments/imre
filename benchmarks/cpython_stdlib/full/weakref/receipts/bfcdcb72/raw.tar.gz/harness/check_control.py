from pathlib import Path
import sys
lines=Path(sys.argv[1]).read_text().splitlines()
err=Path(sys.argv[2]).read_text()
names=[x.split()[1] for x in lines if x.startswith('CALL ')]
expected=['last','error','new','old']
ok=(names==expected and lines[1].startswith('BODY_END retained owners 1 owner_alive True events []') and
    all('owners 1 owner_alive True' in l for l in lines if l.startswith('CALL ')) and 'ZeroDivisionError' in err)
print('observed',names,'expected',expected,'retained_order_and_report',ok)
sys.exit(0 if ok else 1)
