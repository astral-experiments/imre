import base64
import json
import sys
from test.support import script_helper

target = script_helper.run_python_until_end
while hasattr(target, '__wrapped__'):
    target = target.__wrapped__

def observe(frame,event,arg):
    if frame.f_code is target.__code__ and event=='return' and arg is not None:
        res,argv=arg
        print('ACTUAL_CHILD',json.dumps(dict(argv=argv,exit=res.rc,
              stdout_b64=base64.b64encode(res.out).decode(),
              stderr_b64=base64.b64encode(res.err).decode())),flush=True)

sys.setprofile(observe)
try:
    import checkpoint_test_weakref
finally:
    sys.setprofile(None)
