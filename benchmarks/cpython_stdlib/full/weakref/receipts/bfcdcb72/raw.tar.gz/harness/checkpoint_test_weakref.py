import os
import sys
import unittest
from test import support

support.use_resources = {}
from test import test_weakref as target

print("IMPORT_OK", target.__name__, flush=True)
print("ORIGINAL_SOURCE", target.__file__, support.__file__, sys.implementation.name, flush=True)

class Events(unittest.TextTestResult):
    def startTest(self, test):
        print("startTest", test.id(), flush=True)
        super().startTest(test)

    def stopTest(self, test):
        super().stopTest(test)
        print("stopTest", test.id(), flush=True)

    def addSuccess(self, test):
        print("addSuccess", test.id(), flush=True)
        super().addSuccess(test)

    def addError(self, test, err):
        print("addError", test.id(), str(err[1]), flush=True)
        super().addError(test, err)

    def addFailure(self, test, err):
        print("addFailure", test.id(), str(err[1]), flush=True)
        super().addFailure(test, err)

    def addSkip(self, test, reason):
        print("addSkip", test.id(), reason, flush=True)
        super().addSkip(test, reason)

    def addSubTest(self, test, subtest, err):
        print("addSubTest", test.id(), subtest.id(), str(err[1]) if err else None, flush=True)
        super().addSubTest(test, subtest, err)

suite = unittest.defaultTestLoader.loadTestsFromModule(target)
selector = os.environ.get("WEAKREF_CHECKPOINT_KEYS", "")
if selector:
    requested = set(selector.split(","))
    found = set()
    ordinals = {}
    selected = unittest.TestSuite()

    def select(cases):
        for child in cases:
            if isinstance(child, unittest.TestSuite):
                select(child)
            else:
                name = child.id()
                ordinal = ordinals.get(name, 0) + 1
                ordinals[name] = ordinal
                key = name + "#" + str(ordinal)
                if key in requested:
                    found.add(key)
                    selected.addTest(child)

    select(suite)
    if found != requested:
        raise ValueError("Missing original keys: " + repr(sorted(requested - found)))
    suite = selected
print("REGISTERED_COUNT", suite.countTestCases(), flush=True)
result = unittest.TextTestRunner(verbosity=2, descriptions=False, resultclass=Events).run(suite)
print("RUNNER_RETURN", result.testsRun, result.wasSuccessful(), flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
