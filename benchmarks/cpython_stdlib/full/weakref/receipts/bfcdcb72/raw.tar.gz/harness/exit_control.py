import gc
import sys
import weakref

class Owner:
    pass

def emit(name):
    events.append(name)
    print("CALL", name, "owners", len(owners), "owner_alive", anchor() is not None, flush=True)

def failing():
    weakref.finalize(Owner, emit, "new")
    emit("error")
    1 / 0

mode = sys.argv[1]
events = []
owner = Owner()
owner.loop = owner
owners = [owner]
anchor = weakref.ref(owner)
old = weakref.finalize(owner, emit, "old")
off = weakref.finalize(owner, emit, "disabled")
off.atexit = False
err = weakref.finalize(owner, failing)
last = weakref.finalize(owner, emit, "last")
if mode == "detach":
    detached = err.detach()
    assert detached[0] is owner and detached[1] is failing
    del detached
elif mode == "atexit-false":
    err.atexit = False
elif mode not in ("retained", "released"):
    raise AssertionError(mode)
del owner
print("REGISTERED", mode, "owners", len(owners), "err_alive", err.alive, "err_atexit", err.atexit, flush=True)
if mode == "released":
    owners.clear()
gc.collect()
print("BODY_END", mode, "owners", len(owners), "owner_alive", anchor() is not None, "events", events, flush=True)
