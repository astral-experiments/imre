from boxed_typing_bytestring import current
current()
print("qualified typing.ByteString")
