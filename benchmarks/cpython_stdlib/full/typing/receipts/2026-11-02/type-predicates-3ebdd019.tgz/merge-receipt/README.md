# Requalification of the TypeGuard and TypeIs merge

Imre `3ebdd0192e13c63a4c6a981e497ce697706ef7b3` merges
`1d74cc369713e23dd4775fbaab94071bca2a3234` with public main
`7b5bb2c7d96a6519560ff6e5cf738e992589fafb`. Main removed the bare-name strong
reference to every source class in #4080. The merge retains only the top-level
`typing._Final` registration used by the native generic alias subclass hook.
The appended GC control checks that a different class named `_Final` can be
collected and that its weakref callback runs once. The other independent
controls check the four inheritance expressions for each predicate, allowed
root class definitions, and that rebinding `typing._Final` leaves an existing
alias type's hook intact.

Stock CPython was built from `5607950ef232dad16d75c0cf53101d9649d89115`.
The upstream test file has SHA-256
`28d17772f523800f02a5bf1e0cc012779d7df1f616fec7cc34d922dcba7ee1cc`.
The stage includes byte-identical lines 62, 67–71, 86–87, 6660, 10435–10482
and 10485–10532 at their original line positions. The first two lines import
the dependencies. The isolated classes own 10 original unittest IDs,
ordinals 515–524 in the ordered reference inventory. The intact 712-case
discovery and the historical ledger are separate.

Reproduce from `driver/` with absolute paths to the test-enabled stock
interpreter, Imre, its matching archive, and clang.

```sh
"$STOCK" -B qualify.py
for level in 0 3; do
    "$IMRE" build qualify.py --module-root "$PWD" --runtime-imports --no-cache \
        --clang "$CLANG" --runtime "$RUNTIME" --opt-level "$level" -o "boxed-O$level"
    "./boxed-O$level"
    IMREFLAGS="--clang $CLANG --runtime $RUNTIME --opt-level $level --no-cache" \
        "$IMRE" -B -m qualify
done
```

Git reports stable patch ID `66533db5dbea80157bd14888ba261d0090856724` for
both the tested branch delta (`7b5bb2c7..3ebdd019`) and the public squash
(`31711dcd..c7774039`). Intervening changes on main give the two complete
trees different hashes. The raw runs here use the branch binary at `3ebdd019`.
