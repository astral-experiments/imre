from typing import Callable, Concatenate, ParamSpec, Tuple, TypeVarTuple, Unpack

Ts = TypeVarTuple('Ts')
P = ParamSpec('P')
Q = ParamSpec('Q')

pack_first = Concatenate[Unpack[Ts], P]
assert pack_first.__parameters__ == (Ts, P)
assert pack_first[int, str, [float, bool]] == (int, str, float, bool)
assert pack_first[int, Q] == Concatenate[int, Q]
assert pack_first[[float]] == (float,)

param_first = Callable[P, Tuple[Unpack[Ts]]]
assert param_first.__parameters__ == (P, Ts)
assert param_first[[str, float], int, bytes] == Callable[[str, float], Tuple[int, bytes]]
assert param_first[Q, bool] == Callable[Q, Tuple[bool]]

print("PASS mixed pack and ParamSpec preparation in both declaration orders")
