import typing as t
from typing import Concatenate

class Origin:
    pass

Origin.marker = object()

P = t.ParamSpec('P')
assert t.Concatenate is Concatenate
kind = type(Concatenate[int, P])
concat = kind(Origin, (int, P), inst=False)
assert concat._name is None and concat._inst is False
assert concat.__args__ == (int, P) and concat.__origin__ is Origin
assert concat.marker is Origin.marker
shared = Origin.marker
Origin.marker = object()
assert concat.marker is Origin.marker and concat.marker is not shared
assert concat.copy_with((str, [])) == (str,)
print('Concatenate origin forwarding, metadata, and copy_with passed')

generic = t._GenericAlias(Origin, (int,), inst=False, name='Named')
other = t._GenericAlias(Origin, (str,))
assert generic._name == 'Named' and generic._inst is False
assert other._name is None and other._inst is True
generic.marker = object()
assert generic.marker is other.marker is Origin.marker
generic.copy_with = 'origin attribute'
assert Origin.copy_with == 'origin attribute'
assert generic.copy_with((str,)).__args__ == (str,)
assert generic.__parameters__ == () and generic.__args__ == (int,)
print('named and unnamed generic origin state, metadata, and copy_with passed')

named = t._CallableGenericAlias(Origin, (int, str), inst=False, name='Callable')
assert named._name == 'Callable' and named._inst is False
assert named.marker is Origin.marker
Origin.marker = object()
assert named.marker is Origin.marker and concat.marker is Origin.marker
assert t.List[int]._name == 'List' and t.List[int].append is list.append
print('named callable origin forwarding and public List alias passed')
