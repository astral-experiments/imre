import json,os,sys,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent
mode,level=sys.argv[1:3]
out=r/'receipts'/(mode+level)
out.mkdir(exist_ok=True)
src=r/('probes' if mode=='boxed' else 'ordinary-probes')
entry='broad.py' if mode=='boxed' else 'focus.py'
cmd=[r/'target/debug/imre','build',src/entry,'--module-root',src,'--no-cache','--opt-level',level,'--runtime',r/'target/debug/libimre_runtime.a','--clang','/workspace/scratch/intact/tools/usr/bin/clang-19','-o',out/'program']
if mode=='boxed':cmd.append('--runtime-imports')
for phase,args in [('build',cmd),('run',[out/'program'])]:
 started=time.monotonic()
 with (out/(phase+'.stdout')).open('wb') as so,(out/(phase+'.stderr')).open('wb') as se:
  result=subprocess.run(list(map(str,args)),cwd=src,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=so,stderr=se,timeout=1800)
 (out/(phase+'.json')).write_text(json.dumps(dict(argv=list(map(str,args)),returncode=result.returncode,seconds=round(time.monotonic()-started,3)))+'\n')
 print(mode,level,phase,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
(out/'program').unlink()
