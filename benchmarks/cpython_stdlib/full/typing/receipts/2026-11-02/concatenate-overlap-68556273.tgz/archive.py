from pathlib import Path
import hashlib, json, sys, tarfile
r=Path(__file__).resolve().parent
status={}
for d in sorted((r/'receipts').iterdir()):
 if not d.is_dir():continue
 if (d/'run.json').exists():
  status[d.name]=dict(exit=json.loads((d/'run.json').read_text())['returncode'],signals=(d/'run.stdout').read_text().splitlines())
 elif (d/'build.json').exists():
  status[d.name]=dict(build_exit=json.loads((d/'build.json').read_text())['returncode'],diagnostics=(d/'build.stderr').read_text())
(r/'status.json').write_text(json.dumps(status,indent=2)+'\n')
p=r/sys.argv[1]
with tarfile.open(p,'w:gz') as tf:
 for n in ['archive.py','execute.py','port.patch','revision.txt','native-shas.txt','provenance.txt','status.json','build.log']:tf.add(r/n,arcname=n)
 for d in ('receipts','probes','ordinary-probes'):
  for f in sorted((r/d).rglob('*')):
   if f.is_file() and f.suffix!='.pyc' and f.name!='program':tf.add(f,arcname=f.relative_to(r))
print(p,hashlib.sha256(p.read_bytes()).hexdigest())
