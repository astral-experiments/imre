#!/usr/bin/env bash
set -eu
if [[ $4 == integration ]]; then
    exec 9>/tmp/imre-doc-inventory/integration-build.lock
else
    exec 9>/tmp/imre-doc-inventory/native-build.lock
fi
flock 9
mode=$1
opt=$2
binroot=$3
receipts=/tmp/imre-doc-inventory/$4
mkdir -p "$receipts"
flags=()
if [[ $mode == boxed ]]; then flags+=(--runtime-imports); fi
row=$receipts/$mode-O$opt
mkdir -p "$row"
argv=("$binroot/imre" build /tmp/imre-doc-inventory/candidate-stage/driver.py --module-root /tmp/imre-doc-inventory/candidate-stage --no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime "$binroot/libimre_runtime.a" --opt-level "$opt" "${flags[@]}" -o "$row/program")
printf '%q ' "${argv[@]}" > "$row/build.argv"
date -u > "$row/build.start"
status=0; TMPDIR=/tmp/imre-doc-inventory "${argv[@]}" > "$row/build.out" 2> "$row/build.err" || status=$?; echo "$status" > "$row/build.rc"; if [[ $status != 0 ]]; then exit "$status"; fi
for scenario in control observe original; do
    status=0; "$row/program" "$scenario" > "$row/$scenario.out" 2> "$row/$scenario.err" || status=$?; echo "$status" > "$row/$scenario.rc"
done
