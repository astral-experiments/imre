import hashlib,json,sys,tarfile
from pathlib import Path
r=Path('/tmp/imre-concat-mixed')
entries={}
for d in sorted((r/'receipts').iterdir()):
    if not (d/'run.json').exists():continue
    output=(d/'run.stdout').read_text().splitlines()
    entries[d.name]={
        'status':json.loads((d/'run.json').read_text())['returncode'],
        'passes':[v[5:] for v in output if v.startswith('PASS test.')],
        'skips':[v for v in output if v.startswith('SKIP ')],
        'mixed': 'PASS mixed pack and ParamSpec preparation in both declaration orders' in output,
        'independent':'Concatenate validated, substituted, and preserved its ParamSpec' in output,
        'registered_fixture':d.name.startswith('boxed') or d.name=='stockref'
    }
(r/'status.json').write_text(json.dumps(entries,indent=2)+'\n')
archive=r/sys.argv[1]
with tarfile.open(archive,'w:gz') as t:
    for n in ['archive.py','run.py','port.patch','revision.txt','native-shas.txt','build.log','status.json','provenance.txt']:t.add(r/n,arcname=n)
    for n in ['ordinary','boxed','receipts']:
        for f in sorted((r/n).rglob('*')):
            if f.is_file() and f.name!='program' and f.suffix!='.pyc':t.add(f,arcname=f.relative_to(r))
print(archive,hashlib.sha256(archive.read_bytes()).hexdigest(), list(entries))
