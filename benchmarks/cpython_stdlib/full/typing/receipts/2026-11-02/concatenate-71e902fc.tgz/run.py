import json, os, subprocess, sys, time
from pathlib import Path
r=Path('/tmp/imre-concat-mixed')
comp=r/'target/debug/imre'
rt=r/'target/debug/libimre_runtime.a'
clang='/workspace/scratch/intact/tools/usr/bin/clang-19'
stock='/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
def run(cmd,src,p):
    started=time.monotonic()
    with Path(str(p)+'.stdout').open('wb') as out,Path(str(p)+'.stderr').open('wb') as err:
        try: rc=subprocess.run(list(map(str,cmd)),cwd=src,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err,timeout=720).returncode
        except subprocess.TimeoutExpired: rc=124
    Path(str(p)+'.json').write_text(json.dumps(dict(argv=list(map(str,cmd)),returncode=rc,seconds=round(time.monotonic()-started,3)))+'\n')
    return rc
for mode,level in zip(sys.argv[1::2],sys.argv[2::2]):
    src=r/('boxed' if mode=='stock' else mode)
    out=r/'receipts'/(mode+level)
    out.mkdir(exist_ok=True)
    program=out/'program'
    if mode=='stock':args=[stock,'-B',src/'run.py']
    else:
        cmd=[comp,'build',src/'run.py','--no-cache','--runtime',rt,'--module-root',src,'--clang',clang,'--opt-level',level,'-o',program]
        if mode=='boxed':cmd.append('--runtime-imports')
        rc=run(cmd,src,out/'build')
        print(mode,level,'build',rc,flush=True)
        if rc:continue
        args=[program]
    rc=run(args,src,out/'run')
    print(mode,level,'run',rc,flush=True)
    program.unlink(missing_ok=True)
