import sys
import types
import typing

ids = ['ParamSpec', 'ParamSpecArgs', 'ParamSpecKwargs', 'TypedDict', '_collect_type_parameters', '_should_unflatten_callable_args', 'get_args', 'get_origin', 'get_protocol_members', 'is_protocol', 'is_typeddict']
missing = object()
def runtime_kind(item):
    try:
        return type(item).__name__
    except BaseException as ex:
        return type(ex).__name__ + ": " + str(ex)

for i, name in enumerate(ids):
    item = getattr(typing, name, missing)
    present = item is not missing
    d = typing.__dict__.get(name, missing)
    try:
        doc = item.__doc__ if present else None
        err = None
    except BaseException as ex:
        doc = None
        err = (type(ex).__name__, str(ex))
    print('ROW', repr((702+i,name,present,d is not missing,d is item if present else None,runtime_kind(item) if present else None,getattr(item,'__module__',None) if present else None,getattr(item,'__name__',None) if present else None,doc,err)), flush=True)

