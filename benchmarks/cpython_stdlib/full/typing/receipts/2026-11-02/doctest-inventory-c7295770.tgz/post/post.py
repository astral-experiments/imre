from test import test_typing
import sys
import types
import typing

ids = ['ParamSpec', 'ParamSpecArgs', 'ParamSpecKwargs', 'TypedDict', '_collect_type_parameters', '_should_unflatten_callable_args', 'get_args', 'get_origin', 'get_protocol_members', 'is_protocol', 'is_typeddict']
print('INITIAL_KEYS',repr(tuple((name, name in typing.__dict__) for name in ids)),flush=True)
def origin(item):
    name = getattr(item, '__module__', None)
    module = sys.modules.get(name)
    if module is not None:
        return module is typing
    if isinstance(item,types.FunctionType):
        return item.__globals__ is typing.__dict__
    return name == typing.__name__

def inspect_class(item, fullname, seen):
    key = id(item)
    if key in seen:
        return
    seen.add(key)
    try:
        d = item.__dict__
    except BaseException as ex:
        print('MISSING_CLASS_DICT',repr((fullname,getattr(item,'__module__',None),getattr(item,'__name__',None),type(ex).__name__,str(ex))),flush=True)
        return
    for attr,child in d.items():
        if isinstance(child,type) and origin(child):
            inspect_class(child, fullname+'.'+attr,seen)

seen = set()
for name,item in typing.__dict__.items():
    if isinstance(item,type) and origin(item):
        inspect_class(item,'typing.'+name,seen)
print('CLASSES_END',repr(len(seen)),flush=True)
