import sys
from typing import Generic, TypeVar, TypeVarTuple, ParamSpec, Unpack, get_args, get_origin, NoDefault

class Declared[*Items, **Signature]:
    pass


def classes():
    class Example[T, *Ts, **P]:
        def captured(self):
            return T, Ts, P

    return Example

one, two = classes(), classes()
t, ts, p = one.__type_params__
items, signature = Declared.__type_params__
assert type(items) is TypeVarTuple and type(signature) is ParamSpec
assert items is not ts and signature is not p
assert type(t) is TypeVar and type(ts) is TypeVarTuple and type(p) is ParamSpec
assert (t.__name__, ts.__name__, p.__name__) == ("T", "Ts", "P")
assert t.__infer_variance__ and p.__infer_variance__
assert p.__bound__ is None and p.evaluate_default is None
assert ts.evaluate_default is None and ts.__default__ is NoDefault
assert p.__default__ is NoDefault and not ts.has_default() and not p.has_default()
assert (t.__module__, ts.__module__, p.__module__) == ("typing", "typing", "typing")
assert one.__parameters__ == (t, ts, p) and one().captured() == (t, ts, p)
assert all(a is not b for a,b in zip(one.__type_params__,two.__type_params__))
alias, = one.__orig_bases__
assert get_origin(alias) is Generic
first, unpack, last = get_args(alias)
assert first is t and last is p
assert get_origin(unpack) is Unpack and get_args(unpack) == (ts,)
assert get_origin(p.args) is p and get_origin(p.kwargs) is p
assert TypeVarTuple("Manual").evaluate_default(1) is NoDefault
assert ParamSpec("Manual").evaluate_default(1) is NoDefault
if "inverted" in sys.argv:
    assert first is p
print("class metadata")
