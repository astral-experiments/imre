#!/bin/bash
set -eu
d=/workspace/scratch/class-variadic-control
bin=/workspace/scratch/static-target/debug/imre
runtime=/workspace/scratch/static-target/debug/libimre_runtime.a
clang=/workspace/scratch/intact/tools/usr/bin/clang-19
case "$1" in meta) src="$d/stage/metadata.py"; root="$d/stage";; original) src="$d/stage/entry.py"; root="$d/stage";; narrow) src="$d/public/oracle/control.py"; root="$d/public/oracle";; *) exit 2;; esac
tag="$d/public/$1-$2-O$3"
args=(build "$src" --module-root "$root" --opt-level "$3" --no-cache --runtime "$runtime" --clang "$clang" -o "$tag.exe")
if [[ $2 = boxed ]]; then args+=(--runtime-imports); fi
printf '%q ' "$bin" "${args[@]}" > "$tag.cmd"
rc=0
(cd "$root"; "$bin" "${args[@]}") >"$tag.build.stdout" 2>"$tag.build.stderr" || rc=$?
echo "$rc" > "$tag.build.exit"; echo "$tag build $rc"; tail -2 "$tag.build.stderr"
if ((rc==0)); then
    (cd "$root"; "$tag.exe") > "$tag.run.stdout" 2>"$tag.run.stderr" || rc=$?
    echo "$rc" > "$tag.run.exit"; echo "$tag run $rc"; cat "$tag.run.stdout"; tail -6 "$tag.run.stderr"
    if [[ $1 = meta ]]; then rc=0; (cd "$root"; "$tag.exe" metadata) > "$tag.meta.stdout" 2>"$tag.meta.stderr" || rc=$?; echo "$rc" > "$tag.meta.exit"; echo "$tag metadata $rc"; cat "$tag.meta.stdout"; tail -6 "$tag.meta.stderr"; fi
fi
