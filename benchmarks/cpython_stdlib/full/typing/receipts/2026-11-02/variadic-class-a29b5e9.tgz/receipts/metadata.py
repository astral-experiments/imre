import sys
from test.typinganndata import ann_module695 as m
from typing import Generic, TypeVar, TypeVarTuple, ParamSpec, Unpack, NoDefault, get_args, get_origin

print("IMPORTED", m.A.__name__, flush=True)
if "metadata" in sys.argv:
    t, pack, p = m.A.__type_params__
    assert type(t) is TypeVar and type(pack) is TypeVarTuple and type(p) is ParamSpec
    assert (t.__name__, pack.__name__, p.__name__) == ("T", "Ts", "P")
    assert (t.__module__, pack.__module__, p.__module__) == ("typing", "typing", "typing")
    assert m.A.__parameters__ == (t, pack, p)
    t2, pack2, p2 = m.B.__type_params__
    assert t is not t2 and pack is not pack2 and p is not p2
    assert m.B.T is int and m.B.Ts is str and m.B.P is bytes
    assert p.__infer_variance__ and p.__bound__ is None
    assert p.evaluate_default is None and pack.evaluate_default is None
    assert p.__default__ is NoDefault and pack.__default__ is NoDefault
    assert not p.has_default() and not pack.has_default()
    original, = m.A.__orig_bases__
    assert get_origin(original) is Generic
    first, extracted, last = get_args(original)
    assert first is t and last is p
    assert get_origin(extracted) is Unpack and get_args(extracted) == (pack,)
    assert get_origin(p.args) is p and get_origin(p.kwargs) is p
    print("metadata")
