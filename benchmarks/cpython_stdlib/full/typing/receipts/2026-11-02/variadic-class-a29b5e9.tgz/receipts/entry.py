from test.typinganndata import ann_module695
print("IMPORTED", ann_module695.A.__name__)
