/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14 -IB /workspace/scratch/class-variadic-control/public/oracle/control.py
/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14 -IB /workspace/scratch/class-variadic-control/public/oracle/control.py inverted
(cd /workspace/scratch/class-variadic-control/stage && /tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14 -B metadata.py metadata)
