import doctest
import sys
import typing
import unittest

import annassign_controls


class Events(unittest.TestResult):
    def startTest(self, case):
        print('START', case.id(), flush=True)
        super().startTest(case)

    def addSuccess(self, case):
        print('PASS', case.id(), flush=True)
        super().addSuccess(case)

    def addFailure(self, case, err):
        print('FAIL', case.id(), type(err[1]).__name__, repr(str(err[1])), flush=True)
        super().addFailure(case, err)

    def addError(self, case, err):
        print('ERROR', case.id(), type(err[1]).__name__, repr(str(err[1])), flush=True)
        super().addError(case, err)

    def addSkip(self, case, reason):
        print('SKIP', case.id(), repr(reason), flush=True)
        super().addSkip(case, reason)

    def addSubTest(self, case, child, err):
        outcome = 'PASS' if err is None else 'FAIL'
        print('SUBTEST', case.id(), child.id(), outcome, flush=True)
        super().addSubTest(case, child, err)

    def stopTest(self, case):
        print('STOP', case.id(), flush=True)
        super().stopTest(case)


def original():
    suite = doctest.DocTestSuite(typing)
    matches = [case for case in suite if case.id() == 'typing.TypedDict']
    assert len(matches) == 1
    case = matches[0]
    print('ORIGINAL', case.id(), 'EXAMPLES', len(case._dt_test.examples), flush=True)
    for example in case._dt_test.examples:
        print('EXAMPLE', example.lineno, repr(example.source), repr(example.want), flush=True)
    result = Events()
    case.run(result)
    print('RESULT', result.testsRun, len(result.failures), len(result.errors), len(result.skipped), flush=True)
    if not result.wasSuccessful():
        raise SystemExit(1)


if sys.argv[-1] == 'controls':
    annassign_controls.run_controls()
elif sys.argv[-1] == 'boundaries':
    annassign_controls.run_boundaries()
else:
    original()
