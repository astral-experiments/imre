from pathlib import Path
import hashlib, json, os, sys, tarfile

base=Path('/workspace/scratch/module-annassign-controls');q=base/'qualification';archive=Path(sys.argv[1]);head=sys.argv[2];baseline=q/'baseline'
files=[base/'stage'/'original_705.py',base/'stage'/'annassign_controls.py',base/'qualify_705.py',base/'pack_705.py',base/'bin/provenance.txt'];files.extend(p for p in baseline.iterdir() if p.is_file()); records=[]
for opt in (0,3):
    prefix=f'ordinary-O{opt}';lines=(baseline/(prefix+'.stdout')).read_text().splitlines()
    records.append({'subject':'previous native executable','imre':(baseline/'provenance.txt').read_text().splitlines()[1],'mode':prefix,'events':[line for line in lines if line.startswith(('START typing.TypedDict','FAIL typing.TypedDict','STOP typing.TypedDict','PASS typing.TypedDict','ERROR typing.TypedDict','SKIP typing.TypedDict'))], 'exit':int((baseline/(prefix+'.exit')).read_text())})
for mode in ('stock','ordinary0','ordinary3'):
    row=q/mode
    if not (row/'original.rc').exists(): continue
    files.extend(p for p in row.iterdir() if p.name != 'program' and p.is_file()); lines=(row/'original.stdout').read_text().splitlines()
    records.append({'subject':'pinned stock' if mode=='stock' else 'candidate','mode':mode,'events':[s for s in lines if s.startswith(('START ','STOP ','PASS ','FAIL ','ERROR ','SKIP ','SUBTEST '))], 'examples':[s for s in lines if s.startswith('EXAMPLE ')], 'original_rc':int((row/'original.rc').read_text()), 'original_stdout_equals_stock':(row/'original.stdout').read_bytes()==(q/'stock/original.stdout').read_bytes(),'controls_rc':int((row/'controls.rc').read_text()) if (row/'controls.rc').exists() else None,'boundaries_rc':int((row/'boundaries.rc').read_text()) if (row/'boundaries.rc').exists() else None, 'boundaries_stdout':(row/'boundaries.stdout').read_text() if (row/'boundaries.stdout').exists() else None, 'direct_stdout_matches_stock':(row/'controls.stdout').read_bytes()==(q/'stock/controls.stdout').read_bytes() if (row/'controls.rc').exists() else None})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); binaries={str(p):sha(p) for p in (base/'bin/imre',base/'bin/libimre_runtime.a') if p.exists()}; upstream=Path('/tmp/imre-stock/cpython/Lib'); metadata={'scope':'named original doctest, independent of historical and intact totals','hostname':os.uname().nodename,'id':'typing.TypedDict','ordinal':705,'stock_examples':4,'candidate':head,'candidate_binaries':binaries,'cpython':'5607950ef232dad16d75c0cf53101d9649d89115','upstream_file_sha256':{p.relative_to(upstream).as_posix():sha(p) for p in [upstream/'typing.py',upstream/'test/test_typing.py']},'records':records}; summary=q/'original_705.json';summary.write_text(json.dumps(metadata,indent=2)+'\n');files.append(summary)
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(files): tar.add(p,arcname=p.relative_to(base))
print(sha(archive),archive)
