from pathlib import Path
import os, shlex, subprocess, sys, time

root=Path('/workspace/scratch/module-annassign-controls')
stage=root/'stage'; driver=stage/'original_705.py'
mode=sys.argv[1];row=root/'qualification'/mode;row.mkdir(exist_ok=True)
stock=Path('/tmp/imre-stock/build/python');compiler=root/'bin/imre';library=root/'bin/libimre_runtime.a'
if mode=='stock':
    scenarios={'original':[str(stock),'-B',str(driver), 'original'],'controls':[str(stock),'-B',str(driver),'controls']}
else:
    opt=str(int(mode[-1]));exe=row/'program';scenarios={'build':[str(compiler),'build',str(driver),'--module-root',str(stage),'--no-cache','--clang','/workspace/scratch/intact/tools/usr/bin/clang-19','--runtime',str(library),'--opt-level',opt,'-o',str(exe)],'original':[str(exe),'original'],'controls':[str(exe),'controls']}
scenarios['boundaries'] = [str(stock), '-B', str(driver), 'boundaries'] if mode == 'stock' else [str(row/'program'), 'boundaries']
for name,args in scenarios.items():
    (row/f'{name}.argv').write_text(shlex.join(args)+'\n');(row/f'{name}.start').write_text(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())+'\n')
    with (row/f'{name}.stdout').open('wb') as stdout, (row/f'{name}.stderr').open('wb') as stderr:
        rc=subprocess.run(args,cwd=stage,stdout=stdout,stderr=stderr,env={**os.environ,'TMPDIR':str(root/'qualification')}).returncode
    (row/f'{name}.rc').write_text(str(rc)+'\n')
    if name=='build' and rc: break
