/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14 -IB /workspace/scratch/static/tests/fixtures/unpacking/class_base_display.py
