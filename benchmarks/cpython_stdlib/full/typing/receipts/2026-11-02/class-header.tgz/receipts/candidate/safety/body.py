class Child:
    fields = (*[1],)
