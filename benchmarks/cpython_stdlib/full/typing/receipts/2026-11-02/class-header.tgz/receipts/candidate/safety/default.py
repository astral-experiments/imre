def f(x: tuple[int] = (*(1,),)) -> int:
    return 0
