import collections.abc as abc
import sys
import types
import typing
import unittest


def actual():
    from test import test_typing
    from event_support import Events
    case = test_typing.CollectionsAbcTests('test_awaitable')
    result = unittest.TextTestRunner(verbosity=2, resultclass=Events).run(unittest.TestSuite([case]))
    print('RUNNER_COUNT',result.testsRun,'FAIL',len(result.failures),'ERROR',len(result.errors),'SKIP',len(result.skipped),flush=True)
    if not result.wasSuccessful():
        raise SystemExit(1)


class Structural:
    def __await__(self):
        yield 'paused'
        return 42


class Disabled:
    __await__ = None


async def make():
    return await Structural()


def detail(name, check):
    try:
        print('VALUE',name,repr(check()),flush=True)
    except BaseException as exc:
        print('ERROR',name,type(exc).__name__,str(exc),flush=True)


def controls():
    c=make()
    for name, check in (
        ('alias-origin',lambda: typing.get_origin(typing.Awaitable) is abc.Awaitable),
        ('coroutine-class-name',lambda: type(c).__name__),
        ('coroutine-class',lambda: type(c) is types.CoroutineType),
        ('coroutine-instance-await',lambda: hasattr(c,'__await__')),
        ('coroutine-class-await',lambda: hasattr(type(c),'__await__')),
        ('coroutine-instance-send',lambda: hasattr(c,'send')),
        ('coroutine-class-send',lambda: hasattr(type(c),'send')),
        ('instance-typing',lambda: isinstance(c,typing.Awaitable)),
        ('instance-abc',lambda: isinstance(c,abc.Awaitable)),
        ('coroutine-class-typing',lambda: issubclass(type(c),typing.Awaitable)),
        ('coroutine-class-abc',lambda: issubclass(type(c),abc.Awaitable)),
        ('coroutine-subclasshook',lambda: abc.Awaitable.__subclasshook__(type(c))),
        ('structural-class-typing',lambda: issubclass(Structural,typing.Awaitable)),
        ('structural-class-abc',lambda: issubclass(Structural,abc.Awaitable)),
        ('structural-instance',lambda: isinstance(Structural(),typing.Awaitable)),
        ('none-method-class',lambda: issubclass(Disabled,abc.Awaitable)),
        ('async-function-typing',lambda: isinstance(make,typing.Awaitable)),
        ('async-function-abc',lambda: isinstance(make,abc.Awaitable)),
    ):
        detail(name,check)
    try:
        iterator=c.__await__()
        print('ITER_SELF',iter(iterator) is iterator,flush=True)
        print('AWAIT_FIRST',repr(next(iterator)),flush=True)
        next(iterator)
    except StopIteration as done:
        print('AWAIT_DONE',repr(done.value),flush=True)
    except BaseException as exc:
        print('AWAIT_ERROR',type(exc).__name__,str(exc),flush=True)
    g=make()
    try:
        print('SEND_FIRST',repr(g.send(None)),flush=True)
        g.send(None)
    except StopIteration as done:
        print('SEND_DONE',repr(done.value),flush=True)
    except BaseException as exc:
        print('SEND_ERROR',type(exc).__name__,str(exc),flush=True)


if sys.argv[-1]=='controls':
    controls()
else:
    actual()
