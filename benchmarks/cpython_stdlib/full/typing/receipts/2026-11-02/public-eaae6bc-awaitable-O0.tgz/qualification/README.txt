Original 53 test.test_typing.CollectionsAbcTests.test_awaitable (occurrence 1), from the intact pinned test file. Stock and public eaae6bc ordinary O0 both produced START/PASS/STOP, exit 0 and no skips.
The older preliminary ordinary runtime on 10dd4e8 predates #4136; the boxed 935cf6d runtime and public eaae6bc both contain it. Coroutine and structural controls match pinned stock byte for byte.
No O3 result is present in this packet.
