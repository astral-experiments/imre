from pathlib import Path
from collections import Counter
import json,tarfile,hashlib
here=Path(__file__).resolve().parent
reg=json.loads((here/'19-key-delta.json').read_text())
rows=['ordinal\tid\toccurrence\tprofile\tparent_outcome\tpublic_tested_head\tproduct_squash\traw_callback_stream']
j=json.loads((here/'raw/reveal-type-original-485.json').read_text())
modes=['stock','ordinary-O0','ordinary-O3','boxed-O0','boxed-O3']
files={'c':'concatenate-all-71e902fc.tgz','p':'type-predicates-3ebdd019.tgz','d':'typing-doctest-params-f10db8a-four-cells.tgz'}
heads={'c':('71e902fcc51fd88f3aa2462d6a78cafae8eba74f','c72390b149c95b1f0be3cd19494fac134fcd7f1f'),'p':('3ebdd0192e13c63a4c6a981e497ce697706ef7b3','c7774039298d6d46db62ba33cbbd344af07fca6e'),'d':('f10db8ae3ec2319db1b7c2555ec6ce70685248c7','d2c653087e81cd51e948523e87e4548f6455a3c7'),'r':(j['imre_revision'],'fe7af98cf2bd7c9cb6d6385bf7aac07971c0d5f7')}
for item in reg['details']:
    name=item['id']; ordinal=item['stock_ordinal']
    group='c' if 123<=ordinal<=127 else 'r' if ordinal==485 else 'p' if 515<=ordinal<=524 else 'd'
    for idx,mode in enumerate(modes):
        if group=='r':
            obs=j['observations'][idx]
            assert obs['mode']+('-O'+obs['level'] if obs['level'] else '')==mode and obs['run']['returncode']==0
            stdout=obs['run']['stdout']; ref=f'raw/reveal-type-original-485.json#observations[{idx}].run.stdout'
        else:
            if group=='c':
                path='receipts/'+['stockref','ordinary0','ordinary3','boxed0','boxed3'][idx]+'/run.stdout'
            elif group=='p':
                path='merge-receipt/'+('stock/stock.stdout' if not idx else mode.split('-')[0]+'/'+mode+'.stdout')
            else:
                path=('stock-param-hook' if not idx else 'f10db8a-param_hook-'+mode)+'/stdout'
            with tarfile.open(here/'raw'/files[group]) as t:
                stdout=t.extractfile(path).read().decode()
            ref='raw/'+files[group]+'!/'+path
        lines=stdout.splitlines()
        assert lines.count('START '+name)==lines.count('PASS '+name)==1,(mode,name)
        rows.append('\t'.join(map(str,(ordinal,name,item['occurrence'],mode,'PASS',heads[group][0] if idx else '',heads[group][1],ref))))
assert len(rows)==96 and len(reg['additional_keys'])==19
(here/'case-outcomes.tsv').write_text('\n'.join(rows)+'\n')
events=[json.loads(s) for s in (here/'stock/events.jsonl').read_text().splitlines()]
print('95 original parent observations verified; stock events:',Counter(x.get('event',x.get('phase','')) for x in events))
