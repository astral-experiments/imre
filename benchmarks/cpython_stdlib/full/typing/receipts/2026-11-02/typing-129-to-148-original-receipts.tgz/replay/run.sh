#!/bin/bash
set -u
root=$(cd "$(dirname "$0")" && pwd)
cd "$root/stage"
mode=$1
out=$root/$mode
if [[ $mode == stock ]]; then
  command=(/tmp/imre-stock/build/python -B -m named19)
else
  opt=${mode##*O}
  until [[ -s "$root/provenance" ]]; do sleep 3; done
  export IMREFLAGS="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $root/bin/libimre_runtime.a --opt-level $opt"
  command=("$root/bin/imre" -B -m named19)
fi
{ printf 'cd %q\n' "$PWD"; if [[ $mode != stock ]]; then printf 'export IMREFLAGS=%q\n' "$IMREFLAGS"; fi; printf '%q ' "${command[@]}"; printf '\n'; } > "$out/cmd"
"${command[@]}" > "$out/events.jsonl" 2>"$out/stderr"; rc=$?
echo "$rc" > "$out/exit"
tail -5 "$out/events.jsonl"; tail -5 "$out/stderr"
exit "$rc"
