import doctest
import json
import sys
import typing
import unittest


def output(row):
    print(json.dumps(row, sort_keys=True), flush=True)


# Capture real DocTestCase objects before importing the full upstream module.
# The public typing module materializes additional class bindings during that import.
assert "test.test_typing" not in sys.modules
docs = list(doctest.DocTestSuite(typing))
doc_ids = ("typing.ParamSpec", "typing.ParamSpecArgs", "typing.ParamSpecKwargs")
selected_docs = [case for case in docs if case.id() in doc_ids]
output({"phase": "doctest_discovery", "ids": [case.id() for case in docs]})
assert [case.id() for case in selected_docs] == list(doc_ids)

from test import test_typing

output({"phase": "full_module_import", "module": test_typing.__name__})
classes = (test_typing.ConcatenateTests, test_typing.RevealTypeTests,
           test_typing.TypeGuardTests, test_typing.TypeIsTests)
suite = unittest.TestSuite()
for cls in classes:
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
suite.addTests(selected_docs)
ordered = [case.id() for case in suite]
output({"phase": "selected", "ids": ordered})
assert len(ordered) == len(set(ordered)) == 19

sequence = 0
occurrences = {}


def event(kind, case, subtest=None, error=None, reason=None):
    global sequence
    sequence += 1
    identifier = case.id()
    if kind == "START":
        occurrences[identifier] = occurrences.get(identifier, 0) + 1
    row = {"sequence": sequence, "event": kind, "id": identifier,
           "occurrence": occurrences.get(identifier, 0)}
    if subtest is not None:
        child = subtest.id()
        occurrences[child] = occurrences.get(child, 0) + 1
        row["subtest_id"] = child
        row["subtest_occurrence"] = occurrences[child]
    if error is not None:
        row["error_type"] = error[0].__name__
        row["error_text"] = str(error[1])
    if reason is not None:
        row["reason"] = reason
    output(row)


class Events(unittest.TextTestResult):
    def startTest(self, case):
        event("START", case)
        super().startTest(case)

    def stopTest(self, case):
        event("STOP", case)
        super().stopTest(case)

    def addSuccess(self, case):
        event("PASS", case)
        super().addSuccess(case)

    def addFailure(self, case, error):
        event("FAIL", case, error=error)
        super().addFailure(case, error)

    def addError(self, case, error):
        event("ERROR", case, error=error)
        super().addError(case, error)

    def addSkip(self, case, reason):
        parent = getattr(case, "test_case", None)
        if parent is None:
            event("SKIP", case, reason=reason)
        else:
            event("SUBTEST_SKIP", parent, subtest=case, reason=reason)
        super().addSkip(case, reason)

    def addExpectedFailure(self, case, error):
        event("EXPECTED_FAILURE", case, error=error)
        super().addExpectedFailure(case, error)

    def addUnexpectedSuccess(self, case):
        event("UNEXPECTED_SUCCESS", case)
        super().addUnexpectedSuccess(case)

    def addSubTest(self, case, subtest, error):
        if error is None:
            kind = "SUBTEST_PASS"
        elif issubclass(error[0], case.failureException):
            kind = "SUBTEST_FAIL"
        else:
            kind = "SUBTEST_ERROR"
        event(kind, case, subtest=subtest, error=error)
        super().addSubTest(case, subtest, error)


result = unittest.TextTestRunner(verbosity=2, descriptions=False, resultclass=Events).run(suite)
output({"phase": "runner", "tests_run": result.testsRun, "successful": result.wasSuccessful()})
sys.exit(0 if result.wasSuccessful() and result.testsRun == 19 else 1)
