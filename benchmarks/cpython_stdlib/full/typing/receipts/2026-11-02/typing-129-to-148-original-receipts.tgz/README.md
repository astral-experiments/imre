# Original receipts for the nineteen additions from 129 to 148

The 19 ID/occurrence keys have 95 verified parent passes across stock, ordinary O0/O3 and boxed O0/O3. Every occurrence is 1. The coordinator's separate 14 and all subsequent worker results are outside this capsule. Stock passed all 19 with zero skips. The stock stream includes 19 START, 19 PASS, 19 STOP and three passing subtest callbacks in ConcatenateTests.test_dir.

The case-outcomes table identifies exact tested source heads, their public squash commits, and original callback streams. Each raw archive includes the actual staged runner, command lines, build and process records, and available binary digests. Raw reveal observations and staged source are fields in its JSON. The full pinned CPython source is in source/. The new live observer and verified upstream input manifest are in replay/. Native binaries remain on the Ruff Linux VM.

Parent outcomes on the listed heads are final. Their native named observers recorded START and PASS, but did not instrument stopTest and addSubTest. Those native lifecycle fields are unobserved in this preliminary export. No stop or child outcome has been inferred from a pass or successful exit. The separate instrumented stock replay is final. A matching public native 2dc9357e replay is in progress. Its named lifecycle receipts will follow. The existing intact runs use independent observers; they did not produce native XML for these 19 passes.

Upstream CPython pin: 5607950ef232dad16d75c0cf53101d9649d89115. The 148-key ledger has SHA-256 4d6bc22161270c2bec2a3ce7b271274da34e4bea937b7e0db3cabf4cf7d90df8. The supplied 129-key inventory has SHA-256 35f09b0b99e51bfac53fa2e99d5ca18f6b6599af517d8fcfd67d47619701d78a.
