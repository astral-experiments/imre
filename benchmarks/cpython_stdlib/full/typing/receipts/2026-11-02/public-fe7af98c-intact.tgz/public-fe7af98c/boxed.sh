set -eu
root=/workspace/scratch/intact
bin=/workspace/scratch/public-fe7af98c
level="${1:?optimization level}"
log="$root/logs/public-fe7af98c/boxed-O$level"
cd "$root/baseline-stage"
args=(build discover.py --module-root "$root/baseline-stage" --runtime-imports --no-cache --opt-level "$level" --runtime "$bin/libimre_runtime.a" --clang "$root/tools/usr/bin/clang-19" -o "$log.exe")
printf '%q ' "$bin/imre" "${args[@]}" > "$log.cmd"; printf '\n' >> "$log.cmd"
sha256sum test/test_typing.py > "$log.file.sha256"
set +e
timeout 2100 "$bin/imre" "${args[@]}" > "$log.build.stdout" 2> "$log.build.stderr"
rc=$?
printf '%s\n' "$rc" > "$log.build.exit"
if test "$rc" = 0; then
    sha256sum "$log.exe" > "$log.exe.sha256"
    timeout 900 "$log.exe" > "$log.run.stdout" 2> "$log.run.stderr"; rc=$?
    printf '%s\n' "$rc" > "$log.run.exit"
    echo "boxed O$level run $rc"
    tail -10 "$log.run.stderr"
else
    echo "boxed O$level build $rc"
    tail -8 "$log.build.stderr"
fi
