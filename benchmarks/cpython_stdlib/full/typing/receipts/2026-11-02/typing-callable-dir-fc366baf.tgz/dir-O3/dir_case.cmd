cwd=/workspace/scratch/callable-alias-study/stage
IMREFLAGS=--no-cache\ --clang\ /workspace/scratch/intact/tools/usr/bin/clang-19\ --runtime\ /workspace/scratch/callable-alias-study/dir.a\ --opt-level\ 3
/workspace/scratch/public-eaae6bc-bin/imre -B -m dir_case 
