#!/bin/bash
set -u
root=$(cd "$(dirname "$0")" && pwd)
cd "$root/stage"
label=$1; module=$2
out="$root/$label/$module"
mkdir -p "$root/$label"
if [[ "$label" == stock ]]; then command=(/tmp/imre-stock/build/python -B -m "$module"); else
  bin=$3; lib=$4; opt=$5
  export IMREFLAGS="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $lib --opt-level $opt"
  command=("$bin" -B -m "$module")
fi
printf 'cwd=%s\nIMREFLAGS=%q\n' "$PWD" "${IMREFLAGS-}" > "$out.cmd"
printf '%q ' "${command[@]}" >> "$out.cmd"; printf '\n' >> "$out.cmd"
"${command[@]}" >"$out.stdout" 2>"$out.stderr"; rc=$?; echo "$rc" > "$out.exit"; tail -n 2 "$out.stdout"
