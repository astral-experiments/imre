cwd=/workspace/scratch/callable-alias-study/stage
IMREFLAGS=--no-cache\ --clang\ /workspace/scratch/intact/tools/usr/bin/clang-19\ --runtime\ /workspace/scratch/public-eaae6bc-bin/libimre_runtime.a\ --opt-level\ 0
/workspace/scratch/public-eaae6bc-bin/imre -B -m original 
