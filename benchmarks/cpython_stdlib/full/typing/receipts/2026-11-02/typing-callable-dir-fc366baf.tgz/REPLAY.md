# Named collections.abc.Callable constructor controls

The observer in `stage/qualified.py` imports the intact upstream module, asks the normal loader for CollectionsCallableTests, and runs three unmodified case objects in loader order. These 3 named outcomes are independent of whole-module discovery and historical totals.

## Stage CPython

Check out CPython commit 5607950ef232dad16d75c0cf53101d9649d89115 and build its interpreter. Copy each file in pinned-files.sha256 from the upstream Lib directory to the same relative path under stage, alongside the observer. Validate the staged Python files with `(cd stage && sha256sum -c ../pinned-files.sha256)`. The intact test/test_typing.py digest is 28d17772f523800f02a5bf1e0cc012779d7df1f616fec7cc34d922dcba7ee1cc.

## Run

From stage run the CPython interpreter with `-B -m qualified`, and then run the public Imre executable with `-B -m qualified`. Set IMREFLAGS to `--no-cache --clang /path/to/clang-19 --runtime /path/to/libimre_runtime.a --opt-level 0` for ordinary O0, or change the optimization level to 3 for ordinary O3. The .cmd files record the actual working directory, flags and executable. The .exit files contain the true process exit code. The native invocations are ordinary module execution. The candidate mixes the sealed public eaae6bc compiler with the separately compiled fdf04234 runtime. See clean-runtime-provenance-verified.txt for distinct source trees and the locked runtime build command.

Original stock IDs are #102 test_basic, #107 test_cannot_instantiate, #119 test_type_erasure. The separate `stage/original.py` observer includes #109 test_dir in place of #119 and records the independent public directory failure. `stage/aliases.py` inspects native alias types and constructors. `stage/strict.py` runs the actual candidate fixture with its final entrypoint. It covers nominal relationships, concrete subclass origin and orig_class, invalid forms, and identity of the original non-flattened parameter-expression tuples.
