from collections.abc import Callable
from types import GenericAlias

class Meta(type):
    def __dir__(cls):
        return ["z", "__args__", "__args__", "a"]

class Origin(metaclass=Meta):
    pass

class Failing(type):
    def __dir__(cls):
        raise LookupError("dir from origin")

class Broken(metaclass=Failing):
    pass

alias = GenericAlias(Origin, (int,))
print("CUSTOM", repr(dir(alias)), flush=True)
for alias in (Callable[..., int], list[int]):
    names = dir(alias)
    print("LOCAL", alias, tuple(key for key in (
        "__class__", "__origin__", "__args__", "__unpacked__", "__parameters__",
        "__typing_unpacked_tuple_args__", "__mro_entries__", "__reduce_ex__", "__reduce__"
    ) if key in names), flush=True)

try:
    dir(GenericAlias(Broken, ()))
except LookupError as e:
    print("ORIGIN_ERROR", type(e).__name__, str(e), flush=True)
else:
    raise AssertionError("missing origin dir error")
