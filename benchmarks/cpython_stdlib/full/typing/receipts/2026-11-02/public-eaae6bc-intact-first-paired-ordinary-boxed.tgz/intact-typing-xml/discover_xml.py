"""Observe original case and subtest callbacks, retaining exact skip reasons."""
import sys
import unittest
from test import test_typing

# One complete XML element is flushed per real callback, so partial executions
# retain the observed prefix. Control characters outside XML 1.0 are reversible.
def field(tag, text):
    codec = ''
    if not all(c in '\t\n\r' or 0x20 <= ord(c) <= 0xd7ff or 0xe000 <= ord(c) <= 0xfffd or 0x10000 <= ord(c) <= 0x10ffff for c in text):
        text = ascii(text)
        codec = ' encoding="python-ascii"'
    escaped = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('\r', '&#13;')
    return '<' + tag + codec + '>' + escaped + '</' + tag + '>'

def event(kind, case, subject='', detail=''):
    case_id = case.id()
    print('TYPING_EVENT', repr((kind, case_id, subject, detail)), flush=True)
    content = field('case', case_id)
    if subject:
        content += field('subtest', subject)
    if isinstance(detail, tuple):
        content += field('exception', detail[0]) + field('message', detail[1])
    elif detail or kind in ('SKIP', 'SUBTEST_SKIP'):
        content += field('reason', detail)
    # 'kind' is one of the callback constants in Events, never user data.
    stream.write('<event kind="' + kind + '">' + content + '</event>\n')
    stream.flush()

class Events(unittest.TextTestResult):
    def startTest(self, case):
        self.active_case = case
        event('START', case)
        super().startTest(case)

    def stopTest(self, case):
        event('STOP', case)
        self.active_case = None
        super().stopTest(case)

    def addSuccess(self, case):
        event('PASS', case)
        super().addSuccess(case)

    def addFailure(self, case, error):
        event('FAIL', case, '', (error[0].__name__, str(error[1])))
        super().addFailure(case, error)

    def addError(self, case, error):
        event('ERROR', case, '', (error[0].__name__, str(error[1])))
        super().addError(case, error)

    def addSkip(self, case, reason):
        parent = getattr(case, 'test_case', None)
        if parent is not None and parent is getattr(self, 'active_case', None) and parent is not case:
            event('SUBTEST_SKIP', parent, case.id(), reason)
        else:
            event('SKIP', case, '', reason)
        super().addSkip(case, reason)

    def addExpectedFailure(self, case, error):
        event('EXPECTED_FAILURE', case, '', (error[0].__name__, str(error[1])))
        super().addExpectedFailure(case, error)

    def addUnexpectedSuccess(self, case):
        event('UNEXPECTED_SUCCESS', case)
        super().addUnexpectedSuccess(case)

    def addSubTest(self, case, subtest, error):
        if error is None:
            event('SUBTEST_PASS', case, subtest.id())
        elif issubclass(error[0], case.failureException):
            event('SUBTEST_FAIL', case, subtest.id(), (error[0].__name__, str(error[1])))
        else:
            event('SUBTEST_ERROR', case, subtest.id(), (error[0].__name__, str(error[1])))
        super().addSubTest(case, subtest, error)

if __name__ == '__main__':
    stream = open(sys.argv[1], 'w', encoding='utf-8')
    stream.write('<?xml version="1.0" encoding="UTF-8"?>\n<unittest-events>\n')
    stream.flush()
    try:
        print('IMPORT_OK test.test_typing', flush=True)
        print('LOAD_BEGIN test.test_typing', flush=True)
        suite = unittest.defaultTestLoader.loadTestsFromModule(test_typing)
        print('LOAD_DONE test.test_typing', flush=True)
        print('REGISTERED_COUNT', suite.countTestCases(), flush=True)
        result = unittest.TextTestRunner(verbosity=2, descriptions=False, resultclass=Events).run(suite)
        print('RUNNER_COUNT', result.testsRun, flush=True)
    finally:
        stream.write('</unittest-events>\n')
        stream.close()
    sys.exit(0 if result.wasSuccessful() else 1)
