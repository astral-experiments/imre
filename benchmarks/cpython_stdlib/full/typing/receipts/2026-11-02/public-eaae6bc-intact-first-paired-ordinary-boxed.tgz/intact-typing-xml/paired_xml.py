"""Pair complete original parent lifecycles and child outcomes from native XML."""
import collections
import csv
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

snapshot = Path(sys.argv[1]) if len(sys.argv) > 1 else None
here = snapshot or Path(__file__).resolve().parent / "xml-logs"
ledger = here/"comparison-ledger-181.json" if snapshot else Path("/workspace/shared/downloads/ledger-typing-intact-worker-181.json")
known = {tuple(x) for x in json.loads(ledger.read_text())["keys"]}
ordinals = {}
occurrences = collections.Counter()
with (here / "stock-ordinals.tsv").open() as source:
    for row in csv.DictReader(source, delimiter="\t"):
        name = row["id"]
        occurrences[name] += 1
        ordinals[name, occurrences[name]] = int(row["ordinal"])

def observe(stem):
    if snapshot and stem != "stock":
        cell = here / stem.removeprefix("public-").removeprefix("eaae6bc-")
        file, ex = cell/"xml", cell/"exit"
    else:
        file, ex = here/(stem + ".xml"), here/(stem + ".exit")
    raw = file.read_bytes() if file.exists() else b""
    complete = raw.rstrip().endswith(b"</unittest-events>")
    end = raw.rfind(b"</event>")
    if complete:
        events = ET.fromstring(raw)
    elif end >= 0:
        events = ET.fromstring(raw[:end + len(b"</event>")] + b"</unittest-events>")
    else:
        events = ()
    keys = collections.Counter()
    cases = collections.defaultdict(list)
    skip_reasons = collections.Counter()
    kinds = collections.Counter()
    other = 0
    for event in events:
        name = event.findtext("case")
        kind = event.attrib["kind"]
        if kind == "START":
            keys[name] += 1
        key = (name, keys[name])
        if key not in ordinals:
            other += 1
            continue
        kinds[kind] += 1
        fields = tuple((node.tag, node.text or "", tuple(sorted(node.attrib.items())))
                       for node in event if node.tag != "case")
        cases[key].append((kind, fields))
        if kind in {"SKIP", "SUBTEST_SKIP"}:
            skip_reasons[(kind, event.findtext("reason") or "")] += 1
    return cases, {
        "xml_present": file.exists(), "xml_closed": complete,
        "exit": int(ex.read_text()) if ex.exists() else None,
        "raw_sha256": hashlib.sha256(raw).hexdigest() if file.exists() else None,
        "original_callbacks": kinds, "other_callbacks": other,
        "skip_reasons": [[kind, reason, count] for (kind, reason), count in sorted(skip_reasons.items())],
    }

stock, stock_status = observe("stock")
assert len(ordinals) == len(stock) == 712 and stock_status["exit"] == 0
assert all([kind for kind, _ in events if not kind.startswith("SUBTEST_")] == ["START", "PASS", "STOP"]
           for events in stock.values())
result = {"public": "eaae6bc48b63c29a2d441d3279a4c59051c91fb2", "stock": stock_status, "profiles": {}}
for mode, prefix in [("ordinary", "public-eaae6bc-ordinary"), ("boxed", "eaae6bc-boxed")]:
    observations = [observe(prefix + level) for level in ["-O0", "-O3"]]
    keys = [key for key in sorted(ordinals, key=ordinals.get)
            if all(cases.get(key) == stock[key] for cases, _ in observations)]
    result["profiles"][mode] = {
        "O0": observations[0][1], "O3": observations[1][1],
        "stock_identical_complete_pairs": len(keys), "keys": keys,
        "additional_to_named_181": [key for key in keys if key not in known],
    }
print(json.dumps(result, indent=2, ensure_ascii=True))
