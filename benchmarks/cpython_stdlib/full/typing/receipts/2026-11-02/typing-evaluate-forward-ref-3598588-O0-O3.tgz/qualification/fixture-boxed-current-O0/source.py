import sys
sys.path = ['/workspace/scratch/evaluate-forward-final/qualification/fixture-boxed-current-O0/plugin'] + sys.path
import arithmetic
arithmetic.current()
