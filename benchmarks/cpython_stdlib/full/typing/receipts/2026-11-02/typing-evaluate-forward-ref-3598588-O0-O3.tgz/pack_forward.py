"""Collect completed original-case lifecycles and preserve actual aggregate exits."""
import ast, collections, hashlib, io, json, sys, tarfile
from pathlib import Path

root=Path(__file__).resolve().parent; q=root/'qualification'; stage=root/'stage'; stocklib=Path('/tmp/imre-stock/cpython/Lib'); pin='5607950ef232dad16d75c0cf53101d9649d89115'
archive=Path(sys.argv[1]); modes=sys.argv[2:]; assert modes and modes[0]=='stock'
stock_order=Path('/tmp/imre-stock/stock-pinned.jsonl');reference=[json.loads(x) for x in stock_order.read_text().splitlines()];ref={row['id']:(n,row) for n,row in enumerate(reference,1) if row['id'].startswith('test.test_typing.EvaluateForwardRefTests.')};assert len(ref)==9 and [v[0] for v in ref.values()]==list(range(131,140));digest=lambda s:hashlib.sha256(s).hexdigest()
files={};summary={};manifest={};head=(root/'bin/provenance.txt').read_text().splitlines()[1];parent=(root/'bin/provenance.txt').read_text().splitlines()[2]
for p in sorted(stage.rglob('*.py')):
 value=p.read_bytes();name=p.relative_to(root).as_posix();files[name]=value
 if p.is_relative_to(stage/'test'):
  fixture=stocklib/p.relative_to(stage);assert value==fixture.read_bytes(),name
  manifest[name]={'sha256':digest(value),'pin':pin,'upstream':'Lib/'+p.relative_to(stage).as_posix()}
 else:manifest[name]={'sha256':digest(value),'scope':'observer or direct controls'}
for name in ['run.sh','pack_forward.py','bin/provenance.txt','bin/build.log','stock_review_controls.py','stock-review-controls.stdout','stock-review-controls.stderr']:
 files[name]=(root/name).read_bytes()
for directory in ('preflight','direct-build-O0'):
 for p in (q/directory).glob('*'):
  if p.is_file() and (p.suffix in ('.stdout','.stderr','.cmd','.rc','.start','.py') or p.name=='inputs'):files[p.relative_to(root).as_posix()]=p.read_bytes()
for mode in modes:
 stock=mode.startswith('stock');folder=q if stock else q/mode.removesuffix('-originals');prefix='stock-' if stock else '';record={}
 for scenario in ('combined',):
  s=prefix+scenario
  for ext in ('.stdout','.stderr','.rc','.cmd','.start'):
   f=folder/(s+ext)
   if f.exists():files[f.relative_to(root).as_posix()]=f.read_bytes()
  out=(folder/(s+'.stdout')).read_text();err=(folder/(s+'.stderr')).read_text();rc=int((folder/(s+'.rc')).read_text());rec={'process_exit':rc,'stdout_sha256':digest(out.encode()),'stderr_sha256':digest(err.encode())};record[scenario]=rec
  if scenario=='controls':
   rec['stdout_matches_stock']=out==(q/'stock-controls.stdout').read_text();continue
  if scenario=='combined':
   rec['originals_section_end']=next((v for v in out.splitlines() if v.startswith('ORIGINALS_END ')),None)
   rec['controls_section_completed']='CONTROLS_END' in out.splitlines()
   stockout=(q/'stock-combined.stdout').read_text().splitlines()
   def section(input_lines,begin,end):
    return input_lines[input_lines.index(begin)+1:input_lines.index(end)] if begin in input_lines and end in input_lines else None
   rows=out.splitlines()
   rec['controls']=section(rows,'CONTROLS_BEGIN','CONTROLS_END')
   rec['controls_stdout_matches_stock']=rec['controls']==section(stockout,'CONTROLS_BEGIN','CONTROLS_END')
   rec['boundaries']=section(rows,'BOUNDARIES_BEGIN','BOUNDARIES_END')
   rec['boundaries_stdout_matches_stock']=rec['boundaries']==section(stockout,'BOUNDARIES_BEGIN','BOUNDARIES_END')
   rec['scope']='One process exit for original callbacks and direct controls. Sections have no independent operating-system exits.'
  events=[list(ast.literal_eval(s[len('TYPING_EVENT '):])) for s in out.splitlines() if s.startswith('TYPING_EVENT ')]
  by_case={key:[] for key in ref}
  for event in events:
   assert event[1] in by_case,event;by_case[event[1]].append(event)
  results=[]
  for identifier,case_events in by_case.items():
   kinds=[ev[0] for ev in case_events];outcomes=[ev for ev in case_events if ev[0] in ('PASS','SKIP','FAIL','ERROR','EXPECTED_FAILURE','UNEXPECTED_SUCCESS')];assert len(outcomes)<=1
   results.append({'ordinal':ref[identifier][0],'id':identifier,'occurrence':1,'upstream_stock':ref[identifier][1], 'start_observed':'START' in kinds,'stop_observed':'STOP' in kinds,'status':outcomes[0][0] if outcomes else ('started_without_terminal_outcome' if kinds else 'not_observed'),'detail':outcomes[0][3] if outcomes else None,'skip_reason':outcomes[0][3] if outcomes and outcomes[0][0]=='SKIP' else None,'children':[e for e in case_events if e[0].startswith('SUBTEST_')]})
  rec['outcomes']=results;rec['event_counts']=dict(collections.Counter(ev[0] for ev in events));rec['complete_passing_parents']=sum(r['status']=='PASS' and r['start_observed'] and r['stop_observed'] for r in results)
  if stock:assert rc==0 and rec['event_counts']=={'START':9,'PASS':9,'STOP':9}
  if rc==0:assert 'RUNNER_COUNT 9' in out and all(r['stop_observed'] for r in results)
 if (folder/'inputs').is_file():files[(folder/'inputs').relative_to(root).as_posix()]=(folder/'inputs').read_bytes()
 direct=q if stock else q/('edge-'+mode);suffix='stock-direct' if stock else 'direct'
 if (direct/(suffix+'.rc')).exists():
  for ext in ('.stdout','.stderr','.rc','.cmd','.start'):
   f=direct/(suffix+ext)
   if f.exists():files[f.relative_to(root).as_posix()]=f.read_bytes()
  rd=(direct/(suffix+'.stdout')).read_text()
  record['edge_direct']={'process_exit':int((direct/(suffix+'.rc')).read_text()),'stdout':rd.splitlines(),'scope':'Independent direct probe, separate process.'}
 summary[mode]=record
if 'ordinary-O3' in modes:
 fixture=q/'fixture-boxed-current-O0'
 for n in ('source.py','plugin/arithmetic.py','inputs','stock.stdout','stock.stderr','stock.rc','callback.stdout','callback.stderr','callback.rc'):
  f=fixture/n
  if f.exists():files[f.relative_to(root).as_posix()]=f.read_bytes()
 if (fixture/'callback.rc').exists():
  summary['late_import_fixture']={'callback':{'process_exit':int((fixture/'callback.rc').read_text()),'stock_process_exit':int((fixture/'stock.rc').read_text()),'stdout_matches_stock':(fixture/'callback.stdout').read_bytes()==(fixture/'stock.stdout').read_bytes(),'stderr_matches_stock':(fixture/'callback.stderr').read_bytes()==(fixture/'stock.stderr').read_bytes(),'scope':'Final ordinary O0 late-imported fixture assertions, separate from nine original cases.'}}
module=stage/'test/test_typing.py'; allbytes=module.read_bytes();sourcelines=allbytes.splitlines(keepends=True);classdef=next(n for n in ast.parse(allbytes).body if isinstance(n,ast.ClassDef) and n.name=='EvaluateForwardRefTests');source={}
for fn in classdef.body:
 key='test.test_typing.EvaluateForwardRefTests.'+getattr(fn,'name','');
 if key in ref:source[key]={'lines':[fn.lineno,fn.end_lineno],'sha256':digest(b''.join(sourcelines[fn.lineno-1:fn.end_lineno]))}
metadata={'scope':'Original cases selected from the intact pinned test module. Direct preflight and controls are separate; unobserved outcomes receive no credit.','upstream':pin,'tested_head':head,'compiler_parent':parent,'runtime_provenance':(Path('/workspace/scratch/evaluate-forward-controls/bin/runtime-provenance.txt')).read_text().splitlines(),'module_sha256':digest(allbytes),'stock_order_sha256':digest(stock_order.read_bytes()),'source':source,'stage_sha256':manifest,'modes':summary,'upstream_ledger_rows':[dict(ordinal=num,**row) for num,row in ref.values()]};files['summary.json']=(json.dumps(metadata,indent=2)+'\n').encode();files['source-LICENSE']=(stocklib.parent/'LICENSE').read_bytes();files['MANIFEST.sha256']=''.join(f'{digest(data)}  {name}\n' for name,data in sorted(files.items())).encode()
with tarfile.open(archive,'w:gz') as dest:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;dest.addfile(info,io.BytesIO(data))
assert head=='35985888a4a73a3867cd20a2eeab31c2a1b5cc58'
print(head,digest(archive.read_bytes()),archive,{m:{k:(r['process_exit'],r.get('complete_passing_parents')) for k,r in s.items()} for m,s in summary.items()})
