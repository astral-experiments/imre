try:
    from test.typinganndata import ann_module
except BaseException as error:
    print("FULL", type(error).__name__,str(error),flush=True)
else:
    print("FULL",type(ann_module.S) is ann_module.Meta,ann_module.S.__annotations__,flush=True)
from test.typinganndata import exact
