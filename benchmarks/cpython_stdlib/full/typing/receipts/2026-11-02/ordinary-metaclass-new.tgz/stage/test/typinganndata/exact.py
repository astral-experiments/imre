





































class Meta(type):
    def __new__(meta, name, bases, namespace):
        return super().__new__(meta, name, bases, namespace)

class S(metaclass = Meta):
    x: str = 'something'
    y: str = 'something else'

assert type(S) is Meta
assert S.__annotations__ == {"x": str, "y": str}
assert (S.x, S.y) == ("something", "something else")
print("meta namespace and class annotations")
