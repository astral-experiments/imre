from test.typinganndata import ann_module
from typing import get_type_hints
assert type(ann_module.S) is ann_module.Meta
assert get_type_hints(ann_module.S) == {"x": str, "y": str}
print("UNCHANGED ann_module.S",flush=True)
import meta_checks
print("MUTATION IDENTITY EXCEPTIONS ANNOTATIONS PASS",flush=True)
import specials
print("ABC TYPEDDICT ENUM PASS",flush=True)
