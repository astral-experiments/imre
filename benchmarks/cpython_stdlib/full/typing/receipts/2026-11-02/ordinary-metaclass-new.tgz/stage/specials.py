from abc import ABCMeta, abstractmethod
from enum import Enum
from typing import TypedDict

class CustomABC(ABCMeta):
    def __new__(meta, name, bases, namespace):
        namespace['called'] = name
        return super().__new__(meta, name, bases, namespace)
class Abstract(metaclass=CustomABC):
    @abstractmethod
    def run(self):
        pass

assert Abstract.called == 'Abstract' and '__abstractmethods__' in Abstract.__dict__
try:
    Abstract()
except TypeError:
    pass
else:
    raise AssertionError("abstract class constructed")

class Point(TypedDict):
    x: int
assert Point(x=4) == {'x': 4} and Point.__required_keys__ == frozenset({'x'})

class Color(Enum):
    RED = 1
assert Color(1) is Color.RED
