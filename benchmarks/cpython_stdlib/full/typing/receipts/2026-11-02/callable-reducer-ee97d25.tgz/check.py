import collections.abc
import typing
from typing import Callable, Concatenate, ParamSpec, _should_unflatten_callable_args

P = ParamSpec("P")
for origin in (Callable, collections.abc.Callable):
    for args, expected in (([int, str], True), ([int], True), ([], True), (P, False), (..., False), (Concatenate[str, P], False)):
        alias = origin[args, bytes]
        assert _should_unflatten_callable_args(alias, alias.__args__) is expected
assert _should_unflatten_callable_args(list[int], (int,)) is False
assert typing._should_unflatten_callable_args is _should_unflatten_callable_args
assert ">>> P = ParamSpec('P')" in _should_unflatten_callable_args.__doc__
import roundtrip
import boxed_typing_concatenate
print("completed callable controls")
