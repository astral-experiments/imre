import sys
from typing import Callable, Concatenate, ParamSpec

P = ParamSpec("P")
spec = Concatenate[int, P]
for params, payload in ((spec, spec), (P, P), (..., ...), ([int, str], [int, str])):
    original = Callable[params, bytes]
    rebuild, args = original.__reduce__()
    assert args == (Callable, (payload, bytes)), (args, payload)
    assert rebuild(*args) == original
if len(sys.argv) > 1:
    assert Callable[spec, bytes].__reduce__()[1][1][0] is not spec
print("callable reducer preserved parameters")
