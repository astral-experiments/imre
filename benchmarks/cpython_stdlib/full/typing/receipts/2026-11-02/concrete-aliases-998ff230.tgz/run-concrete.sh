#!/bin/bash
set -eu
base=/workspace/scratch/intact-results
cd "$base/concrete-stage"
label=$1; level=$2; imre=$3; runtime=$4; form=$5
stem="$base/concrete-logs/$label-$form-O$level"
clang=/workspace/scratch/intact/tools/usr/bin/clang-19
if [ "$form" = ordinary ]; then
    flags="--no-cache --clang $clang --runtime $runtime --opt-level $level"
    printf 'IMREFLAGS=%q %q -B -m qualify positive\n' "$flags" "$imre" > "$stem.cmd"
    rc=0; IMREFLAGS="$flags" timeout 1600 "$imre" -B -m qualify positive > "$stem.positive.stdout" 2> "$stem.positive.stderr" || rc=$?; echo "$rc" > "$stem.positive.exit"
    tail -7 "$stem.positive.stderr"; tail -2 "$stem.positive.stdout"
else
    args=(build qualify.py --module-root "$PWD" --runtime-imports --no-cache --runtime "$runtime" --clang "$clang" --opt-level "$level" -o "$stem.exe")
    printf '%q ' "$imre" "${args[@]}" > "$stem.cmd"; echo >> "$stem.cmd"
    rc=0; timeout 1600 "$imre" "${args[@]}" > "$stem.build.stdout" 2> "$stem.build.stderr" || rc=$?; echo "$rc" > "$stem.build.exit"
    if test "$rc" != 0; then tail -8 "$stem.build.stderr"; exit "$rc"; fi
    for mode in positive wrong; do
        rc=0; timeout 180 "$stem.exe" "$mode" > "$stem.$mode.stdout" 2> "$stem.$mode.stderr" || rc=$?; echo "$rc" > "$stem.$mode.exit"; tail -5 "$stem.$mode.stderr"; tail -2 "$stem.$mode.stdout"
    done
fi
