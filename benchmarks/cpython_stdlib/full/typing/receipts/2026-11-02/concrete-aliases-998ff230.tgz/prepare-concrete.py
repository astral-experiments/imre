import ast, hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent
original=Path('/tmp/imre-stock/cpython/Lib/test/test_typing.py').read_bytes()
assert hashlib.sha256(original).hexdigest()=='28d17772f523800f02a5bf1e0cc012779d7df1f616fec7cc34d922dcba7ee1cc'
ls=original.splitlines(keepends=True)
astmod=ast.parse(original)
base=next(n for n in astmod.body if getattr(n,'name',None)=='BaseTestCase')
owner=next(n for n in astmod.body if getattr(n,'name',None)=='CollectionsAbcTests')
selected=['test_chainmap_instantiation','test_chainmap_subclass','test_deque','test_deque_instantiation','test_ordereddict_instantiation','test_ordereddict_subclass']
out=b'import collections\nimport typing\nfrom typing import T, KT, VT\nfrom unittest import TestCase\n\n'+b''.join(ls[base.lineno-1:base.end_lineno])+b'\n'+ls[owner.lineno-1]
provenance={}
for name in selected:
 f=next(n for n in owner.body if getattr(n,'name',None)==name); block=b''.join(ls[f.lineno-1:f.end_lineno]); out+=b'\n'+block
 provenance['test.test_typing.CollectionsAbcTests.'+name]={'first':f.lineno,'last':f.end_lineno,'sha256':hashlib.sha256(block).hexdigest()}
(root/'concrete-stage/test/test_typing.py').write_bytes(out)
(root/'concrete-logs/method-source.json').write_text(json.dumps(provenance,indent=2)+'\n')
