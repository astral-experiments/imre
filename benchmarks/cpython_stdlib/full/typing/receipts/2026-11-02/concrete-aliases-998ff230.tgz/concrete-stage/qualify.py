import sys
import unittest
from test import test_typing

suite = unittest.defaultTestLoader.loadTestsFromTestCase(test_typing.CollectionsAbcTests)
for case in suite:
    print('REGISTERED_ID', case.id(), flush=True)
result = unittest.TextTestRunner(verbosity=2, descriptions=False).run(suite)
print('TEST_COUNTS', result.testsRun, len(result.errors), len(result.failures), len(result.skipped), flush=True)
from boxed_typing_concrete_collections import current
current()
if 'wrong' in sys.argv:
    import typing
    assert typing.Deque[int]([1, 2]).pop() == 1
if not result.wasSuccessful():
    raise SystemExit(1)
