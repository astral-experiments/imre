def f[__debug__](): return 1
