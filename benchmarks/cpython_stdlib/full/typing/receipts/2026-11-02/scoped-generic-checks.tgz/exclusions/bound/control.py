def f[T: int](x: T): return x
assert f(1) == 1
