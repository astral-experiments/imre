def f[T, T](): return 1
