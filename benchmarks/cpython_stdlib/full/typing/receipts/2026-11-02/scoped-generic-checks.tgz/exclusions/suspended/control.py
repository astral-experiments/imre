def f[T](): yield T
