def factory[int]():
    def echo(value: int) -> int:
        return value
    return echo

value = []
echo = factory()
assert echo(value) is value
assert echo.__annotations__ == {"value": factory.__type_params__[0], "return": factory.__type_params__[0]}
