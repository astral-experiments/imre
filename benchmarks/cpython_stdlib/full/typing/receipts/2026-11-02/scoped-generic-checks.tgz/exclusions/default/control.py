def f[T = int](): return 1
assert f() == 1
