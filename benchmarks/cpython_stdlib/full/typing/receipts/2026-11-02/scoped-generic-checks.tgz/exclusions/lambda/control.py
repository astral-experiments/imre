def f[T](): return lambda: T
