def f[*Ts](): return 1
assert f() == 1
