def f[T]():
    nonlocal T
    return T
