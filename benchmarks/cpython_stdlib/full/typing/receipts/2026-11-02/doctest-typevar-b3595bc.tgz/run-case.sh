#!/bin/bash
set -u
cd /workspace/scratch/predicate-stage/doctest-probe
bin=/workspace/scratch/doctest-bin
clang=/workspace/scratch/intact/tools/usr/bin/clang-19
script=$1
mode=$2
opt=$3
out=b3595bc-$script-$mode-O$opt
mkdir -p "$out"
until [[ -x "$bin/imre" && -f "$bin/libimre_runtime.a" ]]; do sleep 3; done
export IMREFLAGS="--no-cache --clang $clang --runtime $bin/libimre_runtime.a --opt-level $opt"
if [[ $mode = ordinary ]]; then
  printf 'IMREFLAGS=%q %q -B -m %q\n' "$IMREFLAGS" "$bin/imre" "$script" > "$out/cmd"
  "$bin/imre" -B -m "$script" >"$out/stdout" 2>"$out/stderr"; echo $? > "$out/exit"
else
  printf '%q ' "$bin/imre" build "$script.py" --module-root "$PWD" --runtime-imports --no-cache --opt-level "$opt" --runtime "$bin/libimre_runtime.a" --clang "$clang" -o "$out/program" > "$out/cmd"
  "$bin/imre" build "$script.py" --module-root "$PWD" --runtime-imports --no-cache --opt-level "$opt" --runtime "$bin/libimre_runtime.a" --clang "$clang" -o "$out/program" >"$out/build.stdout" 2>"$out/build.stderr"; rc=$?; echo $rc > "$out/build.exit"
  if [[ $rc = 0 ]]; then "$out/program" >"$out/stdout" 2>"$out/stderr"; echo $? > "$out/exit"; fi
fi
cat "$out/stdout" "$out/stderr"
