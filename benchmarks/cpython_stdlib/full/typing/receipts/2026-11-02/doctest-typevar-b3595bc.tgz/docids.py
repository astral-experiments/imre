import unittest
from test import test_typing

print('ENTER unittest.defaultTestLoader.loadTestsFromModule(test.test_typing)', flush=True)
suite = unittest.defaultTestLoader.loadTestsFromModule(test_typing)
print('COUNT', suite.countTestCases(), flush=True)
for error in unittest.defaultTestLoader.errors:
    print('LOAD_ERROR', error, flush=True)
for case in suite:
    print('ID', case.id(), flush=True)
