import doctest
import unittest
from test import test_typing

original = doctest._boxed_docs

def trace(obj, name, owner, found, seen):
    try:
        return original(obj, name, owner, found, seen)
    except AttributeError as exc:
        print('DOC_WALK_ERROR', name, type(obj).__name__, str(exc), flush=True)
        raise

doctest._boxed_docs = trace
suite = unittest.defaultTestLoader.loadTestsFromModule(test_typing)
print('LOADER', suite.countTestCases(), flush=True)
for error in unittest.defaultTestLoader.errors:
    print(error, flush=True)
