import doctest
import types
import doctest_fixture
from typevar_members import current
from typing import TypeVar

current()
print("TYPEVAR", type(vars(TypeVar)).__name__, "real descriptor and method identity, binding and read-only mapping", flush=True)

suite = doctest.DocTestSuite(doctest_fixture)
ids = [case.id() for case in suite]
assert ids == ['doctest_fixture', 'doctest_fixture.Examples.nested', 'doctest_fixture.__test__.extra'], ids
print("CONTROL_IDS", ids, flush=True)
module = types.ModuleType('typing_probe_empty')
class Empty:
    pass
module.__test__ = {'empty': Empty}
empty = [case.id() for case in doctest.DocTestSuite(module)]
assert empty == [], empty
print("EMPTY_CLASS", empty, flush=True)

class Denied(type):
    def __getattribute__(self, name):
        if name == '__dict__':
            raise AttributeError('deliberate class namespace access')
        return type.__getattribute__(self, name)
class Opaque(metaclass=Denied):
    pass
module.__test__ = {'opaque': Opaque}
try:
    doctest.DocTestSuite(module)
except AttributeError as error:
    assert str(error) == 'deliberate class namespace access', error
    print("USER_ERROR", str(error), flush=True)
else:
    raise AssertionError('class namespace access error suppressed')
