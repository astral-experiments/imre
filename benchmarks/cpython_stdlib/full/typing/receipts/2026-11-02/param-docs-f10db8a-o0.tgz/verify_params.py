from param_members import current
current()
print("PASS parameter class namespace, read-only member, wrapper and method binding", flush=True)
