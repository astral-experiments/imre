from verify_params import current
import sys
import unittest
from test import test_typing

loader = unittest.TestLoader()
suite = loader.loadTestsFromModule(test_typing)
print("COUNT", suite.countTestCases(), flush=True)
for error in loader.errors:
    print("LOAD_ERROR", error, flush=True)

class Observe(unittest.TextTestResult):
    def startTest(self, test):
        super().startTest(test)
        print("START", test.id(), flush=True)
    def addSuccess(self, test):
        super().addSuccess(test)
        print("PASS", test.id(), flush=True)
    def addFailure(self, test, err):
        super().addFailure(test, err)
        print("FAIL", test.id(), flush=True)
    def addError(self, test, err):
        super().addError(test, err)
        print("ERROR", test.id(), flush=True)
    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        print("SKIP", test.id(), reason, flush=True)

parameters = unittest.TestSuite()
for case in suite:
    print("ID", case.id(), flush=True)
    if case.id() in ("typing.ParamSpec", "typing.ParamSpecArgs", "typing.ParamSpecKwargs"):
        parameters.addTest(case)
print("QUALIFY", parameters.countTestCases(), flush=True)
result = unittest.TextTestRunner(resultclass=Observe).run(parameters)
sys.exit(0 if not loader.errors and result.testsRun == 3 and result.wasSuccessful() else 1)
