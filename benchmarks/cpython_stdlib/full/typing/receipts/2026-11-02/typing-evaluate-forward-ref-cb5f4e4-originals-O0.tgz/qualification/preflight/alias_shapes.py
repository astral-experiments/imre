import typing
from collections.abc import Callable
from types import GenericAlias
from typing import ForwardRef
ref = ForwardRef("Alias")
for alias in (typing.Unpack[tuple[ref, ...]], typing.Literal[ref], typing.Callable[[ref], ref], Callable[[ref], ref], typing.List[ref]):
    print(type(alias).__name__, isinstance(alias, typing._GenericAlias), isinstance(alias, GenericAlias), hasattr(alias, 'copy_with'), alias.__args__)
print("evaluate_forward_ref", hasattr(typing, "evaluate_forward_ref"))
