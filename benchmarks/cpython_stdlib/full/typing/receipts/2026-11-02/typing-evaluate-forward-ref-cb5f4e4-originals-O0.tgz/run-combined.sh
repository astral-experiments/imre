set -eu
root=/workspace/scratch/evaluate-forward-controls
if test -e "$root/qualification/review-hold"; then
    echo 'Initial-head O3 held before compilation for a confirmed review regression.'
    exit 0
fi
dst="$root/qualification/ordinary-O3"
mkdir -p "$dst"
cd "$root/stage"
export TMPDIR="$dst"
export IMREFLAGS="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $root/bin/libimre_runtime.a --opt-level 3"
sha256sum forward_all.py forward_controls.py event_support.py test/test_typing.py test/typinganndata/fwdref_module.py "$root/bin/imre" "$root/bin/libimre_runtime.a" > "$dst/inputs"
date -u +%FT%TZ > "$dst/combined.start"
printf 'IMREFLAGS=%q nice -n 3 %q -B -m forward_all\n' "$IMREFLAGS" "$root/bin/imre" > "$dst/combined.cmd"
rc=0
nice -n 3 "$root/bin/imre" -B -m forward_all > "$dst/combined.stdout" 2> "$dst/combined.stderr" || rc=$?
echo "$rc" > "$dst/combined.rc"
tail -7 "$dst/combined.stdout"; tail -7 "$dst/combined.stderr"
