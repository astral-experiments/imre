set -eu
level=$1
priority=${2:-8}
root=/workspace/scratch/evaluate-forward-controls
dst="$root/qualification/ordinary-O$level"
mkdir -p "$dst/cache"
cd "$root/stage"
export TMPDIR="$dst"
export IMRE_CACHE_DIR="$dst/cache"
export IMREFLAGS="--clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $root/bin/libimre_runtime.a --opt-level $level"
sha256sum forward_cases.py forward_controls.py event_support.py test/test_typing.py test/typinganndata/fwdref_module.py "$root/bin/imre" "$root/bin/libimre_runtime.a" > "$dst/inputs"
for op in originals controls; do
    rc=0
    date -u +%FT%TZ > "$dst/$op.start"
    printf 'IMREFLAGS=%q IMRE_CACHE_DIR=%q %q -B -m forward_cases %q\n' "$IMREFLAGS" "$IMRE_CACHE_DIR" "$root/bin/imre" "$op" > "$dst/$op.cmd"
    nice -n "$priority" "$root/bin/imre" -B -m forward_cases "$op" > "$dst/$op.stdout" 2> "$dst/$op.stderr" || rc=$?
    echo "$rc" > "$dst/$op.rc"
    tail -4 "$dst/$op.stdout"; tail -6 "$dst/$op.stderr"
done
