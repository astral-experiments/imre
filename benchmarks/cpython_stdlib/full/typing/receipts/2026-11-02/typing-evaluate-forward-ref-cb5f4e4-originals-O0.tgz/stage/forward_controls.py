import sys
import types
import typing
from annotationlib import Format
from collections.abc import Callable
from typing import Annotated, ForwardRef, Literal, Union, Unpack, evaluate_forward_ref


class Meta(type):
    def __or__(cls, other):
        return ("custom union", cls, other)


class Custom(metaclass=Meta):
    pass


def run():
    assert typing.evaluate_forward_ref is evaluate_forward_ref
    assert typing.evaluate_forward_ref(ForwardRef("bytes")) is bytes
    assert evaluate_forward_ref(ForwardRef("7")) == 7
    fr = ForwardRef("unresolved")
    assert evaluate_forward_ref(fr, format=Format.FORWARDREF) is fr
    assert evaluate_forward_ref(fr, _recursive_guard={"unresolved"}) is fr
    assert evaluate_forward_ref(fr, format=Format.STRING, _recursive_guard={"unresolved"}) == "unresolved"
    try:
        evaluate_forward_ref(fr)
    except NameError as exc:
        assert exc.name == "unresolved"
    else:
        raise AssertionError("unresolved value")
    try:
        evaluate_forward_ref(fr, format=99)
    except NotImplementedError:
        pass
    else:
        raise AssertionError("invalid format")
    try:
        evaluate_forward_ref(ForwardRef("'invalid syntax!'"))
    except SyntaxError:
        pass
    else:
        raise AssertionError("invalid nested forward expression")
    quoted = ForwardRef("'unresolved'", is_argument=False, is_class=True)
    result = evaluate_forward_ref(quoted, format=Format.FORWARDREF)
    assert result.__forward_arg__ == "unresolved"
    assert result.__forward_is_argument__ is False and result.__forward_is_class__ is True
    print("PASS import forms, formats, values, negative cases and forwarded flags", flush=True)

    scope = {"Alias": bytes, "Literal": Literal, "Annotated": Annotated,
             "Callable": Callable, "tag": "Alias", "meta": object()}
    assert evaluate_forward_ref(ForwardRef("Literal[tag]"), globals=scope) == Literal["Alias"]
    value = evaluate_forward_ref(ForwardRef("Annotated['Alias', meta]"), globals=scope)
    assert value.__origin__ is bytes and value.__metadata__[0] is scope["meta"]
    value = evaluate_forward_ref(ForwardRef("Callable[['Alias'], 'Alias']"), globals=scope)
    assert value.__origin__ is Callable and value.__args__ == (bytes, bytes)
    scope["typed_callable"] = typing.Callable[[ForwardRef("Alias")], ForwardRef("Alias")]
    value = evaluate_forward_ref(ForwardRef("typed_callable"), globals=scope)
    assert value == typing.Callable[[bytes], bytes]
    scope["literal_ref"] = Literal[ForwardRef("Alias"), "Alias"]
    assert evaluate_forward_ref(ForwardRef("literal_ref"), globals=scope) == Literal[bytes, "Alias"]
    scope["unpacked"] = next(iter(tuple["Alias", ...]))
    assert evaluate_forward_ref(ForwardRef("unpacked"), globals=scope) == Unpack[tuple[bytes, ...]]
    scope["union"] = Union[ForwardRef("Custom"), int]
    scope["Custom"] = Custom
    assert evaluate_forward_ref(ForwardRef("union"), globals=scope) == ("custom union", Custom, int)
    print("PASS Literal strings, Annotated metadata, callable, unpack and union dispatch", flush=True)

    m = types.ModuleType("_forward_eval_control")
    m.Alias = bytes
    m.Flat = list["Alias"]
    m.Deep = list[dict[int, "Alias"]]
    sys.modules[m.__name__] = m
    try:
        assert evaluate_forward_ref(ForwardRef("Flat", module=m.__name__)) == list[bytes]
        ref = ForwardRef("Deep", module=m.__name__)
        try:
            evaluate_forward_ref(ref)
        except NameError as exc:
            assert exc.name == "Alias"
        else:
            raise AssertionError("inner generic alias retained parent forward module")
        assert evaluate_forward_ref(ref, owner=m) == list[dict[int, bytes]]
    finally:
        del sys.modules[m.__name__]
    param = typing.TypeVar("Named")
    assert evaluate_forward_ref(ForwardRef("Named"), type_params=(param,)) is param
    assert evaluate_forward_ref(ForwardRef("X"), globals={"X": int}, locals={"X": str}) is str
    print("PASS immediate parent, recursive owner, type parameters and explicit namespaces", flush=True)
