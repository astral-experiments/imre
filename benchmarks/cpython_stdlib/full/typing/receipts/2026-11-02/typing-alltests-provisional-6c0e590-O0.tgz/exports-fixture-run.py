from pathlib import Path
import json,os,subprocess,sys,time
r=Path(__file__).resolve().parent
src=r/'exports-fixture-stage';logs=r/'exports-current-logs'
label,level,compiler,runtime=sys.argv[1:]
assert set(label)<=set('abcdefghijklmnopqrstuvwxyz0123456789-') and level in {'0','3'}
stage=src/'boxed_typing_exports.py'
def run(name,argv):
    args=list(map(str,argv))
    prefix=logs/name
    Path(str(prefix)+'.argv').write_text(json.dumps({'argv':args,'cwd':str(src)})+'\n')
    start=time.monotonic()
    with Path(str(prefix)+'.stdout').open('wb') as out, Path(str(prefix)+'.stderr').open('wb') as err:
        rc=subprocess.run(args,cwd=src,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err).returncode
    Path(str(prefix)+'.result').write_text(json.dumps({'exit':rc,'seconds':round(time.monotonic()-start,3)})+'\n')
    print(name,rc,flush=True)
    return rc
key=label+'-fixture-boxed-O'+level
exe=logs/(key+'.exe')
rc=run(key+'-build',[compiler,'build',stage,'--module-root',src,'--runtime-imports','--no-cache','--clang','/workspace/scratch/intact/tools/usr/bin/clang-19','--runtime',runtime,'--opt-level',level,'-o',exe])
if not rc:rc=run(key,[exe])
exe.unlink(missing_ok=True)
sys.exit(rc)
