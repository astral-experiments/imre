from pathlib import Path
import ast,hashlib,json,sys
root=Path(__file__).resolve().parent
source=root/'exports-current-stage'
logs=root/'exports-current-logs'
expected=ast.literal_eval(next(n.value for n in ast.parse((source/'expected.py').read_text()).body if isinstance(n,ast.Assign)))
ids=['test.test_typing.AllTests.test_all','test.test_typing.AllTests.test_all_exported_names']
label=sys.argv[1]
raw=logs/(label+'.stdout')
lines=raw.read_text().splitlines()
events=[];bound={};diag=None;nonzero=[]
for line in lines:
    tag,_,tail=line.partition(' ')
    if tag in ('START','STOP','PASS','FAIL','ERROR','SKIP'):
        case,_,reason=tail.partition(' ')
        events.append((tag,case,reason or None))
    elif tag=='BIND':
        name,*flags=tail.split()
        if name in bound or len(flags)!=3:raise ValueError(line)
        bound[name]=tuple(x=='True' for x in flags)
    elif tag=='EXPORT_ERRORS':nonzero=ast.literal_eval(tail)
    elif tag=='METADATA_DIFFERENCES':diag=ast.literal_eval(tail)
rpath=logs/(label+'.result')
code=json.loads(rpath.read_text())['exit'] if rpath.is_file() else int((logs/(label+'.exit')).read_text())
summary={'original_ids':ids,'starts':[i for t,i,m in events if t=='START'],'stops':[i for t,i,m in events if t=='STOP'],'outcomes':[(t,i,m) for t,i,m in events if t not in {'START','STOP'}],'exit':code,'expected_export_count':len(expected),'found':len(bound),'all_four_binding_paths_match':sum(all(v) for v in bound.values()),'missing':[n for n in expected if n not in bound],'identities_differing':[n for n,v in bound.items() if not all(v)],'export_controls_errors':nonzero,'unrelated_metadata_differences':diag,'raw_stdout_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'stock_ordered_test_source_sha256':hashlib.sha256((source/'test/test_typing.py').read_bytes()).hexdigest()}
assert summary['starts']==summary['stops']==ids
if code==0:
    assert [(t,i) for t,i,_ in summary['outcomes']]==[('PASS',i) for i in ids]
    assert len(bound)==105 and all(all(v) for v in bound.values()) and not nonzero
    assert 'SEMANTIC_CONTROLS_OK' in lines and diag is not None
    assert 'EXPORT_COUNT 105 WILDCARD_COUNT 105' in lines
    order=next(ast.literal_eval(s.split(' ',1)[1]) for s in lines if s.startswith('WILDCARD_ORDER '))
    assert order==expected
(logs/(label+'.verified.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(label,'exit',code,'outcomes',summary['outcomes'],'bindings',len(bound),summary['all_four_binding_paths_match'],'diagnostic fields',None if diag is None else len(diag))
