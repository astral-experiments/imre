import typing
from collections import ChainMap, OrderedDict, abc, deque


def check_values():
    for alias, origin, arguments in (
        (typing.Deque, deque, (int,)),
        (typing.ChainMap, ChainMap, (str, int)),
        (typing.OrderedDict, OrderedDict, (str, int)),
    ):
        specialized = alias[arguments]
        assert typing.get_origin(alias) is origin
        assert typing.get_origin(specialized) is origin
        assert typing.get_args(specialized) == arguments
        assert type(specialized()) is origin
    assert typing.Text is str and typing.Text(42) == "42"
    assert typing.get_origin(typing.ByteString) is abc.ByteString
    assert isinstance(iter([]), typing.Iterator)
    assert typing.get_origin(typing.Iterator[int]) is abc.Iterator
    assert typing.get_origin(typing.Callable[[int], bool]) is abc.Callable
    token = object()
    assert typing.cast(str, token) is token
    assert typing.evaluate_forward_ref(
        typing.ForwardRef("list['int']"), globals={"list": list, "int": int},
    ) == list[int]
    try:
        typing.evaluate_forward_ref(typing.ForwardRef("sentinel_no_such_name_473"), globals={})
    except NameError:
        pass
    else:
        raise AssertionError("unresolvable forward reference did not raise NameError")
    print("SEMANTIC_CONTROLS_OK", flush=True)
