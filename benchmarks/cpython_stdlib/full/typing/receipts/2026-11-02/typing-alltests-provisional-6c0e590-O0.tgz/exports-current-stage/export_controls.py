import typing
from expected import EXPECTED


from expected_metadata import METADATA
from surface_metadata import FIELDS, MODULES, metadata_for
from expected_origins import PUBLIC_ORIGINS


def check_exports():
    errors = []
    metadata_differences = []
    try:
        from typing import __all__ as names
    except Exception as exc:
        errors.append(("named __all__", type(exc).__name__, str(exc)))
    else:
        if names is not typing.__all__ or type(names) is not list or names != EXPECTED:
            errors.append(("__all__ order, type, alias identity", repr(names)))

    try:
        import star_names
        star = vars(star_names)
    except Exception as exc:
        errors.append(("wildcard import", type(exc).__name__, str(exc)))
        star = {}
    try:
        import named_names
        explicit = vars(named_names)
    except Exception as exc:
        errors.append(("explicit import", type(exc).__name__, str(exc)))
        explicit = {}

    found = 0
    for name in EXPECTED:
        try:
            value = getattr(typing, name)
        except Exception as exc:
            errors.append((name, type(exc).__name__, str(exc)))
            print("MISSING", name, type(exc).__name__, str(exc), flush=True)
            continue
        found += 1
        real = vars(typing)
        retained = name in real and real[name] is value
        imported = name in explicit and explicit[name] is value
        exported = name in star and star[name] is value
        print("BIND", name, retained, imported, exported, flush=True)
        if not (retained and imported and exported):
            errors.append(("identity", name, retained, imported, exported))
        fields = metadata_for(name, value)
        if fields != METADATA[name]:
            metadata_differences.append((name, tuple(f for f, a, b in zip(FIELDS, fields, METADATA[name]) if a != b)))
        print("META", name, repr(fields), flush=True)
        if callable(value) != METADATA[name][5]:
            errors.append(("callable", name, callable(value)))
        ref = PUBLIC_ORIGINS[name][0]
        if ref is not None:
            origin = getattr(MODULES[ref[0]], ref[1])
            if typing.get_origin(value) is not origin:
                errors.append(("origin identity", name, ref))
        elif METADATA[name][6] is None and typing.get_origin(value) is not None:
            errors.append(("unexpected origin", name))

    public = [key for key in star if not key.startswith("_")]
    print("WILDCARD_ORDER", repr(public), flush=True)
    if public != EXPECTED:
        errors.append(("wildcard order", tuple(n for n in EXPECTED if n not in public),
                       tuple(n for n in public if n not in EXPECTED)))
    for bad_name in ("_nonexistent_export_1936765", "NotAnExport_1936765"):
        if hasattr(typing, bad_name) or bad_name in star or bad_name in explicit:
            errors.append(("negative lookup", bad_name))
    if found == len(EXPECTED):
        try:
            from semantic_controls import check_values
            check_values()
        except Exception as exc:
            errors.append(("semantic control", type(exc).__name__, str(exc)))
    print("METADATA_DIFFERENCES", repr(metadata_differences), flush=True)
    print("EXPORT_ERRORS", repr(errors), flush=True)
    print("EXPORT_COUNT", found, "WILDCARD_COUNT", len(public), flush=True)
    return not errors
