from typing import *
import typing as _typing
from typing import __all__ as _exports

assert _exports is _typing.__all__
assert [key for key in globals() if not key.startswith("_")] == _exports
for _key in _exports:
    assert globals()[_key] is getattr(_typing, _key)
print(_exports)
