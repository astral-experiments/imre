# Provisional typing export-list controls

The integration combines e5351c7d, the export list and the complete public 963840af..35985888 forward-evaluation patch. Its two source patches and toolchain provenance are included.

Copy each path in exports-current-logs/staged-test-sources.json from the pinned CPython checkout’s Lib directory to exports-current-stage, preserving its relative path and SHA256. From that stage, run the stock 3.14.5 interpreter or the matching native compiler with -B -m run. The native argv files record the exact optimization level, runtime archive and clang path in IMREFLAGS.

The ordinary runner invokes the original AllTests class from the intact test_typing.py and records unittest callbacks before running the independent export controls. The boxed run exercises the checked-in wildcard fixture separately. Each file retains its own exit and diagnostics.
