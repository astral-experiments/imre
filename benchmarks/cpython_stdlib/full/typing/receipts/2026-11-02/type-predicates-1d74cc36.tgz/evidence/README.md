# TypeGuard and TypeIs on Ruff Cloud Linux

These runs isolate the two unchanged CPython 3.14.5 classes in the original
`test.test_typing` module name. Their ten original IDs have ordinals 515–524
in the 712-case stock inventory. The pinned CPython commit is
`5607950ef232dad16d75c0cf53101d9649d89115`. The source test file has
SHA-256 `28d17772f523800f02a5bf1e0cc012779d7df1f616fec7cc34d922dcba7ee1cc`.

The staged `driver/test/test_typing.py` retains the original line positions.
Lines 62, 67–71, 86–87, 6660, 10435–10482 and 10485–10532 are byte-for-byte
source slices. Lines 1 and 2 import the dependencies used by these methods.
The source interpreter and native runners load the same two classes.
The historical 107/712 and intact module import observations are separate.

The first candidate `c3135492d38575ec999dd800aba081c72ba9e97f` exports the
special forms. The baseline boxed runs both reached ten methods but failed
`TypeGuardTests.test_cannot_subclass` and `TypeIsTests.test_cannot_subclass`.
The small baseline probe tries each of the four bases independently and tests
the permitted `_root=True` class definitions.

The corrected candidate is `1d74cc369713e23dd4775fbaab94071bca2a3234`. Its
driver runs the independent base controls, the product regression fixture, and
then the ten unittest methods. The candidate probe also rebinds `typing._Final`
and calls the previously created alias type's subclass hook.

## Reproduce

Extract the archive and run from `driver/`. Set `STOCK` to a test-enabled
CPython built at the specified commit. Set `IMRE`, `RUNTIME`, and `CLANG` to
absolute paths. This worker used Debian clang 19.1.7 (3+b1). On the first
candidate use `discover.py` as the entry point. On the corrected candidate use
`qualify.py`. These are boxed native runs at the indicated optimization level.

```sh
"$STOCK" -B qualify.py
for level in 0 3; do
    "$IMRE" build qualify.py --module-root "$PWD" --runtime-imports --no-cache \
        --clang "$CLANG" --runtime "$RUNTIME" --opt-level "$level" -o "boxed-O$level"
    "./boxed-O$level"
done
```
