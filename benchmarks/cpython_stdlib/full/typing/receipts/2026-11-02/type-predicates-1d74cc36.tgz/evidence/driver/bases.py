from typing import TypeGuard, TypeIs


def from_form_type(form):
    class C(type(form)):
        pass


def from_alias_type(form):
    class D(type(form[int])):
        pass


def from_form(form):
    class E(form):
        pass


def from_alias(form):
    class F(form[int]):
        pass


def from_root_form_type(form):
    class G(type(form), _root=True):
        pass


def from_root_alias_type(form):
    class H(type(form[int]), _root=True):
        pass


for form in (TypeGuard, TypeIs):
    for build in (from_form_type, from_alias_type, from_form, from_alias,
                  from_root_form_type, from_root_alias_type):
        try:
            build(form)
        except Exception as exc:
            print(form, build.__name__, type(exc).__name__, str(exc), flush=True)
        else:
            print(form, build.__name__, "accepted", flush=True)

# Aliases created before a module-name rebind retain their original subclass hook.
import typing
alias_class = type(TypeGuard[int])
saved = typing._Final
try:
    typing._Final = object
    assert alias_class.__init_subclass__(_root=False) is None
    try:
        class Child(alias_class):
            pass
    except TypeError as exc:
        assert str(exc) == "Cannot subclass special typing classes"
    else:
        raise AssertionError("subclass hook followed the rebound module name")
finally:
    typing._Final = saved
