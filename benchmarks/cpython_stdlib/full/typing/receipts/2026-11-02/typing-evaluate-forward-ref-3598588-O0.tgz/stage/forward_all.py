import sys
import unittest
from test import test_typing
from event_support import Events
import forward_controls

names = ("test_evaluate_forward_ref", "test_evaluate_forward_ref_nested",
         "test_evaluate_forward_ref_none", "test_evaluate_forward_ref_undefined",
         "test_globals", "test_inherited_owner", "test_owner",
         "test_partial_evaluation", "test_with_module")

print("ORIGINALS_BEGIN", flush=True)
cases = unittest.TestSuite(test_typing.EvaluateForwardRefTests(name) for name in names)
print("REGISTERED_COUNT", cases.countTestCases(), flush=True)
result = unittest.TextTestRunner(verbosity=2, descriptions=False, resultclass=Events).run(cases)
print("RUNNER_COUNT", result.testsRun, flush=True)
print("ORIGINALS_END", result.wasSuccessful(), result.testsRun, flush=True)
print("CONTROLS_BEGIN", flush=True)
forward_controls.run()
print("CONTROLS_END", flush=True)
print("BOUNDARIES_BEGIN", flush=True)
forward_controls.private_boundaries()
print("BOUNDARIES_END", flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
