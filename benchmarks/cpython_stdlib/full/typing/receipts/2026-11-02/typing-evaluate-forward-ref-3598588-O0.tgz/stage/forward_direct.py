import forward_controls
print("CONTROLS_BEGIN", flush=True)
forward_controls.run()
print("CONTROLS_END", flush=True)
print("BOUNDARIES_BEGIN", flush=True)
forward_controls.private_boundaries()
print("BOUNDARIES_END", flush=True)
