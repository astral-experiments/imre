import ast, subprocess, typing, types, collections.abc, annotationlib
import sys
repo='/workspace/scratch/imre'
src=subprocess.check_output(['git','-C',repo,'show','35985888:crates/imre-compiler/stdlib/typing.py']).decode()
nodes=ast.parse(src).body
selected=[n for n in nodes if isinstance(n,ast.FunctionDef) and n.name in {'_resolve_forward_type','evaluate_forward_ref','_is_parameterized_typing_alias'}]
ns=vars(typing).copy()
ns.update(ForwardRef=annotationlib.ForwardRef,_typing=typing,_abc_callable_alias_type=type(collections.abc.Callable[...,object]))
exec(compile(ast.Module(body=selected,type_ignores=[]),'<candidate-extracted>','exec'),ns)
checks=[]
class Meta(type):
 def __eq__(cls,other):
  checks.append(getattr(other,'__name__','?'))
  raise RuntimeError('raw type compared')
class Raw(metaclass=Meta):pass
obj=Raw()
for name,fn in [('upstream',typing.evaluate_forward_ref),('candidate',ns['evaluate_forward_ref'])]:
 try:
  ans=fn(annotationlib.ForwardRef('obj'),globals={'obj':obj})
  print(name,'raw identity',ans is obj, 'calls',checks)
 except Exception as e:
  print(name,'raw',type(e).__name__,str(e),'calls',checks)
 checks.clear()
for al in (typing.Callable[[typing.ForwardRef('Alias')],bytes],typing._CallableGenericAlias(collections.abc.Callable,(typing.ForwardRef('Alias'),bytes),name='Custom',inst=False),typing._GenericAlias(list,(typing.ForwardRef('Alias'),),name='Other',inst=False),typing._UnpackGenericAlias(typing.Unpack,(typing.ForwardRef('Alias'),),name='Other',inst=False),typing._LiteralGenericAlias(typing.Literal,(typing.ForwardRef('Alias'),),name='Other',inst=False)):
 print('input',type(al).__name__,al._name,al._inst)
 for name,fn in [('upstream',typing.evaluate_forward_ref),('candidate',ns['evaluate_forward_ref'])]:
  try:
   ans=fn(annotationlib.ForwardRef('al'),globals={'al':al,'Alias':int})
   print(name,type(ans).__name__,ans._name,ans._inst,ans.__args__)
  except Exception as e:print(name,'error',type(e).__name__,str(e))
