set -eu
level=$1
entry=$2
priority=$3
root=/workspace/scratch/evaluate-forward-final
case "$entry" in
  forward_all) dst="$root/qualification/ordinary-O$level"; label=combined;;
  forward_direct) dst="$root/qualification/edge-ordinary-O$level"; label=direct;;
esac
mkdir -p "$dst"
cd "$root/stage"
export TMPDIR="$dst"
export IMREFLAGS="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $root/bin/libimre_runtime.a --opt-level $level"
sha256sum "$entry.py" forward_controls.py event_support.py test/test_typing.py test/typinganndata/fwdref_module.py "$root/bin/imre" "$root/bin/libimre_runtime.a" > "$dst/inputs"
date -u +%FT%TZ > "$dst/$label.start"
printf 'IMREFLAGS=%q nice -n %s %q -B -m %q\n' "$IMREFLAGS" "$priority" "$root/bin/imre" "$entry" > "$dst/$label.cmd"
rc=0; nice -n "$priority" "$root/bin/imre" -B -m "$entry" > "$dst/$label.stdout" 2> "$dst/$label.stderr" || rc=$?
echo "$rc" > "$dst/$label.rc"; tail -8 "$dst/$label.stdout"; tail -7 "$dst/$label.stderr"; exit "$rc"
