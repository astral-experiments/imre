from collections.abc import Callable, Coroutine, Iterable
from types import GenericAlias, FunctionType
import typing

def show(label, function):
    try:
        value = function()
    except Exception as error:
        print(label, type(error).__name__, str(error), flush=True)
    else:
        print(label, repr(value), flush=True)

def relations():
    ABC = type(Callable[[int], str])
    for label, alias in (("abc", Callable[[int], str]), ("typing", typing.Callable[[int], str]),
                         ("list", list[int]), ("iterable", Iterable[int]), ("coroutine", Coroutine[int, str, float])):
        show(label + ".type", lambda: type(alias))
        show(label + ".is_generic", lambda: isinstance(alias, GenericAlias))
        show(label + ".sub_generic", lambda: issubclass(type(alias), GenericAlias))
        show(label + ".args", lambda: alias.__args__)
    for name in ("__base__", "__bases__", "__mro__"):
        show("ABC." + name, lambda: getattr(ABC, name))
    for name, fn in (("origin", lambda: Callable()), ("meta", lambda: type(Callable)()),
                     ("instance", lambda: Callable[[int], str]()), ("class", lambda: ABC()),
                     ("one_arg", lambda: ABC(Callable)), ("invalid", lambda: ABC(Callable, int)),
                     ("invalid_list", lambda: ABC(Callable, [int, str])),
                     ("invalid_head", lambda: ABC(Callable, (int, str))),
                     ("direct", lambda: ABC(Callable, ([int, str], float))),
                     ("tuple_head", lambda: ABC(Callable, ((int, str), float))),
                     ("ellipsis", lambda: ABC(Callable, (..., str))),
                     ("by_keyword", lambda: ABC(origin=Callable, args=([int], str))),
                     ("alt_origin", lambda: ABC(list, ([int], str)).__origin__),
                     ("dir", lambda: all(n in dir(Callable[..., int]) for n in ("__args__", "__parameters__", "__origin__")))):
        show(name, fn)
relations()
