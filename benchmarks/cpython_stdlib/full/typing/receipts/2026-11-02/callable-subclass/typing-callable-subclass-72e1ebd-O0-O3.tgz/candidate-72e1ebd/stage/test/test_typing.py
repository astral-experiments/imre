import annotationlib
import collections.abc
import types
import typing
from typing import Annotated, get_origin
from unittest import TestCase
from test.support import EqualToForwardRef

class BaseTestCase(TestCase):

    def clear_caches(self):
        for f in typing._cleanups:
            f()

class BaseCallableTests:
    def test_self_subclass(self):
        Callable = self.Callable
        with self.assertRaises(TypeError):
            issubclass(types.FunctionType, Callable[[int], int])
        self.assertIsSubclass(types.FunctionType, Callable)
        self.assertIsSubclass(Callable, Callable)

class CollectionsCallableTests(BaseCallableTests, BaseTestCase):
    Callable = collections.abc.Callable

class TypingCallableTests(BaseCallableTests, BaseTestCase):
    Callable = typing.Callable

class AnnotatedTests(BaseTestCase):
    def test_forwardref_partial_evaluation(self):
        # Test that Annotated partially evaluates if it contains a ForwardRef
        # See: https://github.com/python/cpython/issues/137706
        def f(x: Annotated[undefined, '']): pass

        ann = annotationlib.get_annotations(f, format=annotationlib.Format.FORWARDREF)

        # Test that the attributes are retrievable from the partially evaluated annotation
        x_ann = ann['x']
        self.assertIs(get_origin(x_ann), Annotated)
        self.assertEqual(x_ann.__origin__, EqualToForwardRef('undefined', owner=f))
        self.assertEqual(x_ann.__metadata__, ('',))
