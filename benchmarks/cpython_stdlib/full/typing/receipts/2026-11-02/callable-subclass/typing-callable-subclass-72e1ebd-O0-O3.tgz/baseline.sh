set -u
w=/workspace/scratch/awaitable-53/early-callable
cd "$w/stage"
p=/workspace/scratch/awaitable-53/iterator-77/port-b92de59/bin
row=$w/stock; rc=0; /tmp/imre-stock/build/python -B -m diagnose_calls >"$row/stdout" 2>"$row/stderr" || rc=$?; echo "$rc" >"$row/rc"
row=$w/b92-ordinary-O0; export TMPDIR="$row" IMREFLAGS="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $p/libimre_runtime.a --opt-level 0"; printf 'IMREFLAGS=%q %q -B -m diagnose_calls\n' "$IMREFLAGS" "$p/imre" >"$row/cmd"; rc=0; "$p/imre" -B -m diagnose_calls >"$row/stdout" 2>"$row/stderr" || rc=$?; echo "$rc" >"$row/rc"; cat "$row/stdout"
