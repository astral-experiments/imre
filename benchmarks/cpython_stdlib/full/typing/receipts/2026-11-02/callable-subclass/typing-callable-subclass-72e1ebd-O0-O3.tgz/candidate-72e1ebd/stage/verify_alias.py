import collections.abc as abc
import types
import typing
import unittest
from event_support import Events
from test import test_typing as t
from boxed_mapping_abc import callable_classes

suite=unittest.TestSuite([t.AnnotatedTests('test_forwardref_partial_evaluation'),t.CollectionsCallableTests('test_self_subclass'),t.TypingCallableTests('test_self_subclass')])
res=unittest.TextTestRunner(verbosity=2,resultclass=Events).run(suite)
print('ORIGINALS_END',res.testsRun,len(res.errors),len(res.failures),len(res.skipped),flush=True)
if not res.wasSuccessful():raise SystemExit(1)
callable_classes()
assert issubclass(typing.Callable,typing.Callable)
assert issubclass(abc.Callable,typing.Callable)
assert issubclass(typing.Type,typing.Callable)
assert not issubclass(typing.List,typing.Callable)
assert issubclass(types.FunctionType,typing.Callable)
assert not issubclass(int,typing.Callable)
class User:
    def __call__(self): pass
class Disabled:
    __call__=None
assert issubclass(User,typing.Callable) and not issubclass(Disabled,typing.Callable)
assert isinstance(User(),typing.Callable) and not isinstance(Disabled(),typing.Callable)
P=typing.ParamSpec('P')
for bad in (typing.Callable[...,int],typing.List[int],typing.Literal[3],typing.Concatenate[int,P]):
    try:
        issubclass(bad,typing.Callable)
    except TypeError as e:
        assert str(e)=='Subscripted generics cannot be used with class and instance checks',str(e)
    else:raise AssertionError(bad)
for bad in (42,list[int]):
    try:
        issubclass(bad,typing.Callable)
    except TypeError as e:
        assert str(e)=='issubclass() arg 1 must be a class',str(e)
    else:raise AssertionError(bad)
print('PASS original Callable fixture, raw and named alias origins, parameterized and invalid child errors',flush=True)
