set -eu
d=/workspace/scratch/awaitable-53/early-callable/candidate-72e1ebd
source /workspace/ty-env.sh
cd /workspace/scratch/typing-callable-subclass
export CARGO_TARGET_DIR=/workspace/scratch/typing-iterator-target CARGO_PROFILE_DEV_DEBUG=0 CARGO_INCREMENTAL=0
cargo build --offline --locked --jobs 1 -p imre-compiler -p imre-runtime >"$d/build.log" 2>&1
ln "$CARGO_TARGET_DIR/debug/imre" "$d/bin/imre"
ln "$CARGO_TARGET_DIR/debug/libimre_runtime.a" "$d/bin/libimre_runtime.a"
{ hostname; git rev-parse HEAD HEAD^; "$d/bin/imre" --version; sha256sum "$d/bin/imre" "$d/bin/libimre_runtime.a"; } > "$d/provenance.txt"
