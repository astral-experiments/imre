set -eu
d=/workspace/scratch/awaitable-53/early-callable/candidate-72e1ebd
cd "$d/stage"
rc=0; /tmp/imre-stock/build/python -B -m verify_alias >"$d/stock/stdout" 2>"$d/stock/stderr" || rc=$?; echo "$rc" >"$d/stock/rc"; test "$rc" -eq 0
until test -s "$d/provenance.txt"; do if rg -q '^error:' "$d/build.log"; then exit 1; fi; sleep 5; done
for level in 0 3; do
 row="$d/ordinary-O$level"; mkdir -p "$row";export TMPDIR="$row" IMREFLAGS="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $d/bin/libimre_runtime.a --opt-level $level"
 printf 'IMREFLAGS=%q %q -B -m verify_alias\n' "$IMREFLAGS" "$d/bin/imre" >"$row/cmd"
 rc=0; "$d/bin/imre" -B -m verify_alias >"$row/stdout" 2>"$row/stderr" || rc=$?; echo "$rc" >"$row/rc"; test "$rc" -eq 0; cmp "$d/stock/stdout" "$row/stdout"
done
