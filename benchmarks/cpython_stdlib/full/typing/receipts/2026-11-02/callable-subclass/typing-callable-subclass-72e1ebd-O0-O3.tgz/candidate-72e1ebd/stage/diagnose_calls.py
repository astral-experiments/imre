import types
import unittest
from collections.abc import Callable
from test import test_typing as t
from event_support import Events

class HasCall:
    def __call__(self): pass
class Disabled:
    __call__ = None

suite=unittest.TestSuite([t.AnnotatedTests('test_forwardref_partial_evaluation'),t.CollectionsCallableTests('test_self_subclass'),t.TypingCallableTests('test_self_subclass')])
res=unittest.TextTestRunner(verbosity=2,resultclass=Events).run(suite)
print('ORIGINALS_END',res.testsRun,len(res.errors),len(res.failures),len(res.skipped),flush=True)
for name,cls in [('function',types.FunctionType),('builtin',types.BuiltinFunctionType),('method',types.MethodType),('type',type),('user',HasCall),('disabled',Disabled),('int',int)]:
    try:
        print('PROBE',name,issubclass(cls,Callable),hasattr(cls,'__call__'),'__call__' in vars(cls),flush=True)
    except Exception as exc:
        print('PROBE_ERROR',name,type(exc).__name__,str(exc),flush=True)
print('INSTANCES',isinstance(lambda:None,Callable),isinstance(len,Callable),isinstance(HasCall(),Callable),isinstance(Disabled(),Callable), flush=True)
if not res.wasSuccessful(): raise SystemExit(1)
