import ast, pathlib,hashlib,json,shutil
base=pathlib.Path(__file__).parent
stage=base/'stage';lib=pathlib.Path('/tmp/imre-stock/cpython/Lib/test')
cases=lib/'test_typing.py';support=lib/'support/__init__.py'
def lines(p):return p.read_bytes().splitlines(keepends=True)
def node(p,*names):
 n=ast.parse(p.read_bytes())
 for name in names:n=next(x for x in n.body if getattr(x,'name',None)==name)
 return n
def fragment(p,*names):
 n=node(p,*names);return b''.join(lines(p)[n.lineno-1:n.end_lineno])
def header(p,*names):
 n=node(p,*names);return lines(p)[n.lineno-1]
fn='test_self_subclass';sf='test_forwardref_partial_evaluation'
file=b'import annotationlib\nimport collections.abc\nimport types\nimport typing\nfrom typing import Annotated, get_origin\nfrom unittest import TestCase\nfrom test.support import EqualToForwardRef\n\n'+fragment(cases,'BaseTestCase')+b'\n'+header(cases,'BaseCallableTests')+fragment(cases,'BaseCallableTests',fn)+b'\n'+fragment(cases,'CollectionsCallableTests')+b'\n'+header(cases,'TypingCallableTests')+lines(cases)[node(cases,'TypingCallableTests').lineno]+b'\n'+header(cases,'AnnotatedTests')+fragment(cases,'AnnotatedTests',sf)
(stage/'test/test_typing.py').write_bytes(file);(stage/'test/__init__.py').write_text('');(stage/'test/support/__init__.py').write_bytes(b'import annotationlib\n'+fragment(support,'EqualToForwardRef'))
shutil.copyfile(base.parent/'iterator-77/selected-stage/event_support.py',stage/'event_support.py')
info={}
for cl,m in [('AnnotatedTests',sf),('CollectionsCallableTests',fn),('TypingCallableTests',fn)]:
 source=cl if cl=='AnnotatedTests' else 'BaseCallableTests';n=node(cases,source,m)
 info['test.test_typing.'+cl+'.'+m]={'original_ordinal':{'AnnotatedTests':16,'CollectionsCallableTests':118,'TypingCallableTests':655}[cl],'lines':[n.lineno,n.end_lineno],'method_sha256':hashlib.sha256(fragment(cases,source,m)).hexdigest()}
(base/'source.json').write_text(json.dumps({'cases':info,'pin':'5607950ef232dad16d75c0cf53101d9649d89115','upstream_test_typing_sha256':hashlib.sha256(cases.read_bytes()).hexdigest(),'staged_test_typing_sha256':hashlib.sha256(file).hexdigest()},indent=2)+'\n')
