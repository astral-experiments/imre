"""Capture source-selected case lifecycles and true aggregate exits for each process."""
import ast,hashlib,io,json,subprocess,sys,tarfile
from pathlib import Path
base=Path(__file__).resolve().parent; cand=base/'candidate-72e1ebd';out=Path(sys.argv[1]);modes=sys.argv[2:]
dig=lambda b:hashlib.sha256(b).hexdigest();source=json.loads((base/'source.json').read_text());files={};profiles={}
for file in ['pack_calls.py','stage_selected.py','source.json','baseline.sh']:files[file]=(base/file).read_bytes()
for p in (base/'stage').rglob('*.py'):files[str(p.relative_to(base))]=p.read_bytes()
p=base.parent/'iterator-77/port-b92de59/provenance.txt';files['baseline-b92de59-provenance.txt']=p.read_bytes()
files['overlap-check.json']=(json.dumps({'query':'repo:astral-experiments/imre is:pr is:open Callable','at':'2026-11-02T14:53Z','relevant':{'4212':'Callable parameterized alias bases/constructor/subscription','4227':'typing alias dir','4213':'GenericAlias dir'},'historical_diagnostic':'Ordinary combined 10dd4e8 lacked native function structural subclass check; boxed 935cf6d included it. These input source/mode snapshots were not a matched pair.','abc_fix':'9f09eedbbff6b90403d9db9e43d55f65b831aae6','annotationlib_fix':'e278c9c'},indent=2)+'\n').encode()
def collect(name,folder,provenance):
 for entry in ['stdout','stderr','rc','cmd']:
  p=folder/entry
  if p.is_file():files[str(p.relative_to(base))]=p.read_bytes()
 stdout=(folder/'stdout').read_text();ev=[ast.literal_eval(l.removeprefix('TYPING_EVENT ')) for l in stdout.splitlines() if l.startswith('TYPING_EVENT ')]
 assert all(e[1] in source['cases'] for e in ev);row={}
 for key,meta in source['cases'].items():
  events=[e for e in ev if e[1]==key];outcomes=[e for e in events if e[0] in {'PASS','SKIP','ERROR','FAIL','EXPECTED_FAILURE','UNEXPECTED_SUCCESS'}]
  assert len(outcomes)==1
  assert events[0][0]=='START' and events[-1][0]=='STOP'
  row[key]=dict(meta,outcome=outcomes[0][0],detail=outcomes[0][3],skip_reason=outcomes[0][3] if outcomes[0][0]=='SKIP' else None,children=[e for e in events if e[0].startswith('SUBTEST_')])
 profiles[name]={'source':provenance,'aggregate_exit':int((folder/'rc').read_text()),'outcomes':row,'header':next(l for l in stdout.splitlines() if l.startswith('ORIGINALS_END ')),'stdout_sha256':dig(stdout.encode())}
collect('stock-preflight',base/'stock',source['pin'])
collect('ordinary-O0-preflight',base/'b92-ordinary-O0','b92de59f396d498c37e65cb9e1550fef355b9741')
assert profiles['ordinary-O0-preflight']['aggregate_exit']==1
if modes:
 for p in [cand/'qualify.sh',cand/'build.sh',cand/'build.log',cand/'provenance.txt',*(cand/'stage').rglob('*.py')]:
  files[str(p.relative_to(base))]=p.read_bytes()
 prov=(cand/'provenance.txt').read_text().splitlines();head=prov[1];assert head=='72e1ebd0799c1583af46dbd811d5d144b5b26ad5'
 for m in ['stock',*modes]:
  collect('candidate-'+m,cand/m,source['pin'] if m=='stock' else head)
 files['candidate.diff']=subprocess.check_output(['git','-C','/workspace/scratch/typing-callable-subclass','diff',prov[2],head])
summary={'upstream':source,'profiles':profiles,'scope':'Unmodified original method bytes in their original dotted locations with source-selected class definitions. This group is not full-suite discovery. Extra preflight PROBE_ERROR rows on class dictionaries are independent from the three test outcomes.','historical_original_source_sha256':source['upstream_test_typing_sha256']}
if 'ordinary-O3' in modes:
 ep=cand/'entrypoints'
 for f in ep.iterdir():
  if f.is_file():files[str(f.relative_to(base))]=f.read_bytes()
 summary['standalone_entrypoints']={'scope':'Direct standalone compiler and boxed runtime dispatch. Outside the original-case suite.','preflight_ordinary_static_check_exit':int((ep/'baseline-ordinary-check.rc').read_text()),'candidate_ordinary_static_check_exit':int((ep/'ordinary-check.rc').read_text()),'static_diagnostics_match':(ep/'baseline-ordinary-check.stderr').read_bytes()==(ep/'ordinary-check.stderr').read_bytes(),'candidate_boxed_static_check_exit':int((ep/'boxed-check.rc').read_text())}
 if (ep/'boxed-O0.rc').exists():
  summary['standalone_entrypoints'].update(boxed_O0_exit=int((ep/'boxed-O0.rc').read_text()),boxed_stdout_matches_stock=(ep/'boxed-O0.stdout').read_bytes()==(ep/'stock.stdout').read_bytes())
files['summary.json']=(json.dumps(summary,indent=2)+'\n').encode();files['MANIFEST.sha256']=''.join(f'{dig(v)}  {p}\n' for p,v in sorted(files.items())).encode()
with tarfile.open(out,'w:gz') as t:
 for p,v in sorted(files.items()):
  m=tarfile.TarInfo(p);m.size=len(v);m.mode=0o600;t.addfile(m,io.BytesIO(v))
print(dig(out.read_bytes()),out,{p:r['aggregate_exit'] for p,r in profiles.items()})
