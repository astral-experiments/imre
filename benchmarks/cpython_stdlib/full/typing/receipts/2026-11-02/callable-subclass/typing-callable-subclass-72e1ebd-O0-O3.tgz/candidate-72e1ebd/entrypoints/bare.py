from typing import Callable

assert issubclass(Callable, Callable)
print('typing.Callable reflexive')
