/tmp/imre-stock/build/python -B -m probe
