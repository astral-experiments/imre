import typing
import types
import doctest

def observe():
    before=set(vars(typing))
    assert issubclass(types.FunctionType,typing.Callable)
    after=set(vars(typing))
    print('ADDED',sorted(after-before),'REMOVED',sorted(before-after),flush=True)
    try:
        docs=doctest.DocTestSuite(typing)
        found=[c.id() for c in docs]
        print('DOCS',len(found),found,flush=True)
    except Exception as e:
        print('FINDER_ERROR',type(e).__name__,str(e),flush=True)
    assert before==after, 'unexpected publication of a typing alias'
observe()
