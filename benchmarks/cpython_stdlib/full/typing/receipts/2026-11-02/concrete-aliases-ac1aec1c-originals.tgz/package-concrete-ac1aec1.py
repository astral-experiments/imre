"""Check the rebased candidate's original callbacks and package read-only evidence."""
import hashlib
import json
from pathlib import Path
import tarfile

base = Path(__file__).resolve().parent
logs = base / 'concrete-logs'
binary = base / 'concrete-ac1aec1-bin'
prior = json.loads((logs / 'summary.json').read_bytes())
summary = {key: prior[key] for key in ('stock', 'methods', 'scope', 'host', 'baseline')}
summary.update(patch='ac1aec1c430c58153094f17018d34066a437640f', public_base='fcff99c811a6991b941f2ec0b36aebc386d51bf9', original_candidate=prior['patch'], landed_as='c264295454c234f5c0d2aa58524fc7ce6a0cf245')
assert (binary / 'commit').read_text().strip() == summary['patch']
stock = (logs / 'stock-positive.stdout').read_bytes()
stock_methods = [r for r in (logs / 'stock-positive.stderr').read_text().splitlines() if r.endswith(' ... ok')]
assert len(stock_methods) == 6 and len(set(stock_methods)) == 6
summary['stdout_sha256'] = hashlib.sha256(stock).hexdigest()
summary['profiles'] = {}
for mode in ('ordinary', 'boxed'):
    for level in (0, 3):
        stem = 'merged-ac1aec1-' + mode + '-O' + str(level)
        for outcome in (('positive', 'wrong') if mode == 'boxed' else ('positive',)):
            status = int((logs / (stem + '.' + outcome + '.exit')).read_bytes())
            assert status == (1 if outcome == 'wrong' else 0)
            stdout = (logs / (stem + '.' + outcome + '.stdout')).read_bytes()
            stderr = (logs / (stem + '.' + outcome + '.stderr')).read_text().splitlines()
            assert stdout == stock
            assert [r for r in stderr if r.endswith(' ... ok')] == stock_methods
            assert 'OK' in stderr
            if outcome == 'wrong':
                assert stderr[-1] == 'AssertionError' and 'qualify.py", line 14' in stderr[-2]
            summary['profiles'][stem + '.' + outcome] = {'exit': status, 'originals_passed': 6, 'skipped': 0, 'stderr_sha256': hashlib.sha256(('\n'.join(stderr)+'\n').encode()).hexdigest()}
        if mode == 'boxed':
            assert (logs / (stem + '.build.exit')).read_text().strip() == '0'
summary_path = logs / 'merged-ac1aec1-summary.json'
summary_path.write_text(json.dumps(summary,indent=2)+'\n')
archive = base / 'typing-concrete-aliases-ac1aec1c-linux.tar.gz'
paths = [*sorted((base/'concrete-stage').rglob('*.py')), *(p for p in sorted(logs.iterdir()) if p.suffix != '.exe' and (p.name.startswith(('stock-', 'merged-ac1aec1-', 'base-c7295770')) or p.name=='method-source.json')), base/'run-concrete.sh', base/'prepare-concrete.py', Path(__file__).resolve(), binary/'hashes', binary/'commit', binary/'build.log']
with tarfile.open(archive,'x:gz') as tar:
    for path in paths:
        tar.add(path,arcname=path.relative_to(base))
print(archive, archive.stat().st_size, hashlib.sha256(archive.read_bytes()).hexdigest())
