async def values():
    yield 42


print("defined", values.__name__, flush=True)
generator = values()
print("created", type(generator).__name__, generator.__aiter__() is generator, flush=True)
