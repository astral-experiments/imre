import datetime, hashlib, json, sys, tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
logs=root/'abc-current-logs'
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def outcome(prefix):
    path=logs/(prefix+'.result')
    if not path.exists(): return None
    item=json.loads(path.read_text())
    events=(logs/(prefix+'.stdout')).read_text().splitlines()
    item['events']=[e for e in events if e.startswith(('START ','PASS ','FAIL ','ERROR ','SKIP '))]
    return item
pins=(logs/'revision.txt').read_text().splitlines()
cases=[line.split('\t',1) for line in (logs/'ordinals.tsv').read_text().splitlines()]
rows={}
for group in ('abc-current-focus','abc-current-stage','abc-language'):
    for mode,level in (('stock','ref'),('ordinary','0'),('ordinary','3'),('boxed','0'),('boxed','3')):
        prefix=f'{group}-{mode}-{level}'
        entry=outcome(prefix)
        if entry is not None: rows[prefix]=entry
        build=outcome(prefix+"-build")
        if build is not None: rows[prefix+"-build"]=build
named={}
for key,item in rows.items():
    if not key.startswith('abc-current-stage-') or key.endswith('-build'): continue
    by_id={}
    for e in item['events']:
        parts=e.split(' ',2)
        if parts[0]!='START':
            by_id[parts[1]]={'result':parts[0]}
            if len(parts)>2: by_id[parts[1]]['detail']=parts[2]
    named[key.removeprefix('abc-current-stage-')]=by_id
paired=[{'ordinal':int(number),'case_id':ident,'scope':('existing public Sized regression' if number=='97' else 'targeted'),
         'outcomes':{key:ids.get(ident) for key,ids in named.items()}} for number,ident in cases]
snapshot=sys.argv[1]
summary={'snapshot':snapshot,'created_utc':str(datetime.datetime.now(datetime.timezone.utc)),
         'landed_revision':'4f1a2aff77c2f35356eba7cb6fbab3c501fafb43', 'pr':4195, 'imre_revision':pins[0], 'imre_tree':pins[1], 'imre_base':pins[2], 'imre_runtime_tree':pins[3],
         'upstream':'5607950ef232dad16d75c0cf53101d9649d89115',
         'intact_file_sha256':sha(root/'abc-current-stage/test/test_typing.py'),
         'ledger':'named original methods and focused controls; no full discovery pass counts',
         'suite_size_stock':712,'named_selected':cases, 'original_outcomes':paired, 'runs':rows}
out=root/f'abc-{snapshot}-{pins[0][:8]}.tar.gz'
sp=logs/('summary-'+snapshot+'.json')
sp.write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(out,'w:gz') as tf:
    files=['abc-current-run.py','abc-current-package.py','abc-language/run.py','abc-current-focus/run.py','abc-current-stage/run.py',
           'abc-current-stage/alias_semantics.py','abc-current-stage/test/test_typing.py','missing-exports.tsv','open-pr-inventory.json']
    for f in files: tf.add(root/f,arcname=f)
    for f in sorted(logs.glob('*')):
        if f.is_file() and f.suffix not in ('.exe',) and not (f.name.startswith('summary-') and f!=sp):
            tf.add(f,arcname=f.relative_to(root))
print(out,sha(out))
