import doctest
import typing
from annotationlib import ForwardRef
from typing import evaluate_forward_ref


def observe():
    value = ForwardRef('int')
    before = set(vars(typing))
    assert evaluate_forward_ref(value) is int
    after = set(vars(typing))
    print('ADDED', sorted(after - before), 'REMOVED', sorted(before - after), flush=True)
    try:
        ids = [case.id() for case in doctest.DocTestSuite(typing)]
        print('DOCS', len(ids), 'typing.get_args' in ids, 'typing.get_origin' in ids, flush=True)
    except Exception as exc:
        print('FINDER_ERROR', type(exc).__name__, str(exc), flush=True)
        raise
    assert before == after

observe()
