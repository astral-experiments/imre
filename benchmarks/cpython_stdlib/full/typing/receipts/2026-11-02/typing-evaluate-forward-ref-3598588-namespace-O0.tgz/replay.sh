#!/bin/sh
set -eu
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$src/source"
"${CPYTHON:?}" -B -m probe
IMREFLAGS="--no-cache --clang ${CLANG:?} --runtime ${IMRE_RUNTIME:?} --opt-level 0" "${IMRE:?}" -B -m probe
