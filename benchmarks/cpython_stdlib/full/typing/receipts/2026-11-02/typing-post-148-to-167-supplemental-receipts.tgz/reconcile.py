"""Run with Python 3.14 to rebuild the ledger from its original receipt streams."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import tarfile

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / 'inputs'
RAW = ROOT / 'raw'
SOURCE = ROOT / 'source'
CP = '5607950ef232dad16d75c0cf53101d9649d89115'
MODES = ['stock', 'ordinary-O0', 'ordinary-O3', 'boxed-O0', 'boxed-O3']

def digest(data):
    return hashlib.sha256(data).hexdigest()

def archive(name):
    with tarfile.open(RAW / name) as bundle:
        return {p.name: bundle.extractfile(p).read().decode() for p in bundle.getmembers() if p.isfile()}

def keys(j):
    raw = [tuple(p) for p in j['keys']]
    assert len(raw) == len(set(raw))
    return set(raw)

inputs = {int(re.search(r'(\d+)\.json$', p.name)[1]): (p, json.loads(p.read_text())) for p in INPUT.glob('ledger-*.json')}
a, b, c = (keys(inputs[i][1]) for i in (129, 148, 154))
assert len(a) == 129 and len(b) == 148 and len(c) == 154 and a < b < c
assert digest(inputs[148][0].read_bytes()) == '4d6bc22161270c2bec2a3ce7b271274da34e4bea937b7e0db3cabf4cf7d90df8'
stock = [json.loads(line) for line in (INPUT/'stock-pinned.jsonl').read_text().splitlines()]
assert len(stock) == 712
occ = Counter(); ordinals = {}
for n, item in enumerate(stock,1):
    key = item['id']; occ[key] += 1; ordinals[(key,occ[key])] = (n,item)
file_sha = {f.name:digest(f.read_bytes()) for f in SOURCE.glob('*.py')}
assert file_sha['test_typing.py'] == '28d17772f523800f02a5bf1e0cc012779d7df1f616fec7cc34d922dcba7ee1cc'
locations = {}
for file in SOURCE.glob('*.py'):
    data = file.read_bytes(); lines = data.splitlines(keepends=True)
    for node in ast.parse(data, filename=file.name).body:
        if not isinstance(node,(ast.ClassDef,ast.FunctionDef)): continue
        entries = [('typing.'+node.name,node)] if file.name == 'typing.py' else [('test.test_typing.'+node.name+'.'+f.name,f) for f in node.body if isinstance(node,ast.ClassDef) and isinstance(f, ast.FunctionDef)]
        for key,fn in entries:
            lo = min([fn.lineno]+[d.lineno for d in fn.decorator_list]); hi = fn.end_lineno
            locations[key] = {'path': 'Lib/'+('test/' if file.name=='test_typing.py' else '')+file.name, 'lines':[lo,hi], 'source_sha256': digest(b''.join(lines[lo-1:hi]))}

groups={};rows={}
def group(label, head, parent, pr, merge, scope, evidence):
    groups[label] = dict(tested_imre=head,tested_parent=parent,pr=pr,public_squash=merge,selection=scope,raw=evidence,runs={})
def record(g,mode,exit_code, ids,kind,**other):
    assert len(ids)==len(set(ids))
    groups[g]['runs'][mode]={'process_exit':exit_code,'paired_pass_ids':ids,'evidence':kind,**other}
    for name in ids:
        key=(name,1); ordinal,st=ordinals[key]; assert st['status']=='pass' and occ[name]==1
        if key not in rows:
            rows[key]={'id':name,'occurrence':1,'stock_ordinal':ordinal,'stock_status':st['status'],'stock_skip_reason':st.get('reason'),'group':g,'source':locations[name], 'profiles':{}}
        assert rows[key]['group']==g
        rows[key]['profiles'][mode]={'status':'pass','original_group_process_exit':exit_code,'skip_reason':None}

g='sets';z=archive('sets-1791943.tgz');sj=json.loads(z['set-receipt-paired.json'])
group(g,sj['candidate'],sj['base'],4162,'cde7ceaaed82be579cc60e2f97b15050c14cf061','Six original CollectionsAbcTests methods instantiated from the intact upstream test_typing.py.','raw/sets-1791943.tgz')
for m,prefix in zip(MODES[:3],['stock-final','ordinary-O0','ordinary-O3']):
    lines=z[f'logs/{prefix}.stdout'].splitlines(); ev=[ast.literal_eval(s.removeprefix('TYPING_EVENT ')) for s in lines if s.startswith('TYPING_EVENT ')]
    labels={s[1] for s in ev}; ids=[s[1] for s in ev if s[0]=='PASS'];rc=int(z[f'logs/{prefix}.exit']);assert rc==0 and len(ids)==6 and set(ids)==labels
    for name in ids: assert [v[0] for v in ev if v[1]==name]==['START','PASS','STOP']
    record(g,m,rc,ids,'Explicit original parent START/PASS/STOP.',tests_run=6,failures=0,errors=0,skips=0)
assert set(rows)==c-b

g='helpers';z=archive('helpers-4559296.tgz');hj=json.loads(z['final-qualification.json']);group(g,hj['imre_head'],hj['imre_base'],4154,'f1392e99157962263f8b776730ac877bf45abda9','Two live finder-selected CPython documentation tests with six and nine original examples.','raw/helpers-4559296.tgz')
for m in MODES:
    st=m=='stock';out=z['original.stock.out' if st else f'final/{m}/original.out'];err=z['original.stock.err' if st else f'final/{m}/original.err']; rc=0 if st else int(z[f'final/{m}/original.rc']); ids=re.findall(r'^ORIGINAL (\S+) \d+$',out,re.M)
    assert rc==0 and ids==['typing.get_args','typing.get_origin'] and 'RESULT 2 0 0 0' in out and err.rstrip().endswith('OK') and 'Ran 2 tests' in err
    record(g,m,rc,ids,'Selected two unique live IDs; runner passed both without skips, errors or failures. Explicit parent STOP was not recorded.',test_count=2,finder_count=int(re.search(r'DISCOVERED (\d+)',out)[1]),raw_exit_record='native original.rc' if not st else 'stock original process completed successfully; archive records RESULT and OK')

g='aggregate_docs';p=RAW/'named-docs';head=(p/'provenance.txt').read_text().splitlines()[1];assert head=='935cf6db407d04b9d0f08411fa1fc98922e7680e'
group(g,head,'6574267b2b4043988d28a8a013d36353dcba2c16',4169,'eaae6bc48b63c29a2d441d3279a4c59051c91fb2','Fresh, unfiltered DocTestSuite(typing); four new original IDs passed inside an aggregate that failed on 705 in both native modes.','raw/named-docs/')
docs=['typing._should_unflatten_callable_args','typing.get_protocol_members','typing.is_protocol','typing.is_typeddict']
for m in MODES[:3]:
    out=(p/(m+'.stdout')).read_text();err=(p/(m+'.stderr')).read_text();rc=int((p/(m+'.exit')).read_text());passed=re.findall(r'^PASS (\S+)$',out,re.M);failed=re.findall(r'^FAIL (\S+)',out,re.M);disc=re.findall(r'^DISCOVERED (\S+)',out,re.M);ids=[i for i in passed if i in docs];assert ids==docs
    assert all('START '+i+'\n' in out for i in ids) and not re.search(r'^(ERROR|SKIP) ',out,re.M)
    if m=='stock': assert rc==0 and len(disc)==len(passed)==11 and not failed
    else: assert rc==1 and len(disc)==8 and len(passed)==7 and failed==['typing.TypedDict'] and 'NotImplementedError: runtime source: StmtAnnAssign' in err and set(passed)-set(ids)=={k for k,n in b if k.startswith('typing.ParamSpec')}
    record(g,m,rc,ids,'Mid-run parent START/PASS for these four. No STOP observer; the aggregate exit is preserved.',discovered=disc,all_pass_ids=passed,all_fail_ids=failed,skips=0,errors=0)

g='typeddict';z=archive('typeddict-c29335c.tgz');prov=z['bin/provenance.txt'].splitlines();group(g,prov[1],prov[2],4192,'39b49bfc4e64c7a0a67f01de084d1ab173534cc6','Single finder-selected typing.TypedDict testcase with all four pinned examples.','raw/typeddict-c29335c.tgz')
for m,sub in zip(MODES[:3],['stock','ordinary0','ordinary3']):
    prefix='qualification/'+sub+'/';out=z[prefix+'original.stdout'];rc=int(z[prefix+'original.rc']);assert rc==0 and out==z['qualification/stock/original.stdout'] and len(re.findall('^EXAMPLE ',out,re.M))==4 and out.endswith('START typing.TypedDict\nPASS typing.TypedDict\nSTOP typing.TypedDict\nRESULT 1 0 0 0\n')
    record(g,m,rc,['typing.TypedDict'],'Explicit original START/PASS/STOP, all four exact source/want pairs.',tests_run=1,failures=0,errors=0,skips=0)

g='concrete';z=archive('concrete-04f03565.tgz');q='concrete-logs/';cj=json.loads(z[q+'summary.json']);methodsrc=json.loads(z[q+'method-source.json']);group(g,cj['patch'],cj['parent'],4182,None,'Six unchanged CollectionsAbcTests method bodies staged with their original qualified IDs, followed by concrete-alias semantic controls.','raw/concrete-04f03565.tgz')
groups[g]['branch_at_capture']='998ff230c75a549a5fbb00aff563d52043c41b3b';groups[g]['branch_note']='These results were recorded at 04f03565. A later merge of main on the PR branch is not credited by these runs.'
for m in MODES:
    pre='stock-positive' if m=='stock' else 'candidate-'+m+'.positive';out=z[q+pre+'.stdout'];err=z[q+pre+'.stderr'];rc=int(z[q+pre+'.exit']);reg=re.findall(r'^REGISTERED_ID (\S+)$',out,re.M);ok=re.findall(r'^[^\n]+ \(([^()\n]+)\) \.\.\. ok$',err,re.M);assert rc==0 and len(ok)==6 and reg==ok and set(ok)==set(methodsrc) and 'TEST_COUNTS 6 0 0 0' in out
    for name in ok: assert locations[name]['source_sha256']==methodsrc[name]['sha256']
    record(g,m,rc,ok,'Registered original IDs each appear as ok in unittest; suite counts have zero failures/errors/skips. STOP callbacks were not logged.',tests_run=6,failures=0,errors=0,skips=0)
groups[g]['other_process_exits']={k:v['exit'] for k,v in {**cj['profiles'],**cj['controls']}.items() if 'wrong' in k or k.startswith('base-')}

extra=set(rows); allkeys=extra|b; assert len(extra)==19 and extra.isdisjoint(b) and extra.isdisjoint(a) and len(extra-(c-b))==13 and len(allkeys)==167
for key,row in rows.items(): assert all(m in row['profiles'] for m in MODES[:3])
counts=Counter(mode for row in rows.values() for mode in row['profiles']); assert dict(counts)==dict(zip(MODES,[19,19,19,8,8]))
ledger={'schema':'imre.named-paired-supplement.v1','upstream':CP,'denominator':712,'whole':False,'historical_unidentified_floor':107,'baseline_immutable_ledger_size':148,'prior_129_to_148_capsule_sha256':'1f8a5f42236bb18c8e5eb408062a792d481724d4e408a0a544d786badb493ed2','input_ledgers':{str(n):{'filename':p.name,'sha256':digest(p.read_bytes()),'unique_keys':len(keys(j))} for n,(p,j) in sorted(inputs.items())},'stock_ordered_outcomes_sha256':digest((INPUT/'stock-pinned.jsonl').read_bytes()),'source_file_sha256':file_sha,'additional_pairs_after_148':19,'additional_pairs_after_154':13,'overlap_with_129':[],'overlap_with_148':[],'overlap_with_154':sorted(extra & c),'profile_pass_counts_for_19':dict(counts),'coordinator_unkeyed_14':{'contribution_counted':0,'overlap':'unknown; source keys unavailable'},'union_pairs':len(allkeys),'groups':groups,'additional_keys':sorted(extra),'details':sorted(rows.values(),key=lambda x:x['stock_ordinal']),'keys':sorted(allkeys)}
(ROOT/'ledger-typing-intact-worker-167.json').write_text(json.dumps(ledger,indent=2)+'\n')
print(f'{len(extra)} additions, {len(extra-c)} beyond 154, {len(allkeys)} distinct named keys. Profile pass counts {dict(counts)}.')
