import doctest
import sys
import typing
import unittest

class Events(unittest.TextTestResult):
    def startTest(self, case):
        print("START", case.id(), flush=True)
        super().startTest(case)

    def addSuccess(self, case):
        super().addSuccess(case)
        print("PASS", case.id(), flush=True)

    def addError(self, case, exc):
        super().addError(case, exc)
        print("ERROR", case.id(), repr(exc[1]), flush=True)

    def addFailure(self, case, exc):
        super().addFailure(case, exc)
        print("FAIL", case.id(), repr(exc[1]), flush=True)

    def addSkip(self, case, reason):
        super().addSkip(case, reason)
        print("SKIP", case.id(), repr(reason), flush=True)

suite = doctest.DocTestSuite(typing)
for case in suite:
    print("DISCOVERED", case.id(), flush=True)
outcome = unittest.TextTestRunner(verbosity=2, resultclass=Events).run(suite)
print("RUNNER_COUNT", outcome.testsRun, flush=True)
sys.exit(0 if outcome.wasSuccessful() else 1)
