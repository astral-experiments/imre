cwd=/workspace/scratch/callable-alias-study/stage
IMREFLAGS=--no-cache\ --clang\ /workspace/scratch/intact/tools/usr/bin/clang-19\ --runtime\ /workspace/scratch/callable-alias-study/current.a\ --opt-level\ 3
/workspace/scratch/collector-public-29340423/target/debug/imre -B -m qualified 
