import sys
import typing
from typing import TypeAliasType
from test.typinganndata import mod_generics_cache as fixture
from statement_control import current

for name in ('Alias', 'OldStyle'):
    alias = getattr(fixture, name)
    assert type(alias) is TypeAliasType
    assert alias.__name__ == name and alias.__module__ == fixture.__name__
    assert alias.__parameters__ == alias.__type_params__ == ()
    assert alias.__value__ is int
    print(name, alias.__module__, alias.__value__, flush=True)

payload = []
eager = typing.TypeAliasType('Eager', payload)
assert eager.__value__ is payload and eager.evaluate_value(1) is payload
assert eager.evaluate_value is not eager.evaluate_value
assert not hasattr(eager, '__qualname__') and eager.__reduce__() == 'Eager'
assert TypeAliasType(name='N', value=None, type_params=()).__value__ is None
try:
    TypeAliasType(1, int)
except TypeError as e:
    assert str(e) == "typealias() argument 'name' must be str, not int"
else:
    raise AssertionError('accepted an integer name')
current()
if 'wrong' in sys.argv:
    assert eager.__value__ is not payload
print('verified eager alias', flush=True)
