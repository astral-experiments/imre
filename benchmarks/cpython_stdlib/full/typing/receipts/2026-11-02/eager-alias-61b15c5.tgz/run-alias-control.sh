#!/bin/bash
set -eu
root=/workspace/scratch/intact
level=$1
label=$2
runtime=$3
cd "$root/alias-stage"
stem="$root/logs/eager-alias/$label-O$level"
bin=/workspace/scratch/public-fe7af98c/imre
args=(build alias_suite.py --module-root "$PWD" --no-cache --runtime-imports --opt-level "$level" --runtime "$runtime" --clang "$root/tools/usr/bin/clang-19" -o "$stem.exe")
printf '%q ' "$bin" "${args[@]}" > "$stem.cmd"; echo >> "$stem.cmd"
rc=0; timeout 1600 "$bin" "${args[@]}" > "$stem.build.stdout" 2> "$stem.build.stderr" || rc=$?; echo "$rc" > "$stem.build.exit"
if test "$rc" != 0; then tail -9 "$stem.build.stderr"; exit "$rc"; fi
for mode in positive wrong; do
  rc=0; timeout 150 "$stem.exe" "$mode" > "$stem.$mode.stdout" 2> "$stem.$mode.stderr" || rc=$?
  echo "$rc" > "$stem.$mode.exit"; cat "$stem.$mode.stdout"; tail -4 "$stem.$mode.stderr"
done
