from test.typinganndata import mod_generics_cache as target
from typing import TypeAliasType

for name in ('Alias', 'OldStyle'):
    value = getattr(target, name)
    assert type(value) is TypeAliasType
    assert value.__name__ == name
    assert value.__module__ == target.__name__
    assert value.__type_params__ == ()
    assert value.__value__ is int
    print(name, value.__module__, value.__value__, flush=True)
