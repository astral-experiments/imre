from typing import TypeAliasType

OldStyle = TypeAliasType("OldStyle", int)
assert type(OldStyle) is TypeAliasType
assert OldStyle.__name__ == 'OldStyle'
assert OldStyle.__value__ is int
assert OldStyle.__module__ == __name__
assert OldStyle.__type_params__ == ()
assert OldStyle.__reduce__() == 'OldStyle'
print('PASS', OldStyle.__module__, OldStyle.__name__, OldStyle.__value__, flush=True)
