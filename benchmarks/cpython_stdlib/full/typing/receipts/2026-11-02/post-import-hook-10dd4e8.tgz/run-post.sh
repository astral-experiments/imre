#!/bin/bash
set -u
cd /workspace/scratch/predicate-stage/post-intact-doctests
revision=$1
imre=$2
archive=$3
opt=$4
out=$revision-ordinary-O$opt
mkdir -p "$out"
clang=/workspace/scratch/intact/tools/usr/bin/clang-19
export IMREFLAGS="--no-cache --clang $clang --runtime $archive --opt-level $opt"
printf 'IMREFLAGS=%q %q -B -m post_doctests\n' "$IMREFLAGS" "$imre" > "$out/cmd"
"$imre" -B -m post_doctests > "$out/stdout" 2> "$out/stderr"; rc=$?
echo "$rc" > "$out/exit"
cat "$out/stdout" "$out/stderr"
exit "$rc"
