import unittest
from test import test_typing

print("IMPORT_OK", test_typing.__name__, flush=True)
# The original load_tests hook appends its real DocTestSuite to the supplied suite.
suite = test_typing.load_tests(unittest.TestLoader(), unittest.TestSuite(), None)
print("DISCOVERED", suite.countTestCases(), flush=True)
for test in suite:
    print("ID", test.id(), flush=True)
