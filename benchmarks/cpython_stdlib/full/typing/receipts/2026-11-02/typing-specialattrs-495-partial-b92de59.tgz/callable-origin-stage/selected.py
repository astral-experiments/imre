import sys
import unittest
from test import test_typing


class Results(unittest.TextTestResult):
    def startTest(self, case):
        print("START", case.id(), flush=True)
        super().startTest(case)

    def addSuccess(self, case):
        print("PASS", case.id(), flush=True)
        super().addSuccess(case)

    def addError(self, case, err):
        print("ERROR", case.id(), err[0].__name__, str(err[1]), flush=True)
        super().addError(case, err)

    def addFailure(self, case, err):
        print("FAIL", case.id(), err[0].__name__, str(err[1]), flush=True)
        super().addFailure(case, err)

    def addSkip(self, case, reason):
        print("SKIP", case.id(), reason, flush=True)
        super().addSkip(case, reason)

    def addSubTest(self, case, subtest, err):
        if err is None:
            print("SUB_OK", subtest.id(), flush=True)
        else:
            print("SUB_ERR", subtest.id(), err[0].__name__, str(err[1]), flush=True)
        super().addSubTest(case, subtest, err)

    def stopTest(self, case):
        print("STOP", case.id(), flush=True)
        super().stopTest(case)


suite = unittest.TestSuite([
    test_typing.SpecialAttrsTests("test_special_attrs"),
    test_typing.TypingCallableTests("test_basic"),
])
print("COUNT", suite.countTestCases(), flush=True)
result = unittest.TextTestRunner(verbosity=2, descriptions=False, resultclass=Results).run(suite)
print("RAN", result.testsRun, flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
