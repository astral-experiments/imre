from pathlib import Path
import json, os, subprocess, sys, time
root=Path(__file__).resolve().parent
stage=root/'callable-origin-stage'
logs=root/'callable-origin-logs'
label,binary,runtime,level=sys.argv[1:]
assert level in {'0','3'}
assert set(label)<=set('abcdefghijklmnopqrstuvwxyz0123456789-')
cmd=[binary,'-B','-m','selected']
env={**os.environ,'IMREFLAGS':f'--no-cache --runtime {runtime} --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --opt-level {level}','PYTHONDONTWRITEBYTECODE':'1'}
dest=logs/f'{label}-O{level}'
Path(str(dest)+'.argv').write_text(json.dumps(dict(argv=cmd,IMREFLAGS=env['IMREFLAGS'],cwd=str(stage)))+'\n')
with Path(str(dest)+'.stdout').open('wb') as out, Path(str(dest)+'.stderr').open('wb') as err:
    start=time.monotonic()
    try: rc=subprocess.run(cmd,cwd=stage,env=env,stdout=out,stderr=err,timeout=2400).returncode
    except subprocess.TimeoutExpired: rc=124
Path(str(dest)+'.result').write_text(json.dumps(dict(exit_code=rc,seconds=round(time.monotonic()-start,3)))+'\n')
print(label,rc,flush=True)
