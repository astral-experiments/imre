import inspect
import types
import typing
from typing import get_args, get_origin
import doctest
import sys
import unittest

def control():
    assert typing.__dict__["Union"] is type(int | str)
    for fn in (get_args, get_origin):
        print("DOC",fn.__name__,repr(fn.__doc__),flush=True)
    for fn, name in ((get_args, "get_args"), (get_origin, "get_origin")):
        assert fn is getattr(typing, name)
        assert type(fn) is types.FunctionType
        assert fn.__module__ == "typing" and fn.__name__ == fn.__qualname__ == name
        assert str(inspect.signature(fn)) == "(tp)"
        assert fn.__doc__.startswith("Get ") and ">>>" in fn.__doc__
        for args, kwargs in [((), {}), ((int, str), {}), ((), {"value": int})]:
            try:
                fn(*args, **kwargs)
            except TypeError:
                pass
            else:
                raise AssertionError("invalid arguments accepted")

    value = list[int]
    assert get_origin(tp=value) is list and get_args(tp=value) == (int,)
    assert typing.get_origin(value) is list and typing.get_args(value) == (int,)
    assert get_origin(object()) is None and get_args(object()) == ()

    p = typing.ParamSpec("P")
    assert get_origin(p.args) is p
    assert get_args(typing.Callable[[int], str]) == ([int], str)
    print("CONTRACT", flush=True)

def original():
    suite = doctest.DocTestSuite(typing)
    print("DISCOVERED", suite.countTestCases(), flush=True)
    selected = unittest.TestSuite()
    for case in suite:
        if case.id() in ("typing.get_args", "typing.get_origin"):
            print("ORIGINAL",case.id(),len(case._dt_test.examples),flush=True)
            selected.addTest(case)
    result = unittest.TextTestRunner(verbosity=2).run(selected)
    print("RESULT",result.testsRun,len(result.failures),len(result.errors),len(result.skipped),flush=True)

def observe():
    for func, name in ((get_args, "get_args"), (get_origin, "get_origin")):
        print("BINDING", name, getattr(typing, name) is func, type(func) is types.FunctionType, func.__module__, func.__name__, func.__qualname__, repr(func.__doc__), flush=True)
        try:
            print("SIG", name, str(inspect.signature(func)), flush=True)
        except BaseException as error:
            print("SIG_ERR", name, repr(error), flush=True)
        for argv, kw in [((), {}), ((int, str), {}), ((), {"value": int}), ((), {"tp": list[int]}), ((list[int],), {})]:
            try:
                result = func(*argv, **kw)
                print("CALL", name, repr(argv), repr(kw), repr(result), flush=True)
            except BaseException as error:
                print("CALL_ERR", name, repr(argv), repr(kw), type(error).__name__, str(error), flush=True)

if sys.argv[1] == "control":
    control()
elif sys.argv[1] == "observe":
    observe()
else:
    original()
