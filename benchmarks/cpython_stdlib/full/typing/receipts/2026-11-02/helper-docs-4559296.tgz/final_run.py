from pathlib import Path
import os, shlex, subprocess, sys, time

base=Path('/tmp/imre-doc-inventory')
binroot=Path('/workspace/scratch/typing-introspection-4559296-bin')
mode=sys.argv[1]
while not (base/'final.sha256').is_file():
    if (base/'final-build.log').exists() and 'error: could not compile' in (base/'final-build.log').read_text():
        sys.exit('final cargo build failed')
    time.sleep(4)
for opt in (0,3):
    row=base/'final'/f'{mode}-O{opt}';row.mkdir(exist_ok=True,parents=True)
    argv=[str(binroot/'imre'),'build',str(base/'final-stage/driver.py'),'--module-root',str(base/'final-stage'),'--no-cache','--clang','/workspace/scratch/intact/tools/usr/bin/clang-19','--runtime',str(binroot/'libimre_runtime.a'),'--opt-level',str(opt)]
    if mode=='boxed': argv.append('--runtime-imports')
    argv.extend(['-o',str(row/'program')]); (row/'build.argv').write_text(shlex.join(argv)+'\n')
    calls={'build':argv,'original':[str(row/'program'),'original'],'control':[str(row/'program'),'control'],'observe':[str(row/'program'),'observe']}
    for scenario, args in calls.items():
        (row/f'{scenario}.start').write_text(time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())+'\n')
        with (row/f'{scenario}.out').open('wb') as out, (row/f'{scenario}.err').open('wb') as err:
            rc = subprocess.run(args, env={**os.environ,'TMPDIR':str(base)}, stdout=out, stderr=err).returncode
        (row/f'{scenario}.rc').write_text(str(rc)+'\n')
        if scenario=='build' and rc: break
