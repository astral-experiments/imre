from collections.abc import Callable
from types import GenericAlias
from typing import List


class DirectoryOrigin(tuple):
    visible = 42


for item in (GenericAlias(DirectoryOrigin, (int,)), Callable[..., int], List[int]):
    names = dir(item)
    assert "__args__" in names and "__parameters__" in names and "__origin__" in names
assert "visible" in dir(GenericAlias(DirectoryOrigin, (int,)))
assert "visible" in dir(DirectoryOrigin())
print("CONTROL PEP 585 alias, typing alias and tuple origin", flush=True)

from test import test_typing
import unittest
import sys

print("IMPORT", test_typing.__name__, flush=True)
class Events(unittest.TextTestResult):
    def startTest(self, case):
        print("START", case.id(), flush=True)
        super().startTest(case)
    def stopTest(self, case):
        print("STOP", case.id(), flush=True)
        super().stopTest(case)
    def addSubTest(self, case, subtest, error):
        print("SUBTEST", subtest.id(), "PASS" if error is None else str(error[1]), flush=True)
        super().addSubTest(case, subtest, error)
    def addSuccess(self, case):
        print("PASS", case.id(), flush=True)
        super().addSuccess(case)
    def addFailure(self, case, err):
        print("FAIL", case.id(), str(err[1]), flush=True)
        super().addFailure(case, err)
    def addError(self, case, err):
        print("ERROR", case.id(), str(err[1]), flush=True)
        super().addError(case, err)
    def addSkip(self, case, reason):
        print("SKIP", case.id(), reason, flush=True)
        super().addSkip(case, reason)
suite = unittest.TestSuite()
for case in unittest.defaultTestLoader.loadTestsFromTestCase(test_typing.CollectionsCallableTests):
    if case._testMethodName == "test_dir":
        suite.addTest(case)
print("CASES", suite.countTestCases(), flush=True)
result = unittest.TextTestRunner(verbosity=2, descriptions=False, resultclass=Events).run(suite)
sys.exit(0 if result.testsRun == 1 and result.wasSuccessful() else 1)
