cwd=/workspace/scratch/callable-alias-study/stage
IMREFLAGS=''
/tmp/imre-stock/build/python -B -m dir_final 
