import fcntl, json, os, shutil, subprocess, sys, time
from pathlib import Path
r=Path('/tmp/imre-concat-review')
comp=r/'target/debug/imre'
runtime=r/'target/debug/libimre_runtime.a'
clang='/workspace/scratch/intact/tools/usr/bin/clang-19'
def run(args,src,p):
    started=time.monotonic()
    with Path(str(p)+'.out').open('wb') as out, Path(str(p)+'.err').open('wb') as err:
        try:rc=subprocess.run(list(map(str,args)),cwd=src,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err,timeout=720).returncode
        except subprocess.TimeoutExpired:rc=124
    Path(str(p)+'.json').write_text(json.dumps(dict(argv=list(map(str,args)),returncode=rc,seconds=round(time.monotonic()-started,3)))+'\n')
    return rc
group=r/'positive'
shutil.copytree(r/'named',group,dirs_exist_ok=True)
for suite in ('named','fixture','independent'):
    shutil.copyfile(r/suite/'run.py', group/(suite+'_probe.py'))
(group/'driver.py').write_text("""import sys
if sys.argv[1] == 'named':
    import named_probe
elif sys.argv[1] == 'fixture':
    import fixture_probe
elif sys.argv[1] == 'independent':
    import independent_probe
else:
    raise ValueError('unknown probe')
""")
lock=(r/(sys.argv[1]+'.lock')).open('a')
fcntl.flock(lock,fcntl.LOCK_EX)
for mode in (sys.argv[1],):
 for lev in sys.argv[2:]:
  for src,entry,suites in [(group,'driver.py',('named','fixture','independent')), (r/'inverse','run.py',('inverse',))]:
    out=r/'receipts'/(mode+lev)
    out.mkdir(parents=True,exist_ok=True)
    if src.name=='inverse' and os.environ.get('POSITIVE_ONLY'):
        continue
    if all((out/x/'run.json').exists() or (out/x/'build.json').exists() for x in suites):
        continue
    if all((out/(x+'.json')).exists() for x in suites):
        continue
    build_receipt=out/(src.name+'-build.json')
    if build_receipt.exists() and json.loads(build_receipt.read_text())['returncode']:
        continue
    program=out/(src.name+'.bin')
    args=[comp,'build',src/entry,'--no-cache','--module-root',src,'--runtime',runtime,'--clang',clang,'--opt-level',lev,'-o',program]
    if mode=='boxed':args.append('--runtime-imports')
    rc=run(args,src,out/(src.name+'-build'))
    print(mode,lev,src.name,'build',rc,flush=True)
    if rc:continue
    for suite in suites:
        rc=run([program,suite],src,out/suite)
        print(mode,lev,suite,'run',rc,flush=True)
    program.unlink()
