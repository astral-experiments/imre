import sys
if sys.argv[1] == 'named':
    import named_probe
elif sys.argv[1] == 'fixture':
    import fixture_probe
elif sys.argv[1] == 'independent':
    import independent_probe
else:
    raise ValueError('unknown probe')
