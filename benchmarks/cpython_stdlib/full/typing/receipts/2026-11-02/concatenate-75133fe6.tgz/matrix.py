import json, os, subprocess, sys
from pathlib import Path
r=Path('/tmp/imre-concat-review')
clang='/workspace/scratch/intact/tools/usr/bin/clang-19'
compiler=r/'target/debug/imre'
archive=r/'target/debug/libimre_runtime.a'
stock='/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
def proc(args,src,p):
    with open(str(p)+'.out','wb') as out, open(str(p)+'.err','wb') as err:
        rc=subprocess.run([str(s) for s in args],cwd=src,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err,timeout=600).returncode
    Path(str(p)+'.json').write_text(json.dumps({'argv':list(map(str,args)),'returncode':rc})+'\n')
    return rc
for mode in sys.argv[1:]:
  for lev in ([''] if mode=='stock' else ['0','3']):
    for suite in ('named','fixture','independent','inverse'):
        src=r/suite
        log=r/'receipts'/(mode+lev)/suite
        log.mkdir(parents=True,exist_ok=True)
        if mode=='stock':
            args=[stock,'-B',src/'run.py']
        else:
            b=[compiler,'build',src/'run.py','--no-cache','--clang',clang,'--module-root',src,'--runtime',archive,'--opt-level',lev,'-o',log/'program']
            if mode=='boxed': b.append('--runtime-imports')
            rc=proc(b,src,log/'build')
            print(mode,lev,suite,'build',rc,flush=True)
            if rc:continue
            args=[log/'program']
        rc=proc(args,src,log/'run')
        print(mode,lev,suite,'run',rc,flush=True)
        (log/'program').unlink(missing_ok=True)
