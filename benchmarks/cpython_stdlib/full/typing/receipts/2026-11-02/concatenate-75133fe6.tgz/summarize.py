import hashlib,json,re,sys,tarfile
from pathlib import Path
r=Path('/tmp/imre-concat-review')
result={}
for tag in ['stock','ordinary0','ordinary3','boxed0','boxed3']:
    profile=r/'receipts'/tag
    result[tag]={}
    for suite in ('named','fixture','independent','inverse'):
        f=(profile/suite/'run' if tag=='stock' else profile/suite)
        if not f.with_suffix('.json').exists(): continue
        record=json.loads(f.with_suffix('.json').read_text())
        stdout=f.with_suffix('.out').read_text()
        stderr=f.with_suffix('.err').read_text()
        if suite in ('named','inverse'):
          record['starts']=re.findall(r'^START (\S+)',stdout,re.M)
          record['passes']=re.findall(r'^PASS (\S+)',stdout,re.M)
          record['skips']=re.findall(r'^SKIP (.+)',stdout,re.M)
          record['failures']=re.findall(r'^FAIL: (.+)',stderr,re.M)
        result[tag][suite]=record
(r/'status.json').write_text(json.dumps(result,indent=2)+'\n')
if sys.argv[1:]:
    archive=r/sys.argv[1]
    with tarfile.open(archive,'w:gz') as t:
        for f in [r/'provenance.txt', r/'port-revisions.txt',r/'native-shas.txt',r/'public-fixture.py',r/'matrix.py',r/'qualified.py',r/'status.json',r/'build.log',r/'build-merge.log',r/'merge-revision.txt',r/'port.patch',r/'summarize.py']:
            t.add(f,arcname=f.name)
        for group in ('named','inverse','fixture','independent','positive','receipts'):
            for f in (r/group).rglob('*'):
                if f.is_file() and not f.name.endswith(('.bin','.pyc')):t.add(f,arcname=f.relative_to(r))
    print(archive,hashlib.sha256(archive.read_bytes()).hexdigest())
for tag,cases in result.items():print(tag,[(k,v['returncode']) for k,v in cases.items()])
