import typing
from collections import abc
from typing import Concatenate, ParamSpec

assert typing.Concatenate is Concatenate
P = ParamSpec('P')
Q = ParamSpec('Q')
pre = Concatenate[str, P]
assert pre.__origin__ is Concatenate
assert pre.__parameters__ == (P,)
for form in (typing.Callable, abc.Callable):
    f = form[pre, bool]
    assert f[[float, bytes]] == form[[str, float, bytes], bool]
    assert f[Q] == form[Concatenate[str, Q], bool]
try:
    Concatenate[int, str]
except TypeError as exc:
    assert str(exc) == 'The last parameter to Concatenate should be a ParamSpec variable or ellipsis.'
else:
    raise AssertionError('invalid tail was accepted')
print('Concatenate validated, substituted, and preserved its ParamSpec')
