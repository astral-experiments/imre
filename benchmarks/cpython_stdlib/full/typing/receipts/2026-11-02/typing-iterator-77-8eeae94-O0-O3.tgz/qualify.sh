set -eu
w=/workspace/scratch/awaitable-53/iterator-77
while ! test -s "$w/bin/provenance.txt"; do if rg -q '^error' "$w/bin/build.log"; then exit 1; fi; sleep 5; done
cd "$w/selected-stage"
for level in 0 3; do
  row=$w/qualification/ordinary-O$level; mkdir -p "$row"; export TMPDIR=$row IMREFLAGS="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $w/bin/libimre_runtime.a --opt-level $level"; printf 'IMREFLAGS=%q %q -B -m verify_iterator\n' "$IMREFLAGS" "$w/bin/imre" > "$row/cmd"; rc=0; "$w/bin/imre" -B -m verify_iterator > "$row/stdout" 2> "$row/stderr" || rc=$?; echo "$rc" > "$row/rc"; if test "$rc" != 0; then exit "$rc"; fi; cmp "$w/qualification/stock.stdout" "$row/stdout"
done
