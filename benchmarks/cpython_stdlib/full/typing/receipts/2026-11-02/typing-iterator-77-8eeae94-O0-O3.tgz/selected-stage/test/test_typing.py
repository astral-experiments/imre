import typing
from unittest import TestCase

class BaseTestCase(TestCase):

    def clear_caches(self):
        for f in typing._cleanups:
            f()


class CollectionsAbcTests(BaseTestCase):
    def test_iterator(self):
        it = iter([])
        self.assertIsInstance(it, typing.Iterator)
        self.assertNotIsInstance(42, typing.Iterator)
