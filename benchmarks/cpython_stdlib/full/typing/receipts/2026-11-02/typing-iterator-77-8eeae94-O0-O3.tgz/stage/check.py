import collections.abc as abc
import typing

class Structural:
    def __iter__(self): return self
    def __next__(self): raise StopIteration

class DisabledNext:
    def __iter__(self): return self
    __next__ = None

def observation(label, fn):
    try:
        print(label,repr(fn()),flush=True)
    except BaseException as exc:
        print(label,'ERROR',type(exc).__name__,str(exc),flush=True)

observation('origin', lambda: typing.get_origin(typing.Iterator) is abc.Iterator)
observation('parameterized-origin', lambda: typing.get_origin(typing.Iterator[int]) is abc.Iterator)
observation('parameterized-args', lambda: typing.get_args(typing.Iterator[int]) == (int,))
observation('list-iter-type', lambda: type(iter([])).__name__)
for name, value in [('list-iter',iter([])),('tuple-iter',iter(())),('structural',Structural()),('disabled',DisabledNext()),('int',42)]:
    observation(name+'-typing',lambda: isinstance(value,typing.Iterator))
    observation(name+'-abc',lambda: isinstance(value,abc.Iterator))
    observation(name+'-abc-subclass',lambda: issubclass(type(value),abc.Iterator))
    observation(name+'-abc-hook',lambda: abc.Iterator.__subclasshook__(type(value)))
    observation(name+'-has-iter',lambda: hasattr(type(value),'__iter__'))
    observation(name+'-has-next',lambda: hasattr(type(value),'__next__'))
