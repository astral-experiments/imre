"""Rebuild the post-167 named ledger using Python 3.14+ and only this capsule."""
from collections import Counter, defaultdict
from pathlib import Path
import ast, hashlib, json, sys

root = Path(__file__).resolve().parent
basefile = root / "input/ledger-typing-intact-worker-167.json"
stockfile = root / "input/stock-pinned.jsonl"
srcfile = root / "input/test_typing.py"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
baseline = json.loads(basefile.read_text())
assert sha(basefile) == "e7d4f96c5c8cd7be18fd2bf2972e19177c4ca20f23ef068d3d8124f530354882"
assert sha(stockfile) == baseline["stock_ordered_outcomes_sha256"]
assert sha(srcfile) == baseline["source_file_sha256"]["test_typing.py"]
assert baseline["upstream"] == "5607950ef232dad16d75c0cf53101d9649d89115"
prior = {tuple(k) for k in baseline["keys"]}
assert len(prior) == len(baseline["keys"]) == baseline["union_pairs"] == 167
ordered = [json.loads(line) for line in stockfile.read_text().splitlines()]
assert len(ordered) == 712
counts = Counter()
stock = {}
id_to_keys = defaultdict(list)
for ordinal, row in enumerate(ordered,1):
    case_id = row["id"]
    counts[case_id] += 1
    key = (case_id,counts[case_id])
    stock[key] = (ordinal,row)
    id_to_keys[case_id].append(key)

src = srcfile.read_text()
lines = src.splitlines(keepends=True)
klass = next(node for node in ast.parse(src).body if isinstance(node,ast.ClassDef) and node.name == "CollectionsAbcTests")
def source_of(case_id):
    method = next(m for m in klass.body if isinstance(m,(ast.FunctionDef,ast.AsyncFunctionDef)) and m.name == case_id.rsplit(".",1)[-1])
    first = min([method.lineno] + [d.lineno for d in method.decorator_list])
    raw = "".join(lines[first-1:method.end_lineno])
    return dict(path="Lib/test/test_typing.py",lines=[first,method.end_lineno],source_sha256=hashlib.sha256(raw.encode()).hexdigest())

def parse(directory,profile):
    p = directory/(profile+".stdout")
    statuses,starts,rc = {},[],json.loads((directory/(profile+".result")).read_text())["exit_code"]
    event_lines = p.read_text().splitlines()
    for line in event_lines:
        event,space,rest = line.partition(" ")
        if event == "START":
            assert space and len(id_to_keys[rest]) == 1, ("unresolved repeated stock ID", rest)
            starts.append(rest)
        elif event in ("PASS","ERROR","FAIL","SKIP"):
            case_id,_,message = rest.partition(" ")
            assert starts and starts[-1] == case_id and case_id not in statuses
            statuses[case_id] = dict(status=event.lower(),skip_reason=message if event=="SKIP" else None,original_group_process_exit=rc)
            if event in ("ERROR","FAIL"):statuses[case_id]["detail"]=message
    assert f"REGISTERED_COUNT {len(starts)}" in event_lines
    assert f"RUNNER_COUNT {len(starts)}" in event_lines
    assert len(starts) == len(statuses)
    return starts,statuses,dict(process_exit=rc,starts=len(starts),status_counts=dict(Counter(row["status"] for row in statuses.values())),
                              stdout_sha256=sha(p),stderr_sha256=sha(directory/(profile+".stderr")))

groups = ["abc"]
if "--bytestring" in sys.argv: groups.append("bytestring")
metadata,positive,negative = {},{},[]
for name in groups:
    folder = root/name
    meta = json.loads((folder/"group.json").read_text())
    observed = {}
    run_info = {}
    order = []
    for profile in ("stock","ordinary-O0","ordinary-O3"):
        started,observed[profile],run_info[profile] = parse(folder,profile)
        if not order: order=started
        assert order == started
    for case_id in order:
        key, = id_to_keys[case_id]
        ordinal,stock_row = stock[key]
        profiles = {profile:rows[case_id] for profile,rows in observed.items()}
        assert profiles["stock"]["status"]==stock_row["status"]
        row=dict(id=case_id,occurrence=key[1],stock_ordinal=ordinal,stock_status=stock_row["status"],
                 stock_skip_reason=stock_row.get("reason"),group=name,source=source_of(case_id),profiles=profiles)
        if not all(v["status"]=="pass" for v in profiles.values()):
            row["classification"]="excluded nonpositive"
            negative.append(row)
            continue
        row["classification"] = ("incidental existing implementation; newly measured paired key"
                                 if name=="abc" and ordinal==97 else "original method exercising changed behavior")
        assert key not in positive
        positive[key]=row
    meta["runs"]=run_info
    metadata[name]=meta
assert [r["stock_ordinal"] for r in negative]==[50]
assert all(negative[0]["profiles"][p]["status"]=="error" for p in ("ordinary-O0","ordinary-O3"))
assert len(positive) == (14 if "bytestring" in groups else 13)
assert all(metadata["abc"]["runs"][p]["process_exit"]==1 for p in ("ordinary-O0","ordinary-O3"))
if "bytestring" in groups:
    assert all(v["process_exit"]==0 for v in metadata["bytestring"]["runs"].values())
extra = set(positive)-prior
n = len(prior|extra)
assert n==(181 if "bytestring" in groups else 180)
doc=dict(schema="imre.named-paired-supplement.v1",upstream=baseline["upstream"],denominator=712,whole=False,
         historical_unidentified_floor=baseline["historical_unidentified_floor"],
         baseline_immutable_ledger_size=167,input_ledger={"filename":basefile.name,"sha256":sha(basefile),"unique_keys":len(prior)},
         source_file_sha256=baseline["source_file_sha256"],stock_ordered_outcomes_sha256=sha(stockfile),
         historical_floor_in_union=False,coordinator_unkeyed_14=baseline["coordinator_unkeyed_14"],
         measurement_scope="named selection of intact original methods; full-module discovery and historical unkeyed counts stay separate",
         groups=metadata,additional_pairs_after_167=len(extra),overlap_with_167=sorted(prior&positive.keys()),
         profile_pass_counts_for_additional={p:sum(row["profiles"][p]["status"]=="pass" for k,row in positive.items() if k in extra) for p in ("stock","ordinary-O0","ordinary-O3")},
         boxed_original_groups_measured=[],excluded_nonpositives=negative,
         additional_keys=sorted(extra),details=sorted(positive.values(),key=lambda x:x["stock_ordinal"]),
         union_pairs=n,keys=sorted(prior|extra))
out=root/f"ledger-typing-intact-worker-{n}.json"
out.write_text(json.dumps(doc,indent=2)+"\n")
print(out.name,sha(out),"base",len(prior),"added",len(extra),"overlap",len(positive.keys()&prior),"union",n)
