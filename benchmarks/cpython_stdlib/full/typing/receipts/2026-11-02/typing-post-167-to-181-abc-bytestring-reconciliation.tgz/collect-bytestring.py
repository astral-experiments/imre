"""Snapshot the ByteString original only after its O3 process has recorded its status."""
from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent
b=Path('/workspace/scratch/bytestring-check')
assert (b/'original-O3.exit').exists()
p=r/'bytestring';p.mkdir(exist_ok=True)
checked=(b/'provenance').read_text().splitlines()
assert checked[0]=='76e56136ef1aa6186c6d94e18241f7c4910e2fab'
assert hashlib.sha256((b/'test/test_typing.py').read_bytes()).hexdigest()==hashlib.sha256((r/'input/test_typing.py').read_bytes()).hexdigest()
for orig,profile in [('stock','stock'),('original-O0','ordinary-O0'),('original-O3','ordinary-O3')]:
    code=int((b/(orig+'.exit')).read_text().strip())
    assert code==0,(profile,code)
    s=(b/(orig+'.stdout')).read_text().splitlines()
    assert [line for line in s if line.startswith(('START ','PASS ','SKIP ','ERROR ','FAIL '))]==['START test.test_typing.CollectionsAbcTests.test_bytestring','PASS test.test_typing.CollectionsAbcTests.test_bytestring']
    assert s.count('RUNNER_COUNT 1')==1
    for file_ext in ('stdout','stderr'):
        shutil.copyfile(b/(orig+'.'+file_ext),p/(profile+'.'+file_ext))
    cmd=b/(orig+'.cmd')
    if cmd.exists():shutil.copyfile(cmd,p/(profile+'.cmd'))
    (p/(profile+'.result')).write_text(json.dumps({'exit_code':code})+'\n')
for n in ('discover_original.py','check_bytestring.py','boxed_typing_bytestring.py','provenance','merge-tree.log'):
    shutil.copyfile(b/n,p/n)
for c in sorted(b.glob('focus-*')):shutil.copyfile(c,p/c.name)
meta=dict(tested_imre=checked[0],tested_parent='989ea8d55df7793addf9e82a6351a621ef2c4b3a',public_squash='31f658fc5bff1bf1fb96abc9e2ebc51e864ce945',pr=4189,
          selection='Unmodified original ordinal 54 (CollectionsAbcTests.test_bytestring) from intact test/test_typing.py after independent focused controls.',
          measured_native_profiles=['ordinary-O0','ordinary-O3'],runtime_source_tree=checked[1],
          raw_provenance_sha256=hashlib.sha256((b/'provenance').read_bytes()).hexdigest())
(p/'group.json').write_text(json.dumps(meta,indent=2)+'\n')
