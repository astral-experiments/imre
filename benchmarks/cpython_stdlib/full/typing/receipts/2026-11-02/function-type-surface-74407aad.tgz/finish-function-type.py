from pathlib import Path
import hashlib, json, subprocess, sys, tarfile
r=Path(__file__).resolve().parent
logs=r/'function-type-logs'
e=r/'exports-logs'
raw=logs/'preflight-ordinary-O0.stdout'
base=e/'public-eaae6bc-O0.comparison.json'
subprocess.run([sys.executable,r/'compare-preflight.py',raw],check=True)
post=e/'preflight-ordinary-O0.comparison.json'
a,b=[json.loads(p.read_text()) for p in (base,post)]
old,new=[i['present_with_differences'] for i in (a,b)]
delta={
 'base_summary':{k:a[k] for k in ['denominator','observed_real_lookups','matched_metadata_and_bindings']},
 'candidate_summary':{k:b[k] for k in ['denominator','observed_real_lookups','matched_metadata_and_bindings']},
 'new_matches': sorted(set(old)-set(new)), 'regressed': sorted(set(new)-set(old)),
 'remaining_rows_changed': [n for n in sorted(set(old)&set(new)) if old[n]!=new[n]],
 'missing_before':a['missing_or_unobserved'], 'missing_after':b['missing_or_unobserved'],
 'original_upstream_case_credit': 0,
 'mode':'ordinary -B -m preflight O0 for base and candidate',
 'wildcard':'held pending complete genuine baseline',
}
(logs/'surface-delta.json').write_text(json.dumps(delta,indent=2)+'\n')
print(json.dumps({k:delta[k] for k in list(delta)[:5]},indent=2))
if '--final' not in sys.argv:sys.exit()
for name,expected in [('qualify-stock',0),('qualify-ordinary-O0',0),('qualify-ordinary-O3',0),('qualify-boxed-O0',0),('qualify-boxed-O0-build',0),('qualify-boxed-O0-inverse',1),('preflight-ordinary-O0',1)]:
    assert json.loads((logs/(name+'.result')).read_text())['exit_code']==expected, (name,expected)
positive=[(logs/(k+'.stdout')).read_bytes() for k in ['qualify-stock','qualify-ordinary-O0','qualify-ordinary-O3','qualify-boxed-O0']]
assert len(set(positive))==1
assert 'AssertionError' in (logs/'qualify-boxed-O0-inverse.stderr').read_text()
assert not delta['remaining_rows_changed'] and not delta['regressed'] and delta['missing_before']==delta['missing_after']
assert all(set(old[n])=={'type_module'} for n in delta['new_matches']) and len(delta['new_matches'])==17
pinned_paths=list(sorted((r/'exports-stage').glob('*.py')))
files=sorted(list((r/'function-type-stage').glob('*.py'))+[r/'function-type-matrix.py',r/'finish-function-type.py',r/'compare-preflight.py']+pinned_paths+list(p for p in logs.iterdir() if p.is_file() and p.suffix!='.exe' and p.name!='SHA256SUMS')+[base,post,e/'public-eaae6bc-O0.stdout',e/'public-eaae6bc-O0.stderr',e/'public-eaae6bc-O0.exit',e/'public-eaae6bc-O0.cmd',e/'public-eaae6bc-provenance.txt',e/'preflight-stock.stdout',e/'preflight-stock.stderr',e/'preflight-stock.exit'])
checksums=logs/'SHA256SUMS'
checksums.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r))+'\n' for p in files))
archive=r/'function-type-surface-74407aad.tgz'
with tarfile.open(archive,'w:gz') as stream:
    for p in files+[checksums]:
        stream.add(p,arcname=str(p.relative_to(r)),recursive=False)
print(archive,hashlib.sha256(archive.read_bytes()).hexdigest())
