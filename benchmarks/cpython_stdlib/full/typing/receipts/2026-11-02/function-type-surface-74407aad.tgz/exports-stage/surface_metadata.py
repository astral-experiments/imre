import builtins
import collections
from collections import abc
import contextlib
import re
import typing
from expected_origins import PUBLIC_ORIGINS

FIELDS = ("type", "type_module", "__name__", "__qualname__", "__module__", "callable", "get_origin", "__origin__")
MISSING = object()
MODULES = {"builtins": builtins, "collections": collections, "collections.abc": abc,
           "contextlib": contextlib, "re": re, "typing": typing}


def origin_stamp(value, public):
    if value is MISSING:
        return ("absent",)
    if value is None:
        return None
    module = getattr(value, "__module__", None)
    qual = getattr(value, "__qualname__", None)
    if public is not None:
        owner, target = public
        return ("public type", module, qual, value is getattr(MODULES[owner], target))
    objclass = getattr(value, "__objclass__", None)
    declaring = getattr(objclass, "__qualname__", None)
    return ("object", type(value).__name__, module, qual, declaring)


def field_value(name, value, field):
    try:
        if field == "type":
            return type(value).__name__
        if field == "type_module":
            return type(value).__module__
        if field == "callable":
            return callable(value)
        if field == "get_origin":
            return origin_stamp(typing.get_origin(value), PUBLIC_ORIGINS[name][0])
        if field == "__origin__":
            return origin_stamp(getattr(value, field, MISSING), PUBLIC_ORIGINS[name][1])
        attr = getattr(value, field, MISSING)
        return ("absent",) if attr is MISSING else attr
    except Exception as exc:
        return ("ERROR", type(exc).__name__, str(exc))


def metadata_for(name, value):
    return tuple(field_value(name, value, field) for field in FIELDS)
