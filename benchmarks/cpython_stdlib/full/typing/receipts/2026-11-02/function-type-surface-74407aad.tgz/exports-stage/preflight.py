"""Measure the real public bindings before enabling typing.__all__."""
from collections import ChainMap, OrderedDict, abc, deque
import typing
from expected import EXPECTED
from surface_metadata import FIELDS, metadata_for
from expected_metadata import METADATA

errors = []
try:
    import named_names
    bindings = vars(named_names)
except Exception as exc:
    errors.append(("named import", type(exc).__name__, str(exc)))
    bindings = {}

found = 0
for name in EXPECTED:
    try:
        value = getattr(typing, name)
    except Exception as exc:
        errors.append((name, type(exc).__name__, str(exc)))
        continue
    found += 1
    namespace = vars(typing)
    retained = name in namespace and namespace[name] is value
    explicit = name in bindings and bindings[name] is value
    print("BIND", name, retained, explicit, flush=True)
    if not retained or not explicit:
        errors.append(("identity", name, retained, explicit))
    fields = metadata_for(name, value)
    if fields != METADATA[name]:
        errors.append(("metadata", name, tuple(f for f, a, b in zip(FIELDS, fields, METADATA[name]) if a != b)))
    print("META", name, repr(fields), flush=True)

print("PREFLIGHT_COUNT", found, "ERRORS", repr(errors), flush=True)
assert not errors and found == len(EXPECTED)
for alias, origin, arguments in (
    (typing.Deque, deque, (int,)),
    (typing.ChainMap, ChainMap, (str, int)),
    (typing.OrderedDict, OrderedDict, (str, int)),
):
    specialized = alias[arguments]
    assert typing.get_origin(alias) is origin
    assert typing.get_origin(specialized) is origin
    assert typing.get_args(specialized) == arguments
    assert type(specialized()) is origin
assert typing.get_origin(typing.ByteString) is abc.ByteString
assert typing.Text is str
assert typing.evaluate_forward_ref(
    typing.ForwardRef("list['int']"), globals={"list": list, "int": int},
) == list[int]
assert not hasattr(typing, "_nonexistent_export_1936765")
assert not hasattr(typing, "NotAnExport_1936765")
print("PREFLIGHT_OK", flush=True)
