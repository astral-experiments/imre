"""Generate the stock references independently of Imre."""
from pathlib import Path
from expected import EXPECTED
import typing
p=Path(__file__).resolve().parent
public={}
for name in EXPECTED:
    obj=getattr(typing,name)
    def ref(val):
        return (val.__module__,val.__qualname__) if isinstance(val,type) else None
    public[name]=(ref(typing.get_origin(obj)),ref(getattr(obj,"__origin__",None)))
(p/"expected_origins.py").write_text("PUBLIC_ORIGINS = "+repr(public)+"\n")
from surface_metadata import metadata_for
meta={name:metadata_for(name,getattr(typing,name)) for name in EXPECTED}
assert len(meta)==105 and meta["Iterator"][0]=="_SpecialGenericAlias"
(p/"expected_metadata.py").write_text("METADATA = "+repr(meta)+"\n")
(p/"named_names.py").write_text("".join("try:\n    from typing import "+n+"\nexcept ImportError:\n    pass\n" for n in EXPECTED))
