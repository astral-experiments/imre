from pathlib import Path
import os,subprocess,sys,json,time
r=Path(__file__).resolve().parent
logs=r/'function-type-logs';src=r/'function-type-stage';audit=r/'exports-stage'
bin=Path('/workspace/scratch/public-eaae6bc-bin/imre')
runtime=r/'function-type-bin/libimre_runtime.a'
clang='/workspace/scratch/intact/tools/usr/bin/clang-19'
stock='/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
def invoke(key,args,cwd=src,flags=None):
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
 if flags:env['IMREFLAGS']=flags
 cmd=list(map(str,args))
 prefix=str(logs/key)
 Path(prefix+'.argv').write_text(json.dumps(dict(argv=cmd,cwd=str(cwd),IMREFLAGS=flags))+'\n')
 start=time.monotonic()
 with open(prefix+'.stdout','wb') as so,open(prefix+'.stderr','wb') as se:
  try:rc=subprocess.run(cmd,cwd=cwd,env=env,stdout=so,stderr=se,timeout=1800).returncode
  except subprocess.TimeoutExpired:rc=124
 Path(prefix+'.result').write_text(json.dumps({'exit_code':rc,'seconds':round(time.monotonic()-start,3)})+'\n')
 print(key,rc,flush=True)
 return rc
for mode in sys.argv[1:]:
 if mode=='stock': sys.exit(invoke('qualify-stock',[stock,'-B','-m','qualify']))
 if mode=='preflight':
  key='preflight-ordinary-O0'
  rc=invoke(key,[bin,'-B','-m','preflight'],audit,f'--no-cache --clang {clang} --runtime {runtime} --opt-level 0')
  if rc!=1:sys.exit(1)
  continue
 kind,level=mode.split('-')
 key=f'qualify-{kind}-O{level}'
 if kind=='ordinary':
  rc=invoke(key,[bin,'-B','-m','qualify'],src,f'--no-cache --clang {clang} --runtime {runtime} --opt-level {level}')
 else:
  exe=logs/(key+'.exe')
  b=invoke(key+'-build',[bin,'build',src/'qualify.py','--module-root',src,'--runtime-imports','--clang',clang,'--runtime',runtime,'--no-cache','--opt-level',level,'-o',exe])
  if b:sys.exit(b)
  rc=invoke(key,[exe])
  if not rc:
   inverse=invoke(key+'-inverse',[exe,'wrong'])
   if inverse!=1:rc=1
  exe.unlink(missing_ok=True)
 if rc:sys.exit(rc)
