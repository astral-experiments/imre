import ast,hashlib,json,sys
from pathlib import Path
r=Path(__file__).resolve().parent
logs=r/'exports-logs'
fields=('type','type_module','__name__','__qualname__','__module__','callable','get_origin','__origin__')
def read(path):
    values,bindings={},{}
    for line in path.read_text().splitlines():
        tag,_,tail=line.partition(' ')
        if tag=='META':
            name,_,raw=tail.partition(' ')
            values[name]=ast.literal_eval(raw)
        if tag=='BIND':
            name,identity,named=tail.split()
            bindings[name]=(identity=='True',named=='True')
    return values,bindings
reference=logs/'preflight-stock.stdout'
observed=Path(sys.argv[1])
exp,exp_bind=read(reference)
actual,bind=read(observed)
assert len(exp)==105
diff={}
missing=[]
for name,expected in exp.items():
    if name not in actual:missing.append(name);continue
    record={}
    if bind[name]!=exp_bind[name]:record['module_namespace_explicit_import_identity']={'stock':exp_bind[name],'native':bind[name]}
    for field,want,got in zip(fields,expected,actual[name],strict=True):
        if want!=got:record[field]={'stock':want,'native':got}
    if record:diff[name]=record
rows={'denominator':105,'observed_real_lookups':len(actual),'matched_metadata_and_bindings':len(exp)-len(missing)-len(diff),'missing_or_unobserved':missing,'present_with_differences':diff,
      'rows_per_field':{k:[n for n,v in diff.items() if k in v] for k in fields},
      'stock_sha256':hashlib.sha256(reference.read_bytes()).hexdigest(),'observed_sha256':hashlib.sha256(observed.read_bytes()).hexdigest(),
      'wildcard_profile':'deferred until preflight qualifies all real exports','fields':fields}
out=logs/(observed.stem+'.comparison.json')
out.write_text(json.dumps(rows,indent=2)+'\n')
print(out,len(actual),'found',len(missing),'missing',len(diff),'different',rows['matched_metadata_and_bindings'],'matched')
for k,ns in rows['rows_per_field'].items():
    if ns:print(k,', '.join(ns))
print('missing',', '.join(missing))
