import probe
from boxed_functiontype import current
current()
print("function constructor fixture complete", flush=True)
