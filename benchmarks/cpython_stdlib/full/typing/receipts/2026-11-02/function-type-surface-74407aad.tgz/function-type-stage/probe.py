import sys
import types
import typing


def local_marker():
    return 17


function_class = type(local_marker)
assert function_class is types.FunctionType
assert type(lambda: 17) is function_class
assert local_marker() == 17 and local_marker.__module__ == __name__
print("function type is types.FunctionType", flush=True)
assert function_class.__module__ == "builtins"
assert function_class.__name__ == function_class.__qualname__ == "function"
for name in (
    "NamedTuple", "TypedDict", "assert_type", "assert_never", "dataclass_transform",
    "final", "get_args", "get_origin", "get_protocol_members", "get_type_hints",
    "is_protocol", "is_typeddict", "no_type_check", "no_type_check_decorator",
    "override", "reveal_type", "runtime_checkable",
):
    func = getattr(typing, name)
    assert type(func) is function_class and type(func).__module__ == "builtins"
    assert func.__module__ == "typing"
print("17 typing functions share the builtin function type", flush=True)
if len(sys.argv) > 1:
    assert function_class.__module__ == "typing"
