#!/bin/bash
set -eu
root=/workspace/scratch/collect-params
cd "$root"
source /workspace/ty-env.sh
out=/tmp/imre-alias-ns
while [[ ! -f $out/cargo.rc ]]; do sleep 2; done
if [[ $(cat "$out/cargo.rc") != 0 ]]; then exit 1; fi
CARGO_INCREMENTAL=0 cargo build --locked --offline --jobs 1 --config 'profile.dev.debug=0' --target-dir /workspace/scratch/static-target -p imre-runtime >"$out/cargo.final.out" 2>"$out/cargo.final.err"
sha256sum /workspace/scratch/static-target/debug/libimre_runtime.a /workspace/scratch/typing-introspection-bin/imre >"$out/build.sha256"
for mode in boxed ordinary; do
    path=$out/$mode-O0
    mkdir -p "$path"
    flags=()
    if [[ $mode == boxed ]]; then flags+=(--runtime-imports); fi
    cmd=(/workspace/scratch/typing-introspection-bin/imre build "$root/tests/fixtures/boxed_typing_alias_namespaces.py" --no-cache --module-root "$root/tests/fixtures" --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime /workspace/scratch/static-target/debug/libimre_runtime.a --opt-level 0 "${flags[@]}" -o "$path/program")
    printf '%q ' "${cmd[@]}" >"$path/build.argv"
    status=0; TMPDIR="$out" "${cmd[@]}" >"$path/build.out" 2>"$path/build.err" || status=$?
    echo "$status" >"$path/build.rc"; if [[ $status != 0 ]]; then tail -12 "$path/build.err"; continue; fi
    status=0; "$path/program" >"$path/run.out" 2>"$path/run.err" || status=$?
    echo "$status" >"$path/run.rc"; cat "$path/run.out" "$path/run.err"
done
