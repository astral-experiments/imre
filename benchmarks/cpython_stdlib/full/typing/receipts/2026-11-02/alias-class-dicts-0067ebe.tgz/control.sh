#!/bin/bash
set -eu
root=/workspace/scratch/collect-params
cd "$root"
source /workspace/ty-env.sh
out=/tmp/imre-alias-ns
while [[ ! -f $out/cargo.rc ]]; do sleep 2; done
if [[ $(cat "$out/cargo.rc") != 0 ]]; then exit 1; fi
sha256sum /workspace/scratch/alias-ns-pin/06ef256c.a /workspace/scratch/parameter-classes-bin/imre >"$out/build.sha256"
for mode in boxed ordinary; do
    path=$out/$mode-O0
    mkdir -p "$path"
    flags=()
    if [[ $mode == boxed ]]; then flags+=(--runtime-imports); fi
    cmd=(/workspace/scratch/parameter-classes-bin/imre build "$root/tests/fixtures/boxed_typing_alias_namespaces.py" --no-cache --module-root "$root/tests/fixtures" --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime /workspace/scratch/alias-ns-pin/06ef256c.a --opt-level 0 "${flags[@]}" -o "$path/program")
    printf '%q ' "${cmd[@]}" >"$path/build.argv"
    status=0; TMPDIR="$out" "${cmd[@]}" >"$path/build.out" 2>"$path/build.err" || status=$?
    echo "$status" >"$path/build.rc"; if [[ $status != 0 ]]; then tail -12 "$path/build.err"; continue; fi
    status=0; "$path/program" >"$path/run.out" 2>"$path/run.err" || status=$?
    echo "$status" >"$path/run.rc"; cat "$path/run.out" "$path/run.err"
done
