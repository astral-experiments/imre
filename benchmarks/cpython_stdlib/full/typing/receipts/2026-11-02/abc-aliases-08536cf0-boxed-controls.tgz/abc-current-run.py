from pathlib import Path
import json,os,subprocess,time,sys
r=Path(__file__).resolve().parent
logs=r/'abc-current-logs'
cc=Path('/workspace/scratch/intact/tools/usr/bin/clang-19')
exe=r/'abc-current-bin/imre'
archive=r/'abc-current-bin/libimre_runtime.a'
stock='/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
def invoke(key, args, cwd, flags=None):
    prefix=logs/key
    env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"}
    if flags: env['IMREFLAGS']=flags
    args=list(map(str,args));start=time.monotonic()
    p=Path(str(prefix)+'.argv')
    p.write_text(json.dumps({'argv':args, 'cwd':str(cwd), 'IMREFLAGS':flags})+'\n')
    with Path(str(prefix)+'.stdout').open('wb') as so,Path(str(prefix)+'.stderr').open('wb') as se:
        try: rc=subprocess.run(args,cwd=cwd,env=env,stdout=so,stderr=se,timeout=2400).returncode
        except subprocess.TimeoutExpired: rc=124
    Path(str(prefix)+'.result').write_text(json.dumps({'exit_code':rc,'seconds':round(time.monotonic()-start,3)})+'\n')
    print(key,rc,flush=True)
    return rc
def run(group,mode,level):
    key=f'{group}-{mode}-{level}'; c=r/group
    if mode=='stock': return invoke(key,[stock,'-B','-m','run'],c)
    if mode=='ordinary':
        return invoke(key,[exe,'-B','-m','run'],c, f'--no-cache --clang {cc} --runtime {archive} --opt-level {level}')
    binary=logs/(key+'.exe')
    rc=invoke(key+'-build',[exe,'build',c/'run.py','--runtime-imports','--module-root',c,'--no-cache','--clang',cc,'--runtime',archive,'--opt-level',level,'-o',binary],c)
    if not rc: rc=invoke(key,[binary],c)
    binary.unlink(missing_ok=True)
    return rc
if __name__=='__main__':
    for g,m,lv in zip(sys.argv[1::3],sys.argv[2::3],sys.argv[3::3]):
        if run(g,m,lv): sys.exit(1)
