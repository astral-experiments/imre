from collections import abc
import typing
from typing import (
    AbstractSet, AsyncGenerator, AsyncIterable, Collection, Container, Coroutine,
    Hashable, ItemsView, KeysView, MappingView, MutableSequence, MutableSet,
    ValuesView,
)


failures = []
for alias, origin, arity in (
    (AbstractSet, abc.Set, 1),
    (AsyncGenerator, abc.AsyncGenerator, 2),
    (AsyncIterable, abc.AsyncIterable, 1),
    (Collection, abc.Collection, 1),
    (Container, abc.Container, 1),
    (Coroutine, abc.Coroutine, 3),
    (Hashable, abc.Hashable, 0),
    (ItemsView, abc.ItemsView, 2),
    (KeysView, abc.KeysView, 1),
    (MappingView, abc.MappingView, 1),
    (MutableSequence, abc.MutableSequence, 1),
    (MutableSet, abc.MutableSet, 1),
    (ValuesView, abc.ValuesView, 1),
):
    stage = "start"
    try:
        stage = "origin and arguments"
        stage = "binding"
        assert getattr(typing, alias.__name__) is alias
        stage = "display name"
        assert repr(alias) == "typing." + alias.__name__
        stage = "origin module"
        assert origin.__module__ == "collections.abc"
        stage = "deprecation docstring"
        assert alias.__doc__ == f"Deprecated alias to collections.abc.{origin.__qualname__}."
        stage = "subscription"
        arguments = (str, int, bytes)[:arity]
        specialized = alias[arguments]
        stage = "unparameterized origin"
        assert typing.get_origin(alias) is origin
        stage = "bare arguments"
        assert typing.get_args(alias) == ()
        stage = "specialized origin"
        assert typing.get_origin(specialized) is origin
        stage = "specialized arguments"
        assert typing.get_args(specialized) == arguments
        stage = "subscription cache"
        assert specialized is alias[arguments]
        stage = "invalid type"
        try:
            alias[((int, str),)]
        except TypeError as exc:
            assert "Parameters to generic types must be types" in str(exc)
        else:
            raise AssertionError("accepted tuple as a single type argument")

        for base in (alias, specialized):
            stage = f"inheritance on {base}"
            class Child(base):
                pass

            assert Child.__orig_bases__ == (base,)
            assert Child.__bases__ == (origin, typing.Generic)
            stage = f"call on {base}"
            if alias in (ItemsView, KeysView, MappingView, ValuesView):
                data = {"a": 1}
                view = base(data)
                assert type(view) is origin
                data["b"] = 2
                assert len(view) == 2
            else:
                try:
                    base()
                except TypeError as actual_error:
                    try:
                        origin()
                    except TypeError as origin_error:
                        assert str(actual_error) == str(origin_error)
                    else:
                        raise AssertionError("abstract origin instantiated")
                else:
                    raise AssertionError(f"{base} instantiated an abstract class")

        stage = "arity"
        for wrong in ((), (str, int, bytes, bool)):
            if not arity and not wrong:
                continue
            try:
                alias[wrong]
            except TypeError as error:
                if not arity:
                    assert str(error) == f"{alias} is not a generic class"
                else:
                    expected = "at least 1" if alias is AsyncGenerator else str(arity)
                    which = "many" if wrong else "few"
                    assert str(error) == f"Too {which} arguments for {alias}; actual {len(wrong)}, expected {expected}"
            else:
                raise AssertionError(f"{alias} accepted {wrong}")
    except Exception as exc:
        failures.append((str(alias), stage, type(exc).__name__, str(exc)))
        print("FAIL", failures[-1], flush=True)
    else:
        print("PASS", alias, flush=True)

assert typing.get_args(AsyncGenerator[int]) == (int, type(None))
assert list(ItemsView({"a": 1})) == [("a", 1)]
assert list(KeysView[str]({"a": 1})) == ["a"]
assert list(ValuesView[int]({"a": 1})) == [1]
assert not failures, failures
print("ABC aliases")
