"""Package the named selector inputs and terminal callbacks without re-running a suite."""
import ast
import gzip
import hashlib
import json
import tarfile
from pathlib import Path

root = Path(__file__).parent
stock = Path("/tmp/imre-stock/stock-pinned.jsonl")
ordinals = {json.loads(line)["id"]: i for i, line in enumerate(stock.read_text().splitlines(), start=1)}
selected = [71,72,86,89,95,96]
prefix = "TYPING_EVENT "
results = {}
raw = []
for name in ("stock-final","ordinary-O0","ordinary-O3"):
    base = root/"logs"/name
    if not base.with_suffix(".exit").exists():
        continue
    assert base.with_suffix(".exit").read_text().strip()=="0"
    stdout = base.with_suffix(".stdout").read_text().splitlines()
    assert "REGISTERED_COUNT 6" in stdout and "RUNNER_COUNT 6" in stdout and "ALIAS_CONTROLS_OK" in stdout
    events = [ast.literal_eval(s[len(prefix):]) for s in stdout if s.startswith(prefix)]
    cases = {case_id: [ev[0] for ev in events if ev[1]==case_id] for _,case_id,*_ in events}
    assert sorted(ordinals[id_] for id_ in cases)==selected
    assert all(event_list==["START","PASS","STOP"] for event_list in cases.values())
    results[name]=[{"ordinal":ordinals[id_],"id":id_,"status":"pass"} for id_ in sorted(cases,key=ordinals.__getitem__)]
    raw.extend(base.parent.glob(name+".*"))
summary={
    "candidate":"1791943ed8bcb0fe8e30aaa0ec1a9f5f3b9c0c17",
    "base":"2f966819cdd4e0b01e86e0f36b9496ce0f68dab4",
    "upstream":"5607950ef232dad16d75c0cf53101d9649d89115",
    "test_typing_sha256":hashlib.sha256((root/"stage/test/test_typing.py").read_bytes()).hexdigest(),
    "stock_712_ledger_sha256":hashlib.sha256(stock.read_bytes()).hexdigest(),
    "selection":"Directly instantiate these six original methods from the intact test.test_typing.CollectionsAbcTests class",
    "modes":results
}
suffix = "paired" if "ordinary-O3" in results else "O0"
report=root/("set-receipt-"+suffix+".json")
report.write_text(json.dumps(summary,indent=2)+"\n")
target=root/("set-originals-"+suffix+".tar.gz")
with tarfile.open(target,"w:gz") as archive:
    paths=[report,*raw,root/"run.sh",root/"package.py",root/"stage/set_cases.py",root/"stage/event_support.py",root/"stage/alias_semantics.py",root/"build-j1.log"]
    for path in sorted(set(paths)):
        if path.is_file(): archive.add(path,arcname=path.relative_to(root))
print(target, target.stat().st_size,hashlib.sha256(target.read_bytes()).hexdigest())
