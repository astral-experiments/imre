import sys
import unittest

from test import test_typing
from event_support import Events

def check_aliases():
    import alias_semantics


case_class = test_typing.CollectionsAbcTests
names = ("test_set", "test_frozenset", "test_no_set_instantiation",
         "test_set_subclass_instantiation", "test_no_frozenset_instantiation",
         "test_frozenset_subclass_instantiation")
suite = unittest.TestSuite(case_class(name) for name in names)
print("REGISTERED_COUNT", suite.countTestCases(), flush=True)
result = unittest.TextTestRunner(verbosity=2, descriptions=False, resultclass=Events).run(suite)
print("RUNNER_COUNT", result.testsRun, flush=True)
check_aliases()
print("ALIAS_CONTROLS_OK", flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
