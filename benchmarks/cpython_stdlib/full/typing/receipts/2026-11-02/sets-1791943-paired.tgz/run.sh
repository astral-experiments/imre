set -eu
root=/workspace/scratch/typing-set-controls
mode=$1
level=$2
bin="$root/bin"
stem="$root/logs/$mode-O$level"
cd "$root/stage"
for n in $(seq 1 240); do test -x "$bin/imre" && test -s "$bin/libimre_runtime.a" && break; sleep 3; done
test -x "$bin/imre"
clang=/workspace/scratch/intact/tools/usr/bin/clang-19
sha256sum set_cases.py alias_semantics.py test/test_typing.py "$bin/imre" "$bin/libimre_runtime.a" > "$stem.inputs"
if test "$mode" = ordinary; then
    flags="--no-cache --clang $clang --runtime $bin/libimre_runtime.a --opt-level $level"
    printf 'IMREFLAGS=%q %q -B -m set_cases\n' "$flags" "$bin/imre" > "$stem.cmd"
    rc=0; IMREFLAGS="$flags" timeout 2400 "$bin/imre" -B -m set_cases > "$stem.stdout" 2> "$stem.stderr" || rc=$?
else
    args=(build "$root/stage/set_cases.py" --runtime-imports --module-root "$root/stage" --runtime "$bin/libimre_runtime.a" --clang "$clang" --opt-level "$level" --no-cache -o "$stem.exe")
    printf '%q ' "$bin/imre" "${args[@]}" > "$stem.cmd"; printf '\n' >> "$stem.cmd"
    rc=0; timeout 2100 "$bin/imre" "${args[@]}" > "$stem.build.stdout" 2> "$stem.build.stderr" || rc=$?
    echo "$rc" > "$stem.build.exit"
    if test "$rc" = 0; then
        sha256sum "$stem.exe" > "$stem.exe.sha256"
        timeout 1200 "$stem.exe" > "$stem.stdout" 2> "$stem.stderr" || rc=$?
    fi
fi
echo "$rc" > "$stem.exit"; echo "$mode O$level $rc"; tail -10 "$stem.stderr"; tail -4 "$stem.stdout"
