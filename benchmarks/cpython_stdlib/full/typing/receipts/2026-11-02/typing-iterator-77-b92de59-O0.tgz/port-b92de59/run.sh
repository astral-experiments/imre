set -eu
w=/workspace/scratch/awaitable-53/iterator-77
d="$w/port-b92de59"
source /workspace/ty-env.sh
cd /workspace/scratch/typing-iterator-77
CARGO_PROFILE_DEV_DEBUG=0 CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/workspace/scratch/typing-iterator-target cargo build --offline --locked --jobs 1 -p imre-compiler -p imre-runtime >"$d/build.log" 2>&1
ln /workspace/scratch/typing-iterator-target/debug/imre "$d/bin/imre"
ln /workspace/scratch/typing-iterator-target/debug/libimre_runtime.a "$d/bin/libimre_runtime.a"
{ hostname; git rev-parse HEAD; git rev-parse HEAD^1; git rev-parse HEAD^2; sha256sum "$d"/bin/{imre,libimre_runtime.a}; } >"$d/provenance.txt"
cd "$w/selected-stage"
export TMPDIR="$d/ordinary-O0"
export IMREFLAGS="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $d/bin/libimre_runtime.a --opt-level 0"
printf 'IMREFLAGS=%q %q -B -m verify_iterator\n' "$IMREFLAGS" "$d/bin/imre" >"$d/ordinary-O0/cmd"
rc=0; "$d/bin/imre" -B -m verify_iterator >"$d/ordinary-O0/stdout" 2>"$d/ordinary-O0/stderr" || rc=$?; echo "$rc" >"$d/ordinary-O0/rc"
test "$rc" -eq 0 && cmp "$w/qualification/stock.stdout" "$d/ordinary-O0/stdout" && tail -4 "$d/ordinary-O0/stdout"
