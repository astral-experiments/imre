import hashlib, io, json, subprocess, tarfile
from pathlib import Path

port=Path(__file__).resolve().parent
base=port.parent
repo='/workspace/scratch/typing-iterator-77'
merge='b92de59f396d498c37e65cb9e1550fef355b9741'
public='7f8864530b30bd98d14661da8e15d94a5fc9ed50'
first='8eeae94e139d2bd73496ea21fe82c149900982c7'
hashb=lambda value:hashlib.sha256(value).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',repo,*args])
assert git('rev-parse',f'{merge}^1',f'{merge}^2').decode().splitlines()==[first,public]
q=port/'ordinary-O0'
rc=int((q/'rc').read_text())
stock=(base/'qualification/stock.stdout').read_bytes()
assert rc==0 and (q/'stdout').read_bytes()==stock and b'RESULT 1 0 0 0' in stock
assert [line.split(b"'",2)[1] for line in stock.splitlines() if line.startswith(b'TYPING_EVENT ')]==[b'START',b'PASS',b'STOP']
assert (port/'provenance.txt').read_text().splitlines()[1:4]==[merge,first,public]
diff=git('diff',public,merge)
assert set(git('diff','--name-only',public,merge).decode().splitlines())=={'crates/imre-compiler/stdlib/typing.py','tests/fixtures/boxed_typing_iterable.py'}
files={'resolved.diff':diff,'parents.txt':git('show','-s','--format=%H %P %s',merge)}
for f in [port/'run.sh',port/'pack_port.py',port/'provenance.txt',port/'build.log',*(q/name for name in ('rc','stdout','stderr','cmd')), *(base/'qualification').glob('stock.*'),base/'qualification/original-source.json',*(base/'selected-stage').rglob('*.py')]:
    files[str(f.relative_to(base))]=f.read_bytes()
fixture='tests/fixtures/boxed_typing_iterable.py'
assert files['selected-stage/boxed_typing_iterable.py']==git('show',f'{merge}:{fixture}')
old=Path('/workspace/shared/downloads/typing-iterator-77-8eeae94-O0-O3.tgz')
files['summary.json']=(json.dumps({'tested_head':merge,'public_base':public,'branch':'charlie/typing-iterator-alias','original_ordinal':77,'source_scope':'byte-identical selected CPython test method and original dotted ID','original_source':json.loads((base/'qualification/original-source.json').read_text()),'native_mode':'ordinary module CLI O0','aggregate_exit':rc,'events':['START','PASS','STOP'],'children':[],'skip_reason':None,'raw_stdout_sha256':hashb(stock),'stock_stdout_equal':True,'prior_ordinary_O0_O3':{'head':first,'archive':str(old),'sha256':hashb(old.read_bytes())}},indent=2)+'\n').encode()
files['MANIFEST.sha256']=''.join(f'{hashb(v)}  {p}\n' for p,v in sorted(files.items())).encode()
out=Path('/workspace/shared/downloads/typing-iterator-77-b92de59-O0.tgz')
with tarfile.open(out,'w:gz') as archive:
    for p,v in sorted(files.items()):
        info=tarfile.TarInfo(p);info.size=len(v);info.mode=0o600;archive.addfile(info,io.BytesIO(v))
print(hashb(out.read_bytes()),out)
