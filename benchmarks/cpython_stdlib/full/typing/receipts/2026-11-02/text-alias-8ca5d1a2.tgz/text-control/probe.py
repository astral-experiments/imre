import sys
import typing
from typing import Text

assert Text is typing.Text
assert Text is str
assert Text(42) == "42"
value = "".join(("native ", "text"))
assert Text(value) is value
assert isinstance(value, typing.Text)
print("Text is str and calls the string constructor", flush=True)
if len(sys.argv) > 1:
    assert Text is not str
