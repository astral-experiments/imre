import json,os,sys,subprocess,time
from pathlib import Path
r=Path('/tmp/imre-alltests')
out=r/'receipts'
stock='/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
clang='/workspace/scratch/intact/tools/usr/bin/clang-19'
src=r/'text-control'
def run(args,p,flags=None):
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
 if flags:env['IMREFLAGS']=flags
 t=time.monotonic()
 with Path(str(p)+'.stdout').open('wb') as so,Path(str(p)+'.stderr').open('wb') as se:
  res=subprocess.run(list(map(str,args)),cwd=src,stdout=so,stderr=se,env=env,timeout=1500)
 Path(str(p)+'.json').write_text(json.dumps(dict(argv=list(map(str,args)),IMREFLAGS=flags,code=res.returncode,seconds=round(time.monotonic()-t,3)))+'\n')
 print(p,res.returncode,flush=True)
 return res.returncode
for mode in sys.argv[1:]:
 for level in ([''] if mode=='stock' else ['0'] if mode=='baseline' else ['0','3']):
  d=out/('text-'+mode+level);d.mkdir(exist_ok=True);flags=None
  b=Path('/workspace/scratch/public-c7295770-bin' if mode=='baseline' else '/tmp/imre-concat-latest/target/debug')
  runtime=b/'libimre_runtime.a'
  if mode=='stock': seq=[stock,'-B','-m','probe']
  elif mode in ('ordinary','baseline'):
   flags=f'--no-cache --clang {clang} --runtime {runtime} --opt-level {level}'
   seq=[b/'imre','-B','-m','probe']
  else:
   exe=d/'program'
   args=[b/'imre','build',src/'probe.py','--module-root',src,'--no-cache','--clang',clang,'--runtime',runtime,'--opt-level',level,'--runtime-imports','-o',exe]
   if run(args,d/'build'): continue
   seq=[exe]
  rc=run(seq,d/'positive',flags)
  if rc==0:run(seq+['wrong'],d/'inverse',flags)
  (d/'program').unlink(missing_ok=True)
