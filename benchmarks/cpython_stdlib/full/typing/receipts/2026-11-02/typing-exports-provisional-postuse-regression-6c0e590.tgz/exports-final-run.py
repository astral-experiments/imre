import json, os, subprocess, sys, time
from pathlib import Path
r=Path(__file__).resolve().parent
src=r/'exports-final-stage'
logs=r/'exports-final-logs'
version,mode,level,compiler,archive,entry=sys.argv[1:]
assert entry in {'run','postuse'}
assert set(version) <= set('0123456789abcdefghijklmnopqrstuvwxyz-')
cc='/workspace/scratch/intact/tools/usr/bin/clang-19'
prefix=f'{version}-{entry}-{mode}-O{level}'
def invoke(key,argv,flags=None):
    args=list(map(str,argv))
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
    if flags: env['IMREFLAGS']=flags
    p=logs/key
    p.with_suffix('.argv').write_text(json.dumps({'cwd':str(src),'argv':args,'IMREFLAGS':flags})+'\n')
    t=time.monotonic()
    with p.with_suffix('.stdout').open('wb') as out,p.with_suffix('.stderr').open('wb') as err:
        status=subprocess.run(args,env=env,cwd=src,stdout=out,stderr=err).returncode
    p.with_suffix('.result').write_text(json.dumps({'exit':status, 'seconds':round(time.monotonic()-t,3)})+'\n')
    return status
if mode=='ordinary':
    result=invoke(prefix,[compiler,'-B','-m',entry],f'--no-cache --clang {cc} --runtime {archive} --opt-level {level}')
elif mode=='boxed':
    binary=logs/(prefix+'.exe')
    result=invoke(prefix+'-build',[compiler,'build',src/(entry+'.py'),'--module-root',src,'--runtime-imports','--no-cache','--clang',cc,'--runtime',archive,'--opt-level',level,'-o',binary])
    if result==0:result=invoke(prefix,[binary])
    binary.unlink(missing_ok=True)
else:
    raise ValueError(mode)
print(prefix,result)
sys.exit(result)
