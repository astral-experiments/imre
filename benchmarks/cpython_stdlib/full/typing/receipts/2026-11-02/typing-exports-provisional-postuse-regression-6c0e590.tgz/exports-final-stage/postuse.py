import sys
import types
import typing


EXPECTED_IDS = [
    "typing.ParamSpec", "typing.ParamSpecArgs", "typing.ParamSpecKwargs",
    "typing.TypedDict", "typing._collect_type_parameters", "typing._should_unflatten_callable_args",
    "typing.get_args", "typing.get_origin", "typing.get_protocol_members",
    "typing.is_protocol", "typing.is_typeddict",
]
WATCHED = ("_CallableGenericAlias", "_GenericAlias", "_LiteralGenericAlias")


def snapshot(label, previous):
    current = dict(vars(typing))
    if previous is None:
        print("NAMESPACE_INITIAL", label, repr(sorted(current)), flush=True)
    else:
        added = sorted(name for name in current if name not in previous)
        removed = sorted(name for name in previous if name not in current)
        replaced = sorted(name for name in previous if name in current and previous[name] is not current[name])
        print("NAMESPACE_DELTA", label, repr((added, removed, replaced)), flush=True)
    watch = []
    for name in WATCHED:
        same = None
        if previous is not None and name in current and name in previous:
            same = current[name] is previous[name]
        watch.append((name, name in current, same))
    print("WATCHED", label, repr(watch), flush=True)
    return current


def predicate():
    return issubclass(types.FunctionType, typing.Callable)


def wildcard():
    import postuse_star_names
    public = [name for name in vars(postuse_star_names) if not name.startswith("_")]
    return len(public) == 105 and public == typing.__all__ and all(
        vars(postuse_star_names)[name] is getattr(typing, name) for name in public
    )


def simple_forward():
    return typing.evaluate_forward_ref(typing.ForwardRef("int")) is int


def nested_forward():
    return typing.evaluate_forward_ref(
        typing.ForwardRef("list['int']"), globals={"list": list, "int": int}
    ) == list[int]


def unresolved_forward():
    try:
        typing.evaluate_forward_ref(typing.ForwardRef("sentinel_no_such_name_473"), globals={})
    except NameError:
        return True
    return False


def check():
    state = snapshot("start", None)
    errors = []
    for label, operation in (
        ("predicate", predicate), ("wildcard", wildcard), ("simple_forward", simple_forward),
        ("nested_forward", nested_forward), ("unresolved_forward", unresolved_forward),
    ):
        try:
            value = operation()
        except Exception as exc:
            errors.append((label, type(exc).__name__, str(exc)))
            print("OPERATION_ERROR", label, type(exc).__name__, str(exc), flush=True)
        else:
            print("OPERATION", label, repr(value), flush=True)
            if value is not True:
                errors.append((label, "unexpected result", repr(value)))
        state = snapshot(label, state)
    import doctest
    state = snapshot("import_doctest", state)
    try:
        suite = doctest.DocTestSuite(typing)
        actual = [case.id() for case in suite]
    except Exception as exc:
        print("DISCOVERY_ERROR", type(exc).__name__, str(exc), flush=True)
        snapshot("discovery_error", state)
        raise
    print("REGISTERED_IDS", repr(actual), flush=True)
    snapshot("discovery", state)
    if actual != EXPECTED_IDS:
        errors.append(("doctest registrations", tuple(actual), tuple(EXPECTED_IDS)))
    print("POSTUSE_ERRORS", repr(errors), flush=True)
    return not errors


if __name__ == "__main__":
    sys.exit(0 if check() else 1)
