#!/bin/bash
set -eu
out=/tmp/imre-collector
while [[ ! -f "$out/boxed-hook-O0/build.rc" ]]; do sleep 2; done
cd /workspace/scratch/collector-stage
bin=/workspace/scratch/collect-target/debug
for probe in qualification:intact controls:positive; do
    module=${probe%:*}
    scenario=${probe#*:}
    row=$out/ordinary-cli-O0/$scenario
    mkdir -p "$row"
    flags="--no-cache --clang /workspace/scratch/intact/tools/usr/bin/clang-19 --runtime $bin/libimre_runtime.a --opt-level 0"
    printf 'IMREFLAGS=%q %q -B -m %q %q\n' "$flags" "$bin/imre" "$module" "$scenario" >"$row/argv"
    status=0; TMPDIR="$out" IMREFLAGS="$flags" "$bin/imre" -B -m "$module" "$scenario" >"$row/out" 2>"$row/err" || status=$?
    echo "$status" >"$row/rc"; rg '^(IMPORT_OK|REGISTERED_COUNT|LOADER_ERRORS|LEAF_COUNT|SELECTED_COUNT|START|PASS|FAIL|ERROR|SKIP|RUNNER_COUNT|typing parameter)' "$row/out" || true; tail -5 "$row/err"
done
