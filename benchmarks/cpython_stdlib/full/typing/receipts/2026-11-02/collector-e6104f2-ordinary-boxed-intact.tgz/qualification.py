import sys
import unittest
import typing
import doctest

class Events(unittest.TextTestResult):
    def startTest(self, case):
        print('START', case.id(), flush=True)
        super().startTest(case)

    def addSuccess(self, case):
        print('PASS', case.id(), flush=True)
        super().addSuccess(case)

    def addFailure(self, case, error):
        print('FAIL', case.id(), str(error[1]), flush=True)
        super().addFailure(case, error)

    def addError(self, case, error):
        print('ERROR', case.id(), str(error[1]), flush=True)
        super().addError(case, error)

    def addSkip(self, case, reason):
        print('SKIP', case.id(), reason, flush=True)
        super().addSkip(case, reason)


def flatten(suite):
    cases = []
    for item in suite:
        if hasattr(item, "id"):
            cases.append(item)
        else:
            cases.extend(flatten(item))
    return cases

scenario = sys.argv[-1]
if scenario == "intact":
    from test import test_typing
    print('IMPORT_OK', test_typing.__name__, flush=True)
    loader = unittest.defaultTestLoader
    suite = loader.loadTestsFromModule(test_typing)
    print('LOAD_TESTS', test_typing.load_tests.__module__, flush=True)
    print('REGISTERED_COUNT', suite.countTestCases(), flush=True)
    print('LOADER_ERRORS', repr(getattr(loader, 'errors', ())), flush=True)
else:
    suite = doctest.DocTestSuite(typing)
cases = flatten(suite)
selected = unittest.TestSuite()
for case in cases:
    print('DISCOVERED', case.id(), flush=True)
    if case.id() == 'typing._collect_type_parameters':
        selected.addTest(case)
print('LEAF_COUNT', len(cases), flush=True)
print('SELECTED_COUNT', selected.countTestCases(), flush=True)
assert selected.countTestCases() == 1
result = unittest.TextTestRunner(verbosity=0, resultclass=Events).run(selected)
print('RUNNER_COUNT', result.testsRun, flush=True)
assert result.testsRun == 1 and result.wasSuccessful()
