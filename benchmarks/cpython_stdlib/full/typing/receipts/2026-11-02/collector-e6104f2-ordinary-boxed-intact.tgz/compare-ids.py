import collections
import json
import pathlib
import sys

stock_file, native_file = map(pathlib.Path, sys.argv[1:3])
def ids(path):
    return [line.partition(" ")[2] for line in path.read_text().splitlines() if line.startswith("DISCOVERED ")]
stock = ids(stock_file)
native = ids(native_file)
native_lines = native_file.read_text().splitlines()
stock_counts = collections.Counter(stock)
native_counts = collections.Counter(native)
target = "typing._collect_type_parameters"
print(json.dumps({
    "stock_registered": len(stock),
    "native_loader_report": [line for line in native_lines if line.startswith(("IMPORT_OK ", "LOAD_TESTS ", "REGISTERED_COUNT ", "LOADER_ERRORS ", "LEAF_COUNT ", "SELECTED_COUNT ", "RUNNER_COUNT "))],
    "callbacks": [line for line in native_lines if line.startswith(("START ", "PASS ", "FAIL ", "ERROR ", "SKIP "))],
    "native_registered": len(native),
    "native_unique": len(native_counts),
    "id_order_matches": native == stock,
    "missing": list((stock_counts-native_counts).elements()),
    "extra": list((native_counts-stock_counts).elements()),
    "duplicate_native_ids": {i:n for i,n in native_counts.items() if n>1},
    "target_stock_ordinal": stock.index(target)+1 if target in stock else None,
    "target_native_ordinal": native.index(target)+1 if target in native else None,
}, indent=2))
