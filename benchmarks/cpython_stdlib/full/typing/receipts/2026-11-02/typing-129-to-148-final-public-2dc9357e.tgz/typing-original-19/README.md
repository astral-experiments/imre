# Original typing cases added between 129 and 148

On Ruff Linux, stock CPython 3.14.5 and ordinary public Imre O0 and O3 each emitted 19 original starts, 19 parent passes, 19 stops, and the three passing child callbacks from ConcatenateTests.test_dir. All three processes exited 0. Stock skips were zero. The separately supplied 14 introspection keys and later observations are outside these 19.

public-case-outcomes.tsv identifies the canonical ID, occurrence, stock ordinal, profile, tested revision, lifecycle and exit. public-replay contains the full staged input, runner and unedited stdout, stderr, commands and process exits. Each events.jsonl is direct process output. The XML in this named replay is generated from the raw callback stream by verify.py. The whole-suite runs have separate lifecycles. status.json records build tree IDs, VM artifact paths and SHA-256.

prior-heads contains the earlier cohort-specific ordinary and boxed O0/O3 raw outcomes. Its README and status describe that historical export. The complete lifecycle comparison on one public revision is in public-replay. Upstream source and LICENSE are included. The original stock test file is unmodified.

The first separate O0 archive reported Rust 1.98.0 from its observer directory. The corrected toolchain-build.txt queries the build worktree and records rustc 1.98.1 (48a229cea) and clang 19.1.7. The earlier report is retained as toolchain-build-wrong-cwd.txt.
