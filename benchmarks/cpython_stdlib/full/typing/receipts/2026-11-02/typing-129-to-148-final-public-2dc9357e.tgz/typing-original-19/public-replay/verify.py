"""Postprocess completed raw observer output; all XML and summary files are derived."""
import collections
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
expected = json.loads((root / "expected.json").read_text())
ids = [row["id"] for row in expected]
reference = None
for mode in sys.argv[1:] or ["stock", "ordinary-O0", "ordinary-O3"]:
    directory = root / mode
    rows = [json.loads(line) for line in (directory / "events.jsonl").read_text().splitlines()]
    phases = {row["phase"]: row for row in rows if "phase" in row}
    observed = [row for row in rows if "event" in row]
    counts = collections.Counter(row["event"] for row in observed)
    starts = [row["id"] for row in observed if row["event"] == "START"]
    stops = [row["id"] for row in observed if row["event"] == "STOP"]
    matching = reference is None or observed == reference
    print(mode, (directory / "exit").read_text().strip(), counts, "match", matching)
    assert (directory / "exit").read_text().strip() == "0"
    assert phases["selected"]["ids"] == starts == stops == ids
    assert phases["runner"] == {"phase":"runner","tests_run":19,"successful":True}
    assert [row["sequence"] for row in observed] == list(range(1, len(observed)+1))
    assert all(row["occurrence"] == 1 for row in observed)
    assert matching
    if reference is None:
        reference = observed
    assert counts == {"START":19,"PASS":19,"STOP":19,"SUBTEST_PASS":3}
    assert len({row["subtest_id"] for row in observed if row["event"] == "SUBTEST_PASS"}) == 3
    report = ET.Element("testsuite", name=mode, tests="19", failures="0", errors="0", skipped="0")
    properties = ET.SubElement(report, "properties")
    ET.SubElement(properties, "property", name="generated_from", value="events.jsonl")
    for item in expected:
        identifier = item["id"]
        case_events = [row for row in observed if row["id"] == identifier]
        assert [row["event"] for row in case_events if not row["event"].startswith("SUBTEST_")] == ["START","PASS","STOP"]
        module, name = identifier.rsplit(".", 1)
        case = ET.SubElement(report,"testcase",classname=module,name=name)
        props = ET.SubElement(case,"properties")
        ET.SubElement(props,"property",name="stock_ordinal",value=str(item["ordinal"]))
        ET.SubElement(case,"system-out").text = "\n".join(json.dumps(row,sort_keys=True) for row in case_events)
    ET.indent(report)
    ET.ElementTree(report).write(directory / "generated-junit.xml",encoding="utf-8",xml_declaration=True)
    digest = hashlib.sha256(json.dumps(observed,sort_keys=True).encode()).hexdigest()
    (directory / "generated-summary.json").write_text(json.dumps({"mode":mode,"counts":counts,"normalized_event_sequence_sha256":digest,"skip_reasons":[r["reason"] for r in observed if "reason" in r]},indent=2,sort_keys=True)+"\n")
