import os,json,sys,time,subprocess
from pathlib import Path
r=Path('/tmp/imre-alltests')
stock='/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
bin=Path('/workspace/scratch/public-c7295770-bin')
clang='/workspace/scratch/intact/tools/usr/bin/clang-19'
for kind,lev in zip(sys.argv[1::2],sys.argv[2::2]):
    src=r/kind
    out=r/'receipts'/(kind+'-ordinary-cli-'+lev)
    out.mkdir(exist_ok=True);env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
    flags=None
    if lev=='stock':args=[stock,'-B','-m','run']
    else:
        flags=f'--no-cache --clang {clang} --runtime {bin}/libimre_runtime.a --opt-level {lev}'
        env['IMREFLAGS']=flags
        args=[str(bin/'imre'),'-B','-m','run']
    t=time.monotonic()
    with (out/'run.stdout').open('wb') as so,(out/'run.stderr').open('wb') as se:
        proc=subprocess.run(args,cwd=src,env=env,stdout=so,stderr=se,timeout=1800)
    (out/'run.json').write_text(json.dumps(dict(argv=args,IMREFLAGS=flags,code=proc.returncode,seconds=round(time.monotonic()-t,3)))+'\n')
    print(kind,lev,proc.returncode,flush=True)
