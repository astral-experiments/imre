from pathlib import Path
import json,os,sys,subprocess,time
r=Path(__file__).resolve().parent
stock='/tmp/imre-stock/python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
bin=Path('/workspace/scratch/public-c7295770-bin')
clang='/workspace/scratch/intact/tools/usr/bin/clang-19'
for kind,mode,level in zip(sys.argv[1::3],sys.argv[2::3],sys.argv[3::3]):
 root=r/kind
 out=r/'receipts'/(kind+'-'+mode+level)
 out.mkdir(exist_ok=True)
 program=out/'program'
 if mode=='stock':
  cmds=[('run',[stock,'-B',root/'run.py'])]
 else:
  build=[bin/'imre','build',root/'run.py','--module-root',root,'--no-cache','--runtime',bin/'libimre_runtime.a','--clang',clang,'--opt-level',level,'-o',program]
  if mode=='boxed':build.append('--runtime-imports')
  cmds=[('build',build),('run',[program])]
 for stage,args in cmds:
  t=time.monotonic()
  with (out/(stage+'.stdout')).open('wb') as so,(out/(stage+'.stderr')).open('wb') as se:
   p=subprocess.run(list(map(str,args)),cwd=root,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=so,stderr=se,timeout=1800)
  (out/(stage+'.json')).write_text(json.dumps(dict(argv=list(map(str,args)),code=p.returncode,seconds=round(time.monotonic()-t,3)))+'\n')
  print(kind,mode,level,stage,p.returncode,flush=True)
  if p.returncode:break
 program.unlink(missing_ok=True)
