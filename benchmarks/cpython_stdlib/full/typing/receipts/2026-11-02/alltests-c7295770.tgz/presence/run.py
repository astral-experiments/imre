import typing

expected = ['Annotated', 'Any', 'Callable', 'ClassVar', 'Concatenate', 'Final', 'ForwardRef', 'Generic', 'Literal', 'Optional', 'ParamSpec', 'Protocol', 'Tuple', 'Type', 'TypeVar', 'TypeVarTuple', 'Union', 'AbstractSet', 'ByteString', 'Container', 'ContextManager', 'Hashable', 'ItemsView', 'Iterable', 'Iterator', 'KeysView', 'Mapping', 'MappingView', 'MutableMapping', 'MutableSequence', 'MutableSet', 'Sequence', 'Sized', 'ValuesView', 'Awaitable', 'AsyncIterator', 'AsyncIterable', 'Coroutine', 'Collection', 'AsyncGenerator', 'AsyncContextManager', 'Reversible', 'SupportsAbs', 'SupportsBytes', 'SupportsComplex', 'SupportsFloat', 'SupportsIndex', 'SupportsInt', 'SupportsRound', 'ChainMap', 'Counter', 'Deque', 'Dict', 'DefaultDict', 'List', 'OrderedDict', 'Set', 'FrozenSet', 'NamedTuple', 'TypedDict', 'Generator', 'BinaryIO', 'IO', 'Match', 'Pattern', 'TextIO', 'AnyStr', 'assert_type', 'assert_never', 'cast', 'clear_overloads', 'dataclass_transform', 'evaluate_forward_ref', 'final', 'get_args', 'get_origin', 'get_overloads', 'get_protocol_members', 'get_type_hints', 'is_protocol', 'is_typeddict', 'LiteralString', 'Never', 'NewType', 'no_type_check', 'no_type_check_decorator', 'NoDefault', 'NoReturn', 'NotRequired', 'overload', 'override', 'ParamSpecArgs', 'ParamSpecKwargs', 'ReadOnly', 'Required', 'reveal_type', 'runtime_checkable', 'Self', 'Text', 'TYPE_CHECKING', 'TypeAlias', 'TypeGuard', 'TypeIs', 'TypeAliasType', 'Unpack']
namespace = vars(typing)
for name in expected:
    try:
        item = getattr(typing, name)
    except AttributeError as e:
        print("MISSING", name, str(e))
    except Exception as e:
        print("ERROR", name, type(e).__name__, str(e))
    else:
        print("FOUND", name, name in namespace)
for name, item in list(namespace.items()):
    if not (name.startswith('_') or name.endswith(('Meta', '_contra', '_co')) or name.upper() == name or name in expected):
        try:
            owner = getattr(item, '__module__', None)
        except Exception as error:
            print('OWNER_ERROR', name, str(error))
        else:
            if owner == 'typing':
                print('EXTRA', name)
try:
    exported = typing.__all__
except AttributeError as e:
    print("ALL_ABSENT", str(e))
else:
    print("ALL_PRESENT", type(exported).__name__, len(exported), repr(exported))
for name in ('NotAnExport_1936765', '_not_an_export_1936765'):
    print("NEGATIVE", name, hasattr(typing, name))
