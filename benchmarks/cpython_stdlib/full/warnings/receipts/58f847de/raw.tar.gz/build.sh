#!/bin/bash
set -eu
repo=$1
filter_merge=$2
trace_merge=$3
cd "$repo"
commit=$(git rev-parse HEAD)
for base in "$filter_merge" "$trace_merge"; do git merge-base --is-ancestor "$base" "$commit"; done
test -z "$(git status --porcelain --untracked-files=no)"
tag=public-${commit:0:8}
work=/workspace/scratch/warnings-next/child-four-public
out=/workspace/shared/downloads/warnings-native-followup/child-four-public/$tag
mkdir -p "$out" "$work/$tag"
. /workspace/ty-env.sh
export PATH=/workspace/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin:$PATH RUSTUP_TOOLCHAIN=1.98.0 CARGO_TARGET_DIR=/workspace/scratch/explicit-public-target CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 TMPDIR=$work/$tag
python3 -IB - "$out/source-manifest.json" "$filter_merge" "$trace_merge" <<'PY'
import hashlib,json,os,subprocess,sys
from pathlib import Path
def git(*args):return subprocess.check_output(['git',*args]).decode().strip()
manifest=dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),tracked_clean=not git('status','--porcelain','--untracked-files=no'),filter_merge=sys.argv[2],traceback_merge=sys.argv[3],toolchain='offline locked Cargo, pinned 1.98.0 Ruff VM toolchain',runtime_sha256=None,clang_sha256=hashlib.sha256(Path('/workspace/scratch/clang19/bin/clang').read_bytes()).hexdigest())
Path(sys.argv[1]).write_text(json.dumps(manifest,indent=2)+'\n')
PY
for lev in 0 3; do
  binpath=$work/$tag/O$lev/bin; mkdir -p "$binpath"
  export IMRE_DEFAULT_NATIVE_OPT_LEVEL=$lev
  if [ "$lev" = 0 ]; then
    cargo build --offline --locked -j2 -p imre-runtime --lib > "$out/build-runtime.log" 2>&1
    cp "$CARGO_TARGET_DIR/debug/libimre_runtime.a" "$work/$tag/libimre_runtime.a"
    python3 -IB - "$out/source-manifest.json" "$work/$tag/libimre_runtime.a" <<'PY'
from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[1]);j=json.loads(p.read_bytes())
with open(sys.argv[2],'rb') as f:j['runtime_sha256']=hashlib.file_digest(f,'sha256').hexdigest()
p.write_text(json.dumps(j,indent=2)+'\n')
PY
  fi
  cargo build --offline --locked -j2 -p imre-compiler --bin imre > "$out/build-O$lev.log" 2>&1
  cp "$CARGO_TARGET_DIR/debug/imre" "$binpath/imre"
  ln -s "$work/$tag/libimre_runtime.a" "$binpath/libimre_runtime.a"
  sha256sum "$binpath/imre" "$binpath/libimre_runtime.a" > "$out/sha256-O$lev.pending"
  mv "$out/sha256-O$lev.pending" "$out/sha256-O$lev.txt"
  echo "$tag O$lev frozen"
done
