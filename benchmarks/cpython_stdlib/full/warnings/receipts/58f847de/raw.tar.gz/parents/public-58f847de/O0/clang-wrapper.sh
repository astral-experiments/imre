#!/bin/sh
set -eu
ev=${PPID}.$$
op=none
ir=no
for arg; do
  case "$arg" in -O[0-3]) op=$arg;; *.ll) ir=yes;; esac
done
if [ "$ir" = yes ]; then
    awk -F '	' '$1 == "START" {id=$2} END {print id}' "/workspace/shared/downloads/warnings-native-followup/child-four-public/parents/public-58f847de/O0/stdout" > "/workspace/shared/downloads/warnings-native-followup/child-four-public/parents/public-58f847de/O0/audit/$ev.parent"
    {
        if [ "${PYTHONWARNINGS+x}" = x ]; then printf 'PYTHONWARNINGS=%s\n' "$PYTHONWARNINGS"; fi
        if [ "${PYTHONDEVMODE+x}" = x ]; then printf 'PYTHONDEVMODE=%s\n' "$PYTHONDEVMODE"; fi
    } > "/workspace/shared/downloads/warnings-native-followup/child-four-public/parents/public-58f847de/O0/audit/$ev.options"
    ps -p "$PPID" -o pgid= > "/workspace/shared/downloads/warnings-native-followup/child-four-public/parents/public-58f847de/O0/audit/$ev.group"
    cp "/proc/$PPID/cmdline" "/workspace/shared/downloads/warnings-native-followup/child-four-public/parents/public-58f847de/O0/audit/$ev.argv"
    printf '%s\n' "$op" > "/workspace/shared/downloads/warnings-native-followup/child-four-public/parents/public-58f847de/O0/audit/$ev.level"
fi
exec /workspace/scratch/clang19/bin/clang "$@"
