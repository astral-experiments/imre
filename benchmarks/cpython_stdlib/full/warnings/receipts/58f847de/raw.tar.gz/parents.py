"""Execute the four stock parents unchanged; observe codegen on the exact isolated child argv."""
import ast, ctypes, hashlib, json, os, signal, subprocess, sys, tarfile, time
from pathlib import Path
root=Path(__file__).resolve().parent
harness=root/'harness';wk=Path('/workspace/scratch/warnings-next/child-four-public')
label,level=sys.argv[1:]
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
dest=root/'parents'/label/level;dest.mkdir(exist_ok=True,parents=True)
work=wk/label/level/'parents';work.mkdir(exist_ok=True,parents=True)
native=level!='stock'
cli=wk/label/level/'bin/imre' if native else Path('/workspace/scratch/cpytools/bin/python3.14')
keys=json.loads((harness/'original-keys.json').read_bytes())
for src in (harness/'upstream').rglob('*.py'):
    assert sha(src)==sha(wk/'search/test'/src.relative_to(harness/'upstream'))
base='import warnings; [print(f) for f in warnings._get_filters()]'
py="import sys; sys.modules.pop('warnings', None); sys.modules['_warnings'] = None; "+base
conflict="import sys, warnings; sys.stdout.write(str(sys.warnoptions)); warnings.warn('Message', DeprecationWarning)"
env=dict(PATH='/workspace/scratch/clang19/bin:/usr/local/bin:/usr/bin:/bin',TZ='UTC',LC_ALL='C.UTF-8',PYTHONHASHSEED='0',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(work),IMRE_CACHE_DIR=str(work/'cache'))
if native:env['IMRE_ENCODED_FLAGS']='--no-cache'
if not native:env['PYTHONPATH']='/workspace/scratch/cpython/Lib'
argv=[str(cli),'-B',str(harness/'launcher.py'),str(wk/'search')]
if native:
    cc=work/'cc';cc.mkdir(exist_ok=True)
    audit=dest/'audit';audit.mkdir(exist_ok=True)
    wrapper=cc/'clang'
    wrapper.write_text("""#!/bin/sh
set -eu
ev=${PPID}.$$
op=none
ir=no
for arg; do
  case "$arg" in -O[0-3]) op=$arg;; *.ll) ir=yes;; esac
done
if [ "$ir" = yes ]; then
    awk -F '\t' '$1 == "START" {id=$2} END {print id}' "RESULTSTDOUT" > "AUDITDIR/$ev.parent"
    {
        if [ "${PYTHONWARNINGS+x}" = x ]; then printf 'PYTHONWARNINGS=%s\\n' "$PYTHONWARNINGS"; fi
        if [ "${PYTHONDEVMODE+x}" = x ]; then printf 'PYTHONDEVMODE=%s\\n' "$PYTHONDEVMODE"; fi
    } > "AUDITDIR/$ev.options"
    ps -p "$PPID" -o pgid= > "AUDITDIR/$ev.group"
    cp "/proc/$PPID/cmdline" "AUDITDIR/$ev.argv"
    printf '%s\\n' "$op" > "AUDITDIR/$ev.level"
fi
exec /workspace/scratch/clang19/bin/clang "$@"
""".replace('AUDITDIR',str(audit)).replace('RESULTSTDOUT',str(dest/'stdout')))
    wrapper.chmod(0o755)
    (dest/'clang-wrapper.sh').write_text(wrapper.read_text())
    env['PATH']=str(cc)+':'+env['PATH']
now=time.monotonic()
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
with (dest/'stdout').open('wb') as out,(dest/'stderr').open('wb') as err,subprocess.Popen(argv,env=env,cwd=work,stdout=out,stderr=err,start_new_session=True) as p:
    try:rc=p.wait(timeout=3600);expired=False
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL);rc=p.wait();expired=True
while True:
    try:os.waitpid(-1,0)
    except ChildProcessError:break
ev=[x.split('\t',2) for x in (dest/'stdout').read_text().splitlines()]
children={}
for a in sorted((dest/'audit').glob('*.argv')):
    row=a.read_bytes().decode().split('\0')[:-1]
    parent=a.with_suffix('.parent').read_text().strip()
    if parent not in keys:
        continue
    defaults=parent.endswith('.test_default_filter_configuration')
    pure=parent.rsplit('.',2)[1].startswith('Py')
    tail=['-I','-c', (py if pure else base)] if defaults else ['-Werror::DeprecationWarning','-c',conflict]
    if row != [str(cli),'-X','faulthandler',*tail]:
        continue
    assert parent not in children and int(a.with_suffix('.group').read_text())==p.pid
    options=a.with_suffix('.options').read_text().splitlines()
    if not defaults:assert sorted(options)==['PYTHONDEVMODE=','PYTHONWARNINGS=default::DeprecationWarning']
    children[parent]=dict(argv=row,level=a.with_suffix('.level').read_text().strip(),options=options)
parent_ok=rc==0 and all([e[1] for e in ev if e[0]==event]==keys for event in ('REGISTER','START','STOP','PASS')) and ev[-1:]==[['END','testsRun',str(len(keys))]]
fingerprint=any(e==['PROVIDER_IDENTICAL','C/PurePython','False'] for e in ev)
providers={e[1]:ast.literal_eval(e[2]) for e in ev if e[0]=='PROVIDER'}
for name,shape in [('C',('warnings','builtin_function_or_method','_warnings')),('PurePython',('_py_warnings','function','_py_warnings'))]:
    value=providers.get(name)
    fingerprint=fingerprint and isinstance(value,tuple) and len(value)==5 and (value[0],value[2],value[3])==shape and not value[4]

valid=parent_ok and fingerprint and (not native or (set(children)==set(keys) and all(c['level']=='-'+level for c in children.values())))
metadata=dict(argv=argv,env=env,cwd=str(work),executable_sha256=sha(cli),exit=rc,timed_out=expired,seconds=time.monotonic()-now,children=children,parent_ok=parent_ok,valid=valid,stdout_sha256=sha(dest/'stdout'),stderr_sha256=sha(dest/'stderr'))
(dest/'process.json').write_text(json.dumps(metadata,indent=2)+'\n')
arc=root.parent/f'parents-four-warning-children-{label}-{level}.tar.gz'
with tarfile.open(arc,'w:gz') as t:
    paths=[harness,Path(__file__),dest]
    if native:paths.extend([root/label/f'sha256-{level}.txt',root/label/f'build-{level}.log',root/label/'source-manifest.json'])
    for path in paths:t.add(path,arcname=path.relative_to(root))
print(label,level,rc,valid,children.keys(),arc,sha(arc),flush=True)
