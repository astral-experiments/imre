import sys
print("EXECUTABLE", sys.executable, sep="\t", flush=True)
sys.path.insert(0, sys.argv[1])
__import__("selected_four_children")
