import pathlib,shutil,subprocess,hashlib,json,os,time,sys,concurrent.futures
P=pathlib.Path;home=P(__file__).resolve().parent;src=home.parent/'public-src';target=P('/workspace/scratch/warnings-closure/target');shared=P('/workspace/shared/downloads/warnings-native-followup/pairing');work=P('/workspace/scratch/warnings-next/pairing')
head=subprocess.check_output(['git','-C',src,'rev-parse','HEAD'],text=True).strip();tag='public-'+head[:8];out=shared/tag;out.mkdir(exist_ok=True);ct=out/'child-tools';ct.mkdir(exist_ok=True)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
env=dict(os.environ,PATH='/workspace/.cargo/bin:'+os.environ['PATH'],RUSTUP_HOME='/workspace/.rustup',CARGO_HOME='/workspace/.cargo',RUSTUP_TOOLCHAIN='1.98.0',CARGO_TARGET_DIR=str(target),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',TMPDIR=str(home))
assert head==sys.argv[1] and len(head)==40
assert not subprocess.check_output(['git','-C',src,'status','--porcelain'])
def build(lev):
 assert subprocess.run(['git','-C',src,'diff','--quiet','HEAD']).returncode==0
 env['IMRE_DEFAULT_NATIVE_OPT_LEVEL']=lev[1:]
 exeDir=work/'bin'/tag if lev=='O3' else work/'children'/(tag+'-O0');exeDir.mkdir(exist_ok=True)
 args=['cargo','build','--offline','--locked','-j2','-p','imre-compiler']+(['-p','imre-runtime'] if lev=='O3' else ['--bin','imre'])
 with (ct/('cargo-'+lev+'.log')).open('wb') as f:subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,cwd=src,check=True)
 sh={}
 for n in ('imre','libimre_runtime.a'):
  if lev=='O0' and n=='libimre_runtime.a':
   frozen=work/'bin'/tag/n;assert sha(frozen)==sha(target/'debug'/n);os.link(frozen,exeDir/n)
  else:shutil.copy2(target/'debug'/n,exeDir/n)
  sh[n]=sha(exeDir/n)
 if lev=='O3':
  manifest=dict(head=head,repo=str(src),tree=subprocess.check_output(['git','-C',src,'rev-parse','HEAD^{tree}'],text=True).strip(),files=sh,clang_sha256=sha(P('/workspace/scratch/clang19/bin/clang')))
  (out/'tools.json').write_text(json.dumps(manifest,indent=2)+'\n')
 else:(ct/'sha256-O0.txt').write_text(''.join(h+'  '+str(exeDir/n)+'\n' for n,h in sh.items()))
 meta=dict(head=head,tree=subprocess.check_output(['git','-C',src,'rev-parse','HEAD^{tree}'],text=True).strip(),repo=str(src),status=subprocess.check_output(['git','-C',src,'status','--porcelain'],text=True),argv=args,level=lev,default_native_level=env.get('IMRE_DEFAULT_NATIVE_OPT_LEVEL','3'),files=sh,log_sha256=sha(ct/('cargo-'+lev+'.log')))
 (ct/('build-'+lev+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
 print('frozen',lev,sh,flush=True)
def qualify(lev):
 label='selected_shutdown_children';driver=work/'bin'/tag/'imre' if lev=='O3' else work/'children'/(tag+'-O0')/'imre'
 args=[sys.executable,'-IB',str(shared/'children.py'),tag,lev,label];sub=subprocess.Popen(args)
 folder=out/('children-'+lev+'-'+label)
 while not (folder/(label+'.attempt.json')).exists() and sub.poll() is None:time.sleep(.1)
 observer=subprocess.run([sys.executable,'-IB',shared/'child-observer.py',tag,lev,label]);sub.wait();print('qualification',lev,sub.returncode,observer.returncode,flush=True);subprocess.run([sys.executable,'-IB',shared/'seal-child-level.py',tag,lev,label],check=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 fs=[]
 for lev in ('O3','O0'):
  build(lev);fs.append(pool.submit(qualify,lev))
 for f in fs:f.result()
subprocess.run([sys.executable,'-IB',shared/'child-ledger.py',tag,'selected_shutdown_children'],check=True)
