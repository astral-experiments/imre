#!/bin/sh
opt=none
ir=no
for a do
  case "$a" in -O[0-3]) opt=$a;; *.ll) ir=yes;; esac
done
printf '%s\t%s\t%s\t%s\n' "$$" "$PPID" "$opt" "$ir" >> /workspace/scratch/warnings-next/pairing/children/public-061b0196-run-O3-selected_shutdown_children/clang.tsv
exec /workspace/scratch/clang19/bin/clang "$@"
