import sys

if len(sys.argv) != 3 or sys.argv[1] != "/workspace/scratch/warnings-next/pairing/search":
    print("The suite launcher received a child interpreter invocation.", file=sys.stderr)
    sys.exit(125)
print("EXECUTABLE", sys.executable, sep="\t", flush=True)
sys.path.insert(0, sys.argv[1])
__import__(sys.argv[2])
