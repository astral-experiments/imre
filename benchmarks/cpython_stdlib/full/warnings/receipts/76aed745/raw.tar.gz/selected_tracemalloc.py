import sys
import unittest
import test.test_warnings as suite_module


def event(kind, identity, detail):
    print(kind, identity, detail, sep="\t", flush=True)


def register(item):
    if isinstance(item, unittest.TestSuite):
        for child in item:
            register(child)
    else:
        event("REGISTER", item.id(), "")


class Result(unittest.TestResult):
    def startTest(self, test):
        super().startTest(test)
        event("START", test.id(), "")

    def stopTest(self, test):
        super().stopTest(test)
        event("STOP", test.id(), "")

    def addSuccess(self, test):
        super().addSuccess(test)
        event("PASS", test.id(), "")

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        event("SKIP", test.id(), repr(reason))

    def addFailure(self, test, err):
        super().addFailure(test, err)
        event("FAIL", test.id(), repr(self.failures[-1][1]))

    def addError(self, test, err):
        super().addError(test, err)
        event("ERROR", test.id(), repr(self.errors[-1][1]))

    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err)
        event("XFAIL", test.id(), repr(self.expectedFailures[-1][1]))

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test)
        event("XPASS", test.id(), "")

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        if err is None:
            event("SUBPASS", test.id(), repr(subtest.id()))
        else:
            event("SUBFAIL", test.id(), repr((subtest.id(), str(err[1]))))


def fingerprint(label, provider):
    if provider is None:
        event("PROVIDER", label, "None")
    else:
        event("PROVIDER", label, repr((provider.__name__, getattr(provider, "__file__", None),
              type(provider.warn).__name__, getattr(provider.warn, "__module__", None),
              getattr(provider, "_use_context", None))))


fingerprint("original", suite_module.original_warnings)
fingerprint("C", suite_module.c_warnings)
fingerprint("PurePython", suite_module.py_warnings)
event("PROVIDER_IDENTICAL", "C/PurePython", str(suite_module.c_warnings is suite_module.py_warnings))
suite = unittest.defaultTestLoader.loadTestsFromNames(['test.test_warnings.PyWarningsDisplayTests.test_tracemalloc'])
register(suite)
event("COUNT", "registered", str(suite.countTestCases()))
result = Result()
result.startTestRun()
suite.run(result)
result.stopTestRun()
event("END", "testsRun", str(result.testsRun))
if not result.wasSuccessful():
    sys.exit(1)
