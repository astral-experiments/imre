#!/bin/bash
set -eu
cd /workspace/imre-campaign
base=$PWD
for test in fixture retry; do
    python3 evidence/tools/run.py --owner "stock-$test" --opt stock --scope selected-caller --rev 5607950ef232dad16d75c0cf53101d9649d89115 --timeout 45 -- "$base/cpython/python" -B "$base/controls/selected.py" "$test" || true
done
while ! test -s products/candidate/build.sha256; do
    if test -s evidence/reviewedbuild/build.exit && ! rg -qx '0' evidence/reviewedbuild/build.exit; then exit 1; fi
    sleep 5
done
validate() {
    level=$1
    driver="$base/products/candidate/cases-O$level"
    controls="$base/products/candidate/selected-O$level"
    native=(bash "$base/evidence/tools/native.sh" candidate "$level")
    "${native[@]}" selected-caller-build controls-build --timeout 420 -- "$base/products/candidate/imre" build "$base/controls/selected.py" --runtime-imports --no-cache --opt-level "$level" --module-root "$base/controls" -o "$controls" || return 1
    for test in rebound fixture retry; do
        "${native[@]}" selected-caller "$test" --timeout 60 -- "$controls" "$test" || true
    done
    "${native[@]}" build || return 1
    "${native[@]}" unchanged-occurrence-1 communicate --timeout 360 --trace -- "$driver" test.test_subprocess.ProcessTestCase.test_communicate && python3 "$base/evidence/tools/wire.py" "$base/evidence/runs/candidate-communicate-O$level" || true
    CAMPAIGN_CHILD="$base/cpython/python" "${native[@]}" full-suite-stock-child full-stock-child --timeout 400 -- "$driver" all || true
}
validate 0 &
pid0=$!
validate 3 &
pid3=$!
wait "$pid0"
wait "$pid3"
