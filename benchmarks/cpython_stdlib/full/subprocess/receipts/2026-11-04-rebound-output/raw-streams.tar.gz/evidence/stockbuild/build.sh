#!/bin/bash
set -eu
cd /workspace/imre-campaign
exec 3>evidence/stockbuild/commands.log
export BASH_XTRACEFD=3
set -x
trap 'printf "%s\n" "$?" > /workspace/imre-campaign/evidence/stockbuild/exit-status' EXIT
git clone --quiet --depth=1 --branch v3.14.5 https://github.com/python/cpython.git cpython
cd cpython
git rev-parse HEAD | tee ../evidence/stockbuild/revision
test "$(git rev-parse HEAD)" = 5607950ef232dad16d75c0cf53101d9649d89115
./configure --without-ensurepip >../evidence/stockbuild/configure.stdout 2>../evidence/stockbuild/configure.stderr
make -j3 >../evidence/stockbuild/make.stdout 2>../evidence/stockbuild/make.stderr
./python -c 'import sys,subprocess,_posixsubprocess,test.test_subprocess; print(sys.version, sys.executable, subprocess.__file__,test.test_subprocess.__file__)' | tee ../evidence/stockbuild/usability
sha256sum python Lib/subprocess.py Lib/test/test_subprocess.py | tee ../evidence/stockbuild/sha256sums
