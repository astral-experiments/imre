#!/bin/bash
set -eu
cd /workspace/imre-campaign
for ((i=0; i<250; i++)); do
    if [[ -x imre/target/release/imre && -s imre/target/release/libimre_runtime.a ]]; then break; fi
    sleep 4
done
test -x imre/target/release/imre
test -s imre/target/release/libimre_runtime.a
mkdir -p products/public
cp --reflink=auto imre/target/release/{imre,libimre_runtime.a} products/public/
git -C imre rev-parse HEAD > products/public/revision
sha256sum products/public/{imre,libimre_runtime.a} > products/public/build.sha256
for level in 0 3; do
    bash evidence/tools/native.sh public "$level" build || continue
    bash evidence/tools/native.sh public "$level" unchanged-occurrence-1 communicate --timeout 240 --trace -- "$PWD/products/public/cases-O$level" test.test_subprocess.ProcessTestCase.test_communicate || continue
    python3 evidence/tools/wire.py "evidence/runs/public-communicate-O$level"
done
