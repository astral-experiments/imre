#!/usr/bin/env python3
"""Package completed Ruff Cloud runs. Run from the original campaign workspace."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import gzip
import io
import json
import os
import re
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "evidence"
PRODUCTS = ROOT / "products"
STOCK = "5607950ef232dad16d75c0cf53101d9649d89115"
ORIGINAL = "test.test_subprocess.ProcessTestCase.test_communicate"
SOURCE = PRODUCTS / "candidate.bundle"

# Only known evidence paths are eligible. Refuse suspicious path names, links,
# binaries, and recognizable credentials without logging the matched data.
SECRET_NAME = re.compile(r"(?i)^(?:\.env(?:\..*)?|\.netrc|\.git-credentials|id_(?:rsa|ed25519)|credentials(?:\..*)?|.*\.(?:p12|pfx|pem|key))$")
SECRET_DATA = re.compile(
    rb"(?:-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:gh[pousr]_[0-9A-Za-z]{30,}"
    rb"|github_pat_[0-9A-Za-z_]{40,}|AKIA[0-9A-Z]{16}|glpat-[a-zA-Z0-9_-]{18,}"
    rb"|xox[baprs]-[A-Za-z0-9-]{18,}|sk-(?:proj-)?[A-Za-z0-9_-]{35,})"
    rb"|(?i:authorization:\s*(?:bearer|basic)\s+[A-Za-z0-9+/._=-]{16,}"
    rb"|https?://[^/\s:@]+:[^/\s@]{3,}@))"
)


def rel(path):
    return path.relative_to(ROOT).as_posix()


def inspect_text(name, data):
    if any(SECRET_NAME.fullmatch(part) for part in Path(name).parts):
        raise ValueError(f"credential-like file name: {name}")
    if b"\0" in data or SECRET_DATA.search(data):
        raise ValueError(f"binary or credential pattern detected in {name}")


def digest(path):
    with path.open("rb") as stream:
        h = sha256()
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
        return h.hexdigest()


def dump(obj):
    return (json.dumps(obj, indent=2, ensure_ascii=True) + "\n").encode()


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT / "imre"), *args],
                                   stderr=subprocess.PIPE)


def source_info():
    git("bundle", "verify", str(SOURCE))
    with SOURCE.open("rb") as stream:
        assert stream.readline() == b"# v2 git bundle\n"
        prereq = stream.readline().decode().split(maxsplit=1)[0].removeprefix("-")
        head, ref = stream.readline().decode().split()
        assert stream.readline() == b"\n"
    assert prereq == (PRODUCTS / "public/revision").read_text().strip()
    assert head == (PRODUCTS / "candidate/revision").read_text().strip()
    assert head == (EVIDENCE / "reviewedbuild/revision").read_text().strip()
    assert ref.startswith("refs/heads/charlie/")
    for rev in git("rev-list", f"{prereq}..{head}").decode().splitlines():
        authors = git("show", "-s", "--format=%an <%ae>%n%cn <%ce>", rev).decode().splitlines()
        assert authors == ["Charlie Marsh <charlie.r.marsh@gmail.com>"] * 2
        inspect_text("commit message", git("show", "-s", "--format=%B", rev))
        changed = git("diff-tree", "--no-commit-id", "--name-only", "-z", "-r",
                      "--diff-filter=ACMRT", rev).decode().strip("\0").split("\0")
        for name in filter(None, changed):
            inspect_text(name, git("show", f"{rev}:{name}"))
    return {"repository": "https://github.com/astral-experiments/imre", "head": head,
            "ref": ref, "base_prerequisite": prereq, "bundle_sha256": digest(SOURCE),
            "apply": "Fetch the public base prerequisite first. In that clone, run "
                     f"git bundle verify /path/to/source.bundle and git fetch /path/to/source.bundle {ref}."}


def result_totals(output):
    matches = re.findall(r"^RESULT (\d+) (\d+) (\d+) (\d+)$", output, re.M)
    if not matches:
        return None
    assert len(matches) == 1
    ran, fails, errors, skipped = map(int, matches[0])
    return {"ran": ran, "passed": ran - fails - errors - skipped,
            "failures": fails, "errors": errors, "skipped": skipped}


def suite_detail(stderr, totals):
    # TextTestRunner emits the test id on the first line, then an optional
    # description. Some tests emit output of their own between id and status.
    skips = []
    occurrences = Counter()
    current = None
    for line in stderr.splitlines():
        if line.startswith(("======", "------")):
            break
        m = re.match(r"^\S+ \((test\.test_subprocess\.[^)\n]+)\)", line)
        if m:
            current = m[1]
            occurrences[current] += 1
        m = re.search(r"(?:\.\.\. |^)skipped (.*)$", line)
        if m and current:
            skips.append({"test": current, "occurrence": occurrences[current], "reason": m[1]})
    problems = []
    for block in re.split(r"^={20,}\n", stderr, flags=re.M)[1:]:
        m = re.match(r"^(ERROR|FAIL): .*? \((test\.test_subprocess\.[^)]+)\)", block)
        if m:
            traceback = re.split(r"\n-{20,}\nRan ", block, maxsplit=1)[0].strip().splitlines()
            problems.append({"kind": m[1], "test": m[2], "last_traceback_line": traceback[-1]})
    if totals:
        assert len(skips) == totals["skipped"], (len(skips), totals)
        assert len(problems) == totals["errors"] + totals["failures"]
    return {"nonpassing_cases": problems, "skips": skips}


def classification(receipt):
    scope = receipt["scope"]
    if scope == "unchanged-occurrence-1":
        if receipt["argv"][-1] == ORIGINAL:
            return "original-communicate-occurrence-1"
        return "other-original-occurrence-1"
    return {"full-suite": "stock-full-suite", "full-suite-stock-child": "imre-full-suite-with-stock-child",
            "selected-caller": "selected-caller", "selected-caller-build": "selected-caller-build",
            "driver-build": "original-driver-build"}.get(scope, scope)


def physical_runs():
    rows = []
    for folder in sorted((EVIDENCE / "runs").iterdir()):
        receipt = json.loads((folder / "receipt.json").read_bytes())
        assert receipt["owner"] == folder.name
        row = {k: receipt.get(k) for k in ("owner", "scope", "source", "optimization", "exit", "argv",
                                           "started_utc", "pid", "timed_out", "command_image_sha256")}
        row["classification"] = classification(receipt)
        if "rewrapped" in folder.name and receipt["scope"] in {"selected-caller", "selected-caller-rewrapped-streams"}:
            row["variant_of"] = "test_communicate_pipe_fd_leak"
            row["selected_caller_source"] = "stage/rewrapped.py"
            row["variant"] = "reopen child output streams"
        row["receipt"] = rel(folder / "receipt.json")
        for stream in ("stdout", "stderr"):
            h = digest(folder / stream)
            if stream + "_sha256" in receipt:
                assert receipt[stream + "_sha256"] == h
            row[stream] = {"path": rel(folder / stream), "sha256": h}
        for k in ("note", "supervisor_exit", "terminal_wait", "adopted"):
            if k in receipt:
                row[k] = receipt[k]
        if row["exit"] is None:
            row["exit_status"] = "target exit unknown"
        stdout = (folder / "stdout").read_text(errors="replace")
        if row["classification"].startswith(("stock-full-", "imre-full-", "original-", "other-original-")):
            if row["scope"] != "driver-build":
                row["unittest_result"] = result_totals(stdout)
        if row["scope"].startswith("full-suite"):
            row["suite_detail"] = suite_detail((folder / "stderr").read_text(errors="replace"),
                                               row["unittest_result"])
        if row["scope"] in ("full-suite", "full-suite-stock-child", "unchanged-occurrence-1"):
            row["driver"] = next((line for line in stdout.splitlines() if line.startswith("MODULE ")), None)
            row["configured_child_executable"] = receipt.get("environment", {}).get("IMRE_PYTHON")
        if (folder / "wire.json").is_file():
            row["wire"] = json.loads((folder / "wire.json").read_bytes())
            row["wire_path"] = rel(folder / "wire.json")
        rows.append(row)
    stock = next(r["suite_detail"] for r in rows if r["owner"] == "stock-full-r2")
    stock_skips = {(s["test"], s["occurrence"]) for s in stock["skips"]}
    for row in rows:
        if "suite_detail" in row:
            detail = row["suite_detail"]
            skips = {(s["test"], s["occurrence"]) for s in detail["skips"]}
            detail["extra_skips_vs_stock_full_r2"] = sorted(skips - stock_skips)
            detail["missing_skips_vs_stock_full_r2"] = sorted(stock_skips - skips)
    return rows


def archive_files():
    paths = {EVIDENCE / "preflight.txt", EVIDENCE / "source-sha256.txt",
             ROOT / "stage/run_original.py", ROOT / "stage/rewrapped.py", ROOT / "stage/test/test_subprocess.py"}
    paths.update(EVIDENCE.glob("*.patch"))
    for root in ("controls", "probes"):
        paths.update((ROOT / root).glob("*.py"))
    for pattern in ("*.py", "*.sh"):
        paths.update((EVIDENCE / "tools").glob(pattern))
    for folder in EVIDENCE.glob("*build"):
        for f in folder.iterdir():
            if re.fullmatch(r"smoke-O[03]", f.name):
                continue
            paths.add(f)
    for folder in ("public", "candidate"):
        paths.add(PRODUCTS / folder / "revision")
        paths.update((PRODUCTS / folder).glob("*.sha256"))
    paths.update(p for p in (EVIDENCE / "runs").rglob("*") if p.is_file())
    return sorted(paths)


def build_records():
    records = []
    for folder in sorted(EVIDENCE.glob("*build")):
        def add(owner, opt, exitfile, streams, commands):
            stat = exitfile.read_text().strip()
            match = re.search(r"(?:^|exit=)(\d+)$", stat)
            assert match, exitfile
            records.append({"owner": owner, "optimization": opt, "exit": int(match[1]),
                            "status_receipt": rel(exitfile),
                            "streams": [rel(p) for p in streams], "command_records": [rel(p) for p in commands]})
        if folder.name == "stockbuild":
            add("stockbuild", "stock configure defaults", folder / "exit-status",
                sorted((*folder.glob("*.stdout"), *folder.glob("*.stderr"))),
                [folder / "commands.log", folder / "build.sh"])
        else:
            add(folder.name, "cargo-release", folder / "build.exit",
                [folder / "build.stdout", folder / "build.stderr"], [folder / "build.info"])
        for f in sorted(folder.glob("smoke-*.exit")):
            stem = f.stem
            add(folder.name + "/" + stem, stem.split("-")[-1], f,
                [f.with_suffix(".stdout"), f.with_suffix(".stderr")],
                [folder / "howto", folder / "smoke.py"])
    return records


def add_tar(tar, name, data, mode=0o644):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = mode
    tar.addfile(info, io.BytesIO(data))


def package():
    source = source_info()
    rows = physical_runs()
    builds = build_records()
    assert (EVIDENCE / "stockbuild/revision").read_text().strip() == STOCK
    unchanged = digest(ROOT / "stage/test/test_subprocess.py")
    assert unchanged == digest(ROOT / "cpython/Lib/test/test_subprocess.py")
    assert digest(ROOT / "stage/rewrapped.py") == digest(EVIDENCE / "tools/rewrapped.py")
    products = {}
    for name in ("public", "candidate"):
        products[name] = {p.name: digest(p) for p in sorted((PRODUCTS / name).iterdir())
                          if p.is_file() and p.name != "revision" and p.suffix != ".sha256"}
    index = {"format": 1, "source_bundle": source, "cpython": {"tag": "v3.14.5", "commit": STOCK,
             "frozen_test_subprocess_py_sha256": unchanged, "stock_interpreter_sha256": digest(ROOT / "cpython/python")},
             "original": {"id": ORIGINAL, "occurrence": 1, "stock_optimization": "stock",
                          "imre_optimizations": ["O0", "O3"]},
             "product_sha256": products, "builds_and_smoke": builds, "runs": rows,
             "notes": ["Each owner identifies one physical invocation. See the full receipt for the child selection, command, and working directory.",
                       "The imre-full-suite-with-stock-child classification uses the Imre parent driver with pinned stock CPython as sys.executable.",
                       "RESULT gives observed unittest totals independently of process exit. stock-full lost its target exit during orphan collection and was repeated as stock-full-r2.",
                       "Selected callers use independent fixture sources and remain separate from original CPython outcomes.",
                       "Smoke status files record owner, optimization and phase; howto records the build command template.",
                       "Build and test binary contents are excluded from raw-streams.tar.gz. Product hashes identify the reviewed and public binaries."],
             "files_in_stream_archive": {}}
    out = ROOT / "handoff"
    out.mkdir(exist_ok=True)
    with TemporaryDirectory(dir=out) as tmpdir:
        tmp = Path(tmpdir)
        shutil.copyfile(SOURCE, tmp / "source.bundle")
        raw = tmp / "raw-streams.tar.gz"
        with raw.open("wb") as output, gzip.GzipFile(filename="", fileobj=output, mode="wb", mtime=0) as compressed, tarfile.open(mode="w|", fileobj=compressed, format=tarfile.PAX_FORMAT) as tar:
            for path in archive_files():
                name = rel(path)
                if not path.is_file() or path.resolve() != path or path.stat().st_size > 64 * 1024 * 1024:
                    raise ValueError(f"unexpected archive member: {name}")
                if any(SECRET_NAME.fullmatch(part) for part in path.parts):
                    raise ValueError(f"sensitive file path: {name}")
                data = path.read_bytes()
                inspect_text(name, data)
                add_tar(tar, name, data, 0o755 if path.suffix == ".sh" else 0o644)
                index["files_in_stream_archive"][name] = sha256(data).hexdigest()
        index["raw_streams_sha256"] = digest(raw)
        data = dump(index)
        inspect_text("receipt-index.json", data)
        (tmp / "receipt-index.json").write_bytes(data)
        objects = ("source.bundle", "raw-streams.tar.gz", "receipt-index.json")
        (tmp / "SHA256SUMS").write_text("".join(f"{digest(tmp / name)}  {name}\n" for name in objects))
        with tarfile.open(raw, "r:gz") as tar:
            seen = {}
            for member in tar:
                assert member.isfile()
                seen[member.name] = sha256(tar.extractfile(member).read()).hexdigest()
            assert seen == index["files_in_stream_archive"]
        assert digest(tmp / "source.bundle") == source["bundle_sha256"]
        for name in (*objects, "SHA256SUMS"):
            os.replace(tmp / name, out / name)
    print(f"{len(rows)} run receipts, {len(builds)} build/smoke records, {len(seen)} raw files")
    print((out / "SHA256SUMS").read_text(), end="")


if __name__ == "__main__":
    package()
