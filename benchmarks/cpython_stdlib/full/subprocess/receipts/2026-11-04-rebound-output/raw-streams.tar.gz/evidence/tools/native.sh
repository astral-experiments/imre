#!/bin/bash
set -eu
base=/workspace/imre-campaign
cd "$base"
phase=$1
level=$2
shift 2
source_dir="$base/products/$phase"
rev=$(cat "$source_dir/revision")
imre="$source_dir/imre"
runtime="$source_dir/libimre_runtime.a"
clang="$base/stage/clang19/root/usr/lib/llvm-19/bin/clang"
export PATH="${clang%/*}:/usr/bin:/bin"
export LD_LIBRARY_PATH="$base/stage/clang19/root/usr/lib/x86_64-linux-gnu"
export IMRE_PYTHON="${CAMPAIGN_CHILD:-$imre}"
export PYTHONPATH="$base/stage"
export IMRE_CACHE_DIR="$base/cache/$phase-O$level"
export IMREFLAGS="--clang $clang --runtime $runtime --opt-level $level -C link-arg=-fuse-ld=lld -C link-arg=-Wl,--threads=1"
runner=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
record=( "$runner" "$base/evidence/tools/run.py" --opt "O$level" --rev "$rev" )
entry="$base/stage/run_original.py"
binary="$source_dir/cases-O$level"
mode=$1
shift
if [[ $mode == build ]]; then
    "${record[@]}" --scope driver-build --owner "$phase-build-O$level" --timeout 500 -- "$imre" build "$entry" --runtime-imports --module-root "$base/stage" --no-cache --opt-level "$level" --runtime "$runtime" --clang "$clang" -o "$binary"
    sha256sum "$binary" >> "$source_dir/native.sha256"
else
    owner=$1
    shift
    mkdir -p "$base/work/$phase-$owner-O$level"
    cd "$base/work/$phase-$owner-O$level"
    "${record[@]}" --scope "$mode" --owner "$phase-$owner-O$level" "$@" 
fi
