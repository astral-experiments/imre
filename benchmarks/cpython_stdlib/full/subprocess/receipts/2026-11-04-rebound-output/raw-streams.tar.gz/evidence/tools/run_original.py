"""Run a discovered pinned subprocess occurrence, or the entire discovered suite."""
import importlib
import sys
import unittest

def leaves(suite):
    for test in suite:
        if isinstance(test, unittest.TestSuite):
            yield from leaves(test)
        else:
            yield test

support = importlib.import_module("test.support")
support.use_resources = {}
module = importlib.import_module("test.test_subprocess")
print("MODULE", module.__file__, "ENGINE", sys.implementation.name, "EXECUTABLE", sys.executable, flush=True)
loader = unittest.TestLoader()
suite = loader.loadTestsFromModule(module)
if loader.errors:
    raise RuntimeError(loader.errors)
rows = list(leaves(suite))
counts = {}
selection = []
wanted = sys.argv[1]
for ordinal, test in enumerate(rows, 1):
    name = test.id()
    occurrence = counts.get(name, 0) + 1
    counts[name] = occurrence
    print("REGISTER", ordinal, occurrence, name, sep="\t")
    if wanted == name and occurrence == 1:
        selection.append(test)
print("DISCOVERED", len(rows), flush=True)
if wanted != "all":
    if len(selection) != 1:
        raise RuntimeError(("missing selection", wanted, len(selection)))
    suite = unittest.TestSuite(selection)
result = unittest.TextTestRunner(verbosity=2).run(suite)
print("RESULT", result.testsRun, len(result.failures), len(result.errors), len(result.skipped), flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
