"""Verify successful pipe syscalls against the unchanged communicate assertions."""
import json
from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
record = json.loads((root / "receipt.json").read_text())
assert record["exit"] == 0 and not record["timed_out"], record
calls = []
images = {}
exits = {}
parents = {}
for path in root.glob("trace.*"):
    pid = int(path.suffix[1:])
    for line in path.open(errors="replace"):
        m = re.match(r'(read|write)\((\d+)<pipe:\[(\d+)\]>, "([^"\\]*)", \d+\)\s+= (\d+)$', line)
        if m:
            op, fd, pipe, data, size = m.groups()
            if int(size) == len(data) and data in ("banana","pineapple"):
                calls.append(dict(pid=pid, op=op, fd=int(fd), pipe=int(pipe), data=data, returned=int(size)))
        if line.startswith("execve(") and re.search(r' = 0$', line):
            images.setdefault(pid, []).append(line.strip())
        m = re.match(r'\+\+\+ exited with (\d+) \+\+\+', line)
        if m:
            exits[pid] = int(m[1])
        m = re.match(r'(?:vfork|fork|clone3?)\(.*\)\s+= (\d+)$', line)
        if m:
            parents[int(m[1])] = pid
leaves = [pid for pid in images if all(any(e["pid"] == pid and e["op"] == op and e["data"] == data and e["fd"] == fd for e in calls) for op, data, fd in [("read","banana",0), ("write","banana",1), ("write","pineapple",2)])]
assert len(leaves) == 1, (leaves, calls)
leaf = leaves[0]
assert exits.get(leaf) == 0
lineage = []
pid = leaf
while pid:
    lineage.append(dict(pid=pid, images=images.get(pid, []), exit=exits.get(pid)))
    pid = parents.get(pid)
for e in [v for v in calls if v["pid"] == leaf]:
    opposite = "write" if e["op"] == "read" else "read"
    assert any(v["pid"] in {p["pid"] for p in lineage[1:]} and v["pipe"] == e["pipe"] and v["op"] == opposite and v["data"] == e["data"] for v in calls), e
result = dict(owner=record["owner"], optimization=record["optimization"], leaf_pid=leaf, lineage=lineage, matched_pipe_events=calls)
(root/"wire.json").write_text(json.dumps(result, indent=2)+"\n")
print(root.name, leaf, len(calls), "pipe events")
