"""Selected public-API variant of the pinned descriptor-closure caller."""
import importlib
import os
import subprocess
import sys
import unittest
from unittest import mock

support = importlib.import_module("test.support")
support.use_resources = {}
module = importlib.import_module("test.test_subprocess")
class RewrappedOutputs(subprocess.Popen):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name in ("stdout", "stderr"):
            original = getattr(self, name)
            if original is not None:
                replacement = os.fdopen(os.dup(original.fileno()), "rb")
                original.close()
                setattr(self, name, replacement)

case = module.ProcessTestCase("test_communicate_pipe_fd_leak")
print("SELECTED REWRAPPED OUTPUTS", case.id(), module.__file__, flush=True)
with mock.patch.object(subprocess, "Popen", RewrappedOutputs):
    result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
sys.exit(0 if result.wasSuccessful() else 1)
