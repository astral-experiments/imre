"""One physical owner per directory. Keep streams and collect orphan descendants on timeout."""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parents[2]
p = argparse.ArgumentParser()
for key in ("owner", "scope", "opt", "rev"):
    p.add_argument("--" + key, required=True)
p.add_argument("--timeout", type=int, default=120)
p.add_argument("--trace", action="store_true")
p.add_argument("argv", nargs=argparse.REMAINDER)
a = p.parse_args()
argv = a.argv[1:] if a.argv[:1] == ["--"] else a.argv
run_dir = BASE / "evidence" / "runs" / a.owner
run_dir.mkdir()
if ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), "prctl subreaper")
# Keep the process suite's inherited environment small and reproducible.
env = {k:os.environ[k] for k in ("PATH","HOME","TMPDIR","IMREFLAGS","IMRE_PYTHON","IMRE_CACHE_DIR","PYTHONPATH","LD_LIBRARY_PATH") if k in os.environ}
env.update(LANG="C.UTF-8", PYTHONDONTWRITEBYTECODE="1", RAYON_NUM_THREADS="2")
# Bound the number of descendant tasks even when a failing test starts children.
def limits():
    soft, hard = resource.getrlimit(resource.RLIMIT_NPROC)
    current = int(Path("/sys/fs/cgroup/pids.current").read_text())
    cap = current + 128
    if hard >= 0:
        cap = min(hard, cap)
    resource.setrlimit(resource.RLIMIT_NPROC, (cap, cap))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

def digest(path):
    with open(path, "rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

cmd = argv
if a.trace:
    cmd = ["strace", "-ff", "-yy", "-s", "160", "-o", str(run_dir / "trace"), "-e",
           "trace=execve,clone,clone3,fork,vfork,read,write,readv,writev,exit,exit_group,wait4", "--", *argv]
record = dict(owner=a.owner, scope=a.scope, optimization=a.opt, source=a.rev, argv=cmd, cwd=os.getcwd(),
              command_image_sha256=digest(argv[0]), started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              environment={k:env.get(k) for k in ("IMRE_PYTHON","IMREFLAGS","IMRE_RUNTIME_IMPORTS","IMRE_CACHE_DIR","TMPDIR","PYTHONPATH","PATH","PYTHONDONTWRITEBYTECODE","RAYON_NUM_THREADS")})
receipt = run_dir / "receipt.json"
start = time.monotonic()
with (run_dir / "stdout").open("wb") as out, (run_dir / "stderr").open("wb") as err:
    proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=out, stderr=err, env=env, preexec_fn=limits, start_new_session=True)
    record["pid"] = proc.pid
    receipt.write_text(json.dumps(record, indent=2) + "\n")
    record["timed_out"] = False
    try:
        status = proc.wait(timeout=a.timeout)
    except subprocess.TimeoutExpired:
        record["timed_out"] = True
        os.killpg(proc.pid, signal.SIGKILL)
        status = proc.wait()
    record["exit"] = status
    receipt.write_text(json.dumps(record, indent=2) + "\n")
# Reap only descendants of this run, including those that made their own process group.
adopted = []
while True:
    try:
        pid, wait = os.waitpid(-1, os.WNOHANG)
    except ChildProcessError:
        break
    if pid:
        adopted.append([pid, os.waitstatus_to_exitcode(wait)])
    else:
        for child in Path("/proc").glob("[0-9]*"):
            try:
                lines = (child / "status").read_text().splitlines()
                if any(line.split() == ["PPid:", str(os.getpid())] for line in lines):
                    os.kill(int(child.name), signal.SIGKILL)
            except (FileNotFoundError, ProcessLookupError):
                pass
        time.sleep(0.05)
record.update(duration_seconds=round(time.monotonic()-start,3), adopted=adopted, terminal_wait="ECHILD",
              stdout_sha256=digest(run_dir/"stdout"), stderr_sha256=digest(run_dir/"stderr"))
receipt.write_text(json.dumps(record, indent=2) + "\n")
print(a.owner, "opt", a.opt, "pid", proc.pid, "exit", status, "timeout", record["timed_out"], "duration", record["duration_seconds"], flush=True)
raise SystemExit(124 if record["timed_out"] else status if status >= 0 else 128-status)
