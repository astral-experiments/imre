import os
import subprocess

for attribute in ("stdout", "stderr"):
    with subprocess.Popen(["/bin/sh", "-c", "printf child; printf diagnostic >&2"],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE) as child:
        original = getattr(child, attribute)
        r, w = os.pipe()
        try:
            os.write(w, b"replacement")
        finally:
            os.close(w)
        with os.fdopen(r, "rb") as replacement:
            setattr(child, attribute, replacement)
            try:
                result = child.communicate()
                print(attribute, result, replacement.closed, child.returncode, flush=True)
                expected = (b"replacement", b"diagnostic") if attribute == "stdout" else (b"child", b"replacement")
                assert result == expected and replacement.closed and child.returncode == 0
                assert not original.closed
            finally:
                original.close()
