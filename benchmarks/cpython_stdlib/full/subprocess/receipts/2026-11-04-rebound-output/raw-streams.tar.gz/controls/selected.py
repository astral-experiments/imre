import sys
if sys.argv[1] == "fixture":
    import boxed_subprocess_buffering
    boxed_subprocess_buffering.current()
elif sys.argv[1] == "retry":
    import retry_output
elif sys.argv[1] == "rebound":
    import rebound_output
else:
    raise ValueError(sys.argv[1])
