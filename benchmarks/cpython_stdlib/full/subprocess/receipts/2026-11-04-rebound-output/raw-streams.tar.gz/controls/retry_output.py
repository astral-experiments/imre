import os
import subprocess

pipe = subprocess.PIPE
with subprocess.Popen(["/bin/sh", "-c", "printf child; printf marker >&2"], stdout=pipe, stderr=pipe) as child:
    r, w = os.pipe()
    with child.stdout as original, os.fdopen(r, "rb") as reader, os.fdopen(w, "wb", buffering=0) as writer:
        child.stdout = reader
        writer.write(b"first")
        try:
            child.communicate(timeout=0.4)
        except subprocess.TimeoutExpired as exc:
            assert exc.output == b"first", exc.output
        else:
            raise AssertionError("open writer must hold the exchange")
        writer.write(b"second")
        writer.close()
        result = child.communicate(timeout=5)
        assert result == (b"firstsecond", b"marker") and reader.closed
        assert original.read() == b"child"
        print(result, child.returncode)
