"""Run after extracting the Linux receipts, passing the documentation checkout."""
import csv
import hashlib
import io
import json
import subprocess
import sys
from pathlib import Path


here = Path(__file__).resolve().parent
checkout = Path(sys.argv[1]).resolve()
base = "c0b639e10f04e117be6a48be9c5f7ea60deee47f"
full = "benchmarks/cpython_stdlib/full/"


def git_file(revision, path):
    return subprocess.check_output(["git", "-C", checkout, "show", revision + ":" + full + path])


def tsv(data):
    return list(csv.DictReader(io.StringIO(data.decode()), delimiter="\t"))


for name, identity in json.loads((here / "MANIFEST.json").read_bytes()).items():
    data = (here / name).read_bytes()
    assert (len(data), hashlib.sha256(data).hexdigest()) == (identity["bytes"], identity["sha256"]), name
reference = json.loads(git_file(base, "unittest/reference-linux.json"))["reference"]
prior = tsv((here / "history/uncredited-37-at-7236.tsv").read_bytes())
ledger = tsv(git_file("HEAD", "unittest-wrapped-autospec-7263.tsv"))
for name in ("unittest-wrapped-autospec-7263.tsv", "frozen-stock-intersection-7263.tsv"):
    assert git_file("HEAD", name) == (here / "accounting" / name).read_bytes()
assert len(ledger) == 2 and len(prior) == 37
for r in ledger:
    method = r["canonical_id"]
    assert prior[int(r["uncredited_7236_tsv_line"]) - 2] == {"canonical_id": method, "occurrence": r["occurrence"]}
    assert list(reference)[int(r["frozen_ordinal"]) - 1] == method and reference[method] == "pass"
    for engine in ("stock-named", "public-O0", "public-O3"):
        p = here / "selectors" / engine
        wait = json.loads((p / "wait.json").read_bytes())
        stderr = (p / "stderr.raw").read_text()
        assert wait["wait_status"] == wait["returncode"] == 0 and not wait["timed_out"]
        assert method in stderr and stderr.count("... ok") == 2 and stderr.rstrip().endswith("OK")
        assert (p / "stdout.raw").stat().st_size == 0
        for stream in ("stdout", "stderr"):
            assert hashlib.sha256((p / (stream + ".raw")).read_bytes()).hexdigest() == wait[stream + "_sha256"]
old = tsv(git_file(base, "frozen-stock-intersection-7253.tsv"))
new = tsv(git_file("HEAD", "frozen-stock-intersection-7263.tsv"))
assert len(old) == len(new) == 45
for a, b in zip(old, new):
    assert (a["family"], a["originals"], a["frozen_stock_positive"]) == (b["family"], b["originals"], b["frozen_stock_positive"])
    delta = sum(int(r["credit_delta"]) for r in ledger if r["family"] == a["family"])
    assert int(b["paired_at_7263"]) == int(a["paired_at_7253"]) + delta
    assert int(b["frozen_stock_positive_paired_at_7263"]) == int(a["frozen_stock_positive_paired_at_7253"]) + delta
assert sum(int(r["paired_at_7263"]) for r in new) == 13167
assert sum(int(r["frozen_stock_positive_paired_at_7263"]) for r in new) == 13069
assert git_file("HEAD", "os-socket-statistics-7253.tsv") == git_file(base, "os-socket-statistics-7253.tsv")
print("Verified both frozen occurrences, six named outcomes, the two new credits, and the 45-family totals.")
