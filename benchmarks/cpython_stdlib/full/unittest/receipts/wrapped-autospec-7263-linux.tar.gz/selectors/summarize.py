"""Cross-check actual named terminal results, stock callbacks and Linux waits."""
import csv
import json
from pathlib import Path

from process import load, sha


root = Path(__file__).resolve().parent
original = load(root/"original.json")
ids = original["selectors"]
stock_events = [json.loads(x) for x in (root/"stock-events/stdout.raw").read_text().splitlines()]
assert [x["id"] for x in stock_events if x.get("event")=="addSuccess"] == ids
with (root/"named-results.tsv").open("w", newline="") as out:
    tab = csv.writer(out, delimiter="\t", lineterminator="\n")
    tab.writerow(["engine","source_commit","canonical_id","occurrence","stock_terminal","named_terminal","pid","raw_wait","executable_sha256","stdout_sha256","stderr_sha256"])
    for mode in ("stock-named","public-O0","public-O3"):
        directory = root/mode
        wait = load(directory/"wait.json")
        assert wait["wait_status"] == 0 and wait["returncode"] == 0 and not wait["timed_out"]
        stdout,stderr = directory/"stdout.raw",directory/"stderr.raw"
        assert stdout.stat().st_size == 0 and (sha(stdout),sha(stderr)) == (wait["stdout_sha256"],wait["stderr_sha256"])
        output = stderr.read_text()
        assert output.rstrip().endswith("OK") and "Ran 2 tests" in output and output.count("... ok") == 2
        if mode == "stock-named":
            source, exe = original["cpython_commit"], original["stock_sha256"]
        else:
            source = load(directory/"source.json")["source"]["commit"]
            img = directory/"executed-image.json"
            exe = load(img)["sha256"] if img.is_file() else ""
        for name in ids:
            assert name in output
            tab.writerow([mode,source,name,1,"addSuccess","ok",wait["pid"],wait["wait_status"],exe,sha(stdout),sha(stderr)])
