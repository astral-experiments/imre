"""Run the unchanged CPython tests under the declared named loader."""
import hashlib
import json
import os
from pathlib import Path
import sys

from process import load, run, save, sha


here = Path(__file__).resolve().parent
fixture = Path("/dev/shm/autospec7238/tests/Lib")
entry = fixture / "test/test_unittest/testmock/testmock.py"
stock = Path("/workspace/fault/stock-python/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14")
module = "test.test_unittest.testmock.testmock"
methods = ["test_create_autospec_instance_wraps_class", "test_create_autospec_wraps_class"]
ids = [f"{module}.MockTest.{name}" for name in methods]
data = entry.read_bytes()
assert sha(entry) == "4b28e9359c4689cbadd401ac1f90275814bf0adedba3738e420c89a8a97d16e0"
assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == "764585ec5d54688b483dca510d6fa187a9fc2531"
assert sha(stock) == "c27397da5541f67655be462e128ca3d3eb6e0a8eb0d39036896c9042529f4304"
work = Path("/dev/shm/credits7263/selector") / sys.argv[1]
for d in ("home","tmp","cache"):
    (work / d).mkdir(exist_ok=True, parents=True)
env = {"PATH":"/usr/bin:/bin","HOME":str(work/"home"),"TMPDIR":str(work/"tmp"),
       "LC_ALL":"C.UTF-8","TZ":"UTC","PYTHONPATH":str(fixture),"PYTHONDONTWRITEBYTECODE":"1","PYTHON_COLORS":"0"}
args = ["-m", "unittest", "-v", *ids]


def execute(label, argv, *, named=False, count=2):
    folder = here / label
    wait = run(folder, argv, fixture, env, 1500, sample_image=label.startswith("public-O"))
    assert wait["wait_status"] == 0 and not wait["timed_out"], folder
    print(label, wait["pid"], wait["wait_status"], flush=True)
    if named:
        stderr = (folder/"stderr.raw").read_text()
        assert f"Ran {count} test" in stderr and stderr.rstrip().endswith("OK")
        assert (folder/"stdout.raw").stat().st_size == 0
        if count == 2:
            assert all(canonical in stderr for canonical in ids) and stderr.count("... ok") == count
    return wait


if sys.argv[1] == "stock":
    archive = Path("/dev/shm/imre-cpython-3.14.5-Lib-test.tar.gz")
    assert sha(archive) == "1e6c7c0d35b0ddb9150c3a142a1ea52810f5e3cb13fce7ca9bb23f3e59c9a196"
    save(here/"original.json",{"fixture":str(entry),"fixture_sha256":sha(entry),"stock":str(stock),
         "stock_sha256":sha(stock),"cpython_commit":"5607950ef232dad16d75c0cf53101d9649d89115",
         "testmock_blob":"764585ec5d54688b483dca510d6fa187a9fc2531","archive":str(archive),
         "archive_sha256":sha(archive),"selectors":ids})
    execute("stock-version",[stock,"-B","-VV"])
    execute("stock-named",[stock,"-B",*args],named=True)
    for i, name in enumerate(methods):
        execute("stock-file-"+str(i+1),[stock,"-B",entry,"MockTest."+name],named=True,count=1)
    execute("stock-events",[stock,"-B",here/"observe_stock.py",*ids])
    actual = [json.loads(line) for line in (here/"stock-events/stdout.raw").read_text().splitlines()]
    assert [item["id"] for item in actual if item.get("event")=="addSuccess"] == ids
    assert actual[-1] == {"testsRun":2,"errors":[],"failures":[]}
else:
    level = sys.argv[1]
    assert level in ("0", "3")
    sdk = Path(sys.argv[2])
    identity = load(Path(sys.argv[3]))
    source_id = identity["source"]
    public = load(here.parent/"transport/source.json")
    assert source_id["commit"] == public["source"] == "c0b639e10f04e117be6a48be9c5f7ea60deee47f"
    assert source_id["tree"] == public["tree"] and source_id["runtime"] == public["runtime"]
    components = {k:sha(sdk/k) for k in ("imre","libimre_runtime.a","imre-stdlib.zip")}
    assert components == source_id["sdk"]
    llvm = Path("/workspace/shared/llvm19/usr")
    env.update(PATH=f"{sdk}/imre-toolchain/bin:{llvm}/lib/llvm-19/bin:/usr/bin:/bin",
               IMRE_CACHE_DIR=str(work/"cache"),LD_LIBRARY_PATH=str(llvm/"lib/x86_64-linux-gnu"),
               IMRE_ENCODED_FLAGS="\x1f".join(["--opt-level",level,"--runtime",str(sdk/"libimre_runtime.a")]))
    label = "public-O"+level
    w = execute(label,[sdk/"imre","-B","--include-module",module,*args],named=True)
    save(here/label/"source.json",{"source":source_id, "sdk":str(sdk), "fixture":str(entry),
         "fixture_sha256":sha(entry),"pid":w["pid"],"raw_wait":w["wait_status"],
         "returncode":w["returncode"],"opt_level":level,
         "test_results":[{"id":canonical,"occurrence":1,"status":"ok"} for canonical in ids]})
