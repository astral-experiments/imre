"""Record genuine TestResult.addSuccess for the two original loaded methods."""
import json
import sys
import unittest


class Observer(unittest.TestResult):
    def addSuccess(self, test):
        super().addSuccess(test)
        print(json.dumps({"event": "addSuccess", "id": test.id()}))


suite = unittest.defaultTestLoader.loadTestsFromNames(sys.argv[1:])
result = Observer()
suite.run(result)
print(json.dumps({"testsRun": result.testsRun, "errors": result.errors, "failures": result.failures}, default=str))
raise SystemExit(0 if result.testsRun == 2 and result.wasSuccessful() else 1)
