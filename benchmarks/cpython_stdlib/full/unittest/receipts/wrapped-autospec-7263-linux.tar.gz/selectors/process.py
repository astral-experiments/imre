"""Record the spawned process group, exact Linux wait4 results and timestamped raw streams."""
import hashlib
import json
import os
import selectors
import signal
import subprocess
import time
from pathlib import Path


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(path.name + ".partial")
    partial.write_text(json.dumps(data, indent=2) + "\n")
    partial.replace(path)


def run(folder, argv, cwd, env, timeout, pass_fds=(), sample_image=False):
    folder.mkdir(parents=True, exist_ok=False)
    cwd.mkdir(parents=True, exist_ok=True)
    argv = list(map(str, argv))
    record = dict(argv=argv, cwd=str(cwd), env=env, timeout_s=timeout, unix_start_ns=time.time_ns())
    mono = time.monotonic_ns()
    child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             start_new_session=True, pass_fds=pass_fds)
    record["pid"] = child.pid
    save(folder / "start.json", record)
    events = []
    timed_out = False
    image = None
    source_image = None
    codegen = {}
    with (folder / "stdout.raw").open("wb") as so, (folder / "stderr.raw").open("wb") as se, selectors.DefaultSelector() as poll:
        poll.register(child.stdout, selectors.EVENT_READ, ("stdout", so))
        poll.register(child.stderr, selectors.EVENT_READ, ("stderr", se))
        while poll.get_map():
            if not timed_out and time.monotonic_ns() - mono >= timeout * 1_000_000_000:
                os.killpg(child.pid, signal.SIGKILL)
                timed_out = True
            if sample_image and image is None:
                processes = [str(child.pid)]
                try:
                    child_list = Path(f"/proc/{child.pid}/task/{child.pid}/children")
                    processes.extend(child_list.read_text().split())
                except FileNotFoundError:
                    pass
                for pid in processes:
                    executable = Path(f"/proc/{pid}/exe")
                    try:
                        target = executable.readlink()
                        if "clang" in target.name and pid not in codegen:
                            raw_args = Path(f"/proc/{pid}/cmdline").read_bytes()
                            flags = [os.fsdecode(arg) for arg in raw_args.split(b"\0") if arg in (b"-O0", b"-O1", b"-O2", b"-O3")]
                            codegen[pid] = {"pid":int(pid),"executable":str(target),"opt_flags":flags,
                                            "argv_sha256":hashlib.sha256(raw_args).hexdigest()}
                        if target.name.startswith((".imre-exec-fd-", ".imre-run-fd-")):
                            image = executable.open("rb")
                            source_image = dict(pid=int(pid), executable=str(target), bytes=os.fstat(image.fileno()).st_size)
                            break
                    except (FileNotFoundError, ProcessLookupError, PermissionError):
                        pass
            for key, _ in poll.select(.025 if sample_image and image is None else .25):
                data = os.read(key.fd, 65536)
                if not data:
                    poll.unregister(key.fileobj)
                    continue
                name, target = key.data
                events.append((time.monotonic_ns() - mono, name, target.tell(), len(data)))
                target.write(data)
                target.flush()
    _, status, usage = os.wait4(child.pid, 0)
    child.returncode = os.waitstatus_to_exitcode(status)
    record.update(wait_status=status, returncode=child.returncode, timed_out=timed_out, unix_end_ns=time.time_ns(),
                  elapsed_ns=time.monotonic_ns() - mono, user_s=usage.ru_utime, sys_s=usage.ru_stime, maxrss_kib=usage.ru_maxrss,
                  stdout_sha256=sha(folder / "stdout.raw"), stderr_sha256=sha(folder / "stderr.raw"))
    save(folder / "streams.json", events)
    save(folder / "wait.json", record)
    if sample_image:
        save(folder/"observed-codegen.json", list(codegen.values()))
    if image is not None:
        with image:
            source_image["sha256"] = hashlib.file_digest(image,"sha256").hexdigest()
            notes = subprocess.check_output(["readelf", "-n", f"/proc/self/fd/{image.fileno()}"],
                                           pass_fds=(image.fileno(),), text=True)
        source_image["build_id"] = next((line.split("Build ID: ")[1].strip() for line in notes.splitlines() if "Build ID: " in line), None)
        save(folder/"executed-image.json", source_image)
    return record
