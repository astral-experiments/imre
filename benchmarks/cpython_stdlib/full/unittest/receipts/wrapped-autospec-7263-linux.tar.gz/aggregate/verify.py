"""Reconcile public README coverage with the frozen 45-family and seven-original ledgers."""
import argparse
import csv
import hashlib
import io
import json
import re
import subprocess
from pathlib import Path

PUBLIC = "c0b639e10f04e117be6a48be9c5f7ea60deee47f"
LEDGER = "benchmarks/cpython_stdlib/full/frozen-stock-intersection-7253.tsv"
SEVEN = "benchmarks/cpython_stdlib/full/os-socket-statistics-7253.tsv"
BASELINE = Path("/tmp/imre-7260-frozen-stock-intersection-7253-2c1c9c91af4124b4.tsv")


def sha(b):
    return hashlib.sha256(b).hexdigest()


def tsv(b):
    return list(csv.DictReader(io.StringIO(b.decode()), delimiter="\t"))


parser = argparse.ArgumentParser()
parser.add_argument("repo")
parser.add_argument("--ref", default=PUBLIC)
parser.add_argument("--delta", type=int, choices=(0, 1, 2), default=0)
args = parser.parse_args()


def git(*argv):
    return subprocess.check_output(["git", "-C", args.repo, *argv])


def blob(rev, name):
    return git("show", rev + ":" + name)


def rows(section):
    return {name: (int(pairs.replace(",", "")), int(total.replace(",", "")))
            for name, pairs, total in re.findall(
                r"^\| `([^`]+)` \| ([\d,]+) \| ([\d,]+) \|", section, re.MULTILINE)}


def section(text):
    return text.split("## Standard library test results\n", 1)[1].split("### Whole-suite baselines for later additions\n", 1)


assert sha(BASELINE.read_bytes()) == "2c1c9c91af4124b43ec248fa7cc4786041fb56a7d53b004923a47bcbad99a69a"
assert BASELINE.read_bytes() == blob(PUBLIC, LEDGER) == blob(args.ref, LEDGER)
base = tsv(BASELINE.read_bytes())
assert len(base) == len({r["family"] for r in base}) == 45
prior_seven = blob(PUBLIC, SEVEN)
assert prior_seven == blob(args.ref, SEVEN)
seven = tsv(prior_seven)
assert len(seven) == len({(r["family"], r["id"], r["occurrence"]) for r in seven}) == 7
assert {(r["family"], int(r["ordinal"])) for r in seven} == {
    ("os",80), ("socket",180), *(("statistics",i) for i in range(318,323))}
for r in seven:
    assert r["prior_credit"] == "0" and r["credit_delta"] == "1"
    assert r["O0_state"] == r["O3_state"] == "pass" and r["paired_at_7253"] == "1"
for r in base:
    should_add = sum(s["family"] == r["family"] for s in seven)
    assert int(r["new_pairs_7253"]) == int(r["new_frozen_stock_positive_pairs_7253"]) == should_add
    assert int(r["paired_at_7236"]) + should_add == int(r["paired_at_7253"])
    assert int(r["frozen_stock_positive_paired_at_7236"]) + should_add == int(r["frozen_stock_positive_paired_at_7253"])

expected = {r["family"]: (int(r["paired_at_7253"]), int(r["originals"])) for r in base}
expected["unittest"] = (expected["unittest"][0] + args.delta, expected["unittest"][1])
old_text = blob(PUBLIC, "README.md").decode()
new_text = blob(args.ref, "README.md").decode()
current, supplemental = section(new_text)
assert rows(current) == expected
if git("rev-parse", args.ref).decode().strip() != PUBLIC:
    assert git("rev-parse", args.ref+"^").decode().strip() == PUBLIC
    assert git("show", "-s", "--format=%an <%ae>%n%cn <%ce>", args.ref).decode().splitlines() == [
        "Charlie Marsh <charlie.r.marsh@gmail.com>",
        "Charlie Marsh <charlie.r.marsh@gmail.com>",
    ]
    assert git("rev-list","--count",PUBLIC+".."+args.ref).strip() == b"1"
    assert all(p == "README.md" or p.startswith("benchmarks/cpython_stdlib/")
               for p in git("diff","--name-only",PUBLIC,args.ref).decode().splitlines())
# Preserve the whole separately tracked section, including history and prior IDs.
assert supplemental == section(old_text)[1]
other = rows(supplemental.split("\n\n",2)[1])
assert len(other) == 49 and other["statistics"] == (169,400)
assert tuple(map(sum,zip(*other.values()))) == (3231,5985)
assert "**3,231 paired passes among 5,985 originals**" in supplemental

all_pairs, originals = map(sum, zip(*expected.values()))
first25, _ = current.split("| **Total**",1)
earlier = rows(first25)
assert len(earlier)==25
p25,n25 = map(sum,zip(*earlier.values()))
assert (p25,n25)==(10679+args.delta,13327)
assert (all_pairs-p25,originals-n25)==(2486,2898)
assert f"**{all_pairs:,} of {originals:,} tests ({all_pairs/originals:.2%})**" in current
assert f"{p25/n25:.1%} ({p25:,} of {n25:,})" in current
assert f"| **Total** | **{p25:,}** | **{n25:,}** |" in current

frozen = sum(int(r["frozen_stock_positive"]) for r in base)
matched = sum(int(r["frozen_stock_positive_paired_at_7253"]) for r in base) + args.delta
assert all_pairs-matched == 98
assert f"**{matched:,} of the {frozen:,} stock Linux passes ({matched/frozen:.1%})**" in current
gap = (9*frozen+9)//10 - matched
assert f"**{gap}** more to reach 90%" in current
netrc,netrc_count = expected["netrc"]
assert netrc==22 and netrc_count==23
assert f"Of the {all_pairs-netrc:,} paired originals in that cohort, **{matched-netrc:,}** passed in that stock run" in current
assert "registered **16,191** of the **16,202** originals" in current
assert "**15,161**, skipped 1,023, and reported 7 errors" in current
assert "The other 98 skipped or recorded an error." in current

print(json.dumps({
    "ref":git("rev-parse",args.ref).decode().strip(),"tree":git("rev-parse",args.ref+"^{tree}").decode().strip(),
    "readme_sha256":sha(new_text.encode()),"aggregate_baseline_sha256":sha(BASELINE.read_bytes()),
    "net_new_unittest":args.delta,"unittest":[*expected["unittest"]],"unittest_frozen_stock_positive":1088,
    "45_families":{"paired":all_pairs,"originals":originals,"frozen_stock_positive":frozen,
                   "paired_in_frozen_stock_positive":matched,"frozen_stock_positive_unpaired":frozen-matched,
                   "paired_outside_frozen_stock_positive":all_pairs-matched,"pairs_to_90_percent":gap},
    "44_families_before_netrc":{"paired":all_pairs-netrc,"paired_in_frozen_stock_positive":matched-netrc},
    "25_families":[p25,n25],"20_families":[all_pairs-p25,originals-n25],
    "separate_49":[3231,5985],"statistics":other["statistics"],"previous_seven_sha256":sha(prior_seven),
    "previous_seven":[{k:r[k] for k in ("family","id","occurrence","ordinal","prior_credit","credit_delta")} for r in seven]
},indent=2))
