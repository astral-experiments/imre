"""Trace the two committed unittest.mock methods through the frozen and cumulative ledgers."""

import collections
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile


PUBLIC = "c0b639e10f04e117be6a48be9c5f7ea60deee47f"
BEFORE = "de12c41aeb93f73c6b96f1b4ad6ceaaa4b2b496d"
MERGED = "446e39be9b8299366000913eeaa737a2bc547a95"
TEST = "test.test_unittest.testmock.testmock"
CLASS = TEST + ".MockTest"
IDS = [CLASS + "." + method for method in (
    "test_create_autospec_instance_wraps_class", "test_create_autospec_wraps_class",
)]
FULL = "benchmarks/cpython_stdlib/full/"
BASE = FULL + "unittest/"
OUT = Path(__file__).resolve().parent
REPO = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/dev/shm/credits7263/public")


def git(*args):
    return subprocess.check_output(["git", "-C", REPO, *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def tsv(raw):
    return list(csv.DictReader(io.StringIO(raw.decode()), delimiter="\t"))


sources = {}


def blob(path):
    spec = PUBLIC + ":" + path
    raw = git("show", spec)
    sources[path] = {"blob": git("rev-parse", spec).decode().strip(), "sha256": sha(raw)}
    return raw


assert git("rev-parse", PUBLIC).decode().strip() == PUBLIC
raw_reference = blob(BASE + "reference-linux.json")
reference = json.loads(raw_reference)
ordered = reference["reference"]
modules = list(dict.fromkeys(test.rsplit(".", 2)[0] for test in ordered))
classes = list(dict.fromkeys(test.rsplit(".", 1)[0] for test in ordered))
members = [test for test in ordered if test.rsplit(".", 2)[0] == TEST]
own_classes = list(dict.fromkeys(test.rsplit(".", 1)[0] for test in members))
own_members = [test for test in members if test.rsplit(".", 1)[0] == CLASS]
assert len(ordered) == 1090 and len(members) == 146 and members == own_members
assert len(modules) == 24 and len(classes) == 50 and own_classes == [CLASS]
selector = (OUT / "uncredited-37-at-7236.tsv").read_bytes()
assert sha(selector) == "c38904563bf8191c8ef76a6beff496ea2e6fb47cd5c8bbac079e7d66a1c7d7bc"
uncredited = tsv(selector)
keys = [(i["canonical_id"], int(i["occurrence"])) for i in uncredited]
assert len(keys) == len(set(keys)) == 37
for case, occurrence in keys:
    assert occurrence == 1 and ordered[case] == "pass"
baseline = blob(FULL + "frozen-stock-intersection-7253.tsv")
assert sha(baseline) == "2c1c9c91af4124b43ec248fa7cc4786041fb56a7d53b004923a47bcbad99a69a"
families = tsv(baseline)
unit = next(r for r in families if r["family"] == "unittest")
assert int(unit["frozen_stock_positive_without_pair"]) == len(keys)
assert int(unit["frozen_stock_positive_paired_at_7253"]) == sum(v == "pass" for v in ordered.values()) - len(keys) == 1051
assert int(unit["paired_at_7236"]) == int(unit["paired_at_7253"]) == 1051
rows = {}
for case in IDS:
    assert ordered[case] == "pass"
    physical = [i for i, line in enumerate(raw_reference.decode().splitlines(), 1)
                if '"' + case + '"' in line]
    assert len(physical) == 1
    index = keys.index((case, 1))
    rows[case] = {
        "occurrence": 1, "frozen_reference_status": ordered[case],
        "frozen_reference_ordinal": list(ordered).index(case) + 1,
        "frozen_reference_json_line": physical[0],
        "module_ordinal_in_suite": modules.index(TEST) + 1,
        "class_ordinal_in_suite": classes.index(CLASS) + 1,
        "class_ordinal_in_module": own_classes.index(CLASS) + 1,
        "method_ordinal_in_module": members.index(case) + 1,
        "method_ordinal_in_class": own_members.index(case) + 1,
        "previous_credit": 0, "frozen_uncredited_ordinal": index + 1,
        "frozen_uncredited_tsv_line": index + 2, "archive_observations": [],
    }


def match(data, path, pointer=()):
    if isinstance(data, list):
        for i, child in enumerate(data):
            match(child, path, (*pointer, str(i)))
    elif isinstance(data, dict):
        case = data.get("id")
        if case in rows:
            occurrence = data.get("occurrence")
            assert occurrence == rows[case]["occurrence"]
            if "records" in pointer:
                assert int(pointer[-1]) + 1 == rows[case]["frozen_reference_ordinal"]
            if "modes" in data:
                outcomes = {key: value["stage"] for key, value in data["modes"].items()}
                assert set(outcomes.values()) == {"compile-blocked"}
            elif "outcome" in data:
                assert data["outcome"] in {"not-run", "blocked"}
            rows[case]["archive_observations"].append(
                {"file": path, "json_pointer": "/" + "/".join(pointer), "record": data})
        else:
            for key, child in data.items():
                match(child, path, (*pointer, key))


paths = git("ls-tree", "-r", "--name-only", PUBLIC, "--", BASE).decode().splitlines()
file_coverage = {}
for path in paths:
    if "/upstream/" in path or not path.endswith((".json", ".json.gz", ".tar.gz")):
        continue
    raw = blob(path)
    before = sum(len(r["archive_observations"]) for r in rows.values())
    if path.endswith(".tar.gz"):
        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
            for member in archive:
                if member.name.endswith(".json"):
                    match(json.load(archive.extractfile(member)), path + "#" + member.name)
    else:
        match(json.loads(gzip.decompress(raw) if path.endswith(".gz") else raw), path)
    file_coverage[path] = sum(len(r["archive_observations"]) for r in rows.values()) - before

# Examine exact IDs and occurrence columns of the cumulative family supplements.
overlays = {}
paths = git("ls-tree", "-r", "--name-only", PUBLIC, "--", FULL).decode().splitlines()
for path in paths:
    if not (path.startswith(FULL + "unittest-") and path.endswith(".tsv")
            or path == FULL + "os-socket-statistics-7253.tsv"):
        continue
    data = tsv(blob(path))
    ids = [(r["id"], int(r["occurrence"])) for r in data]
    assert not (set(ids) & {(case, 1) for case in rows})
    overlays[path] = [{"id": case, "occurrence": n} for case, n in ids]
seven = overlays[FULL + "os-socket-statistics-7253.tsv"]
assert len(seven) == len({r["id"] for r in seven}) == 7
between = git("log", "--format=%H", BEFORE + ".." + PUBLIC,
              "--", "README.md", "benchmarks/cpython_stdlib").decode().splitlines()
assert between == [PUBLIC]
merged_paths = git("diff-tree", "--no-commit-id", "--name-only", "-r", MERGED).decode().splitlines()
assert merged_paths == ["crates/imre-compiler/stdlib/unittest/boxed_mock.py"]
totals = {field: sum(int(v[field]) for v in families) for field in (
    "originals", "frozen_stock_positive", "paired_at_7253", "frozen_stock_positive_paired_at_7253")}
assert totals == {"originals": 16225, "frozen_stock_positive": 15183,
                  "paired_at_7253": 13165, "frozen_stock_positive_paired_at_7253": 13067}
controls = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("/tmp/imre-7238-autospec-wrapped-class-callables-89345436-controls.tar.gz")
assert sha(controls.read_bytes()) == "f787ded53aa86732e6f6b4f95a56b02200366e09bd6f7f60e815b8f2ebc66318"
old_member = "transport/imre-genuine-uncredited-37-unittest-method-occurrences-at-public-7236.tsv"
with tarfile.open(controls, "r:gz") as previous:
    assert previous.extractfile(old_member).read() == selector
    older = tsv(previous.extractfile("declared/occurrence-results.tsv").read())
    for case in IDS:
        replays = [r for r in older if r["canonical_id"] == case and r["occurrence"] == "1"]
        assert len(replays) == 4
        for replay in replays:
            public_before = replay["run"].startswith("public-")
            assert (replay["unittest_status"], int(replay["raw_wait"]), int(replay["exit"])) == (
                ("ERROR",256,1) if public_before else ("ok",0,0))
            errpath = "declared/" + replay["run"] + "/stderr.raw"
            stderr = previous.extractfile(errpath).read()
            assert sha(stderr) == replay["stderr_sha256"]
            if public_before:
                assert stderr.count(b"NotImplementedError: create_autospec does not support 'wraps'") == 2
            replay["stderr_member"] = errpath
        rows[case]["prepublication_named_results"] = replays
output = {
    "public": PUBLIC, "tree": git("rev-parse", PUBLIC + "^{tree}").decode().strip(),
    "reference_cpython": reference["cpython_commit"], "rows": rows, "archived_files_reviewed": file_coverage,
    "source_blobs": sources, "cumulative_supplements_reviewed": overlays,
    "frozen_uncredited_selector_sha256": sha(selector), "frozen_intersection_sha256": sha(baseline),
    "sealed_previous_controls": {"file": str(controls), "sha256": sha(controls.read_bytes()),
                                 "selector_member": old_member, "prior_named_member": "declared/occurrence-results.tsv"},
    "family_baseline": unit, "prior_45_family_totals": totals,
    "post_7238_documentation_changes": between, "7260_source_commit": MERGED,
    "7260_changed_files": merged_paths, "implementation_blob": git("rev-parse", PUBLIC + ":" + merged_paths[0]).decode().strip(),
    "conclusion": "The prior concurrent stock/native credit for each exact occurrence was zero. Both were among the 37 frozen stock-positive unpaired occurrences on #7236. The only subsequent published coverage delta up to #7263 concerns OS, socket and statistics. A public source merge alone does not confer coverage.",
}
(OUT / "history.json").write_text(json.dumps(output, indent=2) + "\n")
with (OUT / "prior-per-id.tsv").open("w", newline="") as f:
    table = csv.writer(f, delimiter="\t", lineterminator="\n")
    table.writerow(("canonical_id", "occurrence", "frozen_reference_ordinal", "reference_json_line", "module_ordinal",
                    "class_ordinal_in_module", "method_ordinal_in_class", "previous_official_credit",
                    "uncredited_list_tsv_line", "frozen_stock", "old_native_O0_O3", "projected_and_default_audits",
                    "public_7238_O0_pid", "public_7238_O3_pid", "public_7238_raw_wait", "premerge_89345436_O0_pid",
                    "premerge_89345436_O3_pid", "premerge_raw_wait"))
    for case, row in rows.items():
        pids = {r["run"]: r["pid"] for r in row["prepublication_named_results"]}
        table.writerow((case, 1, row["frozen_reference_ordinal"], row["frozen_reference_json_line"],
                        row["module_ordinal_in_suite"], row["class_ordinal_in_module"], row["method_ordinal_in_class"],
                        0, row["frozen_uncredited_tsv_line"], row["frozen_reference_status"],
                        "reference-only/not-run", "compile-blocked: missing static create_autospec binding",
                        pids["public-wraps-O0"], pids["public-wraps-O3"], 256, pids["candidate-wraps-O0"],
                        pids["candidate-wraps-O3"], 0))
for case, row in rows.items():
    print(case, row["frozen_reference_ordinal"], row["method_ordinal_in_module"],
          row["frozen_uncredited_tsv_line"], len(row["archive_observations"]))
