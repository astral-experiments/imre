# Wrapped autospec occurrences on public #7263

The unchanged CPython 3.14.5 test module is Git blob `764585ec5d54688b483dca510d6fa187a9fc2531`. The two assigned tests are frozen suite entries 807 and 811, both occurrence 1. The stock and native named loaders selected them by their full dotted names.

Read `selectors/named-results.tsv` for the six named terminal outcomes. The adjacent run directories contain the original argv, environment, stdout, stderr and Linux wait status. The stock FILE runs and the two stock addSuccess events are also retained. `build/sdk.json` identifies the release products built from `c0b639e10f04e117be6a48be9c5f7ea60deee47f`.

`history/prior-per-id.tsv` joins each ID to the frozen reference, earlier native observations and the previously uncredited selector. That selector has 37 distinct occurrence keys and SHA-256 `c38904563bf8191c8ef76a6beff496ea2e6fb47cd5c8bbac079e7d66a1c7d7bc`. The selected keys are its TSV lines 30 and 31. `history/history.json` identifies the published reports and their exact Git blobs. The earlier public #7238 named runs are retained in `previous-7238`. Their original controls archive has SHA-256 `f787ded53aa86732e6f6b4f95a56b02200366e09bd6f7f60e815b8f2ebc66318`.

`aggregate/public.json` records the starting 45-family totals and the separate 49-family measurement. The new two-row ledger and updated 45-family table in the documentation use the two successful public #7263 native tiers. The earlier seven OS, socket and statistics rows remain in their #7253 ledger.

After extraction, run `python3 verify.py /path/to/imre` with the documentation commit checked out.
