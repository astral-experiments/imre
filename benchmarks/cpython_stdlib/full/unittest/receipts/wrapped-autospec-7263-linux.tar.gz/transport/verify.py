import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct


record = Path(__file__).resolve().parent
tmp = Path("/tmp")
large = Path("/dev/shm/credits7263/transport")
large.mkdir(mode=0o700, parents=True, exist_ok=True)
os.umask(0o077)
artifacts = [
    ("public-7263-frozen-stock-family-baseline", "2c1c9c91af4124b43ec248fa7cc4786041fb56a7d53b004923a47bcbad99a69a", "imre-7260-frozen-stock-intersection-7253-2c1c9c91af4124b4.tsv"),
    ("qualified-public-c0b639e1-from-de12c41a", "a42d79d6638e3400d2ebc03c4f9ab2752b4c43e9a542b9b38e1f9916282b8a69", "imre-public-c0b639e1-from-de12c41a.bundle"),
]

def digest(path):
    with path.open("rb") as src:
        return hashlib.file_digest(src, "sha256").hexdigest()

for label, expected, name in artifacts:
    prefix = f"imre-capacity-{label}-{expected[:16]}-"
    manifest = tmp / (prefix + "manifest.json")
    data = json.loads(manifest.read_bytes())
    dest = tmp / name
    assert data["destination"] == str(dest) and data["sha256"] == expected
    blobs = []
    for i, part in enumerate(data["parts"]):
        path = tmp / (prefix + f"{i:03d}")
        assert path == Path(part["path"]) and path.stat().st_size == part["bytes"]
        assert digest(path) == part["sha256"]
        blobs.append(path)
    assert sum(p.stat().st_size for p in blobs) == data["bytes"]
    receipt = {"manifest": str(manifest), "manifest_sha256": digest(manifest), **data}
    if not dest.exists():
        if data["bytes"] < shutil.disk_usage(tmp).free - 512_000:
            with dest.open("xb") as f:
                for p in blobs:
                    with p.open("rb") as src:
                        shutil.copyfileobj(src,f)
        else:
            trial = dest.with_suffix(".range-clone")
            try:
                with trial.open("xb") as f:
                    off = 0
                    for p in blobs:
                        with p.open("rb") as src:
                            fcntl.ioctl(f.fileno(), 0x4020940D, struct.pack("qQQQ",src.fileno(),0,p.stat().st_size,off))
                        off += p.stat().st_size
                assert digest(trial) == expected
                trial.rename(dest)
                receipt["storage"] = "reflink ranges on /tmp"
            except OSError as exc:
                receipt["range_clone_error"] = str(exc)
                trial.unlink(missing_ok=True)
                target = large/name
                with target.open("xb") as out:
                    for p in blobs:
                        with p.open("rb") as src:
                            shutil.copyfileobj(src, out)
                assert digest(target) == expected
                dest.symlink_to(target)
                receipt["storage"] = str(target)
    assert dest.stat().st_size == data["bytes"] and digest(dest) == expected
    (record/(name+".verified.json")).write_text(json.dumps(receipt,indent=2)+"\n")
    print(str(dest), expected, receipt.get("storage","regular"),flush=True)
