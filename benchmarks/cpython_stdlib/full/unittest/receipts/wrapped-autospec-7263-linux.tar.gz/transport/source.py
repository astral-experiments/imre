import hashlib
import json
import os
import re
import subprocess
from pathlib import Path


here = Path(__file__).resolve().parent
repo = Path("/dev/shm/credits7263/public")
tip = "c0b639e10f04e117be6a48be9c5f7ea60deee47f"
parent = "de12c41aeb93f73c6b96f1b4ad6ceaaa4b2b496d"
bundle = Path("/tmp/imre-public-c0b639e1-from-de12c41a.bundle")

def git(*args):
    return subprocess.check_output(["git", "-C", repo, *args], text=True).strip()

assert git("rev-parse","HEAD") == tip
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == "a42d79d6638e3400d2ebc03c4f9ab2752b4c43e9a542b9b38e1f9916282b8a69"
tracked = set(git("ls-tree","-r","--name-only","HEAD").splitlines())
needed = set(json.loads(Path("/workspace/autospec7238/build/hydrated.json").read_bytes())["files"])
needed.update(path for path in tracked if path.startswith("licenses/"))
needed.update(["LICENSE-MIT","LICENSE-APACHE","benchmarks/cpython_stdlib/full/http/upstream/Lib/http/cookies.py","benchmarks/cpython_stdlib/full/shlex/upstream/Lib/shlex.py"])
for rs in (repo/"crates").rglob("*.rs"):
    for lit in re.findall(r'(?:include_str|include_bytes|include)!\(\s*"([^"]+)"',rs.read_text()):
        dest = (rs.parent/lit).resolve()
        if dest.is_relative_to(repo) and not dest.is_file():
            rel = str(dest.relative_to(repo))
            if rel in tracked:
                needed.add(rel)
assert needed <= tracked
git("restore","--source=HEAD","--worktree","--ignore-skip-worktree-bits","--",*sorted(needed))
checked = {}
for path in sorted(needed):
    data = (repo/path).read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert git("rev-parse","HEAD:"+path) == blob
    checked[path] = blob
data = {"bundle":str(bundle),"bundle_verify":git("bundle","verify",str(bundle)),"prerequisite":parent,
        "source":tip,"tree":git("rev-parse","HEAD^{tree}"),"runtime":git("rev-parse","HEAD:crates/imre-runtime"),
        "compiler":git("rev-parse","HEAD:crates/imre-compiler"),"commit":git("show","-s","--format=fuller",tip),
        "git_source":str(repo),"compiler_hydrated_inputs":checked}
assert git("status","--porcelain") == ""
(here/"source.json").write_text(json.dumps(data,indent=2)+"\n")
print(data["source"],data["tree"],len(needed),"build inputs")
