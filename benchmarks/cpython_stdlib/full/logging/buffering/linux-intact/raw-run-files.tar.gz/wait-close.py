import subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
pending={'O0','O3'}
while pending:
    for lane in tuple(pending):
        if (root/lane/'suite.json').exists():
            subprocess.run([sys.executable,'-B',root/'close.py',lane],cwd=root,check=True)
            pending.remove(lane)
    if pending:
        time.sleep(3)
