"""Defer the host duration check while the existing native suite runs to natural exit."""
import hashlib,json,os,select,signal,sys,time
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parent
lane=sys.argv[1]
assert lane in ('O0','O3')
out=root/lane
start=json.loads((out/'suite-start.json').read_bytes())
cpid=start['pid']
def stat(pid):
    return Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
def stamp():
    return datetime.now(timezone.utc).isoformat()
def record(name,info):
    fp=out/name
    tmp=fp.with_suffix('.pending');tmp.write_text(json.dumps(info,indent=2)+'\n');tmp.replace(fp)
def command(pid):
    return Path(f'/proc/{pid}/cmdline').read_bytes().rstrip(b'\0').split(b'\0')
assert [v.decode() for v in command(cpid)]==start['argv']
with Path(start['argv'][0]).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==start['executable_sha256']
cfd=os.pidfd_open(cpid)
cst=stat(cpid);parent=int(cst[1]);pfd=os.pidfd_open(parent)
assert command(parent)[-3:]==[b'-B',os.fsencode(root/'run.py'),lane.encode()]
assert int(cst[2])==int(cst[3])==cpid and os.getpgid(parent)!=cpid
assert not (out/'suite.json').exists()
poll=select.poll();poll.register(cfd,select.POLLIN)
if poll.poll(0):raise SystemExit('native process already completed')
for _ in range(200):
    if 'nanosleep' in Path(f'/proc/{parent}/wchan').read_text():break
    time.sleep(.001)
info=dict(lane=lane,pid=cpid,supervisor=parent,supervisor_args=[s.decode() for s in command(parent)],native_process_group=cpid,host_group=os.getpgid(parent),original_deadline_seconds=start['deadline_seconds'],suite_start=start['started'],activated=stamp(),reason='The intact suite was advancing too slowly to finish within its initial wall-clock deadline. Only its host waiter was paused; the existing native process and its descendants continue.',monitor_pid=os.getpid(),status='waiting for natural native exit',c_start_ticks=cst[19],p_start_ticks=stat(parent)[19])
record('extension.json',info)
signal.pidfd_send_signal(pfd,signal.SIGSTOP)
for _ in range(200):
    if stat(parent)[0] in ('T','t'):break
    time.sleep(.005)
assert stat(parent)[0] in ('T','t')
info['confirmed_supervisor_paused']=stamp();record('extension.json',info)
while not poll.poll(30000):
    c=stat(cpid)
    lines=(out/'suite.out').read_bytes().splitlines()
    prefix=b'IMRE_INTACT '+str(cpid).encode()+b' '
    events=[s[len(prefix):] for s in lines if s.startswith(prefix)]
    with (out/'progress.tsv').open('a') as stream:
        last=events[-1].decode(errors='replace').replace('\t',' ')[:200] if events else ''
        stream.write(f'{stamp()}\t{c[0]}\t{int(c[11])+int(c[12])}\t{len(events)}\t{last}\n')
# The child's PID is reserved as a zombie until the waiting parent reaps it.
end=stat(cpid)
assert end[0]=='Z' and int(end[1])==parent
info.update(terminal=stamp(),observed_terminal_state=end[0],status='pidfd became readable on natural native exit; authoritative exit or signal is in the host suite.json receipt')
record('extension.json',info)
signal.pidfd_send_signal(pfd,signal.SIGCONT)
info['host_waiter_resumed']=stamp();record('extension.json',info)
