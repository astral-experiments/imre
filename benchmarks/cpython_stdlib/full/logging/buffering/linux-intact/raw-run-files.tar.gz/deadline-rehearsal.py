import json,os,select,signal,subprocess,sys,time
from pathlib import Path
d=Path('/workspace/scratch/imre-logging-buffering/intact')/'timer-rehearsal';d.mkdir(exist_ok=True)
if len(sys.argv)>1:
    child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(2.2);raise SystemExit(7)'],start_new_session=True)
    (d/'child').write_text(str(child.pid))
    try:code=child.wait(timeout=1.0);expired=False
    except subprocess.TimeoutExpired:expired=True;code=child.wait()
    (d/'out').write_text(json.dumps({'status':code,'expired':expired}));sys.exit(0)
s=subprocess.Popen([sys.executable,__file__,'parent'])
while not (d/'child').exists():time.sleep(.01)
pid=int((d/'child').read_text());time.sleep(.1)
sfd=os.pidfd_open(s.pid);cfd=os.pidfd_open(pid)
signal.pidfd_send_signal(sfd,signal.SIGSTOP)
poll=select.poll();poll.register(cfd,select.POLLIN);assert poll.poll(10000)
status=int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[49])
signal.pidfd_send_signal(sfd,signal.SIGCONT)
assert s.wait(timeout=5)==0;out=json.loads((d/'out').read_text())
assert status==7<<8 and out=={'status':7,'expired':False},(status,out)
print('toy child reached its natural exit 7 despite parent timeout of 1 second',out)
