"""Sample Linux task counters while an unchanged native long-running case is active."""
from datetime import datetime, timezone
import json,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent
wanted={k:json.loads((here/k/'suite-start.json').read_bytes())['pid'] for k in ('O0','O3')}
maximum=360
samples=here/'scheduler-samples.tsv'
with samples.open('w') as fp:
    fp.write('utc\tlane\tpid\tstate\tcpu_ticks\tvoluntary_switches\tinvoluntary_switches\trss_kib\tlast_started\tstarts\tstops\n')
    while wanted and maximum:
        for lane,pid in list(wanted.items()):
            folder=here/lane
            if (folder/'suite.json').is_file():
                del wanted[lane];continue
            try:
                prefix=f'IMRE_INTACT {pid} '
                rows=[z[len(prefix):] for z in (folder/'suite.out').read_text(errors='replace').splitlines() if z.startswith(prefix)]
                starts=[z[6:] for z in rows if z.startswith('START ')]
                stops=[z[5:] for z in rows if z.startswith('STOP ')]
                ps=Path(f'/proc/{pid}')
                st=ps.joinpath('stat').read_text().rsplit(')',1)[1].split()
                status=dict(s.split(':',1) for s in ps.joinpath('status').read_text().splitlines())
                v=int(status['voluntary_ctxt_switches']);iv=int(status['nonvoluntary_ctxt_switches'])
                rss=status.get('VmRSS','0').split()[0]
                line=[datetime.now(timezone.utc).isoformat(),lane,pid,st[0],int(st[11])+int(st[12]),v,iv,rss,starts[-1] if starts else '',len(starts),len(stops)]
                fp.write('\t'.join(map(str,line))+'\n');fp.flush()
            except (FileNotFoundError,ProcessLookupError):
                del wanted[lane]
        maximum-=1
        if wanted:time.sleep(30)
