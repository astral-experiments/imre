from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

p=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
inventory=(p.parent/'matrix/all-272.txt').read_text().splitlines()
assert len(inventory)==len(set(inventory))==272
for lane in sys.argv[1:]:
    d=p/lane
    r=json.loads((d/'suite.json').read_bytes())
    assert sha(d/'suite.out')==r['stdout_sha256'] and sha(d/'suite.err')==r['stderr_sha256']
    ev=[]; foreign=Counter(); by_case={}; synthetic=[]
    for line in (d/'suite.out').read_bytes().decode('utf-8','backslashreplace').splitlines():
        if not line.startswith('IMRE_INTACT '):continue
        cols=line.split(' ',3)
        if len(cols)<3:continue
        pid,tag=cols[1:3]; arg=cols[3] if len(cols)>3 else ''
        if pid!=str(r['pid']):
            foreign[(pid,tag)]+=1
            continue
        ev.append((tag,arg))
        if tag in ('START','STOP','PASS','FAIL','ERROR','SKIP','XFAIL','XPASS','SUBPASS','SUBERROR'):
            key=arg.split(' ',1)[0]
            if key in inventory:
                by_case.setdefault(key,[]).append(tag)
            else:
                synthetic.append({'event':tag,'details':arg})
    total=[v for k,v in ev if k=='TOTAL']
    starts=[arg for k,arg in ev if k=='START'];stops=[arg for k,arg in ev if k=='STOP']
    result={'lane':lane,'pid':r['pid'],'status':r['status'],'exit':r['exit'],'signal':r['signal'],'timed_out':r['timed_out'],'time_seconds':r['elapsed_seconds'],'deadline_seconds':r['deadline_seconds'],'discovered':[v for k,v in ev if k=='DISCOVERED'],'total':total,'parent_events':Counter(k for k,v in ev),'foreign_events':dict((pid+' '+tag,n) for (pid,tag),n in foreign.items()),'started':len(starts),'stopped':len(stops),'paired_start_stops':sum(k in stops for k in dict.fromkeys(starts)),'subtests':sum(k.startswith('SUB') for k,v in ev),'last_events':ev[-8:],'synthetic_terminal_events':synthetic,'stderr_bytes':(d/'suite.err').stat().st_size,'complete':starts==stops and set(starts)==set(inventory) and len(starts)==len(inventory) and [v for k,v in ev if k=='DISCOVERED']==['272'] and sum(k=='RUN_START' for k,v in ev)==sum(k=='RUN_STOP' for k,v in ev)==len(total)==1 and not foreign and r['status'] in (0,1) and not r['timed_out'],'source_sha256':r['original_sha256'],'entry_sha256':r['entry_sha256'],'receipt_sha256':sha(d/'suite.json')}
    crosswalk=d/'parent-callbacks.tsv'
    rows=['original_id\tstarted\tstopped\tterminal_callbacks\tsubtest_callbacks']
    for key in inventory:
        seq=by_case.get(key,[])
        terminal=[tag for tag in seq if tag in ('PASS','FAIL','ERROR','SKIP','XFAIL','XPASS')]
        subs=[tag for tag in seq if tag in ('SUBPASS','SUBERROR')]
        rows.append('\t'.join([key,str(seq.count('START')),str(seq.count('STOP')),','.join(terminal),','.join(subs)]))
    crosswalk.write_text('\n'.join(rows)+'\n')
    result['crosswalk_sha256']=sha(crosswalk)
    if (d/'extension.json').is_file():
        ext=json.loads((d/'extension.json').read_bytes())
        assert ext['pid']==r['pid'] and ext['observed_terminal_state']=='Z' and ext['host_waiter_resumed']
        result.update(initial_deadline_extended=True,effective_deadline='allowed to finish naturally under pidfd observation',extension_sha256=sha(d/'extension.json'))
    (d/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
    print(lane,result['status'],result['complete'],result['parent_events'],sha(d/'outcome.json'),flush=True)
