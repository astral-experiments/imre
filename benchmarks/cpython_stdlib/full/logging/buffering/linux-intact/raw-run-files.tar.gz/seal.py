import collections
import csv
import hashlib
import json
from pathlib import Path
p=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def rows(f):return list(csv.DictReader(f.open(),delimiter='\t'))
results={n: json.loads((p/n/'outcome.json').read_bytes()) for n in ('stock','O0','O3')}
for n,v in results.items():
    assert v['complete'] and not v['timed_out'] and v['signal'] is None, (n,v)
    assert v['parent_events']['START']==v['parent_events']['STOP']==v['paired_start_stops']==272
    assert not v['foreign_events']
    if n!='stock':assert v['initial_deadline_extended']
keys=[r['original_id']for r in rows(p/'stock/parent-callbacks.tsv')]
trace={n:rows(p/n/'parent-callbacks.tsv') for n in results}
assert all([r['original_id']for r in t]==keys for t in trace.values())
cross=p/'originals.tsv'
cross.write_text('original_id\tstock parent terminals\tstock subtests\tO0 parent terminals\tO0 subtests\tO3 parent terminals\tO3 subtests\n'+''.join('\t'.join([k]+[trace[n][i][field] for n in results for field in ('terminal_callbacks','subtest_callbacks')])+'\n' for i,k in enumerate(keys)))
streams={}
for n in results:
    journal=p/n/'suite.out'
    pid=results[n]['pid']
    s=[line for line in journal.read_text(errors='replace').splitlines() if line.startswith(f'IMRE_INTACT {pid} ')]
    streams[n]=[line.split(' ',2)[2] for line in s]
def normalized(stream):
    # Compare event tags and case IDs, excluding engine-specific traceback or fault text.
    return [line.split(' ',2)[:2] for line in stream]
summary={'role':'guarded, intact TestLoader.loadTestsFromModule(test.test_logging) TestSuite; separate from selected-family results','source_reference':'5607950ef232dad16d75c0cf53101d9649d89115','public_imre':'8d3fe99e55c190cc72bfd78d2b5afe46de48e8ce','public_pr':'https://github.com/astral-experiments/imre/pull/4083','entry_sha256':sha(p/'entry.py'),'source_sha256':sha(p/'stock-test_logging.py'),'comparison':{'same_native_order_and_verdicts':normalized(streams['O0'])==normalized(streams['O3']),'same_native_per_parent_callback_and_subtest_tags':trace['O0']==trace['O3'],'same_native_terminal_details':streams['O0']==streams['O3']},'processes':{},'per_parent_tsv_sha256':sha(cross)}
for n,v in results.items():
    summary['processes'][n]={k:v[k] for k in ('complete','pid','status','exit','signal','timed_out','time_seconds','discovered','parent_events','total','foreign_events','crosswalk_sha256','receipt_sha256')}
    summary['processes'][n]['unexpected_handlers_parent_failures']=sum(line.startswith('FAIL ') and 'Unexpected handlers:' in line for line in streams[n])
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
manifest=p/'SHA256SUMS'
top=('entry.py','run.py','seal.py','close.py','extend.py','observe-slow.py','wait-close.py','stock-test_logging.py','deadline-rehearsal.py','deadline-rehearsal.out','scheduler-samples.tsv','originals.tsv','summary.json','scheduler-supervisor.out','scheduler-supervisor.err','outcome-supervisor.out','outcome-supervisor.err')
common=('suite-start.json','suite.out','suite.err','suite.json','outcome.json','parent-callbacks.tsv')
native=('compile-start.json','compile.out','compile.err','compile.json','extension.json','extension.out','extension.err','progress.tsv')
files=[p/n for n in top]
for lane in ('stock','O0','O3'):
    files.extend(p/lane/n for n in (common if lane=='stock' else common+native))
    files.extend(p/(lane+'-supervisor.'+ext) for ext in ('out','err'))
files=sorted(files)
assert all(f.is_file() for f in files)
manifest.write_text(''.join(f'{sha(f)}  {f.relative_to(p)}\n'for f in files))
print(sha(manifest),'SHA256SUMS',sha(p/'summary.json'),'summary.json',sha(cross),'originals.tsv')
