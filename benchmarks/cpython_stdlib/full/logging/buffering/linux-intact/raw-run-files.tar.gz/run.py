"""Execute the unchanged discovered logging suite with diagnostic callbacks."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
work=Path('/workspace/scratch/imre-logging-buffering/intact')
mem=Path('/dev/shm/imre-logging-leaf-public/buffering-intact')
head='8d3fe99e55c190cc72bfd78d2b5afe46de48e8ce'
pin='5607950ef232dad16d75c0cf53101d9649d89115'
stage=work/'stage'
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def save(file,data):
    tmp=file.with_suffix('.pending')
    tmp.write_text(json.dumps(data,indent=2)+'\n')
    tmp.replace(file)
def when():
    return datetime.now(timezone.utc).isoformat()
lane=sys.argv[1]
assert lane in ('stock','O0','O3')
out=here/lane
out.mkdir(exist_ok=True)
cwd=work/'run'/lane
env={**os.environ,'TMPDIR':str(mem/lane/'tmp'),'PYTHONDONTWRITEBYTECODE':'1'}
info=dict(suite='test.test_logging',lane=lane,cp_reference=pin,entry=str(stage/'entry.py'),original=str(stage/'test/test_logging.py'),entry_sha256=sha(stage/'entry.py'),original_sha256=sha(stage/'test/test_logging.py'))
assert info['entry_sha256']==sha(here/'entry.py')=='7b991b6760ecf896db5af3d9c9cadf1d7b6974562930c681e762886f46570371'
assert info['original_sha256']=='529fb98e8a0890d562d8d8903c09700635ad8f67cef4bad6f749f89d3442a563'
def run(name,argv,cwd,deadline):
    started=time.monotonic()
    r=dict(info,argv=list(map(str,argv)),executable_sha256=sha(argv[0]),cwd=str(cwd),tmpdir=env['TMPDIR'],started=when(),deadline_seconds=deadline)
    with (out/(name+'.out')).open('wb') as so,(out/(name+'.err')).open('wb') as se:
        proc=subprocess.Popen(argv,cwd=cwd,env=env,stdout=so,stderr=se,start_new_session=True)
        r.update(pid=proc.pid);save(out/(name+'-start.json'),r)
        try:
            status=proc.wait(timeout=deadline)
            timed_out=False
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(proc.pid,signal.SIGTERM)
            try:status=proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL)
                status=proc.wait()
    r.update(finished=when(),elapsed_seconds=time.monotonic()-started,status=status,exit=(status if status>=0 else None),signal=(-status if status<0 else None),timed_out=timed_out,stdout_sha256=sha(out/(name+'.out')),stderr_sha256=sha(out/(name+'.err')))
    save(out/(name+'.json'),r)
    return r
if lane=='stock':
    cmd=[Path('/workspace/scratch/imre-resources/cpython/python'),'-I','-B',stage/'entry.py']
else:
    from fcntl import flock,LOCK_EX
    freeze=here.parent/'public'/head/'freeze.json'
    fr=json.loads(freeze.read_bytes())
    assert fr['head']==head
    for tool in ('compiler','runtime','clang'):
        assert sha(fr[tool]['path'])==fr[tool]['sha256']
    info.update(imre_head=head,freeze=fr,freeze_sha256=sha(freeze))
    elf=mem/lane/'intact-suite'
    # Only one intact application level may allocate temporary LLVM / linker files at a time.
    with (work/'compile.lock').open('a') as lock:
        flock(lock,LOCK_EX)
        build=run('compile',[fr['compiler']['path'],'build',stage/'entry.py','--module-root',stage,'--runtime-imports','--no-cache','--opt-level',lane[1:],'--runtime',fr['runtime']['path'],'--clang',fr['clang']['path'],'-o',elf],stage,1800)
        if build['status']!=0:
            raise SystemExit(1)
    info.update(compile_receipt_sha256=sha(out/'compile.json'))
    cmd=[elf]
run('suite',cmd,cwd,1800)
