from pathlib import Path
import hashlib,json,sys,tarfile
root=Path(__file__).resolve().parents[1]
shared=Path('/workspace/shared')
out=root/'rollup'/sys.argv[1]
out.mkdir(exist_ok=True,parents=True)
ref=json.loads((root/'ref/ordered-reference.json').read_bytes())
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def ids(classes,methods): return ['test.test_ordered_dict.'+c+'.'+m for c in classes for m in methods]
old='2a1d028118c6ffdd57db37d716beed0fb21b13ec'
rev='cd9a332848640f6c704254b2a2c433d121fa2405'
builtin=['CPythonBuiltinDictTests']
accel=['CPythonOrderedDictTests','CPythonOrderedDictSubclassTests']
groups=[
 [old,'ordered-abc-4b3f1c19b1ef.tar.gz',ids(builtin,['test_abc'])],
 [old,'ordered-builtin-regression-2a1d028.tar.gz',ids(builtin,'test_init test_update test_delitem test_setitem test_detect_deletion_during_iteration test_reinsert test_override_update test_delitem_hash_collision'.split())],
 [rev,'ordered-accelerated-abc-578f64fe5af5.tar.gz',ids(accel,['test_abc'])],
 [rev,'ordered-repr-public-07671d856654.tar.gz',ids(accel,['test_repr'])],
 [rev,'ordered-mapping-public-39127c3dd79f.tar.gz',[r['id'] for r in json.loads((root/'mapping/accelerated/manifest.json').read_bytes())['rows']]]]
extra=root/'rollup/extra-groups.json'
if extra.is_file(): groups+=json.loads(extra.read_bytes())
packets={'ordered-linux-reference-7c872b6204c6.tar.gz','ordered-public-baseline-f64c25ec33f8.tar.gz'}
extra_packets=root/'rollup/extra-packets.json'
if extra_packets.is_file(): packets.update(json.loads(extra_packets.read_bytes()))
coverage={}
for head,packet,cases in groups:
    assert len(head)==40 and (shared/packet).is_file() and len(cases)==len(set(cases))
    for case in cases: coverage.setdefault(case,[]).append(dict(imre=head,packet=packet,O0='pass',O3='pass',reference='pass'))
    packets.add(packet)
rows=[dict(id=r['id'],occurrence=r['occurrence'],prior_paired=r['prior'],provider=r['provider'],source=r['source'],linux_reference=r['status'],public_selected=coverage.get(r['id'],[])) for r in ref['rows']]
assert set(coverage)<={r['id'] for r in rows}
assert len(rows)==295 and sum(r['prior_paired'] for r in rows)==228 and all(r['linux_reference']=='pass' for r in rows)
new=[r['id'] for r in rows if r['public_selected'] and not r['prior_paired']]
guard=[r['id'] for r in rows if r['public_selected'] and r['prior_paired']]
doc=out/'registrations.json'
doc.write_text(json.dumps(dict(cpython=ref['revision'],full_inventory=659,prior_full=528,ordered_inventory=295,prior_ordered=228,public_additions=new,prior_replayed=guard,historical_union_ordered=228+len(new),historical_union_full=528+len(new),scope='This union combines historical and public revisions. Public selections retain original method bodies and fixture classes. The intact-module result is recorded independently.',rows=rows,sha256={p:sha(shared/p) for p in sorted(packets)}),indent=2)+'\n')
tarpath=out/'ordered-public.tar.gz'
with tarfile.open(tarpath,'w:gz') as t:
    t.add(doc,arcname='registrations.json')
    t.add(Path(__file__),arcname='rollup.py')
    if extra.is_file(): t.add(extra,arcname='extra-groups.json')
    for p in sorted(packets): t.add(shared/p,arcname='packets/'+p,recursive=False)
print(sha(tarpath),len(new),len(guard),tarpath)
