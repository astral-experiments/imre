from collections import ChainMap
value = ChainMap({"a": 1})
print(eval(repr(value)))
