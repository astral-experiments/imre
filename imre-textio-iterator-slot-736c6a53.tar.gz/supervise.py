from pathlib import Path
import sys, json, hashlib
here=Path(__file__).resolve().parent
original=here.parent/'controls/run.py'
ns={'__file__':str(original)}
exec(compile(original.read_text().rsplit('lane(sys.argv[1])',1)[0],str(original),'exec'),ns)
pin=sys.argv[2] if len(sys.argv)>2 else 'd7948b7fec52794f7e3c5970fcea9cf472c3066d'
base=ns['base'];pair=base/'fs-family/provider-replay/pairs'/pin
ns['env']['IMRE_PYTHON']=str(pair/'imre');run=ns['run']
lane=sys.argv[1];out=here/pin/lane if len(sys.argv)>2 else here/lane;out.mkdir(parents=True)
src=here/'slot.py'
if lane=='cpython':
 cmd=[ns['ref'],'-B',src]
else:
 assert (pair/'commit').read_text().strip()==pin
 hashes={k:h for h,k in [x.split() for x in (pair/'ready').read_text().splitlines()]}
 for k,h in hashes.items(): assert hashlib.sha256((pair/k).read_bytes()).hexdigest()==h
 b=out/'build';b.mkdir();cmd=[out/'slot'];c=[pair/'imre','build',src,'--module-root',here,'--opt-level',lane[-1],'--no-cache','--runtime',pair/'libimre_runtime.a','--clang',base/'llvm/usr/bin/clang-19','--runtime-imports','-o',cmd[0]]
 m=run(c,b,b,200);m.update(sha=pin,hashes=hashes)
 (b/'result.json').write_text(json.dumps(m,indent=2));assert m['rc']==0,(b/'stderr').read_text()
cwd=out/'cwd';cwd.mkdir();m=run(cmd,cwd,out,20);m['cwd_residue']=[x.name for x in cwd.iterdir()];m['source_sha']=hashlib.sha256(src.read_bytes()).hexdigest();m['revision']='v3.14.5' if lane=='cpython' else pin
(out/'result.json').write_text(json.dumps(m,indent=2));print(lane,m['rc'],(out/'stdout').read_text(),(out/'stderr').read_text())
