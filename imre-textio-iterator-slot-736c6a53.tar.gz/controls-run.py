from pathlib import Path
import ctypes, hashlib, json, os, signal, stat, subprocess, sys, time
root=Path(__file__).resolve().parent
base=root.parents[1]
sha=(root.parent/'base').read_text().strip()
pair=base/'fs-family/provider-replay/pairs'/sha
ref=base/'python/managed/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
src=root/'src/probe.py'
env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','PYTHONWARNINGS','PYTHON_CONTEXT_AWARE_WARNINGS','IMREFLAGS')}
env.update(IMRE_PYTHON=str(pair/'imre'),LD_LIBRARY_PATH=str(base/'llvm/usr/lib/x86_64-linux-gnu'),PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
def digest(blob):return hashlib.sha256(blob).hexdigest()
def run(cmd, cwd, dest, timeout):
    temp=dest/'tmp';temp.mkdir()
    with (dest/'stdout').open('wb') as so, (dest/'stderr').open('wb') as se:
        p=subprocess.Popen([str(x) for x in cmd],cwd=cwd,env=dict(env,TMPDIR=str(temp)),stdin=subprocess.PIPE,stdout=so,stderr=se,start_new_session=True)
        pipe=stat.S_ISFIFO(os.fstat(p.stdin.fileno()).st_mode)
        timedout=False
        try:p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timedout=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
        p.stdin.close()
    kids=[]
    while True:
        try:
            pid,status=os.waitpid(-1,os.WNOHANG)
            assert pid
            kids.append([pid,status])
        except ChildProcessError:break
    extra=sorted(str(p.relative_to(temp)) for p in temp.rglob('*'))
    assert pipe and not kids and not timedout and not extra
    return dict(cmd=list(map(str,cmd)),pid=p.pid,rc=p.returncode,stdin_pipe=pipe,timeout=timedout,adopted=kids,tmp_residue=extra,stdout_sha256=digest((dest/'stdout').read_bytes()),stderr_sha256=digest((dest/'stderr').read_bytes()))
mixed=b'a\r\nb\rc\n\xc3\xa9'
dataset={k:mixed for k in ('translate','preserve','crlf','iterate','invalid-whence','decode-all')}
dataset.update({'offset':b'A\xc3\xa9B\n','offset-inverted':b'A\xc3\xa9B\n','latin1':b'a\xe9B\n','cookie':b'a\rb','trailing-cr':b'line1\r','strict':b'X\xffY','replace':b'X\xffY','wide':'Aé麵Z'.encode('utf-16'),'fixed16':'Aé麵Z'.encode('utf-16-le')})
def lane(name):
    out=root/name;out.mkdir()
    if name=='cpython':
        cmd=[ref,'-B',src]
    else:
        wait_until=time.monotonic()+780
        while not (pair/'ready').exists():
            if time.monotonic()>wait_until:raise TimeoutError(pair)
            time.sleep(1)
        assert (pair/'commit').read_text().strip()==sha
        hashes={k:h for h,k in [line.split() for line in (pair/'ready').read_text().splitlines()]}
        for n,h in hashes.items():assert digest((pair/n).read_bytes())==h
        build=out/'build';build.mkdir()
        cmd=[out/'probe']
        args=[pair/'imre','build',src,'--module-root',src.parent,'--opt-level',name.rsplit('O',1)[1],'--no-cache','--runtime',pair/'libimre_runtime.a','--clang',base/'llvm/usr/bin/clang-19','-o',cmd[0]]
        if name.startswith('boxed'):args.append('--runtime-imports')
        meta=run(args,build,build,240)
        meta.update(sha=sha,pair=hashes)
        (build/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
        if meta['rc']:raise RuntimeError((build/'stderr').read_text())
    for form in ('bytes','buffered','raw','buffered-bytes'):
        for case,data in dataset.items():
            dest=out/form/case; dest.mkdir(parents=True)
            work=dest/'cwd';work.mkdir()
            fixture=work/'fixture';fixture.write_bytes(data)
            stat0=fixture.stat()
            meta=run(cmd+[form,case],work,dest,20)
            assert meta['rc']==0
            assert fixture.read_bytes()==data and stat0.st_ino==fixture.stat().st_ino and list(work.iterdir())==[fixture]
            fixture.unlink()
            assert not list(work.iterdir())
            meta.update(form=form,case=case,fixture_sha256=digest(data),input_hex=data.hex(),same_inode=True,cwd_residue=[],sha=sha if name!='cpython' else 'v3.14.5')
            if name!='cpython':
                for stream in ('stdout','stderr'):
                    meta[stream+'_matches_cpython']=(dest/stream).read_bytes()==(root/'cpython'/form/case/stream).read_bytes()
            (dest/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
        print(name,form,'finished',flush=True)
lane(sys.argv[1])
