import _io

def disabled(text):
    try:
        text.tell()
    except OSError as error:
        assert str(error) == "telling position disabled by next() call"
    else:
        raise AssertionError("telling was enabled")

def slot(control):
    with _io.TextIOWrapper(_io.BytesIO(b"a\nb\n")) as text:
        text.readline = lambda: "instance"
        assert next(text) == "a\n"
        disabled(text)
    with _io.TextIOWrapper(_io.BytesIO(b"a\nb\n")) as text:
        assert _io._IOBase.__next__(text) == "a\n" and text.tell() == 2
    try:
        _io.TextIOWrapper.__next__(_io.BytesIO())
    except TypeError as error:
        assert str(error) == "descriptor '__next__' requires a '_io.TextIOWrapper' object but received a '_io.BytesIO'"
    else:
        raise AssertionError("concrete slot accepted BytesIO")
    class Lines(_io.TextIOWrapper):
        def readline(self):
            disabled(self)
            if control == "resumed":
                self.flush()
                return super().readline()
            if control == "stop":
                raise StopIteration("override")
            return b""
    with Lines(_io.BytesIO(b"a\nb\n")) as text:
        if control == "resumed":
            assert next(text) == "a\n" and text.tell() == 2
        elif control == "stop":
            assert next(text, None) is None
            disabled(text)
        else:
            try:
                next(text)
            except OSError as error:
                assert str(error) == "readline() should have returned a str object, not 'bytes'"
            else:
                raise AssertionError("accepted binary line")
            disabled(text)

for control in ("resumed", "stop", "bad"):
    slot(control)
print("concrete/base and subclass success, StopIteration, non-text guards")
class Raw(_io.BytesIO):
    fail = False
    def flush(self):
        if self.fail:
            raise ValueError("injected")
        return super().flush()

raw = Raw(b"a\nb\n")
with _io.TextIOWrapper(raw) as text:
    assert next(text) == "a\n"
    raw.fail = True
    try:
        text.flush()
    except ValueError as error:
        assert str(error) == "injected"
    else:
        raise AssertionError("swallowed flush failure")
    raw.fail = False
    assert text.tell() == 4
print("flush failure re-enabled telling")
