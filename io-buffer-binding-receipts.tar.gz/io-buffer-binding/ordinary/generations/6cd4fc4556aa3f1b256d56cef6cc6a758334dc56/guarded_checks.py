import io
import _io
import sys

saved_public_module = io
saved_private_module = _io
original_reader_class = io.BufferedReader

print("BEGIN receiver")
import io

try:
    io.BufferedReader.read(object(), 1)
except TypeError as exc:
    print(type(exc).__name__, str(exc))
else:
    raise AssertionError("BufferedReader.read accepted an unrelated receiver")

print("END receiver")

print("BEGIN named")
from io import BufferedReader as PublicReader
from _io import BufferedReader as NativeReader

assert PublicReader is NativeReader
assert PublicReader.__name__ == "BufferedReader"
assert PublicReader.__module__ == "_io"
print("from imports")

print("END named")

print("BEGIN bound_args")
import io

cls = io.BufferedReader
with io.open(__file__, "rb") as f:
    assert type(f) is cls
    for op in (lambda: f.read(1, 2), lambda: f.read(size=1),
               lambda: cls.read(f, 1, 2), lambda: cls.read(f, size=1)):
        try:
            op()
        except TypeError as exc:
            print(exc)
        else:
            raise AssertionError("invalid read accepted")
    assert f.tell() == 0
    assert f.read(6) == b"import"

print("END bound_args")

print("BEGIN generation_classes")
import io
import _io
import sys

first = io.BufferedReader
first_open = _io.open
del sys.modules['io'], sys.modules['_io']
low = __import__('_io')
fresh = __import__('io')
second = low.BufferedReader
assert second is not first and fresh.BufferedReader is second
for cls in (first, second):
    try:
        cls.test_probe_attribute = 1
    except TypeError:
        print("immutable")
    else:
        raise AssertionError("native class accepted new class attribute")

low.BufferedReader = first
fresh.BufferedReader = first
with first_open(__file__, "rb") as old_file, low.open(__file__, "rb") as fresh_file:
    assert type(fresh_file) is second and type(old_file) is first
    for cls, valid, wrong in ((first, old_file, fresh_file), (second, fresh_file, old_file)):
        try:
            cls.read(wrong, 1)
        except TypeError:
            print("cross generation rejected")
        else:
            raise AssertionError("accepted unrelated native class generation")
        assert cls.read(valid, 6) == b"import"

print("END generation_classes")
sys.modules["io"] = saved_public_module
sys.modules["_io"] = saved_private_module

print("BEGIN four_opens")
import builtins
import io
import _io
import sys

old = io
old_low = _io
old_open = io.open
old_file = io.open(__file__, "rb")
del sys.modules["io"], sys.modules["_io"]
fresh_low = __import__("_io")
fresh = __import__("io")

for label, opener in (("builtins", builtins.open), ("old", old_open),
                      ("fresh", fresh.open), ("fresh-low", fresh_low.open)):
    with opener(__file__, "rb") as source:
        cls = type(source)
        print(label, cls is old.BufferedReader, cls is fresh.BufferedReader,
              isinstance(source, old.BufferedIOBase), isinstance(source, fresh.BufferedIOBase))
        assert source.read(1) == b"i"

assert old_open is builtins.open and old_open is old_low.open
assert fresh.open is fresh_low.open and fresh.open is not builtins.open
assert old_open.__self__ is old_low and fresh.open.__self__ is fresh_low
assert type(old_file) is old.BufferedReader
assert old.BufferedReader.read(old_file, 6) == b"import"
old_file.close()

print("END four_opens")
sys.modules["io"] = saved_public_module
sys.modules["_io"] = saved_private_module
