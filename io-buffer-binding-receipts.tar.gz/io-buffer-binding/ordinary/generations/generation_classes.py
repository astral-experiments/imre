import io
import _io
import sys

first = io.BufferedReader
first_open = _io.open
del sys.modules['io'], sys.modules['_io']
low = __import__('_io')
fresh = __import__('io')
second = low.BufferedReader
assert second is not first and fresh.BufferedReader is second
for cls in (first, second):
    try:
        cls.test_probe_attribute = 1
    except TypeError:
        print("immutable")
    else:
        raise AssertionError("native class accepted new class attribute")

low.BufferedReader = first
fresh.BufferedReader = first
with first_open(__file__, "rb") as old_file, low.open(__file__, "rb") as fresh_file:
    assert type(fresh_file) is second and type(old_file) is first
    for cls, valid, wrong in ((first, old_file, fresh_file), (second, fresh_file, old_file)):
        try:
            cls.read(wrong, 1)
        except TypeError:
            print("cross generation rejected")
        else:
            raise AssertionError("accepted unrelated native class generation")
        assert cls.read(valid, 6) == b"import"
