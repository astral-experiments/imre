import builtins
import io
import _io
import sys

old = io
old_low = _io
old_open = io.open
old_file = io.open(__file__, "rb")
del sys.modules["io"], sys.modules["_io"]
fresh_low = __import__("_io")
fresh = __import__("io")

for label, opener in (("builtins", builtins.open), ("old", old_open),
                      ("fresh", fresh.open), ("fresh-low", fresh_low.open)):
    with opener(__file__, "rb") as source:
        cls = type(source)
        print(label, cls is old.BufferedReader, cls is fresh.BufferedReader,
              isinstance(source, old.BufferedIOBase), isinstance(source, fresh.BufferedIOBase))
        assert source.read(1) == b"i"

assert old_open is builtins.open and old_open is old_low.open
assert fresh.open is fresh_low.open and fresh.open is not builtins.open
assert old_open.__self__ is old_low and fresh.open.__self__ is fresh_low
assert type(old_file) is old.BufferedReader
assert old.BufferedReader.read(old_file, 6) == b"import"
old_file.close()
