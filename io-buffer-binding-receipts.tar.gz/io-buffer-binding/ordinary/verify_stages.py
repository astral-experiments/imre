"""Verify complete two-mode/two-level results for the published-head controls."""
import argparse
import hashlib
import json
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('revision')
options=parser.parse_args()
root=Path(__file__).resolve().parent
files=set()
results=[]
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for mode in ('ordinary','boxed'):
    for level in (0,3):
        stage=root/f'{options.label}-{mode}-O{level}'
        provenance=stage/'provenance.json'
        meta=json.loads(provenance.read_bytes())
        assert meta['sha']==options.revision
        files.add(provenance)
        for case in ['guarded_fixture','guarded_checks','file','module_open','index_refusal']+(['fixed_open'] if mode=='ordinary' else []):
            lane=stage/f'{case}.{mode}.O{level}'
            path=lane/'receipt.json'
            result=json.loads(path.read_bytes())
            native=result['process']
            assert result['build']['exit']==native['exit']==result['oracle']['exit']==0,(stage,case)
            source=root/'inputs'/(case+'.py')
            assert digest(source)==meta['inputs'][case]
            if case=='index_refusal':
                assert (lane/'process.stdout').read_bytes()==b'unsupported Python readinto, cursor 0\n'
                assert (lane/'oracle.stdout').read_bytes()==b"Python readinto b'z' 0\n"
                assert not (lane/'process.stderr').read_bytes()
                verdict='explicit unsupported callback; raw cursor remains zero'
            else:
                assert result['matches_cpython'] and all((lane/f'process.{x}').read_bytes()==(lane/f'oracle.{x}').read_bytes() for x in ('stderr','stdout')), (stage,case)
                verdict='matches CPython'
            if case=='guarded_checks':
                output=(lane/'process.stdout').read_bytes()
                for name in ('receiver','named','bound_args','generation_classes','four_opens'):
                    assert f'END {name}\n'.encode() in output
                assert b'builtins True False True False\nold True False True False\nfresh False True False True\nfresh-low False True False True\n' in output
            if case=='fixed_open':
                before=root/'parent-ordinary'/f'fixed_open.ordinary.O{level}'/'receipt.json'
                parent=json.loads(before.read_bytes())
                assert result['llvm_sha256']==parent['llvm_sha256']=='611bc6b2a7dcaa04475862c42b91e90361da39ce1fbe3848fbc7aa80cd52ca59'
                assert not result['boxed_ir'] and not parent['boxed_ir']
                files.add(before)
            results.append(dict(lane=f'{case}.{mode}.O{level}',verdict=verdict,receipt=str(path.relative_to(root))))
            files.add(source)
            files.update(p for p in lane.iterdir() if p.is_file())
prefix=options.label.upper()
summary=root/(prefix+'.json')
summary.write_text(json.dumps(dict(revision=options.revision,fixture_sha256=digest(root/'inputs/guarded_fixture.py'),native_checks=results),indent=2)+'\n')
files.update([summary,Path(__file__).resolve(),root/'measure.py'])
manifest=root/(prefix+'.sha256')
manifest.write_text(''.join(digest(f)+'  '+str(f.relative_to(root))+'\n' for f in sorted(files)))
print(len(results),'lanes,',len(files),'files;',manifest.name,digest(manifest))
