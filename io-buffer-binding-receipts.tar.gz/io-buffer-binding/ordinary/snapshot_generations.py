from pathlib import Path
import argparse,hashlib,json,shutil
p=argparse.ArgumentParser()
p.add_argument('stage')
p.add_argument('revision')
args=p.parse_args()
root=Path(__file__).resolve().parent
out=root/'generations'/args.revision
out.mkdir(exist_ok=True)
src=root/'inputs/guarded_checks.py'
for mode in ('ordinary','boxed'):
    for level in (0,3):
        stage=root/f'{args.stage}-{mode}-O{level}'
        source=stage/f'guarded_checks.{mode}.O{level}'
        meta=json.loads((stage/'provenance.json').read_bytes())
        assert meta['sha']==args.revision
        assert meta['inputs']['guarded_checks']==hashlib.sha256(src.read_bytes()).hexdigest()
        for suffix in ('receipt.json','process.stdout','process.stderr','build.stdout','build.stderr'):
            shutil.copyfile(source/suffix,out/f'{mode}.O{level}.{suffix}')
        stream=(source/'process.stdout').read_bytes()
        begin=b'BEGIN four_opens\n'
        end=b'END four_opens\n'
        assert stream.count(begin)==stream.count(end)==1
        excerpt=stream.split(begin,1)[1].split(end,1)[0]
        assert excerpt==(root/'generations/oracle.stdout').read_bytes()
        (out/f'{mode}.O{level}.four_opens.stdout').write_bytes(excerpt)
shutil.copyfile(src,out/'guarded_checks.py')
files=sorted(f for f in out.iterdir() if f.is_file() and f.name!='SHA256SUMS')
sums=out/'SHA256SUMS'
sums.write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in files))
print('generation matrix SHA256SUMS',hashlib.sha256(sums.read_bytes()).hexdigest())
