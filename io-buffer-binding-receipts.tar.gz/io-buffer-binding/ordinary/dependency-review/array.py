import array
import io

for method in ("readinto", "readinto1"):
    dst = array.array("i", [0, 0])
    f = io.BufferedReader(io.BytesIO(b"ABCD"), 4)
    assert getattr(f, method)(dst) == 4
    assert memoryview(dst).cast("B").tobytes() == b"ABCD" + b"\0" * (dst.itemsize * len(dst) - 4)
    print(method, "wrote 4 bytes")
    f.close()
