import io

with io.open(__file__, "rb") as source:
    for args in ((1, 2),):
        try:
            io.BufferedReader.read(source, *args)
        except TypeError as exc:
            print(str(exc))
        else:
            raise AssertionError("read accepted two arguments")
    try:
        io.BufferedReader.read(source, size=1)
    except TypeError as exc:
        print(str(exc))
    else:
        raise AssertionError("read accepted a keyword")
    assert source.tell() == 0
    print("file position preserved")
