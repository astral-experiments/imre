# Independent review of BufferedReader callback support

Reviewed frozen #3437 at `64621bb1b99392529e881624fc753c74dc96f2ce` against public Imre `922b21506bf57f399cf2356f9803906b1f0d55a4` and CPython 3.14.5 at `5607950ef232dad16d75c0cf53101d9649d89115`. Each probe has a captured pinned-CPython exit code and output. Source predictions for #3437 are distinct from native results.

| Probe | CPython result | Finding in #3437 |
| --- | --- | --- |
| `callback.py` | During raw.readinto, read(0), read1(0), and readline(0) return empty bytes. Nested readinto raises RuntimeError. The outer read succeeds. | `buffered_reader.rs:643` unconditionally reacquires the lock for all three zero-length reads and rejects them. |
| `array.py` | Both readinto methods write four bytes to an integer array and preserve the untouched bytes. | `buffered_reader.rs:293` uses `memoryview.rs:87`, accepting only bytearrays or writable views. Constructing and casting a view of an array is missing. This affects the unchanged CBufferedReaderTest.test_readinto_array and test_readinto1_array. |
| `descriptor_args.py` | Unbound read rejects an extra positional argument and a size keyword. Both errors preserve file position. | On native files, `io.rs:488–493` bypasses the wrapper's checks and forwards to files::call. The regular-file Reader branch reads only args[1] at `files.rs:392–395`. |
| `hash_release.py` | Bytes and an equivalent read-only view agree as dictionary keys. A previously computed hash survives release. Collection clears the view's weak reference. | Public `dictionary/keys.rs:494` relies on a cached hash. #3437's representation has no hash slot. Preserve public hash, equality, released-state, and weakref behavior when porting the representation. |
| `callback_gc.py` | Collection inside tell and readinto, a retained view, a read from the buffer it changed, and then releasing the view and raw weakref all work. | The PR traces the persistent backing and raw handle. This test checks those edges across Python callbacks without accessing the view after closing the reader. |

The public tree also protects array exports in `dynamic/mod.rs:355`. The older dependency's buffer-export helper omits arrays. Keep public export/release behavior when porting. The public base passed `hash_release.py` natively in boxed mode at both levels. Frozen #3437 requires resolution with the newer public representation before it can supply a tested dependency.
