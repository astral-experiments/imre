import gc
import re
import weakref

v = memoryview(b"x")
w = weakref.ref(v)
d = {v: "ok"}
assert d[b"x"] == "ok"
assert hash(v) == hash(b"x")
v.release()
gc.collect()
assert hash(v) == hash(b"x")
assert d[v] == "ok"
del d[v], v
gc.collect()
assert w() is None
print("dict equality, cached hash and weakref passed")
