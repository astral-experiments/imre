import gc
import io

class Raw(io.RawIOBase):
    def readable(self):
        return True

    def readinto(self, dest):
        gc.collect()
        print("nested", reader.read(0), reader.read1(0), reader.readline(0))
        try:
            reader.readinto(bytearray())
        except RuntimeError:
            print("nested readinto locked")
        else:
            raise AssertionError("readinto re-entered the lock")
        dest[:1] = b"x"
        return 1


reader = io.BufferedReader(Raw(), buffer_size=4)
assert reader.read(1) == b"x"
print("outer read x")
