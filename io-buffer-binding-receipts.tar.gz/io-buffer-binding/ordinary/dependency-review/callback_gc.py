import gc
import io
import weakref


class Raw(io.RawIOBase):
    def readable(self):
        return True

    def tell(self):
        gc.collect()
        return 0

    def readinto(self, dest):
        self.saved = dest
        gc.collect()
        assert dest.obj is None
        dest[:] = b"abcd"
        return 4


raw = Raw()
reader = io.BufferedReader(raw, 4)
assert reader.peek() == b"abcd"
gc.collect()
raw.saved[1] = 120
assert reader.read(4) == b"axcd"
raw.saved.release()
weak = weakref.ref(raw)
reader.close()
del raw, reader
gc.collect()
assert weak() is None
print("retained read-ahead view and raw weakref")
