"""Summarize native receipt files while retaining stdout, stderr and build/process timings."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
rows = []
for proof in sorted(root.glob('*/provenance.json')):
    provenance = json.loads(proof.read_bytes())
    for receipt in sorted(proof.parent.glob('*/receipt.json')):
        case, mode, opt = receipt.parent.name.split('.')
        measured = json.loads(receipt.read_bytes())
        result = measured.get('process')
        build = measured['build']
        verdict = 'compile failure'
        if result:
            if result['exit'] < 0:
                verdict = 'process signal'
            elif result['exit']:
                verdict = 'native failure'
            elif measured['matches_cpython']:
                verdict = 'matches CPython'
            elif case == 'index_refusal' and (receipt.parent/'process.stdout').read_bytes() == b'unsupported Python readinto, cursor 0\n':
                verdict = 'explicit unsupported callback, raw tell preserved'
            else:
                verdict = 'native output mismatch'
        rows.append(dict(stage=proof.parent.name, revision=provenance['sha'], probe=case, mode=mode,
            opt=opt, verdict=verdict, build_exit=build['exit'], build_seconds=build['elapsed_s'],
            native_exit=result['exit'] if result else None,
            native_seconds=result['elapsed_s'] if result else None,
            llvm_sha256=measured.get('llvm_sha256'), boxed_ir=measured.get('boxed_ir'),
            receipt=str(receipt.relative_to(root))))
(root/'summary.json').write_text(json.dumps(dict(cpython='5607950ef232dad16d75c0cf53101d9649d89115',
    results=rows), indent=2)+'\n')
for stage in ('head-ordinary','head-boxed','parent-ordinary','parent-boxed'):
    here=[r for r in rows if r['stage']==stage]
    print(stage,len(here),{v:sum(1 for r in here if r['verdict']==v) for v in {r['verdict'] for r in here}})
