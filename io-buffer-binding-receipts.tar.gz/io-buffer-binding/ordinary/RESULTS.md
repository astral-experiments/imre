# Native BufferedReader binding controls

The checked-in fixture in [PR #3673](https://github.com/astral-experiments/imre/pull/3673) uses the original `tp = io.BufferedReader` class attribute, real native files, and concrete subclasses through both public and private import paths. It also checks inherited iteration and the diagnostics from calling the unbound methods with an unrelated object. These focused probes contribute zero original unittest IDs. The campaign records intact module discovery separately.

| Source | SHA | Ordinary O0 and O3 | Boxed O0 and O3 |
| --- | --- | --- | --- |
| Public parent | `2e658557643b5d4d53e3b24624c2ea6a06bf9da4` | Fixture compile exit 1, unsupported sealed export | Fixture build exit 0, native exit 1, missing private import |
| Guarded PR head | `6cd4fc4556aa3f1b256d56cef6cc6a758334dc56` | Checked-in fixture matches CPython | Checked-in fixture matches CPython |
| Public merge | `ae0e69c4f08a6a859550c18b70ed22509121667d` | Checked-in fixture matches CPython | Checked-in fixture matches CPython |

The parent, guarded and merged fixture inputs have SHA-256 `ec1712c917468212d42122fb3dc33199dfe43065cc0996f40c7cec1e5de53ae8`. Each release revision also ran the leading `with io.open(...)` file case, named `io.open` and `_io.open` imports, bound and unbound reads, native class mutability, cross-generation receiver rejection, and the original versus freshly imported openers. The four-opener outputs match the pinned CPython 3.14.5 oracle at `5607950ef232dad16d75c0cf53101d9649d89115` in every release lane. See `generations/` for the raw outputs.

Each release revision contains 22 native lanes, all with build and process exit 0. Eighteen matched CPython stdout and stderr exactly. In each of the other four, a size conversion replaced `raw.readinto` with a Python callback. Imre reported unsupported Python raw methods and preserved the file cursor at zero. CPython invoked the callback and also left the cursor at zero. During preliminary testing, `70ac77ae532c9079a13b8aae56d9d362d86fd5a2` had silently consumed source bytes in this case.

The two-level ordinary `builtins.open` control retained byte-identical LLVM on the exact parent, guarded head, and merge. The emitted IR SHA-256 was `611bc6b2a7dcaa04475862c42b91e90361da39ce1fbe3848fbc7aa80cd52ca59` throughout, with no boxed runtime symbols.

Run `sha256sum -c GUARDED.sha256` or `sha256sum -c PUBLIC.sha256` from this directory to verify a release stage. `summary.json` points to raw argv, seconds, status, and stdout/stderr for every compiler and native process. `REVIEW-tested-54e1504.md` records the independent runtime review. The older #3437 callback review and pinned CPython probes live in `dependency-review/`.
