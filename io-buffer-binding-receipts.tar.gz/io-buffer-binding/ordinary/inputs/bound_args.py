import io

cls = io.BufferedReader
with io.open(__file__, "rb") as f:
    assert type(f) is cls
    for op in (lambda: f.read(1, 2), lambda: f.read(size=1),
               lambda: cls.read(f, 1, 2), lambda: cls.read(f, size=1)):
        try:
            op()
        except TypeError as exc:
            print(exc)
        else:
            raise AssertionError("invalid read accepted")
    assert f.tell() == 0
    assert f.read(6) == b"import"
