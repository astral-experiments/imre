with open("data.bin", "rb") as source:
    print(source.read(2))
    print(source.tell())
    print(source.read(4))
