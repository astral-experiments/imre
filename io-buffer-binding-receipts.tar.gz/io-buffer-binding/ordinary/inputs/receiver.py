import io

try:
    io.BufferedReader.read(object(), 1)
except TypeError as exc:
    print(type(exc).__name__, str(exc))
else:
    raise AssertionError("BufferedReader.read accepted an unrelated receiver")
