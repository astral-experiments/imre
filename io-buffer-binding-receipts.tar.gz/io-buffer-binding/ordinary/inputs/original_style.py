import io
from _io import BufferedReader as NativeReader


class ReaderCase:
    tp = io.BufferedReader


assert ReaderCase.tp is NativeReader
with io.open(__file__, "rb") as source:
    assert type(source) is ReaderCase.tp
    assert isinstance(source, io.BufferedIOBase)
    assert source.read(1) == b"i"
    assert NativeReader.read(source, 5) == b"mport"

try:
    NativeReader.read(object(), 1)
except TypeError as exc:
    print(exc)
else:
    raise AssertionError("BufferedReader.read accepted an unrelated receiver")
