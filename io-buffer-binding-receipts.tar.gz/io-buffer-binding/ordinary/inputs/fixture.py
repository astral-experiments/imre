import io


class BufferedReaderCase:
    tp = io.BufferedReader


assert BufferedReaderCase.tp is io.BufferedReader
assert BufferedReaderCase().tp is io.BufferedReader
print("class fixture")
