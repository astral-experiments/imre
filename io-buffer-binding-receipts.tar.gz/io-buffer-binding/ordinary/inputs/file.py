import io
import _io

with io.open("data.bin", "rb") as stream:
    assert type(stream) is io.BufferedReader
    assert type(stream) is _io.BufferedReader
    assert isinstance(stream, io.BufferedReader)
    assert isinstance(stream, io.BufferedIOBase)
    print("reader identity")
    assert stream.read(2) == b"ab"
    print("bound read")
    assert io.BufferedReader.read(stream, 2) == b"cd"
    assert stream.read() == b"ef"
    print("unbound read")
