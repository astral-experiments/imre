import io


class FileIOCase:
    tp = io.FileIO


assert FileIOCase.tp is io.FileIO
assert FileIOCase().tp is io.FileIO
print("class fixture")
