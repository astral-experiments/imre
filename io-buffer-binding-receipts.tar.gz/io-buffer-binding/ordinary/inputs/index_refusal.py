import io

cls = io.BufferedReader
with io.FileIO(__file__, "r") as raw, cls(raw, 4) as reader:
    class Size:
        def __index__(self):
            def replacement(dest):
                dest[0] = 122
                return 1
            raw.readinto = replacement
            return 1

    try:
        read = reader.read(Size())
    except NotImplementedError:
        assert raw.tell() == 0
        print("unsupported Python readinto, cursor", raw.tell())
    else:
        assert read == b"z" and raw.tell() == 0
        print("Python readinto", read, raw.tell())
