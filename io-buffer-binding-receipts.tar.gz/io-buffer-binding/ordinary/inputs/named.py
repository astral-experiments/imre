from io import BufferedReader as PublicReader
from _io import BufferedReader as NativeReader

assert PublicReader is NativeReader
assert PublicReader.__name__ == "BufferedReader"
assert PublicReader.__module__ == "_io"
print("from imports")
