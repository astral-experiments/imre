import io

class F(io.FileIO):
    pass

assert issubclass(F, io.FileIO)
