from io import open as public_open
from _io import open as low_open

assert public_open is low_open
assert public_open is open
with low_open("data.bin", "rb") as source:
    print(source.read(2))
with public_open("data.bin", "rb") as source:
    print(source.read(4))
