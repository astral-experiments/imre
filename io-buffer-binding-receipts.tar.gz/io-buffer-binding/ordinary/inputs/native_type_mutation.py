import _io
import io


class User(io.BufferedReader):
    pass


for cls in (_io._IOBase, _io._RawIOBase, _io._BufferedIOBase, _io._TextIOBase,
            _io.BytesIO, _io.StringIO, _io.FileIO, _io.TextIOWrapper, _io.BufferedReader):
    for change in (lambda: setattr(cls, "ordinary_probe", 1),
                   lambda: delattr(cls, "read")):
        try:
            change()
        except TypeError:
            pass
        else:
            raise AssertionError("native table mutation succeeded")
    print(cls.__name__, "immutable")
for cls in (io.IOBase, io.BufferedIOBase, User):
    cls.ordinary_probe = 1
    assert cls.ordinary_probe == 1
    del cls.ordinary_probe
    assert not hasattr(cls, "ordinary_probe")
    print(cls.__name__, "mutable")
