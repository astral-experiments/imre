# Native BufferedReader dispatch review

Reviewed the changes in `calls.rs`, `value.rs`, `stdlib/io.rs`, `stdlib/io/native_reader.rs` and `stdlib/io/descriptor_buffer.rs` between public parent `2e658557643b5d4d53e3b24624c2ea6a06bf9da4` and tested head `54e15041ba6253f06fb8327088db103332df7bc3`. The two compiler export entries and subclass lowering have a separate implementation and test history.

- Native read handles use the class installed by their original low-level module for descriptor lookup. The lookup accepts the class's own method and getset descriptors. The unbound descriptor checks the actual receiver class and its concrete ancestors.
- Subsequent low-level imports create a module-bound opener carrying that generation's reader class. A fresh reader traces the existing file handle and preserves its cursor. The original opener retains its identity, and old instances and descriptors keep their class when the modules are evicted or their public names rebound.
- Constructor-backed readers retain their actual raw FileIO object through a traced backing handle. The descriptor shares the raw owner and closes its descriptor only once, respecting closefd. Finite reads drain buffered bytes, take complete blocks directly, and fill the final partial block so that FileIO.tell exposes read-ahead.
- The public native type write/delete guard checks low-level classes. CPython 3.14.5 rejects class writes on all nine protected native I/O classes and permits them on public Python I/O bases and subclasses.
- A Python-defined raw read operation requires broader callback support. The focused implementation refuses an override introduced during size conversion and preserves the raw cursor. The CPython oracle invokes that callback. Fresh-generation FileIO and text/writer class identity belong to the wider open implementation.

The exact native controls and actual before/after results are in the adjacent stage directories. This review covers class and dispatch behavior. The standalone probes contribute zero original unittest IDs.
