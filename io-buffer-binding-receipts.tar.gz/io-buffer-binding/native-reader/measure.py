"""Reuse ordinary/measure.py's exact compiler/digest/receipt protocol in a separate family."""
from pathlib import Path
import runpy
base = Path(__file__).resolve().parent
runner = runpy.run_path(str(base.parent / "ordinary" / "measure.py"))
runner["main"].__globals__.update(BASE=base, WORK=Path("/tmp/io-native-reader-runs"))
runner["main"]()
