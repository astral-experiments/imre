import io
import sys
import _io
import importlib

def members(source):
    for method in ("read", "read1", "readinto1", "readlines", "__iter__", "__next__", "writable", "write", "detach"):
        print(method, hasattr(source, method), hasattr(type(source), method))

with open("data.bin", "rb") as original:
    members(original)

old = _io
del sys.modules["_io"]
fresh = importlib.import_module("_io")
print("open type", type(old.open).__name__, type(fresh.open).__name__, type(old.open) is type(fresh.open))
print("open self", getattr(fresh.open, "__self__", None) is fresh)
with old.FileIO("data.bin") as raw:
    with fresh.open(raw.fileno(), "rb", closefd=False) as reader:
        print("fresh reader", type(reader) is getattr(fresh, "BufferedReader", None))
        print("raw generation", type(reader.raw) is getattr(fresh, "FileIO", None), type(reader.raw) is getattr(old, "FileIO", None))
