import io

class Recorded(io.BufferedReader):
    def flush(self):
        print("flush", self.raw.closed)
        return super().flush()

raw = io.FileIO("data.bin", "r")
reader = Recorded(raw, 4)
raw.readinto = lambda dst: 0
reader.close()
print("closed", reader.closed, raw.closed)
