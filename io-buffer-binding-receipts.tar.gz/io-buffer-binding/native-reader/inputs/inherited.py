import io

for action in (lambda: io.BufferedReader.__init__(), lambda: io.BufferedReader.__init__(object()), lambda: io.BufferedReader.read(object())):
    try:
        action()
    except TypeError as error:
        print("receiver", str(error))
with io.open("data.bin", "rb") as reader:
    print("iter", reader.__iter__() is reader)
    print("next", reader.__next__())
    reader.seek(0)
    buf = bytearray(2)
    print("readinto1", reader.readinto1(buf), buf)
    print("tail", reader.readlines())
    print("bound detach", hasattr(reader, "detach"))
print("closed writable", reader.writable())
