import io

with io.FileIO("cursor.bin", "w") as writer:
    writer.write(b"0123456789abcdefghijklmnopqrstuvwxyz")

for size in (1, 3, 4, 5, 6, 8, 9, 13, 31, 36, 37):
    raw = io.FileIO("cursor.bin", "r")
    with io.BufferedReader(raw, buffer_size=4) as reader:
        assert reader.raw is raw
        data = reader.read(size)
        print(size, len(data), reader.tell(), raw.tell())
        suffix = reader.read(3)
        print(len(suffix), reader.tell(), raw.tell())
    assert raw.closed
