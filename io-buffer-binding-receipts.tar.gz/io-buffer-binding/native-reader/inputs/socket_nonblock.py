import socket

left, right = socket.socketpair()
with left, right:
    right.setblocking(False)
    with right.makefile("rb") as reader:
        print("no data", reader.read1(1))
        left.sendall(b"xyz")
        print("partial", reader.read1(1), right.recv(8))
