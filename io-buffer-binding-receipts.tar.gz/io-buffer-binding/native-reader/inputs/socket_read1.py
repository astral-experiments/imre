import socket
left, right = socket.socketpair()
with left, right:
    left.sendall(b"abcdef")
    left.shutdown(socket.SHUT_WR)
    with right.makefile("rb") as reader:
        print("single", reader.read1(1), right.recv(8))
left, right = socket.socketpair()
with left, right:
    left.sendall(b"abcdef")
    left.shutdown(socket.SHUT_WR)
    with right.makefile("rb") as reader:
        print("prefilled", reader.read(1), reader.read1(2), reader.read1(8), reader.read1(0), right.recv(8))
