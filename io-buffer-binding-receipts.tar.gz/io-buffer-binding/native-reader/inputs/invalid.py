import io

def show(fn):
    try:
        fn()
    except Exception as error:
        print(type(error).__name__, str(error))

raw = io.FileIO("data.bin", "r")
show(lambda: io.BufferedReader(None))
show(lambda: io.BufferedReader(None, "bad"))
show(lambda: io.BufferedReader(raw, -1))
show(lambda: io.BufferedReader(raw, 0))
show(lambda: io.BufferedReader(raw, None))
show(lambda: io.BufferedReader(raw, 1, 2))
show(lambda: io.BufferedReader(raw, no=1))
show(lambda: io.BufferedReader(raw, raw=raw))
with io.BufferedReader(raw, 2) as stream:
    show(lambda: stream.read(1, 2))
    show(lambda: stream.read(size=1))
    show(lambda: stream.readinto(b"x"))
    show(lambda: io.BufferedReader.read(stream, 0, 1))
    print("cursor", stream.tell(), raw.tell())
show(lambda: stream.read(1))
show(lambda: stream.readinto(bytearray(1)))
show(lambda: stream.read1(0))
write_only = io.FileIO("unread.bin", "w")
show(lambda: io.BufferedReader(write_only, 0))
print("write only raw retained", not write_only.closed)
write_only.close()
