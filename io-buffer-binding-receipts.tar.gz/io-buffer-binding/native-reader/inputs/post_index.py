import io

raw = io.FileIO("data.bin", "r")
reader = io.BufferedReader(raw, 4)
class Size:
    def __index__(self):
        def changed(destination):
            destination[0] = 122
            return 1
        raw.readinto = changed
        return 1
try:
    data = reader.read(Size())
except NotImplementedError as error:
    print("declined", str(error), raw.tell())
    assert raw.tell() == 0
else:
    assert data == b"z" and raw.tell() == 0
    print("callback", data, raw.tell())
reader.close()
