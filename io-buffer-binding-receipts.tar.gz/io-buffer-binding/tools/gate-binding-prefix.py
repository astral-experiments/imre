"""Validate the supplementary original reader fixture on the shared six-selector executable."""
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import types

CP = "5607950ef232dad16d75c0cf53101d9649d89115"
INTACT = "6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af"
PREVIOUS = "11466b8f5b50472e7275e6b2cba451f77dec66c962927b6a061236b739cf54e9"
PROOF = "141a038fd612e50ce240d3312c7f84249a6c4f228e9ac52045da9026200758b6"
CP_BINARY = "c27397da5541f67655be462e128ca3d3eb6e0a8eb0d39036896c9042529f4304"
RUNNERS = {
    "1fff3d036a69aa77a0015abc1ff78283761793eaaf3d280987cf4a5fb632f1d3": 600,
    "a6e92eb6903287d3dc90bc55589e59fc4b393987c466572efc316f6408567fa7": 1800,
}
MARKERS = [
    "ORIGINAL_FIXTURE test.test_io CBufferedReaderTest tp_public_private_identity",
    "ORIGINAL_FILE type_matches bound_ab unbound_cd",
    "ORIGINAL_FIXTURE_PASS test.test_io.CBufferedReaderTest zero_unittest_ids",
]
IDS = [f"test.test_io.{cls}.{method}" for cls in ("CMiscIOTest","PyMiscIOTest")
       for method in ("test_abc_inheritance","test_abc_inheritance_official","test_abcs")]


def check(ok, msg):
    if not ok:
        raise ValueError(msg)


def obj(p):
    return json.loads(p.read_bytes())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def sources(root, section):
    reader = section/"reader"
    official = (root/"cpython/Lib/test/test_io.py").read_bytes()
    old = (section/"generator/projected/test/test_io.py").read_bytes()
    measured = (reader/"module/test/test_io.py").read_bytes()
    proof_file = reader/"source-receipt.json"
    check(sha(official) == INTACT and sha(old) == PREVIOUS and sha(proof_file.read_bytes()) == PROOF,
          "unrecognized upstream source, prior projection, or prefix proof")
    proof = obj(proof_file)
    src = official.splitlines(keepends=True)
    prefix = b"".join(src[:1859])
    tail = b"".join(old.splitlines(keepends=True)[1859:])
    check(measured == prefix+tail and proof["prefix_lines"] == [1,1859] and len(prefix) == proof["prefix_bytes"]
          and sha(prefix) == proof["prefix_sha256"] and sha(tail) == proof["suffix_sha256"]
          and sha(measured) == proof["combined_sha256"], "measured source differs from the unchanged lines 1–1859 plus verified tail")
    files = {p.relative_to(reader/"module").as_posix():sha(p.read_bytes()) for p in (reader/"module").rglob("*.py")}
    check(files == proof["files"] and files["run.py"] == sha((reader/"run.py").read_bytes()),
          "wrong reader driver, fixture, or supporting module in the measured source tree")
    def definitions(data):
        return {c.co_name:c for c in compile(data, "test/test_io.py", "exec").co_consts if isinstance(c,types.CodeType)}
    original, actual, prior = map(definitions,(official, measured, old))
    for klass, info in proof["classes"].items():
        a,b = info["lines"]
        check(info["sha256"] == sha(b"".join(src[a-1:b])) and original[klass] == actual[klass],
              f"reader fixture class differs from upstream: {klass}")
    for name in ("load_tests","CMiscIOTest","PyMiscIOTest","MiscIOTest"):
        check(prior[name] == actual[name], f"grouped-suite class or hook differs from the verified projection: {name}")
    return proof


def streams(section, d, stem, proc, argv, cwd, timeout):
    check(proc["argv"] == argv and proc["cwd"] == cwd and datetime.fromisoformat(proc["utc_start"]).utcoffset() is not None,
          f"incorrect process invocation at {d}/{stem}")
    elapsed, code = proc["elapsed_s"], proc["exit"]
    check(type(elapsed) in (float,int) and math.isfinite(elapsed) and elapsed >= 0 and
          (type(code) is int or code is None and elapsed >= timeout), f"invalid exit/timeout at {d}/{stem}")
    text = []
    for ext in ("stdout","stderr"):
        p = d/(stem+"."+ext)
        check(proc[ext] == p.relative_to(section).as_posix(), f"mixed process streams at {p}")
        text.append(p.read_bytes().decode(errors="replace"))
    return text


def paired_lane(section, label, key, prov, reference=False):
    mode, opt = key.split("-O")
    base = section/"runs"/label
    d = base/"reader-prefix"/key
    g = base/("combined-misc" if reference else "misc-group")/key
    rec,group = obj(d/"receipt.json"),obj(g/"receipt.json")
    for r,kind in ((rec,"reader-prefix"),(group,"misc-group")):
        check(r["kind"] == kind and r["mode"] == mode and r["opt"] == int(opt)
              and r["imre_commit"] == prov["imre_commit"], f"incorrect paired stage or lane at {d}")
    check(rec["unittest_ids"] == [] and group["process_scope"] == "one shared original suite" and
          [c["selector"] for c in group["cases"]] == IDS, f"wrong method attribution at {d}")
    proc = rec["process"]
    suite = group["cases"][0]["process"]
    check(all(c["process"] == suite and c["local_occurrence"] == prov["canonical_local_occurrences_1based"][c["selector"]]
              for c in group["cases"]), f"different grouped suite processes at {d}")
    build = rec["build"]
    binary = rec["exe_sha256"]
    check(build == group["build"] and binary == group["exe_sha256"], f"reader and grouped builds differ at {d}")
    entry = prov["inputs"]["misc_group_driver"]["file"]
    module = str(Path(entry).parent)
    timeout = RUNNERS[prov["inputs"]["matrix_runner"]["sha256"]]
    check(Path(entry).parts[-4:] == ("focused","reader","module","run.py"), f"unexpected combined driver at {d}")
    if reference:
        check(build is None and binary is None and proc is not None and suite is not None, "incomplete CPython paired control")
        cwd = proc["cwd"]
        start = [prov["reference_binary"], "-I","-B","-c",
                 'import runpy,sys; sys.path.insert(0,sys.argv.pop(1)); runpy.run_path(sys.argv.pop(1),run_name="__main__")',
                 module,entry]
    else:
        bindir = Path(prov["bindir"])
        cwd = build["cwd"]
        exe = str(Path(cwd)/"suite")
        args = [str(bindir/"imre"), "build",entry,"--module-root",module,"--no-cache","--runtime",str(bindir/"libimre_runtime.a"),
                "--clang",prov["clang"],"--opt-level",opt,"-o",exe]
        if mode == "boxed":
            args.append("--runtime-imports")
        streams(section,g,"build",build,args,cwd,timeout)
        check((build["exit"] == 0) == (suite is not None) == (proc is not None), f"missing or stale paired process at {d}")
        if build["exit"] == 0:
            check(isinstance(binary,str) and re.fullmatch(r"[0-9a-f]{64}",binary), f"missing paired executable hash at {d}")
        else:
            check(binary is None and rec["verdict"] == "BUILD_ERROR" and all(c["verdict"] == "BUILD_ERROR" for c in group["cases"]),
                  f"spurious paired executable or verdict at {d}")
        start = [exe]
    check(Path(cwd).parts[-3:] == ("reader",label,key), f"incorrect paired cwd at {d}")
    if proc is None:
        check(not any((d/("fixture."+s)).exists() or (g/("selected-six."+s)).exists() for s in ("stdout","stderr")),
              f"stale paired process outputs after failed build at {d}")
        code = build["exit"]
        status = "BUILD_TIMEOUT" if code is None else f"BUILD_SIGNAL_{-code}" if code < 0 else "BUILD_ERROR"
        return dict(status=status, fixture_process_started=False, grouped_process_started=False, unittest_ids=[],
                    build_exit=code, executable_sha256=None)
    out, err = streams(section,d,"fixture",proc,[*start,"--reader-fixture"],cwd,timeout)
    grouped_out, grouped_err = streams(section,g,"selected-six",suite,[*start,*IDS],cwd,timeout)
    check(not any(l.startswith(("IMRE_CASE_", "IMRE_GROUP_", "IMRE_IO_ID ", "Ran ")) for l in out.splitlines()) and
          not any(l.startswith("ORIGINAL_FIXTURE") for l in grouped_out.splitlines()),
          f"fixture and grouped process outcomes intermingled at {d}")
    code = proc["exit"]
    if code == 0 and out.splitlines() == MARKERS:
        verdict = "PASS"
    elif not out and "line 1804" in err and "BufferedReader" in err:
        verdict = "UNREACHED"
    else:
        verdict = "ERROR"
    check(rec["verdict"] == verdict, f"unverified reader fixture verdict at {d}")
    if reference:
        text = grouped_out.splitlines()
        check(verdict == "PASS" and not err and suite["exit"] == 0 and not grouped_err
              and [l for l in text if l.startswith("IMRE_GROUP_SELECTED ")] == ["IMRE_GROUP_SELECTED "+i for i in IDS]
              and [l for l in text if l.startswith("IMRE_GROUP_VERDICT ")] == ["IMRE_GROUP_VERDICT "+i+" PASS" for i in IDS]
              and all(c["verdict"] == "PASS" and c["selector"].split(".")[-1]+" ("+c["selector"]+") ... ok" in text
                      for c in group["cases"]) and len(re.findall(r"(?m)^Ran 6 tests in ",grouped_out)) == 1 and text.count("OK") == 1,
              "unverified CPython prefix/combined-six references")
    status = "TIMEOUT" if code is None else f"SIGNAL_{-code}" if code < 0 else verdict
    return dict(status=status, fixture_process_started=True, grouped_process_started=True, unittest_ids=[],
                build_exit=build["exit"] if build else None, executable_sha256=binary, fixture_exit=code,
                grouped_process_exit=suite["exit"], fixture_markers=out.splitlines(), last_stderr=err.splitlines()[-2:])


def validate_reader_prefix(root, label, commit):
    check(re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*",label) and re.fullmatch(r"[0-9a-f]{40}",commit),"invalid reader stage")
    root=Path(root)
    section=root/"focused"
    proof=sources(root,section)
    cp=obj(section/"runs/cpython/provenance-reader-prefix.json")
    base=section/"runs"/label
    prov=obj(base/"provenance-reader-prefix.json")
    check(cp["imre_commit"] is None and cp["bindir"] is None and prov["imre_commit"] == commit and
          obj(base/"provenance.json") == prov, "reader and grouped native provenance differ")
    for k in ("cpython_commit","reference_binary","reference_binary_sha256","canonical_local_occurrences_1based"):
        check(cp[k] == prov[k],f"native reader source differs from CPython reference: {k}")
    check(prov["cpython_commit"] == CP and prov["reference_binary_sha256"] == CP_BINARY and
          prov["canonical_local_occurrences_1based"] == dict(zip(IDS,[603,604,605,626,627,628])), "wrong CPython reader reference")
    inputs=prov["inputs"]
    check(cp["inputs"].keys() == inputs.keys() and all(inputs[k] == cp["inputs"][k] for k in inputs if k != "matrix_runner")
          and cp["inputs"]["matrix_runner"]["sha256"] == sha((section/"reader/measure.py").read_bytes())
          == "1fff3d036a69aa77a0015abc1ff78283761793eaaf3d280987cf4a5fb632f1d3", "combined reader input or CPython runner mismatch")
    for k,desc in inputs.items():
        if k in ("official_test_io","official_pyio"):
            p = root/"cpython/Lib"/("test/test_io.py" if k=="official_test_io" else "_pyio.py")
        else:
            _, sep, rel=desc["file"].rpartition("/focused/")
            check(sep and rel and not Path(rel).is_absolute() and ".." not in Path(rel).parts,"invalid reader source path")
            p=section/rel
        check(sha(p.read_bytes())==desc["sha256"], f"reader source/harness differs from provenance: {k}")
    check(inputs["projected_test_io"]["sha256"] == proof["combined_sha256"] and
          inputs["source_receipt"]["sha256"] == PROOF and inputs["misc_group_driver"]["sha256"] == proof["files"]["run.py"] and
          inputs["matrix_runner"]["sha256"] in RUNNERS,
          "wrong combined grouped/reader inputs")
    compiler,runtime=prov["compiler_sha256"],prov["runtime_sha256"]
    freezes=[obj(p) for p in (root/"build").glob("*-binary-provenance.json")]
    check(any(p["commit"]==commit and p["artifacts"]["imre"]["sha256"]==compiler and
              p["artifacts"]["libimre_runtime.a"]["sha256"]==runtime for p in freezes),"reader compiler/runtime differ from frozen revision")
    oracle=paired_lane(section,"cpython","cpython-O0",cp,reference=True)
    lanes={f"{m}.O{o}":paired_lane(section,label,f"{m}-O{o}",prov) for m in ("ordinary","boxed") for o in (0,3)}
    return dict(scope="Supplementary unchanged original reader fixture; zero additional unittest IDs.",
                label=label, commit=commit, compiler_sha256=compiler, runtime_sha256=runtime, unittest_ids=[],
                prefix_lines=proof["prefix_lines"], prefix_bytes=proof["prefix_bytes"], prefix_sha256=proof["prefix_sha256"],
                combined_module_sha256=proof["combined_sha256"], cpython=oracle, lanes=lanes)
