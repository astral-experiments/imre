"""Build and verify the final Imre I/O registration receipts archive."""
import argparse
import csv
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path("/workspace/shared/downloads/io-register")
ROOT_FILES = ("RESULTS.md", "initial-checkpoint.sha256")
DIRECTORIES = ("bisect", "build", "discovery", "dispatch", "dispatch-review", "focused",
               "module-lookup", "ordinary", "probes", "patches")
SUFFIXES = {".md", ".py", ".json", ".tsv", ".out", ".log", ".stdout", ".stderr",
            ".exit", ".sh", ".xml", ".ids", ".patch", ".sha", ".sha256", ".txt", ".command", ".c"}
SPECIAL_FILES = {"LICENSE", "LICENSE.cpython", "SHA256SUMS"}
TEMP_NAME = re.compile(r"(?:^|[._-])(?:tmp|temp|partial|backup)(?:[._-]|$)", re.I)
PINNED_HASHES = {
    "test/test_io.py": "6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af",
    "_pyio.py": "1beee84c68ef6f7acb649dd5aada4c2f34f0476b01c293efe4afd9d0fe2d3ff1",
    "_py_abc.py": "f9c6fe3dd9b51bd7d93f867356e9d362600c924febfd903ee1c6e298860dca92",
    "abc.py": "e558702a95cdce3febd289da021715d2b92bc43995b8a1bc58dfa1c3d8010287",
    "io.py": "1b75584d4efcc612dc0db2ae98619408276585a106f0544879edb5e25b55430a",
    "unittest/__init__.py": "2698f2daf7a02609a6825b89cd459ebaa283dec2403c7b846315a0701bc74a0d",
    "test/support/__init__.py": "ab77f9f5d2a4cd07f21550980fc84a224553a8d7c7ffdda409ebd7f3ee1941c4",
    "test/support/os_helper.py": "ffd61626a8353c9446ea44a9faa3e46e8c0bd75fce0d6d2647dd2bae02ee0c78",
    "test/support/threading_helper.py": "93976321a0592dda85d769089d443f7ce6f0742911852d3d875de5f03a8d7471",
}
CPYTHON_LICENSE = "b0e25a78cffb43f4d92de8b61ccfa1f1f98ecbc22330b54b5251e7b6ba010231"
LANES = ("ordinary.O0", "ordinary.O3", "boxed.O0", "boxed.O3")
ORACLE = "e82addd026e03cd24b66534764472806847401dcffaaa392bab2081fb70cdab4"
SECRET_NAME = re.compile(r"(?:^|[.\-_])(?:credentials?|secrets?|tokens?|passwords?|auth|private[-_]?key|id_rsa|id_ed25519)(?:[.\-_]|$)", re.I)
SECRET_CONTENT = re.compile(rb"-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----|\b(?:gh[pousr]_[A-Za-z0-9]{24,}|(?:AKIA|ASIA)[A-Z0-9]{16}|github_pat_[A-Za-z0-9_]{35,}|xox[baprs]-[A-Za-z0-9-]{20,}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}|Bearer [A-Za-z0-9_.~-]{24,})")


ASSIGNED_CREDENTIAL = re.compile(rb"""(?ix) (?:password|passwd|client_secret|api[_-]?key|access[_-]?token|refresh[_-]?token|aws_secret_access_key) ["']? \s* [=:] \s* ["']? (?!\$) [A-Za-z0-9_/.+=:-]{20,} """)


def require(test, message):
    if not test:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def payload(root, additional_dirs):
    files = {}

    def collect(path):
        rel = path.relative_to(root).as_posix()
        mode = path.lstat().st_mode
        if (path.name.startswith(".") or path.name.lower() in {"__pycache__", "tmp", "temp", "target", "cache", "node_modules"} or SECRET_NAME.search(path.name)
                or TEMP_NAME.search(path.name) or path.name.endswith("~") or stat.S_ISLNK(mode)):
            return
        require(re.fullmatch(r"[A-Za-z0-9_ .+@/-]+", rel), f"unsafe receipt path: {rel}")
        if stat.S_ISDIR(mode):
            for child in path.iterdir():
                if not child.name.startswith("."):
                    collect(child)
        elif stat.S_ISREG(mode):
            if path.suffix not in SUFFIXES and path.name not in SPECIAL_FILES:
                return
            data = path.read_bytes()
            if (b"\x00" in data or data.startswith((b"\x7fELF", b"MZ"))
                    or data.startswith(b"#!") and path.suffix not in {".py", ".sh"}):
                return
            if mode & 0o111 and path.suffix not in {".py", ".sh"}:
                return
            try:
                data.decode("utf-8")
            except UnicodeDecodeError:
                return
            require(not (SECRET_CONTENT.search(data) or ASSIGNED_CREDENTIAL.search(data)), f"credential-shaped material in {rel}")
            files[rel] = data

    require(root.is_dir() and not root.is_symlink(), "receipt root must be a physical directory")
    for name in ROOT_FILES:
        require((root / name).is_file(), f"missing public file: {name}")
        collect(root / name)
        require(name in files, f"missing public file: {name}")
    for name in (*DIRECTORIES, *additional_dirs):
        target = root / name
        require(target.is_dir() and not target.is_symlink(), f"missing public directory: {name}")
        collect(target)
        require(any(k.startswith(name + "/") for k in files), f"empty public directory: {name}")
    for pattern in ("*.log", "*.patch", "*.md", "*.sha256", "*merge*.json", "executor.json", "pull-requests.json"):
        for path in root.glob(pattern):
            if stat.S_ISREG(path.lstat().st_mode):
                collect(path)
    revisions = json.loads(files["patches/revisions.json"])
    require(revisions, "missing patch revisions")
    for entry in revisions:
        name = entry["patch"]
        require(Path(name).name == name and name.endswith(".patch"), "invalid patch name in revisions")
        require(digest(files["patches/" + name]) == entry["sha256"], f"mismatched shareable patch: {name}")
    patch_manifest = files["patches/SHA256SUMS"]
    for entry in patch_manifest.decode().splitlines():
        checksum, name = entry.split("  ", 1)
        require(Path(name).name == name and digest(files["patches/" + name]) == checksum,
                f"mismatched patch bundle manifest: {name}")
    return files


def validate_lanes(files, label, commit):
    folder = f"native/{label}"
    oracle = files["oracle/regrtest-default/ordered.ids"]
    ids = oracle.decode().splitlines()
    require(digest(oracle) == ORACLE and len(ids) == len(set(ids)) == 667, "wrong canonical oracle")
    fixture = files["oracle/regrtest-default/fixtures.json"]
    require(digest(fixture) == "2aa31a95409b3e7810d3ccb62cff56efd4d24e4ddceea8a04c437cdef19335e9",
            "unexpected canonical CPython fixture metadata")
    canonical = json.loads(files["oracle/regrtest-default/ordered-cases.json"])
    require([case["id"] for case in canonical] == ids, "CPython case ledger differs from the canonical oracle")
    provenance = json.loads(files[f"{folder}/provenance.json"])
    require(provenance["imre_commit"] == commit and provenance["expected_ordered_ids_sha256"] == ORACLE,
            "requested final commit or canonical order differs from provenance")
    require(provenance["cpython_commit"] == "5607950ef232dad16d75c0cf53101d9649d89115" and
            provenance["source_sha256"]["test/test_io.py"] == "6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af",
            "unrecognized CPython pin or test_io source")
    ledger = csv.DictReader(io.StringIO(files[f"{folder}/denominator-ledger.tsv"].decode()), delimiter="\t")
    expected_fields = ["oracle_index", "occurrence", "id", "fixture_group", "cpython_regrtest", "cpython_skip_reason", *LANES]
    require(ledger.fieldnames == expected_fields, "wrong denominator ledger columns")
    records = list(ledger)
    require([r["id"] for r in records] == ids, "ledger IDs differ from the ordered 667 canonical IDs")
    require(all(r["oracle_index"] == str(i) and r["occurrence"] == "1" for i, r in enumerate(records, 1)),
            "wrong oracle index or occurrence in ledger")
    for row, ref in zip(records, canonical):
        require(row["fixture_group"] == str(ref["group"]) and row["cpython_regrtest"] == ref["reference_verdict"]
                and row["cpython_skip_reason"] == (ref.get("reference_reason") or ""),
                "CPython outcome or skip reason differs from case ledger")
    runs = json.loads(files[f"{folder}/runs.json"])
    summary = json.loads(files[f"{folder}/summary.json"])
    require(summary["imre_commit"] == commit, "summary commit mismatch")
    for rows in (runs, summary["runs"]):
        require(sorted(f'{r["mode"]}.O{r["level"]}' for r in rows) == sorted(LANES), "expected four intact runs")
    for result in runs:
        lane = f'{result["mode"]}.O{result["level"]}'
        directory = f"{folder}/{lane}"
        require(json.loads(files[f"{directory}/result.json"]) == result, f"combined result differs: {lane}")
        require(result["scope"] == "discovery", f"expected intact discovery: {lane}")
        args = result["build"]["argv"]
        require(args[args.index("--opt-level") + 1] == str(result["level"]) and
                ("--runtime-imports" in args) == (result["mode"] == "boxed"), f"wrong build flags: {lane}")
        observed = []
        for step in ("build", "process"):
            proc = result[step]
            if step == "process" and proc is None:
                require(result["build"]["exit"] != 0, f"successful build missing process: {lane}")
                continue
            require(isinstance(proc["elapsed_s"], (int, float)) and proc["elapsed_s"] >= 0
                    and proc["argv"] and isinstance(proc["argv"], list) and proc["cwd"]
                    and (isinstance(proc["exit"], int) or (proc["exit"] is None and proc["timed_out"])),
                    f"incomplete command, elapsed time, or exit status: {lane} {step}")
            for stream in ("stdout", "stderr"):
                path = f"{directory}/{step}.{stream}"
                require(proc[stream] == path and path in files, f"missing raw receipt: {path}")
            if step == "process":
                observed = [line.removeprefix("IMRE_IO_ID ") for line in files[proc["stdout"]].decode().splitlines()
                            if line.startswith("IMRE_IO_ID ")]
        require(len(observed) == result["observed_id_lines"], f"raw ID count mismatch: {lane}")
        seen = set(observed)
        for row in records:
            expected = "DISCOVERED_NO_VERDICT" if row["id"] in seen else "UNREACHED"
            require(row[lane] == expected, f"wrong {lane} state for {row['id']}")
        if observed:
            raw = ("\n".join(observed) + "\n").encode()
            require(files[f"{directory}/observed.ids"] == raw and digest(raw) == result["ordered_ids_sha256"],
                    f"observed IDs mismatch: {lane}")


def add_pinned_sources(files, cpython, label):
    official = json.loads(files[f"discovery/native/{label}/provenance.json"])["source_sha256"]
    for name, expected_hash in PINNED_HASHES.items():
        path = cpython / "Lib" / name
        require(path.is_file() and not path.is_symlink(), f"missing pinned source: {name}")
        data = path.read_bytes()
        require(digest(data) == expected_hash, f"source differs from 3.14.5: {name}")
        if name in official:
            require(digest(data) == official[name], f"source differs from final receipt: {name}")
        files[f"cpython/Lib/{name}"] = data
    license_data = (cpython / "LICENSE").read_bytes()
    require(digest(license_data) == CPYTHON_LICENSE, "unexpected CPython license")
    files["cpython/LICENSE"] = license_data


def add_snapshots(files, args):
    helper = Path(__file__).resolve().with_name("snapshot-io-register.py")
    require(helper.is_file() and not helper.is_symlink(), "snapshot helper must be next to the packager")
    files["tools/snapshot-io-register.py"] = helper.read_bytes()
    files["tools/package-io-register.py"] = Path(__file__).read_bytes()
    with tempfile.TemporaryDirectory(dir=args.output.absolute().parent, prefix=".register-snapshot-") as temp:
        temp = Path(temp)
        evidence = temp / "evidence"
        for name, data in files.items():
            if name.startswith(("focused/", "discovery/")):
                p = evidence / name
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(data)
        output = temp / "out"
        subprocess.run([sys.executable, helper, "--root", evidence, "--native-label", args.label,
                        "--focused-label", args.focused_label or args.label, "--commit", args.commit,
                        "--output", output, *(["--require-misc-group", "--require-ctypes", "--require-api-imports"] if args.label.startswith("merged-") else [])], check=True)
        for name in ("canonical-667.tsv", "selector-attempts.tsv", "summary.json", "README.md"):
            path = output / name
            require(path.is_file() and not path.is_symlink(), f"missing derived snapshot: {name}")
            data = path.read_bytes()
            require(not SECRET_CONTENT.search(data), f"credential-shaped material in derived {name}")
            files[f"snapshots/{name}"] = data
        attempts = csv.DictReader(io.StringIO(files["snapshots/selector-attempts.tsv"].decode()), delimiter="\t")
        require({attempt["lane"] for attempt in attempts} == set(LANES),
                "missing canonical selector receipts for one or more final lanes")


def write_archive(path, files):
    with path.open("wb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.GNU_FORMAT) as archive:
            for name in sorted(files):
                data = files[name]
                info = tarfile.TarInfo(f"io-register/{name}")
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))


def verify_archive(path, files):
    with tarfile.open(path, "r:gz") as archive:
        names = sorted(files)
        require(archive.getnames() == [f"io-register/{name}" for name in names], "archive member mismatch")
        manifest = archive.extractfile("io-register/SHA256SUMS").read()
        require(manifest == files["SHA256SUMS"], "manifest mismatch")
        expected = {}
        for line in manifest.decode().splitlines():
            checksum, name = line.split("  ", 1)
            expected[name] = checksum
        require(set(expected) == set(files) - {"SHA256SUMS"}, "incomplete manifest")
        for member in archive.getmembers():
            require(member.isreg() and member.mtime == member.uid == member.gid == 0 and member.mode == 0o644,
                    f"unexpected archive metadata: {member.name}")
            name = member.name.removeprefix("io-register/")
            if name != "SHA256SUMS":
                source = archive.extractfile(member)
                require(hashlib.file_digest(source, "sha256").hexdigest() == expected[name], f"archive hash mismatch: {name}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("label", help="final native receipt label, e.g. merged-abcdef0")
    parser.add_argument("commit", help="full public merge SHA for the supplied label")
    parser.add_argument("--focused-label", help="focused/runs label for the same public commit; defaults to the discovery label")
    parser.add_argument("--include-dir", action="append", default=[], help="explicitly whitelist an additional receipt folder")
    parser.add_argument("--cpython", type=Path, default=Path("/workspace/scratch/cpython"))
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=ROOT.parent / "io-register-receipts.tar.gz")
    args = parser.parse_args()
    require(re.fullmatch(r"[A-Za-z0-9_-]+", args.label) and re.fullmatch(r"[0-9a-f]{40}", args.commit), "invalid label or commit")
    dest = args.output.absolute()
    require(not dest.resolve().is_relative_to(args.root.resolve()), "place output outside the evidence directory")
    require(not args.focused_label or re.fullmatch(r"[A-Za-z0-9_-]+", args.focused_label), "invalid focused label")
    require(all(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", name)
                and not SECRET_NAME.search(name) for name in args.include_dir), "invalid additional directory")
    files = payload(args.root, args.include_dir)
    require(args.commit.encode() in files["RESULTS.md"], "RESULTS.md must include the full requested commit SHA")
    discovery = {name.removeprefix("discovery/"): data for name, data in files.items() if name.startswith("discovery/")}
    validate_lanes(discovery, args.label, args.commit)
    add_pinned_sources(files, args.cpython, args.label)
    add_snapshots(files, args)
    files["SHA256SUMS"] = "".join(f"{digest(files[n])}  {n}\n" for n in sorted(files)).encode()
    with tempfile.NamedTemporaryFile(dir=dest.parent, prefix=".io-register-", suffix=".tmp", delete=False) as stream:
        tmp = Path(stream.name)
    try:
        write_archive(tmp, files)
        verify_archive(tmp, files)
        os.replace(tmp, dest)
    finally:
        tmp.unlink(missing_ok=True)
    print(f"{digest(dest.read_bytes())}  {dest} ({len(files)} files, {dest.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
