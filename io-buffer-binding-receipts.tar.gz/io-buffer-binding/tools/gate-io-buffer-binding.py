"""Check native/control/CPython provenance and execution scope before release signing."""
import hashlib
import json
import re
import runpy
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

LANES = ("ordinary.O0", "ordinary.O3", "boxed.O0", "boxed.O3")
CONTROLS = ("fixture", "named", "file", "receiver")
BASE = "922b21506bf57f399cf2356f9803906b1f0d55a4"
CPY = "5607950ef232dad16d75c0cf53101d9649d89115"
WIDER = "a36ef3e564b1fc39d7a3d145f47e76faed1dfc96550e8a4b83830d0c8bef8507"


def req(ok, msg):
    if not ok:
        raise ValueError(msg)


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def obj(p):
    return json.loads(p.read_bytes())


def wider(root):
    p = root / "discovery/wider/oracle"
    s, cases = obj(p/"summary.json"), obj(p/"ordered-cases.json")
    ids = (p/"ordered.ids").read_bytes()
    req(sha(ids) == WIDER == s["ordered_ids_sha256"] and s["cpython_commit"] == CPY and
        [c["id"] for c in cases] == ids.decode().splitlines() and len(set(ids.splitlines())) == len(cases) == 1038,
        "incorrect ordered 1,038-ID CPython inventory")
    xml = list(ET.parse(p/"regrtest.xml").iter("testcase"))
    req(len(xml) == 1038 and obj(p/"regrtest-run.json")["exit"] == 0, "invalid wider reference process")
    for ix,(item,c) in enumerate(zip(xml,cases),1):
        req(c["id"] == item.get("name") and c["index"] == ix and c["occurrence"] == 1 and
            c["id"].startswith(c["module"]+".") and item.find("error") is None and item.find("failure") is None
            and c["reference_verdict"] == ("SKIP" if item.find("skipped") is not None else "PASS"),
            f"wider XML disagreement at occurrence {ix}")
    counts = Counter(c["module"] for c in cases)
    req(counts == {name:meta["count"] for name,meta in s["modules"].items()} and len(counts)==7 and
        Counter(c["reference_verdict"] for c in cases)==s["reference_verdicts"]=={"PASS":1009,"SKIP":29},
        "inconsistent wider counts")
    for name,entry in s["modules"].items():
        rows = [c["id"] for c in cases if c["module"] == name]
        req(sha(("\n".join(rows)+"\n").encode()) == entry["ordered_ids_sha256"], f"wider ID hash mismatch: {name}")
    return dict(scope="CPython default-resource reference", count=1038, modules=counts, verdicts=s["reference_verdicts"], ordered_ids_sha256=WIDER)


def control(root, dirname, sha1, mode, section_name="ordinary", minimum=CONTROLS, levels=(0,3)):
    section = root/section_name
    folder = section / dirname
    prov = obj(folder/"provenance.json")
    req(prov["sha"] == sha1, f"wrong control commit: {folder}")
    details = {}
    req(set(minimum)<=prov["inputs"].keys(), f"missing primary file identity controls: {folder}")
    for name in prov["inputs"]:
        req(re.fullmatch(r"[a-z0-9_]+",name), "invalid control name")
        req(sha((section/"inputs"/(name+".py")).read_bytes()) == prov["inputs"][name], f"wrong control input: {name}")
        for lvl in levels:
            lane = f"{mode}.O{lvl}"
            field = f"{name}.{lane}"
            dest = folder / field
            rec = obj(dest/"receipt.json")
            build, proc = rec["build"], rec["process"]
            args = build["argv"]
            req(rec["oracle"]["exit"] == 0 and (build["exit"]==0)==(proc is not None) and
                args[args.index("--opt-level")+1] == str(lvl) and ("--runtime-imports" in args) == (mode=="boxed")
                and "--no-cache" in args and Path(args[2]).name == name+".py", f"incorrect control command: {field}")
            for step in ("oracle","build","process"):
                if rec[step] is None:
                    continue
                step_rec=rec[step]
                req(step_rec["argv"] and step_rec["cwd"] and step_rec["elapsed_s"]>=0 and "exit" in step_rec,
                    f"missing process metadata: {dest}/{step}")
                for key in ("stdout","stderr"):
                    req((dest/f"{step}.{key}").is_file(),f"missing raw control output: {dest}/{step}.{key}")
            match = proc is not None and proc["exit"]==0 and all((dest/f"process.{ext}").read_bytes()==
                    (dest/f"oracle.{ext}").read_bytes() for ext in ("stdout","stderr"))
            req(rec.get("matches_cpython",False)==match, f"unverified CPython control result: {dest}")
            if proc:
                req(proc["argv"] == [args[args.index("-o")+1]], f"different control executable: {dest}")
            details[field] = dict(build_exit=build["exit"], process_exit=proc["exit"] if proc else None,
                                  process_started=proc is not None, matches_cpython=match, boxed_ir=rec.get("boxed_ir"))
    return details, (prov["compiler"],prov["runtime"])


def six(root, label, sha1, snap):
    folder = root/"focused"/"runs"/label
    prov = obj(folder/"provenance.json")
    ids = snap["MISC_IDS"]
    req(prov["imre_commit"] == sha1 and prov["cpython_commit"] == CPY and
        prov["canonical_local_occurrences_1based"] == dict(zip(ids,[603,604,605,626,627,628])), "wrong six-case source or occurrences")
    inputs=prov["inputs"]
    req({"official_test_io","official_pyio","projected_test_io","projected_pyio","generator","source_receipt",
         "ordered_ids","misc_group_driver","reference_receivers","matrix_runner"}<=inputs.keys(), "incomplete focused source provenance")
    for name,desc in inputs.items():
        if name in {"official_test_io", "official_pyio"}:
            req(desc["sha256"]==(snap["SOURCE"] if name=="official_test_io" else snap["PYIO"]), "incorrect official IO source")
        else:
            _,partition,tail = desc["file"].rpartition("/focused/")
            req(partition and tail and not Path(tail).is_absolute() and ".." not in Path(tail).parts, "invalid focused input path")
            req(sha((root/"focused"/tail).read_bytes())==desc["sha256"], f"different focused input: {name}")
    result = {}
    for lane in LANES:
        dest=folder/"misc-group"/lane.replace(".","-")
        path=dest/"receipt.json"
        rec=obj(path)
        req(rec["imre_commit"]==sha1 and rec["kind"]=="misc-group" and f'{rec["mode"]}.O{rec["opt"]}'==lane,
            f"incorrect focused lane or head: {path}")
        args=rec["build"]["argv"]
        req(args[0]==str(Path(prov["bindir"])/"imre") and args[2]==inputs["misc_group_driver"]["file"] and
            args[args.index("--runtime")+1]==str(Path(prov["bindir"])/"libimre_runtime.a"),"incorrect focused build target or binaries")
        snap["check_build"](rec["build"],lane)
        snap["read_streams"](root/"focused",dest,"build",rec["build"])
        req(all(c["local_occurrence"]==prov["canonical_local_occurrences_1based"][c["selector"]] for c in rec["cases"]),
            f"incorrect focused selector ordinal: {path}")
        shared, outcomes = snap["grouped_suite"](root/"focused",path,rec)
        result[lane]=dict(build_exit=rec["build"]["exit"],shared=shared,case_outcomes=outcomes)
    return result,(prov["compiler_sha256"],prov["runtime_sha256"])


def validate(root, files, plan):
    prior = runpy.run_path(str(root/"tools/package-io-register.py"))
    snap = runpy.run_path(str(root/"tools/binding-evidence-utils.py"))
    report = {"wider_reference": wider(root), "revisions": {}}
    outcome = plan["outcome"]
    req(plan["base"]==BASE and outcome in ("merged","unmerged","qa"), "unrecognized final scope or baseline")
    note = b"\n".join(files[path] for path in plan["handoff"])
    req(all(plan[k].encode() in note for k in ("base","tested_head","public_head")),
        "handoff must identify public, baseline and tested revisions")
    if outcome == "unmerged":
        req(plan.get("public_pr") is None and plan["public_head"]==plan["base"],
            "unmerged release must distinguish the measured baseline and private tested head")
        stages = (("base",BASE),("tested",plan["tested_head"]))
    else:
        req(re.fullmatch(r"https://github\.com/astral-experiments/imre/pull/[0-9]+",plan["public_pr"])
            and plan["public_pr"].encode() in note, "missing public pull request in handoff")
        stages = (("base",BASE),("tested",plan["tested_head"]),("public",plan["public_head"]))
    report["release_outcome"]=outcome
    manifests = {"ordinary/BASELINE.sha256": "48ccc0fbb340c9ab3e283b9ba33e3bf8b0a5d6a3213a83f68df6fb30c4f24d68",
                 **plan.get("manifests", {})}
    report["checked_manifests"] = {}
    for name, checksum in manifests.items():
        raw = files[name]
        req(sha(raw)==checksum, f"incorrect source manifest: {name}")
        entries = set()
        for line in raw.decode().splitlines():
            value, entry = line.split("  ",1)
            req(entry not in entries and not Path(entry).is_absolute() and ".." not in Path(entry).parts
                and sha(files[str(Path(name).parent/entry)])==value,f"invalid source manifest entry: {name} {entry}")
            entries.add(entry)
        req(entries,f"empty source manifest: {name}")
        report["checked_manifests"][name] = dict(entries=len(entries),sha256=checksum)
    patches = plan["patches"]
    req(patches and any(files[path] for path in patches) and all(path.endswith(".patch") and sha(files[path])==checksum
                        for path,checksum in patches.items()),"missing or mismatched compact patch")
    if outcome != "qa":
        for phase, head in (("tested",plan["tested_head"]),("public",plan["public_head"])):
            if phase=="public" and outcome=="unmerged":
                continue
            proof=obj(root/"patches"/f"{phase}-{head[:7]}.json")
            name="patches/"+proof["patch"]
            req(proof["commit"]==head and proof["phase"]==phase and len(proof["parents"])>=1 and
                proof["tree"]==proof["replayed_tree"] and proof["sha256"]==patches[name] and
                proof["bytes"]==len(files[name]) and proof.get("empty_delta",proof.get("empty_first_parent"))==(not bool(files[name])),
                f"incorrect replay proof for {phase} patch")
            if phase=="tested":
                req(proof.get("delta_base",proof["parents"][0])==plan["pr_base"], "tested patch must span entire PR")
            if phase=="public":
                req(proof.get("delta_base",proof["parents"][0])==proof["parents"][0], "incorrect public first-parent delta")
                req(proof["tested_head"]==plan["tested_head"],"wrong tested head in public patch metadata")
    revisions = plan["revisions"]
    req(set(revisions)=={k for k, _ in stages},"missing required revision coverage")
    discovery={n.removeprefix("discovery/"):blob for n,blob in files.items() if n.startswith("discovery/")}
    canonical = snap["read_oracle"](root)
    interim=plan.get("intermediates", {})
    req(not set(interim).intersection(revisions), "overlapping intermediate and final stage names")
    report["intermediate_revisions"] = {}
    for stage, expected in (*stages, *((key, val["commit"]) for key, val in interim.items())):
        terminal = stage == stages[-1][0]
        r=(revisions if stage in revisions else interim)[stage];out={"commit":expected};bins=set()
        for lane in (LANES if stage in revisions or "controls" in r or "control_prefix" in r else ()):

            mode, opt = lane.split(".O")
            dirname = r["controls"][lane] if "controls" in r else r["control_prefix"]+"-"+mode
            primary = CONTROLS if stage == "base" or stage in interim or outcome == "qa" else (
                "guarded_fixture","file","guarded_checks","module_open","index_refusal")
            if stage in {"tested","public"} and outcome != "qa" and mode == "ordinary":
                primary = (*primary, "fixed_open")
            rows,pair=control(root,dirname,expected,mode,minimum=primary,levels=(int(opt),))
            out.setdefault(mode+"_controls", {}).update(rows)
            bins.add(pair)
        if stage in ("base","tested","public") or r.get("focused"):
            out["selected_six"],pair=six(root,r["focused"],expected,snap)
            bins.add(pair)
            constructor_gate=runpy.run_path(str(root/"tools/gate-binding-constructor.py"))
            cr=constructor_gate["validate_constructors"](root,r.get("constructors",r["focused"]),expected)
            out["supplementary_constructor_controls"]=cr
            bins.add((cr["compiler_sha256"],cr["runtime_sha256"]))
            if stage in {"tested","public"} and outcome != "qa":
                prefix_gate=runpy.run_path(str(root/"tools/gate-binding-prefix.py"))
                pr=prefix_gate["validate_reader_prefix"](root,r["focused"],expected)
                out["original_reader_prefix_control"]=pr
                bins.add((pr["compiler_sha256"],pr["runtime_sha256"]))
        if stage=="base" or terminal or r.get("discovery"):
            label=r["discovery"]
            prior["validate_lanes"](discovery,label,expected)
            d=root/"discovery"/"native"/label
            prov=obj(d/"provenance.json");bins.add((prov["compiler_sha256"],prov["runtime_sha256"]))
            _,lanes,_=snap["discovery"](root,label,expected,canonical)
            for line in obj(d/"summary.json")["runs"]:
                lane = f'{line["mode"]}.O{line["level"]}'
                real = lanes[lane]
                rec = obj(d/lane/"result.json")
                proc = rec["process"]
                req(line["build_exit"]==real["build_exit"] and line["process_exit"]==real["process_exit"]
                    and line["build_s"]==rec["build"]["elapsed_s"] and line["process_s"]==(proc and proc["elapsed_s"])
                    and line["raw_record"]==f"native/{label}/{lane}/result.json" and line["expected_occurrences"]==667
                    and line["discovered_expected_occurrences"]==real["canonical_ids_seen"]
                    and line["native_unittest_executions"]==0 and line["ordered_ids_match"]==real["discovery_complete"],
                    f"intact discovery summary disagrees with raw receipt: {label}/{lane}")
            out["intact_667"]=lanes

        if stage=="base" or terminal or r.get("wider"):
            wider_gate=runpy.run_path(str(root/"tools/gate-binding-wider.py"))
            label = r["wider"]
            wr=wider_gate["validate_wider_registration"](root,label,expected)
            out["registration_1038"]=wr
            bins.add((wr["compiler_sha256"],wr["runtime_sha256"]))
            supplemental = root/"discovery"/"wider"/"native"/label
            if (supplemental/"denominator-ledger.tsv").is_file():
                out["supplementary_wider_execution"]=wider_gate["validate_wider_native"](root,label,expected)
            elif supplemental.is_dir():
                out["supplementary_wider_execution"] = wider_gate["validate_partial_wider_native"](root,label,expected)
        req(len(bins)==1 and all(re.fullmatch(r"[0-9a-f]{64}",h) for h in next(iter(bins))),
            f"inconsistent compiler or runtime provenance across {stage} lanes")
        binary_hashes=next(iter(bins))
        frozen=[obj(p) for p in (root/"build").glob("*-binary-provenance.json")]
        req(any(b["commit"]==expected and
                tuple(b["artifacts"][n]["sha256"] for n in ("imre","libimre_runtime.a"))==binary_hashes for b in frozen),
            f"no matching frozen compiler/runtime input manifest for {stage}")
        out["compiler_sha256"],out["runtime_sha256"]=binary_hashes
        report["revisions" if stage in revisions else "intermediate_revisions"][stage]=out
    report["supplementary_diagnostics"] = {}
    for spec in plan.get("diagnostics", []):
        section, label, head = spec["section"], spec["label"], spec["commit"]
        mode, levels = spec["mode"], spec["levels"]
        req(section in {"ordinary","native-reader"} and mode in {"ordinary","boxed"} and
            set(levels) in ({0},{3},{0,3}), "invalid supplementary measurement scope")
        rows,pair = control(root,label,head,mode,section_name=section,minimum=(),levels=levels)
        req(any(b["commit"]==head and tuple(b["artifacts"][n]["sha256"] for n in
                ("imre","libimre_runtime.a"))==pair for b in frozen), "unfrozen supplementary control binary")
        report["supplementary_diagnostics"][section+"/"+label] = dict(commit=head,scope="non-original controls",rows=rows)
    f=root/"focused"/"runs"/"cpython"
    req(obj(f/"provenance.json")["cpython_commit"]==CPY,"incorrect six-case CPython reference")
    for kind in ("intact","misc-group"):
        d=f/kind/"cpython-O0"
        receipt=obj(d/"receipt.json")
        ids=snap["MISC_IDS"];cases=receipt["cases"]
        req([c["selector"] for c in cases]==ids and all(c["verdict"]=="PASS" and c["process"]==cases[0]["process"] for c in cases)
            and cases[0]["process"]["exit"]==0,"incorrect CPython six-selector reference")
        out,err=snap["read_streams"](root/"focused",d,"selected-six",cases[0]["process"])
        req(out.splitlines().count("OK")==1 and re.search(r"(?m)^Ran 6 tests in ",out+err)
            and all(f"IMRE_GROUP_VERDICT {sel} PASS" in out.splitlines() for sel in ids),"missing CPython per-method verdicts")
    return report
