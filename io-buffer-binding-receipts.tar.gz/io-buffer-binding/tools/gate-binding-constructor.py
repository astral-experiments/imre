"""Verify supplementary BufferedReader ownership and raw-callback processes."""
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re


SOURCE = "e50b5b72c1778a84cf2b94cf45aa47b240592c65bf28ca59a0ecad79784fa352"
HARNESS = "850f9e7459ba5f1299bb185b1d0d274cb1794b91f0cc437a20c473142d19f29b"
INTERPRETER = "c27397da5541f67655be462e128ca3d3eb6e0a8eb0d39036896c9042529f4304"
CONTROLS = {
    "borrowed": ["BORROWED raw.closed=True reader.closed=True owner_read=a"],
    "readahead": ["POSITIONS 1 4", "READAHEAD single_refill"],
    "subclass_context": ["SUBCLASS_CONTEXT self_and_closed"],
    "raw_subclass": ["CALLBACK readinto invoked"],
    "raw_instance": ["CALLBACK instance readinto invoked"],
    "finalize": ["FINALIZED_RAW_CLOSED True"],
}


def check(ok, message):
    if not ok:
        raise ValueError(message)


def obj(p):
    return json.loads(p.read_bytes())


def streams(section, folder, name, record, argv, cwd):
    check(record["argv"] == argv and record["cwd"] == cwd and
          datetime.fromisoformat(record["utc_start"]).utcoffset() is not None,
          f"wrong command, working directory or timestamp at {folder}/{name}")
    duration, code = record["elapsed_s"], record["exit"]
    check(type(duration) in (float, int) and math.isfinite(duration) and duration >= 0
          and (type(code) is int or code is None and duration >= 360), f"invalid exit/timeout at {folder}/{name}")
    result = []
    for ext in ("stdout", "stderr"):
        path = folder/(name+"."+ext)
        check(record[ext] == path.relative_to(section).as_posix(), f"wrong stream path {path}")
        result.append(path.read_bytes().decode(errors="replace"))
    return result


def lane_results(section, label, mode, opt, prov):
    key = f"{mode}-O{opt}"
    folder = section/"runs"/label/key
    receipt = obj(folder/"receipt.json")
    check(receipt["mode"] == mode and receipt["opt"] == opt and receipt["imre_commit"] == prov["imre_commit"],
          f"mixed stage or lane at {folder}")
    rows, build = receipt["controls"], receipt["build"]
    check([r["control"] for r in rows] == list(CONTROLS), f"missing, duplicate or reordered controls at {folder}")
    native = mode != "cpython"
    check((build is not None) == native, f"unexpected build at {folder}")
    source = (build["argv"][2] if native else rows[0]["process"]["argv"][3])
    check(Path(source).is_absolute() and Path(source).parts[-3:] == ("focused","constructor","control.py"),
          f"incorrect control source at {folder}")
    cwd = (build or rows[0]["process"])["cwd"]
    check(Path(cwd).parts[-3:] == ("constructor",label,key), f"incorrect lane cwd at {folder}")
    start = [prov["cpython"], "-I", "-B", source]
    if native:
        bindir, exe = Path(prov["bindir"]), str(Path(cwd)/"probe")
        args = [str(bindir/"imre"), "build", source, "--no-cache", "--clang", "/workspace/scratch/tools/clang",
                "--runtime", str(bindir/"libimre_runtime.a"), "--opt-level", str(opt), "-o", exe]
        if mode == "boxed":
            args.append("--runtime-imports")
        streams(section, folder, "build", build, args, cwd)
        start = [exe]
    built = not native or build["exit"] == 0
    recorded_hash = receipt["exe_sha256"]
    check((isinstance(recorded_hash, str) and re.fullmatch(r"[0-9a-f]{64}", recorded_hash))
          if native and built else recorded_hash is None, f"wrong executable digest at {folder}")
    outcomes = {}
    for row in rows:
        name, proc = row["control"], row["process"]
        check((proc is not None) == built, f"missing or unexpected process for {folder}/{name}")
        if not proc:
            check(row["verdict"] == "BUILD_ERROR" and
                  not any((folder/(name+"."+s)).exists() for s in ("stdout","stderr")),
                  f"stale or misclassified attempted control {folder}/{name}")
            code = build["exit"]
            status = "BUILD_TIMEOUT" if code is None else f"BUILD_SIGNAL_{-code}" if code < 0 else "BUILD_ERROR"
            outcomes[name] = dict(status=status, process_started=False, process_exit=None)
            continue
        out, err = streams(section, folder, name, proc, start + [name], cwd)
        code = proc["exit"]
        selected, completed = "CONTROL_SELECTED "+name, "CONTROL_COMPLETED "+name
        observed = out.splitlines()
        check([line for line in observed if line.startswith("CONTROL_SELECTED ")] in ([], [selected]) and
              [line for line in observed if line.startswith("CONTROL_COMPLETED ")] in ([], [completed]),
              f"invalid control selection at {folder}/{name}")
        reason = None
        if code == 0 and completed in observed:
            if any(line.startswith("EXPLICIT_LIMIT ") for line in observed):
                check(native and name in ("raw_subclass","raw_instance") and len(observed) == 3 and
                      observed[0] == selected and observed[1].startswith("EXPLICIT_LIMIT ") and observed[2] == completed,
                      f"invalid explicit scope-limit transcript at {folder}/{name}")
                reason, recorded = observed[1][len("EXPLICIT_LIMIT "):], "EXPLICIT_SCOPE_LIMIT"
            else:
                check(observed == [selected, *CONTROLS[name], completed], f"missing CPython control observation at {folder}/{name}")
                recorded = "PASS"
        else:
            recorded = "FAIL" if "AssertionError" in err else "ERROR"
        check(row["verdict"] == recorded, f"unverified control verdict at {folder}/{name}")
        status = "TIMEOUT" if code is None else f"SIGNAL_{-code}" if code < 0 else recorded
        if not native:
            check(status == "PASS" and not err, f"CPython supplementary control failed at {folder}/{name}")
        outcomes[name] = dict(status=status, process_started=True, process_exit=code, timed_out=code is None,
                              elapsed_s=proc["elapsed_s"], scope_limit=reason, last_stderr=err.splitlines()[-1:])
    return dict(build_exit=build["exit"] if native else None, build_timed_out=native and build["exit"] is None,
                executable_sha256=recorded_hash, outcomes=outcomes)


def validate_constructors(root, label, commit):
    check(re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*", label) and re.fullmatch(r"[0-9a-f]{40}",commit),
          "invalid constructor revision")
    section = Path(root)/"focused/constructor"
    prov = obj(section/"runs"/label/"provenance.json")
    oracle = obj(section/"runs/cpython/provenance.json")
    check(prov["imre_commit"] == commit and oracle["imre_commit"] is None, "wrong supplementary stage or reference")
    for filename, pin, key in (("control.py",SOURCE,"source_sha256"), ("measure.py",HARNESS,"harness_sha256")):
        check(hashlib.sha256((section/filename).read_bytes()).hexdigest() == prov[key] == oracle[key] == pin,
              f"supplementary input mismatch: {filename}")
    check(prov["cpython_sha256"] == oracle["cpython_sha256"] == INTERPRETER and
          prov["cpython"] == oracle["cpython"] and Path(oracle["cpython"]).name == "python3.14",
          "wrong CPython 3.14.5 constructor reference")
    compiler, runtime = prov["compiler_sha256"], prov["runtime_sha256"]
    freezes = [obj(p) for p in (Path(root)/"build").glob("*-binary-provenance.json")]
    check(all(re.fullmatch(r"[0-9a-f]{64}", h) for h in (compiler,runtime)) and
          any(r["commit"] == commit and r["artifacts"]["imre"]["sha256"] == compiler and
              r["artifacts"]["libimre_runtime.a"]["sha256"] == runtime for r in freezes),
          "constructor compiler/runtime digests differ from frozen revision")
    reference = lane_results(section,"cpython","cpython",0,oracle)
    lanes = {f"{m}.O{o}":lane_results(section,label,m,o,prov) for m in ("ordinary","boxed") for o in (0,3)}
    return dict(label=label, commit=commit, compiler_sha256=compiler, runtime_sha256=runtime,
                source_sha256=SOURCE, harness_sha256=HARNESS, cpython_sha256=INTERPRETER,
                scope="Supplementary BufferedReader constructor controls; separate from original unittest IDs.",
                cpython=reference, lanes=lanes)
