"""Reconcile native I/O evidence for one measured revision with its 1,038-row ledger."""
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
import re

LANES = ("ordinary.O0", "ordinary.O3", "boxed.O0", "boxed.O3")
MODULES = ("test_fileio", "test_memoryio", "test_file", "test_univnewlines", "test_largefile", "test_bufio")
CPYTHON = "5607950ef232dad16d75c0cf53101d9649d89115"
ORDERED = "a36ef3e564b1fc39d7a3d145f47e76faed1dfc96550e8a4b83830d0c8bef8507"
DRIVER = "05e951d4599cc5b16a36f9917600efafe705978d590f2741f425fe6077fdd2a3"
VERDICTS = {"PASS", "SKIP", "FAIL", "ERROR"}
SCOPE = ("test_io runs unchanged discovery. Other six modules run their original suites through "
         "unittest.TestSuite.run after recording discovery. UNREACHED records no observed ID or verdict.")


def check(ok, message):
    if not ok:
        raise ValueError(message)


def obj(p):
    return json.loads(p.read_bytes())


def lines(p):
    return p.read_bytes().decode(errors="replace").splitlines()


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def tags(rows, marker):
    prefix = marker + " "
    return [s[len(prefix):] for s in rows if s.startswith(prefix)]


def process_record(record, path, intact=False, timeout=None):
    timed, code = record["timed_out"], record["exit"]
    check(type(timed) is bool and (type(code) is int or (intact and code is None))
          and (not intact or timed == (code is None)), f"inconsistent exit/timeout at {path}")
    duration = record["elapsed_s"]
    check(type(duration) in (int, float) and math.isfinite(duration) and duration >= 0
          and isinstance(record["argv"], list) and record["argv"]
          and isinstance(record["cwd"], str) and record["cwd"], f"incomplete command at {path}")
    if timed and timeout is not None:
        check(duration >= timeout, f"timeout recorded before the {timeout}s deadline at {path}")
    return dict(exit=code, timed_out=timed, elapsed_s=duration)


def intact_section(disc, label, lane, goals, allow_extra=False):
    folder = disc/"native"/label/lane
    receipt = folder/"result.json"
    rec = obj(receipt)
    mode, opt = lane.split(".O")
    check(rec["mode"] == mode and rec["level"] == int(opt) and rec["scope"] == "discovery"
          and rec["tests_run"] == 0, f"incorrect discovery scope at {receipt}")
    build, proc = rec["build"], rec["process"]
    process_record(build, receipt, intact=True)
    check((build["exit"] == 0) == (proc is not None), f"incorrect discovery process at {receipt}")
    observed = []
    if proc is not None:
        process_record(proc, receipt, intact=True)
        observed = tags(lines(folder/"process.stdout"), "IMRE_IO_ID")
    check(len(observed) == rec["observed_id_lines"] and (allow_extra or
          (len(observed) == len(set(observed)) and set(observed) <= set(goals))),
          f"invalid discovery IDs at {receipt}")
    observed_file = folder/"observed.ids"
    check((lines(observed_file) if observed_file.exists() else []) == observed, f"stale observed.ids at {receipt}")
    states = {ident:"UNREACHED" for ident in goals}
    states.update(dict.fromkeys(set(observed) & set(goals), "DISCOVERED_NO_VERDICT"))
    diag = lines(folder/("process.stderr" if proc else "build.stderr"))[-1:]
    summary = dict(expected=len(goals), discovered=len(observed), tests_run_reported=0,
                   events=dict(Counter(states.values())), fixture_events=[], build_exit=build["exit"],
                   process_exit=proc["exit"] if proc else None, last_diagnostic=diag,
                   raw_record=receipt.relative_to(disc).as_posix())
    return states, summary, rec


def native_module(folder, mod, goals, build, executable, disc):
    base = folder/mod
    rec = obj(base/"process.json")
    proc_info = process_record(rec, base, timeout=300)
    check(rec["argv"] == [executable, mod] and Path(rec["cwd"]) == Path(build["cwd"])/mod,
          f"wrong module command at {base}")
    out = lines(base/"process.stdout")
    diag = lines(base/"process.stderr")[-2:]
    observed = tags(out, "IMRE_WIDE_ID")
    check(lines(base/"observed.ids") == observed and len(observed) == len(set(observed))
          and set(observed) <= set(goals), f"incorrect or unknown discovered ID at {base}")
    states = dict.fromkeys(goals, "UNREACHED")
    states.update(dict.fromkeys(observed, "DISCOVERED_NO_VERDICT"))
    events, outsiders, counts = [], [], Counter()
    for event in tags(out, "IMRE_WIDE_VERDICT"):
        verdict, sep, ident = event.partition(" ")
        check(sep and verdict in VERDICTS and ident, f"invalid event at {base}: {event!r}")
        events.append([verdict, ident])
        if ident in states:
            check(states[ident] == "DISCOVERED_NO_VERDICT", f"duplicate or undiscovered outcome at {base}: {ident}")
            states[ident] = verdict
            counts[verdict] += 1
        else:
            outsiders.append([verdict, ident])
    discovered = tags(out, "IMRE_WIDE_DISCOVERED")
    ran = tags(out, "IMRE_WIDE_RAN")
    check(len(discovered) <= 1 and len(ran) <= 1
          and all(re.fullmatch(r"[0-9]+", x) for x in discovered + ran), f"invalid suite markers at {base}")
    # Early exits, signals and timeouts may follow genuine per-method events.
    tests_run = int(ran[0]) if ran else None
    skip_reasons = {}
    for ident, verdict in states.items():
        if verdict == "SKIP":
            prefix = f"IMRE_WIDE_DETAIL {ident} SkipTest "
            reasons = [s[len(prefix):] for s in out if s.startswith(prefix)]
            check(len(reasons) <= 1 and (reasons or not ran), f"unverified skip reason at {base}: {ident}")
            skip_reasons[ident] = reasons[0] if reasons else None
    summary = dict(module="test."+mod, expected=len(goals), discovered_count=len(observed),
                   discovery_matches_reference=observed == goals and discovered == [str(len(goals))],
                   reported_tests_run=tests_run, verified_native_events=dict(counts),
                   outside_expected_ids=[ident for _,ident in outsiders], process=rec, last_diagnostic=diag,
                   events=events)
    p = base/"summary.json"
    check(obj(p) == summary, f"module summary differs from raw streams at {base}")
    group = dict(expected=len(goals), discovered=len(observed), tests_run_reported=tests_run,
                 events=dict(Counter(states.values())), fixture_events=outsiders, build_exit=build["exit"],
                 process_exit=rec["exit"], last_diagnostic=diag, raw_record=p.relative_to(disc).as_posix())
    detail = dict(process=proc_info, reported_tests_run=tests_run, canonical_events=dict(counts),
                  outside_canonical_events=outsiders, skip_reasons=skip_reasons)
    return states, group, summary, detail


def execution_inputs(root, label, commit):
    check(re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*", label) and re.fullmatch(r"[0-9a-f]{40}", commit),
          "invalid native stage label or commit")
    disc = Path(root)/"discovery"
    wider = disc/"wider"
    folder = wider/"native"/label
    oracle = wider/"oracle"
    cases = obj(oracle/"ordered-cases.json")
    ids = [r["id"] for r in cases]
    check(len(ids) == len(set(ids)) == 1038 and digest(oracle/"ordered.ids") == ORDERED
          and lines(oracle/"ordered.ids") == ids, "invalid wider reference IDs")
    groups = {mod:[r["id"] for r in cases if r["module"] == "test."+mod] for mod in ("test_io", *MODULES)}
    check(len(groups["test_io"]) == 667 and sum(len(groups[m]) for m in MODULES) == 371, "wrong wider denominator")
    provenance = obj(folder/"provenance.json")
    intact_prov = obj(disc/"native"/label/"provenance.json")
    source = obj(oracle/"summary.json")["modules"]
    check(provenance["imre_commit"] == intact_prov["imre_commit"] == commit
          and provenance["cpython_commit"] == intact_prov["cpython_commit"] == CPYTHON
          and provenance["source_sha256"] == {m:source["test."+m]["sha256"] for m in MODULES}
          and digest(disc/"drivers/run_wider_io.py") == provenance["driver_sha256"] == DRIVER,
          f"mixed source or commit for wider label {label}")
    for key in ("compiler_sha256", "runtime_sha256"):
        check(provenance[key] == intact_prov[key] and re.fullmatch(r"[0-9a-f]{64}", provenance[key]),
              f"mismatched {key} for wider label {label}")
    return disc, folder, cases, groups, provenance, intact_prov


def execution_build(d, lane, label, intact_rec, intact_prov):
    build = obj(d/"build.json")
    build_info = process_record(build, d, timeout=1200)
    args, cwd = build["argv"], Path(build["cwd"])
    mode, opt = lane.split(".O")
    executable = str(cwd/"driver")
    expected_driver = str(Path(intact_rec["build"]["argv"][2]).with_name("run_wider_io.py"))
    clang = intact_rec["build"]["argv"]
    expected = [intact_prov["compiler"], "build", expected_driver, "--module-root", str(Path(expected_driver).parent),
                "--no-cache", "--runtime", intact_prov["runtime"], "--clang", clang[clang.index("--clang")+1],
                "--opt-level", opt, "-o", executable]
    if mode == "boxed":
        expected.append("--runtime-imports")
    check(cwd.parts[-2:] == (label, lane) and args == expected, f"wrong native build lane, SDK or driver at {d}")
    lines(d/"build.stdout")
    build_diag = lines(d/"build.stderr")[-1:]
    return build, build_info, executable, build_diag


def validate_wider_native(root: Path, label: str, commit: str, cases_667: dict | None = None) -> dict:
    disc, folder, cases, groups, provenance, intact_prov = execution_inputs(root,label,commit)
    tracks, measurements, all_states = {}, {}, {}
    for lane in LANES:
        d = folder/lane
        intact, intact_group, intact_rec = intact_section(disc, label, lane, groups["test_io"])
        if cases_667 is not None:
            check(cases_667[lane] == intact, f"667-row scope disagreement for {label}/{lane}")
        build, build_info, executable, build_diag = execution_build(d,lane,label,intact_rec,intact_prov)
        suite_records, details = [], {}
        group_summary, extra_states = {"test.test_io":intact_group}, {}
        if build["exit"] == 0:
            check(re.fullmatch(r"[0-9a-f]{64}", (d/"exe.sha256").read_text().strip()), f"missing executable hash at {d}")
        else:
            check(not (d/"exe.sha256").exists() and not (d/"suite-results.json").exists()
                  and not any((d/m).exists() for m in MODULES), f"stale module receipts after failed build at {d}")
        for mod in MODULES:
            goals = groups[mod]
            if build["exit"] == 0:
                states, group, summary, detail = native_module(d, mod, goals, build, executable, disc)
                suite_records.append(summary)
            else:
                states = dict.fromkeys(goals, "UNREACHED")
                group = dict(expected=len(goals), discovered=0, tests_run_reported=None, events={"UNREACHED":len(goals)},
                             fixture_events=[], build_exit=build["exit"], process_exit=None, last_diagnostic=build_diag,
                             raw_record=(d/"build.json").relative_to(disc).as_posix())
                detail = dict(process=None, reported_tests_run=None, canonical_events={}, outside_canonical_events=[], skip_reasons={})
            extra_states.update(states)
            details[mod] = detail
            group_summary["test."+mod] = group
        if build["exit"] == 0:
            check(obj(d/"suite-results.json") == suite_records, f"combined module results differ at {d}")
        states = intact | extra_states
        all_states[lane] = states
        tracks[lane] = dict(status_counts=dict(Counter(states.values())), groups=group_summary)
        measurements[lane] = dict(wider_build=build_info, wider_modules=details,
                                  extra_371=dict(Counter(extra_states.values())), discovery_667=dict(Counter(intact.values())),
                                  combined_1038=dict(Counter(states.values())))
    summary = obj(folder/"summary.json")
    check(summary["label"] == label and summary["denominator"] == 1038
          and summary["scope"] == SCOPE and summary["reference_order_sha256"] == ORDERED and summary["tracks"] == tracks,
          f"wider summary differs from raw records for {label}")
    fields = ["index", "occurrence", "id", "module", "reference_verdict", "reference_reason"]
    with (folder/"denominator-ledger.tsv").open(newline="") as f:
        reader = csv.reader(f, delimiter="\t")
        check(next(reader, None) == fields + list(LANES), f"incorrect wider ledger header for {label}")
        rows = list(reader)
    check(len(rows) == len(cases), f"incomplete wider ledger for {label}")
    for row, case in zip(rows, cases):
        expected = ["" if case[k] is None else str(case[k]) for k in fields]
        expected.extend(all_states[lane][case["id"]] for lane in LANES)
        check(row == expected, f"wider ledger differs at {label}/{case['id']}")
    return dict(label=label, commit=commit, compiler_sha256=provenance["compiler_sha256"],
                runtime_sha256=provenance["runtime_sha256"], reference_order_sha256=ORDERED, lanes=measurements)


REGISTRATION_DRIVER = "9456d315f345b47af9e5a63c09691154ed7db537567090e1b87c5e44dbf26781"


def registration_events(output, requested):
    """Verify process emission order and keep import failures distinct from loader failures."""
    begun, active, done = {}, None, None
    for line in output:
        if not line.startswith("IMRE_REG_"):
            check(not line.startswith(("IMRE_WIDE_VERDICT ", "IMRE_WIDE_RAN ")),
                  "unexpected suite-execution markers in registration process")
            continue
        token, sep, body = line.partition(" ")
        check(sep and done is None, f"unexpected registration marker {line!r}")
        short, _, tail = body.partition(" ")
        if token == "IMRE_REG_DONE":
            failures = sum(r["error"] is not None for r in begun.values())
            check(active is None and list(begun) == list(requested) and
                  body == f"{len(requested)} {failures}", f"inconsistent registration completion {line!r}")
            done = [len(requested), failures]
            continue
        if token == "IMRE_REG_BEGIN":
            check(active is None and len(begun) < len(requested) and short == requested[len(begun)]
                  and body == short, f"unexpected registration attempt {line!r}")
            active = short
            begun[active] = dict(imported=False, ids=[], discovered=None, loader_errors=[], error=None)
            continue
        check(active == short and active in begun, f"registration marker outside module attempt {line!r}")
        record = begun[active]
        if token == "IMRE_REG_IMPORTED":
            check(body == short and not record["imported"], f"repeated or malformed import {line!r}")
            record["imported"] = True
        elif token == "IMRE_REG_ID":
            check(record["imported"] and tail and not record["loader_errors"], f"unexpected ID marker {line!r}")
            record["ids"].append(tail)
        elif token == "IMRE_REG_LOADER_ERROR":
            check(record["imported"] and not record["ids"], f"unexpected loader error {line!r}")
            record["loader_errors"].append(tail)
        elif token == "IMRE_REG_ERROR":
            check(tail, f"empty exception marker {line!r}")
            record["error"] = tail
            active = None
        elif token == "IMRE_REG_DISCOVERED":
            check(record["imported"] and re.fullmatch(r"[0-9]+", tail) and not record["loader_errors"],
                  f"unexpected suite count {line!r}")
            record["discovered"] = int(tail)
            active = None
        else:
            raise ValueError(f"unknown registration marker {token!r}")
    return begun, done


def registration_process(d, requested, argv, cwd):
    record = obj(d/"process.json")
    info = process_record(record, d, timeout=1200)
    check(record["argv"] == argv and record["cwd"] == str(cwd), f"wrong registration process at {d}")
    emitted, done = registration_events(lines(d/"process.stdout"), requested)
    info.update(reported_done=done, begun=list(emitted), last_stderr=lines(d/"process.stderr")[-2:])
    return emitted, info


def registration_lane(disc, folder, lane, goals, prov):
    d = folder/lane
    build = obj(d/"build.json")
    info = process_record(build, d, timeout=1200)
    mode, opt = lane.split(".O")
    cwd = Path(build["cwd"])
    intact_folder = disc/"native"/folder.name/lane
    intact_args = obj(intact_folder/"result.json")["build"]["argv"]
    driver = Path(intact_args[2]).with_name("run_wider_registration.py")
    exe = str(cwd/"driver")
    args = [prov["compiler"],"build",str(driver),"--module-root",str(driver.parent),"--no-cache",
            "--runtime",prov["runtime"],"--clang","/workspace/scratch/tools/clang","--opt-level",opt,"-o",exe]
    if mode == "boxed":
        args.append("--runtime-imports")
    check(build["argv"] == args and cwd.parts[-3:] == ("registration",folder.name,lane),
          f"wrong registration build command at {d}")
    lines(d/"build.stdout")
    info["last_stderr"] = lines(d/"build.stderr")[-2:]
    recorded = obj(d/"registrations.json")
    processes, registry = {}, {}
    if build["exit"] != 0:
        check(recorded == {} and not any((d/n).exists() for n in ("all","exe.sha256",*MODULES)),
              f"stale registration records following failed build at {d}")
        return registry, info, processes
    check(re.fullmatch(r"[0-9a-f]{64}", (d/"exe.sha256").read_text().strip()), f"missing registration executable hash at {d}")
    shared, processes["all"] = registration_process(d/"all", MODULES, [exe], cwd)
    for mod in MODULES:
        location = "all"
        if mod in shared:
            check(not (d/mod).exists(), f"extra retry of an already attempted registration at {d}/{mod}")
            result = shared[mod]
        else:
            location = mod
            fallback, processes[mod] = registration_process(d/mod, [mod], [exe,mod], cwd/mod)
            result = fallback.get(mod)
        seen = result["ids"] if result else []
        count = result["discovered"] if result else None
        errors = []
        if result:
            errors = [f"IMRE_REG_LOADER_ERROR {mod} {reason}" for reason in result["loader_errors"]]
            if result["error"] is not None:
                errors.append(f"IMRE_REG_ERROR {mod} {result['error']}")
        registry["test."+mod] = dict(module="test."+mod, attempted=result is not None, imported=bool(result and result["imported"]),
                                     ids=seen, reported_count=count, expected=len(goals[mod]),
                                     order_matches_reference=seen == goals[mod] and count == len(seen),
                                     diagnostics=errors, tests_run=0, process_record=f"{lane}/{location}/process.json")
    check(registry == recorded, f"registration records differ from raw native marker sequence at {d}")
    return registry, info, processes


def validate_wider_registration(root: Path, label: str, commit: str) -> dict:
    check(re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*", label) and re.fullmatch(r"[0-9a-f]{40}",commit),
          "invalid registration revision")
    disc = Path(root)/"discovery"
    wider = disc/"wider"
    folder = wider/"registration"/label
    oracle = wider/"oracle"
    cases = obj(oracle/"ordered-cases.json")
    ids = [r["id"] for r in cases]
    check(len(ids) == len(set(ids)) == 1038 and digest(oracle/"ordered.ids") == ORDERED
          and lines(oracle/"ordered.ids") == ids, "invalid registration inventory")
    goals = {m:[r["id"] for r in cases if r["module"] == "test."+m] for m in ("test_io", *MODULES)}
    check(len(goals["test_io"]) == 667 and sum(len(goals[m]) for m in MODULES) == 371, "wrong registration scope")
    prov = obj(folder/"provenance.json")
    intact_prov = obj(disc/"native"/label/"provenance.json")
    check(prov["imre_commit"] == intact_prov["imre_commit"] == commit
          and prov["cpython_commit"] == intact_prov["cpython_commit"] == CPYTHON and
          digest(disc/"drivers/run_wider_registration.py") == prov["entry_sha256"] == REGISTRATION_DRIVER,
          f"mixed registration source or revision for {label}")
    ref = obj(oracle/"summary.json")["modules"]
    check(prov["original_sha256"] == {n:ref["test."+n]["sha256"] for n in MODULES}, "mixed original registration sources")
    for key in ("compiler", "runtime"):
        check(prov[key] == intact_prov[key] and prov[key+"_sha256"] == intact_prov[key+"_sha256"]
              and re.fullmatch(r"[0-9a-f]{64}",prov[key+"_sha256"]), f"mixed registration {key} for {label}")
    cp = wider/"registration/oracle"
    cp_proc = obj(cp/"process.json")
    process_record(cp_proc, cp)
    check(cp_proc["exit"] == 0 and not cp_proc["timed_out"] and len(cp_proc["argv"]) == 5
          and Path(cp_proc["argv"][0]).name == "python3.14" and cp_proc["argv"][1:4] == ["-B","-X","frozen_modules=off"]
          and Path(cp_proc["argv"][4]).name == "run_wider_registration.py", "incorrect CPython registration command")
    reference, done = registration_events(lines(cp/"process.stdout"), MODULES)
    check(done == [6,0] and not lines(cp/"process.stderr") and all(reference[n]["ids"] == goals[n] and
          reference[n]["discovered"] == len(goals[n]) for n in MODULES), "CPython 371-case registration differs from oracle")
    tracks, ledger = {}, {}
    for lane in LANES:
        intact, group, rec = intact_section(disc,label,lane,goals["test_io"],allow_extra=True)
        registry, build, processes = registration_lane(disc,folder,lane,goals,prov)
        extra = dict.fromkeys((ident for n in MODULES for ident in goals[n]), "UNREACHED")
        for r in registry.values():
            extra.update(dict.fromkeys(set(r["ids"]) & set(goals[r["module"][5:]]),"DISCOVERED_NO_VERDICT"))
        ledger[lane] = intact | extra
        tracks[lane] = dict(wider_build=build, wider_processes=processes, wider_modules=registry, intact_summary=group,
                            intact_667=dict(Counter(intact.values())), extra_371=dict(Counter(extra.values())),
                            combined_1038=dict(Counter(ledger[lane].values())), tests_run=0)
    registration_aggregate(disc,folder,cases,tracks,ledger)
    return dict(label=label, commit=commit, scope="Original-suite registration and discovery; zero native unittest methods run.",
                compiler_sha256=prov["compiler_sha256"], runtime_sha256=prov["runtime_sha256"],
                reference_order_sha256=ORDERED, lanes=tracks)


def registration_aggregate(disc, folder, cases, tracks, ledger):
    label = folder.name
    modules = {c["module"] for c in cases}
    expected_tracks = {}
    for lane, track in tracks.items():
        registry = track.pop("wider_modules")
        details = {}
        for module in modules:
            goals = [c["id"] for c in cases if c["module"] == module]
            if module == "test.test_io":
                dest = disc/"native"/label/lane
                raw = dest/"result.json"
                rec = obj(raw)
                build, proc = rec["build"], rec["process"]
                attempted, be, pe = proc is not None, build["exit"], proc["exit"] if proc else None
                text = lines(dest/"process.stdout") if proc else []
                observed = tags(text,"IMRE_IO_ID")
                match = pe == 0 and observed == goals and tags(text,"IMRE_IO_DISCOVERED") == [str(len(goals))]
                check(rec["discovery_complete"] == match, f"false intact registration claim at {raw}")
                count = len(observed) if match else None
                imported = True if observed or match else None
                diag = lines(dest/("process.stderr" if proc else "build.stderr"))[-2:]
            elif module not in registry:
                raw = folder/lane/"build.json"
                attempted, imported, count, match, observed = False, None, None, False, []
                be, pe, diag = track["wider_build"]["exit"], None, track["wider_build"]["last_stderr"]
            else:
                r = registry[module]
                raw = folder/r["process_record"]
                location = raw.parent.name
                proc = track["wider_processes"][location]
                attempted = r["attempted"]
                imported, count, match, observed = r["imported"] if attempted else None, r["reported_count"], r["order_matches_reference"], r["ids"]
                be, pe = track["wider_build"]["exit"], proc["exit"]
                diag = r["diagnostics"] or ([] if match else proc["last_stderr"])
            seen = Counter(observed)
            details[module] = dict(expected=len(goals), attempted=attempted, imported=imported, reported_count=count,
                                   observed_ids=len(observed), expected_ids_observed=sum(ident in seen for ident in goals),
                                   order_matches_reference=match, unexpected_ids=dict(seen-Counter(goals)), methods_executed=0,
                                   diagnostics=diag, build_exit=be, process_exit=pe, raw_record=raw.relative_to(disc).as_posix())
        expected_tracks[lane] = dict(expected=1038, modules_attempted=sum(i["attempted"] for i in details.values()),
                                     modules_imported_known=sum(i["imported"] is True for i in details.values()),
                                     methods_executed=0, states=track["combined_1038"], modules=details)
        track["modules"] = details
    summary = obj(folder/"summary.json")
    check(summary == dict(label=label, imre_commit=obj(folder/"provenance.json")["imre_commit"], denominator=1038,
                          reference_order_sha256=ORDERED, tracks=expected_tracks,
                          scope="Original-registration discovery only. Separate execution receipts live under wider/native."),
          f"registration summary differs from staged native processes for {label}")
    flds = ["index","occurrence","id","module","reference_verdict","reference_reason"]
    with (folder/"denominator-ledger.tsv").open(newline="") as f:
        table = csv.reader(f, delimiter="\t")
        check(next(table, None) == flds + list(LANES), f"incorrect registration ledger header for {label}")
        rows = list(table)
    check(len(rows) == len(cases), f"incomplete registration ledger for {label}")
    for row, case in zip(rows,cases):
        expected = ["" if case[k] is None else str(case[k]) for k in flds] + [ledger[l][case["id"]] for l in LANES]
        check(row == expected, f"registration ledger differs at {label}/{case['id']}")


def validate_partial_wider_native(root: Path, label: str, commit: str) -> dict:
    """Verify only finished, archived suite processes; raw-only files carry no method verdict."""
    root = Path(root)
    disc, folder, _, groups, prov, intact = execution_inputs(root,label,commit)
    lanes, all_raw, complete, terminal = {}, [], [], {}
    for lane in LANES:
        d = folder/lane
        records, details, events, raw = [], {}, {}, []
        build_info = None
        build_path = d/"build.json"
        known = set()
        if build_path.is_file():
            observed = obj(disc/"native"/label/lane/"result.json")
            build, build_info, exe, _ = execution_build(d,lane,label,observed,intact)
            known.update(d/n for n in ("build.json","build.stdout","build.stderr"))
            executable_file = d/"exe.sha256"
            if executable_file.is_file():
                check(build["exit"] == 0 and re.fullmatch(r"[0-9a-f]{64}",executable_file.read_text().strip()),
                      f"unverified supplementary executable at {d}")
                known.add(executable_file)
            for mod in MODULES:
                m = d/mod
                required = [m/n for n in ("process.stdout","process.stderr","process.json","observed.ids","summary.json")]
                if all(p.is_file() for p in required):
                    check(build["exit"] == 0 and executable_file in known, f"no verified build for {m}")
                    states, _, result, info = native_module(d,mod,groups[mod],build,exe,disc)
                    records.append(result)
                    events.update(states)
                    info["process_receipt"] = (m/"process.json").relative_to(root).as_posix()
                    details["test."+mod] = info
                    known.update(required)
            complete_suite = d/"suite-results.json"
            if complete_suite.is_file():
                check(len(records) == len(MODULES) and obj(complete_suite) == records, f"incorrect final suite list at {d}")
                known.add(complete_suite)
                complete.append(lane)
        terminal[lane] = records
        if d.is_dir():
            raw = sorted(p.relative_to(root).as_posix() for p in d.rglob("*") if p.is_file() and p not in known)
        all_raw.extend(raw)
        counts = Counter(events.values())
        lanes[lane] = dict(build=build_info, completed_modules=details, canonical_case_statuses=events,
                           recorded_status_counts=dict(counts), canonical_verdict_events=sum(counts[v] for v in VERDICTS),
                           raw_only_paths=raw)
    final = folder/"supplementary-final.json"
    if final.is_file():
        declared = obj(final)
        planned = declared["planned_lane"]
        check(planned in LANES and declared["completed_suites"] == terminal[planned],
              f"supplementary-final list differs from verified suite processes for {label}")
    return dict(scope="Supplementary whole-suite processes; separate from registration and its 1,038-ID totals.",
                label=label, commit=commit, compiler_sha256=prov["compiler_sha256"], runtime_sha256=prov["runtime_sha256"],
                completed_lanes=complete, lanes=lanes, raw_only_file_count=len(all_raw), raw_only_paths=all_raw)
