"""Derive final I/O discovery and original selector snapshots from immutable local receipts."""
import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import re
import tempfile


LANES = ("ordinary.O0", "ordinary.O3", "boxed.O0", "boxed.O3")
ORACLE = "e82addd026e03cd24b66534764472806847401dcffaaa392bab2081fb70cdab4"
CPYTHON = "5607950ef232dad16d75c0cf53101d9649d89115"
SOURCE = "6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af"
PYIO = "1beee84c68ef6f7acb649dd5aada4c2f34f0476b01c293efe4afd9d0fe2d3ff1"
SCOPES = {"misc-group": "focused", "projected": "focused", "checked": "focused", "api": "focused", "api-imports": "focused", "decoder": "focused", "ctypes": "focused",
          "intact": "intact_selector", "intact-decoder": "intact_selector"}
VERDICTS = ("PASS", "SKIP", "FAIL", "ERROR")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_bytes())


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def read_oracle(root):
    folder = root / "discovery/oracle/regrtest-default"
    raw = (folder / "ordered.ids").read_bytes()
    ids = raw.decode().splitlines()
    require(digest(raw) == ORACLE and len(set(ids)) == len(ids) == 667, "invalid canonical denominator")
    cases = read_json(folder / "ordered-cases.json")
    require([c["id"] for c in cases] == ids and
            all(c["index"] == i and c["occurrence"] == 1 for i, c in enumerate(cases, 1)),
            "oracle ledger differs from the canonical 667 IDs")
    require(Counter(c["reference_verdict"] for c in cases) == {"PASS": 649, "SKIP": 18} and
            all(c.get("reference_reason") for c in cases if c["reference_verdict"] == "SKIP"),
            "wrong pinned default-resource CPython outcomes")
    return cases


def read_streams(section, folder, stem, record):
    paths = [folder / f"{stem}.{ext}" for ext in ("stdout", "stderr")]
    for ext, path in zip(("stdout", "stderr"), paths):
        require(record[ext] == path.relative_to(section).as_posix(), f"unexpected stream path: {path}")
    return [p.read_bytes().decode(errors="replace") for p in paths]


def check_build(build, lane):
    args = build["argv"]
    require(args[args.index("--opt-level") + 1] == lane[-1] and
            ("--runtime-imports" in args) == lane.startswith("boxed.") and "--no-cache" in args,
            f"build flags differ from receipt lane {lane}")


def discovery(root, label, commit, cases):
    section = root / "discovery"
    base = section / "native" / label
    prov = read_json(base / "provenance.json")
    require(prov["imre_commit"] == commit and prov["cpython_commit"] == CPYTHON and
            prov["source_sha256"]["test/test_io.py"] == SOURCE and prov["source_sha256"]["_pyio.py"] == PYIO and
            prov["expected_ordered_ids_sha256"] == ORACLE, "intact source or commit mismatch")
    summary, seen = {}, {}
    ids = [case["id"] for case in cases]
    for lane in LANES:
        folder = base / lane
        receipt = read_json(folder / "result.json")
        require(f'{receipt["mode"]}.O{receipt["level"]}' == lane and receipt["scope"] == "discovery" and
                receipt["tests_run"] == 0, f"wrong intact discovery receipt: {folder}")
        build, proc = receipt["build"], receipt["process"]
        check_build(build, lane)
        _, err = read_streams(section, folder, "build", build)
        require((build["exit"] == 0) == (proc is not None), f"missing or spurious native process: {folder}")
        out = ""
        if proc is not None:
            out, err = read_streams(section, folder, "process", proc)
        emitted = [line.removeprefix("IMRE_IO_ID ") for line in out.splitlines() if line.startswith("IMRE_IO_ID ")]
        raw_ids = ("\n".join(emitted) + "\n").encode() if emitted else b""
        require(len(emitted) == receipt["observed_id_lines"] and
                (digest(raw_ids) if emitted else None) == receipt["ordered_ids_sha256"],
                f"discovery process output differs from recorded IDs: {folder}")
        complete = (proc is not None and proc["exit"] == 0 and emitted == ids and
                    [line for line in out.splitlines() if line.startswith("IMRE_IO_DISCOVERED ")] == ["IMRE_IO_DISCOVERED 667"])
        require(receipt["discovery_complete"] == complete, f"incorrect discovery_complete flag: {folder}")
        seen[lane] = set(emitted)
        effective = proc or build
        summary[lane] = dict(build_exit=build["exit"], process_exit=proc["exit"] if proc else None,
                             timed_out=effective.get("timed_out", False), discovery_complete=complete,
                             observed_id_lines=len(emitted), canonical_ids_seen=len(seen[lane].intersection(ids)),
                             intact_unittest_executions=0, last_stderr_line=err.strip().splitlines()[-1:] or [],
                             receipt=(folder / "result.json").relative_to(root).as_posix())
    return prov, summary, seen


MISC_IDS = [f"test.test_io.{cls}.{method}"
            for cls in ("CMiscIOTest", "PyMiscIOTest")
            for method in ("test_abc_inheritance", "test_abc_inheritance_official", "test_abcs")]


def grouped_suite(section, path, rec):
    cases = rec["cases"]
    require(rec.get("process_scope") == "one shared original suite" and
            [c["selector"] for c in cases] == MISC_IDS, f"wrong shared suite or selector order: {path}")
    proc = cases[0]["process"]
    require(all(c["process"] == proc for c in cases) and (proc is not None) == (rec["build"]["exit"] == 0),
            f"expected one common native process after a successful build: {path}")
    summary = dict(receipt=path.relative_to(section.parent).as_posix(), requested_ids=MISC_IDS,
                   process=proc, native_processes=int(proc is not None), per_method_verdicts=0)
    if proc is None:
        require(all(c["verdict"] == "BUILD_ERROR" for c in cases), f"missing shared selector build error: {path}")
        summary["suite_status"] = "BUILD_TIMEOUT" if rec["build"]["exit"] is None else "BUILD_ERROR"
        return summary, {sel: (summary["suite_status"], "") for sel in MISC_IDS}
    require(proc["argv"] == [rec["build"]["argv"][rec["build"]["argv"].index("-o")+1], *MISC_IDS]
            and proc["elapsed_s"] >= 0, f"unexpected shared executable, argv, or duration: {path}")
    out, err = read_streams(section, path.parent, "selected-six", proc)
    lines = out.splitlines()
    selected = [line.removeprefix("IMRE_GROUP_SELECTED ") for line in lines if line.startswith("IMRE_GROUP_SELECTED ")]
    claims = [line.removeprefix("IMRE_GROUP_VERDICT ") for line in lines if line.startswith("IMRE_GROUP_VERDICT ")]
    require(selected == MISC_IDS[:len(selected)], f"unexpected shared selection markers: {path}")
    summary["last_stderr_line"] = err.strip().splitlines()[-1:]
    if not claims:
        code = proc["exit"]
        status = ("TIMEOUT" if code is None else f"SIGNAL_{-code}" if code < 0 else
                  "LOADER_ERROR" if code != 0 and not selected and
                  any(line.startswith("IMRE_LOADER_ERROR ") for line in lines) and
                  err.rstrip().endswith("RuntimeError: test_io.load_tests failed before selector enumeration") else
                  "NO_SELECTION" if not selected else "INCOMPLETE")
        summary["suite_status"] = status
        outcomes = {}
        for c in cases:
            sel = c["selector"]
            individual = "UNCLASSIFIED" if sel in selected else "UNREACHED"
            expected = status if (status.startswith("SIGNAL_") or status == "TIMEOUT") else individual
            require(c["verdict"] == expected, f"unverified shared selector claim for {sel}")
            outcomes[sel] = (individual, "")
        return summary, outcomes
    require(selected == MISC_IDS and claims == [c["selector"] + " " + c["verdict"] for c in cases]
            and all(c["verdict"] in VERDICTS for c in cases), f"incomplete shared verdict markers: {path}")
    text = out + "\n" + err
    require(len(re.findall(r"(?m)^Ran 6 tests in ", text)) == 1, f"unverified shared test count: {path}")
    counts = Counter(c["verdict"] for c in cases)
    failed = bool(counts["ERROR"] + counts["FAIL"])
    require(proc["exit"] == int(failed), f"shared exit differs from unittest outcomes: {path}")
    if failed:
        details = ", ".join(f"{kind}={counts[key]}" for key, kind in
                            (("FAIL", "failures"), ("ERROR", "errors"), ("SKIP", "skipped")) if counts[key])
        ending = f"FAILED ({details})"
    else:
        ending = f'OK (skipped={counts["SKIP"]})' if counts["SKIP"] else "OK"
    require(ending in text.splitlines(), f"missing shared unittest result: {path}")
    outcomes = {}
    for c in cases:
        sel, verdict = c["selector"], c["verdict"]
        status = {"PASS": "ok", "FAIL": "FAIL", "ERROR": "ERROR", "SKIP": r"skipped (.+)"}[verdict]
        match = re.search(r"(?m)^" + re.escape(sel.rsplit(".", 1)[-1] + " (" + sel + ") ... ") +
                          status + "$", text)
        require(match, f"missing unittest result for shared selector {sel}")
        outcomes[sel] = verdict, match[1].strip() if verdict == "SKIP" else ""
    summary.update(suite_status="COMPLETED", per_method_verdicts=len(outcomes))
    return summary, outcomes


