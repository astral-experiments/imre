"""Capture and replay an exact Imre PR or first-parent merge patch using only scratch Git objects."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile


def require(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase",choices=("tested","public"))
    parser.add_argument("commit")
    span=parser.add_mutually_exclusive_group(required=True)
    span.add_argument("--expected-parent", help="capture a guarded single first-parent delta")
    span.add_argument("--base", help="capture a tested multi-commit PR from its guarded base")
    parser.add_argument("--tested",help="exact tested head for public first-parent comparison")
    parser.add_argument("--repo",type=Path,default=Path("/workspace/scratch/imre-io-buffer-binding"))
    parser.add_argument("--out",type=Path,default=Path("/workspace/shared/downloads/io-buffer-binding/patches"))
    parser.add_argument("--scratch",type=Path,default=Path("/workspace/scratch"))
    a=parser.parse_args()
    require(all(re.fullmatch(r"[a-f0-9]{40}",v) for v in (a.commit,a.expected_parent or a.base)),"full SHAs required")
    require(a.phase=="tested" or (a.tested and re.fullmatch(r"[a-f0-9]{40}",a.tested)), "public capture needs exact tested SHA")
    repo=a.repo.resolve()
    runs=[]
    def git(*argv,env=None,data=None,status=(0,)):
        cmd=["git","-C",str(repo),*argv]
        p=subprocess.run(cmd,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
        runs.append(dict(argv=cmd,exit=p.returncode,stderr=p.stderr.decode(errors="replace")))
        require(p.returncode in status,f"{cmd} exited {p.returncode}: {p.stderr.decode(errors='replace')}")
        return p
    parents=git("show","-s","--format=%P",a.commit).stdout.decode().strip().split()
    require(parents, "commit must have a parent")
    delta_base=a.expected_parent or a.base
    if a.expected_parent:
        require(parents[0]==a.expected_parent, "commit has unexpected first parent")
    else:
        require(a.phase=="tested", "the public merge must use its actual first parent")
        git("merge-base","--is-ancestor",delta_base,a.commit)
    series=git("rev-list","--reverse","--first-parent",delta_base+".."+a.commit).stdout.decode().splitlines()
    require(series and git("rev-parse",f"{a.commit}~{len(series)}").stdout.decode().strip()==delta_base,
            "requested base is outside the tested first-parent chain")
    tree=git("rev-parse",a.commit+"^{tree}").stdout.decode().strip()
    opts=["diff","--no-ext-diff","--no-textconv","--no-color","--binary","--full-index","--no-renames","--diff-algorithm=myers",delta_base,a.commit,"--"]
    patch=git(*opts).stdout
    names=git("diff","--name-only","--no-renames",delta_base,a.commit,"--").stdout.decode().splitlines()
    objects=Path(git("rev-parse","--path-format=absolute","--git-path","objects").stdout.decode().strip())
    with tempfile.TemporaryDirectory(dir=a.scratch,prefix=".patch-replay-") as t:
        t=Path(t);obj=t/"objects";obj.mkdir();ind=t/"index"
        env=dict(os.environ,GIT_INDEX_FILE=str(ind),GIT_OBJECT_DIRECTORY=str(obj),
                 GIT_ALTERNATE_OBJECT_DIRECTORIES=str(objects),GIT_OPTIONAL_LOCKS="0")
        git("read-tree",delta_base+"^{tree}",env=env)
        if patch:
            git("apply","--cached","--check","--binary","--whitespace=nowarn","-",data=patch,env=env)
            git("apply","--cached","--binary","--whitespace=nowarn","-",data=patch,env=env)
        replayed=git("write-tree",env=env).stdout.decode().strip()
    require(tree==replayed,"first-parent replay produced a different tree")
    a.out.mkdir(exist_ok=True,parents=True);stem=f"{a.phase}-{a.commit[:7]}";fname=stem+".patch"
    pair=dict(phase=a.phase,commit=a.commit,parents=parents,delta_base=delta_base,span=("guarded PR base to tested head" if a.base else "first parent to head"),commits=series,tree=tree,replayed_tree=replayed,empty_delta=not bool(patch),
              patch=fname,bytes=len(patch),sha256=hashlib.sha256(patch).hexdigest(),files=names)
    if a.phase=="public":
        pair.update(tested_head=a.tested,tested_is_ancestor=git("merge-base","--is-ancestor",a.tested,a.commit,status=(0,1)).returncode==0)
    pair["commands"]=runs
    for path,raw in [(a.out/fname,patch),(a.out/(stem+".json"),(json.dumps(pair,indent=2)+"\n").encode())]:
        if path.exists():
            require(path.read_bytes()==raw,f"existing capture differs: {path}")
            continue
        with path.open("xb") as out:out.write(raw)
    print(f"{pair['sha256']}  {a.out/fname} ({len(patch)} bytes, {len(names)} paths), tree {tree}")


if __name__=="__main__":
    main()
