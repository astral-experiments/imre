# Public BufferedReader fixture and original I/O discovery

[Imre PR #3673](https://github.com/astral-experiments/imre/pull/3673) merged as `ae0e69c4f08a6a859550c18b70ed22509121667d`. The guarded head was `6cd4fc4556aa3f1b256d56cef6cc6a758334dc56`, its PR parent was `2e658557643b5d4d53e3b24624c2ea6a06bf9da4`, and the baseline was `922b21506bf57f399cf2356f9803906b1f0d55a4`. The public first-parent patch has SHA-256 `324db4e185ee820d75afd51056c2e24ac139a814faf0fd583930337708d1e2f9`. [Patch and tree replay](patches)

Pinned CPython 3.14.5 at `5607950ef232dad16d75c0cf53101d9649d89115` supplied the reference. The SHA-256 of the unchanged original test_io.py is `6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af` and that of _pyio.py is `1beee84c68ef6f7acb649dd5aada4c2f34f0476b01c293efe4afd9d0fe2d3ff1`.

## Public native measurements

The reader-fixture runner preserves all 67,288 bytes of the first 1,859 original lines, including the complete C and Py reader classes. It checks that the original CBufferedReaderTest.tp equals both public and private BufferedReader and the type returned by opening a real binary file. Bound and unbound reads return b"ab" and b"cd". Its success counts as zero unittest methods. The six-selector runner uses an original loader projection retaining the actual fixture namespace construction, methods, lifecycle and skips. The 667 column uses the unedited full module and original loader. Ordinary uses the default compiler dispatch and can emit boxed IR. The forced boxed command adds --runtime-imports. Each fixture receipt identifies the executable, LLVM hash, and chosen IR. The fixed builtin open control also compares its typed LLVM across the change. [Original fixture source proof](focused/reader/source-receipt.json) · [Six-selector receipt definitions](focused/README.md)

| Lane | Reader fixture build/process | Six selectors build/process | Intact build/process and registered | Wider registered |
| --- | --- | --- | --- | --- |
| ordinary O0 | 0/0 PASS | 0/1 | 0/1 at test_io.py:2159, 0/667 | 371/1,038 |
| ordinary O3 | 0/0 PASS | 0/1 | 0/1 at test_io.py:2159, 0/667 | 371/1,038 |
| boxed O0 | 0/0 PASS | 0/1 | 0/1 at test_io.py:2159, 0/667 | 371/1,038 |
| boxed O3 | 0/0 PASS | 0/1 | 0/1 at test_io.py:2159, 0/667 | 371/1,038 |

The original CBufferedWriterTest.tp assignment at test_io.py:2159 needs io.BufferedWriter. At original line 5095 the focused Misc loader reaches the first missing name, BufferedWriter, while preparing c_io_ns. Its export inventory also lacks BufferedRWPair, BufferedRandom and IncrementalNewlineDecoder. No one of the six methods ran. [Original group and fixture processes](focused/runs/merged-ae0e69c) · [Intact imports](discovery/native/merged-ae0e69c)

| 667 ordinal | ID occurrence | Exact original ID | Ordinary O0 | Ordinary O3 | Boxed O0 | Boxed O3 |
| --- | --- | --- | --- | --- | --- | --- |
| 603 | 1 | test.test_io.CMiscIOTest.test_abc_inheritance | UNREACHED | UNREACHED | UNREACHED | UNREACHED |
| 604 | 1 | test.test_io.CMiscIOTest.test_abc_inheritance_official | UNREACHED | UNREACHED | UNREACHED | UNREACHED |
| 605 | 1 | test.test_io.CMiscIOTest.test_abcs | UNREACHED | UNREACHED | UNREACHED | UNREACHED |
| 626 | 1 | test.test_io.PyMiscIOTest.test_abc_inheritance | UNREACHED | UNREACHED | UNREACHED | UNREACHED |
| 627 | 1 | test.test_io.PyMiscIOTest.test_abc_inheritance_official | UNREACHED | UNREACHED | UNREACHED | UNREACHED |
| 628 | 1 | test.test_io.PyMiscIOTest.test_abcs | UNREACHED | UNREACHED | UNREACHED | UNREACHED |

The 1,038 denominator includes the 667 above and 371 from six other original modules. The canonical ledgers preserve every ID, occurrence, reference verdict and native lane disposition. Discovery executes zero methods. [667 ledger](discovery/native/merged-ae0e69c/denominator-ledger.tsv) · [1,038 ledger](discovery/wider/registration/merged-ae0e69c/denominator-ledger.tsv)

CPython's seven-module regrtest returned 1,009 passes and 29 skips, including 649 passes and 18 skips in test_io. The separate supplemental public-baseline ordinary O0 execution attempt on the other six modules recorded 161 PASS, 12 SKIP, 3 FAIL, 99 ERROR and 96 discovered without a verdict. Five module processes reached the 300-second limit. [Oracle](discovery/DENOMINATOR.md) · [Partial native execution](discovery/wider/native/public-922b215/supplementary-final.json)

## Before, guarded head and remaining scope

The public baseline stopped at line 1804 in all four intact lanes, each with build exit 0 and process exit 1. The PR parent failed the permanent fixture during ordinary compilation and during boxed execution at both levels. On the guarded head the permanent fixture passed in all four lanes, with native stdout and stderr matching CPython. Raw argv, elapsed time and status distinguish compiler failures, shared fixture errors, timeouts and method executions. [Baseline](discovery/native/public-922b215) · [Before/after checkpoint](ordinary/GUARDED_FIXTURE.sha256) · [Compiler provenance](build/guarded-6cd4fc4-binary-provenance.json)

Both modules export the implemented native reader. The public ABC registers the concrete low-level class. Controls cover file and descriptor input, Python subclasses backed by exact native FileIO, positive and negative type checks, receiver errors, inherited descriptors, reimports, and socket/pipe reads. The combined public ABC probe also checks virtual registration, cache-token invalidation, cycle rejection, and reader subclass and instance relationships against all four io ABCs. Its initial ordinary harness put a class definition after executable statements and was rejected at compile time at O0/O3. The boxed build ran it. Moving the same class definition ahead of the probe calls allowed the default pipeline to compile it. [Original harness runs](build/public-abc/report.json) · [Reordered public ABC probe](build/public-abc-ordered/report.json)

The constructor retains its raw FileIO. Custom Python raw callbacks, active wrapper reinitialization and explicit buffers larger than 8 MiB remain unsupported. The pre-existing opener can omit the raw object or keep a FileIO from the initial module generation. [Independent runtime review](native-reader/REVIEW-6cd4fc4.md)

The general buffered implementation supplies Python raw callback and writable memoryview work. Its dependency merge against the baseline conflicted in eight files and produced no build or native verdict. The IO primary retains C open and its file families. On follow-up main 2bfd2b05edd39cc5f57a28d6f780dc3b22487eaf the runtime still registered writer and random handle-type symbols internally but had no native public class constructor for Writer, Random or RWPair. PR #3356 provides the real IncrementalNewlineDecoder on top of the reader squash. PR #3702 changes nonblocking writes on the existing writer handle. The next real export needed by intact discovery is BufferedWriter. [Nonblocking writer work](https://github.com/astral-experiments/imre/pull/3702) [Buffered implementation coordination](https://github.com/astral-experiments/imre/pull/3437#issuecomment-6570010656) · [IO primary coordination](https://github.com/astral-experiments/imre/pull/3356#issuecomment-6570013218) · [Dependency analysis](dependency-review/README.md)
