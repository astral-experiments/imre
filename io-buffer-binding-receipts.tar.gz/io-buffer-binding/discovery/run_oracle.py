"""Run pinned, unmodified CPython regrtest in isolated writable directories."""
import json
import os
from pathlib import Path
import subprocess
import time

base = Path(__file__).resolve().parent
work = Path('/workspace/scratch/io-buffer-bind-discovery/reference')
python = Path('/workspace/scratch/cpytools/bin/python3.14')
modules = ('test_io', 'test_fileio', 'test_memoryio', 'test_file', 'test_univnewlines', 'test_largefile', 'test_bufio')
for group, reports, selection in [('intact', base/'oracle', modules[:1]), ('wider', base/'wider/oracle', modules)]:
    directory = work / group
    directory.mkdir(exist_ok=True)
    env = dict(os.environ, PYTHONPATH='/workspace/scratch/cpython/Lib', TMPDIR=str(directory), PYTHONDONTWRITEBYTECODE='1')
    cmd = [str(python), '-B', '-X', 'frozen_modules=off', '-m', 'test', '--single-process', '--tempdir', str(directory), '--randseed', '1', '--junit-xml', str(reports/'regrtest.xml'), *selection]
    start = time.monotonic()
    result = subprocess.run(cmd,cwd=directory,env=env,capture_output=True,timeout=600)
    for stream in ('stdout','stderr'):
        (reports/('regrtest.'+stream)).write_bytes(getattr(result,stream))
    (reports/'regrtest-run.json').write_text(json.dumps({'argv':cmd, 'cwd':str(directory), 'exit':result.returncode,'elapsed_s':round(time.monotonic()-start,3),'PYTHONPATH':env['PYTHONPATH'],'resources':'CPython regrtest default', 'interpreter':str(python)},indent=2)+'\n')
    print(group,result.returncode,result.stdout.decode(errors='replace').splitlines()[-4:],flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
