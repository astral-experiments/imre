"""Record the intact load_tests denominator and the fixture attached to each group."""
import argparse
from collections import Counter
import hashlib
import inspect
import json
import sys
import unittest
from pathlib import Path
from test import support

p=argparse.ArgumentParser()
p.add_argument("--resources",choices=("bare", "regrtest-default"),required=True)
p.add_argument("--out",type=Path,required=True)
a=p.parse_args()
assert sys.version_info[:3] == (3,14,5)
if a.resources == "regrtest-default":
    support.use_resources={}
else:
    assert support.use_resources is None
from test import test_io
import _pyio
import io
import abc
import xml.etree.ElementTree as ET

def sha(data):
    return hashlib.sha256(data).hexdigest()

def dump(path,obj):
    path.write_text(json.dumps(obj,indent=2)+"\n")

def source(func):
    f = inspect.unwrap(func)
    path = inspect.getsourcefile(f)
    if not path:
        return {"qualname":f.__qualname__,"module":f.__module__}
    lines, first=inspect.getsourcelines(f)
    return {"module":f.__module__,"qualname":f.__qualname__,"file":str(Path(path).resolve()),
            "line":first,"source_sha256":sha("".join(lines).encode())}

blobs = {}
for mod in (test_io, _pyio, abc, io, unittest, support):
    path = Path(mod.__file__).resolve()
    assert path.is_relative_to("/workspace/scratch/cpython/Lib")
    blobs[mod.__name__] = {"path":str(path),"sha256":sha(path.read_bytes())}
assert blobs["test.test_io"]["sha256"] == "6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af"
loader=unittest.TestLoader()
suite=loader.loadTestsFromModule(test_io)
assert not loader.errors
ids=[]
records=[]
groups=[]
counts=Counter()
all_members=io.__all__
mocks=("MockRawIO","MisbehavedRawIO","MockFileIO","CloseFailureIO","MockNonBlockWriterIO",
       "MockUnseekableIO","MockRawIOWithoutRead","SlowFlushRawIO","MockCharPseudoDevFileIO")
for group_no,group in enumerate(suite,1):
    cases=list(group)
    assert cases
    cls=type(cases[0])
    assert all(type(c) is cls for c in cases)
    assert cls.__module__=="test.test_io"
    hooks={name:source(getattr(cls,name)) for name in ("setUp", "tearDown", "setUpClass","tearDownClass","run")}
    variant = "C" if cls.__name__.startswith("C") else "Py" if cls.__name__.startswith("Py") else None
    info={"index":group_no,"class":cls.__qualname__,"cases":len(cases),"mro":[f"{c.__module__}.{c.__qualname__}" for c in cls.__mro__],"lifecycle":hooks}
    if variant:
        module=io if variant=="C" else _pyio
        for name in all_members:
            assert cls.__dict__[name] is getattr(module,name), (cls,name)
        assert cls.__dict__["is_C"] is (variant=="C")
        mock_bindings = {name:getattr(test_io,variant+name) for name in mocks}
        assert all(cls.__dict__[k] is v for k,v in mock_bindings.items())
        info["load_tests_bindings"]={"variant":variant,"export_source":module.__name__,"all_exports":list(all_members),"is_C":cls.__dict__["is_C"],"mocks":{k:f"{v.__module__}.{v.__qualname__}" for k,v in mock_bindings.items()}}
    groups.append(info)
    for case in cases:
        name=case._testMethodName
        body=getattr(cls,name)
        counts[case.id()]+=1
        ids.append(case.id())
        skip = (getattr(cls,"__unittest_skip_why__","") if getattr(cls,"__unittest_skip__",False) else
                getattr(body,"__unittest_skip_why__","") if getattr(body,"__unittest_skip__",False) else None)
        records.append({"index":len(ids),"id":case.id(),"occurrence":counts[case.id()],
                        "group":group_no,"method":source(body),
                        "declared_skip_reason":skip,"expecting_failure":getattr(body,"__unittest_expecting_failure__",False)})
assert len(ids)==suite.countTestCases()
order=("\n".join(ids)+"\n").encode()
out=a.out
out.mkdir(parents=True,exist_ok=True)
(out/"ordered.ids").write_bytes(order)
if a.resources=="regrtest-default":
    xml=ET.parse(out.parent/"regrtest.xml")
    results=xml.findall(".//testcase")
    observed=[row.attrib["name"] for row in results]
    assert observed==ids, "Regrtest JUnit order or multiplicity differs from the actual discovery order"
    for row,case in zip(results,records):
        assert row.attrib["status"]=="run" and row.attrib["result"]=="completed"
        children=[el for el in row if el.tag not in {"system-out","system-err"}]
        if not children:
            case["reference_verdict"]="PASS"
        else:
            child,=children
            case["reference_verdict"]={"skipped":"SKIP","error":"ERROR","failure":"FAIL"}[child.tag]
            case["reference_reason"]=child.text or child.attrib.get("message","")
        case["reference_elapsed_s"]=float(row.attrib["time"])
dump(out/"fixtures.json",groups)
dump(out/"ordered-cases.json",records)
summary={"python":sys.version,"interpreter":sys.executable,"resource_context":a.resources,"use_resources":support.use_resources,
         "suite":"test.test_io","cpython_commit":"5607950ef232dad16d75c0cf53101d9649d89115","source":blobs,
         "denominator":len(ids),"unique_ids":len(counts),"repeat_counts":{k:v for k,v in counts.items() if v!=1},
         "groups":len(groups),"ordered_ids_sha256":sha(order),"ordered_ids_encoding":"UTF-8, one TestCase.id() followed by LF per occurrence",
         "first_id":ids[0],"last_id":ids[-1],"loader_errors":loader.errors,"discovery_declared_skips":sum(r["declared_skip_reason"] is not None for r in records),
         "expecting_failure":sum(bool(r["expecting_failure"]) for r in records),"fixture_sha256":sha((out/"fixtures.json").read_bytes()),
         "load_tests":source(test_io.load_tests)}
if a.resources=="regrtest-default":
    summary["reference_verdicts"]=dict(Counter(r["reference_verdict"] for r in records))
    summary["reference_skip_reasons"]=dict(Counter(r["reference_reason"] for r in records if r["reference_verdict"]=="SKIP"))
canonical = {"fixture_sha256":summary["fixture_sha256"], "occurrences":[{
    "id":r["id"],"occurrence":r["occurrence"],"group":r["group"],
    "method":r["method"]["qualname"],"method_source_sha256":r["method"]["source_sha256"],
    "declared_skip_reason":r["declared_skip_reason"],"expecting_failure":r["expecting_failure"]
} for r in records]}
summary["ordered_fixture_and_declared_skips_sha256"] = sha((json.dumps(canonical,sort_keys=True,separators=(",",":")) + chr(10)).encode())
summary["case_ledger_file_sha256"] = sha((out/"ordered-cases.json").read_bytes())
dump(out/"summary.json",summary)
print(a.resources,len(ids),len(groups),summary["ordered_ids_sha256"],summary["discovery_declared_skips"],summary.get("reference_verdicts"))

