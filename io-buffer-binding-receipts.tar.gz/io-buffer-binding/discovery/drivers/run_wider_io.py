import sys
import unittest
from test import support


def select(name):
    if name == 'test_fileio':
        from test import test_fileio
        return test_fileio
    if name == 'test_memoryio':
        from test import test_memoryio
        return test_memoryio
    if name == 'test_file':
        from test import test_file
        return test_file
    if name == 'test_univnewlines':
        from test import test_univnewlines
        return test_univnewlines
    if name == 'test_largefile':
        from test import test_largefile
        return test_largefile
    if name == 'test_bufio':
        from test import test_bufio
        return test_bufio
    raise ValueError(name)


class Result(unittest.TestResult):
    def addSuccess(self, case):
        super().addSuccess(case)
        print('IMRE_WIDE_VERDICT', 'PASS', case.id(), flush=True)

    def addError(self, case, detail):
        print('IMRE_WIDE_VERDICT', 'ERROR', case.id(), flush=True)
        print('IMRE_WIDE_DETAIL', case.id(), detail[0].__name__, str(detail[1]), flush=True)
        super().addError(case, detail)

    def addFailure(self, case, detail):
        print('IMRE_WIDE_VERDICT', 'FAIL', case.id(), flush=True)
        print('IMRE_WIDE_DETAIL', case.id(), detail[0].__name__, str(detail[1]), flush=True)
        super().addFailure(case, detail)

    def addSkip(self, case, reason):
        super().addSkip(case, reason)
        print('IMRE_WIDE_VERDICT', 'SKIP', case.id(), flush=True)
        print('IMRE_WIDE_DETAIL', case.id(), 'SkipTest', reason, flush=True)


support.use_resources = {}
module = select(sys.argv[1])
loader = unittest.TestLoader()
suite = loader.loadTestsFromModule(module)
if loader.errors:
    for error in loader.errors:
        print('IMRE_WIDE_LOADER_ERROR', error, flush=True)
    raise RuntimeError('original suite loading failed')
for group in suite:
    for case in group:
        print('IMRE_WIDE_ID', case.id(), flush=True)
print('IMRE_WIDE_DISCOVERED', suite.countTestCases(), flush=True)
result = Result()
suite.run(result)
print('IMRE_WIDE_RAN', result.testsRun, flush=True)
if not result.wasSuccessful():
    raise SystemExit(1)
