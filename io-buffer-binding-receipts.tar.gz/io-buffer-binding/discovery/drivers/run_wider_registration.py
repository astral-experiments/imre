import sys
import unittest
from test import support


def select(name):
    if name == 'test_fileio':
        from test import test_fileio
        return test_fileio
    if name == 'test_memoryio':
        from test import test_memoryio
        return test_memoryio
    if name == 'test_file':
        from test import test_file
        return test_file
    if name == 'test_univnewlines':
        from test import test_univnewlines
        return test_univnewlines
    if name == 'test_largefile':
        from test import test_largefile
        return test_largefile
    if name == 'test_bufio':
        from test import test_bufio
        return test_bufio
    raise ValueError(name)


def discover(name):
    print('IMRE_REG_BEGIN', name, flush=True)
    module = select(name)
    print('IMRE_REG_IMPORTED', name, flush=True)
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(module)
    if loader.errors:
        for error in loader.errors:
            print('IMRE_REG_LOADER_ERROR', name, error, flush=True)
        raise RuntimeError('original suite loading failed')
    for group in suite:
        for case in group:
            print('IMRE_REG_ID', name, case.id(), flush=True)
    print('IMRE_REG_DISCOVERED', name, suite.countTestCases(), flush=True)


support.use_resources = {}
names = ['test_fileio', 'test_memoryio', 'test_file', 'test_univnewlines', 'test_largefile', 'test_bufio']
if len(sys.argv) == 2:
    names = [sys.argv[1]]
failures = 0
for name in names:
    try:
        discover(name)
    except Exception as error:
        print('IMRE_REG_ERROR', name, type(error).__name__, str(error), flush=True)
        failures += 1
print('IMRE_REG_DONE', len(names), failures, flush=True)
if failures:
    raise SystemExit(1)
