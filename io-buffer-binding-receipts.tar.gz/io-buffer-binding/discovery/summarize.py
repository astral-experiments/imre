"""Attribute one shared discovery attempt to its expected CPython occurrence denominator."""
from collections import Counter
import csv
import hashlib
import json
import sys
import re
import signal
from pathlib import Path

root=Path(__file__).resolve().parent
oracle=root/"oracle/regrtest-default"
expected=json.loads((oracle/"ordered-cases.json").read_text())
oracle_summary=json.loads((oracle/"summary.json").read_text())
out=root/"native"/sys.argv[1]
provenance=json.loads((out/"provenance.json").read_text())
rows=json.loads((out/"runs.json").read_text())
assert len(rows)==4 and len(expected)==oracle_summary["denominator"]
assert hashlib.sha256((oracle/"ordered.ids").read_bytes()).hexdigest()==provenance["expected_ordered_ids_sha256"]
ledger=out/"denominator-ledger.tsv"
with ledger.open("w") as stream:
    writer=csv.writer(stream,delimiter="\t",lineterminator="\n")
    labels=[r["mode"]+".O"+str(r["level"]) for r in rows]
    writer.writerow(["oracle_index","occurrence","id","fixture_group","cpython_regrtest","cpython_skip_reason",*labels])
    seen={}
    for label,measure in zip(labels,rows):
        raw=out/label/"observed.ids"
        seen[label]=Counter(raw.read_text().splitlines()) if raw.exists() and measure["observed_id_lines"] else Counter()
    for case in expected:
        states=[]
        for label,measure in zip(labels,rows):
            has_id=case["occurrence"]<=seen[label][case["id"]]
            states.append("DISCOVERED_NO_VERDICT" if has_id else "UNREACHED")
        writer.writerow([case["index"],case["occurrence"],case["id"],case["group"],case["reference_verdict"],case.get("reference_reason",""),*states])
summary=[]
for measure in rows:
    label=f'{measure["mode"]}.O{measure["level"]}'
    build,proc=measure["build"],measure["process"]
    origin=proc if proc else build
    diag=(root/origin["stderr"]).read_text(errors="replace").splitlines()
    frames=[m for line in diag if (m:=re.match(r'\s*File "([^"]+)", line (\d+)', line))]
    last_location=f"{Path(frames[-1].group(1)).name}:{frames[-1].group(2)}" if frames else None
    diagnostic = diag[-1] if diag and origin["exit"] != 0 else ""
    if origin["timed_out"]:
        diagnostic = "Timed out"
    elif origin["exit"] is not None and origin["exit"] < 0:
        signal_name = signal.Signals(-origin["exit"]).name
        diagnostic = f"{signal_name} (signal {-origin['exit']})" + (f". {diagnostic}" if diagnostic else ". Native process emitted no stderr.")
    summary.append({"last_traceback_source":last_location,"mode":measure["mode"],"level":measure["level"],
                    "build_exit":build["exit"],"build_s":build["elapsed_s"],"process_exit":proc["exit"] if proc else None,
                    "process_s":proc["elapsed_s"] if proc else None,"expected_occurrences":len(expected),
                    "discovered_expected_occurrences":sum(min(n,seen[label][ident]) for ident,n in Counter(c["id"] for c in expected).items()),
                    "native_unittest_executions":0,"ordered_ids_match":measure["discovery_complete"],
                    "diagnostic":diagnostic,
                    "raw_record":str((out/label/"result.json").relative_to(root))})
(out/"summary.json").write_text(json.dumps({"imre_commit":provenance["imre_commit"],
     "oracle_ordered_ids_sha256":oracle_summary["ordered_ids_sha256"],"runs":summary},indent=2)+"\n")
print(sys.argv[1],len(expected),"expected IDs;",[(r["mode"],r["level"],r["discovered_expected_occurrences"],r["build_exit"],r["process_exit"]) for r in summary])

