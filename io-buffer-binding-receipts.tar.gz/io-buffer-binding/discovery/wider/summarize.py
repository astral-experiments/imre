"""Reconcile the 667 intact discovery rows and 371 extra original cases by exact ID."""
from collections import Counter
import csv
import json
from pathlib import Path
import sys

here=Path(__file__).resolve().parent
label=sys.argv[1];out=here/'native'/label
reference=json.loads((here/'oracle/ordered-cases.json').read_text());assert len(reference)==1038
lanes=['ordinary.O0','ordinary.O3','boxed.O0','boxed.O3'];allstates={};coverage={}
for lane in lanes:
    first=here.parent/'native'/label/lane
    first_record=json.loads((first/'result.json').read_text());first_ids=set((first/'observed.ids').read_text().splitlines()) if (first/'observed.ids').is_file() else set()
    states={};groups={};records=[]
    for name in dict.fromkeys(row['module'] for row in reference):
        goals=[row['id'] for row in reference if row['module']==name];status={};diagnostic='';build=None;process=None;fixture_events=[]
        if name=='test.test_io':
            status={k:'DISCOVERED_NO_VERDICT' for k in first_ids};build=first_record['build'];process=first_record['process'];raw=first/'result.json'; diagnostic=(here.parent/(process or build)['stderr']).read_text(errors='replace').splitlines()[-1:];count=first_record['observed_id_lines'];ran=0
        else:
            p=out/lane/name.split('.')[1];build=json.loads((out/lane/'build.json').read_text());raw=p/'summary.json';count=0;ran=None
            if raw.exists():
                record=json.loads(raw.read_text());process=record['process'];observed=(p/'observed.ids').read_text().splitlines();count=len(observed);ran=record['reported_tests_run'];diagnostic=record['last_diagnostic'];assert len(observed)==len(set(observed));status={k:'DISCOVERED_NO_VERDICT' for k in observed}
                for v,k in record['events']:
                    if k in goals:
                        assert k in status and status[k]=='DISCOVERED_NO_VERDICT', (name,k,v,status.get(k));status[k]=v
                    else: fixture_events.append([v,k])
            else:
                assert build['exit']!=0;raw=out/lane/'build.json';diagnostic=(out/lane/'build.stderr').read_text(errors='replace').splitlines()[-1:]
        assert set(status).issubset(goals),(name,set(status)-set(goals))
        for k in goals:states[k]=status.get(k,'UNREACHED')
        groups[name]={'expected':len(goals),'discovered':count,'tests_run_reported':ran,'events':dict(Counter(states[x] for x in goals)),'fixture_events':fixture_events,'build_exit':build['exit'],'process_exit':process['exit'] if process else None,'last_diagnostic':diagnostic,'raw_record':str(raw.relative_to(here.parent))}
    assert len(states)==1038;allstates[lane]=states;coverage[lane]={'status_counts':dict(Counter(states.values())),'groups':groups}
with (out/'denominator-ledger.tsv').open('w') as stream:
    writer=csv.writer(stream,delimiter='\t',lineterminator='\n');fields=['index','occurrence','id','module','reference_verdict','reference_reason'];writer.writerow(fields+lanes)
    for row in reference:writer.writerow([row[k] for k in fields]+[allstates[l][row['id']] for l in lanes])
(out/'summary.json').write_text(json.dumps({'label':label,'denominator':1038,'reference_order_sha256':json.loads((here/'oracle/summary.json').read_text())['ordered_ids_sha256'],'tracks':coverage,'scope':'test_io runs unchanged discovery. Other six modules run their original suites through unittest.TestSuite.run after recording discovery. UNREACHED records no observed ID or verdict.'},indent=2)+'\n')
for l in lanes:print(label,l,coverage[l]['status_counts'])
