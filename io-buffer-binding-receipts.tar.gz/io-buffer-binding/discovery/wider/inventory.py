"""Compare exact pinned unittest discovery with the seven-module regrtest JUnit results."""
from collections import Counter
import hashlib
import importlib
import json
from pathlib import Path
import sys
import unittest
import xml.etree.ElementTree as ET
from test import support

assert sys.version_info[:3] == (3,14,5)
support.use_resources = {}
here = Path(__file__).resolve().parent / 'oracle'
root = Path('/workspace/scratch/cpython/Lib')
expected = {'test.test_io':667,'test.test_fileio':99,'test.test_memoryio':182,'test.test_file':36,'test.test_univnewlines':34,'test.test_largefile':16,'test.test_bufio':4}
sha = lambda data: hashlib.sha256(data).hexdigest()

def flatten(suite):
    for x in suite:
        if isinstance(x, unittest.TestCase): yield x
        else: yield from flatten(x)

xml = ET.parse(here/'regrtest.xml'); junit = xml.findall('.//testcase'); ids=[row.get('name') for row in junit];modules=list(dict.fromkeys('.'.join(x.split('.')[:2]) for x in ids));assert set(modules)==set(expected)
summary={};rows=[];seen=Counter();outcomes=Counter()
for modname in modules:
    mod = importlib.import_module(modname);src=Path(mod.__file__).resolve();assert src.is_relative_to(root)
    loader=unittest.TestLoader();suite=loader.loadTestsFromModule(mod);assert not loader.errors
    cases=list(flatten(suite));ordered=[c.id() for c in cases];assert len(cases)==suite.countTestCases()==expected[modname];assert ordered==[x for x in ids if x.startswith(modname+'.')]
    per=Counter()
    for case,item in zip(cases,junit[len(rows):],strict=False):
        assert item.get('name')==case.id();assert item.find('error') is None and item.find('failure') is None
        skip=item.find('skipped');tag='SKIP' if skip is not None else 'PASS';reason=skip.get('message') if skip is not None else None;per[tag]+=1;outcomes[tag]+=1;seen[case.id()]+=1
        rows.append({'index':len(rows)+1, 'module':modname,'id':case.id(),'occurrence':seen[case.id()],'group':case.__class__.__qualname__,'reference_verdict':tag,'reference_reason':reason})
    summary[modname]={'count':len(ordered),'unique_ids':len(set(ordered)),'sha256':sha(src.read_bytes()),'source':str(src),'ordered_ids_sha256':sha(('\n'.join(ordered)+'\n').encode()),'reference_verdicts':dict(per)}
assert [r['id'] for r in rows]==ids;assert len(ids)==len(set(ids))==1038
bytes_ids=('\n'.join(ids)+'\n').encode();(here/'ordered.ids').write_bytes(bytes_ids)
(here/'ordered-cases.json').write_text(json.dumps(rows,indent=2)+'\n')
report={'cpython_commit':'5607950ef232dad16d75c0cf53101d9649d89115','version':sys.version,'denominator':len(ids),'unique_ids':len(set(ids)),'ordered_ids_sha256':sha(bytes_ids),'reference_verdicts':dict(outcomes),'original_modules_in_regrtest_order':modules,'modules':summary,'corroborating_public_source':'https://github.com/astral-experiments/imre/pull/3091','reference_order':'Pinned regrtest --single-process --randseed 1. Original loadTestsFromModule order cross-checked per entry.'}
(here/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print('wide oracle',len(ids),dict(outcomes),report['ordered_ids_sha256'])
