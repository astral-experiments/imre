"""End the original baseline execution queue after its one budgeted lane has finished."""
import json
import os
from pathlib import Path
import signal
import time

base=Path(__file__).resolve().parent/'native/public-922b215'
args=['python3','-B','wider/run_native.py','public-922b215','/workspace/scratch/bin-io-buffer-base','922b21506bf57f399cf2356f9803906b1f0d55a4']
def argv(p):
    try:return (p/'cmdline').read_bytes().decode().strip('\x00').split('\x00')
    except (OSError,UnicodeError):return []
worker,=[x for x in Path('/proc').glob('[0-9]*') if argv(x)==args]
while not (base/'ordinary.O0/suite-results.json').is_file():
    if argv(worker)!=args:raise RuntimeError('baseline worker exited before bounded lane completed')
    time.sleep(0.25)
# The supervisor originally queued four execution lanes. Release gating now uses
# pure registration for each lane. Stop only this exact supervisor and its own
# next-lane compiler, if it has started; prior native processes have returned.
if argv(worker)==args:
    pid=int(worker.name);os.kill(pid,signal.SIGSTOP)
    children=[]
    for entry in Path('/proc').glob('[0-9]*'):
        try: ppid=int((entry/'stat').read_text().rsplit(')',1)[1].split()[1])
        except (OSError,ValueError,IndexError): continue
        if ppid==pid: children.append(entry.name)
    for child in children:
        c=int(child);cmd=argv(Path('/proc')/child)
        assert cmd and cmd[0]=='/workspace/scratch/bin-io-buffer-base/imre' and cmd[1]=='build' and '/workspace/scratch/io-buffer-bind-discovery/Lib/run_wider_io.py' in cmd
        assert os.getpgid(c)==c;os.killpg(c,signal.SIGTERM)
    os.kill(pid,signal.SIGTERM);os.kill(pid,signal.SIGCONT)
result={'planned_lane':'ordinary.O0','scope':'six additional whole suites, one process per module, 300-second per-suite limit','reason':'subsequent lanes are covered by registration-only primary gate; unattempted supplementary runs have no method verdicts','completed_suites':json.loads((base/'ordinary.O0/suite-results.json').read_text())}
(base/'supplementary-final.json').write_text(json.dumps(result,indent=2)+'\n')
