"""Run each non-test_io module in its own process and working directory at each level."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
scratch=Path('/workspace/scratch')
work=scratch/'io-buffer-bind-discovery'
entry=work/'Lib/run_wider_io.py'
label, bindir, commit, *selected=sys.argv[1:]
assert label=='oracle' or (Path(bindir)/'READY').read_text().strip()==commit
modes=selected or ['ordinary.O0','boxed.O0','ordinary.O3','boxed.O3']
base=here/('native/'+label if label!='oracle' else 'oracle/direct-driver');base.mkdir(parents=True,exist_ok=True)
ref=json.loads((here/'oracle/ordered-cases.json').read_text());mods=['test_fileio','test_memoryio','test_file','test_univnewlines','test_largefile','test_bufio'];assert sum(1 for i in ref if i['module']!='test.test_io')==371
expected={name:[i for i in ref if i['module']=='test.'+name] for name in mods}
env={k:v for k,v in os.environ.items() if not k.startswith(('IMRE','PYTHON'))};resource.setrlimit(resource.RLIMIT_CORE,(0,0))
def dump(file,value):file.write_text(json.dumps(value,indent=2)+'\n')
def digest(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,cwd,log,name,env,timeout):
    argv=list(map(str,cmd));start=time.monotonic();timed=False
    with (log/(name+'.stdout')).open('wb') as out,(log/(name+'.stderr')).open('wb') as err:
        proc=subprocess.Popen(argv,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
        try:proc.wait(timeout)
        except subprocess.TimeoutExpired:
            import signal
            timed=True;os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    record={'argv':argv,'cwd':str(cwd),'exit':proc.returncode,'timed_out':timed,'elapsed_s':round(time.monotonic()-start,3)}
    dump(log/(name+'.json'),record);return record
assert digest(entry)==digest(here.parent/'drivers'/entry.name)
source={}
for name in mods:
    path=entry.parent/'test'/(name+'.py');assert digest(path)==digest(scratch/'cpython/Lib/test'/(name+'.py'));source[name]=digest(path)
prov={'imre_commit':commit,'source_sha256':source,'driver_sha256':digest(entry),'cpython_commit':'5607950ef232dad16d75c0cf53101d9649d89115'}
compiler=Path(bindir)/'imre';runtime=Path(bindir)/'libimre_runtime.a';
if label!='oracle':prov.update(compiler_sha256=digest(compiler),runtime_sha256=digest(runtime))
dump(base/'provenance.json',prov)
for lane in (modes if label!='oracle' else ['cpython']):
    local=work/'wider'/label/lane;local.mkdir(parents=True,exist_ok=True);logs=base/lane;logs.mkdir(exist_ok=True);exe=local/'driver';
    if label!='oracle':
        mode,opt=lane.split('.');cmd=[compiler,'build',entry,'--module-root',entry.parent,'--no-cache','--runtime',runtime,'--clang',scratch/'tools/clang','--opt-level',opt[1:],'-o',exe];cmd+=['--runtime-imports'] if mode=='boxed' else []
        build=run(cmd,local,logs,'build',dict(env,TMPDIR=str(local)),1200);print(label,lane,'build',build['exit'],build['elapsed_s'],flush=True)
        if build['exit']:continue
        (logs/'exe.sha256').write_text(digest(exe)+'\n')
    rows=[]
    for mod in mods:
        wd=local/mod;wd.mkdir(exist_ok=True);log=logs/mod;log.mkdir(exist_ok=True);active=dict(env,TMPDIR=str(wd))
        if label=='oracle': active['PYTHONPATH']=str(scratch/'cpython/Lib');cmd=[scratch/'cpytools/bin/python3.14','-B','-X','frozen_modules=off',entry,mod]
        else:cmd=[exe,mod]
        proc=run(cmd,wd,log,'process',active,300);lines=(log/'process.stdout').read_text(errors='replace').splitlines();ids=[x.split(' ',1)[1] for x in lines if x.startswith('IMRE_WIDE_ID ')];goals=[r['id'] for r in expected[mod]];events=[x.split(' ',2)[1:] for x in lines if x.startswith('IMRE_WIDE_VERDICT ')];collected=set(ids);verdicts={i:v for v,i in events if i in goals}; cb=dict(Counter(verdicts.values()));c=[x for x in lines if x.startswith('IMRE_WIDE_DISCOVERED ')];rn=[x for x in lines if x.startswith('IMRE_WIDE_RAN ')];record={'module':'test.'+mod,'expected':len(goals),'discovered_count':len(ids),'discovery_matches_reference':ids==goals and c==['IMRE_WIDE_DISCOVERED '+str(len(goals))],'reported_tests_run':int(rn[-1].split()[-1]) if rn else None,'verified_native_events':cb,'outside_expected_ids':[i for _,i in events if i not in goals],'process':proc,'last_diagnostic':(log/'process.stderr').read_text(errors='replace').splitlines()[-2:], 'events':events}
        if label=='oracle': assert record['discovery_matches_reference'] and proc['exit']==0 and verdicts=={r['id']:r['reference_verdict'] for r in expected[mod]},record
        rows.append(record);dump(log/'summary.json',record);(log/'observed.ids').write_text(''.join(s+'\n' for s in ids));print(label,lane,mod,len(ids),cb,proc['exit'],flush=True)
    dump(logs/'suite-results.json',rows);exe.unlink(missing_ok=True)
