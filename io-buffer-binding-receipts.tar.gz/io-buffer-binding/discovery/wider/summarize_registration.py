"""Reconcile the 667 intact entry and the six additional original registration attempts."""
from collections import Counter
import csv
import json
from pathlib import Path
import sys

here=Path(__file__).resolve().parent
label=sys.argv[1];base=here/'registration'/label
oracle=json.loads((here/'oracle/ordered-cases.json').read_text());modules=list(dict.fromkeys(r['module'] for r in oracle));goals={m:[r['id'] for r in oracle if r['module']==m] for m in modules}
tracks={};states={};lanes=('ordinary.O0','ordinary.O3','boxed.O0','boxed.O3')
for lane in lanes:
    extras=json.loads((base/lane/'registrations.json').read_text());build=json.loads((base/lane/'build.json').read_text());mods={};state={}
    for m in modules:
        if m=='test.test_io':
            loc=here.parent/'native'/label/lane;raw=loc/'result.json';r=json.loads(raw.read_text());p=r['process'];src=loc/'observed.ids';ids=src.read_text().splitlines() if src.exists() else []
            measured=p is not None;match=r['discovery_complete'];c=len(ids) if match else None
            lines=(here.parent/(p or r['build'])['stderr']).read_text(errors='replace').splitlines();detail=lines[-2:];be=r['build']['exit'];pe=p['exit'] if p else None
            # The original driver lacks a standalone import marker.
            known_import=True if (ids or match) else None
        elif m not in extras:
            raw=base/lane/'build.json';ids=[];c=None;match=False;detail=(base/lane/'build.stderr').read_text(errors='replace').splitlines()[-2:];be=build['exit'];pe=None;known_import=None;measured=False
        else:
            r=extras[m];raw=base/r['process_record'];proc=json.loads(raw.read_text());ids=r['ids'];c=r['reported_count'];match=r['order_matches_reference'];measured=r['attempted'];known_import=r['imported'] if measured else None
            detail=r['diagnostics'] or (raw.with_suffix('.stderr').read_text(errors='replace').splitlines()[-2:] if not match else []);be=build['exit'];pe=proc['exit']
        remaining=Counter(ids);expected=goals[m]
        for i in expected:
            state[i]='DISCOVERED_NO_VERDICT' if remaining[i]>0 else 'UNREACHED'
            if remaining[i]>0:remaining[i]-=1
        mods[m]={'expected':len(expected),'attempted':measured,'imported':known_import,'reported_count':c,'observed_ids':len(ids),'expected_ids_observed':sum(state[i]=='DISCOVERED_NO_VERDICT' for i in expected),'order_matches_reference':match,'unexpected_ids':dict(+remaining),'methods_executed':0,'diagnostics':detail,'build_exit':be,'process_exit':pe,'raw_record':str(raw.relative_to(here.parent))}
    states[lane]=state;tracks[lane]={'expected':len(oracle),'modules_attempted':sum(m['attempted'] for m in mods.values()),'modules_imported_known':sum(m['imported'] is True for m in mods.values()),'methods_executed':0,'states':dict(Counter(state.values())),'modules':mods}
with (base/'denominator-ledger.tsv').open('w') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n');fields=['index','occurrence','id','module','reference_verdict','reference_reason'];w.writerow(fields+list(lanes))
    for r in oracle:w.writerow([r[k] for k in fields]+[states[l][r['id']] for l in lanes])
(base/'summary.json').write_text(json.dumps({'label':label,'imre_commit':json.loads((base/'provenance.json').read_text())['imre_commit'],'denominator':1038,'reference_order_sha256':json.loads((here/'oracle/summary.json').read_text())['ordered_ids_sha256'],'tracks':tracks,'scope':'Original-registration discovery only. Separate execution receipts live under wider/native.'},indent=2)+'\n')
for l in lanes:print(label,l,tracks[l]['states'],flush=True)
