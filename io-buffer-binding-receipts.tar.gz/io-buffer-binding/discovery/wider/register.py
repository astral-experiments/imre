"""Register six original modules with one binary per lane, retrying unreached imports independently."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
WORK = Path('/workspace/scratch/io-buffer-bind-discovery')
ENTRY = WORK / 'Lib/run_wider_registration.py'
NAMES = ('test_fileio','test_memoryio','test_file','test_univnewlines','test_largefile','test_bufio')
label, bins, commit = sys.argv[1:4]
lanes = sys.argv[4:] or ['ordinary.O0','boxed.O0','ordinary.O3','boxed.O3']
bindir = Path(bins)
assert (bindir/'READY').read_text().strip() == commit
out = HERE/'registration'/label;out.mkdir(parents=True,exist_ok=True)
expected = json.loads((HERE/'oracle/ordered-cases.json').read_text())
reference = {n:[r['id'] for r in expected if r['module']=='test.'+n] for n in NAMES}
assert sum(map(len,reference.values())) == 371
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env = {k:v for k,v in os.environ.items() if not k.startswith(('IMRE','PYTHON'))}

def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')

def call(cmd,cwd,logs,name):
    argv=list(map(str,cmd));timed=False;start=time.monotonic()
    with (logs/(name+'.stdout')).open('wb') as std,(logs/(name+'.stderr')).open('wb') as err:
        child=subprocess.Popen(argv,cwd=cwd,env=dict(env,TMPDIR=str(cwd)),stdout=std,stderr=err,start_new_session=True)
        try:child.wait(int(os.environ.get("IO_REGISTRATION_TIMEOUT", "1200")))
        except subprocess.TimeoutExpired:
            timed=True;os.killpg(child.pid,signal.SIGKILL);child.wait()
    result={'argv':argv,'cwd':str(cwd),'exit':child.returncode,'timed_out':timed,'elapsed_s':round(time.monotonic()-start,3)}
    dump(logs/(name+'.json'),result);return result

def extract(logs,name):
    lines=(logs/'process.stdout').read_text(errors='replace').splitlines();prefix='IMRE_REG_ID '+name+' ';ids=[x[len(prefix):] for x in lines if x.startswith(prefix)]
    count=[int(x.split(' ',2)[-1]) for x in lines if x.startswith('IMRE_REG_DISCOVERED '+name+' ')];errors=[x for x in lines if x.startswith(('IMRE_REG_ERROR '+name+' ','IMRE_REG_LOADER_ERROR '+name+' '))]
    return {'module':'test.'+name,'attempted':'IMRE_REG_BEGIN '+name in lines,'imported':'IMRE_REG_IMPORTED '+name in lines,'ids':ids,'reported_count':count[0] if count else None,'expected':len(reference[name]),'order_matches_reference':ids==reference[name] and count==[len(ids)],'diagnostics':errors,'tests_run':0,'process_record':str((logs/'process.json').relative_to(out))}

assert sha(ENTRY)==sha(HERE.parent/'drivers'/ENTRY.name)
source={n:sha(ENTRY.parent/'test'/(n+'.py')) for n in NAMES}
assert all(source[n]==sha(Path('/workspace/scratch/cpython/Lib/test')/(n+'.py')) for n in NAMES)
compiler=bindir/'imre';runtime=bindir/'libimre_runtime.a'
provenance={'imre_commit':commit,'compiler':str(compiler),'compiler_sha256':sha(compiler),'runtime':str(runtime),'runtime_sha256':sha(runtime),'cpython_commit':'5607950ef232dad16d75c0cf53101d9649d89115','entry_sha256':sha(ENTRY),'original_sha256':source}
if (out/'provenance.json').exists():
    assert json.loads((out/'provenance.json').read_text()) == provenance
else:
    dump(out/'provenance.json',provenance)

def lane_run(lane):
    mode,level=lane.split('.');root=Path(os.environ.get('IO_REGISTRATION_WORK',WORK))/'registration'/label/lane;root.mkdir(parents=True,exist_ok=True);logs=out/lane;logs.mkdir(exist_ok=True);exe=root/'driver'
    argv=[compiler,'build',ENTRY,'--module-root',ENTRY.parent,'--no-cache','--runtime',runtime,'--clang','/workspace/scratch/tools/clang','--opt-level',level[1:],'-o',exe]
    if mode=='boxed':argv+=['--runtime-imports']
    compiler_result=call(argv,root,logs,'build');print(label,lane,'build',compiler_result['exit'],compiler_result['elapsed_s'],flush=True)
    if compiler_result['exit']:dump(logs/'registrations.json',{});return
    (logs/'exe.sha256').write_text(sha(exe)+'\n');result_dir=logs/'all';result_dir.mkdir(exist_ok=True);result=call([exe],root,result_dir,'process');registry={}
    for n in NAMES:
        item=extract(result_dir,n)
        if not item['attempted']:
            trial=logs/n;trial.mkdir(exist_ok=True);cwd=root/n;cwd.mkdir(exist_ok=True);call([exe,n],cwd,trial,'process');item=extract(trial,n)
        registry['test.'+n]=item
    dump(logs/'registrations.json',registry);exe.unlink(missing_ok=True)
    print(label,lane,'process',result['exit'],result['elapsed_s'],[(n,r['imported'],len(r['ids'])) for n,r in registry.items()],flush=True)

with ThreadPoolExecutor(max_workers=int(os.environ.get("IO_REGISTRATION_JOBS", "2"))) as workers:list(workers.map(lane_run,lanes))
