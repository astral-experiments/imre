# CPython I/O campaign inventory

The public campaign recorded 1,038 registrations across seven original entries. The pinned CPython 3.14.5 interpreter independently collected and ran the following seven modules. Every ordered ID within each module matched `unittest.TestLoader.loadTestsFromModule`, including the original `test_io.load_tests` hook. The seven-module regrtest used `--single-process --randseed 1` with default resources and recorded 1,038 unique IDs, 1,009 passes and 29 skips. [Campaign count](https://github.com/astral-experiments/imre/pull/3091) · [Pinned CPython](https://github.com/python/cpython/tree/5607950ef232dad16d75c0cf53101d9649d89115)

| Original module | IDs | Pass | Skip |
|---|---:|---:|---:|
| `test.test_io` | 667 | 649 | 18 |
| `test.test_fileio` | 99 | 96 | 3 |
| `test.test_memoryio` | 182 | 182 | 0 |
| `test.test_file` | 36 | 34 | 2 |
| `test.test_univnewlines` | 34 | 34 | 0 |
| `test.test_largefile` | 16 | 10 | 6 |
| `test.test_bufio` | 4 | 4 | 0 |

The 667-entry `test_io` oracle has its own regrtest XML, manifest of fixture and method identities, and ordered-ID SHA-256 `e82addd026e03cd24b66534764472806847401dcffaaa392bab2081fb70cdab4`. The seed-1 run across all seven has ordered-ID SHA-256 `a36ef3e564b1fc39d7a3d145f47e76faed1dfc96550e8a4b83830d0c8bef8507`. The six additional modules contribute 371 IDs, 360 reference passes and 11 skips. Running the separate six-module native driver on CPython matched every reference verdict before its use with Imre. [667 manifest](oracle/regrtest-default/summary.json) · [1,038 manifest](wider/oracle/summary.json) · [Seven-module regrtest receipt](wider/oracle/regrtest-run.json)

Each native configuration measures registration in two runs. One attempts the intact `test_io` fixture and its 667 IDs. The other imports the six additional modules and invokes their original unittest discovery in one process. If a process stops before a module starts, the driver retries that module separately. Each of the four ordinary and forced-boxed configurations at `-O0` and `-O3` has its own 1,038-row ledger. An emitted original ID is `DISCOVERED_NO_VERDICT` and an expected ID absent from the discovery output is `UNREACHED`. These registration runs execute zero test methods.

A supplementary baseline run at ordinary `-O0` executed each of the six additional original suites in its own process, through its original `TestSuite.run`, with default resources and a 300-second limit per suite. It recorded 161 passes, 12 skips, 3 failures and 99 errors, plus 96 registered IDs with no completed verdict. Five processes timed out and one completed with exit 1. The execution ledger and raw process receipts are separate from the registration measurements. [Supplementary summary](wider/native/public-922b215/supplementary-final.json) · [371-ID execution ledger](wider/native/public-922b215/ordinary.O0/371-ledger.tsv)
