# Focused BufferedReader binding evidence

CPython 3.14.5 at `5607950ef232dad16d75c0cf53101d9649d89115` supplies the oracle. These local positions are one-based in its 667-ID unmodified `test_io.load_tests` ordering. The cross-campaign 1,038-entry inventory is separate.

| Local occurrence | Exact selector |
| --- | --- |
| [603](generator/ordered.ids#L603) | `test.test_io.CMiscIOTest.test_abc_inheritance` |
| [604](generator/ordered.ids#L604) | `test.test_io.CMiscIOTest.test_abc_inheritance_official` |
| [605](generator/ordered.ids#L605) | `test.test_io.CMiscIOTest.test_abcs` |
| [626](generator/ordered.ids#L626) | `test.test_io.PyMiscIOTest.test_abc_inheritance` |
| [627](generator/ordered.ids#L627) | `test.test_io.PyMiscIOTest.test_abc_inheritance_official` |
| [628](generator/ordered.ids#L628) | `test.test_io.PyMiscIOTest.test_abcs` |

The focused projection retains upstream lines 1–49, all source for the original fixture mocks, the real `_pyio`, both subclass declarations and class attributes, all six methods, their common helper, the original teardown, and inherited unittest lifecycle. The selector runs one genuine loader and one suite. The only change inside upstream `load_tests` narrows the first tuple to the two selected original classes. All fixture namespace construction, mock lookup, attachment, and suite construction after that tuple are byte-identical to upstream, preserving line numbers. Generation compares the retained method code and global bindings, fixture exports, lifecycle and skip flags with intact CPython. [Source spans and file hashes](generator/source-receipt.json) · [Original methods](https://github.com/python/cpython/blob/5607950ef232dad16d75c0cf53101d9649d89115/Lib/test/test_io.py#L4467-L4498) · [Original hook](https://github.com/python/cpython/blob/5607950ef232dad16d75c0cf53101d9649d89115/Lib/test/test_io.py#L5075-L5111)

CPython passed the six selectors both from the intact test module and from the projection. In the separate descriptor reference, a real binary file accepted bound and unbound reads. Calling `io.BufferedReader.read` on object(), None, a FileIO or a BytesIO raised TypeError, as did omitting the receiver. [Intact unittest output](runs/cpython/intact/cpython-O0/selected-six.stdout) · [Projected unittest output](runs/cpython/misc-group/cpython-O0/selected-six.stdout) · [Descriptor output](runs/cpython/wrong-receiver/cpython-O0/descriptor.stdout)

A reported unittest verdict requires that the six exact IDs were selected in order and that unittest recorded six executions. A failed import or fixture is one shared process failure before any of these six methods executes. When the module imports and the hook fails, the driver then lists missing real exports from both modules to distinguish the first error from later dependencies. This diagnostic runs after the loader has failed and does not mutate either module or any fixture.

Each lane records exact arguments, commit, binary digests, working directory, elapsed time, process status and streams. An ordinary build uses default routing. A forced boxed build adds `--runtime-imports`. The selectors use the complete public namespace from `io.__all__` in both modes. The receipt for a native build identifies whether execution reached the loader, suite, or method. Independent intact unfiltered native discovery is in the sibling discovery packet. [Measurement harness](measure.py) · [Raw receipts](runs)

## Actual reader fixture

The `reader-prefix` control uses the complete original `CBufferedReaderTest`, `PyBufferedReaderTest` and their bases. Every byte of the first 1,859 upstream lines is present (67,288 bytes, SHA-256 `b4b93d06153195b41a1d38313e015d4999926e405e0b25b85db14792dd420bcd`). The remainder comes from the verified Misc projection. The retained reader class code objects match intact CPython, and the Misc classes and original fixture attachment match the earlier projection. A dedicated process compares the actual C fixture's `tp` attribute with both public and private `BufferedReader` and with the type of a real file returned by `open(..., "rb")`. It checks bound and unbound reads and the Py fixture's original pure-Python binding. This control adds zero unittest IDs. A separate process uses the same native binary to select the six original Misc IDs. [Source verification](reader/source-receipt.json) · [Driver](reader/module/run.py) · [CPython original fixture](runs/cpython/reader-prefix/cpython-O0/fixture.stdout) · [CPython original suite](runs/cpython/combined-misc/cpython-O0/selected-six.stdout)

The final public driver allows 1,800 seconds per subprocess under shared executor load. Its binary arguments, probe, selector and verdict logic are identical to the guarded harness. The preliminary 54e1504 ordinary O3 build hit its original 600-second budget; its receipt has a null exit and no runtime verdict. [Guarded harness](reader/measure.py) · [Public harness](reader/measure_public.py)

## Merged public results

PR #3673 merged as `ae0e69c4f08a6a859550c18b70ed22509121667d`. On that public build and guarded head `6cd4fc4556aa3f1b256d56cef6cc6a758334dc56`, the original C/Py fixture binding control passes at `-O0` and `-O3` in ordinary and boxed modes. The public baseline failed in the original C class body at line 1804 before these checks could start. The six original Misc cases still have zero native verdicts. In each final lane their separate real loader stops at line 5095 on `io.BufferedWriter`, followed in the missing export inventory by `BufferedRWPair`, `BufferedRandom`, and `IncrementalNewlineDecoder`. All four public resource checks pass per lane. Both Python raw callback overrides remain explicitly unsupported. [Merged PR](https://github.com/astral-experiments/imre/pull/3673) · [Verified comparison](public-focused.json) · [Merged receipts](runs/merged-ae0e69c) · [Resource receipts](constructor/runs/merged-ae0e69c)
