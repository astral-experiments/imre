"""Measure one upstream six-selector unittest group per build."""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
READER = ROOT / 'reader'
GEN = ROOT / 'generator'
PROJ = READER / 'module'
SCRATCH = Path('/workspace/scratch/io-buffer-focused')
CPY = Path('/workspace/scratch/cpytools/bin/python3.14')
LIB = Path('/workspace/scratch/cpython/Lib')
CLANG = Path('/workspace/scratch/tools/clang')
OCC = json.loads((GEN/'source-receipt.json').read_text())['case_ids_and_local_667_positions']
IDS = list(OCC)
def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):
    p.write_text(json.dumps(v,indent=2)+'\n')
def run(cmd,cwd,folder,name):
    args=list(map(str,cmd))
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    timer=time.monotonic()
    env=os.environ.copy()
    for key in ('IMREFLAGS','IMRE_ENCODED_FLAGS','PYTHONPATH'):
        env.pop(key,None)
    env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE='1')
    try:
        p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=1800)
        rc,out,err=p.returncode,p.stdout,p.stderr
    except subprocess.TimeoutExpired as e:
        rc,out,err=None,e.stdout or b'',e.stderr or b''
    so,se=folder/(name+'.stdout'),folder/(name+'.stderr')
    so.write_bytes(out);se.write_bytes(err)
    return dict(argv=args,cwd=str(cwd),utc_start=start,elapsed_s=round(time.monotonic()-timer,6),exit=rc,
                stdout=str(so.relative_to(ROOT)),stderr=str(se.relative_to(ROOT))),out.decode(errors='replace'),err.decode(errors='replace')
def classify(sel,p,out,err):
    lines=out.splitlines()
    if p['exit'] is None: return 'TIMEOUT'
    if p['exit']<0: return 'SIGNAL_'+str(-p['exit'])
    if 'IMRE_GROUP_SELECTED '+sel not in lines: return 'UNREACHED'
    if 'Ran 6 tests in ' not in out+err or p['exit'] not in (0,1): return 'UNCLASSIFIED'
    emitted=[v for v in ('PASS','SKIP','FAIL','ERROR') if f'IMRE_GROUP_VERDICT {sel} {v}' in lines]
    return emitted[0] if len(emitted)==1 else 'UNCLASSIFIED'

ap=argparse.ArgumentParser()
ap.add_argument('label')
ap.add_argument('--bindir',type=Path)
ap.add_argument('--commit')
ap.add_argument('--prefix-only',action='store_true')
ap.add_argument('--jobs',type=int,default=1)
ap.add_argument('--modes',nargs='+',default=['ordinary','boxed'],choices=['ordinary','boxed'])
ap.add_argument('--levels',nargs='+',type=int,default=[0,3],choices=[0,3])
opts=ap.parse_args()
base=ROOT/'runs'/opts.label
base.mkdir(parents=True,exist_ok=True)
source_proof=json.loads((GEN/'source-receipt.json').read_text())
assert list(OCC.values())==[603,604,605,626,627,628]
reader_proof=json.loads((READER/'source-receipt.json').read_text())
for rel,h in reader_proof['files'].items():
    assert sha(PROJ/rel)==h,rel
assert sha(LIB/'test/test_io.py')==source_proof['intact_test_io']
assert sha(LIB/'_pyio.py')==source_proof['input_sha256']['_pyio.py']
inputs={'official_test_io':LIB/'test/test_io.py','official_pyio':LIB/'_pyio.py','projected_test_io':PROJ/'test/test_io.py','projected_pyio':PROJ/'_pyio.py','generator':READER/'prepare.py','source_receipt':READER/'source-receipt.json','previous_source_receipt':GEN/'source-receipt.json','previous_generator':GEN/'prepare.py','ordered_ids':GEN/'ordered.ids','misc_group_driver':PROJ/'run.py','reference_receivers':GEN/'reference_receivers.py','matrix_runner':READER/'measure_public.py'}
prov={'cpython_commit':source_proof['reference_revision'],'reference_binary':str(CPY),'reference_binary_sha256':sha(CPY),
      'canonical_local_occurrences_1based':OCC,'inputs':{k:{'file':str(p),'sha256':sha(p)} for k,p in inputs.items()},
      'imre_commit':opts.commit,'bindir':str(opts.bindir) if opts.bindir else None}
if opts.bindir:
    assert (opts.bindir/'READY').read_text().strip()==opts.commit
    prov.update(compiler_sha256=sha(opts.bindir/'imre'),runtime_sha256=sha(opts.bindir/'libimre_runtime.a'),clang=str(CLANG))
save(base/'provenance-reader-prefix.json',prov)
if opts.bindir and not opts.prefix_only: save(base/'provenance.json',prov)

def measure(job):
    mode,opt=job
    group=base/('misc-group' if opts.bindir else 'combined-misc')/f'{mode}-O{opt}'
    dest=base/'reader-prefix'/f'{mode}-O{opt}'
    dest.mkdir(parents=True,exist_ok=True)
    if not opts.prefix_only: group.mkdir(parents=True,exist_ok=True)
    cwd=SCRATCH/'reader'/opts.label/f'{mode}-O{opt}'
    cwd.mkdir(parents=True,exist_ok=True)
    (cwd/'data.bin').write_bytes(b'abcdef')
    entry=PROJ/'run.py'
    build=exe_hash=None
    if opts.bindir:
        exe=cwd/'suite';exe.unlink(missing_ok=True)
        cmd=[opts.bindir/'imre','build',entry,'--module-root',PROJ,'--no-cache','--runtime',opts.bindir/'libimre_runtime.a','--clang',CLANG,'--opt-level',opt,'-o',exe]
        if mode=='boxed': cmd.append('--runtime-imports')
        build,_,_=run(cmd,cwd,dest if opts.prefix_only else group,'build')
        start=[exe] if build['exit']==0 else None
        if start: exe_hash=sha(exe)
    else:
        start=[CPY,'-I','-B','-c','import runpy,sys; sys.path.insert(0,sys.argv.pop(1)); runpy.run_path(sys.argv.pop(1),run_name="__main__")',PROJ,entry]
    def fixture():
        p=None;verdict='BUILD_ERROR'
        if start:
            p,so,se=run(start+['--reader-fixture'],cwd,dest,'fixture')
            if p['exit']==0 and so.splitlines()==[
                'ORIGINAL_FIXTURE test.test_io CBufferedReaderTest tp_public_private_identity',
                'ORIGINAL_FILE type_matches bound_ab unbound_cd',
                'ORIGINAL_FIXTURE_PASS test.test_io.CBufferedReaderTest zero_unittest_ids']:
                verdict='PASS'
            elif 'line 1804' in se and 'BufferedReader' in se and not so:
                verdict='UNREACHED'
            else: verdict='ERROR'
        save(dest/'receipt.json',dict(kind='reader-prefix',mode=mode,opt=opt,build=build,exe_sha256=exe_hash,imre_commit=opts.commit,process=p,verdict=verdict,unittest_ids=[]))
        print(opts.label,'reader-prefix',mode,opt,verdict,flush=True)
        if not opts.bindir: assert verdict=='PASS'
    def suite():
        p=None;rows=[]
        if start: p,so,se=run(start+IDS,cwd,group,'selected-six')
        for name in IDS:
            status=classify(name,p,so,se) if p else 'BUILD_ERROR'
            lines=(se or so).strip().splitlines() if p else []
            rows.append(dict(selector=name,local_occurrence=OCC[name],verdict=status,process=p,ending=lines[-1] if lines else None))
        save(group/'receipt.json',dict(kind='misc-group',mode=mode,opt=opt,process_scope='one shared original suite',build=build,exe_sha256=exe_hash,cases=rows,imre_commit=opts.commit))
        print(opts.label,'combined-misc',mode,opt,[r['verdict'] for r in rows],flush=True)
        if not opts.bindir: assert p['exit']==0 and [r['verdict'] for r in rows]==['PASS']*6
    if opts.prefix_only:
        fixture()
    else:
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            list(pool.map(lambda f:f(),[fixture,suite]))
    if opts.bindir: exe.unlink(missing_ok=True)
jobs=[(m,n) for n in opts.levels for m in opts.modes] if opts.bindir else [('cpython',0)]
with concurrent.futures.ThreadPoolExecutor(max_workers=opts.jobs) as pool:
    list(pool.map(measure,jobs))
if opts.bindir:
    assert sha(opts.bindir/'imre')==prov['compiler_sha256'] and sha(opts.bindir/'libimre_runtime.a')==prov['runtime_sha256']
