"""Keep the real CPython reader fixture and its original Misc fixture dependencies."""
import ast,hashlib,json,shutil,types
from pathlib import Path
root=Path(__file__).resolve().parent
lib=Path('/workspace/scratch/cpython/Lib'); old=root.parent/'generator/projected'
source=(lib/'test/test_io.py').read_bytes();base=(old/'test/test_io.py').read_bytes()
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha(source)=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
assert sha(base)=='11466b8f5b50472e7275e6b2cba451f77dec66c962927b6a061236b739cf54e9'
tree=ast.parse(source);defs={node.name:node for node in tree.body if isinstance(node,ast.ClassDef)}
end=defs['PyBufferedReaderTest'].end_lineno
assert end==1859 and defs['CBufferedReaderTest'].lineno==1803 and defs['CBufferedReaderTest'].end_lineno==1855
src_lines=source.splitlines(keepends=True); old_lines=base.splitlines(keepends=True)
prefix=b''.join(src_lines[:end]);tail=b''.join(old_lines[end:]);combined=prefix+tail
out=root/'module';out.mkdir(exist_ok=True)
shutil.copytree(old/'test',out/'test',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copyfile(old/'_pyio.py',out/'_pyio.py');shutil.copyfile(root/'run.py',out/'run.py')
(out/'test/test_io.py').write_bytes(combined)
def classes(src):
    return {x.co_name:x for x in compile(src,'test/test_io.py','exec').co_consts if isinstance(x,types.CodeType)}
original=classes(source);measured=classes(combined);prev=classes(base)
for name in ('CBufferedReaderTest','PyBufferedReaderTest','BufferedReaderTest','SizeofTest'):
    assert original[name]==measured[name]
for name in ('load_tests','CMiscIOTest','PyMiscIOTest','MiscIOTest'):
    assert prev[name]==measured[name]
proof={'cpython_commit':'5607950ef232dad16d75c0cf53101d9649d89115','upstream_sha256':sha(source),
       'prefix_lines':[1,end],'prefix_bytes':len(prefix),'prefix_sha256':sha(prefix),
       'unchanged_suffix_from_projected_lines':[end+1,len(src_lines)],'suffix_sha256':sha(tail),
       'combined_sha256':sha(combined),'classes':{n:{'lines':[defs[n].lineno,defs[n].end_lineno],'sha256':sha(b''.join(src_lines[defs[n].lineno-1:defs[n].end_lineno]))} for n in ('CBufferedReaderTest','PyBufferedReaderTest','BufferedReaderTest','SizeofTest')},
       'reader_class_code_objects_equal_to_intact':True,'misc_class_and_hook_code_objects_equal_to_verified_projection':True,
       'files':{str(p.relative_to(out)):sha(p.read_bytes()) for p in sorted(out.rglob('*.py'))}}
(root/'source-receipt.json').write_text(json.dumps(proof,indent=2)+'\n')
print(proof['prefix_bytes'],proof['prefix_sha256'],proof['combined_sha256'])
