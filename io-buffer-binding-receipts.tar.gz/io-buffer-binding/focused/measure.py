"""Measure one upstream six-selector unittest group per build."""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
GEN = ROOT / 'generator'
PROJ = GEN / 'projected'
SCRATCH = Path('/workspace/scratch/io-buffer-focused')
CPY = Path('/workspace/scratch/cpytools/bin/python3.14')
LIB = Path('/workspace/scratch/cpython/Lib')
CLANG = Path('/workspace/scratch/tools/clang')
OCC = json.loads((GEN/'source-receipt.json').read_text())['case_ids_and_local_667_positions']
IDS = list(OCC)
def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):
    p.write_text(json.dumps(v,indent=2)+'\n')
def run(cmd,cwd,folder,name):
    args=list(map(str,cmd))
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    timer=time.monotonic()
    env=os.environ.copy()
    for key in ('IMREFLAGS','IMRE_ENCODED_FLAGS','PYTHONPATH'):
        env.pop(key,None)
    env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE='1')
    try:
        p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=600)
        rc,out,err=p.returncode,p.stdout,p.stderr
    except subprocess.TimeoutExpired as e:
        rc,out,err=None,e.stdout or b'',e.stderr or b''
    so,se=folder/(name+'.stdout'),folder/(name+'.stderr')
    so.write_bytes(out);se.write_bytes(err)
    return dict(argv=args,cwd=str(cwd),utc_start=start,elapsed_s=round(time.monotonic()-timer,6),exit=rc,
                stdout=str(so.relative_to(ROOT)),stderr=str(se.relative_to(ROOT))),out.decode(errors='replace'),err.decode(errors='replace')
def classify(sel,p,out,err):
    lines=out.splitlines()
    if p['exit'] is None: return 'TIMEOUT'
    if p['exit']<0: return 'SIGNAL_'+str(-p['exit'])
    if 'IMRE_GROUP_SELECTED '+sel not in lines: return 'UNREACHED'
    if 'Ran 6 tests in ' not in out+err or p['exit'] not in (0,1): return 'UNCLASSIFIED'
    emitted=[v for v in ('PASS','SKIP','FAIL','ERROR') if f'IMRE_GROUP_VERDICT {sel} {v}' in lines]
    return emitted[0] if len(emitted)==1 else 'UNCLASSIFIED'

ap=argparse.ArgumentParser()
ap.add_argument('label')
ap.add_argument('--bindir',type=Path)
ap.add_argument('--commit')
ap.add_argument('--jobs',type=int,default=1)
ap.add_argument('--modes',nargs='+',default=['ordinary','boxed'],choices=['ordinary','boxed'])
ap.add_argument('--levels',nargs='+',type=int,default=[0,3],choices=[0,3])
opts=ap.parse_args()
base=ROOT/'runs'/opts.label
base.mkdir(parents=True,exist_ok=True)
source_proof=json.loads((GEN/'source-receipt.json').read_text())
assert list(OCC.values())==[603,604,605,626,627,628]
for rel,h in source_proof['input_sha256'].items():
    assert sha(PROJ/rel)==h,rel
assert sha(LIB/'test/test_io.py')==source_proof['intact_test_io']
assert sha(LIB/'_pyio.py')==source_proof['input_sha256']['_pyio.py']
inputs={'official_test_io':LIB/'test/test_io.py','official_pyio':LIB/'_pyio.py','projected_test_io':PROJ/'test/test_io.py','projected_pyio':PROJ/'_pyio.py','generator':GEN/'prepare.py','source_receipt':GEN/'source-receipt.json','ordered_ids':GEN/'ordered.ids','misc_group_driver':PROJ/'run.py','reference_receivers':GEN/'reference_receivers.py','matrix_runner':ROOT/'measure.py'}
prov={'cpython_commit':source_proof['reference_revision'],'reference_binary':str(CPY),'reference_binary_sha256':sha(CPY),
      'canonical_local_occurrences_1based':OCC,'inputs':{k:{'file':str(p),'sha256':sha(p)} for k,p in inputs.items()},
      'imre_commit':opts.commit,'bindir':str(opts.bindir) if opts.bindir else None}
if opts.bindir:
    assert (opts.bindir/'READY').read_text().strip()==opts.commit
    prov.update(compiler_sha256=sha(opts.bindir/'imre'),runtime_sha256=sha(opts.bindir/'libimre_runtime.a'),clang=str(CLANG))
save(base/'provenance.json',prov)

def measure(job):
    kind,mode,opt=job
    dest=base/kind/f'{mode}-O{opt}';dest.mkdir(parents=True,exist_ok=True)
    cwd=SCRATCH/opts.label/kind/f'{mode}-O{opt}';cwd.mkdir(parents=True,exist_ok=True)
    entry=PROJ/'run.py'
    build=exe_sha=process=None;so=se=''
    if opts.bindir:
        exe=cwd/'suite';exe.unlink(missing_ok=True)
        cmd=[opts.bindir/'imre','build',entry,'--module-root',PROJ,'--no-cache','--runtime',opts.bindir/'libimre_runtime.a','--clang',CLANG,'--opt-level',opt,'-o',exe]
        if mode=='boxed': cmd.append('--runtime-imports')
        build,_,_=run(cmd,cwd,dest,'build')
        if build['exit']==0:
            exe_sha=sha(exe);process,so,se=run([exe,*IDS],cwd,dest,'selected-six')
        exe.unlink(missing_ok=True)
    elif kind=='wrong-receiver':
        process,so,se=run([CPY,'-I','-B',GEN/'reference_receivers.py'],cwd,dest,'descriptor')
        assert process['exit']==0 and so.count('WRONG_RECEIVER')==4 and 'NO_RECEIVER TypeError' in so
        save(dest/'receipt.json',{'kind':kind,'mode':mode,'opt':opt,'process':process,'outcome':'PASS'})
        print(opts.label,kind,'PASS',flush=True)
        return
    else:
        root=LIB if kind=='intact' else PROJ
        cmd=[CPY,'-I','-B','-c','import runpy,sys; sys.path.insert(0,sys.argv.pop(1)); runpy.run_path(sys.argv.pop(1),run_name="__main__")',root,entry,*IDS]
        process,so,se=run(cmd,cwd,dest,'selected-six')
    ending=(se or so).strip().splitlines()
    rows=[dict(selector=s,local_occurrence=OCC[s],verdict=classify(s,process,so,se) if process else 'BUILD_ERROR',process=process,ending=ending[-1] if ending else None) for s in IDS]
    if not opts.bindir:
        assert process['exit']==0 and [row['verdict'] for row in rows]==['PASS']*6,rows
    save(dest/'receipt.json',dict(kind=kind,mode=mode,opt=opt,process_scope='one shared original suite',build=build,exe_sha256=exe_sha,cases=rows,imre_commit=opts.commit))
    print(opts.label,kind,mode,opt,[r['verdict'] for r in rows],flush=True)

jobs=[('misc-group',m,n) for n in opts.levels for m in opts.modes] if opts.bindir else [(k,'cpython',0) for k in ('misc-group','intact','wrong-receiver')]
with concurrent.futures.ThreadPoolExecutor(max_workers=opts.jobs) as pool:
    list(pool.map(measure,jobs))
if opts.bindir:
    assert sha(opts.bindir/'imre')==prov['compiler_sha256'] and sha(opts.bindir/'libimre_runtime.a')==prov['runtime_sha256']
