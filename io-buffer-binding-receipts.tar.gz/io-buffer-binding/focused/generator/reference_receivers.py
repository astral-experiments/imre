"""Observe the CPython descriptor's accepted receiver types and read results."""
import _io
import io
import tempfile
from pathlib import Path
import sys

assert sys.version_info[:3] == (3, 14, 5)
assert io.BufferedReader is _io.BufferedReader
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "probe"
    path.write_bytes(b"xy")
    with io.open(path, "rb") as reader, io.open(path, "rb", buffering=0) as raw:
        assert type(reader) is io.BufferedReader and type(raw) is io.FileIO
        assert io.BufferedReader.read(reader, 1) == b"x"
        assert reader.read(1) == b"y"
        print("VALID", type(reader).__module__, type(reader).__name__, "unbound x", "bound y")
        for name, receiver in (("object", object()), ("None", None), ("FileIO", raw),
                               ("BytesIO", io.BytesIO(b"xy"))):
            try:
                io.BufferedReader.read(receiver, 1)
            except TypeError as exc:
                print("WRONG_RECEIVER", name, type(exc).__name__, str(exc))
            else:
                raise AssertionError(name)
        try:
            io.BufferedReader.read()
        except TypeError as exc:
            print("NO_RECEIVER", type(exc).__name__, str(exc))
        else:
            raise AssertionError("missing receiver")
