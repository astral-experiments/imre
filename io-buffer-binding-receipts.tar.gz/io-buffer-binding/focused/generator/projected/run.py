"""Select the six inherited originals in one genuine load_tests and unittest run."""
import sys
import unittest
from test import test_io

selectors = sys.argv[1:]
if len(selectors) != 6:
    raise AssertionError("expected all six exact selectors on argv")
loader = unittest.TestLoader()
loader.testNamePatterns = selectors
suite = loader.loadTestsFromModule(test_io)
if loader.errors:
    for problem in loader.errors:
        print("IMRE_LOADER_ERROR", problem)
    # The hook has already terminated. Record the independent full export
    # inventory so a fresh first missing member cannot hide later ones.
    for label, module in (("io", test_io.io), ("_pyio", test_io.pyio)):
        for name in test_io.io.__all__:
            try:
                getattr(module, name)
            except AttributeError:
                print("IMRE_MISSING_EXPORT", label, name)
    raise RuntimeError("test_io.load_tests failed before selector enumeration")
found = []
for group in suite:
    for case in group:
        found.append(case.id())
if found != selectors:
    raise AssertionError("original suite did not select the six requested IDs")
for name in found:
    print("IMRE_GROUP_SELECTED", name)
result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(suite)
if result.testsRun != len(found):
    raise AssertionError("unittest did not execute the selected count")
outcomes = {}
for case, details in result.errors:
    outcomes[case.id()] = "ERROR"
for case, details in result.failures:
    outcomes[case.id()] = "FAIL"
for case, reason in result.skipped:
    outcomes[case.id()] = "SKIP"
for name in outcomes:
    if name not in found:
        raise AssertionError("fixture failure without an individual case verdict")
for name in found:
    print("IMRE_GROUP_VERDICT", name, outcomes.get(name, "PASS"))
if not result.wasSuccessful():
    sys.exit(1)
