"""Build a focused projection of the two 3.14.5 MiscIO fixture classes."""
import ast
import hashlib
import inspect
import json
import shutil
import sys
import types
import unittest
from pathlib import Path
from test import test_io as original

HERE = Path(__file__).resolve().parent
OUT = HERE / "projected"
LIB = Path(original.__file__).resolve().parents[1]
METHODS = ("test_abcs", "test_abc_inheritance", "test_abc_inheritance_official")
RETAINED = (*METHODS, "tearDown", "_check_abc_inheritance")
OWNERS = ("CMiscIOTest", "PyMiscIOTest")
SOURCE_SHA = "6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af"
assert sys.version_info[:3] == (3, 14, 5)
data = (LIB / "test/test_io.py").read_bytes()
assert hashlib.sha256(data).hexdigest() == SOURCE_SHA
lines = data.decode().splitlines(keepends=True)
stage = ["\n"] * len(lines)
tree = ast.parse(data)


def keep(node):
    assert not getattr(node, "decorator_list", [])
    stage[node.lineno-1:node.end_lineno] = lines[node.lineno-1:node.end_lineno]


def leaf_tests(suite):
    for test in suite:
        if isinstance(test, unittest.TestSuite):
            yield from leaf_tests(test)
        else:
            yield test


assert lines[48].startswith("import _pyio as pyio")
stage[:49] = lines[:49]
for statement in tree.body:
    if isinstance(statement, ast.ClassDef) and 82 <= statement.lineno <= 332:
        keep(statement)
    if isinstance(statement, ast.ClassDef) and statement.name in (*OWNERS, "MiscIOTest"):
        assert not statement.decorator_list
        stage[statement.lineno-1] = lines[statement.lineno-1]
        for member in statement.body:
            if isinstance(member, ast.Assign) or isinstance(member, ast.FunctionDef) and member.name in RETAINED:
                keep(member)
    if isinstance(statement, ast.FunctionDef) and statement.name == "load_tests":
        keep(statement)
        first = statement.body[0]
        assert isinstance(first, ast.Assign) and first.targets[0].id == "tests"
        # The copied setup/attachment and discovery below are untouched. Select
        # only the two classes whose original cases are retained here.
        stage[first.lineno-1] = "    tests = (CMiscIOTest, PyMiscIOTest)\n"
        stage[first.lineno:first.end_lineno] = ["\n"] * (first.end_lineno - first.lineno)

pkg = OUT / "test"
pkg.mkdir(parents=True, exist_ok=True)
for rel in ("_pyio.py", "test/__init__.py"):
    shutil.copyfile(LIB / rel, OUT / rel)
shutil.copytree(LIB / "test/support", pkg / "support", dirs_exist_ok=True,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
module = pkg / "test_io.py"
module.write_text("".join(stage))
staged_lines = module.read_bytes().splitlines(keepends=True)
for node in tree.body:
    if isinstance(node, ast.ClassDef) and 82 <= node.lineno <= 332:
        assert b"".join(staged_lines[node.lineno-1:node.end_lineno]) == "".join(lines[node.lineno-1:node.end_lineno]).encode()
shutil.copyfile(HERE / "selected_misc.py", OUT / "run.py")
target = types.ModuleType(original.__name__)
exec(compile(module.read_bytes(), str(module), "exec"), vars(target))
loader = unittest.TestLoader()
ids = [f"test.test_io.{owner}.{method}" for owner in OWNERS for method in METHODS]
loader.testNamePatterns = ids
original_suite = loader.loadTestsFromModule(original)
projected_suite = loader.loadTestsFromModule(target)
assert not loader.errors
assert sorted(case.id() for case in leaf_tests(original_suite)) == sorted(ids)
assert sorted(case.id() for case in leaf_tests(projected_suite)) == sorted(ids)
for name in OWNERS:
    before = getattr(original, name)
    after = getattr(target, name)
    assert before.__qualname__ == after.__qualname__
    assert before.__bases__[0].__qualname__ == after.__bases__[0].__qualname__ == "MiscIOTest"
    # Compare the complete namespace added by upstream load_tests. The fixture
    # mock classes are distinct incarnations of identical pinned definitions.
    for attr in (*original.io.__all__, "is_C", "io", "name_of_module", "extra_exported", "not_exported"):
        assert inspect.getattr_static(before, attr) == inspect.getattr_static(after, attr), (name, attr)
    for mock in ("MockRawIO", "MisbehavedRawIO", "MockFileIO", "CloseFailureIO", "MockNonBlockWriterIO",
                 "MockUnseekableIO", "MockRawIOWithoutRead", "SlowFlushRawIO", "MockCharPseudoDevFileIO"):
        a, b = getattr(before, mock), getattr(after, mock)
        assert a.__qualname__ == b.__qualname__ and a.__module__ == b.__module__
        assert [x.__qualname__ for x in a.__mro__] == [x.__qualname__ for x in b.__mro__]
    for func in RETAINED:
        a, b = getattr(before, func), getattr(after, func)
        assert a.__code__ == b.__code__, (name, func)
        assert inspect.getclosurevars(a) == inspect.getclosurevars(b), (name, func)
        assert getattr(a, "__unittest_skip__", False) == getattr(b, "__unittest_skip__", False) == False
    assert getattr(before, "__unittest_skip__", False) == getattr(after, "__unittest_skip__", False) == False
    for attr in ("setUp", "setUpClass", "tearDownClass", "doCleanups", "run"):
        assert inspect.getattr_static(before, attr) is inspect.getattr_static(after, attr)
print("source", LIB / "test/test_io.py", SOURCE_SHA)
print("equal code objects, closure/global bindings, fixture exports and original case identities:", ids)
print("projected module", module, hashlib.sha256(module.read_bytes()).hexdigest())

def digest(blob):
    return hashlib.sha256(blob).hexdigest()

load_hook = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "load_tests")
after_class_selection = load_hook.body[0].end_lineno
original_tail = "".join(lines[after_class_selection:load_hook.end_lineno]).encode()
assert original_tail == b"".join(staged_lines[after_class_selection:load_hook.end_lineno])
assert b"".join(staged_lines[:49]) == b"".join(data.splitlines(keepends=True)[:49])
ordered = (HERE / "ordered.ids").read_text().splitlines()
assert len(ordered) == len(set(ordered)) == 667
cases = [case.id() for case in leaf_tests(original_suite)]
assert [ordered.index(i)+1 for i in cases] == [603,604,605,626,627,628]
manifest = {"python":sys.version,"reference_revision":"5607950ef232dad16d75c0cf53101d9649d89115",
    "intact_test_io":SOURCE_SHA, "projection_sha256":digest(module.read_bytes()),
    "original_preamble_lines":[1,49],"preamble_sha256":digest(b"".join(staged_lines[:49])),
    "original_fixture_attachment_lines":[after_class_selection+1,load_hook.end_lineno],
    "original_fixture_attachment_sha256":digest(original_tail),
    "only_load_tests_edit":"narrow its tests tuple to the two selected original subclasses",
    "case_ids_and_local_667_positions":{i:ordered.index(i)+1 for i in cases},
    "test_code_objects_globals_lifecycle_skip_and_original_fixture_checked": True,
    "source_spans":{}, "input_sha256":{}}
for node in tree.body:
    if isinstance(node,ast.ClassDef) and 82 <= node.lineno <= 332:
        manifest["source_spans"][node.name] = [node.lineno,node.end_lineno]
    if isinstance(node,ast.ClassDef) and node.name in (*OWNERS,"MiscIOTest"):
        for member in node.body:
            if isinstance(member,ast.FunctionDef) and member.name in RETAINED:
                name=node.name+"."+member.name
                manifest["source_spans"][name]=[member.lineno,member.end_lineno]
                assert b"".join(staged_lines[member.lineno-1:member.end_lineno]) == "".join(lines[member.lineno-1:member.end_lineno]).encode()
for f in sorted(OUT.rglob("*.py")):
    manifest["input_sha256"][str(f.relative_to(OUT))]=digest(f.read_bytes())
assert manifest["input_sha256"]["_pyio.py"] == "1beee84c68ef6f7acb649dd5aada4c2f34f0476b01c293efe4afd9d0fe2d3ff1"
(HERE/"source-receipt.json").write_text(json.dumps(manifest,indent=2)+"\n")
