"""Observed BufferedReader resource and raw callback semantics."""
import gc
import io
import os
import sys

def borrowed():
    fd = os.open("data.bin", os.O_RDONLY)
    try:
        raw = io.FileIO(fd, "r", closefd=False)
        reader = io.BufferedReader(raw, 4)
        assert reader.raw is raw
        assert reader.read(1) == b"a"
        reader.close()
        assert raw.closed and reader.closed
        # The FileIO closed, but its borrowed fd remains usable by its owner.
        os.lseek(fd, 0, os.SEEK_SET)
        assert os.read(fd, 1) == b"a"
    finally:
        os.close(fd)
    print("BORROWED raw.closed=True reader.closed=True owner_read=a")

def readahead():
    raw = io.FileIO("data.bin", "r")
    reader = io.BufferedReader(raw, 4)
    try:
        assert reader.raw is raw
        assert reader.read(1) == b"a"
        print("POSITIONS", reader.tell(), raw.tell())
        assert (reader.tell(), raw.tell()) == (1, 4)
        assert reader.read(1) == b"b"
        assert (reader.tell(), raw.tell()) == (2, 4)
    finally:
        reader.close()
    print("READAHEAD single_refill")

def subclass_context():
    class UserReader(io.BufferedReader):
        pass
    raw = io.FileIO("data.bin", "r")
    reader = UserReader(raw, 4)
    with reader as active:
        assert active is reader
        assert type(active) is UserReader
        assert active.read(2) == b"ab"
    assert raw.closed and reader.closed
    print("SUBCLASS_CONTEXT self_and_closed")

def raw_subclass():
    class UserFile(io.FileIO):
        def readinto(self, target):
            raise AssertionError("original readinto callback")
    raw = UserFile("data.bin", "r")
    try:
        try:
            reader = io.BufferedReader(raw, 4)
        except NotImplementedError as exc:
            print("EXPLICIT_LIMIT", str(exc))
            return
        try:
            reader.read(1)
        except AssertionError as exc:
            assert str(exc) == "original readinto callback"
            print("CALLBACK readinto invoked")
        else:
            raise AssertionError("FileIO subclass readinto override was bypassed")
        finally:
            reader.close()
    finally:
        raw.close()

def raw_instance():
    def callback(target):
        raise AssertionError("instance readinto callback")
    raw = io.FileIO("data.bin", "r")
    raw.readinto = callback
    try:
        try:
            reader = io.BufferedReader(raw, 4)
        except NotImplementedError as exc:
            print("EXPLICIT_LIMIT", str(exc))
            return
        try:
            reader.read(1)
        except AssertionError as exc:
            assert str(exc) == "instance readinto callback"
            print("CALLBACK instance readinto invoked")
        else:
            raise AssertionError("FileIO instance readinto override was bypassed")
        finally:
            reader.close()
    finally:
        raw.close()

def finalize():
    raw = io.FileIO("data.bin", "r")
    reader = io.BufferedReader(raw, 4)
    assert not raw.closed
    del reader
    gc.collect()
    print("FINALIZED_RAW_CLOSED", raw.closed)
    assert raw.closed

name=sys.argv[1]
print("CONTROL_SELECTED",name)
if name=="borrowed": borrowed()
elif name=="readahead": readahead()
elif name=="subclass_context": subclass_context()
elif name=="raw_subclass": raw_subclass()
elif name=="raw_instance": raw_instance()
elif name=="finalize": finalize()
else: raise AssertionError(name)
print("CONTROL_COMPLETED",name)
