"""Measure raw/wrapper ownership with an isolated process per control."""
import argparse,concurrent.futures,datetime,hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SCRATCH=Path("/workspace/scratch/io-buffer-focused/constructor")
CPY=Path("/workspace/scratch/cpytools/bin/python3.14")
CLANG=Path("/workspace/scratch/tools/clang")
NAMES="borrowed readahead subclass_context raw_subclass raw_instance finalize".split()
def sha(p):
    with p.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
def save(p,v): p.write_text(json.dumps(v,indent=2)+"\n")
def run(cmd,cwd,folder,name):
    cmd=list(map(str,cmd)); stamp=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
    env=os.environ.copy();env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE="1")
    for k in ("PYTHONPATH","IMREFLAGS","IMRE_ENCODED_FLAGS"):env.pop(k,None)
    try:
        p=subprocess.run(cmd,capture_output=True,cwd=cwd,env=env,timeout=360);rc,out,err=p.returncode,p.stdout,p.stderr
    except subprocess.TimeoutExpired as e:rc,out,err=None,e.stdout or b"",e.stderr or b""
    so,se=folder/(name+".stdout"),folder/(name+".stderr")
    so.write_bytes(out);se.write_bytes(err)
    return dict(argv=cmd,cwd=str(cwd),utc_start=stamp,elapsed_s=round(time.monotonic()-t,6),exit=rc,stdout=str(so.relative_to(ROOT)),stderr=str(se.relative_to(ROOT))),out.decode(errors="replace"),err.decode(errors="replace")
ap=argparse.ArgumentParser();ap.add_argument("label");ap.add_argument("--bindir",type=Path);ap.add_argument("--commit");ap.add_argument("--jobs",type=int,default=1);ap.add_argument("--modes",nargs="+",default=["ordinary","boxed"]);ap.add_argument("--levels",type=int,nargs="+",default=[0,3]);o=ap.parse_args()
source=ROOT/"control.py"; out=ROOT/"runs"/o.label;out.mkdir(parents=True,exist_ok=True)
provenance=dict(imre_commit=o.commit,source_sha256=sha(source),harness_sha256=sha(Path(__file__)),cpython=str(CPY),cpython_sha256=sha(CPY))
if o.bindir:
    assert (o.bindir/"READY").read_text().strip()==o.commit
    provenance.update(bindir=str(o.bindir),compiler_sha256=sha(o.bindir/"imre"),runtime_sha256=sha(o.bindir/"libimre_runtime.a"))
save(out/"provenance.json",provenance)
def lane(job):
    m,n=job; dest=out/f"{m}-O{n}";dest.mkdir(parents=True,exist_ok=True);cwd=SCRATCH/o.label/f"{m}-O{n}";cwd.mkdir(parents=True,exist_ok=True)
    (cwd/"data.bin").write_bytes(b"abcdefghijklmnop"); build=exe_hash=None
    if o.bindir:
        exe=cwd/"probe";exe.unlink(missing_ok=True)
        cmd=[o.bindir/"imre","build",source,"--no-cache","--clang",CLANG,"--runtime",o.bindir/"libimre_runtime.a","--opt-level",n,"-o",exe]
        if m=="boxed":cmd.append("--runtime-imports")
        build,_,_=run(cmd,cwd,dest,"build");start=[exe] if build["exit"]==0 else None
        if start:exe_hash=sha(exe)
    else: start=[CPY,"-I","-B",source]
    rows=[]
    for name in NAMES:
        proc=None;status="BUILD_ERROR"
        if start:
            proc,so,se=run(start+[name],cwd,dest,name)
            if proc["exit"]==0 and "CONTROL_COMPLETED "+name in so.splitlines():
                status="EXPLICIT_SCOPE_LIMIT" if any(v.startswith("EXPLICIT_LIMIT ") for v in so.splitlines()) else "PASS"
            else: status="FAIL" if "AssertionError" in se else "ERROR"
        rows.append(dict(control=name,process=proc,verdict=status))
    if o.bindir:exe.unlink(missing_ok=True)
    if not o.bindir:assert all(r["verdict"]=="PASS" for r in rows),rows
    save(dest/"receipt.json",dict(imre_commit=o.commit,mode=m,opt=n,build=build,exe_sha256=exe_hash,controls=rows))
    print(o.label,m,n,[(r["control"],r["verdict"]) for r in rows],flush=True)
jobs=[(m,n) for n in o.levels for m in o.modes] if o.bindir else [("cpython",0)]
with concurrent.futures.ThreadPoolExecutor(o.jobs) as pool:list(pool.map(lane,jobs))
