# BufferedReader ownership and raw callbacks

These six controls are measured separately from original unittest IDs. Each uses a fresh process and a 16-byte real file. CPython 3.14.5 passes all six. The pure Python subclass and instance callbacks on FileIO both run under CPython. A native `NotImplementedError` for either callback is recorded as `EXPLICIT_SCOPE_LIMIT`. [CPython receipt](runs/cpython/cpython-O0/receipt.json) · [Control source](control.py)

- `borrowed` wraps a FileIO with `closefd=False`, closes the reader, checks that the FileIO closed and uses the original operating system descriptor for another read.
- `readahead` checks the exact supplied raw object and reads two single bytes using a four-byte buffer. CPython reports logical positions 1 and 2, with raw position still 4.
- `subclass_context` enters a genuine subclass instance, checks that the context manager returns that instance, then checks that exiting closes both layers.
- `raw_subclass` and `raw_instance` install an observable `readinto` override. Bypassing an override fails the control.
- `finalize` drops the last Python reader reference, calls `gc.collect()`, and checks the retained FileIO object's `closed` flag.

The earlier public 922b215 baseline was measured in ordinary and boxed modes at both optimization levels. Every program compiled and all six control processes per lane reached an AttributeError while resolving `io.BufferedReader`. [Baseline receipts](runs/base-922b215)
