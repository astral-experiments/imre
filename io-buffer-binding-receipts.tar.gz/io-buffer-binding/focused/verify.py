"""Verify raw process evidence and regenerate a compact, per-suite ledger."""
import hashlib
import json
from pathlib import Path
import re
import sys

root=Path(__file__).resolve().parent
source=json.loads((root/'generator/source-receipt.json').read_text())
ids=source['case_ids_and_local_667_positions']
for rel,h in source['input_sha256'].items():
    assert hashlib.sha256((root/'generator/projected'/rel).read_bytes()).hexdigest()==h
summary=[]
for prov_path in sorted((root/'runs').glob('*/provenance.json')):
    provenance=json.loads(prov_path.read_text())
    for info in provenance['inputs'].values():
        assert hashlib.sha256(Path(info['file']).read_bytes()).hexdigest()==info['sha256'],info['file']
    label=prov_path.parent.name
    if provenance['imre_commit']:
        binaries=Path(provenance['bindir'])
        assert (binaries/'READY').read_text().strip()==provenance['imre_commit']
        for filename,key in [('imre','compiler_sha256'),('libimre_runtime.a','runtime_sha256')]:
            with (binaries/filename).open('rb') as fd:
                assert hashlib.file_digest(fd,'sha256').hexdigest()==provenance[key]
    for receipt in sorted(prov_path.parent.glob('*/*/receipt.json')):
        rr=json.loads(receipt.read_text())
        if rr['kind']=='reader-prefix':
            pp=json.loads((prov_path.parent/'provenance-reader-prefix.json').read_text())
            assert rr['unittest_ids']==[] and pp['imre_commit']==rr['imre_commit']
            for info in pp['inputs'].values():
                assert hashlib.sha256(Path(info['file']).read_bytes()).hexdigest()==info['sha256']
            process=rr['process']
            if process:
                out=(root/process['stdout']).read_text()
                err=(root/process['stderr']).read_text()
                assert process['argv'][-1]=='--reader-fixture'
                if rr['verdict']=='PASS':
                    assert process['exit']==0 and out.splitlines()==['ORIGINAL_FIXTURE test.test_io CBufferedReaderTest tp_public_private_identity','ORIGINAL_FILE type_matches bound_ab unbound_cd','ORIGINAL_FIXTURE_PASS test.test_io.CBufferedReaderTest zero_unittest_ids']
                elif rr['verdict']=='UNREACHED':
                    assert process['exit']==1 and not out.strip() and 'line 1804' in err and 'BufferedReader' in err
            continue
        if rr['kind']=='wrong-receiver':
            assert rr['process']['exit']==0
            so=(root/rr['process']['stdout']).read_text()
            assert len(re.findall(r'^WRONG_RECEIVER .* TypeError ',so,re.M))==4
            assert 'NO_RECEIVER TypeError ' in so
            continue
        build=rr['build']
        if build:
            cmd=build['argv']; assert cmd[cmd.index('--opt-level')+1]==str(rr['opt'])
            assert ('--runtime-imports' in cmd)==(rr['mode']=='boxed')
            assert cmd[0]==str(Path(provenance['bindir'])/'imre')
        rows=rr['cases']; assert len(rows)==6
        assert {r['selector']:r['local_occurrence'] for r in rows}==ids
        processes=[r['process'] for r in rows]; assert all(p==processes[0] for p in processes)
        p=processes[0]; assert p is None or p['argv'][-6:]==list(ids)
        diagnostic=None
        missing=[]
        if p is None:
            assert build and build['exit']!=0 and all(r['verdict']=='BUILD_ERROR' for r in rows)
            phase='compile error'
        else:
            so=(root/p['stdout']).read_text()
            se=(root/p['stderr']).read_text()
            selected=re.findall('^IMRE_GROUP_SELECTED (.+)$',so,re.M)
            verdicts=dict(re.findall(r'^IMRE_GROUP_VERDICT (\S+) (PASS|SKIP|FAIL|ERROR)$',so,re.M))
            if selected:
                assert selected==list(ids) and re.search(r'^Ran 6 tests in ',so,re.M)
                assert verdicts=={r['selector']:r['verdict'] for r in rows}
                assert p['exit']==int(any(status in ('FAIL','ERROR') for status in verdicts.values()))
                phase='unittest ran'
            elif 'IMRE_LOADER_ERROR Failed to call load_tests:' in so:
                assert not verdicts and p['exit']==1 and all(r['verdict']=='UNREACHED' for r in rows)
                assert re.search(r'line [0-9]+, in load_tests',so) and 'test_io.py' in so
                phase='load_tests error'
                diagnostic=next((line for line in so.splitlines() if line.startswith(('AttributeError:','NameError:','TypeError:'))),None)
                missing=re.findall('^IMRE_MISSING_EXPORT (.+)$',so,re.M)
            else:
                assert not verdicts and p['exit']!=0
                phase='before suite selection'
                diagnostic=se.strip().splitlines()[-1] if se.strip() else None
        summary.append(dict(label=label,commit=provenance['imre_commit'],kind=rr['kind'],mode=rr['mode'],opt=rr['opt'],build_exit=build['exit'] if build else None,process_exit=p['exit'] if p else None,phase=phase,diagnostic=diagnostic,missing=missing,outcomes={r['selector']:r['verdict'] for r in rows}))
if '--require-complete' in sys.argv:
    labels={s['label'] for s in summary}
    all_labels={x.parent.name for x in (root/'runs').glob('*/provenance.json')}
    assert labels==all_labels and 'cpython' in labels
    for label in labels-{'cpython'}:
        assert {(s['mode'],s['opt']) for s in summary if s['label']==label}=={(m,n) for m in ('ordinary','boxed') for n in (0,3)}
(root/'verified-suites.json').write_text(json.dumps(summary,indent=2)+'\n')
for s in summary:
    print(s['label'],s['kind'],s['mode'],s['opt'],s['build_exit'],s['process_exit'],s['phase'],s['diagnostic'],s['missing'],list(s['outcomes'].values()))
