"""Verify focused final results from durable per-lane outputs."""
import json
from pathlib import Path

root=Path(__file__).resolve().parent
labels=('guarded-6cd4fc4','merged-ae0e69c')
lanes=('ordinary-O0','boxed-O0','ordinary-O3','boxed-O3')
controls=['borrowed','readahead','subclass_context','raw_subclass','raw_instance','finalize']
markers=['ORIGINAL_FIXTURE test.test_io CBufferedReaderTest tp_public_private_identity',
         'ORIGINAL_FILE type_matches bound_ab unbound_cd','ORIGINAL_FIXTURE_PASS test.test_io.CBufferedReaderTest zero_unittest_ids']
def read(p): return json.loads(p.read_text())
results=[]
for label in labels:
    prov=read(root/'runs'/label/'provenance.json')
    for lane in lanes:
        fix=read(root/'runs'/label/'reader-prefix'/lane/'receipt.json')
        group=read(root/'runs'/label/'misc-group'/lane/'receipt.json')
        support=read(root/'constructor/runs'/label/lane/'receipt.json')
        assert fix['imre_commit']==group['imre_commit']==support['imre_commit']==prov['imre_commit']
        assert fix['build']==group['build'] and fix['exe_sha256']==group['exe_sha256']
        assert fix['verdict']=='PASS' and fix['process']['exit']==0 and fix['unittest_ids']==[]
        assert (root/fix['process']['stdout']).read_text().splitlines()==markers
        rows=group['cases']; case_process=rows[0]['process']
        assert len(rows)==6 and all(x['process']==case_process for x in rows)
        assert [x['local_occurrence'] for x in rows]==[603,604,605,626,627,628]
        raw=(root/case_process['stdout']).read_text()
        assert group['build']['exit']==0 and case_process['exit']==1 and 'line 5095, in load_tests' in raw
        assert "AttributeError: module 'io' has no attribute 'BufferedWriter'" in raw and 'IMRE_GROUP_SELECTED' not in raw
        assert all(x['verdict']=='UNREACHED' for x in rows)
        missing=[l.split(' ',1)[1] for l in raw.splitlines() if l.startswith('IMRE_MISSING_EXPORT ')]
        assert missing==['io BufferedWriter','io BufferedRWPair','io BufferedRandom','io IncrementalNewlineDecoder']
        assert support['build']['exit']==0
        assert [x['control'] for x in support['controls']]==controls
        expected=['PASS','PASS','PASS','EXPLICIT_SCOPE_LIMIT','EXPLICIT_SCOPE_LIMIT','PASS']
        assert [x['verdict'] for x in support['controls']]==expected
        for row in support['controls']:
            cp=row['process']; cso=(root/'constructor'/cp['stdout']).read_text()
            assert cp['exit']==0 and f"CONTROL_COMPLETED {row['control']}" in cso
            assert ('EXPLICIT_LIMIT ' in cso)==(row['verdict']=='EXPLICIT_SCOPE_LIMIT')
        results.append(dict(label=label,commit=prov['imre_commit'],lane=lane,exe_sha256=fix['exe_sha256'],fixture=fix['verdict'],originals_executed=0,first_missing='io.BufferedWriter',controls=dict(zip(controls,expected))))
(root/'public-focused.json').write_text(json.dumps(results,indent=2)+'\n')
print('Verified',len(results),'guarded/public lanes, each with a genuine fixture PASS, zero selected original IDs, four resource PASS and two explicit raw-callback limitations.')
