"""Materialize the unchanged upstream stage, oracle and frozen raw receipts from the nested packet."""
import hashlib,subprocess,tarfile
from pathlib import Path
d=Path(__file__).resolve().parent;b=d/'baseline.tar.gz'
assert hashlib.sha256(b.read_bytes()).hexdigest()=='62e7b6206b2af129e8caca6802a59d66983b6c4f37b27e9d4681ed8b5c6c4342'
with tarfile.open(b) as t:
    for member in t:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        p=d/member.name
        if p.exists():assert p.is_file() and p.read_bytes()==t.extractfile(member).read()
        else:t.extract(member,d,filter='data')
subprocess.run(['sha256sum','--quiet','-c','SHA256SUMS'],cwd=d,check=True)
