"""Summarize raw streams without assuming the frozen import exception persists."""
import collections,csv,json,re,sys
from verify import audit,digest,here,readcase
BASE='5472a33cc16130407cc906daf38d3ce50332ea88'
def inspect(pin,lane,keys):
    d=here/'raw'/pin/lane;b=json.loads((d/'build.json').read_text())
    assert b['pin']==pin and b['lane']==lane and b['driver_sha256']==digest(here/'stage/Lib/callback_class.py')
    for s in ('stdout','stderr'):assert digest(d/('build.'+s))==b[s+'_sha256']
    result=dict(build=b,selections={},class_by_id={})
    if b['timeout'] or b['exit']!=0:
        result['stage']='build timeout' if b['timeout'] else 'compile failure'
        result['first_error']=(d/'build.stderr').read_text(errors='backslashreplace').splitlines()[-1:]
        return result
    assert b['executable_sha256']
    for sel in ('class','single','wrong','provider'):
        m,o,e=readcase(d/sel);assert m['revision']==pin and m['lane']==lane
        lines=o.splitlines();events=collections.defaultdict(list);reg=[]
        for l in lines:
            s=l.split('\t')
            if s[0]=='select' and len(s)==5:reg.append((int(s[1]),int(s[2]),int(s[3]),s[4]))
            if len(s)>=3 and s[0] in {'start','stop','failure','success','error','skip','subtest'}:events[s[1]].append(s)
        obs=dict(rc=m['exit'],timeout=m['timeout'],residue=m['residue'],exception=(e.splitlines()[-1:] if 'Traceback (most recent call last):' in e else []),registrations=reg,started=sum(any(s[0]=='start' for s in ev) for ev in events.values()))
        obs['diagnostic_markers']=[s for s in ('Exception ignored','ResourceWarning:','Exception in thread','unraisablehook') if s in e]
        obs['reported_runs']=re.findall(r'(?m)^Ran (\d+) tests? in [\d.]+s$',e)
        obs['module_registered']=any(l.startswith('discovery\t') for l in lines)
        if sel=='class':
            qualified_order=reg==keys
            for key,ev in events.items():
                sts=[x[0] for x in ev];terminal=[s for s in ev if s[0] in ('success','error','failure','skip')]
                if 'start' not in sts:continue
                state='incomplete callbacks'
                if sts.count('start')==1 and sts.count('stop')==1 and len(terminal)==1: state=terminal[0][0]
                elif 'subtest' in sts and any(x[0]=='subtest' and x[-1]!='ok' for x in ev):state='subtest non-success'
                result['class_by_id'][key]=dict(callback=state,details=terminal,subtests=[x[2:] for x in ev if x[0]=='subtest'])
            obs['stock_registration_order_matches']=qualified_order
        if sel=='provider':obs['identity_checks']=next((l for l in lines if l.startswith('provider ')),None)
        result['selections'][sel]=obs
    c=result['selections']['class']
    result['stage']='original callbacks' if c['started'] else 'after registration, no original starts' if c['module_registered'] else 'pre-registration timeout' if c['timeout'] else 'before registration'
    result['class_counts']=dict(collections.Counter(x['callback'] for x in result['class_by_id'].values()))
    result['first_error']=c['exception']
    result['class_success_evidence_qualified']=bool(c.get('stock_registration_order_matches') and not c['diagnostic_markers'] and not c['timeout'] and not c['residue'] and c['reported_runs']==['82'] and result['selections']['provider'].get('identity_checks')=='provider True True True True True True True')
    return result
def run(pin):
    cp=audit(here/'raw/cpython/ordinary');ks=[(r['module_ordinal'],r['class_ordinal'],r['occurrence'],r['identity']) for r in cp['results']]
    pins=list(dict.fromkeys([BASE,pin]));matrix={s:{l:inspect(s,l,ks) for l in ('boxed-O0','boxed-O3')} for s in pins}
    for lanes in matrix.values():assert lanes['boxed-O0']['build']['compiler_runtime']==lanes['boxed-O3']['build']['compiler_runtime']
    prior=here/'global-1038-ae0e69c.tsv'
    assert digest(prior)=='f4f208cfd969ac9ca40a16f52ed9fc37b7ceef1a3fd0b98e408dd3afd07bc88c'
    with prior.open() as f: ledger=list(csv.DictReader(f,delimiter='\t'))
    assert len(ledger)==1038
    lookup={(i['id'],int(i['occurrence'])):i for i in ledger}
    rows=[]
    for ordinal,pos,occ,id in ks:
        record=lookup[id,occ]
        assert record['module']=='test.test_io' and record['reference_verdict']=='PASS'
        assert all(record[k]=='UNREACHED' for k in ('ordinary.O0','ordinary.O3','boxed.O0','boxed.O3'))
        global_ordinal=int(record['index'])
        assert global_ordinal==682+pos
        row=dict(prior_1038_ordinal=global_ordinal,module_ordinal=ordinal,class_ordinal=pos,occurrence=occ,id=id,fixture='test.test_io.CTextIOWrapperTest',CPython='success')
        for s in pins:
            for lane,q in matrix[s].items():row[s[:8]+'_'+lane]=q['class_by_id'].get(id,{}).get('callback','unreached ('+q['stage']+')')
        rows.append(row)
    return dict(commits=pins,prior_registration={'source':'https://github.com/astral-experiments/imre/blob/9ec07a60a8d272189f82d8b1e1cb5a6f1ea9dd17/discovery/wider/registration/merged-ae0e69c/denominator-ledger.tsv','sha256':digest(prior),'scope':'indices from prior corpus; historical states are not current outcomes'},reference_source=cp['source_commit'],stock_clean=82,raw_native=matrix,rows=rows)
if __name__=='__main__':
    x=run(sys.argv[1])
    if '--tsv' in sys.argv:
        w=csv.DictWriter(sys.stdout,fieldnames=list(x['rows'][0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(x['rows'])
    else:print(json.dumps(x,indent=2))
