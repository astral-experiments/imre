"""Bundle one frozen baseline plus the new raw data; re-extract and repeat all checks."""
import hashlib,json,subprocess,sys,tarfile,tempfile
from pathlib import Path
from compare import BASE,here
pin=sys.argv[1];out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def call(script,*args,cwd=here):return subprocess.check_output([sys.executable,'-B',script,*args],cwd=cwd)
with tempfile.TemporaryDirectory(dir=here) as name:
    tmp=Path(name)
    l='imre-textio-cwrapper-'+pin[:8]+'-vs-'+BASE[:8];a=tmp/(l+'.tar.gz')
    payload=[(here/n,n) for n in ['baseline.tar.gz','bootstrap.py','run_native.py','run_one.py','run.py','compare.py','seal.py','POSTMERGE.md','global-1038-ae0e69c.tsv']]
    for f in (here/'raw'/pin).rglob('*'):
        if pin!=BASE and f.name in ('build.json','build.stdout','build.stderr','result.json','stdout','stderr'):payload.append((f,str(f.relative_to(here))))
    for n,opts in [('combined.json',[]),('combined.tsv',['--tsv'])]:
        f=tmp/n;f.write_bytes(call('compare.py',pin,*opts));payload.append((f,n))
    m=tmp/'PUBLICATION_SHA256SUMS';m.write_text(''.join(sha(f)+'  '+n+'\n' for f,n in sorted(payload,key=lambda it:it[1])))
    with tarfile.open(a,'w:gz') as tar:
        for f,n in [*payload,(m,m.name)]:tar.add(f,arcname=n)
    check=tmp/'verify';check.mkdir()
    with tarfile.open(a) as t:t.extractall(check,filter='data')
    subprocess.run(['sha256sum','--quiet','-c',m.name],cwd=check,check=True)
    call('bootstrap.py',cwd=check)
    for n,opts in [('combined.json',[]),('combined.tsv',['--tsv'])]:assert call('compare.py',pin,*opts,cwd=check)==(check/n).read_bytes()
    for f,n in [(a,a.name),(tmp/'combined.tsv',l+'.tsv')]:
        target=out/n
        if target.exists():assert sha(target)==sha(f)
        else:target.write_bytes(f.read_bytes())
        print(target,len(target.read_bytes()),sha(target))
