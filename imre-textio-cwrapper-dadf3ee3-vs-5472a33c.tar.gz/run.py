"""Run the intact original CTextIOWrapperTest at both optimization levels for a verified pair."""
import argparse,os,re,subprocess,sys
from pathlib import Path
d=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('commit');p.add_argument('--pair',required=True,type=Path);p.add_argument('--llvm',required=True,type=Path)
p.add_argument('--publish',required=True,type=Path);a=p.parse_args()
if not re.fullmatch('[0-9a-f]{40}',a.commit):p.error('the full 40-character commit is required')
if (d/'raw'/a.commit).exists():p.error('existing raw receipts cannot be overwritten')
env={**os.environ,'CWRAPPER_PAIR':str(a.pair.resolve()),'CWRAPPER_LLVM':str(a.llvm.resolve())}
subprocess.run([sys.executable,'-B',d/'run_native.py',a.commit,'boxed-O0','boxed-O3'],cwd=d,env=env,check=True)
subprocess.run([sys.executable,'-B',d/'seal.py',a.commit,a.publish.resolve()],cwd=d,check=True)
