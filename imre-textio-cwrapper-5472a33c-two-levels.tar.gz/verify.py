from pathlib import Path
import ast,hashlib,json,re
here=Path(__file__).resolve().parent
pin='5472a33cc16130407cc906daf38d3ce50332ea88'
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def readcase(d):
    m=json.loads((d/'result.json').read_text());assert not m['adopted'] and m['stdin_pipe'] and m['stdin_parent_held_through_wait'] and m['cwd']!=m['tmpdir']
    for f in ('stdout','stderr'):assert digest(d/f)==m[f+'_sha256']
    return m,(d/'stdout').read_text(errors='backslashreplace'),(d/'stderr').read_text(errors='backslashreplace')
def audit(cp):
    m,o,e=readcase(cp/'class');lines=o.splitlines();assert lines[:2]==['discovery\t667','class\t82']
    selectors=[];idx=2
    while idx<len(lines) and lines[idx].startswith('select\t'):
        _,a,b,c,s=lines[idx].split('\t');idx+=1;selectors.append((int(a),int(b),int(c),s))
    assert len(selectors)==82 and len(set(s for _,_,_,s in selectors))==82
    src=ast.parse((here/'stage/Lib/test/test_io.py').read_text())
    owners={x.name:{f.name:f.lineno for f in x.body if isinstance(f,ast.FunctionDef)} for x in src.body if isinstance(x,ast.ClassDef)}
    rows=[];subs=0
    for ordinal,pos,occ,identity in selectors:
        assert ordinal==444+pos and occ==1 and lines[idx]=='start\t'+identity+'\t';idx+=1
        subtests=[]
        while lines[idx].startswith('subtest\t'):
            _,who,sub,res=lines[idx].split('\t');assert who==identity and res=='ok';subtests.append(sub);idx+=1
        assert lines[idx]=='success\t'+identity+'\t' and lines[idx+1]=='stop\t'+identity+'\t';idx+=2
        cls='CTextIOWrapperTest';method=identity.rsplit('.',1)[1]
        owner=cls if method in owners[cls] else 'TextIOWrapperTest'
        rows.append(dict(module_ordinal=ordinal,class_ordinal=pos,occurrence=occ,identity=identity,fixture='test.test_io.CTextIOWrapperTest',method_defined_by=owner,source_line=owners[owner][method],setUp='test.test_io.TextIOWrapperTest.setUp',tearDown='test.test_io.TextIOWrapperTest.tearDown',callback='success',subtests=subtests))
        subs+=len(subtests)
    assert idx==len(lines) and m['exit']==0 and not m['timeout'] and not m['residue']
    for row in rows:
        ident=row['identity'];method=ident.rsplit('.',1)[1]
        assert any(s.startswith(method+' ('+ident+')') for s in e.splitlines()),ident
    assert not any(s in e for s in ('Exception ignored','unraisablehook','Traceback (','ResourceWarning:','Exception in thread'))
    assert re.search(r'Ran 82 tests in [0-9.]+s\n\nOK\n\Z',e)
    for key,rc,n in [('single',0,1),('wrong',1,0)]:
        m,o,e=readcase(cp/key);assert m['exit']==rc and not m['residue'] and not m['timeout'] and 'Ran '+str(n)+' test' in e
        assert len([s for s in o.splitlines() if s.startswith('start\t')])==n
    m,o,e=readcase(cp/'provider');assert m['exit']==0 and not m['residue'] and not m['timeout'] and not e and 'provider True True True True True True True' in o
    return dict(source_commit='5607950ef232dad16d75c0cf53101d9649d89115',provider='_io.TextIOWrapper',class_count=82,module_count=667,subtests=subs,results=rows)
if __name__=='__main__':print(json.dumps(audit(here/'raw/cpython/ordinary'),indent=2))
