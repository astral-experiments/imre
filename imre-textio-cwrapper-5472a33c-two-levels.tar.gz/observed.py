import csv,json,sys
from verify import here,pin,audit,readcase,digest
expected="AttributeError: module 'io' has no attribute 'BufferedRWPair'"
def assess(lane):
    root=here/'raw'/pin/lane;build=json.loads((root/'build.json').read_text())
    assert build['pin']==pin and build['exit']==0 and not build['timeout'] and build['executable_sha256']
    for f in ('stdout','stderr'):assert digest(root/('build.'+f))==build[f+'_sha256']
    assert build['driver_sha256']==digest(here/'stage/Lib/callback_class.py')
    out={}
    for sel in ('class','single','wrong','provider'):
        m,o,e=readcase(root/sel)
        assert not m['timeout'] and not m['residue'] and m['exit']==1 and o=='' and m['visible_helper'].endswith('/'+pin+'/imre')
        assert 'Traceback (most recent call last):' in e and 'test_io.py", line 2406\n' in e and e.splitlines()[-1]==expected
        assert not any(s in e for s in ('Ran ','Exception ignored','unraisablehook','ResourceWarning:','Exception in thread'))
        out[sel]=dict(exit=m['exit'],stdout_bytes=m['stdout_bytes'],registration='not reached',callbacks=0,stderr_first_exception=expected)
    return dict(build_revision=pin,build_argv=build['argv'],compiler_runtime=build['compiler_runtime'],executable_sha256=build['executable_sha256'],observations=out)
def run():
    stock=audit(here/'raw/cpython/ordinary');lanes={l:assess(l) for l in ('boxed-O0','boxed-O3')}
    assert lanes['boxed-O0']['compiler_runtime']==lanes['boxed-O3']['compiler_runtime']
    rows=[dict(module_ordinal=r['module_ordinal'],class_ordinal=r['class_ordinal'],occurrence=r['occurrence'],id=r['identity'],fixture=r['fixture'],method_owner=r['method_defined_by'],source_line=r['source_line'],cpython=r['callback'],boxed_O0='unreached before registration',boxed_O3='unreached before registration') for r in stock['results']]
    assert (here/'stage/Lib/test/test_io.py').read_text().splitlines()[2405].strip()=='tp = io.BufferedRWPair'
    return dict(pin=pin,oracle=dict(class_ok=82,subtest_ok=6,original_source_commit=stock['source_commit']),native=dict(originals_executed=0,per_test_errors=0,qualified_successes=0),lanes=lanes,rows=rows)
if __name__=='__main__':
    data=run()
    if '--tsv' in sys.argv:
        w=csv.DictWriter(sys.stdout,fieldnames=list(data['rows'][0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(data['rows'])
    else:print(json.dumps(data,indent=2))
