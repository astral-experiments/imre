Public 0c9885cf2953271a30a7a40b7ac2f5a8bf4f76db compiled successfully and failed a one-case native boxed O0 diagnostic at its mutation assertion. The same source passes on Linux CPython 3.14.5.

Build and run argv and pair SHA-256 digests are in the receipts; adapt only paths. These controls do not add original unittest IDs.
