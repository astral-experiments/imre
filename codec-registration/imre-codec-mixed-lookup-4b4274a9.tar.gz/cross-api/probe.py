import codecs
import sys
seen = []
def custom(name):
    seen.append(name)
    return (lambda obj,*args:(b'CUSTOM',len(obj)),lambda obj,*args:('CUSTOM',len(obj)),None,None)
codecs.register(custom)
key='utf-16-le'
if sys.argv[1] == 'decode-first':
    before=codecs.decode(b'A\0',key)
    print('before',repr(before),list(seen),flush=True)
    assert before=='A' and not seen
try:
    entry=codecs.lookup(key)
except LookupError:
    # Keep the existing native limitation on the standalone CodecInfo lookup separate.
    info='no boxed entry'
else:
    info='native' if isinstance(entry,codecs.CodecInfo) else 'later hook'
after=codecs.decode(b'B\0',key)
print('after',info,repr(after),seen,flush=True)
assert after=='B' and not seen
