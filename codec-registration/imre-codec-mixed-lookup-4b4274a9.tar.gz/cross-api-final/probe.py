import codecs
import sys
import encodings
seen = []
response=(lambda obj,*args:(b'CUSTOM',len(obj)),lambda obj,*args:('CUSTOM',len(obj)),None,None)
def custom(name):
    seen.append(name)
    return response
codecs.register(custom)
key='utf-16-le'
if sys.argv[1]=='custom-first':
    assert codecs.unregister(encodings.search_function) is None
    codecs.register(encodings.search_function)
    assert codecs.decode(b'A\0',key)=='CUSTOM'
    assert codecs.lookup(key) is response and codecs.decode(b'B\0',key)=='CUSTOM'
    print('earlier Python winner',seen,flush=True)
    assert seen==['utf_16_le']
elif sys.argv[1]=='invalidation':
    assert codecs.decode(b'A\0',key)=='A' and seen==[]
    assert codecs.unregister(encodings.search_function) is None
    assert codecs.lookup(key) is response and codecs.decode(b'B\0',key)=='CUSTOM'
    print('removing default clears fallback',seen,flush=True)
    assert seen==['utf_16_le']
else:
    if sys.argv[1] == 'decode-first':
        before=codecs.decode(b'A\0',key)
        print('before',repr(before),list(seen),flush=True)
        assert before=='A' and not seen
    try:
        entry=codecs.lookup(key)
    except LookupError:
        # Keep the existing native limitation on the standalone CodecInfo lookup separate.
        info='no boxed entry'
    else:
        info='native' if isinstance(entry,codecs.CodecInfo) else 'later hook'
    after=codecs.decode(b'B\0',key)
    print('after',info,repr(after),seen,flush=True)
    assert after=='B' and not seen
