"""Build a pinned diagnostic ELF, then run each selector in a fresh process."""
from pathlib import Path
import ctypes, hashlib, json, os, signal, stat, subprocess, sys, time
r = Path(__file__).resolve().parent
b = r.parents[1]
pin, lane = sys.argv[1:3]
cases = sys.argv[3:] or 'order normalization cache duplicate malformed arguments builtins reentrant append remove lifetime cache-lifetime fixture inverted wrong'.split()
fixture = r/'stage/codec_probe.py'
out = r/'raw'/pin/lane
out.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')
def read(path):
    return json.loads(path.read_bytes())
def limited(cmd, secs, cwd, env, stdout, stderr):
    started = time.monotonic()
    with stdout.open('wb') as so, stderr.open('wb') as se:
        child = subprocess.Popen([str(v) for v in cmd], stdin=subprocess.PIPE,
            stdout=so, stderr=se, cwd=cwd, env=env, start_new_session=True)
        timeout = False
        try:
            child.wait(timeout=secs)
        except subprocess.TimeoutExpired:
            timeout = True
        finally:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait(timeout=10)
            pipe_held = stat.S_ISFIFO(os.fstat(child.stdin.fileno()).st_mode) and not child.stdin.closed
            child.stdin.close()
    adopted = []
    while True:
        try: pid, status = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError: break
        if not pid: raise RuntimeError('surviving descendant')
        adopted.append([pid,status])
    return dict(exit=child.returncode, timeout=timeout, duration=round(time.monotonic()-started,3),
        stdin_held=pipe_held, adopted=adopted, stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
assert ctypes.CDLL(None).prctl(36,1,0,0,0) == 0  # Linux child subreaper
env = {**os.environ, 'LC_ALL':'C.UTF-8', 'PYTHONDONTWRITEBYTECODE':'1'}
if pin == 'cpython':
    assert lane == 'stock'
    python = b/'python/managed/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
    info = subprocess.check_output([python,'-IB','-c','import sys;print(sys.version);print(sys.platform);print(sys.implementation.name)']).decode().splitlines()
    assert info[0].startswith('3.14.5 ') and info[1:] == ['linux','cpython']
    save(out/'interpreter.json', dict(executable=str(python),sha256=sha(python),version=info))
    program = [python, '-IB', fixture]
else:
    assert len(pin) == 40 and lane in ('boxed-O0','boxed-O3')
    pair = b/'fs-family/provider-replay/pairs'/pin
    assert (pair/'commit').read_text().strip() == pin
    expected = {n:h for h,n in (line.split() for line in (pair/'ready').read_text().splitlines())}
    assert expected == {n:sha(pair/n) for n in expected}
    env['LD_LIBRARY_PATH'] = str(b/'llvm/usr/lib/x86_64-linux-gnu')
    program = [out/'suite']
    args = [pair/'imre','build',fixture,'--module-root',fixture.parent,'--runtime-imports','--opt-level',lane[-1],'--no-cache','--runtime',pair/'libimre_runtime.a','--clang',b/'llvm/usr/bin/clang-19','-o',program[0]]
    previous = out/'build.json'
    if previous.exists():
        build = read(previous)
        assert build['driver_sha256'] == sha(fixture) and build['pair'] == expected and build['exit'] == 0 and sha(program[0])==build['binary_sha256']
    else:
        tmp = out/'buildtmp'
        tmp.mkdir(exist_ok=True)
        build = limited(args,850,tmp,{**env,'TMPDIR':str(tmp)},out/'build.stdout',out/'build.stderr')
        build.update(argv=list(map(str,args)), pin=pin, lane=lane, pair=expected, driver_sha256=sha(fixture), binary_sha256=sha(program[0]) if build['exit']==0 else None)
        save(previous,build)
        print('build',pin[:8],lane,build['exit'],flush=True)
        if build['exit']: sys.exit(1)
        if not any(tmp.iterdir()): tmp.rmdir()
for sel in cases:
    dest=out/sel
    dest.mkdir(exist_ok=True)
    if (dest/'result.json').exists(): continue
    cwd=dest/'cwd'
    tmp=dest/'tmpdir'
    cwd.mkdir(); tmp.mkdir()
    cmd=[*program,sel]
    result=limited(cmd,35,cwd,{**env,'TMPDIR':str(tmp)},dest/'stdout',dest/'stderr')
    residue={key:sorted(str(p.relative_to(root)) for p in root.rglob('*')) for key,root in [('cwd',cwd),('tmpdir',tmp)]}
    if not residue['cwd']: cwd.rmdir()
    if not residue['tmpdir']: tmp.rmdir()
    result.update(pin=pin,lane=lane,case=sel,argv=list(map(str,cmd)),driver_sha256=sha(fixture),residue=residue)
    save(dest/'result.json',result)
    print(pin[:8],lane,sel,result['exit'],(dest/'stderr').read_text(errors='replace').splitlines()[-1:],flush=True)
