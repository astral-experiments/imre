"""Recheck sources, process receipts and every separately classified result."""
from pathlib import Path
import ast, hashlib, json
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
f=r/'stage/codec_probe.py'; fixture=read(r/'fixture.json'); data=read(r/'packet.json'); cases=data['cases']
assert sha(f)==fixture['control_sha256']
lines=f.read_bytes().splitlines(keepends=True)
slices={n.name: hashlib.sha256(b''.join(lines[n.lineno-1:n.end_lineno])).hexdigest() for n in ast.parse(f.read_bytes()).body if getattr(n,'name','') in fixture['slices']}
assert slices=={k:v['sha256'] for k,v in fixture['slices'].items()}
assert len(set(cases))==len(cases)==15 and cases[-2:]==['inverted','wrong']
rows=[]
for pin,role in data['roles'].items():
    for lane in (['stock'] if role=='oracle' else ['boxed-O0','boxed-O3']):
        base=r/'raw'/pin/lane
        if role=='oracle':
            info=read(base/'interpreter.json')
            assert info['version'][0].startswith('3.14.5 ') and info['version'][1:]==['linux','cpython']
        else:
            build=read(base/'build.json')
            assert build['pin']==pin and build['lane']==lane and build['exit']==0 and not build['timeout'] and not build['adopted']
            assert build['driver_sha256']==sha(f) and build['pair']==data['pairs'][pin]
            assert '--runtime-imports' in build['argv'] and build['argv'][build['argv'].index('--opt-level')+1]==lane[-1]
            assert all(sha(base/('build.'+s))==build[s+'_sha256'] for s in ('stdout','stderr'))
        assert {p.name for p in base.iterdir() if p.is_dir()}==set(cases)
        for case in cases:
            d=base/case;rec=read(d/'result.json');o=(d/'stdout').read_bytes();e=(d/'stderr').read_bytes()
            assert (rec['pin'],rec['lane'],rec['case'],rec['argv'][-1])==(pin,lane,case,case)
            assert rec['driver_sha256']==sha(f) and all(sha(d/s)==rec[s+'_sha256'] for s in ('stdout','stderr'))
            assert rec['stdin_held'] and not rec['timeout'] and not rec['adopted'] and rec['residue']=={'cwd':[],'tmpdir':[]}
            if case=='wrong': same=rec['exit']==3 and o==b'absent selection wrong\n' and not e
            elif case=='inverted': same=rec['exit']==1 and e.endswith(b'AssertionError: reversed codec identity\n') and not o
            else: same=rec['exit']==0 and not e and o==(r/'raw/cpython/stock'/case/'stdout').read_bytes() and o.endswith(b'OK '+case.encode()+b'\n')
            if role=='oracle' or case=='wrong':assert same,(pin,lane,case,o,e)
            if role=='absent' and case!='wrong':
                assert rec['exit']==1 and e.endswith(b"AttributeError: module 'codecs' has no attribute 'register'\n"),(pin,lane,case)
            rows.append(dict(pin=pin,lane=lane,case=case,matched=same,exit=rec['exit'],last_error=e.decode(errors='replace').splitlines()[-1:]))
        subset=rows[-len(cases):]
        print(pin[:8],lane,sum(q['matched'] for q in subset),'/',len(subset),'stock outcomes; differences:',','.join(q['case'] for q in subset if not q['matched']) or 'none')
path=r/'comparison.json'
if path.exists():assert read(path)==rows
else:path.write_text(json.dumps(rows,indent=2)+'\n')
