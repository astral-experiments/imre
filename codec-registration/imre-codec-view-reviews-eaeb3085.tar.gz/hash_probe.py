import codecs

data = bytearray(b'abcdef')
held = []

def decode(view):
    assert view.obj is None and view.readonly
    reverse = view[::-2]
    assert reverse.obj is None and reverse.readonly
    assert hash(view) == hash(b'abcdef')
    assert hash(reverse) == hash(b'fdb')
    held.extend((view, reverse))
    return "ok", len(view)

def search(name):
    if name == 'ownerless_hash':
        return None, decode, None, None

codecs.register(search)
try:
    assert data.decode('ownerless-hash') == 'ok'
finally:
    codecs.unregister(search)

data[1] = ord('z')
view, reverse = held
assert view.tobytes() == b'azcdef' and reverse.tobytes() == b'fdz'
assert hash(view) == hash(b'abcdef') and hash(reverse) == hash(b'fdb')
assert hash(memoryview(view)) == hash(b'azcdef')
assert hash(view[::-2]) == hash(b'fdz')
public = memoryview(data)
try:
    hash(public)
except ValueError:
    pass
else:
    raise AssertionError("public writable memoryview hash")
try:
    hash(public.toreadonly())
except TypeError:
    pass
else:
    raise AssertionError("public owner unexpectedly hashable")
print("anonymous views cache their byte hash; public views keep the bytearray hash rules")
