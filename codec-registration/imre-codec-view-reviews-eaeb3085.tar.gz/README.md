# Raw reader compatibility and anonymous codec-view hashing

Raw reader differential: CPython 3.14.5 on Linux (5607950ef232dad16d75c0cf53101d9649d89115) vs. boxed O0 f0187492f8947ef7818412cb70d440c105b07f22. The launcher calls current() from the unchanged tests/fixtures/boxed_bytes_io.py. It exercises interrupted reads, post-callback writes through a retained anonymous readinto view, writable slices and pipe reads. Both returned 0 with identical raw streams, no stderr, held stdin, empty test and temp directories, and reaped children. These are repository controls, with zero CPython unittest registrations.

The five files in the candidate diff were reviewed against public a3d6f19ff9727a835ca3cd4c19bd438d845a1814. Integrated head eaeb30852ebc6a892972345aeaaef48231c15f8f was compared against public 0c9885cf2953271a30a7a40b7ac2f5a8bf4f76db. The two candidate heads have identical codec/view/raw-reader implementation and identical raw reader fixture. The integrated test fixture preserves the public contiguous-decoder assertions and adds mutable bytearray coverage.

The hash probe covers pre-mutation hashes of an anonymous view and reversed slice, retained post-mutation cached hashes, fresh views reflecting mutated bytes, and both writable and readonly public views over the same unhashable owner. The raw receipts identify the exact compiler/runtime pair. They contain the original machine's paths.

To run in a new Linux checkout, set CPYTHON to a Linux CPython 3.14.5 executable, and IMRE, RUNTIME and CLANG to the compiler, matched runtime archive, and clang. From the extracted directory:

    "$CPYTHON" -B src/entry.py
    "$IMRE" build src/entry.py --module-root src --opt-level 0 --runtime-imports --no-cache --runtime "$RUNTIME" --clang "$CLANG" -o reader
    ./reader
    "$CPYTHON" -B hash_probe.py
    "$IMRE" build hash_probe.py --module-root . --opt-level 0 --runtime-imports --no-cache --runtime "$RUNTIME" --clang "$CLANG" -o hashprobe
    ./hashprobe

The raw reader was replayed again on eaeb30852ebc6a892972345aeaaef48231c15f8f in boxed O0. The hash probe ran on CPython and the same integrated boxed O0 pair. Both stock/native stdout pairs were byte-identical, stderr empty, all five test executions (two on stock, one on f018 and two on eaeb) completed with clean real working directories and no children or temporary files remaining. The per-run receipts give exact status. Bytearray, bytes and subtype codec callback mutation and exception controls at O0/O3 were run separately.
