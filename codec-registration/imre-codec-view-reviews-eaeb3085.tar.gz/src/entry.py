import boxed_bytes_io
boxed_bytes_io.current()
