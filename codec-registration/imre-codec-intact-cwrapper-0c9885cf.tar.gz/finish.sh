set -eu
p=$1; shift
export CWRAPPER_PAIR="${CWRAPPER_PAIR:-/tmp/imre3310/fs-family/provider-replay/pairs/$p}" CWRAPPER_LLVM="${CWRAPPER_LLVM:-/tmp/imre3310/llvm}"
lane_finish() {
    l=$1
    for i in $(seq 1 3600); do
        if [ -f "raw/$p/$l/build.json" ]; then
            rc=$(python3 -B -c 'import json,sys;print(json.load(open(sys.argv[1]))["exit"])' "raw/$p/$l/build.json")
            if [ "$rc" != 0 ]; then break; fi
            if [ -f "raw/$p/$l/class/result.json" ] && [ -f "raw/$p/$l/single/result.json" ] && [ -f "raw/$p/$l/wrong/result.json" ] && [ -f "raw/$p/$l/provider/result.json" ]; then break; fi
        fi
        sleep 3
    done
    (RWEARLY=$l python3 -B seal.py "$p" 36c4f334e96c3bb5a8270ff8f8c85808715fec6d "$p")
    python3 -B repeat.py "$p" "$l"
}
lane_finish boxed-O0 > "finish-$p-boxed-O0.log" 2>&1 & l0=$!
lane_finish boxed-O3 > "finish-$p-boxed-O3.log" 2>&1 & l3=$!
wait "$l0"; wait "$l3"
python3 -B seal.py "$p" "$@" "$p"
