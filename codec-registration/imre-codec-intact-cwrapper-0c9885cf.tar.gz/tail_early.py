"""Start only not-yet-started originals once a canonical invocation has ended."""
import concurrent.futures,json,subprocess,sys,time
from pathlib import Path
from qualify import here
from tail_replay import recover
pin=sys.argv[1]
def one(lane):
    root=here/'raw'/pin/lane;deadline=time.monotonic()+7500
    while not(root/'class/result.json').is_file():
        b=root/'build.json'
        if b.is_file() and json.loads(b.read_text())['exit']!=0:return
        if time.monotonic()>deadline:raise TimeoutError(lane)
        time.sleep(1)
    m=json.loads((root/'class/result.json').read_text());assert m['revision']==pin and m['lane']==lane
    with concurrent.futures.ThreadPoolExecutor(1) as svc:
        future=svc.submit(recover,pin,lane);reported=False
        while not future.done():
            if not reported and list(root.glob('follow-*/result.json')):
                subprocess.run([sys.executable,'-B',here/'interim.py',pin[:8]+'-'+lane.lower()+'-first-disjoint',pin],check=True,cwd=here)
                reported=True
            time.sleep(2)
        rows=future.result()
        if rows:
            subprocess.run([sys.executable,'-B',here/'interim.py',pin[:8]+'-'+lane.lower()+'-disjoint-settled',pin],check=True,cwd=here)
with concurrent.futures.ThreadPoolExecutor(2) as svc:list(svc.map(one,['boxed-O0','boxed-O3']))
