set -eu
pin=$1
export CWRAPPER_PAIR="${CWRAPPER_PAIR:-/tmp/imre3310/fs-family/provider-replay/pairs/$pin}" CWRAPPER_LLVM="${CWRAPPER_LLVM:-/tmp/imre3310/llvm}"
python3 -B run_native.py "$pin" boxed-O0 boxed-O3 > "matrix-$pin.log" 2>&1 & a=$!
bash finish.sh "$pin" 36c4f334e96c3bb5a8270ff8f8c85808715fec6d > "seal-$pin.log" 2>&1 & b=$!
python3 -B class_first.py "$pin" > "settled-$pin.log" 2>&1 & c=$!
python3 -B watch.py "$pin" boxed-O0 /workspace/shared/downloads > "live-$pin-boxed-O0.log" 2>&1 & d=$!
python3 -B watch.py "$pin" boxed-O3 /workspace/shared/downloads > "live-$pin-boxed-O3.log" 2>&1 & e=$!
python3 -B child_identity.py "$pin" boxed-O0 > "helpers-$pin-boxed-O0.log" 2>&1 & f=$!
python3 -B child_identity.py "$pin" boxed-O3 > "helpers-$pin-boxed-O3.log" 2>&1 & g=$!
python3 -B tail_early.py "$pin" > "tail-early-$pin.log" 2>&1 & h=$!
python3 -B long_after.py "$pin" > "extended-$pin.log" 2>&1 & i=$!
wait "$a";wait "$b";wait "$c";wait "$d";wait "$e";wait "$f";wait "$g";wait "$h";wait "$i"
