"""Reserve one long-run slot only after a complete disjoint receipt is available."""
import concurrent.futures,json,time,sys
from repeat import here,keys,run_ref,run_case
pin=sys.argv[1];base=here/'raw'/pin;deadline=time.monotonic()+7000
while not list(base.glob('*/follow-*/result.json')):
    if time.monotonic()>deadline:raise TimeoutError('no completed disjoint receipt')
    time.sleep(2)
def lane(name):
    root=base/name
    source=json.loads((root/'class/result.json').read_text())
    if source['timeout'] and source.get('timeout_active_original'):
        k=source['timeout_active_original'];n=next(n for _,n,_,key in keys if key==k)
        label='long-'+str(n);run_ref(label,k);run_case(pin,name,label,k)
with concurrent.futures.ThreadPoolExecutor(2) as service:list(service.map(lane,['boxed-O0','boxed-O3']))
