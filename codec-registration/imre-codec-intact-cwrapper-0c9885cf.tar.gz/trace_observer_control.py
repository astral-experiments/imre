"""Diagnostic-only runner: the specimen has no upstream fixture or original test ID."""
from pathlib import Path
import ast,contextlib,io,sys,unittest
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here/'stage/Lib'))
data=(here/'stage/Lib/callback_class.py').read_text().partition('def flatten')[0]
namespace={}
exec(compile(data,str(here/'stage/Lib/callback_class.py'),'exec'),namespace)
class ObserverSpecimen(unittest.TestCase):
    def test_ordinary_error(self):raise ValueError('observer control')
    def test_failure(self):self.fail('observer control')
    def test_subtest(self):
        with self.subTest(n=2):raise ValueError('subtest control')
events=io.StringIO();runner=io.StringIO()
with contextlib.redirect_stdout(events):
    r=unittest.TextTestRunner(stream=runner,verbosity=2,resultclass=namespace['CallbackResult']).run(unittest.defaultTestLoader.loadTestsFromTestCase(ObserverSpecimen))
records=[]
for line in events.getvalue().splitlines():
    p=line.split('\t')
    if p[0]=='trace':records.append((p[1],p[2],ast.literal_eval(p[3])))
assert r.testsRun==3 and len(r.errors)==2 and len(r.failures)==1
assert len(records)==3 and sorted(v for _,_,v in records)==sorted(v for _,v in r.errors+r.failures)
for k,typ,formatted in records:
    assert formatted in runner.getvalue() and ('observer control' in formatted or 'subtest control' in formatted)
    print(k,typ,'stored traceback matched unchanged runner')
print('Three diagnostic-only events. Original IDs selected: zero.')
