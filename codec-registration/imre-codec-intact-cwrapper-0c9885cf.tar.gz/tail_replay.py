"""Resume only never-started originals after a bounded or aborted canonical class."""
import hashlib,sys,time
from concurrent.futures import ThreadPoolExecutor
from qualify import case,cpbase,here,scan
def recover(pin,lane):
    from repeat import label_for,run_ref,run_case
    keys,oracle=cpbase();root=here/'raw'/pin/lane;class_path=root/'class'
    if not (class_path/'result.json').exists():return {}
    m,out,err=case(class_path);g=scan((m,out,err),keys,oracle)
    if not(g['cohort'] and g['registration']==keys):return {}
    pending=[k[1] for k in keys if k[-1] not in g['started']]
    if not pending:return {}
    def batch(ns):
        effective={}
        while ns:
            _,sel=label_for(ns);label='follow-'+hashlib.sha256(sel.encode()).hexdigest()[:12]
            run_ref(label,sel);run_case(pin,lane,label,sel)
            local=scan(case(root/label),[keys[i-1] for i in ns],oracle)
            for k,v in local['originals'].items():
                if v['observed']!='incomplete':effective[k]=v
            next_ns=[i for i in ns if keys[i-1][-1] not in local['started']]
            if not next_ns:break
            # A dispatch that failed before any start cannot make a useful same-selector retry.
            if next_ns==ns:break
            ns=next_ns
        return effective
    merged={};chunks=[pending[i:i+16] for i in range(0,len(pending),16)]
    with ThreadPoolExecutor(2) as service:
        for items in service.map(batch,chunks):merged.update(items)
    return merged
if __name__=='__main__':recover(sys.argv[1],sys.argv[2])
