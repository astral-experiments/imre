"""Longer diagnostic after the fully accounted main packet is independently sealed."""
import concurrent.futures,json,os,subprocess,sys,time
from qualify import case,cpbase,here
from pathlib import Path
from repeat import run_case,run_ref
pin=sys.argv[1];keys,_oracle=cpbase()
base=Path('/workspace/shared/downloads')/('imre-codec-intact-cwrapper-'+pin[:8]+'.tar.gz')
deadline=time.monotonic()+20000
while not base.is_file() and time.monotonic()<deadline:time.sleep(4)
assert base.is_file()
def selected(lane):
    root=here/'raw'/pin/lane
    results=[root/'class/result.json',*root.glob('follow-*/result.json')]
    jobs=set()
    for path in results:
        if not path.is_file():continue
        m=json.loads(path.read_text())
        if m['timeout'] and m.get('timeout_active_original'):jobs.add(m['timeout_active_original'])
    for _i,n,_,k in keys:
        if k in jobs:
            label='long-'+str(n);run_ref(label,k);run_case(pin,lane,label,k)
    return len(jobs)
with concurrent.futures.ThreadPoolExecutor(2) as service:counts=list(service.map(selected,('boxed-O0','boxed-O3')))
print('longer isolated control counts',counts,flush=True)
if any(counts):
    subprocess.run([sys.executable,'-B',here/'seal.py',pin,'36c4f334e96c3bb5a8270ff8f8c85808715fec6d',pin],env={**os.environ,'RWSUFFIX':'-extended'},check=True)
