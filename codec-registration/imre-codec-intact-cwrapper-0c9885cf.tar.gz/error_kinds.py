"""Associate actual unittest error-list tracebacks with original IDs without deriving unrun errors."""
import ast,functools,re
from pathlib import Path
SOURCE=Path(__file__).resolve().parent/'stage/Lib/test/test_io.py'
@functools.lru_cache(maxsize=1)
def functions():
    out=[]
    for cls in ast.parse(SOURCE.read_bytes()).body:
        if isinstance(cls,ast.ClassDef):
            for f in cls.body:
                if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)):out.append((f.lineno,f.end_lineno,cls.name+'.'+f.name))
    return out
TRACE=re.compile(r'^\s*File "([^"]+)", line (\d+)(?:, in (.*))?$',re.M)
SECTION=re.compile(r'^={20,}\n(?P<kind>ERROR|FAIL): (?P<header>[^\n]+)\n(?P<body>[\s\S]*?)(?=^={20,}\n(?:ERROR|FAIL): |^[-]{20,}\nRan \d+ tests? in |\Z)',re.M)
def frames(text):
    out=[]
    for path,ln,method in TRACE.findall(text):
        n=int(ln)
        if path.endswith('/test/test_io.py'):
            owner=next((s for a,b,s in functions() if a<=n<=b),None)
            out.append(dict(source='Lib/test/test_io.py',line=n,method=owner or method or None))
        else:out.append(dict(source=path,line=n,method=method or None))
    return out
def diagnostic(text):
    kind,sep,value=text.partition(' ');msg=value
    if sep:
        try:msg=ast.literal_eval(value)
        except (SyntaxError,ValueError):pass
    return dict(type=kind,message=msg if isinstance(msg,str) else value)
def classify(stderr,originals,inline=None):
    blocks={k:[] for k in originals}
    def add(key,kind,header,text,source_kind):
        trace=frames(text);source=[f for f in trace if f['source']=='Lib/test/test_io.py']
        fixture=next((f for f in source if f['method'] and f['method'].rsplit('.',1)[-1] in ('setUp','tearDown','setUpClass','tearDownClass')),None)
        method=next((f for f in source if f['method'] and f['method'].rsplit('.',1)[-1]==key.rsplit('.',1)[1]),None)
        cleanup=next((f for f in trace if (f['source'].endswith('/unittest/case.py') or f['source'].endswith('unittest/case.py>')) and f['method'] in ('doCleanups','_callCleanup','doClassCleanups','_callClassCleanups')),None)
        stage=fixture['method'].rsplit('.',1)[-1] if fixture else 'cleanup' if cleanup else 'test body' if method else 'unknown from captured frames'
        blocks[key].append(dict(kind=kind,header=header,trace_source=source_kind,phase=stage,upstream_frames=source,terminal_frame=trace[-1] if trace else None))
    for b in SECTION.finditer(stderr):
        # Verbosity 2 headers contain complete ID in parentheses. Match exactly, ignoring subtest parameters.
        h=b.group('header');names=[k for k in originals if re.search(r'(?<![\w.])'+re.escape(k)+r'(?![\w.])',h)]
        if len(names)!=1:continue
        add(names[0],b.group('kind'),h,b.group('body'),'unittest stderr')
    for key,items in (inline or {}).items():
        if key in blocks and not blocks[key]:
            for kind,formatted in items:add(key,kind.upper(),key,formatted,'stored unittest callback traceback')
    for k,obs in originals.items():
        exceptions=[]
        for event in obs['callbacks']:
            if event[0] in ('error','failure'):
                exceptions.append(dict(callback=event[0],**diagnostic(event[2])))
            elif event[0]=='subtest' and event[-1]!='ok':
                exceptions.append(dict(callback='subtest',subtest=event[2],**diagnostic(event[-1])))
        obs['exceptions']=exceptions;obs['tracebacks']=blocks[k]
        obs['phase_labels']=list(dict.fromkeys(b['phase'] for b in blocks[k])) or (['unknown from captured frames'] if exceptions else [])
    return frames(stderr) if not originals else []
