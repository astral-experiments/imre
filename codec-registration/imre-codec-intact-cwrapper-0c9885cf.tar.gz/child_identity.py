"""Sample real direct shutdown helper argv and kernel parent PID for the original class."""
import json,os,sys,time
from pathlib import Path
from qualify import here
pin,lane=sys.argv[1:3];group=here/'raw'/pin/lane/'class';end=time.monotonic()+7200;seen=set()
while time.monotonic()<end and not (group/'result.json').is_file():
    if not (group/'stdout').is_file():
        b=group.parent/'build.json'
        if b.is_file() and json.loads(b.read_text())['exit']!=0:break
        time.sleep(3);continue
    active=None
    for line in (group/'stdout').read_text(errors='replace').splitlines():
        e=line.split('\t')
        if len(e)>=3 and e[0]=='start':active=e[1]
        if len(e)>=3 and e[0]=='stop' and e[1]==active:active=None
    if not active or not active.rsplit('.',1)[-1].startswith('test_create_at_shutdown_'):time.sleep(1);continue
    parents=set();children={};procroot=Path('/proc')
    for proc in procroot.glob('[0-9]*'):
        try:
            argv=(proc/'cmdline').read_bytes().split(b'\0')[:-1]
            if argv==[os.fsencode(group.parent/'suite'),b'--class']:parents.add(int(proc.name))
            if len(argv)>=3 and os.path.basename(argv[0]) in (b'imre',b'python',b'python3',b'python3.14') and b'-c' in argv:
                ppid=int((proc/'stat').read_text().rsplit(')',1)[1].split()[1])
                children[int(proc.name)]=(ppid,argv)
        except (OSError,ValueError):continue
    for pid,(ppid,args) in children.items():
        if ppid not in parents or pid in seen:continue
        try:image=os.readlink(procroot/str(pid)/'exe')
        except OSError:image=None
        argv=[s.decode(errors='replace') for s in args]
        dest=group.parent/'helpers';dest.mkdir(exist_ok=True)
        receipt=dict(ordinal_id=active,kernel_executable_if_accessible=image,argv0=argv[0],pid=pid,ppid=ppid,parent_argv=[str(group.parent/'suite'),'--class'],argv=argv)
        (dest/(active.rsplit('.',1)[-1]+'-'+str(pid)+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');seen.add(pid)
    time.sleep(1)
