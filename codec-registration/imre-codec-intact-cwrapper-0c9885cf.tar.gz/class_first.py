"""Publish each canonical class immediately, before independent positive batches."""
from pathlib import Path
import json,subprocess,sys,time
from qualify import here
pin=sys.argv[1];pending={'boxed-O0','boxed-O3'}
deadline=time.monotonic()+7500
while pending and time.monotonic()<deadline:
    for lane in list(pending):
        base=here/'raw'/pin/lane;b=base/'build.json'
        if (base/'class/result.json').exists() or b.exists() and json.loads(b.read_text())['exit']!=0:
            subprocess.run([sys.executable,'-B',here/'interim.py',pin[:8]+'-'+lane.lower()+'-intact-class-settled',pin],cwd=here,check=True)
            pending.remove(lane)
    if pending:time.sleep(2)
assert not pending,pending
