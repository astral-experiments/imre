"""Snapshot only completed registered callbacks. Preserve separate live vs final process state."""
import csv,hashlib,io,json,os,re,sys,tarfile,tempfile,time
from pathlib import Path
from qualify import here,digest,cpbase,case,scan,inspect
keys,oracle=cpbase()
label=sys.argv[1];assert re.fullmatch('[a-z0-9-]+',label)
pins=sys.argv[2:];assert pins and all(re.fullmatch('[a-f0-9]{40}',p) for p in pins)
members={};states={};rows={k:dict(global_1038=n+682,module_667=o,class_82=n,occurrence=c,id=k,stock='success') for o,n,c,k in keys}
def put(n,b):members[n]=b
def js(d):return (json.dumps(d,indent=2)+'\n').encode()
for pin in pins:
    for lane in ('boxed-O0','boxed-O3'):
        top=here/'raw'/pin/lane;pre=pin[:8]+'/'+lane+'/';cl=top/'class';mode=pin[:8]+'_'+lane
        observed={};confirmed={};follow={};status='build pending'
        if (top/'build.json').exists():
            put(pre+'build.json',(top/'build.json').read_bytes());status='no class start'
        if (cl/'stdout').exists():
            out=(cl/'stdout').read_bytes();err=(cl/'stderr').read_bytes();put(pre+'class/stdout',out);put(pre+'class/stderr',err)
            ended=(cl/'result.json').is_file()
            if ended:
                m,stdout,stderr=case(cl);put(pre+'class/result.json',(cl/'result.json').read_bytes());status='superseded/cancelled by campaign, timeout=false' if (cl/'superseded-cancellation.json').exists() else 'process ended, bounded timeout' if m['timeout'] else 'process ended'
            else:
                m=dict(exit=None,timeout=False,adopted=[],residue=[]);stdout=out[:out.rfind(b'\n')+1].decode(errors='replace');stderr=err.decode(errors='replace');status='live process; exit, shutdown stderr and residue pending'
            scanned=scan((m,stdout,stderr),keys,oracle)
            if scanned['registration']==keys:observed=scanned['originals']
        for receipt in sorted(top.glob('follow-*/result.json')):
            m,out,err=case(receipt.parent)
            assert m['selector'].startswith('--positions=') and m['lane']==lane and m['revision']==pin
            positions=[int(n) for n in m['selector'].split('=',1)[1].split(',')]
            g=scan((m,out,err),[keys[n-1] for n in positions],oracle)
            if g['registration']==[keys[n-1] for n in positions]:
                assert not(set(g['originals']) & set(follow)) and not(set(g['originals']) & set(observed))
                follow.update(g['originals'])
        if all((top/s/'result.json').is_file() for s in ('class','provider','single','wrong')):
            obj=inspect(pin,lane,keys,oracle);confirmed=obj['confirmed_independent_originals']
            for group in obj['followup_after_partial_class'].values():follow.update(group['originals'])
            states[mode+'_controls']=obj['controls']
        for f in top.glob('*/result.json'):
            if f.parent==cl:continue
            for n in ('result.json','stdout','stderr'):
                put(pre+f.parent.name+'/'+n,(f.parent/n).read_bytes())
            ref=here/'raw/cpython/ordinary'/f.parent.name
            if (ref/'result.json').is_file():
                for n in ('result.json','stdout','stderr'):put('reference/'+f.parent.name+'/'+n,(ref/n).read_bytes())
        if (top/'build.superseded.json').exists():status='native compile superseded/cancelled by campaign'
        for f in top.rglob('*.json'):
            if f.name in ('superseded-cancellation.json','cancelled-before-launch.json','harness-cleanup.json','build.superseded.json'):
                put(pre+str(f.relative_to(top)),f.read_bytes())
        states[mode]=status
        for *_,k in keys:
            v=observed.get(k,{});later=follow.get(k,{})
            rows[k][mode+'_canonical']=v.get('observed','unreached')
            rows[k][mode+'_canonical_exception']=' | '.join(x['type']+' '+x['message'] for x in v.get('exceptions',[]))
            rows[k][mode+'_canonical_trace_phase']='/'.join(v.get('phase_labels',[]))
            rows[k][mode+'_disjoint_followup']=later.get('observed','')
            rows[k][mode+'_followup_exception']=' | '.join(x['type']+' '+x['message'] for x in later.get('exceptions',[]))
            rows[k][mode+'_followup_phase']='/'.join(later.get('phase_labels',[]))
            rows[k][mode+'_confirmed_independent']=confirmed.get(k,'')
w=io.StringIO();cw=csv.DictWriter(w,fieldnames=list(next(iter(rows.values()))),delimiter='\t',lineterminator='\n');cw.writeheader();cw.writerows(rows.values())
put('canonical.tsv',w.getvalue().encode());put('summary.json',js(dict(archive_type='immutable intermediate snapshot, not final public evidence',pins=pins,registered_fixture='test.test_io.CTextIOWrapperTest',source_sha256=digest(here/'stage/Lib/test/test_io.py'),class_driver_sha256=digest(here/'stage/Lib/callback_class.py'),per_lane_state=states,observation_time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))))
put('SHA256SUMS',''.join(hashlib.sha256(v).hexdigest()+'  '+n+'\n' for n,v in sorted(members.items())).encode())
path=Path('/workspace/shared/downloads')/('imre-codec-cwrapper-'+label+'.tar.gz');assert not path.exists()
temp=path.with_suffix('.tmp')
with tarfile.open(temp,'w:gz') as t:
    for n,b in sorted(members.items()):
        m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(temp) as t:
    for n,b in members.items():assert t.extractfile(n).read()==b
temp.chmod(0o644);temp.rename(path)
print(path,path.stat().st_size,digest(path),flush=True)
