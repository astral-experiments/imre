"""Keep observed callbacks and rigorously qualified successes in separate fields."""
import argparse,ast,collections,csv,hashlib,json,re,sys
from pathlib import Path
here=Path(__file__).resolve().parent
from verify import audit,digest
from error_kinds import classify
ROOT='test.test_io.CTextIOWrapperTest.'
TIMING=re.compile(r'(?m)^(Ran \d+ tests? in )[\d.]+s$')
def norm(text):return TIMING.sub(r'\g<1><duration>s',text)
def case(d):
    m=json.loads((d/'result.json').read_text()); assert all(digest(d/n)==m[n+'_sha256'] for n in ('stdout','stderr'))
    assert m['cwd']!=m['tmpdir'] and m['stdin_pipe'] and m['stdin_parent_held_through_wait']
    return m,(d/'stdout').read_text(errors='backslashreplace'),(d/'stderr').read_text(errors='backslashreplace')
def scan(triple, expected, oracle):
    m,o,e=triple
    lines=o.splitlines();discovery=lines[:1]==['discovery\t667'];cohort=lines[1:2]==['class\t82']
    reg=[];i=2 if discovery and cohort else 0
    while i<len(lines) and lines[i].startswith('select\t'):
        members=lines[i].split('\t')
        if len(members)!=5 or not all(x.isdigit() for x in members[1:4]):break
        reg.append((*map(int,members[1:4]),members[4]));i+=1
    obs=collections.defaultdict(list);extra=[];events=[];inline=collections.defaultdict(list);last=None;active_output=None;extra_by_case=collections.defaultdict(list);outside_output=[]
    for l in lines[i:]:
        p=l.split('\t')
        if len(p)>=3 and p[0] in ('start','success','skip','failure','error','subtest','stop'):
            obs[p[1]].append(p);events.append((p[0],p[1]));last=p
            if p[0]=='start':active_output=p[1]
            elif p[0]=='stop' and active_output==p[1]:active_output=None
        elif len(p)==4 and p[0]=='trace' and last and last[0]==p[2] and last[1]==p[1] and (p[2] in ('failure','error') or p[2]=='subtest' and last[-1]!='ok'):
            try:
                tr=ast.literal_eval(p[3])
                if not isinstance(tr,str) or not tr.strip():raise ValueError()
            except (SyntaxError,ValueError):extra.append(l)
            else:inline[p[1]].append((p[2],tr))
            last=None
        else:
            extra.append(l)
            if active_output:extra_by_case[active_output].append(l)
            else:outside_output.append(l)
    # A suite-level traceback, a real original exception, or no exception are distinguishable.
    started=[k for op,k in events if op=='start'];stopped=[k for op,k in events if op=='stop']
    expected_keys=[q[-1] for q in expected];reason=[]
    if not (discovery and cohort and reg==expected):reason.append('registration tuple mismatch')
    if started!=expected_keys or stopped!=expected_keys:reason.append('start/stop sequence mismatch')
    active=None
    for op,k in events:
        if op=='start' and active is None:active=k
        elif op=='stop' and active==k:active=None
        elif active!=k or op in ('start','stop'):reason.append('interleaved or misordered callbacks');break
    if active is not None:reason.append('incomplete final callback')
    if extra:reason.append('unexpected stdout')
    runner_runs=re.findall(r'(?m)^Ran (\d+) tests? in [\d.]+s$',e)
    if runner_runs!=[str(len(expected))]:reason.append('runner count mismatch')
    if m['timeout'] or m['adopted'] or m['residue']:reason.append('timeout, child or filesystem residue')
    if any(v in e for v in ('Exception ignored','Exception in thread','unraisablehook','ResourceWarning:','Could not run clang')):reason.append('unexpected stderr diagnostic')
    if m['exit'] not in (0,1):reason.append('abnormal process exit')
    rows={}
    for k,ev in obs.items():
        status=[s for s in ev if s[0] in ('success','error','skip','failure')];sub=[t for t in ev if t[0]=='subtest']
        raw=[s[0] for s in status]
        state=raw[0] if len(raw)==1 else 'multiple callbacks' if raw else 'subtest non-success' if any(t[-1]!='ok' for t in sub) else 'incomplete'
        if ev[0][0]!='start' or ev[-1][0]!='stop':state='incomplete'
        canonical=([['start',k,'']]+[['subtest',k,n,'ok'] for n in oracle.get(k,[])]+[['success',k,''],['stop',k,'']])
        rows[k]=dict(observed=state,callbacks=ev,stdout_outside_callback_protocol=extra_by_case[k],canonical_success_transcript=(ev==canonical and k in oracle))
    non_success=any(c['observed'] in ('error','failure','multiple callbacks','subtest non-success') for c in rows.values())
    if len(started)==len(expected) and len(stopped)==len(expected) and m['exit']!=int(not expected or non_success):reason.append('exit contradicts callbacks')
    first=next((s[2] for k,ev in obs.items() for s in ev if s[0] in ('failure','error')),None)
    if not first and 'Traceback (most recent call last):' in e:
        first=next((ln for ln in reversed(e.splitlines()) if re.match(r'^[A-Za-z_][\w.]*?(?:Error|Exception)(?:: |$)',ln)),None)
    trace=classify(e,rows,inline)
    return dict(unexpected_stdout_outside_originals=outside_output,pre_registration_frames=trace if not started else [],stage='original callbacks' if started else 'after module registration' if any(l.startswith('discovery\t') for l in lines) else 'before registration',discovery=discovery,cohort=cohort,registration=reg,started=started,excluded=reason,originals=rows,first_exception=first,returncode=m['exit'],stderr_markers=[s for s in ('Exception ignored','Exception in thread','ResourceWarning:','unraisablehook') if s in e])
def cpbase():
    stage=here/'stage'
    assert all(digest(stage/n)==v for n,v in json.loads((here/'upstream-hashes.json').read_text()).items())
    assert digest(stage/'Lib/callback_class.py')==json.loads((here/'provenance.json').read_text())['driver_sha256']
    stock=audit(here/'raw/cpython/ordinary')
    keys=[(r['module_ordinal'],r['class_ordinal'],r['occurrence'],r['identity']) for r in stock['results']]
    oracle={r['identity']:r['subtests'] for r in stock['results']}
    assert digest(here/'fresh-oracle.json')==digest(here/'oracle.json') and json.loads((here/'fresh-oracle.json').read_text())==stock
    return keys,oracle
SIDE_MARKERS=('Exception ignored','ResourceWarning:','Exception in thread','unraisablehook','Could not run clang')
def progress_chunks(stderr,keys):
    # Bound each ordinary verbosity-2 testcase line before the traceback list or summary.
    ids={k[-1] for k in keys}
    boundary=re.search(r'(?m)^={20,}\n(?:ERROR|FAIL): |^[-]{20,}\nRan \d+ tests? in ',stderr)
    boundary=boundary.start() if boundary else len(stderr)
    header=re.compile(r'(?m)^test_\w+ \((test\.test_io\.CTextIOWrapperTest\.test_\w+)\)')
    all_heads=[h for h in header.finditer(stderr[:boundary]) if h[1] in ids]
    pieces={h[1]:stderr[h.start():(all_heads[n+1].start() if n+1<len(all_heads) else boundary)].rstrip('\n') for n,h in enumerate(all_heads)}
    outside=stderr[:all_heads[0].start()] + stderr[boundary:] if all_heads else stderr
    return pieces,[s for s in SIDE_MARKERS if s in outside]
def valid_process(m):return not m['timeout'] and not m['residue'] and not m['adopted']
def inspect(pin,lane,keys,oracle,confirmations_available=True,include_long=False):
    root=here/'raw'/pin/lane;ref=here/'raw/cpython/ordinary';b=json.loads((root/'build.json').read_text())
    driver=here/'prior_driver.py' if pin=='36c4f334e96c3bb5a8270ff8f8c85808715fec6d' else here/'stage/Lib/callback_class.py'
    assert b['pin']==pin and b['lane']==lane and b['driver_sha256']==digest(driver)
    assert all(digest(root/('build.'+s))==b[s+'_sha256'] for s in ('stdout','stderr'))
    out=dict(build=b)
    if b['timeout'] or b['exit']!=0:return dict(**out,stage='compile failure or timeout',qualified=[],selections={})
    assert b['executable_sha256']
    raw={sel:case(root/sel) for sel in ('class','wrong','provider','single')}
    assert all(m['revision']==pin and m['lane']==lane and m['visible_helper']==b['argv'][0] and m['argv'][0]==b['argv'][b['argv'].index('-o')+1] for m,_,_ in raw.values())
    cl=scan(raw['class'],keys,oracle);si=scan(raw['single'],keys[:1],oracle);wrong=scan(raw['wrong'],[],oracle);p,po,pe=raw['provider']
    crm,co,ce=case(ref/'class');w,wo,we=case(ref/'wrong');s,so,se=case(ref/'single')
    wm,wout,werr=raw['wrong'];sm,sout,serr=raw['single'];cm,cout,cerr=raw['class']
    wr=bool(valid_process(wm) and wm['exit']==1 and wout==wo and norm(werr)==norm(we) and not wrong['excluded'])
    pr=bool(valid_process(p) and p['exit']==0 and not pe and po.splitlines()[:2]==['discovery\t667','class\t82'] and len(po.splitlines())==4 and po.splitlines()[-1]=='provider True True True True True True True')
    # A real selected failure in the single is admissible evidence for other IDs, but must match its class callback.
    sk=keys[0][-1];srow=si['originals'].get(sk,{});crow=cl['originals'].get(sk,{})
    if srow.get('observed')=='success':single_ok=valid_process(sm) and sm['exit']==0 and sout==so and norm(serr)==norm(se)
    else:single_ok=not si['excluded'] and srow.get('observed') in ('error','failure','skip') and srow.get('observed')==crow.get('observed')
    controls=dict(absent=wr,provider=pr,single=bool(single_ok))
    exact=cm['exit']==0 and cout==co and norm(cerr)==norm(ce)
    progress,outside_marks=progress_chunks(cerr,keys);stock_progress,_=progress_chunks(ce,keys)
    progress_clean={k:k in stock_progress and text==stock_progress[k] for k,text in progress.items()}
    structural=[why for why in cl['excluded'] if why!='unexpected stderr diagnostic']
    case_eligible=all(controls.values()) and not structural and not outside_marks
    passed=[]
    if case_eligible:
        for k,val in cl['originals'].items():
            if not val['canonical_success_transcript'] or not progress_clean.get(k):continue
            if exact or (k==sk and single_ok and srow.get('observed')=='success'):passed.append(k);continue
            # Mixed-result groups need an isolated CPython comparison to separate unexpected stderr.
            if not confirmations_available:continue
            n=next(q[1] for q in keys if q[-1]==k);nd=root/('confirm-'+str(n));rd=ref/('confirm-'+str(n))
            if not ((nd/'result.json').exists() and (rd/'result.json').exists()):continue
            nm,no,ne=case(nd);rm,ro,re_=case(rd)
            if all(valid_process(m) and m['exit']==0 for m in (nm,rm)) and no==ro and norm(ne)==norm(re_) and not scan((nm,no,ne),[keys[n-1]],oracle)['excluded']:passed.append(k)
    confirmations={}
    for nd in (sorted(root.glob('confirm-*/result.json')) if confirmations_available else []):
        label=nd.parent.name;n=int(label.split('-')[-1]);key=keys[n-1]
        nm,no,ne=case(nd.parent);rm,ro,re_=case(ref/label)
        native=scan((nm,no,ne),[key],oracle);reference=scan((rm,ro,re_),[key],oracle)
        assert nm['argv'][-1]==rm['argv'][-1]==key[-1] and nm['revision']==pin
        clean=all(valid_process(m) and m['exit']==0 for m in (nm,rm)) and no==ro and norm(ne)==norm(re_) and all(not g['excluded'] and g['originals'].get(key[-1],{}).get('canonical_success_transcript') for g in (native,reference))
        assert nm['lane']==lane and nm['visible_helper']==b['argv'][0] and nm['argv'][0]==b['argv'][b['argv'].index('-o')+1]
        confirmations[key[-1]]=dict(reference_matched_success=bool(clean),observed=native['originals'].get(key[-1]),excluded=native['excluded'],unexpected_stderr=native['stderr_markers'],stock=reference['originals'].get(key[-1],{}).get('observed'),streams_match=(no==ro and norm(ne)==norm(re_)))
    followup={}
    for nd in (sorted(root.glob('follow-*/result.json')) if confirmations_available else []):
        nm,no,ne=case(nd.parent);rd=ref/nd.parent.name
        assert nm['selector']==nm['argv'][-1] and nm['selector'].startswith('--positions=')
        rm,ro,re_=case(rd);assert rm['selector']==nm['selector'] and nm['visible_helper']==b['argv'][0] and nm['revision']==pin and nm['lane']==lane and nm['argv'][0]==b['argv'][b['argv'].index('-o')+1]
        ns=[int(x) for x in nm['selector'].split('=',1)[1].split(',')];assert ns==sorted(set(ns)) and all(1<=n<=82 for n in ns)
        chosen=[keys[n-1] for n in ns];g=scan((nm,no,ne),chosen,oracle);cg=scan((rm,ro,re_),chosen,oracle)
        assert not cg['excluded']
        progress,outer=progress_chunks(ne,chosen);reference_progress,_=progress_chunks(re_,chosen)
        matched={k:k in reference_progress and text==reference_progress[k] for k,text in progress.items()}
        followup[nd.parent.name]=dict(positions=ns,originals=g['originals'],stock_progress_stderr_matched=matched,diagnostics_outside_case_progress=outer,exclusions=g['excluded'],returncode=nm['exit'],timeout=nm['timeout'],timeout_reason=nm.get('timeout_reason'),timeout_active_original=nm.get('timeout_active_original'),residue=nm['residue'],adopted=nm['adopted'])
    registered=cl['discovery'] and cl['cohort'] and cl['registration']==keys
    followup_keys=set()
    for lot in followup.values():
        assert all(keys[n-1][-1] not in cl['started'] for n in lot['positions'])
        started=set(lot['originals'])
        assert not(followup_keys & started)
        followup_keys.update(started)
    subset_repeats={}
    repeat_clean=set()
    for nd in (sorted(root.glob('pick-*/result.json')) if confirmations_available else []):
        d=nd.parent;rd=ref/d.name
        if not (rd/'result.json').exists():continue
        nm,no,ne=case(d);rm,ro,re_=case(rd);sel=nm['selector']
        assert nm['revision']==pin and nm['lane']==lane and nm['argv'][0]==b['argv'][b['argv'].index('-o')+1] and nm['visible_helper']==b['argv'][0]
        assert sel==nm['argv'][-1]==rm['argv'][-1] and sel.startswith('--positions=')
        ns=[int(x) for x in sel.split('=',1)[1].split(',')];assert ns==sorted(set(ns)) and all(1<=n<=len(keys) for n in ns)
        chosen=[keys[n-1] for n in ns];g=scan((nm,no,ne),chosen,oracle);cg=scan((rm,ro,re_),chosen,oracle)
        clean=bool(no==ro and norm(ne)==norm(re_) and all(valid_process(m) and m['exit']==0 for m in (nm,rm)) and not g['excluded'] and not cg['excluded'] and list(g['originals'])==[t[-1] for t in chosen] and all(v['canonical_success_transcript'] for v in g['originals'].values()))
        if clean:
            repeat_clean.update(t[-1] for t in chosen)
        subset_repeats[d.name]=dict(positions=ns,selection=sel,reference_matched=clean,observed={k:o['observed'] for k,o in g['originals'].items()},exclusions=g['excluded'])
    if case_eligible:
        passed.extend(k for k in repeat_clean if k not in passed and progress_clean.get(k) and cl['originals'].get(k,{}).get('canonical_success_transcript'))
    passed.sort(key=lambda k:next(n for _,n,_,i in keys if i==k))
    witnesses=set(repeat_clean)|{k for k,v in confirmations.items() if v['reference_matched_success']}
    if single_ok and srow.get('canonical_success_transcript'):witnesses.add(sk)
    longer_timeout={}
    for done in (sorted(root.glob('long-*/result.json')) if confirmations_available and include_long else []):
        nd=done.parent;rd=ref/nd.name;pos=int(nd.name.split('-')[1]);assert 1<=pos<=82;q=keys[pos-1]
        source='canonical group' if cm['timeout'] and cm['timeout_active_original']==q[-1] else next((name for name,f in followup.items() if f['timeout'] and f['timeout_active_original']==q[-1]),None)
        x=case(nd);y=case(rd);g=scan(x,[q],oracle);cg=scan(y,[q],oracle)
        assert source and x[0]['selector']==y[0]['selector']==q[-1] and x[0]['lane']==lane and x[0]['revision']==pin and x[0]['visible_helper']==b['argv'][0] and not cg['excluded']
        clean=all(valid_process(z[0]) and z[0]['exit']==0 for z in (x,y)) and not g['excluded'] and x[1]==y[1] and norm(x[2])==norm(y[2]) and g['originals'].get(q[-1],{}).get('canonical_success_transcript')
        longer_timeout[q[-1]]=dict(origin=source,bound_seconds=600,clean_reference_matched=bool(clean),observed=g['originals'].get(q[-1],{}),exclusions=g['excluded'],returncode=x[0]['exit'],timeout=x[0]['timeout'],timeout_reason=x[0].get('timeout_reason'))
    confirmed={}
    if registered and all(controls.values()):
        for k in witnesses:
            if cl['originals'].get(k,{}).get('canonical_success_transcript') and progress_clean.get(k):
                confirmed[k]='canonical group'
            elif any(v['originals'].get(k,{}).get('canonical_success_transcript') and v['stock_progress_stderr_matched'].get(k) for v in followup.values()):
                confirmed[k]='disjoint follow-up'
    if registered and all(controls.values()):
        for k,v in longer_timeout.items():
            if v['clean_reference_matched']:confirmed[k]='extended isolated rerun after '+v['origin']+' timeout'
    for k in passed:confirmed.setdefault(k,'canonical group')
    confirmed={k:confirmed[k] for *_,k in keys if k in confirmed}
    return dict(**out,canonical_process={n:cm.get(n) for n in ('exit','timeout','timeout_reason','timeout_active_original','adopted','residue','elapsed_seconds')},extended_isolated_after_timeout=longer_timeout,confirmed_independent_originals=confirmed,stage=cl['stage'],first_exception=cl['first_exception'],selections={'class':cl,'single':si,'wrong':wrong,'provider':dict(rc=p['exit'],stdout=po,stderr=pe)},controls=controls,stock_progress_stderr_matched=progress_clean,diagnostics_outside_case_progress=outside_marks,isolated_confirmations=confirmations,subset_repeats=subset_repeats,followup_after_partial_class=followup,independent_clean_subset_ids=sorted(repeat_clean),full_clean_transcript=exact,qualified=passed)
def gen(pins,lanes,confirmations_available=True,include_long=False):
    keys,oracle=cpbase();ledger=here/'global-1038-ae0e69c.tsv'
    assert digest(ledger)=='f4f208cfd969ac9ca40a16f52ed9fc37b7ceef1a3fd0b98e408dd3afd07bc88c'
    with ledger.open() as f:history=list(csv.DictReader(f,delimiter='\t'))
    h={(r['id'],int(r['occurrence'])):r for r in history};assert len(history)==1038
    allruns={p:{l:inspect(p,l,keys,oracle,confirmations_available,include_long) for l in lanes} for p in pins}
    original_by_id={r['identity']:r for r in json.loads((here/'fresh-oracle.json').read_text())['results']}
    rows=[]
    for ordinal,pos,occ,k in keys:
        prior=h[k,occ];g=int(prior['index']);assert g==pos+682 and prior['reference_verdict']=='PASS' and all(prior[n]=='UNREACHED' for n in ('ordinary.O0','ordinary.O3','boxed.O0','boxed.O3'))
        original=original_by_id[k];assert k.startswith(original['fixture']+'.')
        row=dict(global_1038=g,module_667=ordinal,class_82=pos,occurrence=occ,id=k,fixture=original['fixture'],method_defined_by=original['method_defined_by'],source_line=original['source_line'],stock='success')
        for p,lanes in allruns.items():
            for name,run in lanes.items():
                o=run['selections'].get('class',{}).get('originals',{}).get(k,{})
                row[p[:8]+'_'+name+'_observed']=o.get('observed','unreached')
                matches=[v['originals'][k] for v in run.get('followup_after_partial_class',{}).values() if k in v['originals']]
                row[p[:8]+'_'+name+'_canonical_timeout']=int(run.get('canonical_process',{}).get('timeout_active_original')==k)
                row[p[:8]+'_'+name+'_disjoint_followup_timeout']=int(any(lot.get('timeout_active_original')==k for lot in run.get('followup_after_partial_class',{}).values()))
                row[p[:8]+'_'+name+'_followup_observed']='|'.join(m['observed'] for m in matches)
                row[p[:8]+'_'+name+'_followup_stock_progress_stderr_match']='|'.join(str(v['stock_progress_stderr_matched'].get(k,'')) for v in run.get('followup_after_partial_class',{}).values() if k in v['originals'])
                row[p[:8]+'_'+name+'_followup_exception_types']='|'.join(','.join(x['type'] for x in m.get('exceptions',[])) for m in matches)
                row[p[:8]+'_'+name+'_followup_trace_lines']='|'.join(','.join(str(f['line']) for tr in m.get('tracebacks',[]) for f in tr['upstream_frames']) for m in matches)
                row[p[:8]+'_'+name+'_followup_phase']='|'.join('/'.join(m['phase_labels']) for m in matches)
                row[p[:8]+'_'+name+'_qualified']=int(k in run['qualified'])
                row[p[:8]+'_'+name+'_independent_or_full_group_confirmed']=run.get('confirmed_independent_originals',{}).get(k,'')
                row[p[:8]+'_'+name+'_stock_progress_stderr_match']=run.get('stock_progress_stderr_matched',{}).get(k,'')
                extra=run.get('extended_isolated_after_timeout',{}).get(k,{})
                row[p[:8]+'_'+name+'_extended_600s_observed']=extra.get('observed',{}).get('observed','')
                row[p[:8]+'_'+name+'_extended_600s_timeout']=extra.get('timeout','')
                row[p[:8]+'_'+name+'_clean_subset']=int(k in run.get('independent_clean_subset_ids',()))
                row[p[:8]+'_'+name+'_extra_stdout']=repr(o.get('stdout_outside_callback_protocol',[]) or [t for m in matches for t in m.get('stdout_outside_callback_protocol',[])])
                row[p[:8]+'_'+name+'_exceptions']=','.join(x['type'] for x in o.get('exceptions',[]))
                row[p[:8]+'_'+name+'_phase']='/'.join(o.get('phase_labels',[]))
                row[p[:8]+'_'+name+'_trace_lines']=','.join(str(x['line']) for b in o.get('tracebacks',[]) for x in b['upstream_frames'])
        rows.append(row)
    both={p:[k for *_,k in keys if all(k in run.get('confirmed_independent_originals',{}) for run in by_lane.values())] for p,by_lane in allruns.items() if len(by_lane)==2}
    return dict(pins=pins,lanes=list(next(iter(allruns.values()))),confirmed_at_both_optimization_levels=both,stock={'registered':667,'class':82,'passed':82,'subtests':6},runs=allruns,rows=rows)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('pins',nargs='+');p.add_argument('--tsv',action='store_true');p.add_argument('--only',choices=['boxed-O0','boxed-O3']);p.add_argument('--extended',action='store_true');a=p.parse_args();j=gen(a.pins,[a.only] if a.only else ['boxed-O0','boxed-O3'],not a.only,a.extended)
    if a.tsv:
        w=csv.DictWriter(sys.stdout,fieldnames=list(j['rows'][0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(j['rows'])
    else:print(json.dumps(j,indent=2))
