import codecs
import encodings
import sys

default = encodings.search_function

def priority():
    native = codecs.lookup('UTF-8')
    visits = []
    def before(name):
        visits.append(name)
        if name == 'utf_8':
            return response
    def encode(obj,errors='strict'):
        return b'CUSTOM',len(obj)
    def decode(obj,errors='strict'):
        return 'CUSTOM',len(obj)
    response = (encode,decode,None,None)
    codecs.register(before)
    assert codecs.lookup('UTF-8') is native and visits == []
    assert encodings.search_function('utf_8') is native
    assert codecs.unregister(default) is None
    entry = codecs.lookup('UTF-8')
    assert entry is response and visits==['utf_8']
    print('overridden',entry is response, visits, flush=True)
    assert codecs.register(default) is None
    assert codecs.lookup('UTF-8') is response and visits == ['utf_8']
    print('append keeps cached result',visits)
    assert codecs.unregister(before) is None
    assert codecs.lookup('UTF-8') is native
    print('restored identity',codecs.lookup('UTF-8') is native, flush=True)
    assert codecs.unregister(default) is None
    try:codecs.lookup('UTF-8')
    except LookupError as error:print('empty',str(error));assert str(error)=="no codec search functions registered: can't find encoding"
    else:raise AssertionError('default remained installed')
    assert codecs.unregister(default) is None
    assert codecs.register(default) is None
    assert codecs.lookup('UTF-8') is native

def consumers():
    visits=[]
    response=(lambda obj,*a:(b'CUSTOM',len(obj)),lambda obj,*a:('CUSTOM',len(obj)),None,None)
    def custom(name):
        visits.append(name)
        if name=='utf_8':return response
    codecs.register(custom)
    codecs.unregister(default)
    print('transform',codecs.encode('x','utf-8'),codecs.decode(b'x','utf-8'), flush=True)
    assert codecs.encode('x','utf-8') == b'CUSTOM' and codecs.decode(b'x','utf-8') == 'CUSTOM'
    assert 'x'.encode('utf-8') == b'x' and b'x'.decode('utf-8')=='x'
    print('builtin UTF-8 fastpaths',visits,flush=True)
    assert visits==['utf_8']

def direct():
    native=codecs.lookup('UTF-8')
    print('direct', default(encoding='utf_8') is native, default('UTF-8'), default(b'ascii').name)
    assert default(encoding='utf_8') is native and default('UTF-8') is None and default(b'ascii').name=='ascii'

def metadata():
    print('metadata',default.__name__,default.__module__)
    assert default.__name__=='search_function' and default.__module__=='encodings'

cases={'priority':priority,'consumers':consumers,'direct':direct,'metadata':metadata}
cases[sys.argv[1]]()
