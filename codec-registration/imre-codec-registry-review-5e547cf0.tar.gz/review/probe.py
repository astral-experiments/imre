import codecs
import gc
import sys
import weakref

key = "qz_registry_probe"
trace = []

def result(label):
    return (label, None, None, None)

def error(f, *args):
    try:
        f(*args)
    except Exception as exc:
        return (type(exc).__name__, str(exc))
    raise AssertionError("expected lookup to fail")

def mutation():
    def last(n):
        trace.append("last")
        return result("late")
    def add(n):
        trace.append("add")
        if trace == ["add"]:
            codecs.register(last)
    codecs.register(add)
    assert error(codecs.lookup, key) == ("LookupError", "unknown encoding: " + key)
    assert codecs.lookup(key)[0] == "late"
    assert codecs.lookup(key)[0] == "late"
    assert trace == ["add", "add", "last"]
    print("append", trace)
    codecs.unregister(add)
    codecs.unregister(last)
    trace.clear()

    def a(n):
        trace.append("A")
        codecs.unregister(a)
    def b(n):
        trace.append("B")
    def c(n):
        trace.append("C")
    for f in (a, b, c):
        codecs.register(f)
    exc = error(codecs.lookup, key)
    assert trace == ["A", "C"] and exc == ("IndexError", "list index out of range")
    print("shrink", trace, exc)
    for f in (b, c):
        codecs.unregister(f)
    trace.clear()

    def replace(n):
        trace.append("replace")
        codecs.unregister(b)
        codecs.register(last)
    for f in (replace, b):
        codecs.register(f)
    assert codecs.lookup(key)[0] == "late" and trace == ["replace", "last"]
    print("replace", trace)

def recursion():
    busy = False
    inner, outer = result("inner"), result("outer")
    def first(n):
        nonlocal busy
        if not busy:
            busy = True
            trace.append("outer-in")
            assert codecs.lookup(n) is inner
            trace.append("outer-out")
            return outer
        trace.append("inner-in")
    def second(n):
        trace.append("inner-hit")
        return inner
    codecs.register(first)
    codecs.register(second)
    assert codecs.lookup(key) is outer and codecs.lookup(key) is outer
    assert trace == ["outer-in","inner-in","inner-hit","outer-out"]
    print("reenter", trace, "cached", codecs.lookup(key)[0])
    codecs.unregister(first)
    codecs.unregister(second)
    trace.clear()

    def remove_self(n):
        trace.append(n)
        codecs.unregister(remove_self)
        return outer
    codecs.register(remove_self)
    assert codecs.lookup(key) is outer and codecs.lookup(key) is outer
    assert codecs.unregister(remove_self) is None and codecs.lookup(key) is outer
    assert trace == [key]
    print("self-unregistered result cached", trace)

def identity():
    class Callback:
        def __eq__(self, other):
            raise AssertionError("equality invoked")
        def __call__(self, name):
            trace.append(name)
            return result(len(trace))
    f, impostor = Callback(), Callback()
    codecs.register(f)
    codecs.register(f)
    val = codecs.lookup(key)
    for miss in (impostor, None, 42):
        assert codecs.unregister(miss) is None
    assert codecs.lookup(key) is val and len(trace) == 1
    codecs.unregister(f)
    new = codecs.lookup(key)
    assert new is not val and len(trace) == 2
    codecs.unregister(f)
    assert error(codecs.lookup, key) == ("LookupError","unknown encoding: " + key)
    print("identity, duplicates, no-op cache", trace, val[0], new[0])
    class Bound:
        def search(self,n): return result("bound")
    obj = Bound()
    saved = obj.search
    codecs.register(saved)
    assert obj.search == saved and obj.search is not saved
    codecs.unregister(obj.search)
    assert codecs.lookup(key)[0] == "bound"
    codecs.unregister(saved)
    assert error(codecs.lookup, key) == ("LookupError","unknown encoding: " + key)
    print("fresh equal bound method ignored")

def normalization():
    def f(n):
        trace.append(n)
        if n == "qz_aa..9":
            return result("hit")
    codecs.register(f)
    assert codecs.lookup("__QzéΣ*!Aa..9--") is codecs.lookup("qz / aa..9")
    assert trace == ["qz_aa..9"]
    misses = ["!?","é", "Qz. / Y"]
    for s in misses:
        assert error(codecs.lookup,s) == ("LookupError", "unknown encoding: "+s)
    assert trace == ["qz_aa..9", "", "", "qz._y"]
    assert error(codecs.lookup, "Z\x00Y") == ("ValueError", "embedded null character")
    assert error(codecs.lookup, "\ud800")[0] == "UnicodeEncodeError"
    assert len(trace) == 4
    print("normalized keys", trace, "nul/surrogate rejected pre-callback")

def lifetime():
    class Token: pass
    class Provider:
        def __call__(self, n):
            t=Token()
            tokens.append(weakref.ref(t))
            trace.append(n)
            return (t,None,None,None)
    tokens=[]
    p=Provider()
    pref=weakref.ref(p)
    codecs.register(p)
    del p
    gc.collect()
    assert pref() is not None
    def unused(n): pass
    codecs.lookup(key)
    gc.collect()
    assert tokens[0]() is not None
    codecs.register(unused)
    assert codecs.lookup(key)[0] is tokens[0]() and len(trace)==1
    codecs.unregister(None)
    assert codecs.lookup(key)[0] is tokens[0]() and len(trace)==1
    codecs.unregister(unused)
    gc.collect()
    assert tokens[0]() is None and pref() is not None
    codecs.lookup(key)
    gc.collect()
    assert tokens[1]() is not None and len(trace)==2
    codecs.unregister(pref())
    gc.collect()
    assert pref() is None and tokens[1]() is None
    print("cache and callback roots released", trace)

def cache_destructor():
    class Token:
        def __del__(self):
            trace.append("drop")
            assert codecs.lookup(key+"_nested") is nested
    nested=result("reentered")
    def producer(n):
        if n==key:
            return (Token(),None,None,None)
        if n==key+"_nested":
            trace.append("new")
            return nested
    def unrelated(n): return None
    codecs.register(producer)
    codecs.register(unrelated)
    codecs.lookup(key)
    codecs.unregister(unrelated)
    assert trace==["drop","new"] and codecs.lookup(key+"_nested") is nested and trace==["drop","new"]
    print("eviction destructor refilled cache",trace)

cases={"mutation":mutation,"recursion":recursion,"identity":identity,"normalization":normalization,
       "lifetime":lifetime,"cache_destructor":cache_destructor}

def unknown():
    class S(str):
        def __str__(self):
            raise AssertionError("str subclass invoked")
    calls=[]
    def f(name):
        calls.append(name)
    codecs.register(f)
    for s in (S("Qz--Odd Input"),"Qz??Odd-Input",b"name",7,"\0","\udc80"):
        ty,msg=error(codecs.lookup,s)
        print(ty,msg)
    assert calls == ["qz_odd_input","qz_odd_input"]

def normalized_identity():
    names=[]
    def f(name):
        names.append(name)
    codecs.register(f)
    for s in ("Qz-Identity Test-Long","Qz Identity!Test--Long"):
        error(codecs.lookup,s)
    print("normalized argument identity",names[0] is names[1], names[0] is sys.intern(names[0]),flush=True)
    assert names[0] is names[1] and names[0] is sys.intern(names[0])

cases['unknown']=unknown
cases['normalized_identity']=normalized_identity
cases[sys.argv[1]]()
