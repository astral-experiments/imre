import codecs
import encodings
import sys
trace=[]
def custom(name):
    trace.append(name)
    return (lambda data,*args: (b'CUSTOM',len(data)),lambda data,*args: ('CUSTOM',len(data)),None,None)
codecs.register(custom)
codecs.unregister(encodings.search_function)
name=sys.argv[1]
buf=b'A\0\0\0'
print('codecs', name, repr(codecs.decode(buf,name)),trace,flush=True)
assert codecs.decode(buf,name)=='CUSTOM' and len(trace)==1
