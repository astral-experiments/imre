"""Audit one isolated process. Stdout is callback protocol, stderr belongs to unittest."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
base=here.parents[1]
lane, revision, name, selection, target = sys.argv[1:6]
dst=here/'raw'/revision/lane/name;dst.mkdir(parents=True)
work=dst/'cwd';work.mkdir()
tmp=dst/'tmpdir';tmp.mkdir()
cmd=[target,*sys.argv[6:],selection]
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONWARNINGS','PYTHON_CONTEXT_AWARE_WARNINGS','LD_PRELOAD','IMRE_PYTHON')}
env.update(TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1')
if revision!='cpython':
    pair=Path(os.environ['CWRAPPER_PAIR']).resolve();llvm=Path(os.environ['CWRAPPER_LLVM']).resolve()
    env.update(IMRE_PYTHON=str(pair/'imre'),LD_LIBRARY_PATH=str(llvm/'usr/lib/x86_64-linux-gnu'),
               PATH=str(llvm/'usr/lib/llvm-19/bin')+os.pathsep+env['PATH'])
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
start=time.monotonic()
timeout=False
timeout_reason=None
timeout_active_id=None
with (dst/'stdout').open('wb') as out,(dst/'stderr').open('wb') as err:
    with subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=out,stderr=err,cwd=work,env=env,start_new_session=True) as proc:
        fifo=stat.S_ISFIFO(os.fstat(proc.stdin.fileno()).st_mode)
        assert fifo and not proc.stdin.closed
        try:
            limit=1800 if name=='class' else 600
            active=None;last_change=start;size=0
            while True:
                try:
                    proc.wait(timeout=min(3,max(.01,limit-(time.monotonic()-start))))
                    break
                except subprocess.TimeoutExpired:
                    now=time.monotonic()
                    path=dst/'stdout';new_size=path.stat().st_size
                    if new_size!=size:
                        lines=path.read_bytes().decode(errors='replace').splitlines()
                        active=None
                        for ln in lines:
                            fields=ln.split('\t')
                            if len(fields)>=3 and fields[0]=='start':active=fields[1]
                            elif len(fields)>=3 and fields[0]=='stop' and fields[1]==active:active=None
                        size=new_size;last_change=now
                    # Stock class takes less than a second; allow three minutes of silent execution
                    # after a real start before recording a timeout. Loading has its own total bound.
                    if active and now-last_change>180:
                        timeout=True;timeout_reason='180 seconds without callback progress after original started';timeout_active_id=active;break
                    if now-start>=limit:
                        timeout=True;timeout_reason='process exceeded overall '+str(limit)+' second bound';timeout_active_id=active;break
        finally:
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            proc.wait(timeout=20)
            held=not proc.stdin.closed
            proc.stdin.close()
adopted=[]
for _ in range(100):
    try: pid,rc=os.waitpid(-1,os.WNOHANG)
    except ChildProcessError:break
    if pid:adopted.append([pid,rc])
    else: time.sleep(.05)
else:raise RuntimeError('living adopted child')
def collect(base):
    inventory=[]
    def failure(exc):
        inventory.append({'unreadable':os.path.relpath(exc.filename,base),'errno':exc.errno})
    for path,dirs,files in os.walk(base,onerror=failure):
        for entry in sorted([*dirs,*files]):
            target=Path(path)/entry
            inventory.append({'path':str(target.relative_to(base)),'mode':oct(target.lstat().st_mode)})
    if not inventory: base.rmdir()
    return inventory
cwd_residue,tmp_residue=collect(work),collect(tmp)
inventory=[{'root':name,'entry':entry} for name,entries in [('cwd',cwd_residue),('tmpdir',tmp_residue)] for entry in entries]
data={'revision':revision,'lane':lane,'kind':name,'selector':selection,'visible_helper':env.get('IMRE_PYTHON',str(target)),'argv':cmd,'exit':proc.returncode,'timeout':timeout,'timeout_reason':timeout_reason,'timeout_active_original':timeout_active_id,'adopted':adopted,'cwd':str(work),'tmpdir':str(tmp),'cwd_residue':cwd_residue,'tmpdir_residue':tmp_residue,
      'stdin_pipe':fifo,'stdin_parent_held_through_wait':held,'residue':inventory,'elapsed_seconds':round(time.monotonic()-start,3)}
for stream in ('stdout','stderr'):
    b=(dst/stream).read_bytes();data[stream+'_bytes']=len(b);data[stream+'_sha256']=hashlib.sha256(b).hexdigest()
(dst/'result.json').write_text(json.dumps(data,indent=2)+'\n')
print(revision[:8],lane,name,data['exit'],data['elapsed_seconds'],'residue',len(inventory),flush=True)
