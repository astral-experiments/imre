"""Synthetic verifier fault injections only: no specimens below are original receipts."""
from qualify import case,cpbase,scan,here
keys,oracle=cpbase()
ref=here/'raw/cpython/ordinary';m,o,e=case(ref/'class');x=keys[0][-1]
good=scan((m,o,e),keys,oracle);assert not good['excluded'] and len(good['started'])==82
def invalidate(label,m,o,e):
    r=scan((m,o,e),keys,oracle);assert r['excluded'],label
    print(label,'=>',','.join(r['excluded']))
invalidate('registration ordinal drift',m,o.replace('select\t445\t','select\t444\t',1),e)
invalidate('single passed as whole class',*case(ref/'single'))
invalidate('success after stop',m,o.replace('success\t'+x+'\t\nstop\t'+x+'\t','stop\t'+x+'\t\nsuccess\t'+x+'\t',1),e)
invalidate('unexpected stdout',m,o+'outside-protocol\n',e)
invalidate('unraisable',m,o,e+'Exception ignored in: <function __del__>\n')
invalidate('timeout',dict(m,timeout=True),o,e)
invalidate('adopted child',dict(m,adopted=[[5252,0]]),o,e)
invalidate('leftover file',dict(m,residue=['testfile']),o,e)
invalidate('missing summary',m,o,e.replace('Ran 82 tests','Ran no tests'))
invalidate('exit contradicts callbacks',dict(m,exit=1),o,e)
# Verify a different pre-registration exception yields zero observed original callbacks.
q=scan((dict(m,exit=1),'',"Traceback (most recent call last):\nAttributeError: fixture second blocked symbol\n"),keys,oracle)
assert q['stage']=='before registration' and not q['originals'] and q['first_exception']=='AttributeError: fixture second blocked symbol'
# An extra successful subtest is observed but cannot qualify as the canonical transcript.
q=scan((m,o.replace('success\t'+x+'\t','subtest\t'+x+'\t'+x+' (extra=True)\tok\nsuccess\t'+x+'\t',1),e),keys,oracle)
assert q['originals'][x]['observed']=='success' and not q['originals'][x]['canonical_success_transcript']
print('alternate blocker and unexpected subtest: 0 attributable successes')
from error_kinds import classify
v={x:{'callbacks':[['start',x,''],['error',x,"ValueError 'example'"],['stop',x,'']]}}
fake='='*70+'\nERROR: '+x+'\n'+'-'*70+'\nTraceback (most recent call last):\n  File "/unit/test/test_io.py", line 2832, in setUp\nValueError: example\n'
classify(fake,v)
assert v[x]['phase_labels']==['setUp'] and v[x]['exceptions']==[{'callback':'error','type':'ValueError','message':'example'}]
# A fixture-level failure has no matching original and cannot be turned into 82 per-case errors.
assert classify(fake,{}) and not classify('',{})
print('fixture vs body vs pre-registration attribution: verified')
from qualify import progress_chunks
pr,marks=progress_chunks(e,keys)
assert len(pr)==82 and not marks
bad_e=e.replace(pr[x],pr[x]+'\nException ignored in: synthetic marker',1)
dirty,outer=progress_chunks(bad_e,keys);assert not outer and dirty[x]!=pr[x] and all(dirty[k]==p for k,p in pr.items() if k!=x)
clean,outer=progress_chunks(e+'\nException ignored in: synthetic marker\n',keys);assert 'Exception ignored' in outer
print('local stderr pollution and unattributable shutdown pollution separated')
