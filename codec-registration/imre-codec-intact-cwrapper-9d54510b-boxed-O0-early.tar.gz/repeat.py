"""Compare a fresh native selected suite with the identical native-independent CPython selection."""
from pathlib import Path
import fcntl,hashlib,json,subprocess,sys
from qualify import case,cpbase,here,inspect,norm,scan,valid_process
keys,oracle=cpbase()
def label_for(numbers):
    text=','.join(str(n) for n in numbers)
    return 'pick-'+hashlib.sha256(text.encode()).hexdigest()[:12],'--positions='+text
def run_case(pin,lane,label,selector):
    root=here/'raw'/pin/lane
    lock=here/('.run-'+pin+'-'+lane+'-'+label+'.lock')
    with lock.open('w') as f:
        fcntl.flock(f,fcntl.LOCK_EX)
        if (root/label/'result.json').exists():return
        if pin=='cpython':
            cmd=json.loads((root/'class/result.json').read_text())['argv'][:-1]
        else:
            build=json.loads((root/'build.json').read_text())
            cmd=[build['argv'][build['argv'].index('-o')+1]]
        subprocess.run([sys.executable,'-B',here/'run_one.py',lane,pin,label,selector,*cmd],check=True,timeout=1900)
def run_ref(label,selector):
    with (here/('.ref-'+label+'.lock')).open('w') as file:
        fcntl.flock(file,fcntl.LOCK_EX)
        run_case('cpython','ordinary',label,selector)
def clean_match(pin,lane,label,positions):
    ref=here/'raw/cpython/ordinary';root=here/'raw'/pin/lane
    n=case(root/label);r=case(ref/label);ks=[keys[i-1] for i in positions]
    ns=scan(n,ks,oracle);cs=scan(r,ks,oracle)
    return (all(valid_process(t[0]) and t[0]['exit']==0 for t in (n,r)) and not ns['excluded'] and not cs['excluded'] and ns['registration']==ks and n[1]==r[1] and norm(n[2])==norm(r[2]) and len(ns['originals'])==len(ks) and all(v['canonical_success_transcript'] for v in ns['originals'].values()))
def select(pin,lane):
    result=inspect(pin,lane,keys,oracle)
    group=result.get('selections',{}).get('class',{});obs=group.get('originals',{})
    if not obs and not(group.get('cohort') and group.get('registration')==keys):return
    from tail_replay import recover
    effective=dict(obs)
    effective.update(recover(pin,lane))
    available=[q[1] for q in keys if effective.get(q[-1],{}).get('canonical_success_transcript')]
    # Keep original group status visible even if a fresh repeating selection is clean.
    def batch(ns):
        label,sel=label_for(ns);run_ref(label,sel);run_case(pin,lane,label,sel)
        if not clean_match(pin,lane,label,ns):
            if len(ns)>1:
                half=len(ns)//2;batch(ns[:half]);batch(ns[half:])
            elif ns[0]!=1:
                n=ns[0];label='confirm-'+str(n);k=keys[n-1][-1]
                run_ref(label,k);run_case(pin,lane,label,k)
    if not result.get('full_clean_transcript'):
        # The initial engineering snapshot has a later integrated build and final public replay.
        # Keep one genuinely matched batch on it; retain all its other original observations.
        budget=12 if pin=='9d54510b5601917481fc2a6c228cdccd2e11eba0' else len(available)
        for beg in range(0,min(len(available),budget),12):batch(available[beg:beg+12])
    # Real one-ID process controls cover previous handoff bodies plus unique error/skip modes.
    targets={74,75};buckets=set()
    if available:targets.add(available[0])
    for _mo,n,_occ,k in keys:
        if k not in obs:continue
        q=obs[k];state=q['observed']
        if state!='success':
            sig=(state,tuple(x['type'] for x in q['exceptions']),tuple(q['phase_labels']),tuple(tuple(x['line'] for x in tr['upstream_frames']) for tr in q['tracebacks']))
            if sig not in buckets and len(buckets)<4:targets.add(n);buckets.add(sig)
    if pin=='9d54510b5601917481fc2a6c228cdccd2e11eba0':
        targets=set(available[:1])  # Its full #445 and first-success one-case controls are already retained.
    targets.discard(1)
    if pin=='5e547cf08908db2aafb40d7de31c73602ff8195d':targets.discard(67)  # Separate selected control owned by baseline agent.
    from concurrent.futures import ThreadPoolExecutor
    def one(n):
        k=keys[n-1][-1]
        if k not in obs:return
        label='confirm-'+str(n);run_ref(label,k);run_case(pin,lane,label,k)
    with ThreadPoolExecutor(2) as ex:list(ex.map(one,sorted(targets)))
if __name__=='__main__':select(sys.argv[1],sys.argv[2])
