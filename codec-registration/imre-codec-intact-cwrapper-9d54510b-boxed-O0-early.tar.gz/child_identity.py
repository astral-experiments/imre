"""Passive, race-tolerant observation of direct helper processes for the two original shutdown tests."""
import hashlib,json,os,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent;pin,lane=sys.argv[1:3];group=here/'raw'/pin/lane/'class'
deadline=time.monotonic()+1900;seen=set()
while time.monotonic()<deadline:
    if (group/'result.json').exists():break
    if not (group/'stdout').exists():time.sleep(3);continue
    active=None
    for line in (group/'stdout').read_bytes().decode(errors='replace').splitlines():
        e=line.split('\t')
        if len(e)>=3 and e[0]=='start':active=e[1]
        if len(e)>=3 and e[0]=='stop' and e[1]==active:active=None
    if not active or not active.split('.')[-1].startswith('test_create_at_shutdown_'):time.sleep(1);continue
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if os.readlink(proc/'exe')!=str(group.parent/'suite'):continue
            args=(proc/'cmdline').read_bytes().split(b'\0')[:-1]
            if len(args)!=2 or args[-1]!=b'--class':continue
            for child in (proc/'task'/proc.name/'children').read_text().split():
                cp=Path('/proc')/child;image=os.readlink(cp/'exe');argv=(cp/'cmdline').read_bytes().split(b'\0')[:-1]
                if '-c' not in [a.decode(errors='replace') for a in argv] or str(child) in seen:continue
                if Path(image).name not in ('imre','python','python3','python3.14'):continue
                # Constrain the record to this upstream file's public test payloads or environment probe.
                display=[a.decode(errors='backslashreplace') for a in argv]
                if not any('Avoid looking up codecs at shutdown' in a or a=='import sys; sys.exit(0)' for a in display):continue
                seen.add(str(child));dest=group.parent/'helpers';dest.mkdir(exist_ok=True)
                (dest/(active.split('.')[-1]+'-'+child+'.json')).write_text(json.dumps(dict(ordinal_id=active,exe=image,pid=int(child),ppid=int(proc.name),parent_exe=str(group.parent/'suite'),argv=display),indent=2)+'\n')
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    time.sleep(1)
