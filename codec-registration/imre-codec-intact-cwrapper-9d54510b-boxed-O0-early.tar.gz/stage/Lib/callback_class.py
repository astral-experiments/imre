import sys
import unittest
from test import test_io

def event(kind, test, note=""):
    print(kind + "\t" + test.id() + "\t" + note, flush=True)


class CallbackResult(unittest.TextTestResult):
    def startTest(self, test):
        event("start", test)
        super().startTest(test)

    def stopTest(self, test):
        event("stop", test)
        super().stopTest(test)

    def addSuccess(self, test):
        event("success", test)
        super().addSuccess(test)

    def addError(self, test, err):
        event("error", test, err[0].__name__ + " " + repr(str(err[1])))
        super().addError(test, err)

    def addFailure(self, test, err):
        event("failure", test, err[0].__name__ + " " + repr(str(err[1])))
        super().addFailure(test, err)

    def addSkip(self, test, reason):
        event("skip", test, reason)
        super().addSkip(test, reason)

    def addSubTest(self, test, subtest, err):
        status = "ok" if err is None else err[0].__name__ + " " + repr(str(err[1]))
        event("subtest", test, subtest.id() + "\t" + status)
        super().addSubTest(test, subtest, err)


def flatten(suite, result):
    for test in suite:
        if isinstance(test, unittest.TestSuite):
            flatten(test, result)
        else:
            result.append(test)


if len(sys.argv) != 2:
    raise SystemExit(2)
root = "test.test_io.CTextIOWrapperTest."
fixture = test_io.CTextIOWrapperTest
all_tests = []
flatten(unittest.defaultTestLoader.loadTestsFromModule(test_io), all_tests)
print("discovery\t" + str(len(all_tests)), flush=True)
seen = {}
cohort = []
for ordinal, item in enumerate(all_tests, 1):
    identity = item.id()
    occurrence = seen.get(identity, 0) + 1
    seen[identity] = occurrence
    if type(item) is fixture:
        assert identity.startswith(root)
        cohort.append((ordinal, occurrence, item))
print("class\t" + str(len(cohort)), flush=True)
selection = sys.argv[1]
if selection == "--provider":
    import _io
    print("io", test_io.io, test_io.io.TextIOWrapper, flush=True)
    print("provider", fixture.is_C, fixture.io is test_io.io, fixture.TextIOWrapper is test_io.io.TextIOWrapper, fixture.TextIOWrapper is _io.TextIOWrapper, fixture.BytesIO is test_io.io.BytesIO, fixture.BufferedReader is test_io.io.BufferedReader, fixture.MockRawIO is test_io.CMockRawIO, flush=True)
    raise SystemExit(0)
positions = []
if selection.startswith("--positions="):
    for word in selection[len("--positions="):].split(","):
        number = int(word)
        if number < 1 or number > len(cohort) or (positions and number <= positions[-1]):
            raise ValueError("positions must be strictly increasing registered class ordinals")
        positions.append(number)
selected = unittest.TestSuite()
for pos, entry in enumerate(cohort, 1):
    ordinal, occurrence, item = entry
    if selection == "--class" or item.id() == selection or pos in positions:
        print("select\t" + str(ordinal) + "\t" + str(pos) + "\t" + str(occurrence) + "\t" + item.id(), flush=True)
        selected.addTest(item)
result = unittest.TextTestRunner(verbosity=2, resultclass=CallbackResult).run(selected)
if not result.testsRun or not result.wasSuccessful():
    raise SystemExit(1)
