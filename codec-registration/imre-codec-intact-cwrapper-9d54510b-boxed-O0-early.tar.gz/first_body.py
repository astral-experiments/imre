"""Publish first actual success (including a genuine one-case repeat) and first mixed progress."""
import hashlib,io,json,os,sys,tarfile,time
from pathlib import Path
from repeat import keys,oracle,run_case,run_ref
from qualify import case,digest,here,norm,scan,valid_process
from watch import snap,write
p,lane=sys.argv[1:3];base=here/'raw'/p/lane;group=base/'class';out=Path('/workspace/shared/downloads')
cutoff=time.monotonic()+3900;seen=set();index={k:pos for _,pos,_,k in keys};launch=None;chosen=None
while time.monotonic()<cutoff:
    if not (group/'stdout').exists():
        if (base/'build.json').exists() and json.loads((base/'build.json').read_text())['exit']!=0:break
        time.sleep(2);continue
    std=(group/'stdout').read_bytes();err=(group/'stderr').read_bytes();d=snap(p,lane,group,'any',std,err,out)
    observed=[(k,ev) for k,ev in d['events'].items() if ev[0][0]=='start' and ev[-1][0]=='stop']
    kinds={e[0] for k,v in observed for e in v if e[0] in ('success','skip','error','failure','subtest')}
    if chosen is None:
        chosen=next((k for k,v in observed if any(e[0]=='success' for e in v)),None)
        if chosen is not None:
            d['snapshot']='first-observed-success';write(p,lane,'first-observed-success',d,std,err,out)
            import subprocess
            n=index[chosen];label='single' if n==1 else 'confirm-'+str(n)
            if n!=1:launch=subprocess.Popen([sys.executable,'-B','-c','from repeat import run_case;import sys;run_case(*sys.argv[1:])',p,lane,label,chosen],cwd=here)
            if n!=1:run_ref(label,chosen)
    if 'mixed' not in seen and 'success' in kinds and len(kinds-{'success','subtest'})>=1:
        d['snapshot']='first-mixed';write(p,lane,'first-mixed',d,std,err,out);seen.add('mixed')
    if chosen is not None and 'single' not in seen and (base/label/'result.json').exists():
        rd=here/'raw/cpython/ordinary'/label;nd=base/label
        nm,no,ne=case(nd);rm,ro,re=case(rd);nk=keys[index[chosen]-1]
        nscan=scan((nm,no,ne),[nk],oracle);rscan=scan((rm,ro,re),[nk],oracle)
        matched=all(valid_process(m) and m['exit']==0 for m in (nm,rm)) and not nscan['excluded'] and not rscan['excluded'] and no==ro and norm(ne)==norm(re)
        summary=dict(pin=p,lane=lane,id=chosen,class_ordinal=index[chosen],module_ordinal=nk[0],occurrence=nk[2],full_class_observation='success',single_reference_match=matched,qualified_distinct_pending_complete_group_and_controls=True,observed=nscan['originals'],reference=rscan['originals'],driver_sha256=digest(here/'stage/Lib/callback_class.py'))
        members={'summary.json':(json.dumps(summary,indent=2)+'\n').encode(),'build.json':(base/'build.json').read_bytes(),'upstream-hashes.json':(here/'upstream-hashes.json').read_bytes()}
        for who,folder in [('cpython',rd),('native',nd)]:
            for n in ('result.json','stdout','stderr'):members[who+'/'+n]=(folder/n).read_bytes()
        members['SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+name+'\n' for name,b in members.items()).encode()
        dest=out/('imre-codec-intact-cwrapper-'+p[:8]+'-'+lane+'-first-single-'+str(index[chosen])+'.tar.gz')
        if not dest.exists():
            tmp=dest.with_suffix('.tmp')
            with tarfile.open(tmp,'w:gz') as t:
                for name,data in members.items():
                    info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
            with tarfile.open(tmp) as t:
                for name,data in members.items():assert t.extractfile(name).read()==data
            os.chmod(tmp,0o644);tmp.rename(dest)
        print(dest,dest.stat().st_size,digest(dest),'single reference match',matched,'id',chosen,flush=True);seen.add('single')
    if 'single' in seen and 'mixed' in seen:break
    if (group/'result.json').exists() and (chosen is None or 'single' in seen):break
    time.sleep(1)
if launch is not None:assert launch.wait(timeout=660)==0
