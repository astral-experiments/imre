"""Copy live original callback prefixes, with no qualification before the process exits."""
import argparse,collections,hashlib,io,json,os,tarfile,time
from pathlib import Path
from qualify import here
def snap(pin,lane,folder,name,stdout,stderr,out):
    lines=stdout.decode(errors='backslashreplace').splitlines()
    keys={v['identity']:v for v in json.loads((here/'fresh-oracle.json').read_text())['results']}
    selected=[];observed=collections.defaultdict(list)
    for line in lines:
        p=line.split('\t')
        if len(p)==5 and p[0]=='select' and p[4] in keys:selected.append(p[4])
        if len(p)>=3 and p[1] in keys and p[0] in ('start','error','success','failure','subtest','skip','stop'):
            observed[p[1]].append(p)
    complete={k:v for k,v in observed.items() if v[0][0]=='start' and v[-1][0]=='stop'}
    counts=collections.Counter(ev[0] for v in complete.values() for ev in v if ev[0] in ('success','error','failure','subtest','skip'))
    return dict(pin=pin,lane=lane,snapshot=name,selected=len(selected),started=sum(any(p[0]=='start' for p in v) for v in observed.values()),stopped=len(complete),observed_terminal_counts=counts,events=observed,qualified=0)
def write(pin,lane,name,data,std,err,out):
    dest=out/('imre-codec-intact-cwrapper-'+pin[:8]+'-'+lane+'-live-'+name+'.tar.gz');out.mkdir(parents=True,exist_ok=True)
    data.update(stdout_sha256=hashlib.sha256(std).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),driver_sha256=hashlib.sha256((here/'stage/Lib/callback_class.py').read_bytes()).hexdigest(),source_hashes=json.loads((here/'upstream-hashes.json').read_text()),live_prefix=True)
    members={'snapshot.json':(json.dumps(data,indent=2)+'\n').encode(),'stdout.prefix':std,'stderr.prefix':err}
    members['SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\n' for n,b in members.items()).encode()
    if not dest.exists():
        tmp=dest.with_suffix('.tmp')
        with tarfile.open(tmp,'w:gz') as t:
            for n,b in members.items():
                h=tarfile.TarInfo(n);h.size=len(b);t.addfile(h,io.BytesIO(b))
        with tarfile.open(tmp) as t:
            for n,b in members.items():assert t.extractfile(n).read()==b
        os.chmod(tmp,0o644);tmp.rename(dest)
    print(dest,dest.stat().st_size,hashlib.sha256(dest.read_bytes()).hexdigest(),'stopped',data['stopped'],'outcomes',data['observed_terminal_counts'],flush=True)
def run(pin,lane,out):
    folder=here/'raw'/pin/lane/'class';deadline=time.monotonic()+3700;done=set()
    while time.monotonic()<deadline:
        if not (folder/'stdout').exists():
            b=folder.parent/'build.json'
            if b.exists() and json.loads(b.read_text())['exit']!=0:return
            time.sleep(2);continue
        std=(folder/'stdout').read_bytes();err=(folder/'stderr').read_bytes();data=snap(pin,lane,folder,'observed',std,err,out)
        for tag,n in [('first',1),('half',41)]:
            if tag not in done and data['stopped']>=n:
                data['snapshot']=tag;write(pin,lane,tag,data,std,err,out);done.add(tag)
        if (folder/'result.json').exists():
            if not done:write(pin,lane,'before-registration-or-incomplete',data,std,err,out)
            return
        time.sleep(1)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('pin');p.add_argument('lane');p.add_argument('out',type=Path);a=p.parse_args();run(a.pin,a.lane,a.out)
