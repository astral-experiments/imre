# CTextIOWrapperTest independent crosswalk

Public Imre 0c9885cf2953271a30a7a40b7ac2f5a8bf4f76db and Linux CPython 3.14.5 at 5607950ef232dad16d75c0cf53101d9649d89115. CPython registered 667 module cases and the original C class contains 82. All 82 passed on CPython with six successful subtest callbacks. Each historical 1038-ledger cell for these cases was UNREACHED.

## boxed-O0

The canonical process registered 82, started 66 and produced 21 errors, 8 failures, 1 incomplete case, 1 case with failing subtests, 35 successes. It exited -9. Its recorded timeout was test.test_io.CTextIOWrapperTest.test_rwpair_cleared_before_textio. It had 0 adopted child records and 0 filesystem entries in the exit inventory.
Disjoint follow-ups started 16 additional originals and produced 7 errors, 9 successes. Across the canonical process and disjoint follow-ups, 0 never started.

- follow-5870750b2691 selected 67 through 82, started 16 and completed 16. Exit 1, recorded timeout none.

Clean credited evidence comprised 35 from the canonical prefix, 9 from the disjoint follow-up, 1 extended isolated rerun after canonical group timeout. The eligible count from the canonical process as a whole was 0. The first exception occurred in 37 test bodies.

## boxed-O3

The canonical process registered 82, started 66 and produced 21 errors, 8 failures, 1 incomplete case, 1 case with failing subtests, 35 successes. It exited -9. Its recorded timeout was test.test_io.CTextIOWrapperTest.test_rwpair_cleared_before_textio. It had 0 adopted child records and 0 filesystem entries in the exit inventory.
Disjoint follow-ups started 16 additional originals and produced 7 errors, 9 successes. Across the canonical process and disjoint follow-ups, 0 never started.

- follow-5870750b2691 selected 67 through 82, started 16 and completed 16. Exit 1, recorded timeout none.

Clean credited evidence comprised 35 from the canonical prefix, 9 from the disjoint follow-up, 1 extended isolated rerun after canonical group timeout. The eligible count from the canonical process as a whole was 0. The first exception occurred in 37 test bodies.

Extended boxed-O0 long-66 selected [66], observed success, timeout False, clean stock match True.
Extended boxed-O3 long-66 selected [66], observed success, timeout False, clean stock match True.
## Across levels

45 originals had independently clean evidence at both levels. The class ordinals are 3, 4, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 36, 40, 42, 43, 45, 46, 47, 50, 51, 52, 53, 66, 71, 72, 73, 75, 78, 79, 80, 81, 82.
1 originals had a canonical or disjoint timeout at both levels. The class ordinals are 66.

The first_exception column records the first exception callback, including failing subtests. Its source_line is the original attributed fixture or method line. Incomplete and unreached cases retain an empty phase when they have no exception traceback. Each clean repeat uses complete callback stdout, timing-normalized unittest stderr, and a fresh bounded process with a normal stdin pipe, zero exit, no residue or adopted children. Distinguish a clean repeat and an earlier unclean canonical or follow-up process using the separate columns.

Primary adjudicated TSV SHA-256 `ad492efc0bb66961ebab855335d2a260a970d41a1dfb5bc001ca4dd032e8fb8f`.
Primary raw archive `imre-codec-intact-cwrapper-0c9885cf-extended.tar.gz` SHA-256 `d3ebedfaefb41c44be86e9047557fbe1444ad52173d01bc187e5b4490494fbe6`.

All 82 IDs, occurrence and ordinal coordinates, canonical and disjoint statuses and timeout flags, first attributed phases, and clean-credit sources agree with the adjudicated TSV.
