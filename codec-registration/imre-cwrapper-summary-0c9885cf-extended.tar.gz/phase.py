"""Locate the first callback exception in the unmodified upstream unittest fixture."""

import ast
from functools import lru_cache
from pathlib import Path
import re

FRAME = re.compile(r'^\s*File "([^"\n]+)", line (\d+)(?:, in ([^\n]+))?\s*$', re.M)
CHAIN = re.compile(
    r'\n(?:During handling of the above exception, another exception occurred:|'
    r'The above exception was the direct cause of the following exception:)\n'
)
FIXTURES = {'setUp', 'tearDown', 'setUpClass', 'tearDownClass'}
DISPATCH = {
    '_callSetUp': 'setUp',
    '_callTearDown': 'tearDown',
    '_callCleanup': 'cleanup',
    'doCleanups': 'cleanup',
    'doClassCleanups': 'cleanup',
    '_callClassCleanups': 'cleanup',
}
UNKNOWN = 'unknown from captured frames'


@lru_cache(maxsize=4)
def _fixture_methods(source_path, class_name):
    classes = {
        node.name: node for node in ast.parse(Path(source_path).read_bytes()).body
        if isinstance(node, ast.ClassDef)
    }
    todo = [class_name]
    seen = set()
    scopes = []
    while todo:
        name = todo.pop()
        if name in seen or name not in classes:
            continue
        seen.add(name)
        cls = classes[name]
        todo.extend(b.id for b in cls.bases if isinstance(b, ast.Name))
        for method in cls.body:
            if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)):
                scopes.append((method.lineno, method.end_lineno, method.name))
    return tuple(scopes)


def first_phase(source_path, identity, trace_strings):
    """Return (phase, first original source line) for the first callback error.

    Supply one decoded traceback per failing callback, in callback order.
    A missing trace for the first callback must occupy its position as None.
    An unresolved first callback stays unresolved even if later callbacks have frames.
    """
    text = trace_strings if isinstance(trace_strings, str) else next(iter(trace_strings or ()), None)
    if not text:
        return UNKNOWN, None
    class_name, test_name = identity.rsplit('.', 2)[-2:]
    scopes = _fixture_methods(Path(source_path), class_name)
    text = CHAIN.split(text)[-1]
    original_lines = []
    dispatch = None
    selected = None
    for filename, lineno, symbol in FRAME.findall(text):
        path = Path(filename.strip('<>')).parts
        method = symbol.strip().rsplit('.', 1)[-1]
        if path[-2:] == ('unittest', 'case.py') and method in DISPATCH and dispatch is None:
            dispatch = DISPATCH[method]
        if path[-2:] != ('test', 'test_io.py'):
            continue
        line = int(lineno)
        original_lines.append(line)
        for start, end, declared in scopes:
            if not start <= line <= end or (method and method != declared):
                continue
            if selected is None and (declared in FIXTURES or declared == test_name):
                selected = (declared if declared in FIXTURES else 'test body', line)
            break
    if dispatch:
        if selected and selected[0] == dispatch:
            return selected
        return dispatch, next(iter(original_lines), None)
    return selected or (UNKNOWN, None)
