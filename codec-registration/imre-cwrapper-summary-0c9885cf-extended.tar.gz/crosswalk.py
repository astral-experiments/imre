"""Independently derive the CTextIOWrapperTest crosswalk from raw callback receipts."""
import argparse, ast, csv, hashlib, json, re
from collections import Counter, defaultdict
from pathlib import Path
from phase import first_phase

PIN='0c9885cf2953271a30a7a40b7ac2f5a8bf4f76db'
LANES=('boxed-O0','boxed-O3')
CURRENT=Path(__file__).resolve().parent
MARKERS=('Exception ignored','Exception in thread','ResourceWarning:','unraisablehook','Could not run clang')
def digest(data):return hashlib.sha256(data).hexdigest()
def norm(s):return re.sub(r'(?m)^(Ran \d+ tests? in )[\d.]+s$',r'\1<time>s',s)
def good(m,rc):return m['exit']==rc and not m['timeout'] and not m['adopted'] and not m['residue']
def receipt(d):
    m=json.loads((d/'result.json').read_bytes());streams=[]
    for s in ('stdout','stderr'):
        b=(d/s).read_bytes()
        assert digest(b)==m[s+'_sha256'] and len(b)==m[s+'_bytes']
        streams.append(b.decode('utf-8','backslashreplace'))
    assert m['stdin_pipe'] and m['stdin_parent_held_through_wait']
    return (m,*streams)
def parse(out,extras=None):
    lines=[s.split('\t') for s in out.splitlines()]
    assert lines[:2]==[['discovery','667'],['class','82']]
    choices=[];logs=defaultdict(list);traces=defaultdict(list);active=None
    for p in lines[2:]:
        event=p[0]
        if event not in ('select','start','stop','error','failure','success','skip','subtest','trace') or len(p)<3:
            if extras is not None:extras.append({'during':active,'line':'\t'.join(p)})
            continue
        if event=='select':
            assert not logs;choices.append((int(p[1]),int(p[2]),int(p[3]),p[4]));continue
        if event=='start':
            assert active is None;active=p[1];assert active not in logs
        assert p[1]==active,(active,p)
        if event=='trace':
            assert logs[active][-1][0]==p[2] and traces[active][-1] is None;traces[active][-1]=ast.literal_eval(p[3])
        else:
            logs[active].append(tuple(p))
            if event in ('error','failure') or (event=='subtest' and p[-1]!='ok'):traces[active].append(None)
        if event=='stop':active=None
    return choices,dict(logs),dict(traces),active
def status(log):
    if not log:return 'unreached'
    if log[-1][0]!='stop':return 'incomplete'
    vals=[p[0] for p in log if p[0] in {'success','skip','failure','error'}]
    if len(vals)==1:return vals[0]
    if vals:return 'multiple callbacks'
    return 'subtest non-success' if any(p[0]=='subtest' and p[-1]!='ok' for p in log) else 'incomplete'
def chunks(e):
    limit=re.search(r'(?m)^={20,}\n(?:ERROR|FAIL): |^-{20,}\nRan \d+ tests? in ',e)
    prefix=e[:limit.start()] if limit else e
    matches=list(re.finditer(r'(?m)^test_\w+ \((test\.test_io\.CTextIOWrapperTest\.test_\w+)\)',prefix))
    return {m[1]:prefix[m.start():(matches[i+1].start() if i+1<len(matches) else len(prefix))].rstrip('\n') for i,m in enumerate(matches)}
def add_observed(k,log,tr,e,m,testpath):
    result={'observed':status(log),'first_exception':'','phase':'','source_line':''}
    err=[p[-1] for p in log if p[0] in {'error','failure'} or p[0]=='subtest' and p[-1]!='ok']
    if err:
        result['first_exception']=err[0].replace(m['cwd'],'<cwd>').replace(m['tmpdir'],'<tmpdir>')
        if not tr or all(t is None for t in tr):
            sections=re.split(r'(?m)^={20,}\n(?=ERROR: |FAIL: )',e)
            tr=[b for b in sections[1:] if re.search(r'(?<![\w.])'+re.escape(k)+r'(?![\w.])',b.splitlines()[0])]
        phase,line=first_phase(testpath,k,tr)
        result.update(phase=phase,source_line=line or '')
    return result
def inspect(root,pin,lane,stock,ids,testpath,include_long):
    raw=root/'raw'/pin/lane;ref=root/'raw/cpython/ordinary'
    b=json.loads((raw/'build.json').read_bytes());assert b['pin']==pin and b['lane']==lane and b['exit']==0 and not b['timeout']
    binary=b['argv'][b['argv'].index('-o')+1]
    def native(d):
        m,o,e=receipt(raw/d)
        assert m['revision']==pin and m['lane']==lane and m['visible_helper']==b['argv'][0] and m['argv'][0]==binary
        return m,o,e
    cm,co,ce=native('class');sm,so,se=receipt(ref/'class')
    canon_extras=[];choices,actual,tracks,active=parse(co,canon_extras);assert choices==ids
    assert [k for _,_,_,k in choices[:len(actual)]]==list(actual)
    assert not cm['timeout'] or cm.get('timeout_active_original')==active
    stock_chunks=chunks(se);cchunks=chunks(ce)
    controls={}
    for label in ['wrong','single','provider']:
        m,o,e=native(label);rm,ro,re_=receipt(ref/label)
        if label=='provider':
            controls[label]=good(m,0) and not e and len(o.splitlines())==4 and o.splitlines()[:2]==['discovery\t667','class\t82'] and o.splitlines()[-1]=='provider True True True True True True True'
        elif label=='wrong':controls[label]=good(m,1) and (o,norm(e))==(ro,norm(re_))
        else:
            reg,ev,_,act=parse(o);k=ids[0][-1]
            assert reg==ids[:1] and list(ev)==[k] and not act
            if status(ev[k])=='success':controls[label]=good(m,0) and (o,norm(e))==(ro,norm(re_))
            else:controls[label]=good(m,1) and status(ev[k])==status(actual[k]) and not any(t in e for t in MARKERS)
    follow={};timeouts={};wits=defaultdict(list);repeat_reports={};tail_reports=[]
    for path in sorted(raw.glob('*/result.json')):
        n=path.parent.name
        if n.startswith('long-') and not include_long:continue
        if not (n.startswith(('follow-','pick-','confirm-','long-')) or n=='single'):continue
        m,o,e=native(n);rm,ro,re_=receipt(ref/n)
        assert rm['selector']==m['selector']==m['argv'][-1]
        extras=[];reg,ev,tr,act=parse(o,extras);rreg,rev,rtr,ract=parse(ro);assert reg==rreg and not ract and good(rm,0)
        assert all(t in ids for t in reg) and [t[-1] for t in reg[:len(ev)]]==list(ev)
        if m['timeout']:assert act==m.get('timeout_active_original') or not act
        if n.startswith('follow-'):
            assert not(set(ev)&set(actual)) and not(set(ev)&set(follow))
            assert not(set(x[-1] for x in reg)&set(actual))
            for k,v in ev.items():follow[k]=(n,v,tr.get(k,[]),m,e)
            if m.get('timeout_active_original'):timeouts[m.get('timeout_active_original')]=n
            tail_reports.append(dict(group=n,non_protocol_stdout=extras,selected=[t[1] for t in reg],started=len(ev),completed=sum(status(v)!='incomplete' for v in ev.values()),exit=m['exit'],timed_out=m.get('timeout_active_original'),adopted=len(m['adopted']),residue=len(m['residue'])))
            continue
        clean=(good(m,0) and o==ro and norm(e)==norm(re_) and not act and all(ev.get(t[-1])==stock[t[-1]] for t in reg))
        repeat_reports[n]=dict(clean=clean,count=len(reg),observed=status(next(iter(ev.values()))) if len(reg)==len(ev)==1 else '',timeout=m['timeout'],positions=[t[1] for t in reg])
        if clean:
            for _,_,_,k in reg:wits[k].append(n)
    out={};summary={}
    for _,pos,_,k in ids:
        ca=actual.get(k,[]);ta=[]
        c=add_observed(k,ca,tracks.get(k),ce,cm,testpath)
        f={'observed':'','first_exception':'','phase':'','source_line':''};group='';tail_stderr=''
        if k in follow:
            group,ta,tt,tm,te=follow[k];f=add_observed(k,ta,tt,te,tm,testpath)
            tail_stderr=chunks(te).get(k)==stock_chunks[k]
        extra=repeat_reports.get('long-'+str(pos),{})
        progress=cchunks[k]==stock_chunks[k] if k in cchunks else ''
        same=ca==stock[k] and bool(progress)
        exact=good(cm,0) and co==so and norm(ce)==norm(se)
        passed=''
        if all(controls.values()):
            if extra.get('clean'):
                origin='canonical group' if cm.get('timeout_active_original')==k else timeouts[k]
                passed='extended isolated rerun after '+origin+' timeout'
            elif same and (wits[k] or exact):passed='canonical group'
            elif ta==stock[k] and tail_stderr and wits[k]:passed='disjoint follow-up'
        eff=c if ca else f
        out[k]={'canonical':c['observed'],'canonical_timeout':int(cm.get('timeout_active_original')==k),'tail':f['observed'],'tail_group':group,'tail_timeout':int(k in timeouts),'first_phase':eff['phase'],'source_line':eff['source_line'],'first_exception':eff['first_exception'],'canonical_progress_clean':progress,'tail_progress_clean':tail_stderr,'confirmed':passed,'repeat_witness':','.join(wits[k]),'extended_600s_observed':extra.get('observed',''),'extended_600s_timeout':extra.get('timeout','')}
    for mode,data in [('canonical',actual.values()),('disjoint',[x[1] for x in follow.values()])]:summary[mode]=dict(Counter(status(ev) for ev in data))
    summary.update(controls=controls,canonical_non_protocol_stdout=canon_extras,registered=len(ids),canonical_exit=cm['exit'],canonical_timeout=cm.get('timeout_active_original'),canonical_adopted=len(cm['adopted']),canonical_residue=len(cm['residue']),canonical_started=len(actual),disjoint_started=len(follow),unstarted=len(ids)-len(actual)-len(follow),disjoint_processes=tail_reports,clean_sources=dict(Counter(w['confirmed'] for w in out.values() if w['confirmed'])),error_phases=dict(Counter(w['first_phase'] for w in out.values() if w['first_phase'])),extended={k:v for k,v in repeat_reports.items() if k.startswith('long-')})
    return out,summary
def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--pin',default=PIN);p.add_argument('--published',type=Path);p.add_argument('--include-long',action='store_true');p.add_argument('--out',type=Path,default=CURRENT);a=p.parse_args()
    ref=a.root/'raw/cpython/ordinary';sm,so,se=receipt(ref/'class');assert good(sm,0)
    ids,stock,_,active=parse(so);assert not active and len(ids)==len(stock)==82
    assert all(status(v)=='success' for v in stock.values())
    assert [t[1] for t in ids]==list(range(1,83))
    assert sum(t[0]=='subtest' for ev in stock.values() for t in ev)==6 and 'Ran 82 tests' in se
    oracle=json.loads((a.root/'fresh-oracle.json').read_bytes())
    original={r['identity']:r for r in oracle['results']}
    historical={(r['id'],int(r['occurrence'])):r for r in csv.DictReader((a.root/'global-1038-ae0e69c.tsv').open(),delimiter='\t')}
    assert len(historical)==1038
    rows=[];report={'revision':a.pin,'source':oracle['source_commit'],'cp':{'class':82,'discovery':667,'success':82,'subtest_ok':6}}
    results={}
    for lane in LANES:
        results[lane],report[lane]=inspect(a.root,a.pin,lane,stock,ids,a.root/'stage/Lib/test/test_io.py',a.include_long or bool(a.published and '-extended' in a.published.name))
    for mod,pos,occ,k in ids:
        h=historical[(k,occ)]
        assert int(h['index'])==pos+682 and h['reference_verdict']=='PASS'
        assert all(h[x]=='UNREACHED' for x in ('ordinary.O0','ordinary.O3','boxed.O0','boxed.O3'))
        orig=original[k];assert (mod,pos,occ)==(orig['module_ordinal'],orig['class_ordinal'],orig['occurrence'])
        w=dict(global_1038=h['index'],module_667=mod,class_82=pos,occurrence=occ,id=k,method_defined_by=orig['method_defined_by'],source_line=orig['source_line'],stock='success')
        for lane in LANES:
            for key,val in results[lane][k].items():w[lane+'_'+key]=val
        w['confirmed_both']=int(all(results[l][k]['confirmed'] for l in LANES));rows.append(w)
    report['confirmed_both']=[w['class_82'] for w in rows if w['confirmed_both']]
    report['observed_success_both']=[w['class_82'] for w in rows if all('success' in [w[l+'_canonical'],w[l+'_tail']] for l in LANES)]
    report['timed_out_both']=[w['class_82'] for w in rows if all(w[l+'_canonical_timeout'] or w[l+'_tail_timeout'] for l in LANES)]
    report['unconfirmed_clean_candidate_ids']={l:[w['class_82'] for w in rows if 'success' in [w[l+'_canonical'],w[l+'_tail']] and not w[l+'_confirmed']] for l in LANES}
    report['issues']=[]
    if a.published:
        pub=list(csv.DictReader(a.published.open(),delimiter='\t'));assert len(pub)==len(rows)
        report['public_tsv_sha256']=digest(a.published.read_bytes())
        for w,pv in zip(rows,pub):
            for k in ('id','class_82','module_667','global_1038','occurrence'):assert str(w[k])==pv[k]
            for l in LANES:
                head=a.pin[:8]+'_'+l+'_'
                pairs=[('canonical','observed'),('canonical_timeout','canonical_timeout'),('tail','followup_observed'),('tail_timeout','disjoint_followup_timeout'),('confirmed','independent_or_full_group_confirmed'),('extended_600s_observed','extended_600s_observed'),('extended_600s_timeout','extended_600s_timeout')]
                for k,other in pairs:
                    if str(w[l+'_'+k])!=pv[head+other]:report['issues'].append([w['class_82'],l,k,w[l+'_'+k],pv[head+other]])
                if w[l+'_first_phase'] and w[l+'_first_phase'] not in (pv[head+'phase'] or pv[head+'followup_phase']).split('/'):
                    report['issues'].append([w['class_82'],l,'phase',w[l+'_first_phase'],pv[head+'phase'] or pv[head+'followup_phase']])
        for l in LANES:
            head=a.pin[:8]+'_'+l+'_';report[l]['eligible_from_full_class']=sum(int(v[head+'qualified']) for v in pub)
    a.out.mkdir(parents=True,exist_ok=True)
    with (a.out/'crosswalk.tsv').open('w',newline='') as f:
        writer=csv.DictWriter(f,delimiter='\t',fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
    report['crosswalk_sha256']=digest((a.out/'crosswalk.tsv').read_bytes())
    (a.out/'summary.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:report[k] for k in ('confirmed_both','timed_out_both','public_tsv_sha256','issues','crosswalk_sha256') if k in report}))
    for l in LANES:
        s=report[l];print(l,s['controls'],s['canonical'],s['disjoint'],s['clean_sources'],s['error_phases'])
if __name__=='__main__':main()
