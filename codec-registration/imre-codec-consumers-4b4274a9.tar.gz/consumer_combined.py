import codecs
import sys
import warnings

class B(bytes):
    pass
class S(str):
    pass
class E(Exception):
    pass

def exercise(case):
    trace=[]
    response=[None]
    tag=S("custom-policy")
    value=S("hello")
    data=B(b"hello")
    def call(*args):
        trace.append((len(args), type(args[0]).__name__, args[0] is value, args[0] is data))
        if len(args)==2:
            assert type(args[1]) is str and args[1] == tag
        if isinstance(args[0],memoryview):
            assert args[0].obj is None and args[0].readonly and bytes(args[0])==data
        if response[0] is error:
            raise error
        return response[0]
    error=E("origin")
    class Control(tuple):
        _is_text_encoding = False
    entry=Control((call,call,None,None)) if case == 'blocked' else (call,call,None,None)
    def search(name):
        if name=='qq_demo':
            return entry
    codecs.register(search)
    try:
        if case=='types':
            response[0]=(data,object())
            assert codecs.encode(value,'QQ-demo') is data
            assert value.encode('QQ-demo',tag) is data
            assert bytes(value,'QQ-demo') is data
            response[0]=(value,'consumed ignored')
            assert codecs.decode(data,'QQ-demo',tag) is value
            assert data.decode('QQ-demo') is value
            assert data.decode('QQ-demo',tag) is value
            print('types',trace)
        elif case=='errors':
            response[0]=error
            for fn,part in [(codecs.encode,'encoding'),(codecs.decode,'decoding')]:
                try:fn(123,'QQ-demo')
                except E as exc:
                    assert exc is error
                    assert exc.__notes__[-1] == part+" with 'QQ-demo' codec failed"
                else:raise AssertionError('callback exception lost')
            print('notes',error.__notes__)
            response[0]=['bad',0]
            for fn,msg in [(codecs.encode,'encoder must return a tuple (object, integer)'),(codecs.decode,'decoder must return a tuple (object,integer)')]:
                try:fn('x','QQ-demo')
                except TypeError as exc:assert str(exc)==msg and not hasattr(exc,'__notes__')
                else:raise AssertionError('bad response accepted')
            response[0]=(5,None)
            assert codecs.encode(12,'QQ-demo')==5
            for fn,target in [(value.encode,'bytes'),(data.decode,'str')]:
                try:fn('QQ-demo')
                except TypeError as exc:assert "returned 'int' instead of '"+target+"'" in str(exc)
                else:raise AssertionError('bad text output accepted')
            print("shape, ignored consumed, result validation")
        elif case=='blocked':
            response[0]=(5,None)
            assert codecs.encode(4,'QQ-demo')==5
            for fn,cmd in [(value.encode,'encode'),(data.decode,'decode')]:
                try:fn('QQ-demo')
                except LookupError as exc:assert str(exc)=="'QQ-demo' is not a text encoding; use codecs."+cmd+"() to handle arbitrary codecs"
                else:raise AssertionError("text gate bypassed")
            assert b''.decode('QQ-demo') == ''
            print("generic bypasses text gate; empty bytes bypass codec")
        elif case=='builtin':
            assert codecs.encode('a','utf-8') == 'a'.encode() == b'a'
            assert codecs.decode(b'abc','ascii') == b'abc'.decode() == 'abc'
            assert codecs.decode(b'\xff\xfex\0','utf-16') == 'x' and not trace
            print("utf-8, ascii, native utf-16")
        else:
            response[0]=(bytearray(b'ok'),0)
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')
                assert value.encode('QQ-demo') == b'ok'
                assert len(w)==1 and w[0].category is RuntimeWarning
            print("bytearray accepted with warning")
    finally:
        codecs.unregister(search)

import codecs
import encodings
import sys

def special(case):
    default = encodings.search_function
    data = b'A\0\0\0'
    names = ('raw-unicode-escape', 'utf-16-le', 'utf-32-le')
    calls = []
    def codec(name):
        calls.append(name)
        return (lambda *args:(b'custom', None), lambda *args:('custom',None), None,None)
    if case == 'inventory':
        codecs.register(codec)
        try:
            assert codecs.decode(b'X','raw-unicode-escape') == 'X'
            for label,fn in [('lookup',lambda:codecs.lookup('raw-unicode-escape')),
                             ('encode',lambda:codecs.encode('X','raw-unicode-escape'))]:
                try: obj=fn()
                except LookupError as exc: print(label,'missing',str(exc))
                else: print(label,'available')
            assert calls==[] and codecs.decode(b'X','raw-unicode-escape')=='X'
        finally:
            codecs.unregister(codec)
        return
    assert [codecs.decode(data,n) for n in names] == ['A\0\0\0','A\0','A']
    codecs.register(codec)
    try:
        assert [codecs.decode(data,n) for n in names] == ['A\0\0\0','A\0','A']
        assert calls == []
        codecs.unregister(default)
        try:
            assert [codecs.decode(data,n) for n in names] == ['custom']*3
            assert [data.decode(n) for n in names] == ['custom']*3
            assert ['X'.encode(n) for n in names[1:]] == [b'custom']*2
            assert calls == ['raw_unicode_escape','utf_16_le','utf_32_le']
            codecs.register(default)
            codecs.unregister(codec)
            assert [codecs.decode(data,n) for n in names] == ['A\0\0\0','A\0','A']
            codecs.unregister(default)
            for name in names:
                try:codecs.decode(data,name)
                except LookupError:pass
                else:raise AssertionError("warmed native fallback escaped unregister")
        finally:
            codecs.register(default)
    finally:
        codecs.unregister(codec)
    print("default removed and restored", calls)

import codecs
import encodings
import sys
def peer_transformer(*args): return (args[0], None)
def peer_replacement(name):
    peer_calls.append(name)
    return (peer_transformer,peer_transformer,None,None)
peer_calls=[]
def providers():
    names=('ascii','iso8859-1','utf-8','utf-8-sig','cp1251','cp424','cp437')
    text=('Az','é','é','é','я','א','é')
    expected=(b'Az',b'\xe9',b'\xc3\xa9',b'\xef\xbb\xbf\xc3\xa9',b'\xff',b'\x41',b'\x82')
    for name,plain,octets in zip(names,text,expected):
        assert codecs.encode(plain,name)==octets and codecs.decode(octets,name)==plain
        assert plain.encode(name)==octets and octets.decode(name)==plain
    print("seven builtins round trip")
    saved=encodings.search_function
    codecs.unregister(saved)
    
    codecs.register(peer_replacement)
    try:
        for name in names:
            thing=object()
            assert codecs.encode(thing,name) is thing and codecs.decode(thing,name) is thing
        print("seven generic overrides",peer_calls)
        assert "ascii".encode('utf-8')==b'ascii' and b'ascii'.decode('utf-8')=="ascii"
    finally:
        codecs.unregister(peer_replacement)
        codecs.register(saved)

case=sys.argv[1]
if case in ('precedence','inventory'):
    special(case)
elif case == 'providers':
    providers()
else:
    exercise(case)
