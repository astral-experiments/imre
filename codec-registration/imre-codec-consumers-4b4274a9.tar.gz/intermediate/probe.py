import codecs
import encodings
import sys

def run(case):
    default = encodings.search_function
    data = b'A\0\0\0'
    names = ('raw-unicode-escape', 'utf-16-le', 'utf-32-le')
    calls = []
    def codec(name):
        calls.append(name)
        return (lambda *args:(b'custom', None), lambda *args:('custom',None), None,None)
    if case == 'inventory':
        assert codecs.decode(b'X','raw-unicode-escape') == 'X'
        for label,fn in [('lookup',lambda:codecs.lookup('raw-unicode-escape')),
                         ('encode',lambda:codecs.encode('X','raw-unicode-escape'))]:
            try: obj=fn()
            except LookupError as exc: print(label,'missing',str(exc))
            else: print(label,'available')
        return
    assert [codecs.decode(data,n) for n in names] == ['A\0\0\0','A\0','A']
    codecs.register(codec)
    try:
        assert [codecs.decode(data,n) for n in names] == ['A\0\0\0','A\0','A']
        assert calls == []
        codecs.unregister(default)
        try:
            assert [codecs.decode(data,n) for n in names] == ['custom']*3
            assert [data.decode(n) for n in names] == ['custom']*3
            assert ['X'.encode(n) for n in names[1:]] == [b'custom']*2
            assert calls == ['raw_unicode_escape','utf_16_le','utf_32_le']
            codecs.register(default)
            codecs.unregister(codec)
            assert [codecs.decode(data,n) for n in names] == ['A\0\0\0','A\0','A']
            codecs.unregister(default)
            for name in names:
                try:codecs.decode(data,name)
                except LookupError:pass
                else:raise AssertionError("warmed native fallback escaped unregister")
        finally:
            codecs.register(default)
    finally:
        codecs.unregister(codec)
    print("default removed and restored", calls)
run(sys.argv[1])
