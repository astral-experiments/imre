import codecs
def run():
    assert codecs.decode(b'X','raw-unicode-escape') == 'X'
    for label,fn in [('lookup',lambda:codecs.lookup('raw-unicode-escape')),
                     ('encode',lambda:codecs.encode('X','raw-unicode-escape'))]:
        try: obj=fn()
        except LookupError as exc: print(label,'missing',str(exc))
        else: print(label,'available')
run()
