# Public #4034 postmerge smoke

Public e64c7815dbdd35d7261edfb9c78bac90df29cbad was fetched by exact SHA and built in its own clean checkout. The pair logs document the four cleaned workspace packages, Cargo.lock identity and the source checkout. The compiler and runtime artifacts in pair/ready were hashed again before validation.

On Linux CPython 3.14.5 (5607950ef232dad16d75c0cf53101d9649d89115) and public Imre, sources/probe.py exercises bytes, bytearray and a subtype of each, with normal decoder return and a raised exception for each type. The boxed O0/O3 runs matched the eight stock lines exactly. The unmodified public tests/fixtures/boxed_codec_registry.py passed both on stock and with ordinary O0, with empty output and stderr. All runs had pipe stdin held open until completion, no timeout, and empty working and temporary directories and no remaining children. Each native application was linked to the exact local pair recorded here. These are diagnostic controls with zero new original unittest registrations.

The separately labeled pre-fix control at public 0c9885cf shows the stale snapshot when the original mutable input changed, with the original assertion traceback. Stock saw the changed bytes. Postmerge data uses only e64c7815.

For a portable replay, CPYTHON denotes a Linux CPython 3.14.5 executable. IMRE and RUNTIME should select the matching public compiler/runtime build, and CLANG the linker driver. From the extracted directory:

    "$CPYTHON" -IB sources/probe.py
    "$CPYTHON" -IB sources/boxed_codec_registry.py
    for opt in 0 3; do
        "$IMRE" build sources/probe.py --module-root sources --no-cache --opt-level "$opt" --runtime-imports --runtime "$RUNTIME" --clang "$CLANG" -o "probe$opt"
        "./probe$opt"
    done
    "$IMRE" build sources/boxed_codec_registry.py --module-root sources --no-cache --opt-level 0 --runtime "$RUNTIME" --clang "$CLANG" -o registry
    ./registry
