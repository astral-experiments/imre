import _codecs
initial = _codecs.lookup('latin-1')
