import early_lowlevel
import codecs
import sys

class Derived(codecs.CodecInfo):
    pass

assert type(early_lowlevel.initial) is codecs.CodecInfo
if sys.argv[1] == 'direct':
    mod = __import__('ctor_supported')
    C = codecs.CodecInfo
    result = Derived(mod.en,mod.de,name='derived')
    assert result.__class__ is Derived and result.encode('xy') == (b'yx',2)
    assert C(mod.en,mod.de).encode('ab') == (b'ba',2)
    assert type(codecs.lookup('latin1')) is C
    print('constructor alias and subclass checked')
else:
    __import__(sys.argv[1])
