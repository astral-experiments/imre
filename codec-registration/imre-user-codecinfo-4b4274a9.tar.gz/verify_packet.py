import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
version=(r/'revision').read_text().strip()
assert len(version)==40
rows=[line.split('\t') for line in (r/'class-source.tsv').read_text().splitlines()[1:]]
assert [v[0] for v in rows]==['CPython-3.14.5',version]
assert hashlib.sha256((r/'CodecInfo-class.py').read_bytes()).hexdigest()==rows[0][-1]==rows[1][-1]
ref={'direct':'direct','ctor_supported':'supported','ctor_lowlevel':'lowlevel','ctor_parse_supported':'parse-supported'}
for label in ('stock-qualified','stock-receipts'):
    for case,name in ref.items():
        d=r/label/case
        m=json.loads((d/'result.json').read_text())
        assert m['version']=='Python 3.14.5' and m['exit']==0 and m['stdin_pipe'] and not m['cwd_residue'] and not m['tmp_residue']
        assert (d/'stdout').read_bytes()==(r/('stock-'+name+'.out')).read_bytes() and not (d/'stderr').read_bytes()
for lane in ('ordinary-O0','boxed-O3'):
    for case in ('check-ctor_supported.py','check-ctor_parse_supported.py','build',*ref):
        d=r/lane/case;m=json.loads((d/'result.json').read_text())
        out=(d/'stdout').read_bytes();err=(d/'stderr').read_bytes()
        assert m['sha']==version and m['lane']==lane and m['case']==case and m['exit']==0
        assert m['stdin_pipe'] and not m['timeout'] and not m['adopted'] and not m['cwd_residue'] and not m['tmp_residue']
        assert set(m['pair'])=={'imre','libimre_runtime.a'}
        assert hashlib.sha256(out).hexdigest()==m['stdout_sha256']
        assert hashlib.sha256(err).hexdigest()==m['stderr_sha256']
        if case in ref:
            assert out==(r/('stock-'+ref[case]+'.out')).read_bytes() and not err
        print(lane,case,m['exit'],len(out),len(err),sep='\t')
for case in ('utf-8-sig','cp1251'):
    assert ('missing:'+case+' exception TypeError').encode() in (r/'stock-parse-supported.out').read_bytes()
old=r/'prior-5e547'
if old.exists():
    for lane in ('ordinary-O0','boxed-O0'):
        assert (old/lane/'ctor_parsing.exit').read_text()=='-6'
        assert b'Option::unwrap()' in (old/lane/'ctor_parsing.stderr').read_bytes()
