import sys

if sys.argv[1] == 'direct':
    import codecs
    from ctor_supported import en, de
    C = codecs.CodecInfo
    class Derived(codecs.CodecInfo):
        pass
    result = Derived(en,de,name='derived')
    assert result.__class__ is Derived and result.encode('xy') == (b'yx',2)
    assert C(en,de).encode('ab') == (b'ba',2)
    assert type(codecs.lookup('latin1')) is C
    print('constructor alias and subclass checked')
else:
    __import__(sys.argv[1])
