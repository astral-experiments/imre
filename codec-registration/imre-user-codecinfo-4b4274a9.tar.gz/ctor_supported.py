import codecs

def en(v, errors='strict'):
    return (v[::-1].encode('ascii'),len(v))
def de(v, errors='strict'):
    return (v[::-1].decode('ascii'),len(v))
class ChildInfo(codecs.CodecInfo):
    pass
reader=object()
writer=object()
inc_encode=object()
inc_decode=object()
a=codecs.CodecInfo(en,de,reader,writer,inc_encode,inc_decode,'demo',_is_text_encoding=False)
b=ChildInfo(encode=en,decode=de,name='child')
assert type(a) is codecs.CodecInfo and type(b) is ChildInfo and isinstance(b,codecs.CodecInfo)
assert issubclass(codecs.CodecInfo,tuple) and isinstance(a,tuple)
assert type(a).__module__=='codecs'
assert len(a)==4 and a[1] is de and tuple(a)==(en,de,reader,writer)
assert a[1:]==(de,reader,writer) and a==a.__getnewargs__() and hash(a)==hash(tuple(a))
assert a.name=='demo' and a.incrementalencoder is inc_encode and a.incrementaldecoder is inc_decode and a.streamreader is reader and a.streamwriter is writer
assert a._is_text_encoding is False and b._is_text_encoding is True
assert b.incrementalencoder is None and tuple(b)==(en,de,None,None)
assert a.encode('xy')==(b'yx',2)
a.encode=None
assert a.encode is None and a[0] is en
assert 'encoding demo' in repr(a) and 'codecs.CodecInfo' in repr(a)
n=codecs.lookup('latin-1')
assert type(n) is codecs.CodecInfo and isinstance(n,codecs.CodecInfo) and isinstance(n,tuple)
assert type(n) is not ChildInfo and not isinstance(n,ChildInfo)
assert n.encode is n.encode and n.decode is n.decode
assert n.encode('Å')==(b'\xc5',1) and n.encode('a€','replace')==(b'a?',2)
for enc,txt in [('ascii','abc'),('utf-8','あ'),('utf-8-sig','é'),('cp1251','Я')]:
    result=codecs.lookup(enc).encode(txt)
    assert result==(txt.encode(enc),len(txt))
print('codec info constructor, subtype, tuple, mutation, native owner and encoder OK')
