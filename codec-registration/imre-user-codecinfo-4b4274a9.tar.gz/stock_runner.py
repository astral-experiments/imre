from pathlib import Path
import hashlib, json, os, stat, subprocess, sys
root=Path(__file__).parent.resolve();driver=sys.argv[1] if len(sys.argv)>1 else 'parse_and_probe.py';out=root/('stock-qualified' if driver=='qualified_driver.py' else 'stock-receipts');out.mkdir()
py=Path('/tmp/imre3310/python/managed/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14')
version=subprocess.check_output([py,'--version']).decode().strip();assert version=='Python 3.14.5'
for case,reference in [('direct','direct'),('ctor_supported','supported'),('ctor_lowlevel','lowlevel'),('ctor_parse_supported','parse-supported')]:
    base=out/case;cwd=base/'cwd';tmp=base/'tmp';cwd.mkdir(parents=True);tmp.mkdir()
    args=[str(py),'-B',str(root/driver),case]
    with (base/'stdout').open('wb') as stdout,(base/'stderr').open('wb') as stderr:
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','PYTHONWARNINGS')}
        p=subprocess.Popen(args,cwd=cwd,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,env=dict(env,TMPDIR=str(tmp)));assert stat.S_ISFIFO(os.fstat(p.stdin.fileno()).st_mode)
        rc=p.wait(timeout=30);p.stdin.close()
    output=(base/'stdout').read_bytes();error=(base/'stderr').read_bytes()
    assert rc==0 and not error and not list(cwd.iterdir()) and not list(tmp.iterdir()),(rc,error)
    (base/'result.json').write_text(json.dumps(dict(command=args,exit=rc,version=version,stdin_pipe=True,stderr_sha256=hashlib.sha256(error).hexdigest(),stdout_sha256=hashlib.sha256(output).hexdigest(),cwd_residue=[],tmp_residue=[]),indent=2)+'\n')
    f=root/f'stock-{reference}.out'
    if case!='ctor_parse_supported':assert f.read_bytes()==output
    f.write_bytes(output)
