from pathlib import Path
import ctypes, hashlib, json, os, resource, signal, stat, subprocess, sys, time
root=Path(__file__).resolve().parent
base=root.parents[1]
sha=sys.argv[1]
pair=base/'fs-family/provider-replay/pairs'/sha
lane=sys.argv[2];out=root/'fixed'/sha/lane;out.mkdir(parents=True,exist_ok=True)
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
deadline=time.monotonic()+900
while not (pair/'ready').exists():
    if time.monotonic()>deadline:raise TimeoutError(pair)
    time.sleep(1)
assert (pair/'commit').read_text().strip()==sha
hashes={n:h for h,n in (s.split() for s in (pair/'ready').read_text().splitlines())}
assert all(digest(pair/n)==h for n,h in hashes.items())
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','IMREFLAGS','PYTHONWARNINGS')}
env.update(LD_LIBRARY_PATH=str(base/'llvm/usr/lib/x86_64-linux-gnu'),PYTHONDONTWRITEBYTECODE='1',IMRE_PYTHON=str(pair/'imre'))
def command(case,argv,timeout):
    dest=out/case;cwd=dest/'cwd';temp=dest/'tmp';cwd.mkdir(parents=True);temp.mkdir()
    with (dest/'stdout').open('wb') as stdout,(dest/'stderr').open('wb') as stderr:
        caseenv=dict(env,TMPDIR=str(temp))
        if case in ('direct','ctor_supported','ctor_lowlevel','ctor_parse_supported'):
            caseenv['PYTHONPATH']=str(root)
        p=subprocess.Popen([str(v) for v in argv],cwd=cwd,stdout=stdout,stderr=stderr,stdin=subprocess.PIPE,env=caseenv,start_new_session=True)
        assert stat.S_ISFIFO(os.fstat(p.stdin.fileno()).st_mode)
        expired=False
        try:p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            expired=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=20)
        p.stdin.close()
    adopted=[]
    while True:
        try:
            pid,rc=os.waitpid(-1,os.WNOHANG);assert pid
            adopted.append([pid,rc])
        except ChildProcessError:break
    state=dict(sha=sha,case=case,lane=lane,command=list(map(str,argv)),exit=p.returncode,timeout=expired,adopted=adopted,stdin_pipe=True,cwd_residue=[f.name for f in cwd.iterdir()],tmp_residue=[f.name for f in temp.iterdir()],stdout_sha256=digest(dest/'stdout'),stderr_sha256=digest(dest/'stderr'),pair=hashes)
    (dest/'result.json').write_text(json.dumps(state,indent=2)+'\n')
    print(sha[:8],lane,case,p.returncode,flush=True)
    return state
checks=[]
for name in ['ctor_supported.py','ctor_parse_supported.py']:
    check=out/('check-'+name)/'result.json'
    c=json.loads(check.read_text()) if check.is_file() else command('check-'+name,[pair/'imre','check',root/name],100)
    checks.append((name,c['exit']))
binary=out/'program'
driver='qualified_driver.py' if lane.startswith('ordinary') else 'parse_and_probe.py'
args=[pair/'imre','build',root/driver,'--module-root',root,'--opt-level',lane[-1],'--no-cache','--runtime',pair/'libimre_runtime.a','--clang',base/'llvm/usr/bin/clang-19','-o',binary]
if lane.startswith('boxed'):args.append('--runtime-imports')
b=command('build',args,350);assert b['exit']==0,(out/'build/stderr').read_text()
executions=[]
for case in ('direct','ctor_supported','ctor_lowlevel','ctor_parse_supported'):
    c=command(case,[binary,case],90)
    executions.append((case,c))
for case,c in executions:
    assert c['exit']==0,(out/case/'stderr').read_text()
    assert not c['adopted'] and not c['timeout'] and not c['cwd_residue'] and not c['tmp_residue']
    assert not (out/case/'stderr').read_bytes()
    expected=(root/('stock-'+{'direct':'direct','ctor_supported':'supported','ctor_lowlevel':'lowlevel','ctor_parse_supported':'parse-supported'}[case]+'.out')).read_bytes()
    assert (out/case/'stdout').read_bytes()==expected,case

assert all(code==0 for name,code in checks),checks
