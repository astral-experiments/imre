import _codecs
native=_codecs.lookup('latin-1')
cls=type(native)
print('native',cls.__module__,cls.__name__,isinstance(native,tuple),native.encode('é'))
import codecs
assert cls is codecs.CodecInfo and isinstance(native,cls)
saved=codecs.CodecInfo
codecs.CodecInfo=object
try:
    assert _codecs.lookup('latin-1') is native and type(native) is saved
finally:
    codecs.CodecInfo=saved
print('low-level and captured class OK')
