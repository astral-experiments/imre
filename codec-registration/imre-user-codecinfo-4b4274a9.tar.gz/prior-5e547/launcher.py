import importlib
import sys
importlib.import_module(sys.argv[1])
