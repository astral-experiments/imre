import codecs
def report(label, f):
    try:
        value=f()
    except Exception as e:
        print(label, 'exception', type(e).__name__, str(e))
    else:
        print(label, 'okay', value)
C=codecs.CodecInfo
report('missing',lambda:C())
report('duplicate',lambda:C(None,None,decode=None))
report('extra-pos',lambda:C(1,2,3,4,5,6,7,8))
report('extra-kw',lambda:C(1,2,encoding='z'))
report('four',lambda: tuple(C(None,None)))
report('default',lambda:C(None,None,_is_text_encoding=None)._is_text_encoding)
report('funcs',lambda:(callable(codecs.lookup('latin-1').encode),callable(codecs.lookup('latin-1').decode)))
report('alias-encode',lambda: codecs.lookup('latin-1').encode is codecs.lookup('iso8859-1').encode)
for key in ('latin-1','ascii','utf-8','utf-8-sig','cp1252'):
    e=codecs.lookup(key).encode
    report('keywords:'+key,lambda:e(input='ab',errors='strict'))
    report('bad-input:'+key,lambda:e(b'x'))
    report('count:'+key,lambda:e('ab'))
    report('two-pos:'+key,lambda:e('ab','strict'))
    report('missing:'+key,lambda:e())
    report('duplicate:'+key,lambda:e('ab',input='ab'))
    report('unknown:'+key,lambda:e('ab',mystery='z'))
