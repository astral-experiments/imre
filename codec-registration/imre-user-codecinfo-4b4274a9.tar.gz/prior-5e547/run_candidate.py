from pathlib import Path
import json,os,subprocess,sys,time
root=Path(__file__).resolve().parent
base=root.parents[1];sha=sys.argv[1];pair=base/'fs-family/provider-replay/pairs'/sha
# A fresh pair is produced with both hashes after the matched compiler/runtime build.
until=time.monotonic()+600
while not (pair/'ready').exists():
    if time.monotonic()>until:raise TimeoutError(pair)
    time.sleep(1)
import hashlib
assert (pair/'commit').read_text().strip()==sha
for line in (pair/'ready').read_text().splitlines():
    h,n=line.split();assert hashlib.sha256((pair/n).read_bytes()).hexdigest()==h
env=dict(os.environ,LD_LIBRARY_PATH=str(base/'llvm/usr/lib/x86_64-linux-gnu'),PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(root),PYTHONPATH=str(root/'staged'),IMRE_PYTHON=str(pair/'imre'))
for opt in ('0','3'):
 for mode in ('ordinary','boxed'):
    for case,source in [('simple','simple.py'),('loaded','launcher.py')]:
        dst=root/'elfs'/sha/(mode+'-O'+opt)/case;dst.mkdir(parents=True)
        args=[pair/'imre','build',root/source,'--opt-level',opt,'--runtime',pair/'libimre_runtime.a','--clang',base/'llvm/usr/bin/clang-19','-o',dst/'program']
        buildenv=env.copy();buildenv.pop('PYTHONPATH')
        if mode=='boxed':args.append('--runtime-imports')
        r=subprocess.run(args,env=buildenv,cwd=dst,timeout=240,capture_output=True);(dst/'build.err').write_bytes(r.stderr);(dst/'build.out').write_bytes(r.stdout)
        row={'build':r.returncode};print(mode,opt,case,'build',r.returncode,flush=True)
        if r.returncode:print(r.stderr.decode(errors='replace')[-600:],flush=True)
        else:
            run=subprocess.run([dst/'program',*(['ctor_probe'] if case=='loaded' else [])],cwd=dst,env=env,stdin=subprocess.PIPE,capture_output=True,timeout=100)
            (dst/'stdout').write_bytes(run.stdout);(dst/'stderr').write_bytes(run.stderr);row['exit']=run.returncode
            print(mode,opt,case,'run',run.returncode,run.stdout,run.stderr.decode(errors='replace')[-600:],flush=True)
        (dst/'result.json').write_text(json.dumps(row)+'\n')
