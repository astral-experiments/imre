from pathlib import Path
import os,resource,subprocess,sys,time
root=Path(__file__).resolve().parent
base=root.parents[1];sha=sys.argv[1];p=base/'fs-family/provider-replay/pairs'/sha
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for opt in ('0','3'):
 for mode in ('ordinary','boxed'):
    dest=root/'elfs'/sha/(mode+'-O'+opt)/'loaded'
    until=time.monotonic()+600
    while not (dest/'result.json').is_file():
        if time.monotonic()>until:raise TimeoutError(dest)
        time.sleep(1)
    if not (dest/'program').is_file(): continue
    env=dict(os.environ,LD_LIBRARY_PATH=str(base/'llvm/usr/lib/x86_64-linux-gnu'),PYTHONPATH=str(root),IMRE_PYTHON=str(p/'imre'),TMPDIR=str(root))
    for probe in ('ctor_lowlevel','ctor_parsing'):
        c=subprocess.run([dest/'program',probe],cwd=dest,stdin=subprocess.PIPE,capture_output=True,env=env,timeout=60)
        for name,data in [('stdout',c.stdout),('stderr',c.stderr),('exit',str(c.returncode).encode())]:(dest/(probe+'.'+name)).write_bytes(data)
        print(mode,opt,probe,c.returncode,c.stderr.decode(errors='replace')[-200:],flush=True)
