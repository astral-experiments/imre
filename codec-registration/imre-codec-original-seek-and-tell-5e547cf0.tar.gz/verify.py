from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
m=read(r/'selection.json');identity=m['id'];assert m['campaign']['index']=='749' and m['campaign']['occurrence']=='1' and m['campaign']['id']==identity
assert sha(r/'test_io.py')=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af' and sha(r/'test_io.py')==read(r/'upstream-hashes.json')['Lib/test/test_io.py']
for (pin,mode) in [('cpython','ordinary')]+[(m['pin'],mode) for mode in m['lanes']]:
    d=r/'raw'/pin/mode/'original';q=read(d/'result.json')
    assert q['revision']==pin and q['lane']==mode and q['selector']==identity and q['argv'][-1]==identity
    assert all(sha(d/s)==q[s+'_sha256'] for s in ('stdout','stderr'))
    assert q['stdin_pipe'] and q['stdin_parent_held_through_wait'] and not q['adopted'] and not q['residue'] and not q['timeout']
    o=(d/'stdout').read_text().splitlines();e=(d/'stderr').read_text()
    assert o[:4]==['discovery\t667','class\t82','select\t511\t67\t1\t'+identity,'start\t'+identity+'\t']
    assert o[-1]=='stop\t'+identity+'\t' and len(o)==6 and o[4].split('\t')[1]==identity
    kind=o[4].split('\t')[0];assert kind in ('success','failure','error')
    assert q['exit']==(0 if kind=='success' else 1) and 'Ran 1 test in ' in e and ('\nOK\n' in e if kind=='success' else '\nFAILED (' in e)
    assert 'Exception ignored in' not in e and 'Traceback (most recent call last)' not in (d/'stdout').read_text()
    if pin=='cpython':assert kind=='success'
    else:
        b=read(d.parent/'build.json');assert b['exit']==0 and b['pin']==pin and b['lane']==mode and not b['timeout'] and b['driver_sha256']==sha(r/'callback_class.py')
        assert b['compiler_runtime']==m['pair'] and q['argv'][0]==b['argv'][b['argv'].index('-o')+1]
    print(pin[:8],mode,o[4],q['exit'])
