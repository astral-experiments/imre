from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
packet=read(r/'packet.json')
f=r/'fault/stage/codec_probe.py'
assert sha(f)==packet['fault']['source']
for pin,lanes in packet['fault']['pins'].items():
    for lane in lanes:
        base=r/'fault/raw'/pin/lane
        if pin!='cpython':
            b=read(base/'build.json')
            assert b['driver_sha256']==sha(f) and b['pair']==packet['pairs'][pin]
            assert b['exit']==0 and b['pin']==pin and b['lane']==lane and not b['timeout'] and not b['adopted']
            assert all(sha(base/('build.'+s))==b[s+'_sha256'] for s in ('stdout','stderr'))
        outcomes=[]
        for case in ('exception','cycle','malformed'):
            d=base/case;rec=read(d/'result.json')
            assert (rec['case'],rec['pin'],rec['lane'],rec['driver_sha256'])==(case,pin,lane,sha(f))
            assert not rec['adopted'] and not rec['timeout'] and rec['stdin_held'] and rec['residue']=={'cwd':[],'tmpdir':[]}
            assert all(sha(d/s)==rec[s+'_sha256'] for s in ('stdout','stderr'))
            matched=rec['exit']==0 and not (d/'stderr').read_bytes() and (d/'stdout').read_bytes()==(r/'fault/raw/cpython/stock'/case/'stdout').read_bytes() and (d/'stdout').read_bytes().endswith(b'OK '+case.encode()+b'\n')
            if pin=='cpython':assert matched
            outcomes.append((case,matched))
        print(pin[:8],lane,'lifetime after failing callback / explicit gc:',outcomes)
