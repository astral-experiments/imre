import codecs
import sys



class StatefulIncrementalDecoder(codecs.IncrementalDecoder):
    """
    For testing seek/tell behavior with a stateful, buffering decoder.

    Input is a sequence of words.  Words may be fixed-length (length set
    by input) or variable-length (period-terminated).  In variable-length
    mode, extra periods are ignored.  Possible words are:
      - 'i' followed by a number sets the input length, I (maximum 99).
        When I is set to 0, words are space-terminated.
      - 'o' followed by a number sets the output length, O (maximum 99).
      - Any other word is converted into a word followed by a period on
        the output.  The output word consists of the input word truncated
        or padded out with hyphens to make its length equal to O.  If O
        is 0, the word is output verbatim without truncating or padding.
    I and O are initially set to 1.  When I changes, any buffered input is
    re-scanned according to the new I.  EOF also terminates the last word.
    """

    def __init__(self, errors='strict'):
        codecs.IncrementalDecoder.__init__(self, errors)
        self.reset()

    def __repr__(self):
        return '<SID %x>' % id(self)

    def reset(self):
        self.i = 1
        self.o = 1
        self.buffer = bytearray()

    def getstate(self):
        i, o = self.i ^ 1, self.o ^ 1 # so that flags = 0 after reset()
        return bytes(self.buffer), i*100 + o

    def setstate(self, state):
        buffer, io = state
        self.buffer = bytearray(buffer)
        i, o = divmod(io, 100)
        self.i, self.o = i ^ 1, o ^ 1

    def decode(self, input, final=False):
        output = ''
        for b in input:
            if self.i == 0: # variable-length, terminated with period
                if b == ord('.'):
                    if self.buffer:
                        output += self.process_word()
                else:
                    self.buffer.append(b)
            else: # fixed-length, terminate after self.i bytes
                self.buffer.append(b)
                if len(self.buffer) == self.i:
                    output += self.process_word()
        if final and self.buffer: # EOF terminates the last word
            output += self.process_word()
        return output

    def process_word(self):
        output = ''
        if self.buffer[0] == ord('i'):
            self.i = min(99, int(self.buffer[1:] or 0)) # set input length
        elif self.buffer[0] == ord('o'):
            self.o = min(99, int(self.buffer[1:] or 0)) # set output length
        else:
            output = self.buffer.decode('ascii')
            if len(output) < self.o:
                output += '-'*self.o # pad out with hyphens
            if self.o:
                output = output[:self.o] # truncate to output length
            output += '.'
        self.buffer = bytearray()
        return output

    codecEnabled = False


def lookupTestDecoder(name):
    if StatefulIncrementalDecoder.codecEnabled and name == 'test_decoder':
        latin1 = codecs.lookup('latin-1')
        return codecs.CodecInfo(
            name='test_decoder', encode=latin1.encode, decode=None,
            incrementalencoder=None,
            streamreader=None, streamwriter=None,
            incrementaldecoder=StatefulIncrementalDecoder)


def signature(f, arg):
    try:
        f(arg)
    except BaseException as e:
        return (type(e).__name__, str(e))
    raise AssertionError('expected an exception')


response = ('noncallable-encoder', None, 2, 'not-a-decoder')


def order_case():
    visited = []
    def first(name):
        visited.append('first/' + name)
    def second(name):
        visited.append('second/' + name)
        return response
    def after(name):
        raise AssertionError('a matched lookup continued')
    assert codecs.register(first) is None
    codecs.register(second)
    codecs.register(after)
    assert codecs.lookup('  --Rx•é.. ä+ LOT- -9!') is response
    assert codecs.lookup('RX... -lot 9') is not None
    assert codecs.lookup('Rx.. LOT---9') is response
    print('visited', visited)
    assert visited == ['first/rx_.._lot_9', 'second/rx_.._lot_9', 'first/rx..._lot_9', 'second/rx..._lot_9', 'first/rx.._lot_9', 'second/rx.._lot_9']
    assert codecs.lookup(' Rx? .. LOT_9 ') is response
    assert len(visited) == 6


def normalization_case():
    names = []
    def search(name):
        names.append(name)
    codecs.register(search)
    names_input = [' ÄX\tß ☺ Ab•☂ c. ', '🗺', '. .', '  ..-    ', 'X...a_B', '  UTF...@é / 9.  ']
    for name in names_input:
        assert signature(codecs.lookup, name) == ('LookupError','unknown encoding: ' + name)
    print('names', names)
    assert names == ['x_ab_c.', '', '._.', '..', 'x...a_b', 'utf..._9.']


def cache_case():
    visited = []
    def miss(name):
        visited.append('miss/' + name)
    def accept(name):
        visited.append('accept/' + name)
        if name == 'zz_cache':
            return response
    def unused(name):
        raise AssertionError('unregistered callback ran')
    codecs.register(miss)
    for name in ('ZZ Cache', 'ZZ----cache'):
        assert signature(codecs.lookup, name) == ('LookupError', 'unknown encoding: ' + name)
    codecs.register(accept)
    assert codecs.lookup('ZZ cache') is response
    assert codecs.lookup('ZZ cache') is response
    codecs.register(unused)
    assert codecs.lookup('ZZ cache') is response
    assert codecs.unregister(12) is None
    assert codecs.lookup('ZZ CACHE') is response
    codecs.unregister(unused)
    assert codecs.lookup('ZZ CACHE') is response
    print('history', visited)
    assert visited == ['miss/zz_cache', 'miss/zz_cache', 'miss/zz_cache', 'accept/zz_cache','miss/zz_cache', 'accept/zz_cache']
    codecs.unregister(accept)
    assert signature(codecs.lookup, 'ZZ Cache') == ('LookupError','unknown encoding: ZZ Cache')


class SearchObject:
    def __init__(self, label, log):
        self.label = label
        self.log = log
    def __call__(self, name):
        self.log.append(self.label)
    def __eq__(self, other):
        raise AssertionError('removal compared equality')

def dup_case():
    seen = []
    a = SearchObject('a', seen)
    b = SearchObject('b', seen)
    c = SearchObject('c', seen)
    codecs.register(a)
    codecs.register(b)
    codecs.register(a)
    codecs.unregister(c)
    signature(codecs.lookup, 'Zz-d')
    assert seen == ['a','b','a']
    seen.clear()
    codecs.unregister(a)
    signature(codecs.lookup, 'Zz-d')
    assert seen == ['b','a']
    seen.clear()
    codecs.unregister(a)
    codecs.unregister(a)
    signature(codecs.lookup, 'Zz-d')
    assert seen == ['b']
    print('duplicate first identity removed; equality never called')


def malformed_case():
    visited = []
    def bad(name):
        visited.append(name)
        if name == 'zz_wrong_kind':
            return [1,2,3,4]
        if name == 'zz_short':
            return (None,None,None)
        if name == 'zz_exception':
            raise OSError('search rejected')
        if name == 'zz_empty':
            return ()
    def never(name):
        raise AssertionError('bad return/exception swallowed')
    codecs.register(bad)
    codecs.register(never)
    for name in ['zz_wrong_kind','zz_short','zz_empty','zz_exception','zz_short']:
        expected = ('OSError','search rejected') if name == 'zz_exception' else ('TypeError','codec search functions must return 4-tuples')
        actual = signature(codecs.lookup, name)
        print(name, actual)
        assert actual == expected
    assert visited == ['zz_wrong_kind','zz_short','zz_empty','zz_exception','zz_short']


def arguments_case():
    assert signature(codecs.register, 13) == ('TypeError','argument must be callable')
    assert codecs.unregister(13) is None
    assert signature(codecs.lookup, 'x\x00y') == ('ValueError','embedded null character')
    assert signature(codecs.lookup, b'z') == ('TypeError','lookup() argument must be str, not bytes')
    print('noncallable, unregistered noncallable, embedded NUL, nonstr')


def builtin_case():
    visits = []
    def intercept(name):
        visits.append(name)
        return response
    codecs.register(intercept)
    assert codecs.lookup('utf-8').name == 'utf-8'
    assert codecs.lookup('LATIN--1').name == 'iso8859-1'
    assert visits == []
    print('builtin search precedes user search')


def nested_case():
    trace = []
    def recurse(name):
        trace.append(name)
        if name == 'zz_inner':
            return response
        if name == 'zz_outer':
            return codecs.lookup('ZZ-inner')
        if name == 'zz_same' and trace.count('zz_same') == 1:
            return codecs.lookup('zz_same')
        return response
    codecs.register(recurse)
    assert codecs.lookup('zz outer') is response
    assert codecs.lookup('zz inner') is response
    assert codecs.lookup('zz same') is response
    assert codecs.lookup('zz outer') is response
    print('nested', trace)
    assert trace == ['zz_outer','zz_inner','zz_same','zz_same']


def append_case():
    seen = []
    def late(name):
        seen.append('late')
        return response
    def add(name):
        seen.append('add')
        if len(seen) == 1:
            codecs.register(late)
    codecs.register(add)
    assert signature(codecs.lookup,'ZZ_LATE') == ('LookupError','unknown encoding: ZZ_LATE')
    assert codecs.lookup('ZZ_LATE') is response
    print('append', seen)
    assert seen == ['add','add','late']


def remove_case():
    seen = []
    def drop(name):
        seen.append('drop')
        codecs.unregister(skipped)
    def skipped(name):
        raise AssertionError('unregistered callback ran')
    def last(name):
        seen.append('last')
        return response
    codecs.register(drop)
    codecs.register(skipped)
    codecs.register(last)
    assert codecs.lookup('zz live') is response
    print('remove', seen)
    assert seen == ['drop','last']
    codecs.unregister(drop)
    codecs.unregister(last)
    def selfremove(name):
        codecs.unregister(selfremove)
    def tail(name):
        raise AssertionError('shifted callback ran')
    codecs.register(selfremove)
    codecs.register(tail)
    actual = signature(codecs.lookup, 'zz stale')
    print('shrink', actual)
    assert actual == ('IndexError','list index out of range')


class HeldSearch:
    def __init__(self, events):
        self.events = events
    def __call__(self, name):
        self.events.append('called')
        codecs.unregister(self)
        self.events.append('unregistered')
        return response
    def __del__(self):
        self.events.append('released')


def lifetime_case():
    events = []
    def enroll():
        callback = HeldSearch(events)
        codecs.register(callback)
        codecs.register(callback)
        codecs.unregister(callback)
    enroll()
    assert events == []
    assert codecs.lookup('zz resident') is response
    print('lifetime', events)
    assert events == ['called','unregistered','released']
    assert codecs.lookup('zz resident') is response
    def clear(name):
        pass
    codecs.register(clear)
    codecs.unregister(clear)
    assert signature(codecs.lookup,'zz resident') == ('LookupError','unknown encoding: zz resident')


class HeldResult:
    def __init__(self, events):
        self.events = events
    def __del__(self):
        self.events.append('cache-released')

def payload_case():
    events = []
    def search(name):
        return (HeldResult(events), 1, 2, 3)
    codecs.register(search)
    codecs.lookup('zz result')
    assert events == []
    codecs.unregister(42)
    assert events == []
    codecs.unregister(search)
    print('cache ownership', events)
    assert events == ['cache-released']


def fixture_case():
    codecs.register(lookupTestDecoder)
    assert signature(codecs.lookup,'test decoder') == ('LookupError','unknown encoding: test decoder')
    StatefulIncrementalDecoder.codecEnabled = True
    info = codecs.lookup(' TEST__Decoder! ')
    assert info.name == 'test_decoder'
    assert info.incrementaldecoder is StatefulIncrementalDecoder
    assert info.decode is None and info.encode is codecs.lookup('latin-1').encode
    assert info.incrementaldecoder().decode(b'abc', True) == 'a.b.c.'
    StatefulIncrementalDecoder.codecEnabled = False
    assert codecs.lookup('test-decoder') is info
    codecs.unregister(lookupTestDecoder)
    assert signature(codecs.lookup,'test-decoder') == ('LookupError','unknown encoding: test-decoder')
    print('lookupTestDecoder registered, enabled, cache-visible, unregistered')


def inverted_case():
    codecs.register(lambda name: response)
    assert codecs.lookup('zz-inverted')[0] == 'deliberately wrong', 'reversed codec identity'


cases = {'order': order_case, 'normalization': normalization_case, 'cache': cache_case,
    'duplicate': dup_case, 'malformed': malformed_case, 'arguments': arguments_case,
    'builtins': builtin_case, 'reentrant': nested_case, 'append': append_case,
    'remove': remove_case, 'lifetime': lifetime_case, 'cache-lifetime': payload_case,
    'fixture': fixture_case, 'inverted': inverted_case}
selected = sys.argv[1]
if selected not in cases:
    print('absent selection', selected)
    sys.exit(3)
cases[selected]()
print('OK', selected)
