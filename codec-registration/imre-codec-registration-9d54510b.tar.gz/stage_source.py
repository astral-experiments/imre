"""Copy the two upstream definitions using exact byte boundaries."""
import ast, hashlib, json, pathlib
r = pathlib.Path(__file__).resolve().parent
src = r.parents[1] / 'python/cpython-3.14.5/Lib/test/test_io.py'
data = src.read_bytes()
sha = lambda s: hashlib.sha256(s).hexdigest()
assert sha(data) == '6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
lines = data.splitlines(keepends=True)
parts = [b'import codecs\nimport sys\n\n']
manifest = {}
for node in ast.parse(data).body:
    name = getattr(node, 'name', '')
    if name in ('lookupTestDecoder', 'StatefulIncrementalDecoder'):
        piece = b''.join(lines[node.lineno - 1:node.end_lineno])
        parts.append(piece)
        manifest[name] = dict(first=node.lineno,last=node.end_lineno,sha256=sha(piece))
parts.append((r/'body.py').read_bytes())
out = b'\n\n'.join(parts)
(r/'stage/codec_probe.py').write_bytes(out)
(r/'fixture.json').write_text(json.dumps(dict(cpython='5607950ef232dad16d75c0cf53101d9649d89115',src='Lib/test/test_io.py',source_sha256=sha(data),slices=manifest,control_sha256=sha(out)),indent=2)+'\n')
