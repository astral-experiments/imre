# User codec search registry controls

Every selector uses a new bounded Linux process with private cwd/TMPDIR, held stdin, raw streams and status. Native pairs are identified by commit and compiler/runtime hashes, individually built at boxed O0 and O3. Stock uses CPython 3.14.5, v3.14.5 at 5607950ef232dad16d75c0cf53101d9649d89115.

Thirteen positive selectors test ASCII normalization including non-ASCII separator runs, registration order, normalized success-cache identity, repeated misses and exceptions, first-only identity removal of duplicate registrations, cache clearing on effective unregister, malformed tuples, builtin priority, reentrant same/different-name lookups, mutation of the live callback list with an initially fixed iteration bound, and ownership of both a registered callback and a cached result. A deliberately inverted identity assertion and an absent selector provide negatives.

The fixture selector contains byte-exact definitions of lookupTestDecoder and StatefulIncrementalDecoder copied from the recorded CPython test_io.py. It verifies a disabled miss, an enabled hit with the actual CodecInfo and real incremental decoder, the cached identity even after disabling, and a miss after unregister. The driver isolates these two definitions; it earns zero original unittest registrations.

After unpacking, run sha256sum -c SHA256SUMS followed by python3 -B verify.py. The packet retains both compiler inputs, provider hashes, streams, lifecycle receipts, fixture slice provenance and the stock comparison. The absent role records historical missing-register failures. A candidate role retains all differing outcomes in comparison.json, even where they are expected limitations.
