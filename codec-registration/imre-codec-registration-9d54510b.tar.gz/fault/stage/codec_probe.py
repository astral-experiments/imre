import codecs
import gc
import sys


events = []
class Release:
    def __init__(self, label, cycle):
        self.label = label
        self.cycle = self if cycle else None
    def __call__(self, name):
        events.append('entered')
        codecs.unregister(self)
        gc.collect()
        events.append('still-live')
        raise LookupError('user search rejected')
    def __del__(self):
        events.append('released ' + self.label)

class BadEntry:
    def __del__(self):
        events.append('malformed result released')

def install(label, cycle):
    callback = Release(label, cycle)
    codecs.register(callback)

def run_exception(cycle):
    label = 'cycle' if cycle else 'acyclic'
    install(label, cycle)
    gc.collect()
    assert not events
    try:
        codecs.lookup('zz-failure')
    except LookupError as exc:
        assert str(exc) == 'user search rejected'
    else:
        raise AssertionError('exception lost')
    gc.collect()
    print('after collection', events)
    assert events == ['entered', 'still-live', 'released ' + label]
    try:
        codecs.lookup('zz-failure')
    except LookupError as exc:
        assert str(exc) == 'unknown encoding: zz-failure'
    else:
        raise AssertionError('failed search cached')

def bad_callback(name):
    return (BadEntry(),)
def malformed():
    codecs.register(bad_callback)
    try:
        codecs.lookup('zz-bad')
    except TypeError as e:
        assert str(e) == 'codec search functions must return 4-tuples'
    else:
        raise AssertionError('malformed result accepted')
    gc.collect()
    print('after collection', events)
    assert events == ['malformed result released']

sel=sys.argv[1]
if sel == 'exception': run_exception(False)
elif sel == 'cycle': run_exception(True)
elif sel == 'malformed': malformed()
else: sys.exit(3)
print('OK', sel)
