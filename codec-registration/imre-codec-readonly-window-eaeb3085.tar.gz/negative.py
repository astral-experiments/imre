import codecs

data = bytearray(b'abc')

def decode(view):
    assert view.obj is None and view.readonly
    assert view.tobytes() == b'abc'
    data[0] = 88
    seen = view.tobytes()
    print("source", bytes(data), "codec", seen)
    assert seen == b'Xbc', "decoder received a stale snapshot"
    return 'decoded', 3

def search(name):
    if name == 'fdsource_mutable':
        return (None, decode, None, None)

codecs.register(search)
try:
    assert data.decode('fdsource-mutable') == 'decoded'
finally:
    codecs.unregister(search)
