import codecs
import sys


class BA(bytearray):
    pass


class B(bytes):
    pass


def cannot_resize(data):
    try:
        data.append(63)
    except BufferError:
        return
    raise AssertionError("resize unexpectedly succeeded")


def run(data, fails):
    mutable = isinstance(data, bytearray)
    retained = []
    error = ValueError("decoder exception")

    def decode(view):
        assert type(view) is memoryview and view.obj is None
        assert view.readonly and view.format == 'B' and view.itemsize == 1
        assert view.tobytes() == b'abc'
        for child in (view, memoryview(view), view[1:], view[::2]):
            assert child.obj is None and child.readonly
            try:
                child[0] = 97
            except TypeError:
                pass
            else:
                raise AssertionError("writable codec view")
        child = view[::-2]
        assert child.tobytes() == b'ca'
        retained.extend((view, child))
        if mutable:
            data[0] = 42
            assert view[0] == 42 and view.tobytes() == b'*bc'
            assert child.tobytes() == b'c*'
            cannot_resize(data)
        if fails:
            raise error
        return 'decoded', 3

    def search(name):
        return (None, decode, None, None) if name == 'fdsource_window' else None

    codecs.register(search)
    try:
        if fails:
            try:
                data.decode('fdsource-window')
            except ValueError as exc:
                assert exc is error
            else:
                raise AssertionError("lost decoder error")
        else:
            assert data.decode('fdsource-window') == 'decoded'
        view, stride = retained
        if mutable:
            data[2] = 33
            assert view.tobytes() == b'*b!' and stride.tobytes() == b'!*'
            # Independently verify resize protection for a real, public export.
            public = memoryview(data)
            cannot_resize(data)
            public.release()
            # CPython's borrowed codec views do not pin the source after return.
            # Never access the retained views after this resize.
            data.append(63)
            assert data == bytearray(b'*b!?')
        else:
            assert view.tobytes() == b'abc' and stride.tobytes() == b'ca'
    finally:
        codecs.unregister(search)


for maker in (bytes, B, bytearray, BA):
    for fails in (False, True):
        run(maker(b'abc'), fails)
        print(maker.__name__, 'exception' if fails else 'return')
