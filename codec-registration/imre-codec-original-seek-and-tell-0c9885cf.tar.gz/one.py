"""Reuse the exact full-class ELF to isolate the original enabling the custom decoder."""
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;project=r.parents[1];base=project.parent
pin,lane=sys.argv[1:3]
assert len(pin)==40 and lane in ('boxed-O0','boxed-O3')
src=project/'replay';parent=src/'raw'/pin/lane;deadline=time.monotonic()+1400
while not (parent/'build.json').exists():
    if time.monotonic()>deadline:raise TimeoutError(parent)
    time.sleep(4)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();b=json.loads((parent/'build.json').read_bytes())
pair=base/'fs-family/provider-replay/pairs'/pin
assert (pair/'commit').read_text().strip()==pin and b['pin']==pin and b['lane']==lane and b['executable_sha256']==sha(parent/'suite')
assert b['driver_sha256']==sha(src/'stage/Lib/callback_class.py') and b['exit']==0 and not b['timeout']
assert all(sha(pair/n)==h for n,h in b['compiler_runtime'].items())
env={**os.environ,'CWRAPPER_PAIR':str(pair),'CWRAPPER_LLVM':str(base/'llvm')}
subprocess.run([sys.executable,'-B',r/'run_one.py',lane,pin,'original','test.test_io.CTextIOWrapperTest.test_seek_and_tell',parent/'suite'],env=env,check=True,timeout=685)
dest=r/'raw'/pin/lane
for name in ('build.json','build.stdout','build.stderr'):shutil.copyfile(parent/name,dest/name)
print((dest/'original/stdout').read_text(),end='')
print((dest/'original/stderr').read_text()[-950:],end='')
