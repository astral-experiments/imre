"""Wait for both public classes and use their canonical supplemental slot and ID."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,shutil,subprocess,sys,time
r=Path(__file__).resolve().parent;root=r.parents[1];src=root/'public-replay';pin=sys.argv[1];assert len(pin)==40
key='test.test_io.CTextIOWrapperTest.test_seek_and_tell';label='confirm-67'
pair=root.parent/'fs-family/provider-replay/pairs'/pin
os.environ.update(CWRAPPER_PAIR=str(pair),CWRAPPER_LLVM=str(root.parent/'llvm'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_bytes())
deadline=time.monotonic()+8400
lanes=['boxed-O0','boxed-O3']
while not all((src/'raw'/pin/l/'class/result.json').exists() for l in lanes):
    for lane in lanes:
        b=src/'raw'/pin/lane/'build.json'
        if b.exists() and read(b)['exit']!=0:raise RuntimeError('public class build failed: '+str(b))
    if time.monotonic()>deadline:raise TimeoutError('public class results')
    time.sleep(5)
assert (pair/'commit').read_text().strip()==pin
sys.path.insert(0,str(src))
import repeat
repeat.run_ref(label,key)
base=r/'public'/pin
def collect(revision,lane):
    prior=src/'raw'/revision/lane
    out=base/'raw'/revision/lane
    (out/'original').mkdir(parents=True,exist_ok=True)
    if revision!='cpython':
        b=read(prior/'build.json');assert b['pin']==pin and b['lane']==lane and b['exit']==0 and not b['timeout']
        assert b['driver_sha256']==sha(src/'stage/Lib/callback_class.py')
        assert all(sha(pair/n)==h for n,h in b['compiler_runtime'].items())
        exe=Path(b['argv'][b['argv'].index('-o')+1]);assert b['executable_sha256']==sha(exe)
        repeat.run_case(pin,lane,label,key)
        for f in ('build.json','build.stdout','build.stderr'):shutil.copyfile(prior/f,out/f)
    q=read(prior/label/'result.json');assert q['selector']==key
    for f in ('result.json','stdout','stderr'):shutil.copyfile(prior/label/f,out/'original'/f)
    print(revision[:8],lane,(out/'original/stdout').read_text().splitlines()[-2:],flush=True)
collect('cpython','ordinary')
with ThreadPoolExecutor(2) as pool:list(pool.map(lambda lane:collect(pin,lane),lanes))
subprocess.run([sys.executable,'-B',r/'seal.py',pin],check=True,timeout=120)
