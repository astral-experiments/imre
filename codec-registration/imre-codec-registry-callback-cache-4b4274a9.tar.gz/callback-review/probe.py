import codecs
import gc
import sys
import weakref

class Marker: pass
class Error(Exception): pass
seen = []
key = 'qz_raise_unreg'

class Provider:
    def __call__(self, name):
        assert name == key
        codecs.unregister(self)
        item = Marker()
        seen.append(weakref.ref(item))
        e = Error('search error')
        e.item = item
        raise e

def raising():
    callback = Provider()
    ref = weakref.ref(callback)
    codecs.register(callback)
    del callback
    try:
        codecs.lookup(key)
    except Error as e:
        assert str(e) == 'search error'
        assert seen[0]() is e.item
        print('exception payload alive')
    else:
        raise AssertionError('provider failure lost')
    gc.collect()
    print('released',ref() is None,seen[0]() is None)
    assert ref() is None and seen[0]() is None
    try:
        codecs.lookup(key)
    except LookupError:
        assert len(seen)==1
        print('failed provider removed, failure uncached')
    else:
        raise AssertionError('missing lookup succeeded')

def drops():
    trace=[]
    handles={}
    refs={}
    class Token:
        def __init__(self,name):
            self.name = name
        def __del__(self):
            trace.append((self.name, refs['qz_b']() is not None))
            if self.name=='qz_a':
                codecs.lookup('qz_c')
    def find(name):
        item = Token(name)
        refs[name]=weakref.ref(item)
        return (item,None,None,None)
    def unused(n): pass
    codecs.register(find)
    codecs.register(unused)
    codecs.lookup('qz_a')
    codecs.lookup('qz_b')
    codecs.unregister(unused)
    assert trace == [('qz_a',True),('qz_b',True)],trace
    assert refs['qz_c']() is not None
    print('detached cache destruction',trace)
    codecs.unregister(find)
    assert refs['qz_c']() is None

cases={'raising':raising,'drops':drops}
cases[sys.argv[1]]()
