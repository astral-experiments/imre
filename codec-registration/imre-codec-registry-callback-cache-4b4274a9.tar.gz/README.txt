Linux CPython v3.14.5 binary SHA-256 c27397da5541f67655be462e128ca3d3eb6e0a8eb0d39036896c9042529f4304
Synthetic supplemental controls only; this packet contributes zero original IDs.
raising: self-unregistration preserves exception payload, then both payload and provider are collected. drops: first evicted tuple destructor observes second still live, repopulates cache; insertion order observed. Historical 9d54510b red drops the second first.
Raw escape / UTF-16LE / UTF-32LE: earlier mutable provider misses, specialized default success remains cached on enabling earlier provider and appending a newly registered provider, a matching removal invalidates it, positive custom entry survives re-adding default, removing custom restores native, then removing default leaves an empty registry. Historical 5e547cf O0 bypasses first callback on all three.
Every native build verifies compiler/runtime hashes. Executions use piped stdin, own directory and TMPDIR, bounded Linux subreaper.
