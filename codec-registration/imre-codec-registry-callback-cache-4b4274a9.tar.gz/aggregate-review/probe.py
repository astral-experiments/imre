import sys

if sys.argv[1] in ('raising', 'drops'):
    import codecs
    import gc
    import sys
    import weakref

    class Marker: pass
    class Error(Exception): pass
    seen = []
    key = 'qz_raise_unreg'

    class Provider:
        def __call__(self, name):
            assert name == key
            codecs.unregister(self)
            item = Marker()
            seen.append(weakref.ref(item))
            e = Error('search error')
            e.item = item
            raise e

    def raising():
        callback = Provider()
        ref = weakref.ref(callback)
        codecs.register(callback)
        del callback
        try:
            codecs.lookup(key)
        except Error as e:
            assert str(e) == 'search error'
            assert seen[0]() is e.item
            print('exception payload alive')
        else:
            raise AssertionError('provider failure lost')
        gc.collect()
        print('released',ref() is None,seen[0]() is None)
        assert ref() is None and seen[0]() is None
        try:
            codecs.lookup(key)
        except LookupError:
            assert len(seen)==1
            print('failed provider removed, failure uncached')
        else:
            raise AssertionError('missing lookup succeeded')

    def drops():
        trace=[]
        handles={}
        refs={}
        class Token:
            def __init__(self,name):
                self.name = name
            def __del__(self):
                trace.append((self.name, refs['qz_b']() is not None))
                if self.name=='qz_a':
                    codecs.lookup('qz_c')
        def find(name):
            item = Token(name)
            refs[name]=weakref.ref(item)
            return (item,None,None,None)
        def unused(n): pass
        codecs.register(find)
        codecs.register(unused)
        codecs.lookup('qz_a')
        codecs.lookup('qz_b')
        codecs.unregister(unused)
        assert trace == [('qz_a',True),('qz_b',True)],trace
        assert refs['qz_c']() is not None
        print('detached cache destruction',trace)
        codecs.unregister(find)
        assert refs['qz_c']() is None

    cases={'raising':raising,'drops':drops}
    cases[sys.argv[1]]()
else:
    import codecs
    import encodings
    import sys

    name = sys.argv[1]
    data = {'raw_unicode_escape': b'A', 'utf_16_le': b'A\0', 'utf_32_le': b'A\0\0\0'}[name]
    visits = []
    enabled = False
    response = (None, lambda data, *args: ('CUSTOM', len(data)), None, None)
    default = encodings.search_function

    def first(n):
        visits.append(n)
        if enabled:
            return response

    def unused(n):
        raise AssertionError('late provider should not run')

    codecs.register(first)
    codecs.unregister(default)
    codecs.register(default)
    assert codecs.decode(data,name)=='A'
    print('default via miss',visits,flush=True)
    assert visits==[name]
    enabled=True
    assert codecs.decode(data,name)=='A'
    codecs.register(unused)
    assert codecs.decode(data,name)=='A'
    assert visits==[name]
    codecs.unregister(unused)
    assert codecs.decode(data,name)=='CUSTOM'
    assert visits==[name]*2 and codecs.lookup(name) is response
    codecs.unregister(default)
    assert codecs.decode(data,name)=='CUSTOM' and visits==[name]*3
    codecs.register(default)
    assert codecs.lookup(name) is response and codecs.decode(data,name)=='CUSTOM' and visits==[name]*3
    codecs.unregister(first)
    assert codecs.decode(data,name)=='A'
    codecs.unregister(default)
    try:
        codecs.decode(data,name)
    except LookupError as e:
        assert str(e)=="no codec search functions registered: can't find encoding",str(e)
    else:
        raise AssertionError('removed default still decoded')
    print('cached default, invalidated, user entry cached on re-add, restored, empty misses',len(visits))
