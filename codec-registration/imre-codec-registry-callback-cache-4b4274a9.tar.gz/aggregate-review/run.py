from pathlib import Path
import hashlib,json,sys,time
p=Path(__file__).resolve().parent
base=p.parents[1]; helper=base/'textio/controls/run.py'
ns={'__file__':str(helper)}
exec(compile(helper.read_text().split('mixed=b')[0],str(helper),'exec'),ns)
pin=sys.argv[1]; lane=sys.argv[2]; out=p/pin/lane;out.mkdir(parents=True)
src=p/'probe.py';h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
if lane=='stock':cmd=[ns['ref'],'-IB',src]
else:
 pair=base/'fs-family/provider-replay/pairs'/pin
 deadline=time.monotonic()+1800
 while not (pair/'ready').exists():
    if time.monotonic()>=deadline:raise TimeoutError(pair)
    time.sleep(2)
 hashes={name:h for h,name in [l.split() for l in (pair/'ready').read_text().splitlines()]}
 assert (pair/'commit').read_text().strip()==pin and all(h(pair/n)==v for n,v in hashes.items())
 ns['env']['IMRE_PYTHON']=str(pair/'imre')
 b=out/'build';b.mkdir();binary=out/'probe';cmd=[binary]
 args=[pair/'imre','build',src,'--module-root',p,'--opt-level',lane[-1],'--runtime-imports','--no-cache','--runtime',pair/'libimre_runtime.a','--clang',base/'llvm/usr/bin/clang-19','-o',binary]
 meta=ns['run'](args,b,b,1800);meta['hashes']=hashes;(b/'result.json').write_text(json.dumps(meta,indent=2));assert meta['rc']==0,(b/'stderr').read_text()
for case in ('raising','drops','raw_unicode_escape','utf_16_le','utf_32_le'):
 o=out/case;o.mkdir();cwd=o/'cwd';cwd.mkdir()
 m=ns['run'](cmd+[case],cwd,o,24)
 assert not list(cwd.iterdir())
 same=all((o/n).read_bytes()==(p/'reference/stock'/case/n).read_bytes() for n in ('stdout','stderr'))
 m.update(sha=pin,source=h(src),match=same);(o/'result.json').write_text(json.dumps(m,indent=2))
 print(lane,case,m['rc'],same,(o/'stdout').read_text(), (o/'stderr').read_text(),flush=True)
if lane!='stock':binary.unlink()
