import codecs
import encodings
import sys

name = sys.argv[1]
data = {'raw_unicode_escape': b'A', 'utf_16_le': b'A\0', 'utf_32_le': b'A\0\0\0'}[name]
visits = []
enabled = False
response = (None, lambda data, *args: ('CUSTOM', len(data)), None, None)
default = encodings.search_function

def first(n):
    visits.append(n)
    if enabled:
        return response

def unused(n):
    raise AssertionError('late provider should not run')

codecs.register(first)
codecs.unregister(default)
codecs.register(default)
assert codecs.decode(data,name)=='A'
print('default via miss',visits,flush=True)
assert visits==[name]
enabled=True
assert codecs.decode(data,name)=='A'
codecs.register(unused)
assert codecs.decode(data,name)=='A'
assert visits==[name]
codecs.unregister(unused)
assert codecs.decode(data,name)=='CUSTOM'
assert visits==[name]*2 and codecs.lookup(name) is response
codecs.unregister(default)
assert codecs.decode(data,name)=='CUSTOM' and visits==[name]*3
codecs.register(default)
assert codecs.lookup(name) is response and codecs.decode(data,name)=='CUSTOM' and visits==[name]*3
codecs.unregister(first)
assert codecs.decode(data,name)=='A'
codecs.unregister(default)
try:
    codecs.decode(data,name)
except LookupError as e:
    assert str(e)=="no codec search functions registered: can't find encoding",str(e)
else:
    raise AssertionError('removed default still decoded')
print('cached default, invalidated, user entry cached on re-add, restored, empty misses',len(visits))
