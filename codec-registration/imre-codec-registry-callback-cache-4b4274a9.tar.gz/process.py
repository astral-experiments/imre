from pathlib import Path
import ctypes, hashlib, json, os, signal, stat, subprocess, sys, time
root=Path(__file__).resolve().parent
base=root.parents[1]
sha=(root.parent/'base').read_text().strip()
pair=base/'fs-family/provider-replay/pairs'/sha
ref=base/'python/managed/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
src=root/'src/probe.py'
env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','PYTHONWARNINGS','PYTHON_CONTEXT_AWARE_WARNINGS','IMREFLAGS')}
env.update(IMRE_PYTHON=str(pair/'imre'),LD_LIBRARY_PATH=str(base/'llvm/usr/lib/x86_64-linux-gnu'),PYTHONDONTWRITEBYTECODE='1',LANG='C.UTF-8',LC_ALL='C.UTF-8')
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
def digest(blob):return hashlib.sha256(blob).hexdigest()
def run(cmd, cwd, dest, timeout):
    temp=dest/'tmp';temp.mkdir()
    with (dest/'stdout').open('wb') as so, (dest/'stderr').open('wb') as se:
        p=subprocess.Popen([str(x) for x in cmd],cwd=cwd,env=dict(env,TMPDIR=str(temp)),stdin=subprocess.PIPE,stdout=so,stderr=se,start_new_session=True)
        pipe=stat.S_ISFIFO(os.fstat(p.stdin.fileno()).st_mode)
        timedout=False
        try:p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timedout=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
        p.stdin.close()
    kids=[]
    while True:
        try:
            pid,status=os.waitpid(-1,os.WNOHANG)
            assert pid
            kids.append([pid,status])
        except ChildProcessError:break
    extra=sorted(str(p.relative_to(temp)) for p in temp.rglob('*'))
    assert pipe and not kids and not timedout and not extra
    return dict(cmd=list(map(str,cmd)),pid=p.pid,rc=p.returncode,stdin_pipe=pipe,timeout=timedout,adopted=kids,tmp_residue=extra,stdout_sha256=digest((dest/'stdout').read_bytes()),stderr_sha256=digest((dest/'stderr').read_bytes()))
