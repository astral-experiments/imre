#!/bin/bash
set -euo pipefail
suite=$1
case "$suite" in
 file) label=public-db76; head=db76a638018898fa3dcc59400be90688afc0e091 ;;
 fileio) label=public-92047; head=92047db65af2e66b2b49f6505bcf68f5e37d4cb8 ;;
 *) exit 2 ;;
esac
python3 -B supervise.py 22000 python3 -B intact-io-companions/replay-level.py "$label" "$head" "$suite" boxed 3
for lane in boxed3 ordinary0 ordinary3; do
  python3 -B supervise.py 22000 python3 -B intact-io-companions/replay-level.py public-3727-final 0dfd29b7478757ce95f926590fa80a6ba45ec44f "$suite" "${lane%?}" "${lane: -1}"
done
