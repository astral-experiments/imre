from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,time
p=Path(__file__).resolve().parent; w=p.parent; cp=w.parent/'io-reference/cpython'; pin=json.loads((p/'stage.json').read_text())['pin']
def digest(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
for suite in ('file','fileio'):
    loc=p/('reference-'+suite); loc.mkdir(exist_ok=False)
    source=p/'stage'/('test_'+suite+'_driver.py')
    args=[str(cp/'python'),'-EB',str(source)]
    with tempfile.TemporaryDirectory(dir=loc) as tmp, (loc/'run.stdout').open('wb') as stdout,(loc/'run.stderr').open('wb') as stderr:
        start=time.monotonic()
        r=subprocess.run([sys.executable,'-B',w/'supervise.py','300',*args],cwd=tmp,stdout=stdout,stderr=stderr,timeout=400)
    (loc/'result.json').write_text(json.dumps(dict(argv=args,exit=r.returncode,elapsed=time.monotonic()-start,limit=300,pin=pin,python_sha256=digest(cp/'python'),source_sha256=digest(source),stdout_sha256=digest(loc/'run.stdout'),stderr_sha256=digest(loc/'run.stderr')),indent=2)+'\n')
    print(loc,r.returncode,flush=True);r.check_returncode()
