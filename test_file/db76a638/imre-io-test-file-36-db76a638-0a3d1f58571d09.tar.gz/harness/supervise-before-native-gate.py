import ctypes
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

# Adopt grandchildren on Linux so a timed-out compiler or test cannot orphan them.
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), "PR_SET_CHILD_SUBREAPER")
p = subprocess.Popen(sys.argv[2:], start_new_session=True)
try:
    rc = p.wait(timeout=float(sys.argv[1]))
except subprocess.TimeoutExpired:
    print("deadline exceeded", file=sys.stderr, flush=True)
    rc = 124
    try:
        os.killpg(p.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
finally:
    # Reap all descendants. A detached child's own children become ours on exit.
    while True:
        try:
            pid, _ = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            break
        if pid:
            continue
        # The children file is optional on Linux. stat is available here.
        for entry in Path("/proc").iterdir():
            if not entry.name.isdecimal():
                continue
            try:
                stat = (entry / "stat").read_text().rsplit(")", 1)[1].split()
                if int(stat[1]) == os.getpid():
                    os.kill(int(entry.name), signal.SIGKILL)
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                continue
        time.sleep(0.025)
sys.exit(rc if rc >= 0 else 128 - rc)
