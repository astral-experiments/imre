from pathlib import Path
import collections,hashlib,json,os,subprocess,sys,tempfile,time
base=Path(__file__).resolve().parent;w=base.parent
lane=base/sys.argv[1]/sys.argv[2];bound=int(sys.argv[3]);previous=json.loads((lane/'run.json').read_bytes())
assert previous['exit']==124
exe=lane/'suite';meta=json.loads((lane/'registration.json').read_bytes())
with exe.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==meta['elf']
out=lane/('retry-'+str(bound));out.mkdir();env=dict(os.environ,LC_ALL='C.UTF-8',LANG='C.UTF-8',TMPDIR=str(w/'tmp'),LD_LIBRARY_PATH=str(w/'clang/usr/lib/x86_64-linux-gnu'))
start=time.monotonic()
with tempfile.TemporaryDirectory(dir=out) as work, (out/'run.stdout').open('wb') as stdout,(out/'run.stderr').open('wb') as stderr:
 p=subprocess.run([sys.executable,'-B',w/'supervise.py',str(bound),exe],cwd=work,env=env,stdout=stdout,stderr=stderr)
raw=(out/'run.stdout').read_text(errors='replace').splitlines();suite=lane.name.split('-')[0]
ids=json.loads((w.parent/'io-reference/upstream-registration.json').read_bytes())['registrations'][suite]['cases']
want=collections.Counter(x['id'] for x in ids);seen=collections.Counter(s[11:] for s in raw if s.startswith('REGISTERED '))
info=dict(argv=[str(exe)],elf_sha256=meta['elf'],sys_exit=p.returncode,bound=bound,elapsed=time.monotonic()-start,previous_exit=previous['exit'],registered=sum((want&seen).values()),other=dict(seen-want),outcome=[x for x in raw if x.startswith('OUTCOME ')])
(out/'run.json').write_text(json.dumps(info,indent=2)+'\n'); print(info)
