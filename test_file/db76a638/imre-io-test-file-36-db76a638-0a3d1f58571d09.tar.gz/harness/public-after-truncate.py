from pathlib import Path
from collections import Counter
import hashlib,json,os,subprocess,sys,tempfile,time
d=Path(__file__).resolve().parent;s=d/'stage';w=d.parent;ref=w.parent/'io-reference'
m=json.loads((d/'stage.json').read_bytes());registry=json.loads((ref/'upstream-registration.json').read_bytes())
label,expected=sys.argv[1:3];pair=w/(label+'-tools');out=d/label;out.mkdir()
env=dict(os.environ,LANG='C.UTF-8',LC_ALL='C.UTF-8',TMPDIR=str(w/'tmp'),LD_LIBRARY_PATH=str(w/'clang/usr/lib/x86_64-linux-gnu'))
def digest(f):
    with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def bounded(a,cwd,limit,loc):
    argv=list(map(str,a));start=time.monotonic()
    with loc.with_suffix('.stdout').open('wb') as stdout,loc.with_suffix('.stderr').open('wb') as stderr:
        c=subprocess.run([sys.executable,'-B',w/'supervise.py',str(limit),*argv],stdout=stdout,stderr=stderr,cwd=cwd,env=env)
    ret=dict(argv=argv,limit=limit,elapsed=round(time.monotonic()-start,3),exit=c.returncode,stdout_sha256=digest(loc.with_suffix('.stdout')),stderr_sha256=digest(loc.with_suffix('.stderr')))
    save(loc.with_suffix('.json'),ret);return ret
deadline=time.monotonic()+12000
while not (pair/'tree').exists():
    if time.monotonic()>deadline: raise RuntimeError('tool pair unavailable')
    time.sleep(7)
assert (pair/'commit').read_text().strip()==expected
for line in (pair/'tools.sha256').read_text().splitlines():
    h,n=line.split();assert digest(pair/n)==h
save(out/'tools.json',dict(head=(pair/'commit').read_text().strip(),tree=(pair/'tree').read_text().strip(),tool_hashes=(pair/'tools.sha256').read_text().splitlines()))
for opt in ((0,3) if label=='default-readers-3906' else (0,)):
    for route in ('boxed',):
        for suite in sys.argv[3:]:
            lane=out/(suite+'-'+route+str(opt));lane.mkdir()
            n='test_'+suite;src=s/(n+'_driver.py')
            assert digest(s/'test'/(n+'.py'))==registry['registrations'][suite]['source_sha256']
            exe=lane/'suite'
            a=[pair/'imre','build',src,'--module-root',s,'--runtime',pair/'libimre_runtime.a','--clang',w/'clang/usr/lib/llvm-19/bin/clang','--opt-level',str(opt),'--no-cache','--quiet']
            if route=='boxed':a.append('--runtime-imports')
            b=bounded([*a,'-o',exe],lane,1800,lane/'build')
            if b['exit']!=0:
                print(lane.name,'compile',b['exit'],(lane/'build.stderr').read_text(errors='replace').splitlines()[-1:],flush=True);continue
            with tempfile.TemporaryDirectory(dir=lane) as tmp:r=bounded([exe],Path(tmp),7200,lane/'run')
            observed=Counter(l[11:] for l in (lane/'run.stdout').read_text(errors='replace').splitlines() if l.startswith('REGISTERED '))
            canon=Counter(x['id'] for x in registry['registrations'][suite]['cases'])
            stats=dict(elf=digest(exe),registered=sum((observed&canon).values()),other=dict(observed-canon),expected=sum(canon.values()))
            save(lane/'registration.json',stats)
            if r['exit']!=124:exe.unlink()
            print(lane.name,r['exit'],stats,flush=True)
