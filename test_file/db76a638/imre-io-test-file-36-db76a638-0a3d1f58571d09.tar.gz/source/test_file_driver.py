import unittest
import test.test_file as target

def registered(suite):
    for case in suite:
        if isinstance(case, unittest.TestSuite):
            registered(case)
        else:
            print("REGISTERED", case.id(), flush=True)

def main():
    suite = unittest.defaultTestLoader.loadTestsFromModule(target)
    print("LOADED", target.__name__, target.__file__, flush=True)
    registered(suite)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print("OUTCOME", result.testsRun, len(result.failures), len(result.errors), len(result.skipped), flush=True)
    if not result.wasSuccessful():
        raise SystemExit(1)

main()
