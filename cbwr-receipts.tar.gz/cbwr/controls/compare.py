from pathlib import Path
import csv, hashlib, json, sys
H=Path(__file__).resolve().parent
name=sys.argv[1]
stage=H/name
def h(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def check(p,tag):
    doc=json.loads((p/(tag+".json")).read_text())
    for k in ("stdout","stderr"):
        fname=k if tag=="result" else "build."+k
        assert h(p/fname)==doc[k+"_sha256"]
    return doc
prov=json.loads((stage/"provenance.json").read_text())
assert prov["source_sha256"]==h(H/"probe.py")
records=[]
for level in (0,3):
    lane=stage/f"O{level}"
    bd=check(lane,"build")
    assert bd["exit"]==0 and not bd["timed_out"],bd
    for name in ("files","wrong-bytes","invalid","weak","writable","tell"):
        p=lane/name
        reference=H/"stock/reference"/name
        st=check(reference,"result")
        nt=check(p,"result")
        rc=nt["exit"]
        err_lines=(p/"stderr").read_text().splitlines()
        stock_lines=(reference/"stderr").read_text().splitlines()
        native_tail=err_lines[-1] if err_lines else ""
        stock_tail=stock_lines[-1] if stock_lines else ""
        assert not nt["timed_out"] and nt["argv"][-1]==name
        matched=rc==st["exit"] and nt["stdout_sha256"]==st["stdout_sha256"] and nt["file_hex"]==st["file_hex"] and stock_tail==native_tail
        records.append(dict(stage=stage.name,head=prov["imre"],opt=level,case=name,build_exit=bd["exit"],exit=rc,stock_exit=st["exit"],matched=matched,diagnostic=native_tail,native_receipt=str((p/"result.json").relative_to(H)),native_receipt_sha256=h(p/"result.json")))
with (stage/"summary.tsv").open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=records[0].keys(),delimiter="\t",lineterminator="\n")
    w.writeheader();w.writerows(records)
print("matches",sum(v["matched"] for v in records),"/",len(records),"summary_sha256",h(stage/"summary.tsv"))
