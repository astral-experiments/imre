from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import csv, hashlib, json, os, subprocess, time

H=Path(__file__).resolve().parent
W=Path("/workspace/scratch/cbwr-controls")
BH=H.parent/"build"
old="tested"
current="final"
def digest(p):
    with p.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
def read(p):
    return json.loads(p.read_text())
def dump(p,data):
    p.write_text(json.dumps(data,indent=2)+"\n")
def meta(label):
    p=BH/(label+"-provenance.json"); data=read(p)
    b=Path("/workspace/scratch/cbwr-bin-"+label)
    assert data["commit"]==(b/"READY").read_text().strip()
    for n,v in data["binaries"].items(): assert digest(b/n)==v
    return data
first=meta(old); last=meta(current)
assert first["binaries"]==last["binaries"]
assert last["commit"]=="55b01ff2fa1d4699581bcf9c1c47f362ffd4696f"
assert subprocess.run(["git","diff","--exit-code",first["commit"],last["commit"],"--","crates","Cargo.toml","Cargo.lock","stdlib"],cwd="/workspace/scratch/cbwr-fix",capture_output=True).returncode==0
all_rows=[]
for family in ("core","early-release"):
    work=W if family=="core" else W/family
    evidence=H if family=="core" else H/family
    pr="probe.py" if family=="core" else "release.py"
    st=evidence/old; now=evidence/current; now.mkdir(exist_ok=True)
    assert digest(work/pr)==digest(evidence/pr)
    prov=dict(imre=last["commit"],compiler_sha256=first["binaries"]["imre"],runtime_sha256=first["binaries"]["libimre_runtime.a"],source_sha256=digest(work/pr),qualification="same executable rerun after SHA-256 checks of compiler, runtime and source",prior_compiler_commit=first["commit"])
    dump(now/"provenance.json",prov)
    def run_lane(opt):
        o="O"+str(opt); orig=st/o; p=now/o; wd=work/current/o
        wd.mkdir(parents=True,exist_ok=True);p.mkdir(exist_ok=True)
        ref=orig/"build.json"; build=read(ref)
        assert build["exit"]==0 and "--opt-level" in build["argv"]
        assert build["argv"][build["argv"].index("--opt-level")+1]==str(opt)
        assert build["argv"][2]==str(work/pr)
        assert build["argv"][0]==str(Path("/workspace/scratch/cbwr-bin-tested")/"imre")
        assert build["argv"][build["argv"].index("--runtime")+1]=="/workspace/scratch/cbwr-bin-tested/libimre_runtime.a"
        assert build["stdout_sha256"]==digest(orig/"build.stdout") and build["stderr_sha256"]==digest(orig/"build.stderr")
        oldexe=Path(build["argv"][-1]); exe=wd/"probe"
        assert oldexe.is_file(); assert not exe.exists()
        d=digest(oldexe)
        if family=="core":
            assert d==(orig/"executable.sha256").read_text().strip() and read(st/"provenance.json")["source_sha256"]==prov["source_sha256"]
        else:
            assert build["head"]==first["commit"] and build["source_sha256"]==prov["source_sha256"]
        os.link(oldexe,exe)
        assert digest(exe)==d
        dump(p/"build-reference.json",dict(action="reuse_verified_binary",build_exit_at_prior_head=0,prior_head=first["commit"],prior_argv=build["argv"],prior_build_receipt=str(ref.relative_to(H)),prior_build_receipt_sha256=digest(ref),source_sha256=prov["source_sha256"],same_compiler_runtime_sha256=first["binaries"],executable_sha256=d,final_head=last["commit"],opt=opt))
        (p/"executable.sha256").write_text(d+"\n")
        keys=["files","wrong-bytes","invalid","weak","writable","tell"] if family=="core" else [""]
        for key in keys:
            rd=p/key; cwd=wd/key; rd.mkdir(exist_ok=True);cwd.mkdir(exist_ok=True)
            argv=[str(exe),key] if key else [str(exe)]
            tag="result" if key else "process"
            stdout=rd/("stdout" if key else "process.stdout");stderr=rd/("stderr" if key else "process.stderr")
            start=time.time(); env=os.environ.copy();env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE="1")
            for n in ("PYTHONPATH","IMREFLAGS","IMRE_ENCODED_FLAGS"):env.pop(n,None)
            with stdout.open("wb") as f,stderr.open("wb") as e:r=subprocess.run(argv,env=env,cwd=cwd,stdout=f,stderr=e,timeout=90)
            files={n:(cwd/n).read_bytes().hex() for n in ("old.bin","new.bin") if (cwd/n).is_file()}
            doc=dict(argv=argv,cwd=str(cwd),start_epoch=start,elapsed_s=round(time.time()-start,5),exit=r.returncode,timed_out=False,reaped_status=r.returncode,file_hex=files,stdout_sha256=digest(stdout),stderr_sha256=digest(stderr),head=last["commit"],executable_sha256=d)
            fp=rd/(tag+".json");dump(fp,doc)
            stock=evidence/"stock/reference"/key; cp=read(stock/(tag+".json"))
            stock_stderr=(stock/stderr.name).read_text().splitlines()
            actual_stderr=stderr.read_text().splitlines()
            matched=(cp["exit"]==doc["exit"] and cp["stdout_sha256"]==doc["stdout_sha256"] and stock_stderr[-1:]==actual_stderr[-1:] and files==cp.get("file_hex",{}))
            if key:all_rows.append(dict(stage=current,head=last["commit"],opt=opt,case=key,build_exit=build["exit"],exit=doc["exit"],stock_exit=cp["exit"],matched=matched,diagnostic=actual_stderr[-1] if actual_stderr else "",native_receipt=str(fp.relative_to(H)),native_receipt_sha256=digest(fp)))
            assert matched,(family,opt,key,doc,cp)
        (p/"COMPLETE").write_text(last["commit"]+"\n")
    with ThreadPoolExecutor(2) as pool:list(pool.map(run_lane,(0,3)))
p=H/current/"summary.tsv"
with p.open("w",newline="") as stream:
    w=csv.DictWriter(stream,fieldnames=all_rows[0].keys(),delimiter="\t",lineterminator="\n");w.writeheader(); w.writerows(sorted(all_rows,key=lambda x:(x["opt"],x["case"])))
print("12/12 + 2/2 final native process matches, reused binaries. summary sha256",digest(p))
