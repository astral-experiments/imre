from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib, json, os, subprocess, sys, time
H=Path(__file__).resolve().parent
W=Path("/workspace/scratch/cbwr-controls/early-release")
src=W/"release.py"
stage,head=sys.argv[1:3]
if stage=="public":
    os.nice(12)
cpy=Path("/workspace/scratch/cpytools/bin/python3.14")
def h(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+"\n")
def capture(d,wd,cmd,tag,limit):
    argv=list(map(str,cmd));start=time.time()
    env=os.environ.copy();env.update(TMPDIR=str(wd),PYTHONDONTWRITEBYTECODE="1")
    for k in ("PYTHONPATH","IMREFLAGS","IMRE_ENCODED_FLAGS"):env.pop(k,None)
    f=d/(tag+".stdout");e=d/(tag+".stderr")
    assert not (d/(tag+".json")).exists()
    with f.open("wb") as out,e.open("wb") as err:
        p=subprocess.run(argv,cwd=wd,env=env,stdout=out,stderr=err,timeout=limit)
    result=dict(argv=argv,cwd=str(wd),start_epoch=start,elapsed_s=round(time.time()-start,5),exit=p.returncode,stdout_sha256=h(f),stderr_sha256=h(e),source_sha256=h(src),head=head)
    save(d/(tag+".json"),result)
    return p.returncode
assert h(src)==h(H/"release.py")
def lane(opt):
    name="reference" if stage=="stock" else "O"+str(opt); d=H/stage/name; wd=W/stage/name
    d.mkdir(parents=True,exist_ok=True);wd.mkdir(parents=True,exist_ok=True)
    if stage=="stock":
        assert subprocess.check_output([cpy,"--version"]).strip()==b"Python 3.14.5"
        argv=[cpy,"-B",src]
    else:
        b=Path("/workspace/scratch/cbwr-bin-"+stage)
        assert (b/"READY").read_text().strip()==head
        exe=wd/"probe"
        rc=capture(d,wd,[b/"imre","build",src,"--no-cache","--runtime",b/"libimre_runtime.a","--clang","/workspace/scratch/tools/clang","--opt-level",opt,"-o",exe],"build",1800 if stage in ("guarded","public") else 1200)
        if rc!=0:
            print(stage,name,"build",rc,flush=True); return
        argv=[exe]
    rc=capture(d,wd,argv,"process",70)
    print(stage,name,"exit",rc,(d/"process.stdout").read_text(),(d/"process.stderr").read_text().splitlines()[-1:],flush=True)
with ThreadPoolExecutor(2) as ex:list(ex.map(lane,[0] if stage=="stock" else [0,3]))
