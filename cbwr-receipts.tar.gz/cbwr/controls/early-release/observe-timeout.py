from pathlib import Path
import os,time,sys,json,signal,hashlib
h=Path('/workspace/shared/downloads/cbwr-reinit/controls/early-release/public/O3')
w=Path('/workspace/scratch/cbwr-controls/early-release/public/O3')
frozen=Path('/workspace/scratch/cbwr-bin-public')
def get(pid):
    return [x.decode() for x in (Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0') if x]
cmd=[str(frozen/'imre'),'build',str(w.parents[1]/'release.py'),'--no-cache','--runtime',str(frozen/'libimre_runtime.a'),'--clang','/workspace/scratch/tools/clang','--opt-level','3','-o',str(w/'probe')]
prs={}
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:xs=get(p.name);line=(p/'stat').read_text().split(') ',1)[1].split()
    except (OSError,ValueError):continue
    prs[int(p.name)]=(int(line[1]),xs,int(line[19]))
matches=[k for k,(_,a,_) in prs.items() if a==cmd]
if not matches:
    assert (h/'build.json').is_file()
    sys.exit(0)
assert len(matches)==1
root=matches[0];desc={root}
for _ in range(6):desc|={p for p,(pp,a,tick) in prs.items() if pp in desc}
assert [p for p in desc if p!=root and any(x.startswith(str(w)+'/') for x in prs[p][1])]
btime=int(next(x.split()[1] for x in Path('/proc/stat').read_text().splitlines() if x.startswith('btime ')))
start=btime+prs[root][2]/os.sysconf('SC_CLK_TCK')
while Path('/proc',str(root)).exists() and time.time()-start<1930:time.sleep(2)
while not (h/'build.json').exists() and time.time()-start<1808:time.sleep(1)
if (h/'build.json').exists():sys.exit(0)
assert time.time()-start>=1799 and not Path('/proc',str(root)).exists()
terminated=[]
for p in sorted(desc-{root},reverse=True):
    try:
        if get(p)!=prs[p][1]:continue
        assert any(x.startswith(str(w)+'/') for x in get(p))
        os.kill(p,signal.SIGKILL);terminated.append(p)
    except (FileNotFoundError,ProcessLookupError):pass
while any((Path('/proc',str(p),'cmdline').exists() and Path('/proc',str(p),'cmdline').read_bytes()) for p in terminated):time.sleep(.2)
def dig(p):return hashlib.sha256(p.read_bytes()).hexdigest()
doc=dict(argv=cmd,cwd=str(w),head=(frozen/'READY').read_text().strip(),timeout_s=1800,timed_out=True,exit=None,stdout_sha256=dig(h/'build.stdout'),stderr_sha256=dig(h/'build.stderr'),source='external observer of timed subprocess.run; original driver raises TimeoutExpired before saving build.json',imre_pid=root,imre_proc_start_epoch=start,observed_epoch=time.time(),clang_children_terminated_after_driver_timeout=terminated,observed_elapsed_s=round(time.time()-start,3))
(h/'build-timeout.json').write_text(json.dumps(doc,indent=2)+'\n');print(doc,flush=True)
