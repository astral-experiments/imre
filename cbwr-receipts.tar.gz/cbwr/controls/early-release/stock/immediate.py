import gc
import io
import weakref
from _io import BufferedWriter


class Raw(io.RawIOBase):
    def writable(self):
        return True
    def write(self, b):
        return len(b)


def old_writer():
    old = Raw()
    w = BufferedWriter(old, 8)
    w.write(b"drop")
    return w, weakref.ref(old)


class Replacing(Raw):
    def writable(self):
        gc.collect()
        assert self.previous() is self.writer.raw
        self.events.append("old during writable")
        return True

    def tell(self):
        # The old raw cannot stay reachable from the writer in this phase.
        assert self.writer.raw is self
        self.before_gc = self.previous() is None
        gc.collect()
        assert self.previous() is None
        self.events.append("released before tell")
        return 0


writer, old_ref = old_writer()
new = Replacing()
new.writer = writer
new.previous = old_ref
new.events = []
writer.__init__(new, 4)
assert new.events == ["old during writable", "released before tell"], new.events
assert new.before_gc
print("old weakref already dead on entry to tell")
writer.write(b"abc")
writer.close()
assert new.closed
print("old live during writable and gone during tell")
