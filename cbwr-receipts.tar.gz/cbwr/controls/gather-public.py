"""Preserve the low-priority public build receipts alongside independent successful retries."""
from pathlib import Path
import json, hashlib, subprocess, shutil, time, sys
H=Path('/workspace/shared/downloads/cbwr-reinit/controls')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def copy(p,d):
    assert not d.exists(),d
    shutil.copyfile(p,d)
    assert h(p)==h(d)
for fam,first in [('', 'build.json'),('early-release','build-timeout.json')]:
    area=H/fam
    lane=area/'public/O3';retry=area/'public-retry/O3'
    d=lane/'attempts/initial-build';d.mkdir(parents=True,exist_ok=True)
    f=read(lane/first)
    assert f['timed_out'] and f['exit'] is None
    for n in (first,'build.stdout','build.stderr'):
        copy(lane/n,d/n)
    assert all(h(d/('build.'+n))==f[n+'_sha256'] for n in ('stdout','stderr'))
    prov_file=retry.parent/'provenance.json';prov=read(prov_file)
    assert prov['first_receipt_sha256']==h(d/first)
    prov.update(first_receipt_at_retry_launch=prov['first_build_receipt'],first_build_receipt=str((d/first).relative_to(H)))
    save(prov_file,prov)
    if first=='build-timeout.json':
        (d/'driver-timeout.txt').write_text('Original driver terminal tail, recorded from the subprocess supervisor.\nsubprocess.TimeoutExpired: '+repr(f['argv'])+' timed out after 1799.9999866979997 seconds\n')
for fam,first in [('', 'build.json'),('early-release','build-timeout.json')]:
    a=H/fam
    lane=a/'public/O3';retry=a/'public-retry/O3';d=lane/'attempts/initial-build'
    completed=retry/'COMPLETE'
    while not completed.is_file():
        if (retry/'build.json').is_file():assert read(retry/'build.json')['exit']==0
        time.sleep(2)
    r=read(retry/'build.json');prov=read(retry.parent/'provenance.json')
    assert r['exit']==0 and not r['timed_out'] and r['argv'][0]=='/workspace/scratch/cbwr-bin-public/imre'
    assert r['head']==prov['imre']==completed.read_text().strip()
    assert [r['argv'][r['argv'].index(x)+1] for x in ('--opt-level','--runtime')]==['3','/workspace/scratch/cbwr-bin-public/libimre_runtime.a']
    assert r['source_sha256']==prov['source_sha256']
    ks=[''] if fam else ['files','wrong-bytes','invalid','weak','writable','tell']
    for k in ks:
        path=retry/k; tag='process' if fam else 'result';st=a/'stock/reference'/k
        q=read(path/(tag+'.json'));rr=read(st/(tag+'.json'))
        stdout='process.stdout' if fam else 'stdout';stderr='process.stderr' if fam else 'stderr'
        assert q['exit']==rr['exit'] and q['stdout_sha256']==h(path/stdout)==rr['stdout_sha256'] and q['stderr_sha256']==h(path/stderr) and (path/stderr).read_text().splitlines()[-1:]==(st/stderr).read_text().splitlines()[-1:]
        dest=lane/k;dest.mkdir(exist_ok=True)
        for name in (tag+'.json',stdout,stderr):copy(path/name,dest/name)
    for name in ('build.stdout','build.stderr','build.json','executable.sha256'):
        dest=lane/name
        if dest.exists():
            previous=d/name
            assert previous.is_file() and h(dest)==h(previous),(name,dest,previous)
            new=dest.with_suffix('.swap-'+dest.suffix[1:]);copy(retry/name,new);new.replace(dest)
        else:copy(retry/name,dest)
    summary=dict(optimizing_run='ordinary O3',public_head=r['head'],first_attempt=str((d/first).relative_to(H)),first_attempt_sha256=h(d/first),first_attempt_verdict='compile timed out after 1800s; zero native processes',retry_build=str((retry/'build.json').relative_to(H)),retry_build_sha256=h(retry/'build.json'),retry_provenance=str((retry.parent/'provenance.json').relative_to(H)),retry_provenance_sha256=h(retry.parent/'provenance.json'),retry_nice=prov['nice'],canonical_receipts='Measured compiler and subprocess receipts are byte-identical to the separately retained public-retry directory.')
    save(lane/'retry-provenance.json',summary)
    copy(completed,lane/'COMPLETE')
    print(fam or 'core','qualified public O3 via distinct retry',flush=True)
subprocess.run([sys.executable,str(H/'compare.py'),'public'],check=True)
