from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib, json, os, signal, subprocess, sys, time

H = Path(__file__).resolve().parent
W = Path("/workspace/scratch/cbwr-controls")
P = W / "probe.py"
cpy = Path("/workspace/scratch/cpytools/bin/python3.14")
clang = "/workspace/scratch/tools/clang"
stage, expected = sys.argv[1:3]
if stage=="public":
    os.nice(12)
selectors = ["files", "wrong-bytes", "invalid", "weak", "writable", "tell"]

def h(p):
    with p.open("rb") as s:
        return hashlib.file_digest(s, "sha256").hexdigest()

def dump(p,d):
    p.write_text(json.dumps(d, indent=2)+"\n")

def run(cmd,wd,d,tag,limit):
    assert not (d/(tag+".json")).exists(),d
    wd.mkdir(exist_ok=True, parents=True)
    d.mkdir(exist_ok=True, parents=True)
    out = d/("stdout" if tag=="result" else "build.stdout")
    err = d/("stderr" if tag=="result" else "build.stderr")
    start=time.time()
    env=os.environ.copy()
    for n in ("PYTHONPATH","IMREFLAGS","IMRE_ENCODED_FLAGS"):
        env.pop(n,None)
    env.update(PYTHONDONTWRITEBYTECODE="1",TMPDIR=str(wd))
    cmd=list(map(str,cmd))
    with out.open("wb") as f,err.open("wb") as e:
        p=subprocess.Popen(cmd,cwd=wd,env=env,stdout=f,stderr=e,start_new_session=True)
        try:
            rc=p.wait(timeout=limit)
            expired=False
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL)
            rc=p.wait()
            expired=True
    doc=dict(argv=cmd,cwd=str(wd),start_epoch=start,elapsed_s=round(time.time()-start,6),
             exit=None if expired else rc,reaped_status=rc,timed_out=expired,
             stdout_sha256=h(out),stderr_sha256=h(err))
    if tag=="result":
        doc["file_hex"]={name:(wd/name).read_bytes().hex() for name in ("old.bin","new.bin") if (wd/name).is_file()}
    dump(d/(tag+".json"),doc)
    return doc

assert h(P)==h(H/"probe.py")
(N:=H/stage).mkdir(exist_ok=True)
stock=stage=="stock"
if stock:
    assert subprocess.check_output([cpy,"--version"],text=True).strip()=="Python 3.14.5"
    prov=dict(cpython=expected,version="3.14.5",binary_sha256=h(cpy))
else:
    B=Path("/workspace/scratch/cbwr-bin-"+stage)
    ready=(B/"READY").read_text().strip()
    assert expected==ready
    prov=dict(imre=ready,compiler_sha256=h(B/"imre"),runtime_sha256=h(B/"libimre_runtime.a"))
prov["source_sha256"]=h(P)
dump(N/"provenance.json",prov)

def lane(opt):
    name="reference" if stock else "O"+str(opt)
    d=N/name
    wd=W/stage/name
    if stock:
        binargs=[cpy,"-B",P]
    else:
        exe=wd/"probe"
        build=run([B/"imre","build",P,"--no-cache","--runtime",B/"libimre_runtime.a","--clang",clang,"--opt-level",opt,"-o",exe],wd,d,"build",1800 if stage in ("guarded","public") else 900)
        if build["exit"]!=0:
            print(stage,name,"compile",build["exit"],flush=True)
            return
        (d/"executable.sha256").write_text(h(exe)+"\n")
        binargs=[exe]
    for sel in selectors:
        dd=d/sel
        rec=run([*binargs,sel],wd/sel,dd,"result",90)
        lines=(dd/"stderr").read_text(errors="replace").splitlines()
        err=lines[-1] if lines else ""
        so=(dd/"stdout").read_bytes()
        if stock:
            assert rec["exit"]==int(sel=="wrong-bytes") and (not err or ("AssertionError" in err and "abce" in err)),(sel,err)
        if sel in ("files","wrong-bytes") and (rec["exit"]==0 or "abce" in err):
            assert rec["file_hex"]=={"old.bin":"","new.bin":"61626364"}
        print(stage,name,sel,rec["exit"],so[:120],err[:200],flush=True)
    (d/"COMPLETE").write_text(expected+"\n")

with ThreadPoolExecutor(2) as ex:list(ex.map(lane,[0] if stock else [0,3]))
