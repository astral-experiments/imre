import gc
import io
import sys
import weakref
from _io import BufferedWriter


class Raw(io.RawIOBase):
    def __init__(self, tag):
        self.tag = tag
        self.chunks = []
        self.allow = True

    def writable(self):
        return self.allow

    def tell(self):
        return 0

    def write(self, data):
        self.chunks.append(bytes(data))
        return len(data)


def read_file(path):
    with io.FileIO(path, "r") as source:
        return source.read()


def file_control(wrong):
    assert io.BufferedWriter is BufferedWriter
    old = io.FileIO("old.bin", "w")
    new = io.FileIO("new.bin", "w")
    w = BufferedWriter(old, 16)
    assert w.write(b"drop") == 4
    start = io.BytesIO()
    assert w.__init__(start, buffer_size=12) is None
    assert w.raw is start and not old.closed and old.tell() == 0
    assert w.write(b"bytes") == 5
    raw = Raw("middle")
    assert BufferedWriter.__init__(w, raw, 10) is None
    assert start.getvalue() == b"" and not start.closed
    assert w.raw is raw
    w.write(b"drop")
    w.__init__(new, 9)
    assert not raw.closed and raw.chunks == []
    assert w.write(b"abc") == 3
    assert read_file("new.bin") == b""
    w.flush()
    assert read_file("new.bin") == b"abc"
    assert w.write(b"d") == 1
    w.close()
    assert new.closed and not old.closed
    assert read_file("old.bin") == b""
    observed = read_file("new.bin")
    expected = b"abce" if wrong else b"abcd"
    print("real file", observed)
    assert observed == expected, (observed, expected)
    old.close()
    start.close()
    raw.close()


def blocked(w):
    try:
        w.write(b"unreachable")
    except ValueError as exc:
        assert "uninitialized" in str(exc), str(exc)
    else:
        raise AssertionError("uninitialized write succeeded")


def invalid_control():
    old = Raw("old")
    new = Raw("replacement")
    denied = Raw("denied")
    denied.allow = False
    w = BufferedWriter(old, 16)
    w.write(b"keep")
    try:
        w.__init__(new, buffer_size="bad")
    except TypeError:
        pass
    else:
        raise AssertionError("string size accepted")
    assert w.raw is old and not w.closed
    w.flush()
    assert old.chunks == [b"keep"]
    w.write(b"discard")
    try:
        w.__init__(denied, 16)
    except io.UnsupportedOperation:
        pass
    else:
        raise AssertionError("unwritable raw accepted")
    assert w.raw is old
    blocked(w)
    for size in (0, -16, -1):
        try:
            w.__init__(new, buffer_size=size)
        except ValueError:
            pass
        else:
            raise AssertionError("nonpositive size accepted")
        assert w.raw is new
        blocked(w)
    w.__init__(new)
    assert w.write(b"after") == 5
    assert w.detach() is new
    assert new.chunks == [b"after"] and not new.closed
    w.__init__(old, 4)
    w.write(b"end")
    w.close()
    assert old.closed and old.chunks == [b"keep", b"end"]
    w.__init__(new, 4)
    assert not w.closed
    w.write(b"new")
    w.close()
    assert new.closed and new.chunks == [b"after", b"new"]
    assert not denied.closed
    print("invalid and recovered", old.chunks, new.chunks)

def make_writer():
    old = Raw("old")
    w = BufferedWriter(old, 9)
    w.write(b"discard")
    return w, weakref.ref(old)


def replace_owner(w):
    replacement = Raw("new")
    w.__init__(replacement, 4)
    return weakref.ref(replacement)


def weak_control():
    w, old_ref = make_writer()
    gc.collect()
    assert old_ref() is w.raw
    new_ref = replace_owner(w)
    gc.collect()
    assert old_ref() is None and new_ref() is w.raw
    w.write(b"abc")
    w.close()
    assert new_ref().closed and new_ref().chunks == [b"abc"]
    del w
    gc.collect()
    assert new_ref() is None
    print("released old and retained replacement")


class Watching(Raw):
    def writable(self):
        if self.tag == "outer":
            self.watch("writable")
        return True

    def tell(self):
        if self.tag == "outer":
            self.watch("tell")
        return 0

    def watch(self, method):
        if method == self.phase:
            self.seen.append(self.writer.raw.tag)
            blocked(self.writer)
            self.writer.__init__(self.inner, 3)
            self.seen.append(self.writer.raw.tag)


def nested_control(phase):
    old = Raw("old")
    outer = Watching("outer")
    inner = Raw("inner")
    w = BufferedWriter(old, 12)
    outer.phase = phase
    outer.writer = w
    outer.inner = inner
    outer.seen = []
    w.write(b"drop")
    w.__init__(outer, 4)
    w.write(b"new")
    w.flush()
    w.close()
    assert not old.closed and old.chunks == []
    if phase == "writable":
        assert outer.seen == ["old", "inner"]
        assert w.raw is outer and outer.closed and not inner.closed
        assert outer.chunks == [b"new"] and inner.chunks == []
    else:
        assert outer.seen == ["outer", "inner"]
        assert w.raw is inner and inner.closed and not outer.closed
        assert inner.chunks == [b"new"] and outer.chunks == []
    print(phase, outer.seen, w.raw.tag, outer.chunks, inner.chunks)


case = sys.argv[1]
if case == "files" or case == "wrong-bytes":
    file_control(case == "wrong-bytes")
elif case == "invalid":
    invalid_control()
elif case == "weak":
    weak_control()
elif case == "writable" or case == "tell":
    nested_control(case)
else:
    raise AssertionError(case)
