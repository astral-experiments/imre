"""If an original O3 compile timed out, rebuild only that public selector source at normal priority."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib, json, os, signal, subprocess, sys, time
H=Path('/workspace/shared/downloads/cbwr-reinit/controls')
W=Path('/workspace/scratch/cbwr-controls')
binary=Path('/workspace/scratch/cbwr-bin-public')
head=(binary/'READY').read_text().strip()
assert head=='0c9885cf2953271a30a7a40b7ac2f5a8bf4f76db'
family=sys.argv[1]
assert family in ('core','early-release')
rename='' if family=='core' else 'early-release'
evidence=H/rename
work=W/rename
srcname='probe.py' if family=='core' else 'release.py'
src=work/srcname
wd=work/'public-retry/O3'; d=evidence/'public-retry/O3'
orig=evidence/'public/O3'
def dig(p):
    with p.open("rb") as s:return hashlib.file_digest(s,'sha256').hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def cap(cmd,cwd,d,tag,limit):
    cmd=list(map(str,cmd))
    cwd.mkdir(exist_ok=True,parents=True); d.mkdir(exist_ok=True,parents=True)
    stdout=d/('stdout' if tag=='result' else tag+'.stdout');stderr=d/('stderr' if tag=='result' else tag+'.stderr')
    assert not (d/(tag+'.json')).exists()
    env=os.environ.copy(); env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE='1')
    for n in ('PYTHONPATH','IMREFLAGS','IMRE_ENCODED_FLAGS'):env.pop(n,None)
    st=time.time()
    with stdout.open('wb') as f,stderr.open('wb') as e:
        p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=e,start_new_session=True)
        try:status=p.wait(timeout=limit); expired=False
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL); status=p.wait(); expired=True
    obj=dict(argv=cmd,cwd=str(cwd),start_epoch=st,elapsed_s=round(time.time()-st,5),timed_out=expired,exit=None if expired else status,reaped_status=status,limit_s=limit,head=head,source_sha256=dig(src),stdout_sha256=dig(stdout),stderr_sha256=dig(stderr))
    if tag!='build':
        obj['file_hex']={n:(cwd/n).read_bytes().hex() for n in ('old.bin','new.bin') if (cwd/n).is_file()}
    save(d/(tag+'.json'),obj)
    return obj
if (orig/'build.json').exists():
    first=read(orig/'build.json');assert first['exit']!=0 and first['timed_out'],first
    initial=orig/'build.json'
else:
    initial=orig/'build-timeout.json'
    assert family=='early-release' and initial.is_file() and read(initial)['timed_out'], initial
assert dig(evidence/srcname)==dig(src)
wd.mkdir(exist_ok=True,parents=True); d.mkdir(exist_ok=True,parents=True)
assert not (d/'build.json').exists()
pro=read(H/'public/provenance.json')
assert pro['imre']==head and dig(binary/'imre')==pro['compiler_sha256'] and dig(binary/'libimre_runtime.a')==pro['runtime_sha256']
assert os.getpriority(os.PRIO_PROCESS,0)==0
save(d.parent/'provenance.json',dict(imre=head,compiler_sha256=pro['compiler_sha256'],runtime_sha256=pro['runtime_sha256'],source_sha256=dig(src),first_build_receipt=str(initial.relative_to(H)),first_receipt_sha256=dig(initial),nice=0))
exe=wd/'probe';args=[binary/'imre','build',src,'--no-cache','--runtime',binary/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','--opt-level','3','-o',exe]
build=cap(args,wd,d,'build',1800)
print(family,'retry build',build['exit'],flush=True)
assert build['exit']==0
(d/'executable.sha256').write_text(dig(exe)+'\n')
for name in (['files','wrong-bytes','invalid','weak','writable','tell'] if family=='core' else ['']):
    ref=evidence/'stock/reference'/name;tag='result' if name else 'process'
    st=read(ref/(tag+'.json'));rd=d/name
    r=cap([exe,name] if name else [exe],wd/name,rd,tag,90)
    errname='stderr' if name else 'process.stderr'
    assert r['exit']==st['exit'] and r['stdout_sha256']==st['stdout_sha256'] and r['file_hex']==st.get('file_hex',{}) and (ref/errname).read_text().splitlines()[-1:]==(rd/errname).read_text().splitlines()[-1:], (name,r,st)
    print(family,name,'retry native',r['exit'],flush=True)
(d/'COMPLETE').write_text(head+'\n')
