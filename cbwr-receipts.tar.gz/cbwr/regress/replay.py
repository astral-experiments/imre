from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,sys,time
from pathlib import Path
stage,root,head=sys.argv[1:]
repo=Path(root); out=Path(__file__).parent; binary=Path('/workspace/scratch/cbwr-bin-'+stage)
assert (binary/'READY').read_text().strip()==head
def hashfile(p): return sha256(p.read_bytes()).hexdigest()
fixture=repo/'tests/fixtures/io_buffered_writer_callbacks.py'
assert subprocess.check_output(['git','show','6f29a0da:tests/fixtures/io_buffered_writer_callbacks.py'],cwd=repo)==fixture.read_bytes()
cpy='/workspace/scratch/cpytools/bin/python3.14'
def lane(opt):
    folder=out/stage/f'O{opt}';folder.mkdir(parents=True,exist_ok=True)
    work=Path('/workspace/scratch/cbwr-regress/permanent')/stage/f'O{opt}';work.mkdir(parents=True,exist_ok=True)
    exe=work/'fixture'
    def call(label,argv):
        t=time.monotonic();event=dict(argv=list(map(str,argv)),cwd=str(work),utc=datetime.now(timezone.utc).isoformat(),timed_out=False)
        with (folder/(label+'.stdout')).open('wb') as stdout, (folder/(label+'.stderr')).open('wb') as stderr:
            try: event['exit']=subprocess.run(argv,cwd=work,stdout=stdout,stderr=stderr,timeout=1400).returncode
            except subprocess.TimeoutExpired: event.update(exit=None,timed_out=True)
        event.update(elapsed_s=round(time.monotonic()-t,3),stdout_sha256=hashfile(folder/(label+'.stdout')),stderr_sha256=hashfile(folder/(label+'.stderr')))
        (folder/(label+'.json')).write_text(json.dumps(event,indent=2)+'\n')
        return event
    check=call('cpython',[cpy,'-IB',fixture])
    build=call('build',[binary/'imre','build',fixture,'--no-cache','--opt-level',str(opt),'--runtime',binary/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','-o',exe])
    run=None;exehash=None
    if build['exit']==0:
        exehash=hashfile(exe);run=call('native',[exe]);exe.unlink()
    row=dict(head=head,fixture_sha256=hashfile(fixture),compiler_sha256=hashfile(binary/'imre'),runtime_sha256=hashfile(binary/'libimre_runtime.a'),exe_sha256=exehash,stock=check['exit'],build=build['exit'],native=run and run['exit'],matched_cpython=bool(run and (run['exit'],run['stdout_sha256'],run['stderr_sha256'])==(check['exit'],check['stdout_sha256'],check['stderr_sha256'])))
    (folder/'result.json').write_text(json.dumps(row,indent=2)+'\n')
    return row
with ThreadPoolExecutor(2) as pool:
    print(list(pool.map(lane,[0,3])),flush=True)
