"""Reconcile only raw method callbacks across explicitly keyed public heads and runtime profiles."""
import argparse, collections, csv, io, json
from pathlib import Path
from verify_prior import DOWNLOAD, PRIOR, RAW, ROOT, UPSTREAM, digest, rows

CLASS = ROOT.parent
LANE = CLASS.parent
FINAL = DOWNLOAD/"cbwc-final-d7beefe"
stages = ("base","tested","guarded","final","reparent","resolved","upstream","integrated","public")
STAGE = argparse.ArgumentParser()
STAGE.add_argument("stage",choices=("prior",*stages,"full","supplement"))
stage = STAGE.parse_args().stage
pinned = json.loads((ROOT/"prior.json").read_text())
assert pinned["prior_public"]==PRIOR
ids = rows(CLASS/"stock/registration.tsv")
assert ids==rows(FINAL/"registration.tsv") and len(ids)==43
index = {r["id"]:r for r in ids}
assert len(index)==43
cells = {i:{} for i in index}
refs = {}
headers = []
def write(path,data):
    blob = data.encode()
    if path.exists():
        assert path.read_bytes()==blob, path
    else:
        tmp=path.with_suffix(".part")
        tmp.write_bytes(blob)
        tmp.replace(path)
def tsv(header,data):
    f=io.StringIO(newline="")
    w=csv.writer(f,delimiter="\t",lineterminator="\n");w.writerow(header)
    w.writerows(data)
    return f.getvalue()
def key_for(head,profile,opt,root,path):
    item=(head,profile,str(opt),str(path))
    if item not in refs:
        proc=json.loads(path.read_bytes())
        stream=path.with_name("callbacks.stdout")
        assert digest(stream)==(proc.get("stdout_sha256") or proc["callbacks_sha256"])
        refs[item]=(
            "r"+str(len(refs)+1),head,profile,opt,
            path.relative_to(root).as_posix(),digest(path),stream.relative_to(root).as_posix(),
            digest(stream),proc["exit"],int(proc.get("timed_out",False)))
    return refs[item][0]
def put(prefix,ident,verdict,head,profile,opt,root,path):
    assert ident in index and prefix not in cells[ident]
    if prefix not in headers: headers.append(prefix)
    stream=path.with_name("callbacks.stdout")
    tags=[a[0] for line in stream.read_text().splitlines() if len(a:=line.split("\t",2))==3 and a[1]==ident]
    assert "REGISTER" in tags and "START" in tags
    if verdict=="INTERRUPTED":
        assert "STOP" not in tags
        proc=json.loads(path.read_bytes())
        assert proc["timed_out"] or proc["exit"]!=0
    else:
        assert verdict in ("PASS","SKIP","FAIL","ERROR") and "STOP" in tags and (verdict in tags or "SUB"+verdict in tags),(ident,tags,verdict)
        assert tags.index("START")<tags.index("STOP")
    cells[ident][prefix]=(verdict,key_for(head,profile,opt,root,path))
assert digest(CLASS/"stock/callbacks.stdout")==digest(FINAL/"stock-callbacks.stdout")
for r in ids:put("stock",r["id"],"PASS",UPSTREAM,"stock-cpython","",LANE,CLASS/"stock/process.json")
for r in rows(RAW/"class/public/ledger.tsv"):
    i=r["id"];opt=r["ordinary_opt"];path=RAW/"class"/r["raw_receipt"];assert digest(path)==r["raw_receipt_sha256"]
    assert (index[i]["ordinal_in_667"],index[i]["occurrence"])==(r["ordinal_in_667"],r["occurrence"])
    put("prior_dev_O"+opt,i,r["native_verdict"],PRIOR,"signed-prior-default",opt,RAW,path)
for r in rows(RAW/"class/supplement/public-opt-runtime.tsv"):
    i=r["id"];opt=r["ordinary_opt"];path=RAW/"class/supplement"/r["raw_receipt"];assert digest(path)==r["raw_receipt_sha256"]
    assert (index[i]["ordinal_in_667"],index[i]["occurrence"])==(r["ordinal_in_667"],r["occurrence"])
    put("prior_opt2_O"+opt,i,r["native_verdict"],PRIOR,"signed-prior-opt2",opt,RAW,path)
heads={}
omitted={}
for s in stages[:("prior",*stages,"full","supplement").index(stage)]:
    d=CLASS/"fast"/s
    if s not in ("base","tested","public") and s!=stage:
        if not (d/"results.tsv").is_file():
            omitted[s]="no sealed per-level result rows"
            continue
        complete=rows(d/"results.tsv")
        if len(complete)!=6:
            omitted[s]=f"{len(complete)} sealed target/adjacent rows of six"
            continue
    head=json.loads((d/"provenance.json").read_bytes())["commit"];heads[s]=head
    res=rows(d/"results.tsv");assert len(res)==6 and {r["imre_or_cpython"] for r in res}=={head}
    for r in res:
        ident=r["canonical_id"]; opt=r["lane"]; group="adjacent" if ident.endswith(".test_uninitialized") else "targets"
        assert (index[ident]["ordinal_in_667"],index[ident]["occurrence"])==(r["ordinal_in_667"],r["occurrence"])
        path=d/opt/group/"process.json"
        assert digest(path)==r["process_receipt_sha256"] and digest(path.with_name("callbacks.stdout"))==r["raw_stream_sha256"]
        put(s+"_"+opt,ident,r["callback"],head,f"fresh-{s}-targeted-default",opt,LANE,path)
if stage in ("full","supplement"):
    other=CLASS/"attribution/upstream/results.tsv"
    if other.exists():
        attribution=rows(other)
        assert len(attribution)==2
        for r in attribution:
            i=r["canonical_id"]; opt=r["lane"];path=other.parent/opt/"case/process.json"
            assert i=="test.test_io.CBufferedWriterTest.test_error_through_destructor" and (index[i]["ordinal_in_667"],index[i]["occurrence"])==(r["ordinal_in_667"],r["occurrence"])
            assert r["imre_or_cpython"]==heads["upstream"] and digest(path)==r["process_receipt_sha256"]
            assert digest(path.with_name("callbacks.stdout"))==r["raw_stream_sha256"]
            put("upstream_background_"+opt,i,r["callback"],heads["upstream"],"fresh-parent-attribution-default",opt,LANE,path)
    for family in (["default"] if stage=="full" else ["default","opt2"]):
        f=ROOT/"full"/family
        prov=json.loads((f/"provenance.json").read_bytes())
        assert prov["commit"]==heads["public"]
        rr=rows(f/"ledger.tsv")
        assert len(rr)==(86 if family=="default" else 10)
        for r in rr:
            i=r["id"]; o=r["opt"]; path=f/r["process_path"]
            assert digest(path)==r["process_sha256"]
            put("public_full_"+family+"_O"+o,i,r["verdict"],heads["public"],"fresh-public-"+family,o,LANE,path)
def paired(prefix):
    return {i for i,d in cells.items() if all(d.get(prefix+o,("",))[0]=="PASS" for o in ("0","3"))}
prior_a=paired("prior_dev_O");prior_b=paired("prior_opt2_O")
prior_all=prior_a|prior_b
assert len(prior_a)==26 and len(prior_b)==4 and len(prior_all)==30
confirmed={i for i in index if "public_O0" in cells[i] and "public_O3" in cells[i]}
latest=(paired("public_full_default_O")|paired("public_full_opt2_O")) if stage in ("full","supplement") else paired("public_O")
if stage in ("full","supplement"):
    measured={i for i,d in cells.items() if all(d.get("public_full_default_O"+o,("",))[0] not in ("","INTERRUPTED") for o in ("0","3"))}
else:measured=confirmed
historic=sorted(prior_all-measured)
counts={h:dict(collections.Counter(d[h][0] for d in cells.values() if h in d)) for h in headers}
info=dict(stage=stage,cpython=UPSTREAM,prior_public=PRIOR,current_heads=heads,counts=counts,
    prior_default_paired_pass=26,prior_opt2_additional_paired_pass=4,prior_union_count=30,
    current_public_paired_pass_ids=sorted(latest),prior_paired_pass_ids_without_current_terminal_default_callback=historic,
    public_paired_gains_vs_prior_paired=sorted(latest-prior_all),
    cross_head_cumulative_witnessed_paired_pass_ids=sorted(prior_all|latest),
    scope="Blank means no run for that profile and commit. Prior and cumulative columns retain their original heads. Stock is the original test_io load_tests selection of this class only. Other I/O families are outside this replay.")
if stage in ("public","full","supplement"):
    info["optional_stages_without_complete_pair"]=omitted
    squash=ROOT/"public-squash-build.json"
    if squash.is_file():
        failure=json.loads(squash.read_bytes())
        assert failure["cargo"]["exit"]!=0 and failure["native_callbacks"]==0
        info["squash_build_failure"]=dict(commit=failure["public_squash"],cargo_exit=failure["cargo"]["exit"],native_callbacks=0,receipt="class/reconcile/public-squash-build.json",receipt_sha256=digest(squash))
    target_ids={i for i in index if i.endswith((".test_constructor",".test_initialization"))}
    assert len(target_ids)==2
    before={i for i in target_ids if all(cells[i]["base_O"+o][0] in ("ERROR","FAIL") for o in ("0","3"))}
    isolated=before & paired("tested_O")
    if "final" in heads:isolated &= paired("final_O")
    if "reparent" in heads:isolated &= {i for i in target_ids if all(cells[i]["reparent_O"+o][0] in ("ERROR","FAIL") for o in ("0","3"))}
    if "resolved" in heads:isolated &= paired("resolved_O")
    if "upstream" in heads:isolated &= {i for i in target_ids if all(cells[i]["upstream_O"+o][0] in ("ERROR","FAIL") for o in ("0","3"))}
    if "integrated" in heads:isolated &= paired("integrated_O")
    info["targeted_parent_to_public_paired_gains"]=sorted(latest & isolated)
    others=latest-prior_all-isolated
    confirmed_parent=paired("upstream_background_O")
    info["other_public_gains_observed_passing_on_reproducing_parent"]=sorted(others&confirmed_parent)
    info["other_public_gains_vs_prior_with_origin_unassigned"]=sorted(others-confirmed_parent)
if stage in ("full","supplement"):
    info["fresh_targeted_vs_complete_differences"]={
        i:{o:{"targeted":d["public_O"+o][0],"complete":d["public_full_default_O"+o][0]}
           for o in ("0","3") if d["public_O"+o][0]!=d["public_full_default_O"+o][0]}
        for i,d in cells.items() if "public_O0" in d and any(d["public_O"+o][0]!=d["public_full_default_O"+o][0] for o in ("0","3"))
    }
    info["fresh_default_paired_pass"]=len(paired("public_full_default_O"))
    if stage=="supplement":
        info["fresh_opt2_additional_paired_pass"]=len(paired("public_full_opt2_O")-paired("public_full_default_O"))
hdr=["ordinal_in_667","occurrence","canonical_id"]
for h in headers:hdr.extend((h,h+"_raw"))
data=[]
for r in ids:
    row=[r["ordinal_in_667"],r["occurrence"],r["id"]]
    for h in headers:row.extend(cells[r["id"]].get(h,("","")))
    data.append(row)
write(ROOT/f"paired-{stage}.tsv",tsv(hdr,data))
write(ROOT/f"raw-{stage}.tsv",tsv(("key","head","profile","opt","process","process_sha256","callbacks","callbacks_sha256","process_exit","timed_out"),refs.values()))
info["paired_sha256"]=digest(ROOT/f"paired-{stage}.tsv");info["raw_sha256"]=digest(ROOT/f"raw-{stage}.tsv")
write(ROOT/f"summary-{stage}.json",json.dumps(info,indent=2)+"\n")
print(stage,info["paired_sha256"],counts)
