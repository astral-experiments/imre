from pathlib import Path
from hashlib import sha256
import csv, json, subprocess, sys

ROOT = Path(__file__).resolve().parent
DOWNLOAD = ROOT.parents[2]
UPSTREAM = "5607950ef232dad16d75c0cf53101d9649d89115"
PRIOR = "d7beefe0352e3cd83a6d4a1642357b499dcd4eee"
PINS = {
    "primary": ("final", "24f0785a1bd0825c76bee95e6f592cdf9dea2931", "originals.tsv",
                "196e7b8a7df217e481f6e74eba8dc0e88589309e77d4389d9da6077ca44cd71f",
                "c3594e8dd2354e83c6b84675b75b5616e46421c9bf22b2aa9b15e813f35059ae",
                "153e91b453fb7f0447988884373add0d4029e9d3d9f9546ac87af3d9fdc0cf53", 2181),
    "supplemental": ("supplement", "de4b1e83e6d1a366825e43407e8f1277bb7b5174", "supplement.tsv",
                "f8bc33df880d1970ef5d62b18e9b111bba0ffb2f4f84e9d45df9f6f7c81d6862",
                "1a8e1dba062ffc832589d391f5a86b6a281c525da8719d3c20d21351d1798c45",
                "bd4f0f71980a0581a5c35986e3683c26c23f0f3e0c188ad150910022062ca1a4", 90),
}
RAW = DOWNLOAD / "cbuffered-writer-class"
def digest(p):
    return sha256(p.read_bytes()).hexdigest()
def rows(p):
    with p.open() as f:
        return list(csv.DictReader(f, delimiter="\t"))
def verify():
    result = dict(cpython=UPSTREAM, prior_public=PRIOR, prior={})
    for name, (label, commit, table, pin, archive_hash, table_hash, count) in PINS.items():
        d=DOWNLOAD/f"cbwc-{label}-d7beefe"
        archive=d/"cbwc-receipts.tar.gz"
        assert digest(archive)==archive_hash and digest(d/table)==table_hash
        key=subprocess.check_output(["openssl","pkey","-pubin","-in","signer-ed25519.pem","-outform","DER"],cwd=d)
        assert sha256(key).hexdigest()==pin
        subprocess.run(["openssl","pkeyutl","-verify","-pubin","-inkey","signer-ed25519.pem","-rawin","-in","SHA256SUMS","-sigfile","SHA256SUMS.sig"],cwd=d,check=True,capture_output=True)
        manifest = {line.split("  ",1)[1]:line.split("  ",1)[0] for line in (d/"SHA256SUMS").read_text().splitlines()}
        assert len(manifest)==count and manifest[table]==table_hash and manifest["tools/verify-cbwc.py"]==digest(d/"verify-cbwc.py")
        check=subprocess.run([sys.executable,"-B",str(d/"verify-cbwc.py"),str(archive),"--pin",pin],capture_output=True,check=True,text=True)
        assert f"Verified {count} payloads" in check.stdout
        if name=="primary":
            for path in ("raw-index.tsv","stock-callbacks.stdout","registration.tsv"):
                assert digest(d/path)==manifest[path]
            for row in rows(d/"raw-index.tsv"):
                for what in ("receipt","stdout","stderr"):
                    p=row[f"archive_{what}"]
                    assert digest(RAW/p)==row[f"{what}_sha256"]==manifest[p]
            extra="class/public/ledger.tsv"
        else:
            extra="class/supplement/public-opt-runtime.tsv"
            for row in rows(RAW/extra):
                p=RAW/"class/supplement"/row["raw_receipt"]
                assert digest(p)==manifest[p.relative_to(RAW).as_posix()]==row["raw_receipt_sha256"]
                assert digest(p.with_name("callbacks.stdout"))==json.loads(p.read_bytes())["stdout_sha256"]
        assert digest(RAW/extra)==manifest[extra]
        result["prior"][name]=dict(public_receipt_commit=commit, archive_sha256=archive_hash, pinned_spki_sha256=pin, original_table=table, original_table_sha256=table_hash, verified_payloads=count, native_ledger=extra, native_ledger_sha256=manifest[extra], verification=check.stdout.strip())
    (ROOT/"prior.json").write_text(json.dumps(result,indent=2)+"\n")
if __name__=="__main__":verify()
