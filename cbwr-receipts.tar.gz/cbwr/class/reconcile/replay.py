"""Replay the signed class projection or five separately optimized originals at one public SHA."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import ast, collections, csv, hashlib, json, os, signal, subprocess, sys, time

from verify_prior import DOWNLOAD, RAW, ROOT, digest, rows

WORK = Path("/workspace/scratch/cbwr-class/full")
SOURCE = WORK/"inputs"
REG = rows(ROOT.parent/"stock/registration.tsv")
IDS = [r["id"] for r in REG]
STRESS = [r["id"] for r in REG if r["id"].split(".")[-1] in ("test_writes","test_writes_and_flushes","test_writes_and_seeks","test_writes_and_truncates")]
THREAD = "test.test_io.CBufferedWriterTest.test_threads"
SLOW = "test.test_io.CBufferedWriterTest.test_slow_close_from_thread"
assert len(IDS)==43 and len(STRESS)==4 and SLOW in IDS and THREAD in IDS
family=sys.argv[1]
assert family in ("default","opt2")
public=Path("/workspace/scratch/cbwr-bin-public")
bins=public if family=="default" else Path("/workspace/scratch/cbwr-bin-public-opt-runtime")
D=ROOT/"full"/family
D.mkdir(parents=True,exist_ok=True)
def big_hash(file):
    with file.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def write(p,data):
    if p.exists():assert p.read_bytes()==data,p
    else:
        t=p.with_suffix(p.suffix+".part");t.write_bytes(data);t.replace(p)
def save(p,d):write(p,(json.dumps(d,indent=2)+"\n").encode())

# Preserve the same Python inputs and ordinary opt flags as their respective signed prior runs.
profiles = {
    "class": (SOURCE/"class", RAW/"class/projection.json", "b43b26205ccd857b74a6e2028fae69dc98972370577b5487623a04fa220b4698", IDS),
    "stress": (SOURCE/"stress", RAW/"class/supplement/stress/sources.json", "d85fbd8700adb0a67d25e0d28e914ee7f63aa4607d2e706e2ce7d35380da5a94", STRESS),
    "thread": (SOURCE/"thread", RAW/"class/supplement/thread/sources.json", "d4c2a7227a82fb3d0a9a3fc7d8b24ee210c25d44d7843b2358fcf68cf260d06b", [THREAD]),
}
used=["class"] if family=="default" else ["stress","thread"]
for projection in used:
    mod,meta,sha,ids=profiles[projection]
    assert digest(meta)==sha and all(digest(mod/p)==expected for p,expected in json.loads(meta.read_bytes())["inputs"].items())
head=(public/"READY").read_text().strip()
assert head==(bins/"READY").read_text().strip()
assert len(head)==40 and json.loads((ROOT.parent/"fast/public/provenance.json").read_bytes())["commit"]==head
compiler=public/"imre"
runtime=bins/"libimre_runtime.a"
rh=big_hash(runtime)
data=dict(commit=head,profile=family,compiler=str(compiler),compiler_sha256=big_hash(compiler),runtime=str(runtime),runtime_sha256=rh,
          clang="/workspace/scratch/tools/clang",projections={p:profiles[p][2] for p in used})
if family=="opt2":
    assert big_hash(bins/"imre")==data["compiler_sha256"] and big_hash(public/"libimre_runtime.a")!=rh
save(D/"provenance.json",data)

def execute(args,work,out,tag,limit):
    out.mkdir(parents=True,exist_ok=True);work.mkdir(parents=True,exist_ok=True)
    cmd=list(map(str,args));path=out/(tag+".json")
    stdout=out/("callbacks.stdout" if tag=="process" else "build.stdout")
    stderr=out/(tag+".stderr")
    if path.exists():
        rec=json.loads(path.read_bytes())
        assert rec["argv"]==cmd and rec["cwd"]==str(work) and rec["commit"]==head and rec["profile"]==family
        assert digest(stdout)==rec["stdout_sha256"] and digest(stderr)==rec["stderr_sha256"]
        return rec
    assert not (stdout.exists() and stdout.stat().st_size), "unfinished previous attempt"
    env=os.environ.copy()
    for n in ("PYTHONPATH","IMREFLAGS","IMRE_ENCODED_FLAGS"):env.pop(n,None)
    env.update(TMPDIR=str(work),PYTHONDONTWRITEBYTECODE="1")
    t=time.monotonic()
    stamp=datetime.now(timezone.utc).isoformat()
    with stdout.open("wb") as f,stderr.open("wb") as e:
        p=subprocess.Popen(cmd,cwd=work,env=env,stdout=f,stderr=e,start_new_session=True)
        try:status=p.wait(timeout=limit);timed=False
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);status=p.wait();timed=True
    rec=dict(commit=head,profile=family,provenance_sha256=digest(D/"provenance.json"),argv=cmd,cwd=str(work),utc=stamp,elapsed_s=round(time.monotonic()-t,6),limit_s=limit,exit=None if timed else status,reaped_status=status,timed_out=timed,stdout=stdout.name,stdout_sha256=digest(stdout),stderr=stderr.name,stderr_sha256=digest(stderr))
    save(path,rec);print(out.relative_to(D),tag,rec["exit"],rec["timed_out"],rec["elapsed_s"],flush=True);return rec

def groups(projection):
    if projection=="class":
        main=[i for i in IDS if i not in STRESS+[THREAD,SLOW]]
        return [("main",main,1500),("slow-close",[SLOW],370),("threads",[THREAD],500),*[(i.rsplit(".",1)[1],[i],800) for i in STRESS]]
    return [(i.rsplit(".",1)[1],[i],2600 if i.endswith(".test_writes_and_seeks") else 1800) for i in profiles[projection][3]]

def retry_prestart(d,w,exe,targets,limit,opt,projection):
    prev=json.loads((d/"process.json").read_text())
    assert len(targets)==1 and prev["argv"]==[str(exe),*targets] and prev["timed_out"]
    assert not any(line.startswith("START\t"+targets[0]+"\t") for line in (d/"callbacks.stdout").read_text().splitlines())
    out=d/"registration-retry";work=w/"registration-retry"
    retried=execute([exe,*targets],work,out,"process",max(1800,limit+900))
    return out,retried

if len(sys.argv)>2:
    assert sys.argv[2]=="--recover-prestart"
    proj,opt,group=sys.argv[3:];opt=int(opt)
    w=WORK/family/proj/f"O{opt}";d=D/proj/f"O{opt}";exe=w/"suite"
    name,targets,limit=next(g for g in groups(proj) if g[0]==group)
    assert big_hash(exe)==(d/"program.sha256").read_text().strip()
    retry_prestart(d/name,w/name,exe,targets,limit,opt,proj)
    sys.exit(0)

def lane(key):
    proj,opt=key;sel=profiles[proj][3];mod=profiles[proj][0]
    w=WORK/family/proj/f"O{opt}";d=D/proj/f"O{opt}";exe=w/"suite";w.mkdir(exist_ok=True,parents=True)
    cfg=groups(proj);assert sorted(i for _,g,_ in cfg for i in g)==sorted(sel)
    build=execute([compiler,"build",mod/"run.py","--module-root",mod,"--no-cache","--runtime",runtime,"--clang","/workspace/scratch/tools/clang","--opt-level",opt,"-o",exe],w,d,"build",3600)
    if build["exit"]!=0:raise RuntimeError(f"{proj} O{opt} build exit {build['exit']}, timeout={build['timed_out']} at {d}, no native outcomes")
    write(d/"program.sha256",(big_hash(exe)+"\n").encode())
    def run(group):
        name,targets,t=group
        work=w/name;out=d/name;rec=execute([exe,*targets],work,out,"process",t)
        if len(targets)==1 and rec["timed_out"] and not any(line.startswith("START\t"+targets[0]+"\t") for line in (out/"callbacks.stdout").read_text().splitlines()):
            out,rec=retry_prestart(out,work,exe,targets,t,opt,proj)
        lines=[line.split("\t",2) for line in (out/"callbacks.stdout").read_text(errors="replace").splitlines()]
        events=[p for p in lines if len(p)==3]
        assert {p[1] for p in events if p[0]=="REGISTER"}==set(sel),(proj,opt,name,"registration")
        started=[p[1] for p in events if p[0]=="START"]
        if len(targets)>1 and set(started)!=set(targets):
            # The original group can time out or encounter a process failure. Attempt every unreached selector.
            left=[i for i in targets if i not in started]
            if not started:raise RuntimeError(f"program did not start {name} at {out}")
            retry=run((name+"-remaining",left,t))
        else:retry=[]
        result=[]
        for i in started:
            ordered=[kind for kind,ident,value in events if ident==i]
            assert ordered.count("START")==1 and ordered.count("STOP")<=1 and i in targets
            observed=[kind for kind in ordered if kind in ("PASS","ERROR","SKIP","FAIL","SUBERROR","SUBFAIL")]
            if "STOP" not in ordered:
                assert rec["timed_out"] or rec["exit"]!=0
                verdict="INTERRUPTED"
            else:
                assert observed and ordered[-1] in ("STOP","DETAIL"),ordered
                verdict=next(v for v in ("ERROR","FAIL","SKIP","PASS") if v in observed or "SUB"+v in observed)
                if verdict=="PASS":assert observed==["PASS"]
            file=out/"process.json"
            result.append(dict(opt=opt,id=i,occurrence=1,verdict=verdict,projection=proj,process_path=str(file.relative_to(D)),process_sha256=digest(file),stream_sha256=rec["stdout_sha256"],build_exit=build["exit"],process_exit=rec["exit"],timed_out=int(rec["timed_out"])))
        return result+retry
    with ThreadPoolExecutor(max_workers=3 if family=="default" else 2) as pool:results=[r for chunk in pool.map(run,cfg) for r in chunk]
    assert set(r["id"] for r in results)==set(sel) and len(results)==len(sel)
    return results

jobs=[(k,opt) for k in used for opt in (0,3)]
with ThreadPoolExecutor(max_workers=len(jobs)) as ex:
    results=[r for chunk in ex.map(lane,jobs) for r in chunk]
results.sort(key=lambda r:(r["opt"],IDS.index(r["id"])))
footer=D/"ledger.tsv"
import io
buf=io.StringIO(newline="");f=csv.DictWriter(buf,fieldnames=list(results[0]),delimiter="\t",lineterminator="\n");f.writeheader();f.writerows(results)
write(footer,buf.getvalue().encode())
outcomes={o:dict(collections.Counter(r["verdict"] for r in results if r["opt"]==o)) for o in (0,3)}
save(D/"summary.json",dict(commit=head,family=family,outcomes=outcomes,ledger_sha256=digest(footer)))
print("SEALED",family,head,outcomes,digest(footer),flush=True)
