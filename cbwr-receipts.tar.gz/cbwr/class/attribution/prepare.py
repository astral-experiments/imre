from pathlib import Path
import ast,hashlib,json,shutil
H=Path(__file__).resolve().parent;W=Path('/workspace/scratch/cbwr-class/attribution/module')
P=Path('/workspace/scratch/cpython/Lib/test/test_io.py');S=P.parent/'support/__init__.py'
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(P.read_bytes())=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
proof={}
def stagepath(src,target):
    lines=src.read_text().splitlines(keepends=True);stage=['\n']*len(lines);tree=ast.parse(src.read_bytes())
    def keep(name,a,b):
        stage[a-1:b]=lines[a-1:b];proof[target+'/'+name]={'first_line':a,'last_line':b,'sha256':sha(''.join(lines[a-1:b]).encode())}
    return lines,stage,tree,keep
lines,stage,tree,keep=stagepath(P,'test_io')
mro={'CommonBufferedTests','SizeofTest','BufferedWriterTest','CBufferedWriterTest'}
for x in tree.body:
    if isinstance(x,ast.Import) and x.names[0].name in ('io','unittest'):keep('import/'+x.names[0].name,x.lineno,x.end_lineno)
    if isinstance(x,ast.ImportFrom) and x.module=='test' and x.names[0].name=='support':keep('from test import support',x.lineno,x.end_lineno)
    if isinstance(x,ast.ClassDef) and x.name in ('MockRawIOWithoutRead','MockRawIO','CMockRawIO','CloseFailureIO','CCloseFailureIO'):keep(x.name,x.lineno,x.end_lineno)
    if isinstance(x,ast.ClassDef) and x.name in mro:
        keep(x.name,x.lineno,x.lineno);members=0
        for m in x.body:
            if isinstance(m,ast.Assign) or getattr(m,'name','') in ('test_error_through_destructor','setUp','tearDown','setUpClass','tearDownClass'):
                assert not getattr(m,'decorator_list',[])
                keep(x.name+'.'+str(getattr(m,'name',m.lineno)),m.lineno,m.end_lineno);members+=1
        if not members:stage[x.lineno]='    pass\n'
stage += ['\ndef load_tests(loader, tests, pattern):\n','    CBufferedWriterTest.MockRawIO = CMockRawIO\n','    CBufferedWriterTest.CloseFailureIO = CCloseFailureIO\n','    CBufferedWriterTest.is_C = True\n','    return unittest.TestSuite([loader.loadTestsFromTestCase(CBufferedWriterTest)])\n']
(W/'test/test_io.py').write_text(''.join(stage));shutil.copyfile(P.parent/'__init__.py',W/'test/__init__.py')
lines,stage,tree,keep=stagepath(S,'test.support')
for x in tree.body:
    if isinstance(x,ast.ClassDef) and x.name=='catch_unraisable_exception':keep(x.name,x.lineno,x.end_lineno)
    if isinstance(x,ast.Import) and x.names[0].name=='sys':keep('import sys',x.lineno,x.end_lineno)
assert 'test.support/import sys' in proof
(W/'test/support/__init__.py').write_text(''.join(stage))
runner=(H.parent/'runner.py').read_text().replace('assert cls.MockRawIO is test_io.CMockRawIO and cls.is_C','assert cls.MockRawIO is test_io.CMockRawIO and cls.CloseFailureIO is test_io.CCloseFailureIO and cls.is_C')
(W/'run.py').write_text(runner)
(H/'sources.json').write_text(json.dumps(dict(upstream={'test_io':sha(P.read_bytes()),'test.support':sha(S.read_bytes())},retained=proof,inputs={str(f.relative_to(W)):sha(f.read_bytes()) for f in sorted(W.rglob('*.py'))}),indent=2)+'\n')
