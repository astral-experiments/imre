"""Run original unittest cases with a durable stream of real result callbacks."""
import io
import _io
import os
import sys
import unittest
from test import test_io

def emit(tag, case, detail=""):
    # Write each event immediately, even if a later method terminates the process.
    line = tag + "\t" + case + "\t" + repr(detail) + "\n"
    os.write(1, line.encode("utf-8", "backslashreplace"))

class Recording(unittest.TestResult):
    def startTest(self, test):
        emit("START", test.id())
        super().startTest(test)
    def stopTest(self, test):
        emit("STOP", test.id())
        super().stopTest(test)
    def addSuccess(self, test):
        emit("PASS", test.id())
        super().addSuccess(test)
    def addError(self, test, error):
        emit("ERROR", test.id(), error[0].__name__ + ": " + str(error[1]))
        super().addError(test, error)
    def addFailure(self, test, error):
        emit("FAIL", test.id(), error[0].__name__ + ": " + str(error[1]))
        super().addFailure(test, error)
    def addSkip(self, test, reason):
        emit("SKIP", test.id(), reason)
        super().addSkip(test, reason)
    def addSubTest(self, test, subtest, error):
        if error is not None:
            status = "SUBFAIL" if issubclass(error[0], test.failureException) else "SUBERROR"
            emit(status, test.id(), str(subtest) + " " + error[0].__name__ + ": " + str(error[1]))
        super().addSubTest(test, subtest, error)

loader = unittest.TestLoader()
suite = test_io.load_tests(loader, None, None)
cls = test_io.CBufferedWriterTest
assert cls.tp is io.BufferedWriter and cls.tp is _io.BufferedWriter
assert cls.MockRawIO is test_io.CMockRawIO and cls.is_C
emit("FIXTURE", cls.__module__ + "." + cls.__qualname__, "io and _io writer identity; CMockRawIO")
selected = unittest.TestSuite()
count = 0
for group in suite:
    for item in group:
        count += 1
        if type(item) is cls:
            emit("REGISTER", item.id(), count)
            if len(sys.argv) == 1 or item.id() in sys.argv[1:]:
                selected.addTest(item)
emit("DENOMINATOR", "", count)
result = Recording()
selected.run(result)
for item, trace in result.errors + result.failures:
    emit("DETAIL", item.id(), trace)
emit("END", "", result.testsRun)
if not result.wasSuccessful():
    sys.exit(1)
