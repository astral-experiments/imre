"""Verify inherited lifecycle, source bytes, skip markers and public fixture identity across the pinned stock loads."""
import hashlib, inspect, json, os, subprocess, sys, unittest
from pathlib import Path
H=Path(__file__).resolve().parent
if len(sys.argv)>1:
    import io, _io
    from test import test_io as mod
    suite=unittest.TestLoader().loadTestsFromModule(mod);c=mod.CBufferedWriterTest
    originals={}
    names=('test_constructor','test_initialization','test_uninitialized','setUp','tearDown','setUpClass','tearDownClass')
    for n in names:
        f=getattr(c,n)
        owner=next(x for x in c.__mro__ if n in vars(x))
        src=inspect.getsource(f).encode();code=inspect.unwrap(f).__code__
        originals[n]=dict(owner=owner.__module__+'.'+owner.__qualname__,source_sha256=hashlib.sha256(src).hexdigest(),code_sha256=hashlib.sha256(code.co_code).hexdigest(),first_line=code.co_firstlineno,skip=getattr(f,'__unittest_skip__',False),skip_reason=getattr(f,'__unittest_skip_why__',None))
    assert c.tp is io.BufferedWriter is _io.BufferedWriter
    assert c.MockRawIO is mod.CMockRawIO and c.is_C
    print(json.dumps(dict(originals=originals,mro=[x.__module__+'.'+x.__qualname__ for x in c.__mro__],module_setup=hasattr(mod,'setUpModule'),module_teardown=hasattr(mod,'tearDownModule'),io_writer_identity=True,real_c_mock=True,cpy=sys.version.split()[0])))
else:
    exe='/workspace/scratch/cpytools/bin/python3.14'
    pr='/workspace/scratch/cbwr-class/fast/module'
    py='/workspace/scratch/cpython/Lib'
    runs={}
    for name,p in [('intact',py),('focused',pr+':'+py)]:
        env=os.environ|dict(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=p)
        r=subprocess.run([exe,'-B',str(Path(__file__).resolve()),'case'],env=env,capture_output=True,check=True)
        runs[name]=json.loads(r.stdout)
    assert runs['intact']==runs['focused']
    (H/'stock-fidelity.json').write_text(json.dumps(runs['focused'],indent=2)+'\n')
    print('Stock fidelity verified',hashlib.sha256((H/'stock-fidelity.json').read_bytes()).hexdigest())
