"""Drive exact original constructor methods through stock and ordinary native unittest callbacks."""
import argparse, ast, concurrent.futures, csv, datetime, fcntl, hashlib, json, os, signal, subprocess, time
from pathlib import Path
H=Path(__file__).resolve().parent
W=Path('/workspace/scratch/cbwr-class/fast')
M=W/'module'
stock=Path('/workspace/scratch/cpytools/bin/python3.14')
def hash_file(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p, data):
    t=p.with_suffix('.new');t.write_text(json.dumps(data,indent=2)+'\n');t.replace(p)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
a=argparse.ArgumentParser();a.add_argument('stage');a.add_argument('commit');a.add_argument('bindir',type=Path);a.add_argument('--wait',action='store_true');args=a.parse_args()
binary=args.bindir
stage=args.stage
if stage!='stock':
    if args.wait:
        while not (binary/'READY').exists():time.sleep(2)
    commit=(binary/'READY').read_text().strip()
    assert commit==args.commit or args.commit=='@ready'
else:
    commit='5607950ef232dad16d75c0cf53101d9649d89115'
    assert commit==args.commit
D=H/stage;D.mkdir(exist_ok=True)
guard=(W/(stage+'.lock')).open('a');fcntl.flock(guard,fcntl.LOCK_EX)
smanifest=H/'sources.json'
inputs=json.loads(smanifest.read_text())
for n,h in inputs['inputs'].items():assert hash_file(M/n)==h
prov=dict(stage=stage,commit=commit,sources_sha256=hash_file(smanifest),run_script_sha256=hash_file(__file__))
if stage=='stock':prov.update(stock=str(stock),stock_sha256=hash_file(stock))
else:prov.update(compiler=str(binary/'imre'),runtime=str(binary/'libimre_runtime.a'),compiler_sha256=hash_file(binary/'imre'),runtime_sha256=hash_file(binary/'libimre_runtime.a'))
if (D/'provenance.json').exists():assert json.loads((D/'provenance.json').read_text())==prov
else:save(D/'provenance.json',prov)
pfx='test.test_io.CBufferedWriterTest.'
groups={'targets':[pfx+'test_constructor',pfx+'test_initialization'],'adjacent':[pfx+'test_uninitialized']}
registration={r['id']:r for r in csv.DictReader((H.parent/'stock'/'registration.tsv').open(),delimiter='\t')}
all_ids=[i for ids in groups.values() for i in ids]
assert all(i in registration and registration[i]['occurrence']=='1' for i in all_ids)
def record(cwd, out, cmd, tag, timeout):
    cmd=[str(n) for n in cmd]; meta=out/(tag+'.json')
    if meta.exists():
        saved=json.loads(meta.read_text());assert saved['argv']==cmd and saved['cwd']==str(cwd) and saved['commit']==commit
        assert saved['stdout_sha256']==hash_file(out/saved['stdout']) and saved['stderr_sha256']==hash_file(out/saved['stderr'])
        return saved
    env=os.environ.copy()
    for key in ('PYTHONPATH','IMREFLAGS','IMRE_ENCODED_FLAGS'):env.pop(key,None)
    env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE='1')
    o=out/('callbacks.stdout' if tag=='process' else 'build.stdout'); e=out/(tag+'.stderr')
    start=utc();t=time.monotonic()
    with o.open('wb') as fo,e.open('wb') as fe:
        child=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=fo,stderr=fe,start_new_session=True)
        try:rc=child.wait(timeout=timeout);timed=False
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);rc=child.wait();timed=True
    receipt=dict(stage=stage,commit=commit,argv=cmd,cwd=str(cwd),utc=start,elapsed_s=round(time.monotonic()-t,5),provenance_sha256=hash_file(D/'provenance.json'),source_manifest_sha256=hash_file(smanifest),exit=None if timed else rc,timed_out=timed,reaped_status=rc,stdout=o.name,stdout_sha256=hash_file(o),stderr=e.name,stderr_sha256=hash_file(e))
    save(meta,receipt);print(stage,out.relative_to(H),tag,receipt['exit'],receipt['elapsed_s'],flush=True);return receipt
def lane(opt):
    lane='reference' if stage=='stock' else f'O{opt}';out=D/lane;cwd=W/stage/lane;cwd.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
    if stage=='stock':
        cmd=[stock,'-B',M/'run.py']
    else:
        exe=cwd/'originals'
        # A fixture-only head may have byte-identical compiler, runtime, and input files.
        # Link its unchanged executable to a fresh directory; every case actually runs here.
        witness=H/'tested'/lane
        prior=json.loads((H/'tested'/'provenance.json').read_text())
        prior_build=json.loads((witness/'build.json').read_text())
        if all(prior[key]==prov[key] for key in ('compiler_sha256','runtime_sha256','sources_sha256')):
            src=W/'tested'/lane/'originals'
            target_exec_hash=(witness/'program.sha256').read_text().strip()
            assert hash_file(src)==target_exec_hash
            assert prior_build['exit']==0 and not prior_build['timed_out']
            assert prior_build['commit']==prior['commit'] and prior_build['provenance_sha256']==hash_file(H/'tested'/'provenance.json')
            argv=prior_build['argv']; assert argv[-4:]==['--opt-level',str(opt),'-o',str(src)]
            assert argv[2]==str(M/'run.py') and prior_build['source_manifest_sha256']==hash_file(smanifest)
            assert hash_file(Path(argv[0]))==prov['compiler_sha256'] and hash_file(Path(argv[argv.index('--runtime')+1]))==prov['runtime_sha256']
            if not exe.exists():os.link(src,exe)
            assert hash_file(exe)==target_exec_hash
            save(out/'build-reference.json',dict(stage=stage,commit=commit,opt=opt,invocation='reused byte-identical compiler, static runtime, three input files and previously linked executable; fresh test subprocesses on final fixture-only head',referenced_stage='tested',referenced_commit=prior['commit'],referenced_build=str(witness/'build.json'),referenced_build_sha256=hash_file(witness/'build.json'),referenced_build_exit=prior_build['exit'],referenced_build_argv=argv,referenced_build_elapsed_s=prior_build['elapsed_s'],referenced_program=str(src),executable=str(exe),program_sha256=target_exec_hash,provenance_sha256=hash_file(D/'provenance.json'),compiler_sha256=prov['compiler_sha256'],runtime_sha256=prov['runtime_sha256'],source_manifest_sha256=prov['sources_sha256'],source_files_sha256=inputs['inputs']))
        else:
            r=record(cwd,out,[binary/'imre','build',M/'run.py','--module-root',M,'--no-cache','--runtime',binary/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','--opt-level',opt,'-o',exe],'build',1800)
            if r['exit']!=0:return []
        exe_sha=hash_file(exe)
        if (out/'program.sha256').exists():assert (out/'program.sha256').read_text().strip()==exe_sha
        else:(out/'program.sha256').write_text(exe_sha+'\n')
        cmd=[exe]
    rows=[]
    for name,ids in groups.items():
        where=cwd/name;dest=out/name;where.mkdir(exist_ok=True);dest.mkdir(exist_ok=True)
        r=record(where,dest,cmd+ids,'process',300)
        cb=(dest/'callbacks.stdout').read_text().splitlines();events=[s.split('\t',2) for s in cb]
        assert [x[1] for x in events if x[0]=='REGISTER']==sorted(all_ids)
        assert [x[1] for x in events if x[0]=='START']==ids and [x[1] for x in events if x[0]=='STOP']==ids and len([x for x in events if x[0]=='END' and x[2]==str(len(ids))])==1
        for i in ids:
            pat=[x for x in events if x[1]==i and x[0] in ('PASS','FAIL','ERROR','SKIP')]
            assert len(pat)==1
            reg=registration[i];v,id,detail=pat[0];rows.append([stage,commit,lane,reg['ordinal_in_667'],reg['occurrence'],i,v,ast.literal_eval(detail),r['exit'],r['stdout_sha256'],hash_file(dest/'process.json')])
            print(stage,lane,id,v,detail,flush=True)
    return rows
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:rows=[row for ls in ex.map(lane,([0] if stage=='stock' else (0,3))) for row in ls]
output=D/'results.tsv'
with output.open('w') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['stage','imre_or_cpython','lane','ordinal_in_667','occurrence','canonical_id','callback','detail','process_exit','raw_stream_sha256','process_receipt_sha256']);w.writerows(rows)
