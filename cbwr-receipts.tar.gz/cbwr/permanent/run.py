from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime,timezone
from hashlib import file_digest
import json,sys,subprocess,time
stage,worktree,src_ref=sys.argv[1:]
root=Path('/workspace/shared/downloads/cbwr-reinit/permanent')
work=Path('/workspace/scratch/cbwr-permanent')/stage
repo=Path(worktree); bins=Path('/workspace/scratch/cbwr-bin-'+stage)
while not (bins/'READY').exists():time.sleep(2)
head=(bins/'READY').read_text().strip()
src=Path('/workspace/scratch/cbwr-tested/tests/fixtures/io_buffered_writer_reinitialize.py') if stage=='base' else repo/'tests/fixtures/io_buffered_writer_reinitialize.py'
rel='tests/fixtures/'+src.name
assert src.read_bytes()==subprocess.check_output(['git','show',src_ref+':'+rel],cwd=repo)
assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
def h(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def lane(level):
    w=work/f'O{level}';d=root/stage/f'O{level}';w.mkdir(parents=True,exist_ok=True);d.mkdir(parents=True,exist_ok=True)
    def run(cmd,tag):
        cmd=list(map(str,cmd));start=datetime.now(timezone.utc).isoformat();t=time.monotonic()
        with (d/(tag+'.stdout')).open('wb') as so,(d/(tag+'.stderr')).open('wb') as se:
            try:rc=subprocess.run(cmd,cwd=w,stdout=so,stderr=se,timeout=1400).returncode;to=False
            except subprocess.TimeoutExpired:rc=None;to=True
        obj=dict(argv=cmd,utc=start,cwd=str(w),elapsed_s=round(time.monotonic()-t,5),exit=rc,timed_out=to,stdout_sha256=h(d/(tag+'.stdout')),stderr_sha256=h(d/(tag+'.stderr')))
        (d/(tag+'.json')).write_text(json.dumps(obj,indent=2)+'\n');return rc
    exe=w/'probe'
    rc=run([bins/'imre','build',src,'--no-cache','--opt-level',level,'--runtime',bins/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','-o',exe],'build')
    native={};stock={};files={}
    for mode,extra in [('normal',[]),('wrong-bytes',['--invert'])]:
        for kind,cmd in [('stock',['/workspace/scratch/cpytools/bin/python3.14','-IB',src]),('native',[exe])]:
            if kind=='native' and rc!=0:continue
            path=w/(kind+'-'+mode+'.bin')
            if path.exists():path.unlink()
            status=run([*cmd,path,*extra],kind+'-'+mode)
            (stock if kind=='stock' else native)[mode]=status
            files[kind+'-'+mode]=path.read_bytes().hex() if path.exists() else None
    out=dict(head=head,fixture_sha256=h(src),compiler_sha256=h(bins/'imre'),runtime_sha256=h(bins/'libimre_runtime.a'),exe_sha256=h(exe) if rc==0 else None,build_exit=rc,stock=stock,native=native,file_hex=files)
    (d/'result.json').write_text(json.dumps(out,indent=2)+'\n');print(stage,level,out,flush=True)
    if exe.exists():exe.unlink()
with ThreadPoolExecutor(2) as ex:list(ex.map(lane,(0,3)))
