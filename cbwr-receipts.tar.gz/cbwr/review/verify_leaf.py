from pathlib import Path
import json,csv,hashlib,subprocess
R=Path('/workspace/shared/downloads/cbwr-reinit')
B='aa1c3a37ed8624318a63c5790d24264803526677'; T='18b0d5b672718985c2e1f2cfad9f32033172c943'; F='55b01ff2fa1d4699581bcf9c1c47f362ffd4696f';repo=Path('/workspace/scratch/cbwr-final')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(fname): return json.loads((R/fname).read_bytes())
def t(fname):return list(csv.DictReader((R/fname).open(),delimiter='\t'))
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
assert not git('status','--porcelain')
assert git('rev-parse','HEAD').decode().strip()==F and git('rev-parse',T+'^').decode().strip()==B
assert git('diff','--name-only',T,F).decode().splitlines()==['tests/fixtures/io_buffered_writer_reinitialize.py']
p=git('diff','--binary',B,F)
assert (R/'review/guarded.patch').read_bytes()==p
out={}
for phase,head in [('base',B),('final',F)]:
    prov=j('build/'+phase+'-provenance.json')
    assert prov['commit']==head
    rows=t('class/fast/'+phase+'/results.tsv'); assert len(rows)==6
    checks=t('controls/'+phase+'/summary.tsv');assert len(checks)==12
    summary={}
    for o in ('0','3'):
        methods={r['ordinal_in_667']:r for r in rows if r['lane']=='O'+o}
        assert set(methods)=={'175','185','201'}
        for n,method,expected in [('175','test_constructor','ERROR'),('185','test_initialization','FAIL'),('201','test_uninitialized','ERROR')]:
            r=methods[n];actual=expected if phase=='base' or n=='201' else 'PASS'
            assert r['canonical_id']=='test.test_io.CBufferedWriterTest.'+method and r['occurrence']=='1' and r['callback']==actual and r['imre_or_cpython']==head
            key='adjacent' if n=='201' else 'targets'
            path=R/'class/fast'/phase/('O'+o)/key
            assert h(path/'callbacks.stdout')==r['raw_stream_sha256'] and h(path/'process.json')==r['process_receipt_sha256']
            assert 'STOP\t'+r['canonical_id'] in (path/'callbacks.stdout').read_text()
        f=j(f'permanent/qualified/{phase}/O{o}/result.json')
        assert f['fixture_commit']==F and f['head']==head and f['build_exit']==0 and f['compiler_sha256']==prov['binaries']['imre'] and f['runtime_sha256']==prov['binaries']['libimre_runtime.a']
        assert f['stock']=={'normal':0,'wrong-bytes':1} and f['native']=={'normal':int(phase=='base'),'wrong-bytes':1}
        er=R/f'permanent/qualified/{phase}/O{o}'
        if phase=='base':
            assert all('BufferedWriter reinitialization is unsupported' in (er/('native-'+mode+'.stderr')).read_text() for mode in ('normal','wrong-bytes'))
        else:
            assert 'AssertionError: b\'a\'' in (er/'native-wrong-bytes.stderr').read_text()
            assert f['file_hex']=={'stock-normal':'6162','stock-wrong-bytes':'61','native-normal':'6162','native-wrong-bytes':'61'}
        core=[r for r in checks if r['opt']==o]
        assert len(core)==6 and all(r['head']==head and r['matched']==str(phase=='final') for r in core)
        for r in core:assert h(R/'controls'/r['native_receipt'])==r['native_receipt_sha256']
        summary[o]=dict(originals={i:r['callback'] for i,r in methods.items()},fixture=f['native'],targets_sha256=methods['175']['raw_stream_sha256'],controls_sha256=h(R/f'controls/{phase}/summary.tsv'))
    out[phase]=summary
assert j('build/tested-provenance.json')['binaries']==j('build/final-provenance.json')['binaries']
for o in ('0','3'):
    for mode,expected in [('sole',b'trace True False False\n'),('held',b'trace True True True\n')]:
        d=R/'review/root/tested'/('O'+o)
        assert (d/(mode+'.stdout')).read_bytes()==expected and json.loads((d/(mode+'.json')).read_bytes())['exit']==0
out.update(parent=B,tested_head=F,commit_patch_sha256=h(R/'review/guarded.patch'),independent_review_sha256=h(R/'review/independent/final-source-review.json'))
(R/'review/qualification.json').write_text(json.dumps(out,indent=2)+'\n')
print('Leaf qualified',F,h(R/'review/qualification.json'))
