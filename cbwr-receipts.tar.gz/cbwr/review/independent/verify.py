from pathlib import Path
import json, hashlib
r=Path(__file__).resolve().parent
s={'originals':0,'extra_callback_probes':{},'sole_file_owner':{},'source_sha256':{f:hashlib.sha256((r/f).read_bytes()).hexdigest() for f in ['callback_order.py','sole_raw.py']}}
for case in ('writable_true','writable_false','tell','tell_index'):
    ref=r/'stock/reference'/case
    for opt in ('O0','O3'):
        for label in ('base','tested'):
            d=r/label/opt
            prov=json.loads((d/'provenance.json').read_bytes())
            assert json.loads((d/'build.json').read_bytes())['exit']==0
            rc=json.loads((d/case/'process.json').read_bytes())['exit']
            stdout=(d/case/'process.stdout').read_bytes()
            stderr=(d/case/'process.stderr').read_bytes()
            assert hashlib.sha256(stdout).hexdigest()==json.loads((d/case/'process.json').read_bytes())['stdout_sha256']
            matches=rc==0 and stdout==(ref/'process.stdout').read_bytes() and stderr==(ref/'process.stderr').read_bytes()
            s['extra_callback_probes'][f'{label}-{opt}-{case}']={'head':prov['head'],'exit':rc,'matches_stock':matches,'out':stdout.decode().strip(),'err':stderr.decode().splitlines()[-1:] if not matches else ''}
for opt in ('O0','O3'):
    d=r/'sole/tested'/opt;ref=r/'sole/stock/reference/file'
    rc=json.loads((d/'file/process.json').read_bytes())['exit']
    stdout=(d/'file/process.stdout').read_bytes()
    s['sole_file_owner'][opt]=dict(exit=rc,matches_stock=rc==0 and stdout==(ref/'process.stdout').read_bytes(),out=stdout.decode().strip())
(r/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
print(s['sole_file_owner'],sum(v['matches_stock'] for k,v in s['extra_callback_probes'].items() if k.startswith('tested')),flush=True)
