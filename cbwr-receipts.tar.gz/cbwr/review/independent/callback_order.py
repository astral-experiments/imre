import _io
import io
import sys

phase = sys.argv[1]
events = []


class Position:
    def __index__(self):
        events.append("index")
        nested()
        return 0


class Raw(io.RawIOBase):
    def __init__(self, tag):
        self.tag = tag
        self.sent = b""

    def writable(self):
        if self.tag == "outer" and phase in ("writable_true", "writable_false"):
            events.append("writable")
            nested()
            return phase == "writable_true"
        return True

    def tell(self):
        if self.tag == "outer":
            if phase == "tell":
                events.append("tell")
                nested()
            if phase == "tell_index":
                return Position()
        return 0

    def write(self, view):
        self.sent += bytes(view)
        return len(view)


def nested():
    writer.__init__(inner, 8)
    writer.write(b"x")
    events.append(writer.raw.tag)


old = Raw("old")
outer = Raw("outer")
inner = Raw("inner")
writer = _io.BufferedWriter(old, 8)
writer.write(b"a")
try:
    writer.__init__(outer, 8)
except OSError as exc:
    print(type(exc).__name__, str(exc))
writer.write(b"y")
writer.flush()
print(phase, events, writer.raw.tag, old.sent, outer.sent, inner.sent)
writer.close()
