import _io
import gc
import os
import sys


def main():
    w = _io.BufferedWriter(_io.FileIO(sys.argv[1], 'w+b'), 8)
    fd = w.fileno()
    w.write(b'lost')
    w.__init__(_io.BytesIO(), 8)
    try:
        os.write(fd, b'x')
    except OSError as exc:
        print('immediate-replacement-errno', exc.errno)
    else:
        print('immediate-replacement-write-succeeded')
    gc.collect()
    try:
        os.write(fd, b'y')
    except OSError as exc:
        print('after-collection-errno', exc.errno)
    else:
        print('after-collection-write-succeeded')
    w.close()
    with _io.FileIO(sys.argv[1], 'rb') as f:
        print('observed-file', f.read())

main()
