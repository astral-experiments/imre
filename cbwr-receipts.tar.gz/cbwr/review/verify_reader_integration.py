from pathlib import Path
import csv,json,hashlib,subprocess
R=Path('/workspace/shared/downloads/cbwr-reinit')
base='e3ff3e595bcd5dc0a92048b18e49885d77fb0ee4'
head='8e36c4a58c01425b23692657aa0489b58ed83c5a'
repo=Path('/workspace/scratch/cbwr-integrated')
def read(p):return json.loads((R/p).read_bytes())
def rows(p):return list(csv.DictReader((R/p).open(),delimiter='\t'))
def h(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
assert git('rev-parse','HEAD^2').decode().strip()==base and git('rev-parse','HEAD').decode().strip()==head
assert not git('status','--porcelain') and not git('diff','--check',base,head)
assert git('diff','--binary',base,head)==(R/'review/integrated.patch').read_bytes()
review=read('review/independent/reader-integration-review.json')
assert review['approved_head']==head and review['actual_main']==base and review['all_callback_active_lines_identical_to_main'] and review['normalized_hunk_checks']==7
out={'reproducing_parent':base,'head':head,'diff_sha256':h('review/integrated.patch'),'independent_review_sha256':h('review/independent/reader-integration-review.json'),'prior_qualification_sha256':h('review/qualification.json'),'stages':{}}
for phase,sha in [('upstream',base),('integrated',head)]:
    prov=read('build/'+phase+'-provenance.json');assert prov['commit']==sha
    st='class/fast/'+phase;ds=rows(st+'/results.tsv');assert len(ds)==6
    for o in ('0','3'):
        lane='O'+o
        for n,k,want in [(175,'test_constructor','ERROR'),(185,'test_initialization','FAIL'),(201,'test_uninitialized','ERROR')]:
            name='test.test_io.CBufferedWriterTest.'+k
            sel=[r for r in ds if r['lane']==lane and r['canonical_id']==name];assert len(sel)==1
            r=sel[0];expected='PASS' if n!=201 and phase=='integrated' else want
            assert (r['ordinal_in_667'],r['occurrence'],r['imre_or_cpython'],r['callback'])==(str(n),'1',sha,expected)
            s=st+'/'+lane+('/adjacent' if n==201 else '/targets')
            rec=read(s+'/process.json');data=(R/(s+'/callbacks.stdout')).read_text()
            assert h(s+'/callbacks.stdout')==rec['stdout_sha256']==r['raw_stream_sha256'] and h(s+'/process.json')==r['process_receipt_sha256']
            assert all(i+'\t'+name+'\t' in data for i in ('START',expected,'STOP'))
        p=f'permanent/qualified/{phase}/{lane}';fx=read(p+'/result.json')
        assert fx['head']==sha and fx['fixture_commit']==head and fx['build_exit']==0
        assert (fx['compiler_sha256'],fx['runtime_sha256'])==(prov['binaries']['imre'],prov['binaries']['libimre_runtime.a'])
        assert fx['native']=={'normal':int(phase=='upstream'),'wrong-bytes':1} and fx['stock']=={'normal':0,'wrong-bytes':1}
        if phase=='integrated':
            assert (fx['file_hex']['native-normal'],fx['file_hex']['native-wrong-bytes'])==('6162','61')
            assert "AssertionError: b'a'" in (R/(p+'/native-wrong-bytes.stderr')).read_text()
        else:
            assert 'BufferedWriter reinitialization is unsupported' in (R/(p+'/native-normal.stderr')).read_text()
    out['stages'][phase]={'keyed_callbacks_sha256':h(st+'/results.tsv'),'permanent_O0_sha256':h(f'permanent/qualified/{phase}/O0/result.json'),'permanent_O3_sha256':h(f'permanent/qualified/{phase}/O3/result.json')}
c=rows('controls/integrated/summary.tsv')
assert len(c)==12 and all(r['matched']=='True' and r['head']==head and h('controls/'+r['native_receipt'])==r['native_receipt_sha256'] for r in c)
for o in ('0','3'):
    assert set(r['case'] for r in c if r['opt']==o)=={'files','wrong-bytes','invalid','weak','writable','tell'}
out['integrated_controls_sha256']=h('controls/integrated/summary.tsv')
(R/'review/reader-integration-qualification.json').write_text(json.dumps(out,indent=2)+'\n')
print('Verified integration',head,h('review/reader-integration-qualification.json'))
