import os
import sys
import io
from _io import BufferedWriter

def live(fd):
    try:
        os.write(fd, b'')
    except OSError as exc:
        assert exc.errno == 9, exc
        return False
    return True

class Incoming(io.RawIOBase):
    def writable(self):
        self.before = live(self.fd)
        return True

    def tell(self):
        self.after = live(self.fd)
        return 0

w = BufferedWriter(io.FileIO('retired.bin', 'w'), 8)
w.write(b'lost')
replacement = Incoming()
replacement.fd = w.fileno()
if 'held' in sys.argv:
    held = w.raw
w.__init__(replacement, 9)
print('trace', replacement.before, replacement.after, live(replacement.fd))
assert replacement.before and replacement.after == ('held' in sys.argv)
assert live(replacement.fd) == ('held' in sys.argv)
w.close()
if 'held' in sys.argv:
    assert not held.closed
    held.close()
with io.FileIO('retired.bin', 'r') as reader:
    assert reader.read() == b''
