import concurrent.futures,sys,json,subprocess,hashlib,time
from pathlib import Path
stage=sys.argv[1];root=Path(__file__).resolve().parent
bins=Path('/workspace/scratch/cbwr-bin-'+stage);work=Path('/workspace/scratch/cbwr-root')/stage
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def lane(o):
    d=root/stage/o;w=work/o;d.mkdir(parents=True,exist_ok=True);w.mkdir(parents=True,exist_ok=True)
    def do(k,c):
        t=time.time();c=list(map(str,c));so=d/(k+'.stdout');se=d/(k+'.stderr')
        with so.open('wb') as a,se.open('wb') as b:
            try:rc=subprocess.run(c,cwd=w,stdout=a,stderr=b,timeout=1200).returncode;expired=False
            except subprocess.TimeoutExpired:rc=None;expired=True
        (d/(k+'.json')).write_text(json.dumps(dict(argv=c,cwd=str(w),start_epoch=t,elapsed_s=round(time.time()-t,4),exit=rc,timed_out=expired,stdout_sha256=h(so),stderr_sha256=h(se)),indent=2)+'\n')
        return rc
    src=root/'replace_order.py';pg=w/'probe'
    if stage=='stock':cmd=['/workspace/scratch/cpytools/bin/python3.14','-IB',src]
    else:
        sha=(bins/'READY').read_text().strip()
        (d/'sources.json').write_text(json.dumps(dict(commit=sha,source_sha256=h(src),compiler_sha256=h(bins/'imre'),runtime_sha256=h(bins/'libimre_runtime.a')))+'\n')
        if do('build',[bins/'imre','build',src,'--no-cache','--opt-level',o[1:],'--runtime',bins/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','-o',pg])!=0:return
        cmd=[pg]
    for k in ('sole','held'):
        rc=do(k,cmd+([k] if k=='held' else []));print(stage,o,k,rc,(d/(k+'.stdout')).read_text().strip(),flush=True)
    pg.unlink(missing_ok=True)
with concurrent.futures.ThreadPoolExecutor(2) as pool:list(pool.map(lane,('reference',) if stage=='stock' else ('O0','O3')))
