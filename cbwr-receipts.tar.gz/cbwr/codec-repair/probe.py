import codecs
import sys

expected = b"wrong" if "--invert" in sys.argv else b"abc"

def decode(view, errors="strict"):
    print("provider", type(view).__name__, view.obj, view.readonly, bytes(view))
    assert isinstance(view, memoryview) and view.obj is None and view.readonly
    assert bytes(view) == expected, "wrong provider bytes"
    try:
        view[0] = 120
    except TypeError as exc:
        assert str(exc) == "cannot modify read-only memory", str(exc)
    else:
        raise AssertionError("provider view accepted mutation")
    return "decoded", len(view)

def search(name):
    if name == "private_view":
        return codecs.CodecInfo(name=name, encode=None, decode=decode)

codecs.register(search)
data = bytearray(b"abc") if "--mutable-source" in sys.argv else b"abc"
assert data.decode("private-view") == "decoded"
print("decoder returned")
