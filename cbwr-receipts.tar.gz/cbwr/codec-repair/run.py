from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import time, os, subprocess, hashlib, json, signal, sys
r=Path(__file__).resolve().parent;w=Path('/workspace/scratch/cbwr-codec-check')
repo=Path('/workspace/scratch/cbwr-dep'); cp=Path('/workspace/scratch/cpytools/bin/python3.14')
mode=sys.argv[1]; bins=Path('/workspace/scratch/cbwr-bin-dependency')
def digest(p):
    with p.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def put(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def run(c,d,b,timeout):
    d.mkdir(exist_ok=True,parents=True);b.mkdir(exist_ok=True,parents=True);c=list(map(str,c))
    env=os.environ|dict(TMPDIR=str(b),PYTHONDONTWRITEBYTECODE='1');t=time.monotonic()
    with (d/'stdout').open('wb') as o,(d/'stderr').open('wb') as e:
        p=subprocess.Popen(c,cwd=b,stdout=o,stderr=e,env=env,start_new_session=True)
        try:rc=p.wait(timeout);expired=False
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait();expired=True
    rec=dict(argv=c,cwd=str(b),elapsed=round(time.monotonic()-t,3),timed_out=expired,exit=None if expired else rc,stdout_sha256=digest(d/'stdout'),stderr_sha256=digest(d/'stderr'))
    put(d/'result.json',rec)
    print(str(d.relative_to(r)),rec['exit'],flush=True)
    return rec['exit']
def lane(item):
    src,kind,lvl=item;d=r/mode/kind/src.stem/(lvl or 'reference');b=w/mode/kind/src.stem/(lvl or 'reference')
    if mode=='stock':cmd=[cp,'-IB',src]
    else:
        assert (bins/'READY').read_text().strip()=='03bea799c3e587e03f02728bdd9b367402e08f91'
        exe=b/'test'; cmd=[bins/'imre','build',src,'--no-cache','--runtime',bins/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','--opt-level',lvl[-1],'-o',exe]
        if kind=='boxed':cmd+=['--runtime-imports']
        if run(cmd,d/'build',b,900)!=0:return
        put(d/'source.json',dict(head=(bins/'READY').read_text().strip(),src=digest(src),exe=digest(exe),imre=digest(bins/'imre'),runtime=digest(bins/'libimre_runtime.a')))
        cmd=[exe]
    choices={'normal':[],'mutable':['--mutable-source'],'wrong':['--invert']} if src.stem=='probe' else {'normal':[]}
    for k,a in choices.items():run([*cmd,*a],d/k,b,60)
pro=r/'probe.py';fixture=repo/'tests/fixtures/boxed_codec_registry.py'
cases=[(pro,'reference',''),(fixture,'reference','')] if mode=='stock' else [(src,kind,o) for o in ('O0','O3') for src,kind in [(pro,'ordinary'),(fixture,'boxed')]]
with ThreadPoolExecutor(4) as ex:list(ex.map(lane,cases))
