from pathlib import Path
from hashlib import sha256
import json, subprocess, sys
r=Path(__file__).resolve().parent;n=r/'dependency';stock=r/'stock/reference'
head='03bea799c3e587e03f02728bdd9b367402e08f91';base='a3d6f19ff9727a835ca3cd4c19bd438d845a1814'
def get(d):
    b=(d/'result.json').read_bytes();j=json.loads(b)
    for f in ('stdout','stderr'):assert sha256((d/f).read_bytes()).hexdigest()==j[f+'_sha256']
    assert not j['timed_out']
    return j,sha256(b).hexdigest()
rows=[]
for opt in ('O0','O3'):
    for kind,name in (('ordinary','probe'),('boxed','boxed_codec_registry')):
        d=n/kind/name/opt
        j,_=get(d/'build');assert j['exit']==0
        src=json.loads((d/'source.json').read_bytes());assert src['head']==head
        for sel in (('normal','mutable','wrong') if kind=='ordinary' else ('normal',)):
            jj,rh=get(d/sel);s=stock/name/'reference'/sel;sj,_=get(s)
            expected=int(sel=='wrong')
            assert jj['exit']==sj['exit']==expected and (d/sel/'stdout').read_bytes()==(s/'stdout').read_bytes()
            err=(d/sel/'stderr').read_bytes();referr=(s/'stderr').read_bytes()
            assert (b'AssertionError: wrong provider bytes' in err and b'AssertionError: wrong provider bytes' in referr) if expected else err==referr==b''
            rows.append(dict(mode=kind,fixture=name,opt=opt,selector=sel,stock_exit=sj['exit'],build_exit=j['exit'],native_exit=jj['exit'],relative_process_receipt=str((d/sel/'result.json').relative_to(r)),receipt_sha256=rh,stdout_sha256=jj['stdout_sha256']))
repo='/workspace/scratch/cbwr-dep'
patch=subprocess.check_output(['git','-C',repo,'diff','--binary',base,head])
(r/'public-candidate.patch').write_bytes(patch)
(r/'summary.json').write_text(json.dumps(dict(base=base,head=head,patch_sha256=sha256(patch).hexdigest(),probe_sha256=sha256((r/'probe.py').read_bytes()).hexdigest(),notes='Native controls for the build repair. These contribute zero test_io originals.',rows=rows),indent=2)+'\n')
print('PASS',len(rows),'control/level cells',sha256((r/'summary.json').read_bytes()).hexdigest())
