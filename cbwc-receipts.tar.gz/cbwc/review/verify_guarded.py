from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
root=Path('/workspace/shared/downloads/cbuffered-writer-class')
repo=Path('/workspace/scratch/cbwc-guard'); tested='1a4d86c7658902e17ce14d3130ab0182db897b6c'
base='ff034f7b2538e67bc41efd6c9eedd59dec7a7e66'
out=root/'review';out.mkdir(exist_ok=True)
def j(path):return json.loads((root/path).read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def h(data):return sha256(data).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==tested
assert git('rev-parse','HEAD~2').decode().strip()==base
assert not git('status','--porcelain')
git('diff','--check',base,tested)
patch=git('diff','--binary',base,tested); (out/'guarded.patch').write_bytes(patch)
eligible=['controls','mock','traced','overcount','wrong_bytes','nonblocking']
summary={}
for stage,head in [('base',base),('guarded',tested)]:
 p=j('build/'+stage+'-provenance.json'); assert p['commit']==head
 for opt in (0,3):
  permanent=j(f'permanent/{stage}/O{opt}/result.json')
  assert permanent['head']==head and permanent['stock']==permanent['build']==0 and permanent['native']==int(stage=='base')
  assert permanent['compiler_sha256']==p['binaries']['imre'] and permanent['runtime_sha256']==p['binaries']['libimre_runtime.a']
  for fixture in ('bytesio','type'):
   reg=j(f'regression/{stage}/{fixture}.O{opt}/summary.json')
   assert reg['head']==head and reg['build_exit']==0 and all(r['matched'] for r in reg['cases'].values())
  l=f'ordinary.O{opt}'
  raw=[row for row in j(f'callback/{stage}/summary.json') if row['lane']==l]
  assert {row['case'] for row in raw}==set(eligible)
  for row in raw:
   case=row['case']; expected=case in ('controls','wrong_bytes') or (stage=='guarded' and case!='nonblocking')
   assert row['build_exit']==0 and row['matches_reference']==expected and not row['process_timeout'],row
   if not expected:
    err=(root/f'callback/{stage}/{l}/{case}/process.stderr').read_text()
    assert ("BufferedWriter with Python raw methods is unsupported" if stage=='base' else "'bytes' object has no attribute 'index'") in err
   if stage=='guarded':
    assert row['process_exit']==int(case in ('nonblocking','wrong_bytes')),row
  if stage=='guarded':
   for item in ('partial','nonblocking','invalid','error_chain','rawroot','reentrant'):
    assert j(f'independent/tested-6f29a0d/{l}/{item}.json')['exit']==0
  summary[stage+'-'+l]={'independent_raw': [(i['case'],i['process_exit'],i['matches_reference']) for i in raw], 'permanent_fixture_native':permanent['native']}
import csv
checks=list(csv.DictReader((root/'shutdown-boundary-audit/guarded-1a4d86c/summary.tsv').open(), delimiter='\t'))
assert len(checks)==20
for o in ('0','3'):
 these={x['case']:x for x in checks if x['opt']==o}
 assert len(these)==10 and all(x['python_post_atexit_hook']=='0' for x in these.values())
 g=these['untouched']
 assert (g['reference_file_hex'],g['original_exit'],g['guard_exit'],g['guard_file_hex'],g['shutdown_diagnostic'])==('414243','0','1','','1')
 fast=root/'class'/'fast'/'guarded'/('O'+o)
 assert j(str(fast/'build.json'))['exit']==0 and j(str(fast/'process.json'))['exit']==0
 text=(fast/'callbacks.stdout').read_text()
 sel='test.test_io.CBufferedWriterTest.test_write'
 for tag in ['START','PASS','STOP']:assert tag+'\t'+sel+'\t' in text
summary.update(base=base,guarded=tested,patch_sha256=h(patch),independent_intermediate_review_sha256=h((root/'independent/tested-second-review.json').read_bytes()),guarded_shutdown_review_sha256=h((root/'shutdown-boundary-audit/guarded-1a4d86c/summary.tsv').read_bytes()))
(out/'guarded-qualification.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Verified final guarded source and native evidence', tested, summary['patch_sha256'])
