from pathlib import Path
import collections, hashlib, inspect, json, os, subprocess, sys, time
import unittest, io, _io
from test import test_io as m
here=Path(__file__).resolve().parent
out=here/'stock';out.mkdir(exist_ok=True)
p=Path(m.__file__).resolve()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert p==Path('/workspace/scratch/cpython/Lib/test/test_io.py') and sha(p)=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
assert sys.version_info[:3]==(3,14,5)
s=unittest.TestLoader().loadTestsFromModule(m)
cls=m.CBufferedWriterTest
flat=[a for group in s for a in group]
assert len(flat)==667
occ=collections.Counter();cases=[]
for position,test in enumerate(flat,1):
    name=test.id();occ[name]+=1
    if type(test) is not cls:continue
    method=test._testMethodName
    base=next(base for base in cls.__mro__ if method in vars(base))
    fun=inspect.unwrap(getattr(cls,method))
    cases.append((position,occ[name],name,base.__qualname__,fun.__code__.co_firstlineno,str(getattr(getattr(cls,method),'__unittest_skip_why__',''))))
assert len(cases)==43 and cls.tp is io.BufferedWriter is _io.BufferedWriter and cls.MockRawIO is m.CMockRawIO and cls.is_C
assert cls.setUp is unittest.TestCase.setUp and cls.tearDown is unittest.TestCase.tearDown
(out/'registration.tsv').write_text('ordinal_in_667\toccurrence\tid\toriginal_owner\tfirst_line\tprovider_skip_reason\n'+''.join('\t'.join(map(str,r))+'\n' for r in cases))
(out/'provenance.json').write_text(json.dumps(dict(cpython_commit='5607950ef232dad16d75c0cf53101d9649d89115',version=sys.version,executable=sys.executable,executable_sha256=sha(sys.executable),test_io=str(p),test_io_sha256=sha(p),test_count=len(flat),class_count=len(cases),runner_sha256=sha(here/'runner.py'),stock_setup=cls.setUp.__qualname__,stock_teardown=cls.tearDown.__qualname__,setup_class=cls.setUpClass.__qualname__,teardown_class=cls.tearDownClass.__qualname__,module_setup=getattr(m,'setUpModule',None),module_teardown=getattr(m,'tearDownModule',None),public_type_identity=True),indent=2)+'\n')
cwd=Path('/workspace/scratch/cbwc-class/stock');cwd.mkdir(parents=True,exist_ok=True)
cmd=[sys.executable,'-B',str(here/'runner.py')];t=time.monotonic()
with (out/'callbacks.stdout').open('wb') as f,(out/'process.stderr').open('wb') as e:p=subprocess.run(cmd,cwd=cwd,env=os.environ,stdout=f,stderr=e,timeout=180)
(out/'process.json').write_text(json.dumps(dict(argv=cmd,cwd=str(cwd),env={'PYTHONPATH':os.environ['PYTHONPATH'],'PYTHONDONTWRITEBYTECODE':os.environ['PYTHONDONTWRITEBYTECODE']},elapsed_s=round(time.monotonic()-t,6),exit=p.returncode,callbacks_sha256=sha(out/'callbacks.stdout'),stderr_sha256=sha(out/'process.stderr')),indent=2)+'\n')
print('callback counts:',collections.Counter(x.split('\t',1)[0] for x in (out/'callbacks.stdout').read_text().splitlines()),'exit',p.returncode)
