"""Generate the original one-method guard diagnostic with only its fixture dependencies."""
from pathlib import Path
import ast, hashlib, json, shutil
H=Path(__file__).resolve().parent
M=Path('/workspace/scratch/cbwc-class/fast/module')
P=Path('/workspace/scratch/cpython/Lib/test/test_io.py');b=P.read_bytes()
def digest(data):return hashlib.sha256(data).hexdigest()
assert digest(b)=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
lines=b.decode().splitlines(keepends=True);stage=['\n']*len(lines)
tree=ast.parse(b);classes={n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
proof={}
def keep(name,node):
    stage[node.lineno-1:node.end_lineno]=lines[node.lineno-1:node.end_lineno]
    proof[name]=dict(start=node.lineno,end=node.end_lineno,sha256=digest(''.join(stage[node.lineno-1:node.end_lineno]).encode()))
for x in tree.body:
    if isinstance(x,ast.Import) and x.names[0].name in ('unittest','io'):keep('import_'+x.names[0].name,x)
for name in ('MockRawIOWithoutRead','MockRawIO','CMockRawIO'):keep(name,classes[name])
for name in ('CommonBufferedTests','SizeofTest','BufferedWriterTest','CBufferedWriterTest'):
    n=classes[name];stage[n.lineno-1]=lines[n.lineno-1]
    if name in ('CommonBufferedTests','SizeofTest'):stage[n.lineno]='    pass\n'
    else:
        for el in n.body:
            if isinstance(el,ast.Assign) or getattr(el,'name',None)=='test_write':keep(f'{name}:{el.lineno}',el)
stage.extend(['\ndef load_tests(loader, tests, pattern):\n',
 '    CBufferedWriterTest.MockRawIO = CMockRawIO\n','    CBufferedWriterTest.is_C = True\n',
 '    return unittest.TestSuite([loader.loadTestsFromTestCase(CBufferedWriterTest)])\n'])
(M/'test').mkdir(parents=True,exist_ok=True);shutil.copyfile(P.parent/'__init__.py',M/'test/__init__.py')
(M/'test/test_io.py').write_text(''.join(stage));shutil.copyfile(H.parent/'runner.py',M/'run.py')
(H/'sources.json').write_text(json.dumps(dict(upstream_sha256=digest(b),retained=proof,inputs={p.relative_to(M).as_posix():digest(p.read_bytes()) for p in sorted(M.rglob('*.py'))},label='focused single original method with direct equivalent CMockRawIO fixture, inherited default setup/teardown'),indent=2)+'\n')
