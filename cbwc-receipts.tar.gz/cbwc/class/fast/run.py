from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, sys, time
H=Path(__file__).resolve().parent;work=Path('/workspace/scratch/cbwc-class/fast');m=work/'module'
stage,sha,bdir=sys.argv[1:];bdir=Path(bdir)
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
if stage!='stock':assert (bdir/'READY').read_text().strip()==sha
for n,h in json.loads((H/'sources.json').read_text())['inputs'].items():assert digest(m/n)==h
def lane(opt):
    name='reference' if stage=='stock' else f'O{opt}'
    d=H/stage/name;w=work/stage/name;d.mkdir(parents=True,exist_ok=True);w.mkdir(parents=True,exist_ok=True)
    exe=w/'test_write'
    env=os.environ.copy()
    for n in ('PYTHONPATH','IMREFLAGS','IMRE_ENCODED_FLAGS'):env.pop(n,None)
    env.update(TMPDIR=str(w),PYTHONDONTWRITEBYTECODE='1')
    def record(cmd,tag,timeout):
        cmd=list(map(str,cmd));t=time.time()
        out=d/('callbacks.stdout' if tag=='process' else 'build.stdout');err=d/(tag+'.stderr')
        with out.open('wb') as stdout,err.open('wb') as stderr:
            try:r=subprocess.run(cmd,cwd=w,env=env,stdout=stdout,stderr=stderr,timeout=timeout);rc=r.returncode;expired=False
            except subprocess.TimeoutExpired:rc=None;expired=True
        write(d/(tag+'.json'),dict(argv=cmd,cwd=str(w),source_manifest_sha256=digest(H/'sources.json'),stage=stage,commit=sha,elapsed_s=round(time.time()-t,6),exit=rc,timed_out=expired,stdout_sha256=digest(out),stderr_sha256=digest(err)))
        print(stage,name,tag,rc,flush=True)
        return rc
    if stage=='stock':
        cmd=['/workspace/scratch/cpytools/bin/python3.14','-B',m/'run.py']
    else:
        if record([bdir/'imre','build',m/'run.py','--module-root',m,'--no-cache','--runtime',bdir/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','--opt-level',opt,'-o',exe],'build',1150)!=0:return
        (d/'program.sha256').write_text(digest(exe)+'\n'); cmd=[exe]
    record(cmd,'process',250)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lane,([0] if stage=='stock' else [0,3])))
