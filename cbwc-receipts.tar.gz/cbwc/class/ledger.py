"""Key outcomes on CPython registration. Only real callbacks confer method outcomes."""
import argparse, ast, collections, csv, hashlib, json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('label');options=p.parse_args()
root=Path(__file__).resolve().parent;stage=root/options.label
cases=list(csv.DictReader((root/'stock/registration.tsv').open(),delimiter='\t'))
ids=[r['id'] for r in cases]
table=[];stats={}
for lvl in (0,3):
    lane=stage/f'O{lvl}';build=json.loads((lane/'build.json').read_text())
    paths=[lane/'process.json',*sorted(lane.glob('*/process.json'))] if build['exit']==0 else []
    attempts={i:[] for i in ids};requested={i:[] for i in ids};registered=set()
    for path in paths:
        if not path.exists():continue
        receipt=json.loads(path.read_text());log=path.parent/receipt['stdout']
        assert hashlib.sha256(log.read_bytes()).hexdigest()==receipt['stdout_sha256']
        for i in receipt['argv'][1:] or ids:
            assert i in requested;requested[i].append(path)
        events=collections.defaultdict(list)
        metadata=[]
        for line in log.read_text(errors='replace').splitlines():
            columns=line.split('\t',2)
            if len(columns)!=3:continue
            tag,case,payload=columns
            if tag=='REGISTER':
                assert case in ids;registered.add(case);continue
            if tag in ('START','STOP','PASS','FAIL','ERROR','SUBFAIL','SUBERROR','SKIP') and case in ids:
                events[case].append((tag,payload))
        for i,ev in events.items():
            tags=[tag for tag,d in ev]
            assert tags[0]=='START' and tags.count('START')==1 and tags.count('STOP')<=1,(i,tags)
            outcomes=[(s,d) for s,d in ev if s in ('PASS','FAIL','ERROR','SUBFAIL','SUBERROR','SKIP')]
            if 'STOP' not in tags or not outcomes:
                v='INTERRUPTED' if receipt['timed_out'] or (receipt['exit'] or 0)!=0 else 'NO_VERDICT'
                detail=next((d for s,d in outcomes),'')
            else:
                assert tags[-1]=='STOP',(i,tags)
                v='ERROR' if any(s in ('ERROR','SUBERROR') for s,d in outcomes) else 'FAIL' if any(s in ('FAIL','SUBFAIL') for s,d in outcomes) else 'SKIP' if outcomes[0][0]=='SKIP' else 'PASS'
                if v=='PASS':assert [s for s,d in outcomes]==['PASS'],(i,tags)
                detail=next(d for s,d in outcomes if s in (v,'SUB'+v))
            attempts[i].append((v,detail,str(path.relative_to(root)),receipt['exit'],receipt['timed_out']))
    counts=collections.Counter()
    for c in cases:
        i=c['id'];observed=[r for r in attempts[i] if r[0] not in ('INTERRUPTED','NO_VERDICT')]
        if observed:
            assert len(set((v,d) for v,d,*other in observed))==1,(i,observed)
            outcome=observed[-1]
        elif attempts[i]:outcome=attempts[i][-1]
        else:
            rawpath=requested[i][-1] if requested[i] else lane/'build.json'
            r=json.loads(rawpath.read_text())
            outcome=('UNREACHED','',str(rawpath.relative_to(root)),r['exit'] if requested[i] else None,r['timed_out'])
        v,detail,raw,rc,tout=outcome;counts[v]+=1
        table.append((lvl,c['ordinal_in_667'],c['occurrence'],i,int(i in registered),v,detail,build['exit'],rc,int(tout),raw,hashlib.sha256((root/raw).read_bytes()).hexdigest()))
    stats[f'O{lvl}']=dict(registered=len(registered),outcomes=dict(counts))
with (stage/'ledger.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['ordinary_opt','ordinal_in_667','occurrence','id','native_registered','native_verdict','callback_detail','compiler_exit','shared_process_exit','timeout','raw_receipt','raw_receipt_sha256']);w.writerows(table)
(stage/'stats.json').write_text(json.dumps(stats,indent=2)+'\n');print(stats)
