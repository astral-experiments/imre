"""Measure one frozen Imre head at ordinary O0/O3; preserve completed callback writes."""
from pathlib import Path
import argparse, concurrent.futures, csv, hashlib, json, os, signal, subprocess, time
H=Path(__file__).resolve().parent
WORK=Path('/workspace/scratch/cbwc-class');MODULE=WORK/'module'
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(path,doc):path.write_text(json.dumps(doc,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('commit');p.add_argument('bin',type=Path);p.add_argument('--reuse',action='store_true');p.add_argument('--shard',default='');p.add_argument('--ids',nargs='*',default=[]);p.add_argument('--process-timeout',type=int,default=350);p.add_argument('--opt',nargs='+',type=int,default=[0,3]);args=p.parse_args()
assert (args.bin/'READY').read_text().strip()==args.commit
root=H/args.label;root.mkdir(exist_ok=True)
inputs=json.loads((H/'projection.json').read_text())['inputs']
for name,h in inputs.items():assert sha(MODULE/name)==h
oracle=list(csv.DictReader((H/'stock/registration.tsv').open(),delimiter='\t'));ids=[r['id'] for r in oracle]
assert len(ids)==43 and all(i in ids for i in args.ids)
provenance=dict(imre=args.commit,compiler_sha256=sha(args.bin/'imre'),runtime_sha256=sha(args.bin/'libimre_runtime.a'),projection_sha256=sha(H/'projection.json'),runner_sha256=sha(MODULE/'run.py'),registration_sha256=sha(H/'stock/registration.tsv'))
if (root/'provenance.json').exists():assert json.loads((root/'provenance.json').read_text())==provenance
else:save(root/'provenance.json',provenance)
def execute(cmd,w,d,tag,timeout):
    env=os.environ.copy()
    for k in ('PYTHONPATH','IMREFLAGS','IMRE_ENCODED_FLAGS'): env.pop(k,None)
    env['TMPDIR']=str(w);env['PYTHONDONTWRITEBYTECODE']='1'
    logfile='callbacks.stdout' if tag=='process' else 'build.stdout';start=time.time();cmd=list(map(str,cmd))
    with (d/logfile).open('wb') as out,(d/(tag+'.stderr')).open('wb') as err:
        proc=subprocess.Popen(cmd,env=env,cwd=w,stdout=out,stderr=err,start_new_session=True)
        try:rc=proc.wait(timeout);expired=False
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait();expired=True
    receipt=dict(argv=cmd,cwd=str(w),utc_start_epoch=start,elapsed_s=round(time.time()-start,5),exit=None if expired else rc,reaped_status=rc,timed_out=expired,stdout=logfile,stdout_sha256=sha(d/logfile),stderr=tag+'.stderr',stderr_sha256=sha(d/(tag+'.stderr')))
    save(d/(tag+'.json'),receipt)
    print(args.label,d,tag,receipt['exit'],'timeout',expired,flush=True)
    return receipt
def lane(n):
    w=WORK/args.label/f'O{n}';d=root/f'O{n}';w.mkdir(exist_ok=True,parents=True);d.mkdir(exist_ok=True)
    binary=w/'suite'
    if not args.reuse:
        b=execute([args.bin/'imre','build',MODULE/'run.py','--module-root',MODULE,'--no-cache','--runtime',args.bin/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','--opt-level',n,'-o',binary],w,d,'build',1200)
        if b['exit']!=0:return
        (d/'program.sha256').write_text(sha(binary)+'\n')
    else:assert (d/'program.sha256').read_text().strip()==sha(binary)
    if args.shard:
        w=w/args.shard;d=d/args.shard;w.mkdir(exist_ok=True);d.mkdir(exist_ok=True)
    execute([binary,*args.ids],w,d,'process',args.process_timeout)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lane,args.opt))
