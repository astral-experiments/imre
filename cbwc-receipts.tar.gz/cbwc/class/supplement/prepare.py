"""Generate focused stress and threaded modules, preserving every selected source byte."""
from pathlib import Path
import ast, csv, hashlib, json, shutil, sys
H=Path(__file__).resolve().parent
M=Path('/workspace/scratch/cbwc-class/supplement')
Lib=Path('/workspace/scratch/cpython/Lib')
raw=(Lib/'test/test_io.py').read_bytes()
def digest(b):return hashlib.sha256(b).hexdigest()
assert digest(raw)=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
lines=raw.decode().splitlines(keepends=True);tree=ast.parse(raw)
classes={n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
cases={r['id'].rsplit('.',1)[1]:r for r in csv.DictReader((H.parent/'stock/registration.tsv').open(),delimiter='\t')}
sets={'stress':('test_writes','test_writes_and_flushes','test_writes_and_seeks','test_writes_and_truncates'),
      'thread':('test_threads',)}
for family,methods in sets.items():
    d=H/family;d.mkdir(exist_ok=True)
    mod=M/family/'module';(mod/'test').mkdir(parents=True,exist_ok=True)
    out=['\n']*len(lines);proof={}
    def keep(label,node):
        start=min([node.lineno]+[x.lineno for x in getattr(node,'decorator_list',())]);end=node.end_lineno
        out[start-1:end]=lines[start-1:end]
        proof[label]=dict(start=start,end=end,sha256=digest(''.join(lines[start-1:end]).encode()))
    def copy(rel):
        src=Lib/rel;t=mod/rel;t.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(src,t)
    wanted={'io','unittest'}|({'threading','time'} if family=='thread' else set())
    for node in tree.body:
        if isinstance(node,ast.Import) and node.names[0].name in wanted:keep('import_'+node.names[0].name,node)
        if isinstance(node,ast.ImportFrom):
            if node.module=='itertools' or (family=='thread' and node.module in ('collections','test','test.support')):
                keep(f'from-import-{node.lineno}',node)
    for name in ('MockRawIOWithoutRead','MockRawIO','CMockRawIO'):keep(name,classes[name])
    for name in ('SizeofTest','CommonBufferedTests','BufferedWriterTest','CBufferedWriterTest'):
        node=classes[name];out[node.lineno-1]=lines[node.lineno-1]
        if name in ('SizeofTest','CommonBufferedTests'):out[node.lineno]='    pass\n'
        else:
            for el in node.body:
                if isinstance(el,ast.Assign) or getattr(el,'name',None) in methods or (family=='stress' and getattr(el,'name',None)=='check_writes'):
                    keep(f'{name}.{getattr(el,"name",el.lineno)}',el)
    out.extend(['\ndef load_tests(loader, tests, pattern):\n','    CBufferedWriterTest.MockRawIO = CMockRawIO\n','    CBufferedWriterTest.is_C = True\n'])
    if family=='thread':out.append('    CBufferedWriterTest.open = io.open\n')
    out.append('    return unittest.TestSuite([loader.loadTestsFromTestCase(CBufferedWriterTest)])\n')
    (mod/'test/test_io.py').write_text(''.join(out));copy('test/__init__.py')
    if family=='thread':
        shutil.copytree(Lib/'test/support',mod/'test/support',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copyfile(H.parent/'runner.py',mod/'run.py')
    (d/'sources.json').write_text(json.dumps(dict(cpython='5607950ef232dad16d75c0cf53101d9649d89115',upstream_sha256=digest(raw),retained=proof,inputs={x.relative_to(mod).as_posix():digest(x.read_bytes()) for x in sorted(mod.rglob('*.py'))},registration=[cases[n] for n in methods],fixture='real public/private writer, original CMockRawIO and inherited unittest.TestCase setup/teardown; thread has original decorators, write_mode, real io.open and test.support'),indent=2)+'\n')
