"""Key optimized-runtime callbacks independently of the primary debug-runtime results."""
import csv,json,hashlib,time
from pathlib import Path
H=Path(__file__).resolve().parent;rows=[]
while not (H/'seek-retries-complete.json').exists():time.sleep(2)
seek_attempts=json.loads((H/'seek-retries-complete.json').read_text())
while not (H/'thread-retries-complete.json').exists():time.sleep(2)
thread_attempts=json.loads((H/'thread-retries-complete.json').read_text())
for family in ('stress','thread'):
    src=H/family;runtime=src/'public-opt-runtime'
    cases=json.loads((src/'sources.json').read_text())['registration']
    prov=json.loads((runtime/'provenance.json').read_text())
    for level in (0,3):
        lane=runtime/f'O{level}';buildpath=lane/'build.json';build=json.loads(buildpath.read_text())
        for case in cases:
            i=case['id'];d=lane/i.rsplit('.',1)[1]
            p=buildpath;status='UNREACHED';detail='';registered=False;timeout=build['timed_out'];exit_code=None
            if build['exit']==0:
                attempts=thread_attempts if family=='thread' else seek_attempts
                is_retry_selector=family=='thread' or i.endswith('.test_writes_and_seeks')
                if is_retry_selector and 'retry' in attempts[f'O{level}']:
                    d=d/'retry-1'
                    meta=attempts[f'O{level}']['retry']
                    assert meta['receipt']==str((d/'process.json').relative_to(H)) and meta['sha256']==hashlib.sha256((d/'process.json').read_bytes()).hexdigest()
                p=d/'process.json';rec=json.loads(p.read_text());data=(d/'callbacks.stdout').read_bytes()
                assert hashlib.sha256(data).hexdigest()==rec['stdout_sha256'] and rec['argv'][1:]==[i]
                timeout=rec['timed_out'];exit_code=rec['exit'];tags=[]
                for s in data.decode(errors='replace').splitlines():
                    v=s.split('\t',2)
                    if len(v)!=3 or v[1]!=i:continue
                    tags.append(v[0])
                    if v[0] in ('FAIL','ERROR','SKIP'):detail=v[2]
                registered='REGISTER' in tags
                if 'STOP' in tags:
                    outcomes=[t for t in tags if t in ('PASS','SKIP','ERROR','FAIL')]
                    assert len(outcomes)==1 and registered and tags.index('START')<tags.index(outcomes[0])<tags.index('STOP')
                    status=outcomes[0]
                elif 'START' in tags:status='INTERRUPTED'
            rows.append([prov['public_imre_sha'],family,level,case['ordinal_in_667'],case['occurrence'],i,int(registered),status,detail,build['exit'],exit_code,int(timeout),str(p.relative_to(H)),hashlib.sha256(p.read_bytes()).hexdigest()])
with (H/'public-opt-runtime.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['public_imre_sha','projection','ordinary_opt','ordinal_in_667','occurrence','id','registered','native_verdict','callback_detail','compiler_exit','shared_process_exit','timeout','raw_receipt','raw_receipt_sha256']);w.writerows(rows)
print([(r[1],r[2],r[5].rsplit('.',1)[1],r[7]) for r in rows])
