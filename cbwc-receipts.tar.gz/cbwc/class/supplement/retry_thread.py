"""Pair an actual O3 thread outcome only if O0 exceeded its original bound."""
import concurrent.futures, hashlib, json, os, signal, subprocess, time
from pathlib import Path
H=Path(__file__).resolve().parent
ROOT=H/'thread/public-opt-runtime'
WORK=Path('/workspace/scratch/cbwc-class/supplement/thread/public-opt-runtime')
name='test.test_io.CBufferedWriterTest.test_threads'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def receipt_ref(p):return {'receipt':str(p.relative_to(H)),'sha256':sha(p)}
def verify_stream(rec,folder):
    stdout=folder/'callbacks.stdout';assert sha(stdout)==rec['stdout_sha256']
    return [row[0] for s in stdout.read_text(errors='replace').splitlines() if len(row:=s.split('\t',2))==3 and row[1]==name]
def one(opt):
    lane=ROOT/f'O{opt}';src=lane/'test_threads';p=src/'process.json'
    while not p.exists():
        b=lane/'build.json'
        if b.exists() and json.loads(b.read_text())['exit']!=0:return {'original_build':receipt_ref(b),'status':'compiler failure'}
        time.sleep(2)
    first=json.loads(p.read_text());tags=verify_stream(first,src)
    info={'original':receipt_ref(p),'original_timed_out':first['timed_out']}
    if opt==0:
        other=ROOT/'O3/test_threads'
        while not (other/'process.json').exists():
            ob=ROOT/'O3/build.json'
            if ob.exists() and json.loads(ob.read_text())['exit']!=0:
                info['status']='no O3 executable';return info
            time.sleep(2)
        observed=verify_stream(json.loads((other/'process.json').read_text()),other)
        if 'STOP' not in observed or not any(t in observed for t in ('PASS','FAIL','ERROR','SKIP')):
            info['status']='no O3 terminal method callback to pair';return info
    if opt==3 or not first['timed_out'] or 'START' not in tags or any(t in tags for t in ('PASS','FAIL','ERROR','SKIP','STOP')):
        info['status']='first attempt retained';return info
    exe=WORK/f'O{opt}'/'suite';args=[str(exe),name]
    assert first['argv']==args and sha(exe)==(lane/'program.sha256').read_text().strip()
    out=src/'retry-1';cwd=WORK/f'O{opt}'/'test_threads-retry-1';out.mkdir(exist_ok=True);cwd.mkdir(exist_ok=True)
    rp=out/'process.json'
    if not rp.exists():
        env=os.environ.copy()
        for key in ('PYTHONPATH','IMREFLAGS','IMRE_ENCODED_FLAGS'):env.pop(key,None)
        env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE='1')
        stdout=out/'callbacks.stdout';stderr=out/'process.stderr';start=time.time();limit=1000
        with stdout.open('wb') as f,stderr.open('wb') as e:
            proc=subprocess.Popen(args,cwd=cwd,env=env,stdout=f,stderr=e,start_new_session=True)
            try:rc=proc.wait(timeout=limit);expired=False
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait();expired=True
        rec=dict(argv=args,cwd=str(cwd),start_epoch=start,elapsed_s=round(time.time()-start,6),exit=None if expired else rc,reaped_status=rc,
                 timed_out=expired,limit_s=limit,executable_sha256=sha(exe),stdout_sha256=sha(stdout),stderr_sha256=sha(stderr))
        rp.write_text(json.dumps(rec,indent=2)+'\n')
    rec=json.loads(rp.read_text());assert rec['argv']==args and rec['executable_sha256']==sha(exe)
    verify_stream(rec,out);info['retry']=receipt_ref(rp);info['status']='retry completed'
    print(opt,'retry',rec['exit'],'timed out',rec['timed_out'],flush=True)
    return info
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(zip(('O0','O3'),pool.map(one,(0,3))))
m=H/'thread-retries-complete.json';tmp=m.with_suffix('.new');tmp.write_text(json.dumps(results,indent=2)+'\n');tmp.replace(m)
