from pathlib import Path
import concurrent.futures, fcntl, hashlib, json, os, signal, subprocess, sys, time
H=Path(__file__).resolve().parent;W=Path('/workspace/scratch/cbwc-class/supplement')
family,label,commit=sys.argv[1:];src=json.loads((H/family/'sources.json').read_text());mod=W/family/'module';ids=[r['id'] for r in src['registration']]
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,info):p.write_text(json.dumps(info,indent=2)+'\n')
for name,digest in src['inputs'].items():assert sha(mod/name)==digest
orig=Path('/workspace/scratch/cpytools/bin/python3.14');bins=Path('/workspace/scratch/cbwc-bin-public');optbin=Path('/workspace/scratch/cbwc-bin-public-opt-runtime')
d=H/family/label;d.mkdir(exist_ok=True)
if label!='stock':
    lockfile=W/family/(label+'.lock')
    lock=lockfile.open('a')
    fcntl.flock(lock,fcntl.LOCK_EX)
    if (W/family/(label+'.complete')).exists():
        existing=json.loads((d/'provenance.json').read_text())
        assert existing['public_imre_sha']==commit and existing['runtime_sha256']==sha(optbin/'libimre_runtime.a')
        sys.exit(0)
if label=='stock':
    prov=dict(cpython=commit,executable=str(orig),executable_sha256=sha(orig),sources_sha256=sha(H/family/'sources.json'))
else:
    assert label=='public-opt-runtime' and (bins/'READY').read_text().strip()==(optbin/'READY').read_text().strip()==commit
    prov=dict(public_imre_sha=commit,compiler=str(bins/'imre'),compiler_sha256=sha(bins/'imre'),runtime=str(optbin/'libimre_runtime.a'),runtime_sha256=sha(optbin/'libimre_runtime.a'),runtime_crate_opt_level=2,sources_sha256=sha(H/family/'sources.json'),profile='supplemental optimized Rust runtime; ordinary per-level Imre compilation')
save(d/'provenance.json',prov)
def capture(cmd,wd,out,tag,limit):
    env=os.environ.copy()
    for n in ('PYTHONPATH','IMREFLAGS','IMRE_ENCODED_FLAGS'):env.pop(n,None)
    env.update(TMPDIR=str(wd),PYTHONDONTWRITEBYTECODE='1');cmd=list(map(str,cmd));t=time.time()
    stdout=out/('callbacks.stdout' if tag=='process' else 'build.stdout');stderr=out/(tag+'.stderr')
    with stdout.open('wb') as f,stderr.open('wb') as e:
        p=subprocess.Popen(cmd,cwd=wd,env=env,stdout=f,stderr=e,start_new_session=True)
        try:rc=p.wait(timeout=limit);expired=False
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);rc=p.wait();expired=True
    rec=dict(argv=cmd,cwd=str(wd),start_epoch=t,elapsed_s=round(time.time()-t,6),exit=None if expired else rc,reaped_status=rc,timed_out=expired,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr))
    save(out/(tag+'.json'),rec);print(family,label,out.name,tag,rec['exit'],flush=True);return rec
def lane(opt):
    name='reference' if label=='stock' else f'O{opt}';out=d/name;out.mkdir(exist_ok=True)
    work=W/family/label/name;work.mkdir(parents=True,exist_ok=True)
    if label=='stock':
        capture([orig,'-B',mod/'run.py'],work,out,'process',240);return
    exe=work/'suite'
    build=capture([bins/'imre','build',mod/'run.py','--module-root',mod,'--no-cache','--runtime',optbin/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','--opt-level',opt,'-o',exe],work,out,'build',2200)
    if build['exit']!=0:return
    (out/'program.sha256').write_text(sha(exe)+'\n')
    # An independent bound per original keeps one expensive callback from hiding another.
    def run_case(i):
        suffix=i.rsplit('.',1)[1];r=out/suffix;w=work/suffix;r.mkdir(exist_ok=True);w.mkdir(exist_ok=True)
        capture([exe,i],w,r,'process',600 if family=='thread' else 800)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run_case,ids))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lane,[0] if label=='stock' else [0,3]))

if label!='stock':(W/family/(label+'.complete')).write_text(commit+'\n')
