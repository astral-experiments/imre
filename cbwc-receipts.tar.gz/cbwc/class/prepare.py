"""Select the complete upstream writer class, its bases, and all original raw mocks."""
import ast, hashlib, io, json, shutil, sys
from pathlib import Path
here=Path(__file__).resolve().parent
stage=Path('/workspace/scratch/cbwc-class/module')
lib=Path('/workspace/scratch/cpython/Lib')
original=lib/'test/test_io.py'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(original)=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
lines=original.read_text().splitlines(keepends=True)
tree=ast.parse(''.join(lines))
writers={'CommonBufferedTests','SizeofTest','BufferedWriterTest','CBufferedWriterTest'}
kept=[n for n in tree.body if isinstance(n,ast.ClassDef) and (82<=n.lineno<=332 or n.name in writers)]
inputs={a.attr for node in kept if node.name in writers for a in ast.walk(node) if isinstance(a,ast.Attribute) and isinstance(a.value,ast.Name) and a.value.id=='self'}
exports=tuple(x for x in io.__all__ if x in inputs)
assert set(exports)=={'BlockingIOError','BytesIO','FileIO','UnsupportedOperation','open'}
out=['\n']*len(lines)
assert lines[48].startswith('import _pyio')
out[:49]=lines[:49]
proof={}
for n in kept:
    assert not n.decorator_list
    out[n.lineno-1:n.end_lineno]=lines[n.lineno-1:n.end_lineno]
    proof[n.name]=dict(start=n.lineno,end=n.end_lineno,sha256=hashlib.sha256(''.join(out[n.lineno-1:n.end_lineno]).encode()).hexdigest())
hook=next(n for n in tree.body if getattr(n,'name',None)=='load_tests')
out[hook.lineno-1:hook.end_lineno]=lines[hook.lineno-1:hook.end_lineno]
tests=hook.body[0]
assert tests.targets[0].id=='tests'
out[tests.lineno-1:tests.end_lineno]=['    tests = (CBufferedWriterTest,)\n']+['\n']*(tests.end_lineno-tests.lineno)
members=next(n for n in hook.body if isinstance(n,ast.Assign) and n.targets[0].id=='all_members')
assert lines[members.lineno-1].strip()=='all_members = io.__all__'
out[members.lineno-1]='    all_members = '+repr(exports)+'\n'
(stage/'test').mkdir(parents=True,exist_ok=True)
(stage/'test/test_io.py').write_text(''.join(out))
shutil.copyfile(here/'runner.py',stage/'run.py')
for name in ('test/__init__.py','_pyio.py'):
    shutil.copyfile(lib/name,stage/name)
shutil.copytree(lib/'test/support',stage/'test/support',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
(here/'projection.json').write_text(json.dumps(dict(source_sha256=sha(original),cpython_commit='5607950ef232dad16d75c0cf53101d9649d89115',selected_class='test.test_io.CBufferedWriterTest',unchanged_classes=proof,hook_changes={'tests_at':tests.lineno,'members_at':members.lineno,'members':exports},inputs={p.relative_to(stage).as_posix():sha(p) for p in sorted(stage.rglob('*.py'))}),indent=2)+'\n')
