"""Attempt missing selectors if a bounded group ended before their first callback."""
from pathlib import Path
import concurrent.futures, csv, json, subprocess, sys, time
H=Path(__file__).resolve().parent;label,commit,bin=sys.argv[1:]
def worker(opt):
    lane=H/label/f'O{opt}'
    while not (lane/'build.json').exists():time.sleep(2)
    if json.loads((lane/'build.json').read_text())['exit']!=0:return
    while not (lane/'shard-plan.json').exists():time.sleep(2)
    def watch(group):
        d=lane/group['folder']
        while not (d/'process.json').exists():time.sleep(2)
        cmd=json.loads((d/'process.json').read_text())
        if cmd['exit'] in (0,1) and not cmd['timed_out']:
            # An import/fixture problem before enumeration is diagnosed by its own raw trace.
            if not (d/'callbacks.stdout').read_bytes():return
        lines=(d/'callbacks.stdout').read_text(errors='replace').splitlines()
        started={parts[1] for s in lines if len(parts:=s.split('\t',2))==3 and parts[0]=='START'}
        missing=[i for i in group['selectors'] if i not in started]
        if missing and any(s.startswith('REGISTER\t') for s in lines):
            name='remaining-'+(group['folder'] if group['folder']!='.' else 'main')
            late=lane/name
            if not (late/'process.json').exists():
                subprocess.run([sys.executable,str(H/'native.py'),label,commit,bin,'--reuse','--opt',str(opt),'--shard',name,'--process-timeout','600','--ids',*missing],check=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as e:list(e.map(watch,json.loads((lane/'shard-plan.json').read_text())))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(worker,(0,3)))
subprocess.run([sys.executable,str(H/'ledger.py'),label],check=True)
