"""Resume complete class coverage after a group timeout or process failure."""
import argparse, concurrent.futures, csv, json, subprocess, sys, time
from pathlib import Path
H=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('commit');p.add_argument('bin');p.add_argument('level',type=int);a=p.parse_args()
lane=H/a.label/f'O{a.level}'
def await_file(path,limit):
    start=time.monotonic()
    while not path.exists() and time.monotonic()-start<limit:time.sleep(3)
    return path.exists()
assert await_file(lane/'build.json',1200)
if json.loads((lane/'build.json').read_text())['exit']!=0:sys.exit(0)
assert await_file(lane/'process.json',1600)
ids=[r['id'] for r in csv.DictReader((H/'stock/registration.tsv').open(),delimiter='\t')]
def events(folder):
    d={i:[] for i in ids}
    for line in (folder/'callbacks.stdout').read_text(errors='replace').splitlines():
        cols=line.split('\t',2)
        if len(cols)==3 and cols[1] in ids:d[cols[1]].append(cols[0])
    return d
def run(label,selectors,timeout):
    cmd=[sys.executable,str(H/'native.py'),a.label,a.commit,a.bin,'--reuse','--opt',str(a.level),'--shard',label,'--process-timeout',str(timeout),'--ids',*selectors]
    assert not (lane/label).exists()
    subprocess.run(cmd,check=True)
    return events(lane/label)
ev=events(lane)
if not any('START' in x for x in ev.values()):sys.exit(0)
todo=[i for i in ids if 'STOP' not in ev[i]]
if not todo:sys.exit(0)
print(a.label,a.level,'group unfinished:',len(todo),flush=True)
# Continue the tail first; an individual method or pathological thread may have
# interrupted an otherwise usable binary. Its isolated replay gets its own raw receipt.
interrupted=[i for i in todo if 'START' in ev[i]]
remaining=[i for i in todo if i not in interrupted]
threads=[i for i in remaining if i.endswith('.test_threads') or i.endswith('.test_slow_close_from_thread')]
remaining=[i for i in remaining if i not in threads]
def tail():
    if remaining:
        ev2=run('tail',remaining,1000)
        next_pending=[i for i in remaining if 'STOP' not in ev2[i]]
        if next_pending and len(next_pending)<len(remaining):
            split=[i for i in next_pending if 'START' in ev2[i]]
            final_tail=[i for i in next_pending if 'START' not in ev2[i]]
            if final_tail:run('tail2',final_tail,900)
            for idx,i in enumerate(split):run('tail-interrupted-'+str(idx+1),[i],400)
def isolated():
    for idx,i in enumerate(interrupted+threads):run('interrupted-'+str(idx+1),[i],520 if i.endswith('.test_threads') else 320)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for future in [pool.submit(tail),pool.submit(isolated)]:future.result()
