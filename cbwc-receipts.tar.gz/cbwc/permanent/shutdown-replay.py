from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,sys,time
from pathlib import Path
stage,root,head=sys.argv[1:]
repo=Path(root); out=Path(__file__).parent/"shutdown"; binary=Path('/workspace/scratch/cbwc-bin-'+stage)
assert (binary/'READY').read_text().strip()==head
def hashfile(p): return sha256(p.read_bytes()).hexdigest()
fixture=repo/'tests/fixtures/io_buffered_writer_shutdown.py'
assert subprocess.check_output(['git','show','1a4d86c7:tests/fixtures/io_buffered_writer_shutdown.py'],cwd=repo)==fixture.read_bytes()
cpy='/workspace/scratch/cpytools/bin/python3.14'
def lane(opt):
    folder=out/stage/f'O{opt}';folder.mkdir(parents=True,exist_ok=True)
    work=Path('/workspace/scratch/cbwc-callback/permanent-shutdown')/stage/f'O{opt}';work.mkdir(parents=True,exist_ok=True)
    exe=work/'fixture'
    def call(label,argv):
        t=time.monotonic();event=dict(argv=list(map(str,argv)),cwd=str(work),utc=datetime.now(timezone.utc).isoformat(),timed_out=False)
        with (folder/(label+'.stdout')).open('wb') as stdout, (folder/(label+'.stderr')).open('wb') as stderr:
            try: event['exit']=subprocess.run(argv,cwd=work,stdout=stdout,stderr=stderr,timeout=400).returncode
            except subprocess.TimeoutExpired: event.update(exit=None,timed_out=True)
        event.update(elapsed_s=round(time.monotonic()-t,3),stdout_sha256=hashfile(folder/(label+'.stdout')),stderr_sha256=hashfile(folder/(label+'.stderr')))
        (folder/(label+'.json')).write_text(json.dumps(event,indent=2)+'\n')
        return event
    build=call('build',[binary/'imre','build',fixture,'--no-cache','--opt-level',str(opt),'--runtime',binary/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','-o',exe])
    exehash=hashfile(exe) if build['exit']==0 else None
    rows=[]
    for mode in ('close','temporary-close','pending'):
        def measure(label,cmd):
            sink=work/(label+'-'+mode+'.bin')
            sink.unlink(missing_ok=True)
            ev=call(label+'-'+mode,[*cmd,sink,mode]);data=sink.read_bytes() if sink.exists() else None
            if data is not None:(folder/(label+'-'+mode+'.bin')).write_bytes(data)
            return dict(exit=ev['exit'],stdout_sha256=ev['stdout_sha256'],stderr_sha256=ev['stderr_sha256'],file_sha256=None if data is None else sha256(data).hexdigest(),file_size=None if data is None else len(data))
        stock=measure('cpython',[cpy,'-IB',fixture]);native=measure('native',[exe]) if exehash else None
        rows.append(dict(mode=mode,stock=stock,native=native))
    if exe.exists():exe.unlink()
    row=dict(head=head,fixture_sha256=hashfile(fixture),compiler_sha256=hashfile(binary/'imre'),runtime_sha256=hashfile(binary/'libimre_runtime.a'),exe_sha256=exehash,build_exit=build['exit'],cases=rows)
    (folder/'result.json').write_text(json.dumps(row,indent=2)+'\n')
    return (stage,opt,row['build_exit'],[(case['mode'],case['native'] and (case['native']['exit'],case['native']['file_size'])) for case in rows])
with ThreadPoolExecutor(2) as pool:
    print(list(pool.map(lane,[0,3])),flush=True)
