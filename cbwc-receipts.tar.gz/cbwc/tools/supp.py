import io,csv
add('build','public-opt-runtime.log','public-opt-runtime-provenance.json','public-opt-runtime-cargo.json')
optmeta=j('build/public-opt-runtime-provenance.json');optcargo=j('build/public-opt-runtime-cargo.json');assert optmeta['commit']==optcargo['head']==edge and optmeta['linked_public_compiler'] and optmeta['rust_runtime_optimization']==2 and '-Copt-level=2' in optcargo['argv'] and optcargo['exit']==0
F['tools/compile-opt-runtime.py']=Path('/workspace/scratch/cbwc-opt-runtime.py').read_bytes()
add('class','supplement');add('independent/driver-audit','supplement-ledger-audit.json')
physical=Path('/workspace/scratch/cbwc-class/supplement')
exclusive=[]
for family in ('stress','thread'):
    sd='class/supplement/'+family
    si=j(sd+'/sources.json');manifest=h(F[sd+'/sources.json'])
    registr=si['registration']; keys=[r['id'] for r in registr];assert all(r in reg for r in registr) and len(keys)==len(set(keys))
    script=(physical/family/'module/test/test_io.py').read_bytes();assert h(script)==si['inputs']['test/test_io.py'];F[sd+'/projected-test_io.py']=script
    ref=j(sd+'/stock/provenance.json');assert ref['sources_sha256']==manifest and ref['executable_sha256']==REFBIN and ref['cpython']==CPY
    assert all(('PASS\t'+key+'\t') in F[sd+'/stock/reference/callbacks.stdout'].decode() for key in keys)
    rt=sd+'/public-opt-runtime'
    p=j(rt+'/provenance.json');assert p['public_imre_sha']==edge and p['runtime_crate_opt_level']==2 and p['sources_sha256']==manifest
    assert p['runtime_sha256']==optmeta['binaries']['libimre_runtime.a'] and p['compiler_sha256']==optmeta['binaries']['imre']
    pub=j('build/public-provenance.json');assert p['compiler_sha256']==pub['binaries']['imre'] and p['runtime_sha256']!=pub['binaries']['libimre_runtime.a'];snapbin(p['runtime'],p['runtime_sha256'])
    for opt in ('0','3'):
        lane=rt+'/O'+opt;b=check_event(lane,'build');a=b['argv'];assert a[0]==p['compiler'] and a[a.index('--runtime')+1]==p['runtime'] and a[a.index('--opt-level')+1]==opt and '--runtime-imports' not in a
        for key in keys:
            row=dict(profile='supplemental-rust-runtime-opt2',family=family,case=key,ordinary_opt=opt,build_exit=b['exit'])
            if b['exit']==0:
                first=lane+'/'+key.rsplit('.',1)[-1]
                def observe(directory):
                    res=j(directory+'/process.json');assert res['argv']==[a[a.index('-o')+1],key]
                    data=F[directory+'/callbacks.stdout'];assert h(data)==res['stdout_sha256'] and h(F[directory+'/process.stderr'])==res['stderr_sha256']
                    ev=[ln.split('\t',2) for ln in data.decode(errors='replace').splitlines()]
                    tags=[v[0] for v in ev if len(v)==3 and v[1]==key]
                    verdict='UNREACHED'
                    if 'START' in tags:
                        assert tags.count('START')==1 and 'REGISTER' in tags
                        if 'STOP' not in tags:verdict='INTERRUPTED' if res['timed_out'] or res['exit'] else 'NO_VERDICT'
                        else:
                            result=[x for x in tags if x in ('PASS','FAIL','ERROR','SKIP')]
                            assert len(result)==1 and tags.index('START')<tags.index(result[0])<tags.index('STOP')
                            verdict=result[0]
                    return dict(process_exit=res['exit'],timeout=res['timed_out'],elapsed_s=res['elapsed_s'],verdict=verdict,raw=directory+'/process.json',raw_sha256=h(F[directory+'/process.json']))
                attempts=[observe(first)]
                if first+'/retry-1/process.json' in F:
                    prior=attempts[0]
                    assert prior['timeout'] and prior['verdict']=='INTERRUPTED'
                    if key.endswith('.test_threads'):
                        assert opt=='0'
                        other=F[rt+'/O3/test_threads/callbacks.stdout'].decode().splitlines()
                        assert any(v.startswith('STOP\t'+key+'\t') for v in other)
                    else:assert key.endswith('.test_writes_and_seeks')
                    attempts.append(observe(first+'/retry-1'))
                    assert j(first+'/process.json')['argv']==j(first+'/retry-1/process.json')['argv']
                row.update(attempts[-1]);row['attempts']=attempts
            else:row.update(verdict='UNREACHED',raw=lane+'/build.json',raw_sha256=h(F[lane+'/build.json']))
            exclusive.append(row)
assert len(exclusive)==10
published=list(csv.DictReader(io.StringIO(F['class/supplement/public-opt-runtime.tsv'].decode()), delimiter='\t'))
assert len(published)==10
lookup={(e['family'],e['ordinary_opt'],e['case']):e for e in exclusive}
assert len(lookup)==10
for line in published:
    e=lookup.pop((line['projection'],line['ordinary_opt'],line['id']))
    assert line['public_imre_sha']==edge and line['occurrence']=='1' and line['native_verdict']==e['verdict'] and line['raw_receipt_sha256']==e['raw_sha256']
    assert 'class/supplement/'+line['raw_receipt']==e['raw']
assert not lookup
assert j('class/supplement/seek-retries-complete.json') is not None and j('class/supplement/thread-retries-complete.json') is not None
F['supplemental-opt2.json']=(json.dumps(dict(in_primary=False,rows=exclusive),indent=2)+'\n').encode()


import io,csv
buf=io.StringIO();w=csv.writer(buf,delimiter='\t',lineterminator='\n');w.writerow(('family','opt','original_id','occurrence','build_exit','process_exit','timeout','verdict','attempts','initial_raw_receipt_sha256','raw_receipt_sha256'))
for x in exclusive:w.writerow([x['family'],x['ordinary_opt'],x['case'],1,x['build_exit'],x.get('process_exit'),x.get('timeout'),x['verdict'],len(x.get('attempts',[])),(x.get('attempts') or [x])[0]['raw_sha256'],x['raw_sha256']])
F['supplement.tsv']=buf.getvalue().encode()
