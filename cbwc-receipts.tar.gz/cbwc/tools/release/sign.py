"""Validate and seal the final Imre I/O buffered writer evidence."""
import argparse
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
import runpy
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path("/workspace/shared/downloads/cbwc")
SUFFIXES = {".diff", ".jsonl", ".csv", ".md", ".py", ".json", ".tsv", ".out", ".log", ".stdout", ".stderr",
            ".exit", ".sh", ".xml", ".ids", ".patch", ".sha", ".sha256", ".txt", ".command", ".c"}
SPECIAL_FILES = {"LICENSE", "LICENSE.cpython", "SHA256SUMS"}
TEMP_NAME = re.compile(r"(?:^|[._-])(?:tmp|temp|partial|backup)(?:[._-]|$)", re.I)
SECRET_NAME = re.compile(r"(?:^|[.\-_])(?:credentials?|secrets?|tokens?|passwords?|auth|private[-_]?key|id_rsa|id_ed25519)(?:[.\-_]|$)", re.I)
SECRET_CONTENT = re.compile(rb"-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----|\b(?:gh[pousr]_[A-Za-z0-9]{24,}|(?:AKIA|ASIA)[A-Z0-9]{16}|github_pat_[A-Za-z0-9_]{35,}|xox[baprs]-[A-Za-z0-9-]{20,}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}|Bearer [A-Za-z0-9_.~-]{24,})")


ASSIGNED_CREDENTIAL = re.compile(rb"""(?ix) (?:password|passwd|client_secret|api[_-]?key|access[_-]?token|refresh[_-]?token|aws_secret_access_key) ["']? \s* [=:] \s* ["']? (?!\$) [A-Za-z0-9_/.+=:-]{20,} """)


EMBEDDED_AUTH = re.compile(rb"""(?ix)
    authorization['"\s:][^\n]{0,8}(?:basic|bearer)\s+[A-Za-z0-9._=/-]{6,}
    |https?://[^/\s:@<>{}]{1,40}:[^/\s@<>{}]{3,90}@
    |/(?:run/secrets|var/run/secrets)/|/\.aws/(?:credentials|config)\b|/\.ssh/id_[a-z0-9]+\b
""")


def require(test, message):
    if not test:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def payload(root, additional_dirs):
    files = {}

    def collect(path):
        rel = path.relative_to(root).as_posix()
        mode = path.lstat().st_mode
        if (path.name.startswith(".") or path.name.lower() in {"__pycache__", "tmp", "temp", "target", "cache", "node_modules"} or SECRET_NAME.search(path.name)
                or TEMP_NAME.search(path.name) or path.name.endswith("~") or stat.S_ISLNK(mode)):
            return
        require(re.fullmatch(r"[A-Za-z0-9_ .+@/-]+", rel), f"unsafe receipt path: {rel}")
        if stat.S_ISDIR(mode):
            for child in path.iterdir():
                if not child.name.startswith("."):
                    collect(child)
        elif stat.S_ISREG(mode):
            if path.suffix not in SUFFIXES and path.name not in SPECIAL_FILES:
                return
            data = path.read_bytes()
            if (b"\x00" in data or data.startswith((b"\x7fELF", b"MZ"))
                    or data.startswith(b"#!") and path.suffix not in {".py", ".sh"}):
                return
            if mode & 0o111 and path.suffix not in {".py", ".sh"}:
                return
            try:
                data.decode("utf-8")
            except UnicodeDecodeError:
                return
            require(not (SECRET_CONTENT.search(data) or ASSIGNED_CREDENTIAL.search(data) or EMBEDDED_AUTH.search(data)), f"credential-shaped material in {rel}")
            files[rel] = data

    require(root.is_dir() and not root.is_symlink(), "receipt root must be a physical directory")
    for name in additional_dirs:
        require(re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]*", name), "invalid selection")
        collect(root / name)
        require(any(k.startswith(name + "/") or k == name for k in files), f"missing receipts: {name}")
    return files


def write_archive(path, files):
    with path.open("wb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.GNU_FORMAT) as archive:
            for name in sorted(files):
                data = files[name]
                info = tarfile.TarInfo(f"cbwc/{name}")
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))


PARENT = "db4916b0223c1d0e95385ed1fc2c6c4eb4400c58"
SIGNER, MANIFEST, SIGNATURE = "signer-ed25519.pem", "SHA256SUMS", "SHA256SUMS.sig"
BUNDLE = "cbwc-receipts.tar.gz"
HERE = Path(__file__).resolve().parent


def check_fresh_extraction(archive, work, pin):
    with tarfile.open(archive, "r:gz") as tar:
        # The preceding independent verifier checks canonical names and rejects links and non-regular files.
        tar.extractall(work, filter="data")
    base=work/"cbwc"
    for name in (SIGNER, MANIFEST, SIGNATURE):
        require((base/name).read_bytes()==(archive.parent/name).read_bytes(), f"different extracted sidecar: {name}")
    der=subprocess.check_output(["openssl","pkey","-pubin","-in",str(base/SIGNER),"-outform","DER"])
    require(digest(der)==pin, "extracted public-key fingerprint mismatch")
    subprocess.run(["openssl","pkeyutl","-verify","-pubin","-inkey",str(base/SIGNER),"-rawin",
                    "-in",str(base/MANIFEST),"-sigfile",str(base/SIGNATURE)],check=True)
    expected=set()
    for line in (base/MANIFEST).read_text().splitlines():
        checksum, name=line.split("  ",1)
        path=base/name
        require(path.is_file() and not path.is_symlink() and digest(path.read_bytes())==checksum,
                f"extracted payload hash mismatch: {name}")
        expected.add(name)
    paths={p.relative_to(base).as_posix() for p in base.rglob("*") if p.is_file()}
    require(paths==expected | {MANIFEST,SIGNATURE}, "extracted inventory mismatch")
    return len(expected)


def seal(files, destination):
    require(not destination.exists() and not destination.is_symlink(), f"release location occupied: {destination}")
    require(not {MANIFEST, SIGNATURE, SIGNER, "SIGNING.md"}.intersection(files), "reserved member in source")
    key = Ed25519PrivateKey.generate()
    pub = key.public_key()
    pem = pub.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    pin = digest(pub.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo))
    files[SIGNER] = pem
    files["SIGNING.md"] = (f"# Verification\n\nA one-use Ed25519 key generated in memory signed this release. "
                          f"Compare the SHA-256 of its SPKI DER bytes with `{pin}` from the coordinating chat. "
                          f"The signature identifies this receipt-specific key and authenticates the listed bytes.\n\n"
                          f"From the publication directory, first use the system OpenSSL and hashing tools.\n\n"
                          f"```sh\nopenssl pkey -pubin -in {SIGNER} -outform DER | sha256sum\n"
                          f"openssl pkeyutl -verify -pubin -inkey {SIGNER} -rawin -in {MANIFEST} -sigfile {SIGNATURE}\n"
                          f"sha256sum verify-cbwc.py\ngrep '  tools/verify-cbwc.py$' {MANIFEST}\n```\n\n"
                          f"Check that the last two hashes match, then run `python verify-cbwc.py {BUNDLE} "
                          f"--pin FINGERPRINT_FROM_CHAT` to verify all archive members and signed payload hashes.\n").encode()
    files[MANIFEST] = "".join(f"{digest(data)}  {name}\n" for name, data in sorted(files.items())).encode()
    files[SIGNATURE] = key.sign(files[MANIFEST])
    del key
    pub.verify(files[SIGNATURE], files[MANIFEST])
    with tempfile.TemporaryDirectory(dir=destination.parent, prefix=".buffer-signed-") as tmp:
        out = Path(tmp) / "release"
        out.mkdir()
        archive = out / BUNDLE
        write_archive(archive, files)
        for name in (MANIFEST, SIGNATURE, SIGNER, "SIGNING.md"):
            (out/name).write_bytes(files[name])
        verifier = out / "verify-cbwc.py"
        verifier.write_bytes(files["tools/verify-cbwc.py"])
        subprocess.run([sys.executable, verifier, archive, "--pin", pin], check=True)
        subprocess.run(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", str(out/SIGNER), "-rawin",
                        "-in", str(out/MANIFEST), "-sigfile", str(out/SIGNATURE)], check=True)
        (out/"receipt-archive.sha256").write_text(f"{digest(archive.read_bytes())}  {BUNDLE}\n")
        count=check_fresh_extraction(archive,Path(tmp)/"extraction",pin)
        inventory=dict(signer="receipt-specific one-use Ed25519",spki_der_sha256=pin,
                       covered_manifest=MANIFEST,detached_signature=SIGNATURE,archive=BUNDLE,
                       fresh_extraction_verified_payloads=count,
                       files_to_publish=sorted([f.name for f in out.iterdir()]+["PUBLICATION.json"]),
                       publish_files={f.name:dict(bytes=f.stat().st_size,sha256=digest(f.read_bytes()))
                                      for f in sorted(out.iterdir())})
        (out/"PUBLICATION.json").write_text(json.dumps(inventory,indent=2)+"\n")
        out.rename(destination)
    print(f"SPKI-DER SHA256 {pin}\nArchive SHA256 {digest((destination/BUNDLE).read_bytes())}\n{destination}")

