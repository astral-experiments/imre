from pathlib import Path
from hashlib import sha256
import csv, io, json, re, subprocess, sys, tarfile, shutil
from sign import payload, seal
D=Path(__file__).resolve().parent
BASE="ff034f7b2538e67bc41efd6c9eedd59dec7a7e66"
CPY="5607950ef232dad16d75c0cf53101d9649d89115"
TESTIO="6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af"
REFBIN="c27397da5541f67655be462e128ca3d3eb6e0a8eb0d39036896c9042529f4304"
CASES={'controls','mock','traced','overcount','nonblocking','wrong_bytes'}
ROOT=Path('/workspace/shared/downloads/cbuffered-writer-class')
stage,edge=sys.argv[1:3]
assert stage in ('baseline','final') and re.fullmatch('[a-f0-9]{40}',edge)
out=ROOT.parent/f'cbwc-{stage}-{edge[:7]}'
F={}
def add(folder,*choices):
    for k,v in payload(ROOT/folder,choices).items():F[(Path(folder)/k).as_posix()]=v
def j(p):return json.loads(F[p])
def h(b):return sha256(b).hexdigest()
def tsv(rows):
    s=io.StringIO(); csv.writer(s,delimiter='\t',lineterminator='\n').writerows(rows);return s.getvalue().encode()
def g(k):return F[k].decode().splitlines()
_frozen_hashes={}
def snapbin(path,expected):
    st=Path(path).stat();key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
    if key in _frozen_hashes:
        assert _frozen_hashes[key]==expected,path
        return
    with Path(path).open('rb') as fh:
        d=sha256()
        while block:=fh.read(4194304): d.update(block)
    assert d.hexdigest()==expected, path
    _frozen_hashes[key]=expected
def check_event(prefix,tag):
    p=j(prefix+'/'+tag+'.json')
    for name in ('stdout','stderr'):
        assert h(F[prefix+'/'+tag+'.'+name])==p[name+'_sha256']
    assert p['elapsed_s']>=0 and p['argv']
    return p
add('class','reference.py','runner.py','stock')
upstream=(D/'upstream-test_io.py').read_bytes()
assert h(upstream)==TESTIO
F['licenses/CPython.txt']=Path('/workspace/scratch/cpython/LICENSE').read_bytes()
F['tools/independent-register.py']=(D/'independent-register.py').read_bytes()
F['independent/stock-registration.json']=(D/'stock-43.json').read_bytes()
F['tools/verify-cbwc.py']=(D/'verify-cbwc.py').read_bytes()
reg=list(csv.DictReader(g('class/stock/registration.tsv'),delimiter='\t'))
stock=j('class/stock/provenance.json');raw=j('class/stock/process.json'); boot=j('independent/stock-registration.json')
assert (stock['cpython_commit'],stock['test_io_sha256'],stock['executable_sha256'],stock['test_count'],stock['class_count'],stock['public_type_identity'])==(CPY,TESTIO,REFBIN,667,43,True)
assert stock['version'].startswith('3.14.5 ') and stock['stock_setup']==boot['setup']=='TestCase.setUp' and stock['stock_teardown']==boot['teardown']=='TestCase.tearDown'
assert raw['exit']==0 and raw['callbacks_sha256']==h(F['class/stock/callbacks.stdout']) and raw['stderr_sha256']==h(F['class/stock/process.stderr'])
assert raw['elapsed_s']>=0 and raw['argv'][0]==stock['executable'] and stock['runner_sha256']==h(F['class/runner.py'])
assert boot['source_sha256']==TESTIO and boot['executable_sha256']==REFBIN
snapbin(stock['executable'],REFBIN)
ids=[r['id'] for r in reg]
assert len(set(ids))==43 and [[int(r['ordinal_in_667']),int(r['occurrence']),r['id']] for r in reg]==boot['rows']
assert all(r['id'].startswith('test.test_io.CBufferedWriterTest.') and int(r['occurrence'])==1 for r in reg)
events=[l.split('\t',2) for l in g('class/stock/callbacks.stdout')]
assert all(len(row)==3 for row in events)
assert [[e[1],int(e[2])] for e in events if e[0]=='REGISTER']==[[r['id'],int(r['ordinal_in_667'])] for r in reg]
assert all([e[0] for e in events if e[1]==r['id']]==['REGISTER','START','PASS','STOP'] for r in reg)
assert any(e[:2]==['DENOMINATOR',''] and int(e[2])==667 for e in events)
assert events[-1]==['END','','43']
add('callback','generate.py','body.py.txt','imports.py.txt','inputs.json','measure.py','probes.py','reference','base')
inputs=j('callback/inputs.json')
assert inputs['cpython_pin']==CPY and inputs['upstream_sha256']==TESTIO and inputs['source_sha256']==h(F['callback/probes.py'])
for meta in inputs['classes'].values():
    code=b''.join(upstream.splitlines(keepends=True)[meta['start']-1:meta['end']]); assert h(code)==meta['sha256'] and code in F['callback/probes.py']
rows=[['stage','imre_sha','lane','case','compiler_exit','process_exit','timed_out','matches_cpython','stdout_sha256','stderr_sha256']]
counts={}
def callback(stage_name,commit=None,area='callback',source='probes.py',cases=CASES):
    group=stage_name if area=='callback' else area.split('/')[-1]+'/'+stage_name
    root=area+'/'+stage_name
    summary=j(root+'/summary.json'); p=j(root+'/provenance.json'); ref=commit is None; pairs=set(); good=0
    assert p['cpython_commit']==CPY and p['source_sha256']==h(F[area+'/'+source]) and p['reference_binary_sha256']==REFBIN
    if not ref:
        assert p['imre_commit']==commit
        snapbin(p['compiler'],p['compiler_sha256']);snapbin(p['runtime'],p['runtime_sha256'])
    for row in summary:
        lane,name=row['lane'],row['case']; d=root+('/'+lane if lane else ''); b=None
        assert (lane,name) not in pairs;pairs.add((lane,name))
        if lane:
            b=check_event(d,'build');argv=b['argv'];assert b['exit']==row['build_exit'] and [argv[0],argv[argv.index('--runtime')+1]]==[p['compiler'],p['runtime']] and argv[argv.index('--opt-level')+1]==lane[-1] and '--force-boxed' not in argv and '--runtime-imports' not in argv
            if b['exit']!=0:
                assert row['process_exit'] is None and d+'/'+name+'/process.json' not in F
                rows.append([group,commit,lane,name,b['exit'],'',b['timed_out'],'','','']);continue
            assert re.fullmatch(r'[0-9a-f]{64}',F[d+'/program.sha256'].decode().strip())
        process=check_event(d+'/'+name,'process')
        assert process['exit']==row['process_exit'] and process['timed_out']==row['process_timeout'] and process['argv'][-1]==name
        if ref:
            assert process['argv'][0]==stock['executable'] and process['exit']==(1 if name=='wrong_bytes' else 0) and not process['timed_out']
        else:
            assert process['argv'][0]==b['argv'][b['argv'].index('-o')+1]
            oracle=area+'/reference/'+name; out0=F[oracle+'/process.stdout']; err0=F[oracle+'/process.stderr']; rx=j(oracle+'/process.json')['exit']
            stdout,stderr=F[d+'/'+name+'/process.stdout'],F[d+'/'+name+'/process.stderr']
            eqerr=(stderr==err0 if name!='wrong_bytes' else all(b'AssertionError: deliberate wrong-byte control' in s for s in [stderr,err0]))
            match=(process['exit']==rx and stdout==out0 and eqerr and not process['timed_out'])
            assert match==row['matches_reference'];good+=match
        rows.append([group,commit,lane,name,row['build_exit'],row['process_exit'],row['process_timeout'],row['matches_reference'],process['stdout_sha256'],process['stderr_sha256']])
    assert pairs=={(lane,n) for lane in ([''] if ref else ['ordinary.O0','ordinary.O3']) for n in cases}
    counts[group]={'rows':len(summary),'matches':good if not ref else None}
callback('reference'); callback('base',BASE)
F['registration.tsv']=F['class/stock/registration.tsv']
F['stock-callbacks.stdout']=F['class/stock/callbacks.stdout']
# Final class results and public callback aliases are validated separately before sealing.
add('build',*[p.name for p in sorted((ROOT/'build').glob('base-*'))])
# Cross-check upstream class/method bodies and the whole narrow projection.
add('class','prepare.py','projection.json','native.py','ledger.py','README.md','stock-focused')
proj=j('class/projection.json')
actual=Path('/workspace/scratch/cbwc-class/module/test/test_io.py').read_bytes()
assert h(actual)==proj['inputs']['test/test_io.py']
F['class/projected-test_io.py']=actual
for c,meta in proj['unchanged_classes'].items():
    code=b''.join(upstream.splitlines(keepends=True)[meta['start']-1:meta['end']])
    assert h(code)==meta['sha256'] and code==b''.join(actual.splitlines(keepends=True)[meta['start']-1:meta['end']])
assert set(('CBufferedWriterTest','BufferedWriterTest','SizeofTest','CommonBufferedTests'))<=set(proj['unchanged_classes'])
cf=g('class/stock-focused/callbacks.stdout')
for id in ids:
    assert [row.split('\t')[0] for row in cf if row.split('\t')[1]==id]==['REGISTER','START','PASS','STOP']
F['class/stock-focused/exit']=(ROOT/'class/stock-focused/exit').read_bytes()
assert F['class/stock-focused/exit'].strip()==b'0'
prev=Path('/workspace/shared/downloads/io-buffer-binding/discovery/oracle/regrtest-default/ordered-cases.json').read_bytes()
assert h(prev)=='20b85ee449c8ef9cb66bfe6c4c347db13704e0dfc689884dd26bd662400a1a9c'
previous=[r for r in json.loads(prev) if r['id'] in ids]
assert [r['id'] for r in previous]==ids and [(r['id'],r['reference_reason']) for r in previous if r['reference_verdict']!='PASS']==[('test.test_io.CBufferedWriterTest.test_threads',"resource 'cpu' is not enabled")]
F['provider/profile.json']=(json.dumps(dict(source_receipt_commit='9ec07a60a8d272189f82d8b1e1cb5a6f1ea9dd17',source_payload='discovery/oracle/regrtest-default/ordered-cases.json',source_sha256=h(prev),scope='Prior default-resource CPython regrtest profile vs direct unittest in class/stock',count=43,verdicts={'PASS':42,'SKIP':1},skip=previous[26]),indent=2)+'\n').encode()
prelim=ROOT/'callback/checked-source'
if prelim.is_dir():add('callback','checked-source','README.md')
def class_snapshot(label,commit):
    d='class/'+label
    add(d,'provenance.json');pr=j(d+'/provenance.json')
    assert pr['imre']==commit and pr['projection_sha256']==h(F['class/projection.json']) and pr['runner_sha256']==h(F['class/runner.py']) and pr['registration_sha256']==h(F['registration.tsv'])
    out={}
    for opt in ['0','3']:
        lane=d+'/O'+opt; path=ROOT/lane
        if not (path/'build.json').exists():continue
        add(lane,'build.json','build.stdout','build.stderr')
        b=check_event(lane,'build')
        assert b['argv'][b['argv'].index('--opt-level')+1]==opt and '--runtime-imports' not in b['argv'] and '--no-cache' in b['argv']
        if b['exit']==0 and (path/'program.sha256').is_file():add(lane,'program.sha256')
        if (path/'process.json').exists():
            add(lane,'process.json','process.stderr','callbacks.stdout')
            e=j(lane+'/process.json')
            assert h(F[lane+'/'+e['stdout']])==e['stdout_sha256'] and h(F[lane+'/'+e['stderr']])==e['stderr_sha256']
            out[opt]=dict(build_exit=b['exit'],process_exit=e['exit'],process_timeout=e['timed_out'],raw_sha256=e['stdout_sha256'])
        else:out[opt]=dict(build_exit=b['exit'],process_evidence='no final process result available at snapshot')
        live=path/'callbacks.stdout'
        if stage=='baseline' and live.exists():
            # Atomic frame lines from os.write; clipping a partial final write preserves sealed callback boundaries.
            data=live.read_bytes()
            if data and not data.endswith(b'\n'):data=data[:data.rfind(b'\n')+1]
            F['baseline-callbacks-O'+opt+'.stdout']=data
            out[opt].update(callback_snapshot_bytes=len(data),callback_snapshot_sha256=h(data),records=len(data.splitlines()),
                registered=sum(l.startswith(b'REGISTER\t') for l in data.splitlines()))
    return out
captured=class_snapshot('base',BASE)
F['baseline-focused-snapshot.json']=(json.dumps(captured,indent=2)+'\n').encode()
for name in ('base-provenance.json','base-cargo.json'):
    assert 'build/'+name in F
bi=j('build/base-provenance.json'); cp=j('callback/base/provenance.json')
assert bi['commit']==BASE and bi['binaries']=={'imre':cp['compiler_sha256'],'libimre_runtime.a':cp['runtime_sha256']}


if stage=='final':
    for name in ('base','tested','guarded','public'):
        add('build',*[name+'-'+s for s in ('provenance.json','clean.json','clean.log','cargo.json','cargo.log')])
        src=j('build/'+name+'-provenance.json'); cargo=j('build/'+name+'-cargo.json')
        assert src['commit']==cargo['commit'] and cargo['exit']==0 and cargo['elapsed_s']>0
    F['tools/native-build.py']=Path('/workspace/scratch/cbwc-build.py').read_bytes()
if stage=='final':
    exec((D/'final.py').read_text())
F['callback-controls.tsv']=tsv(rows)
info=dict(stage=stage,imre_baseline=BASE,imre_current=edge,cpython=CPY,reference_registration=len(ids),stock_pass=43,stock_provider_skips=0,upstream_sha256=TESTIO,callback_controls=counts)
if stage=='final':
    info.update(supplemental_opt2_in_packet=bool(cfg.get('supplemental')),guarded_head=cfg['tested'],intermediate=cfg['intermediate'],stock_regrtest_default={'PASS':42,'SKIP':1},prior_credit_reference=profile,original_class_stages={
        k:{o:dict(registered=rows[o]['registered'],outcomes=rows[o]['outcomes']) for o in ('O0','O3')} for k,rows in results.items()},paired_keys_new_on_3912_branch=delta['paired']['newly_passing_on_3912_branch'],additional_paired_keys_only_on_public=delta['paired']['public_additions_after_intermediate'],paired_keys_lost_public_vs_baseline=delta['paired']['lost'],guard_scope='one focused original test_write and control witnesses')
F['scope.json']=(json.dumps(info,indent=2)+'\n').encode()
F['README.md']=(f"# CBufferedWriterTest {stage} checkpoint\n\nPinned CPython 3.14.5 produced 43 registrations and 43 successful method callbacks (0 provider skips). They occupy positions 172–214 in the unchanged 667-case test.test_io module. The public identity fixture uses io.BufferedWriter, _io.BufferedWriter and CMockRawIO.\n\nThe native work starts at Imre {BASE}. Raw writer/descriptor controls and the original class have separate records. Each controls row is one actual binary launch, or a compiler failure with no process result; six controls share one build per native level. The deliberate wrong-byte assertion exits 1 on CPython.\n\nA separate upstream default-resource regrtest records 42 passes and skips test_threads because the cpu resource is disabled. This direct unittest run covers all 43. See provider/profile.json.\n\nThe small ledgers are also available at the receipt commit root. See class/stock in the archive for the unmodified full-module namespace and per-method unittest callbacks, and callback for raw stdout, stderr, argv and separate build/process status.\n").encode()
if stage=='final':
    F['README.md']+=(f"\nThe public source change is [PR #3912]({cfg['pr']}) at `{edge}`, tested at `{cfg['tested']}`. The intermediate `{cfg['intermediate']}` silently lost unflushed global callback bytes at process exit. The guard and public merge signal this pending-write case with status 1 and a diagnostic. Explicit close writes the expected bytes. See shutdown-outcomes.json.\n\nAll 43 baseline, intermediate and public class dispositions are distinct from the single-method guard smoke. The public class ledger is originals.tsv, and raw-index.tsv identifies the exact process by hash. The pinned base already passed {len(delta['paired']['base'])} IDs at both ordinary levels. The public merge passed {len(delta['paired']['final'])} at both, gaining {len(delta['paired']['gained'])} and losing {len(delta['paired']['lost'])} relative to that base. The isolated #3912 branch added {len(delta['paired']['newly_passing_on_3912_branch'])} paired passes over the pinned base. The public first parent separately contains #3917, which implements BufferedRandom.truncate for test_truncate_after_write. Its observed public outcomes are recorded in background-3917.json and the table marks the affected ID. Native-pass-delta.json separates paired and optimization-specific results and prior-credit.json identifies the aggregate upstream 112-key claim. See intact/ for the separate whole-module discovery boundary.\n").replace('Native-pass-delta','native-pass-delta').encode()
seal(F,out)
for name in ('scope.json','registration.tsv','stock-callbacks.stdout','callback-controls.tsv','README.md','originals.tsv','raw-index.tsv','public.patch','supplement.tsv'):
    if name in F:(out/name).write_bytes(F[name])
for name in ('baseline-callbacks-O0.stdout','baseline-callbacks-O3.stdout'):
    if name in F:(out/name).write_bytes(F[name])
print(str(out))

