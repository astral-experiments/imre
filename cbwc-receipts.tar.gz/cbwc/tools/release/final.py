add('class','recover.py','finish_shards.py')
cfg=json.loads((D/'final-config.json').read_text())
def valid(s):return re.fullmatch('[0-9a-f]{40}',s)
assert cfg['base']==BASE and cfg['public']==edge and valid(cfg['tested'])
for tag,commit in cfg['callbacks'].items():
    assert valid(commit)
    if tag in ('reference','base'):continue
    add('callback',tag);callback(tag,commit)
if (ROOT/'callback/forwarding').is_dir():
    add('callback','forwarding')
    for label in ('reference',*cfg['callbacks']):
        if 'callback/forwarding/'+label+'/summary.json' not in F:continue
        callback(label,cfg['callbacks'].get(label),'callback/forwarding','forward.py',{'correct','wrong_bytes'})
exec((D/'classgate.py').read_text())
results={}
for tag,commit in cfg['class_stages'].items():
    assert valid(commit)
    results[tag],tab=gateclass(tag,commit)
    if tag==cfg['public_class']:
        assert commit==edge
        cells={(r['ordinary_opt'],r['id']):r for r in tab}
        prior=next(results[k]['passes_at_both'] for k,c in cfg['class_stages'].items() if c==BASE)
        work=next(results[k]['passes_at_both'] for k,c in cfg['class_stages'].items() if c==cfg['intermediate'])
        truncate_id='test.test_io.CBufferedWriterTest.test_truncate_after_write'
        runs={p:'r'+str(i) for i,p in enumerate(sorted({r['raw_receipt'] for r in tab}),1)}
        F['originals.tsv']=tsv([['ordinal_in_667','occurrence','canonical_id','baseline_paired_pass','intermediate_paired_pass','background_pr','O0_registered','O0_verdict','O0_raw','O3_registered','O3_verdict','O3_raw']]+[[r['ordinal_in_667'],r['occurrence'],r['id'],int(r['id'] in prior),int(r['id'] in work),'3917' if r['id']==truncate_id else '',*[v for o in ('0','3') for v in (cells[o,r['id']]['native_registered'],cells[o,r['id']]['native_verdict'],runs[cells[o,r['id']]['raw_receipt']])]] for r in reg])
        index=[['raw','kind','archive_receipt','receipt_sha256','exit','timed_out','elapsed_s','archive_stdout','stdout_sha256','archive_stderr','stderr_sha256']]
        for path,code in runs.items():
            full='class/'+path;m=j(full);parent=full.rsplit('/',1)[0];kind=path.rsplit('/',1)[-1].removesuffix('.json')
            index.append([code,kind,full,h(F[full]),m['exit'],m['timed_out'],m['elapsed_s'],parent+'/'+m.get('stdout',kind+'.stdout'),m['stdout_sha256'],parent+'/'+m['stderr'],m['stderr_sha256']])
        F['raw-index.tsv']=tsv(index)
assert 'originals.tsv' in F
if cfg.get('guard_smoke'):
    label=cfg['guard_smoke'];area='class/fast';add('class','fast')
    manifest=j(area+'/sources.json');assert manifest['upstream_sha256']==TESTIO
    projected=Path('/workspace/scratch/cbwc-class/fast/module/test/test_io.py').read_bytes()
    assert h(projected)==manifest['inputs']['test/test_io.py'];F[area+'/projected-test_io.py']=projected
    for n,meta in manifest['retained'].items():
        span=slice(meta['start']-1,meta['end']);code=b''.join(upstream.splitlines(keepends=True)[span])
        assert h(code)==meta['sha256'] and b''.join(projected.splitlines(keepends=True)[span])==code
    key='test.test_io.CBufferedWriterTest.test_write';expected=j(area+'/stock/reference/process.json')
    events=F[area+'/stock/reference/callbacks.stdout'];assert expected['stdout_sha256']==h(events)
    assert [ln.split(b'\t')[0] for ln in events.splitlines() if ln.split(b'\t')[1]==key.encode()]==[b'REGISTER',b'START',b'PASS',b'STOP']
    assert expected['commit']==CPY and expected['exit']==0
    for o in ('0','3'):
        basepath=area+'/'+label+'/O'+o
        b=check_event(basepath,'build');p=j(basepath+'/process.json')
        assert b['stage']==label and b['commit']==cfg['tested'] and b['exit']==0 and b['argv'][b['argv'].index('--opt-level')+1]==o and '--runtime-imports' not in b['argv']
        assert p['commit']==b['commit'] and b['source_manifest_sha256']==p['source_manifest_sha256']==h(F[area+'/sources.json'])
        assert p['argv']==[b['argv'][b['argv'].index('-o')+1]] and p['exit']==0 and not p['timed_out']
        assert F[basepath+'/callbacks.stdout']==events and p['stdout_sha256']==h(events) and p['stderr_sha256']==h(F[basepath+'/process.stderr'])
    if (ROOT/'class/guarded/SCHEDULING.json').exists():
        add('class/guarded','SCHEDULING.json','provenance.json')
        assert j('class/guarded/SCHEDULING.json')['status']=='CANCELLED_IN_COMPILE'
        for o in ('0','3'):
            lane='class/guarded/O'+o;add(lane,'build.json','build.stdout','build.stderr'); bb=check_event(lane,'build')
            assert bb['exit']!=0 and not (ROOT/lane/'process.json').exists()
    F['guard-smoke-scope.json']=(json.dumps(dict(head=cfg['tested'],selected=[key],original_method_body_unchanged=True,fixture='direct equivalent CMockRawIO and default inherited setup/teardown',ordinary_O0='PASS',ordinary_O3='PASS',class_denominator=43,scope='one focused method'),indent=2)+'\n').encode()
F['native-class-summary.json']=(json.dumps(results,indent=2)+'\n').encode()
base_class=next(t for t,c in cfg['class_stages'].items() if c==BASE)
before=results[base_class];after=results[cfg['public_class']]
wins=lambda s,o:set(s['passes_at_both'] if o=='paired' else s[o]['passed_ids'])
delta={o:dict(base=sorted(wins(before,o)),final=sorted(wins(after,o)),gained=sorted(wins(after,o)-wins(before,o)),lost=sorted(wins(before,o)-wins(after,o))) for o in ('paired','O0','O3')}
mid=next(results[k] for k,c in cfg['class_stages'].items() if c==cfg['intermediate'])
for o in delta:
    delta[o].update(intermediate=sorted(wins(mid,o)),
                    newly_passing_on_3912_branch=sorted(wins(mid,o)-wins(before,o)),
                    public_additions_after_intermediate=sorted(wins(after,o)-wins(mid,o)),
                    public_losses_after_intermediate=sorted(wins(mid,o)-wins(after,o)))
other='74fa9adae9d6c3361db1949c557c303be365a48c'
def ancestor(a,b):
    st=subprocess.run(['git','-C','/workspace/scratch/imre','merge-base','--is-ancestor',a,b],check=False)
    assert st.returncode in (0,1);return not st.returncode
assert ancestor(other,edge+'^1') and not ancestor(other,cfg['intermediate'])
F['background-3917.json']=(json.dumps(dict(pr=3917,merge_commit=other,original_id=truncate_id,
    reason='The complete original calls truncate on a descriptor-backed buffered update stream. Both baseline and the isolated #3912 branch lacked _io.BufferedRandom.truncate. #3917 supplies it on the actual public first parent.',
    public_lanes_passing=[o for o in ('O0','O3') if truncate_id in wins(after,o)],attributed_to_3912=False),indent=2)+'\n').encode()
F['native-pass-delta.json']=(json.dumps(delta,indent=2)+'\n').encode()
previous_commit='81977ec61cfffc48e9742b022f42f07d733667e3'
readme=subprocess.check_output(['git','-C','/workspace/scratch/imre','show',previous_commit+':README.md'])
line=next((i+1,s) for i,s in enumerate(readme.decode().splitlines()) if s.startswith('| `io` |'))
assert '| 112 | 1,038 |' in line[1]
profile=dict(repository='astral-experiments/imre',commit=previous_commit,path='README.md',sha256=h(readme),line=line[0],row=line[1],prior_credited_total=112,original_io_denominator=1038,distinct_key_overlap='User stated these 43 IDs were absent from the 112-key union. No prior key list was available for an independent set intersection.',paired_before=len(delta['paired']['base']),paired_after=len(delta['paired']['final']),net_paired_public_vs_pinned_base=len(delta['paired']['final'])-len(delta['paired']['base']),conditional_total_if_all_disjoint=112+len(delta['paired']['final']))
F['prior-credit.json']=(json.dumps(profile,indent=2)+'\n').encode()
F['scope-note.txt']=b'The prior public README reports 112 of 1,038. Disjointness of these 43 registrations from the prior credited set comes from the assignment. See native-pass-delta.json to separate measured already-passing IDs at the pinned baseline from keys gained at both levels on the isolated branch and extra keys on the public merge parent, and O0/O3-only results.\n'
if (ROOT/'regression/attempts').exists():
    add('regression','attempts')
    for pp in (ROOT/'regression/attempts').glob('*/build.json'):
        x=check_event(pp.parent.relative_to(ROOT).as_posix(),'build')
        assert x['timed_out'] and x['exit'] is None and not list(pp.parent.glob('*-native.json'))
for tag,commit in cfg['intact'].items():
    prefix='intact/native/'+tag
    add('intact/native',tag)
    if tag=='cpython':
        r=j(prefix+'/result.json');assert (r['process']['exit'],r['tests_run'],r['registered'])==(0,0,667)
        continue
    p=j(prefix+'/provenance.json'); assert p['imre_commit']==commit and p['cpython_commit']==CPY and p['source_sha256']['test/test_io.py']==TESTIO
    summary=j(prefix+'/intact-summary.json');assert summary['commit']==commit and summary['source_sha256']==TESTIO and len(summary['rows'])==2
    for o in ('0','3'):
        lane=prefix+'/ordinary.O'+o
        z=j(lane+'/result.json')
        b=z['build'];assert b['argv'][b['argv'].index('--opt-level')+1]==o and '--runtime-imports' not in b['argv']
        for e in [b,z['process']]:
            if not e:continue
            for k in ('stdout','stderr'):assert 'intact/'+e[k] in F
        assert z['tests_run']==0
        item=next(row for row in summary['rows'] if row['lane']=='ordinary.O'+o)
        assert item['result_sha256']==h(F[lane+'/result.json']) and item['denominator']==667 and item['methods_run']==0 and item['registered']==z['observed_id_lines']
        proc=z.get('process');assert item['build_exit']==b['exit'] and item['build_timeout']==b['timed_out']
        if proc:
            assert item['process_exit']==proc['exit'] and item['process_timeout']==proc['timed_out'] and item['last_diagnostic']==F['intact/'+proc['stderr']].decode(errors='replace').strip().splitlines()[-2:]
add('intact','run_native.py','drivers','README.md','source-tree.json','summarize.py')
exec((D/'reggate.py').read_text())
regressions={label:regress(label,commit) for label,commit in cfg.get('regressions',{}).items()}
F['regression/verified.json']=(json.dumps(regressions,indent=2)+'\n').encode()
F['tools/reggate.py']=(D/'reggate.py').read_bytes()
F['regression/measure.py']=Path('/workspace/scratch/cbwc-regress.py').read_bytes()
from sign import SUFFIXES,SPECIAL_FILES
SUFFIXES.update({'.file','.trace','.bytes'})
SPECIAL_FILES.update({'data','stderr','stdout','exit'})
for f in cfg.get('include',[]):add('',f)
# The cancelled full guard has build receipts and a scheduling record. Only its
# separately compiled original smoke produced method callbacks.
for unused in ('guarded.json','guarded-ledger-audit.json'):
    F.pop('independent/driver-audit/'+unused,None)
for area in ('independent/shutdown','independent/shutdown-study','shutdown-boundary-audit'):
    for p in (ROOT/area).rglob('*'):
        if p.is_file() and p.is_relative_to(ROOT) and not p.is_symlink() and (p.suffix in ('.file','.trace','.bytes') or p.name in ('data','stdout','stderr','exit')):
            name=p.relative_to(ROOT).as_posix();assert name in F and p.read_bytes()==F[name],name
if 'permanent' in (cfg.get('include') or []):
    pem={}
    for label,commit in cfg.get('permanent',{}).items():
        for opt in ('0','3'):
            ld='permanent/'+label+'/O'+opt;e=j(ld+'/result.json')
            assert e['head']==commit
            b=check_event(ld,'build');r=check_event(ld,'cpython')
            assert r['argv'][0]==stock['executable'] and b['argv'][b['argv'].index('--opt-level')+1]==opt and '--runtime-imports' not in b['argv']
            assert e['build']==b['exit'] and e['stock']==r['exit']
            if e['build']==0:
                n=check_event(ld,'native');assert n['argv'][0]==b['argv'][b['argv'].index('-o')+1] and e['native']==n['exit']
                assert e['matched_cpython']==all(n[k]==r[k] for k in ('exit','stdout_sha256','stderr_sha256'))
            expected=e['fixture_sha256']; c=cfg['tested'] if label=='base' else commit
            # Original baseline uses the subsequent fixture. Capture the actual source from
            # the recorded path only if it still matches, otherwise from a tested Git tree.
            p=Path(b['argv'][2]); contents=p.read_bytes() if p.is_file() and h(p.read_bytes())==expected else None
            if contents is None:
                for ref in [c,*cfg['class_stages'].values()]:
                    proc=subprocess.run(['git','-C','/workspace/scratch/imre','show',ref+':tests/fixtures/io_buffered_writer_callbacks.py'],capture_output=True)
                    if proc.returncode==0 and h(proc.stdout)==expected:contents=proc.stdout;break
            assert contents is not None
            F['permanent/sources/'+expected+'.py']=contents
            pem[label+'.O'+opt]=e
    F['permanent/verified.json']=(json.dumps(pem,indent=2)+'\n').encode()
if cfg.get('supplemental'):
    exec((D/'supp.py').read_text());F['tools/supp.py']=(D/'supp.py').read_bytes()
exec((D/'shutdown.py').read_text())
F['tools/shutdown.py']=(D/'shutdown.py').read_bytes()
if cfg.get('pr'):
    assert re.fullmatch(r'https://github.com/astral-experiments/imre/pull/\d+',cfg['pr'])
    api=json.loads((D/'merged-pr.json').read_bytes())
    assert api['number']==3912 and api['state']=='closed' and api['merged'] is True and api['head_sha']==cfg['tested'] and api['merge_commit_sha']==edge and api['merged_at']
    F['review/merged-pr.json']=(json.dumps(api,indent=2)+'\n').encode()
    def git(*args):return subprocess.check_output(['git','-C','/workspace/scratch/imre',*args])
    patch=git('diff','--no-color','--no-ext-diff',edge+'^1',edge)
    assert patch and b'\0' not in patch
    F['public.patch']=patch
    base=git('merge-base',edge+'^1',cfg['tested']).decode().strip()
    F['guarded.patch']=git('diff','--no-color','--no-ext-diff',base,cfg['tested'])
    assert F['guarded.patch'] and F['guarded.patch']==F['review/guarded.patch'] and F['public.patch']==F['review/public.patch']
    merge_meta=j('review/public-merge.json');assert merge_meta['source_patch_sha256']==h(F['public.patch']) and merge_meta['guarded_patch_sha256']==h(F['guarded.patch'])
    import tempfile,os
    with tempfile.TemporaryDirectory(dir=D) as tmp:
        env=os.environ.copy();env['GIT_INDEX_FILE']=str(Path(tmp)/'check.index')
        repo='/workspace/scratch/imre'
        def index(cmd,patch=None):
            return subprocess.run(['git','-C',repo,*cmd],env=env,input=patch,capture_output=True,check=True).stdout
        index(['read-tree',edge+'^1'])
        index(['apply','--cached','--whitespace=nowarn','-'],F['guarded.patch'])
        tree=index(['write-tree']).decode().strip()
    assert tree==git('rev-parse',edge+'^{tree}').decode().strip(),tree
    F['patch-equivalence.json']=(json.dumps(dict(guarded_head=cfg['tested'],guarded_base=base,public_parent=git('rev-parse',edge+'^1').decode().strip(),tested_patch_sha256=h(F['guarded.patch']),public_patch_sha256=h(F['public.patch']),reproduced_public_tree=tree),indent=2)+'\n').encode()
F['runs.json']=(json.dumps(cfg,indent=2)+'\n').encode()
F['tools/classgate.py']=(D/'classgate.py').read_bytes()


F['early-checkpoint.json']=(D/'baseline-published.json').read_bytes()
for check in ('pack.py','sign.py','final.py'):
    F['tools/release/'+check]=(D/check).read_bytes()
