def regress(label,commit):
    area=f'regression/{label}';add('regression',label)
    matrix=j(area+'/matrix.json');assert len(matrix)==4
    docs={}
    for pair,rc,cases in matrix:
        name,opt=pair.split('.O');ld=area+'/'+pair
        assert name in ('type','bytesio') and opt in ('0','3') and pair not in docs
        sn=j(ld+'/summary.json'); b=check_event(ld,'build')
        assert sn['head']==commit and sn['build_exit']==rc==b['exit'] and cases==sn['cases'] and re.fullmatch('[a-f0-9]{64}',sn['source_sha256'])
        assert b['argv'][b['argv'].index('--opt-level')+1]==opt and '--runtime-imports' not in b['argv']
        src=b['argv'][2];rp='tests/fixtures/io_buffered_writer_'+name+'.py';assert src.endswith('/'+rp)
        code=subprocess.check_output(['git','-C','/workspace/scratch/imre','show',commit+':'+rp]);assert h(code)==sn['source_sha256'];F['regression/sources/'+name+'.py']=code
        if b['exit']!=0:
            assert not cases;docs[pair]=dict(build_exit=rc);continue
        assert re.fullmatch('[a-f0-9]{64}',sn['exe_sha256'])
        assert set(cases)==({'normal','wrong-byte'} if name=='bytesio' else {'normal'})
        for t,data in cases.items():
            ref=check_event(ld,t+'-stock');native=check_event(ld,t+'-native')
            assert ref['argv'][0]==stock['executable'] and native['argv'][0]==b['argv'][b['argv'].index('-o')+1]
            assert ref['exit']==data['stock_exit'] and native['exit']==data['native_exit']
            expected=0 if t=='normal' else 1
            e=(ref['stderr_sha256']==native['stderr_sha256'] if t=='normal' else all(b'AssertionError' in F[ld+'/'+t+'-'+a+'.stderr'] for a in ('stock','native')))
            equal=(e and ref['stdout_sha256']==native['stdout_sha256'])
            assert data['matched']==(ref['exit']==native['exit']==expected and equal),(t,data)
        docs[pair]=dict(cases=cases)
    return docs

