from pathlib import Path
import sys,json,hashlib,subprocess,os,time
from datetime import datetime,timezone
stage,repo,sha=sys.argv[1:]
work=Path(repo); build=Path('/workspace/shared/downloads/cbuffered-writer-class/build');build.mkdir(parents=True,exist_ok=True)
bindir=Path('/workspace/scratch/cbwc-bin-'+stage)
assert not (bindir/'READY').exists()
env=os.environ|dict(CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',RUSTUP_TOOLCHAIN='1.98.0',CARGO_TARGET_DIR='/workspace/scratch/target-io-verified',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0')
env['PATH']='/workspace/.cargo/bin:'+env['PATH']
def git(*args):return subprocess.check_output(['git',*args],cwd=work).decode().strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,cmd):
 start=datetime.now(timezone.utc).isoformat();t=time.monotonic()
 with (build/(stage+'-'+label+'.log')).open('wb') as stream:p=subprocess.run(cmd,cwd=work,env=env,stdout=stream,stderr=subprocess.STDOUT)
 (build/(stage+'-'+label+'.json')).write_text(json.dumps(dict(argv=cmd,cwd=str(work),commit=sha,utc=start,elapsed_s=round(time.monotonic()-t,3),exit=p.returncode),indent=2)+'\n')
 if p.returncode:print((build/(stage+'-'+label+'.log')).read_text()[-2000:]);sys.exit(p.returncode)
assert sha==git('rev-parse','HEAD') and not git('status','--porcelain','--untracked-files=no')
run('clean',['cargo','clean','--offline']+sum((['-p',x.name] for x in sorted((work/'crates').glob('imre-*'))),[]))
run('cargo',['cargo','build','--offline','--locked','-p','imre-compiler','-p','imre-runtime','-j8'])
target=Path(env['CARGO_TARGET_DIR'])/'debug';bindir.mkdir(exist_ok=True)
binaries={}
for name,dep in [('imre','imre.d'),('libimre_runtime.a','libimre_runtime.d')]:
 assert str(work/'crates') in (target/dep).read_text()
 dest=bindir/name;os.link(target/name,dest);binaries[name]=h(dest)
assert sha==git('rev-parse','HEAD') and not git('status','--porcelain','--untracked-files=no')
(build/(stage+'-provenance.json')).write_text(json.dumps(dict(commit=sha,tree=git('rev-parse','HEAD^{tree}'),cwd=str(work),rust_toolchain=env['RUSTUP_TOOLCHAIN'],binaries=binaries),indent=2)+'\n')
(bindir/'READY').write_text(sha+'\n');print('READY',stage,sha,binaries,flush=True)
