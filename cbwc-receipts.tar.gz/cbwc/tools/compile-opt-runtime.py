from pathlib import Path
from datetime import datetime,timezone
import os,json,subprocess,signal,time,hashlib
r=Path('/workspace/scratch'); repo=r/'cbwc-public'; prefix=r/'cbwc-bin-public'; binary=r/'cbwc-bin-public-opt-runtime'
out=Path('/workspace/shared/downloads/cbuffered-writer-class/build')
head=(prefix/'READY').read_text().strip()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
def h(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert len(head)==40 and git('rev-parse','HEAD')==head and not git('status','--porcelain') and not (binary/'READY').exists()
env=os.environ|dict(CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',RUSTUP_TOOLCHAIN='1.98.0',CARGO_TARGET_DIR=str(r/'target-io-verified'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0')
env['PATH']='/workspace/.cargo/bin:'+env['PATH']
cmd=['cargo','rustc','--offline','--locked','-p','imre-runtime','--lib','-j6','--','-Copt-level=2']
record=dict(head=head,argv=cmd,cwd=str(repo),rust_toolchain='1.98.0',rust_profile='dev, imre-runtime crate built with -Copt-level=2',utc=datetime.now(timezone.utc).isoformat())
t=time.monotonic()
record['compiler_nice']=os.nice(3)
with (out/'public-opt-runtime.log').open('wb') as f:
    proc=subprocess.Popen(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    try:record.update(exit=proc.wait(timeout=2400),timed_out=False)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait();record.update(exit=None,timed_out=True)
record['elapsed_s']=round(time.monotonic()-t,2)
(out/'public-opt-runtime-cargo.json').write_text(json.dumps(record,indent=2)+'\n')
assert record['exit']==0,record
target=Path(env['CARGO_TARGET_DIR'])/'debug';dep=target/'libimre_runtime.d'
assert str(repo/'crates/imre-runtime') in dep.read_text()
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
binary.mkdir(exist_ok=True)
os.link(prefix/'imre',binary/'imre');os.link(target/'libimre_runtime.a',binary/'libimre_runtime.a')
hs={n:h(binary/n) for n in ('imre','libimre_runtime.a')}
assert hs['imre']==h(prefix/'imre') and hs['libimre_runtime.a']!=h(prefix/'libimre_runtime.a')
(out/'public-opt-runtime-provenance.json').write_text(json.dumps(dict(commit=head,tree=git('rev-parse','HEAD^{tree}'),binaries=hs,linked_public_compiler=True,depfile_sha256=h(dep),rust_runtime_optimization=2),indent=2)+'\n')
(binary/'READY').write_text(head+'\n');print('public optimized runtime READY',head,hs)
