diag=b'NotImplementedError: BufferedWriter has unflushed bytes at shutdown; explicitly flush or close Python-backed writers'
shutdown=[]
for tag,commit in cfg.get('shutdown',{}).items():
    vm=j('build/'+tag+'-provenance.json');assert vm['commit']==commit
    for o in ('0','3'):
        ld='permanent/shutdown/'+tag+'/O'+o;r=j(ld+'/result.json')
        b=check_event(ld,'build')
        assert r['head']==commit and r['build_exit']==b['exit']==0 and b['argv'][b['argv'].index('--opt-level')+1]==o and '--runtime-imports' not in b['argv']
        assert r['compiler_sha256']==vm['binaries']['imre'] and r['runtime_sha256']==vm['binaries']['libimre_runtime.a']
        checksrc=subprocess.check_output(['git','-C','/workspace/scratch/imre','show',cfg['tested']+':tests/fixtures/io_buffered_writer_shutdown.py'])
        assert h(checksrc)==r['fixture_sha256'];F['permanent/sources/shutdown.py']=checksrc
        assert {c['mode'] for c in r['cases']}=={'close','temporary-close','pending'} and len(r['cases'])==3
        for c in r['cases']:
            mode=c['mode'];observed={}
            for interp,about in [('cpython',c['stock']),('native',c['native'])]:
                stem=interp+'-'+mode; x=check_event(ld,stem);name=ld+'/'+stem+'.bin';p=ROOT/name
                assert p.is_file() and not p.is_symlink() and p.stat().st_size<=3
                actual=p.read_bytes();F[name]=actual
                assert about['exit']==x['exit'] and about['stdout_sha256']==x['stdout_sha256'] and about['stderr_sha256']==x['stderr_sha256']
                assert h(actual)==about['file_sha256'] and len(actual)==about['file_size']
                pending=interp=='native' and mode=='pending'
                expected_exit=int(pending and commit!=cfg['intermediate'])
                assert x['exit']==expected_exit and not x['timed_out'] and actual==(b'' if pending else b'abc')
                if expected_exit:assert diag in F[ld+'/'+stem+'.stderr']
                observed[interp]={'exit':x['exit'],'persisted_ascii':actual.decode()}
            shutdown.append({'stage':tag,'opt':o,'shape':mode,**observed})
F['shutdown-outcomes.json']=(json.dumps(shutdown,indent=2)+'\n').encode()

