"""Validate completed original native unittest rows and record disjoint/overlap sets."""
from collections import Counter
def gateclass(name,commit):
    area='class/'+name
    add('class',name)
    cpmeta=j(area+'/provenance.json')
    assert cpmeta['imre']==commit and cpmeta['registration_sha256']==h(F['registration.tsv']) and cpmeta['runner_sha256']==h(F['class/runner.py'])
    assert cpmeta['projection_sha256']==h(F['class/projection.json'])
    binmeta=[j(k) for k in F if k.startswith('build/') and k.endswith('-provenance.json') and j(k)['commit']==commit]
    assert binmeta and any(b['binaries']=={'imre':cpmeta['compiler_sha256'],'libimre_runtime.a':cpmeta['runtime_sha256']} for b in binmeta)
    ledger=list(csv.DictReader(g(area+'/ledger.tsv'),delimiter='\t'))
    assert len(ledger)==86
    hits={}; stages={}; parsed=set(); records={}
    for mode in ('0','3'):
        lane=area+'/O'+mode
        b=check_event(lane,'build'); argv=b['argv']
        assert argv[argv.index('--opt-level')+1]==mode and '--runtime-imports' not in argv and '--no-cache' in argv
        if b['exit']==0:assert re.fullmatch(r'[a-f0-9]{64}',F[lane+'/program.sha256'].decode().strip())
        if b['exit']!=0:assert lane+'/process.json' not in F
        registered=set(); completed={}
        for idpath in [k for k in F if k.startswith(lane+'/') and k.endswith('/process.json')]:
            e=j(idpath); folder=idpath.rsplit('/',1)[0]; stdout=F[folder+'/'+e['stdout']]
            assert e['stdout_sha256']==h(stdout) and e['stderr_sha256']==h(F[folder+'/'+e['stderr']]) and e['elapsed_s']>=0
            assert e['argv'][0]==argv[argv.index('-o')+1] and set(e['argv'][1:])<=set(ids)
            tags={}; here=set()
            for line in stdout.decode(errors='replace').splitlines():
                t=line.split('\t',2)
                if len(t)!=3:continue
                ev,key,detail=t
                if ev=='REGISTER':
                    assert key in ids and key not in here;here.add(key)
                elif ev in ('START','STOP','PASS','FAIL','ERROR','SUBFAIL','SUBERROR','SKIP'):
                    assert key in ids and key in here; tags.setdefault(key,[]).append((ev,detail))
            for key,evs in tags.items():
                tt=[t[0] for t in evs]
                assert tt.count('START')==1 and tt[0]=='START' and tt.count('STOP')<=1
                if tt[-1]=='STOP':
                    outcomes=[x for x in tt if x in ('ERROR','SUBERROR','FAIL','SUBFAIL','SKIP','PASS')]
                    if outcomes:
                        v='ERROR' if any(x in ('ERROR','SUBERROR') for x in outcomes) else 'FAIL' if any(x in ('FAIL','SUBFAIL') for x in outcomes) else outcomes[0]
                        completed.setdefault(key,set()).add(v)
            assert all(len(statuses)==1 for statuses in completed.values()),(name,mode,completed)
            records[idpath]=(e,tags); registered.update(here)
        counts=Counter(); wins=[]; skipped={}
        lane_rows=[r for r in ledger if r['ordinary_opt']==mode]
        assert [r['id'] for r in lane_rows]==ids
        for oracle,row in zip(reg,lane_rows):
            key=row['id']; ref='class/'+row['raw_receipt'];record=j(ref)
            assert row['raw_receipt_sha256']==h(F[ref]) and row['ordinal_in_667']==oracle['ordinal_in_667'] and row['occurrence']==oracle['occurrence']
            assert row['compiler_exit']==('' if b['exit'] is None else str(b['exit'])) and int(row['native_registered'])==int(key in registered)
            v=row['native_verdict']
            if key in completed:assert v in completed[key],(name,mode,key,v,completed[key])
            if ref in records:
                e,tags=records[ref]; tt=[t[0] for t in tags.get(key,[])]
                assert row['shared_process_exit']==('' if e['exit'] is None else str(e['exit'])) and int(row['timeout'])==int(e['timed_out'])
                if v in ('PASS','FAIL','ERROR','SKIP'):
                    assert tt[0]=='START' and tt[-1]=='STOP'
                    out='ERROR' if 'ERROR' in tt or 'SUBERROR' in tt else 'FAIL' if 'FAIL' in tt or 'SUBFAIL' in tt else 'SKIP' if 'SKIP' in tt else 'PASS' if 'PASS' in tt else 'NO_VERDICT'
                    assert v==out and (v!='PASS' or tt==['START','PASS','STOP'])
                elif v=='UNREACHED':
                    assert not any(key in ts for pn,(_,ts) in records.items() if pn.startswith(lane+'/'))
                else:assert v in ('INTERRUPTED','NO_VERDICT') and key in tags
            else:assert ref==lane+'/build.json' and v=='UNREACHED' and b['exit']!=0
            counts[v]+=1
            if v=='PASS':wins.append(key)
            if v=='SKIP':skipped[key]=row['callback_detail']
        stats=j(area+'/stats.json')['O'+mode];assert stats['outcomes']==dict(counts) and stats['registered']==len(registered)
        stages['O'+mode]=dict(registered=len(registered),outcomes=dict(counts),provider_skips=skipped,passed_ids=wins)
        hits[mode]=set(wins)
    stages['passes_at_both']=sorted(hits['0']&hits['3']);stages['O0_only']=sorted(hits['0']-hits['3']);stages['O3_only']=sorted(hits['3']-hits['0'])
    return stages,ledger

