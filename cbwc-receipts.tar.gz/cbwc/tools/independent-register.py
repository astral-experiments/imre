import hashlib, json, sys, unittest
import io, _io
from pathlib import Path
from test import test_io as m
def flatten(s):
    for e in s:
        if isinstance(e, unittest.TestSuite):
            yield from flatten(e)
        else:
            yield e.id()
suite=unittest.defaultTestLoader.loadTestsFromModule(m)
ids=list(flatten(suite))
ours=[(i,ids[:i].count(k),k) for i,k in enumerate(ids,1) if k.startswith('test.test_io.CBufferedWriterTest.')]
cl=m.CBufferedWriterTest
assert cl.tp is io.BufferedWriter is _io.BufferedWriter
assert len(ids)==667 and len(ours)==43 and all(x[1]==1 for x in ours)
print(json.dumps(dict(cpython=sys.version.split()[0], executable_sha256=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(), source_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(), class_tp='_io.BufferedWriter', setup=cl.setUp.__qualname__,teardown=cl.tearDown.__qualname__,denominator=len(ids), rows=ours),indent=2))

