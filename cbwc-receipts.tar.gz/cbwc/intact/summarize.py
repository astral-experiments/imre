import hashlib,json,sys
from pathlib import Path
here=Path(__file__).resolve().parent
stage=sys.argv[1]
raw=here/'native'/stage
meta=json.loads((raw/'provenance.json').read_text())
def digest(data):return hashlib.sha256(data).hexdigest()
rows=[]
for opt in (0,3):
    label=f'ordinary.O{opt}';file=raw/label/'result.json';r=json.loads(file.read_text());c=r['build'];p=r['process']
    diag=[]
    if p is not None:
        stderr=(here/p['stderr']).read_bytes()
        diag=stderr.decode(errors='replace').strip().splitlines()[-2:]
    rows.append(dict(lane=label,build_exit=c['exit'],build_timeout=c['timed_out'],process_exit=p['exit'] if p else None,process_timeout=p['timed_out'] if p else None,registered=r['observed_id_lines'],denominator=667,methods_run=r['tests_run'],last_diagnostic=diag,result_sha256=digest(file.read_bytes())))
print(json.dumps(dict(commit=meta['imre_commit'],cpython_commit=meta['cpython_commit'],source_sha256=meta['source_sha256']['test/test_io.py'],rows=rows),indent=2))
