"""Measure CPython test_io load_tests without changing the test module or its fixtures."""
import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = Path(os.environ.get("IO_DISC_WORK", "/workspace/scratch/io-buffer-bind-discovery"))
LIB = Path(os.environ.get("CPYTHON_SOURCE", "/workspace/scratch/cpython")) / "Lib"
EXPECTED = "e82addd026e03cd24b66534764472806847401dcffaaa392bab2081fb70cdab4"
ENTRY = "run_intact_discovery.py"

def sha(p):
    with p.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def source_root():
    root = WORK / "Lib"
    root.mkdir(parents=True, exist_ok=True)
    if not (root/"test").exists():
        shutil.copytree(LIB/"test",root/"test",ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    for name in ("_pyio.py","_py_abc.py"):
        if not (root/name).exists():
            shutil.copyfile(LIB/name,root/name)
        assert sha(root/name) == sha(LIB/name)
    assert sha(root/"test/test_io.py") == sha(LIB/"test/test_io.py") == "6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af"
    if not (root/ENTRY).exists():
        shutil.copyfile(HERE/"drivers"/ENTRY,root/ENTRY)
    assert sha(root/ENTRY) == sha(HERE/"drivers"/ENTRY)
    return root

def write(p, x):
    p.write_text(json.dumps(x,indent=2)+"\n")

def run(argv, cwd, env, logs, name, timeout):
    argv = list(map(str, argv))
    start = time.monotonic()
    timeout_hit = False
    try:
        r = subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=timeout)
        rc,out,err = r.returncode,r.stdout,r.stderr
    except subprocess.TimeoutExpired as exc:
        rc,out,err,timeout_hit = None,exc.stdout or b"",exc.stderr or b"",True
    elapsed = round(time.monotonic()-start,6)
    (logs/(name+".stdout")).write_bytes(out)
    (logs/(name+".stderr")).write_bytes(err)
    return {"argv":argv,"cwd":str(cwd),"elapsed_s":elapsed,"exit":rc,"timed_out":timeout_hit,
            "stdout":str((logs/(name+".stdout")).relative_to(HERE)),
            "stderr":str((logs/(name+".stderr")).relative_to(HERE))},out,err

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("label")
    ap.add_argument("bindir",type=Path)
    ap.add_argument("--commit",required=True)
    ap.add_argument("--jobs",type=int,default=2)
    ap.add_argument("--lane",choices=("ordinary.O0","ordinary.O3","boxed.O0","boxed.O3"))
    ap.add_argument("--timeout",type=int,default=420)
    a=ap.parse_args()
    root=source_root()
    out=HERE/"native"/a.label
    out.mkdir(parents=True,exist_ok=True)
    bin=a.bindir.resolve()
    assert (bin/"READY").read_text().strip() == a.commit
    imre,runtime=bin/"imre",bin/"libimre_runtime.a"
    clang=os.environ.get("CLANG","/workspace/scratch/tools/clang")
    env={k:v for k,v in os.environ.items() if k not in ("IMREFLAGS","IMRE_ENCODED_FLAGS","PYTHONPATH")}
    provenance = dict(imre_commit=a.commit,compiler=str(imre),compiler_sha256=sha(imre),runtime=str(runtime),runtime_sha256=sha(runtime),cpython_commit="5607950ef232dad16d75c0cf53101d9649d89115",source_sha256={name:sha(root/name) for name in ("test/test_io.py","_pyio.py",ENTRY,"test/support/__init__.py","test/support/os_helper.py","test/support/threading_helper.py")},expected_ordered_ids_sha256=EXPECTED)
    if (out/"provenance.json").exists():
        assert json.loads((out/"provenance.json").read_text()) == provenance
    else:
        write(out/"provenance.json",provenance)
    def measure(job):
        mode,level=job
        label=f"{mode}.O{level}"
        logs=out/label
        logs.mkdir(exist_ok=True)
        work=Path(os.environ.get("IO_DISC_RUN_ROOT",WORK))/a.label/label
        work.mkdir(parents=True,exist_ok=True)
        exe=work/"driver"
        exe.unlink(missing_ok=True)
        build=[imre,"build",root/ENTRY,"--module-root",root,"--no-cache","--runtime",runtime,
               "--clang",clang,"--opt-level",level,"-o",exe]
        if mode=="boxed":
            build.append("--runtime-imports")
        local_env={**env,"TMPDIR":str(work)}
        compiler,_,err=run(build,work,local_env,logs,"build",a.timeout)
        record=dict(mode=mode, level=level,build=compiler,process=None,discovery_complete=False,
                    observed_id_lines=0,ordered_ids_sha256=None,tests_run=0,scope="discovery")
        print(a.label,label,"build",compiler["exit"],compiler["elapsed_s"],err.decode(errors="replace").splitlines()[-2:],flush=True)
        if compiler["exit"] == 0:
            record["executable_sha256"]=sha(exe)
            proc,data,err=run([exe],work,local_env,logs,"process",a.timeout)
            record["process"]=proc
            lines=data.decode(errors="replace").splitlines()
            ids=[line.removeprefix("IMRE_IO_ID ") for line in lines if line.startswith("IMRE_IO_ID ")]
            record["observed_id_lines"]=len(ids)
            if ids:
                order=("\n".join(ids)+"\n").encode()
                (logs/"observed.ids").write_bytes(order)
                record["ordered_ids_sha256"]=hashlib.sha256(order).hexdigest()
            count=[line for line in lines if line.startswith("IMRE_IO_DISCOVERED ")]
            record["discovery_complete"]=proc["exit"]==0 and count==[f"IMRE_IO_DISCOVERED {len(ids)}"] and record["ordered_ids_sha256"]==EXPECTED
            print(a.label,label,"process",proc["exit"],proc["elapsed_s"],"discovered",len(ids),err.decode(errors="replace").splitlines()[-2:],flush=True)
            exe.unlink()
        write(logs/"result.json",record)
        return record
    jobs=[("ordinary",l) for l in (0,3)]
    if a.lane:
        jobs=[(a.lane.split(".O")[0],int(a.lane[-1]))]
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:
        rows=list(pool.map(measure,jobs))
    if not a.lane:
        write(out/"runs.json",rows)

if __name__=="__main__":
    main()

