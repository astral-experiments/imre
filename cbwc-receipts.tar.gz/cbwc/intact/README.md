# Intact test_io discovery

The original CPython 3.14.5 module and loader run independently of the 43-method CBufferedWriterTest projection. The driver invokes unittest discovery and emits each ID. It executes zero methods.

Stock 3.14.5 registered 667 IDs on this executor. The ordered ID list has SHA-256 e82addd026e03cd24b66534764472806847401dcffaaa392bab2081fb70cdab4. The checksum is over each canonical ID plus a newline, in registration order. [Stock stdout](native/cpython/process.stdout) · [Stock provenance and exit](native/cpython/result.json)

Native ordinary O0 and O3 pass the unchanged original test module to the default Imre compiler with no cache. Each mode has independent compiler argv, elapsed time and exit status, executable hash, and native process streams and status. [Raw runs](native)

The separate seven-module campaign denominator of 1,038 includes these 667. The earlier #3673 campaign measured 371/1,038 registrations. The present intact measurement is scoped to the one 667-ID submodule.
