import argparse
import hashlib
import json
import os
import resource
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=Path('/workspace/scratch/cbwc-callback/forwarding')
PY=Path('/workspace/scratch/cpytools/bin/python3.14')
PIN='5607950ef232dad16d75c0cf53101d9649d89115'
CLANG='/workspace/scratch/tools/clang'
CASES=('correct','wrong_bytes')
SOURCE=HERE/'forward.py'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(path, obj):
    path.write_text(json.dumps(obj,indent=2)+'\n')
def run(argv, cwd, dest, stem, extra=None):
    env={k:v for k,v in os.environ.items() if not k.startswith(('PYTHON','IMRE'))}
    env.update(TMPDIR=str(cwd), **(extra or {}))
    argv=list(map(str,argv))
    record={'argv':argv,'cwd':str(cwd),'env_overrides':{k:env[k] for k in ('TMPDIR',*(extra or ())) }}
    t=time.monotonic()
    with (dest/(stem+'.stdout')).open('wb') as out,(dest/(stem+'.stderr')).open('wb') as err:
        try:
            p=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=err,timeout=1300 if stem=='build' else 45)
            record.update(exit=p.returncode,timed_out=False)
        except subprocess.TimeoutExpired:
            record.update(exit=None,timed_out=True)
    record['elapsed_s']=round(time.monotonic()-t,3)
    for name in ('stdout','stderr'):
        record[name+'_sha256']=sha(dest/(stem+'.'+name))
    save(dest/(stem+'.json'),record)
    return record
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('label');parser.add_argument('--bindir',type=Path);parser.add_argument('--commit');parser.add_argument('--jobs',type=int,default=2)
    a=parser.parse_args();ref=a.label=='reference';dest=HERE/a.label
    assert not dest.exists(),dest
    if not ref:assert a.bindir and (a.bindir/'READY').read_text().strip()==a.commit
    dest.mkdir(); prov=dict(source_sha256=sha(SOURCE),cpython_commit=PIN,reference_binary=str(PY),reference_binary_sha256=sha(PY))
    if not ref:
        imre=a.bindir/'imre';rt=a.bindir/'libimre_runtime.a'
        prov.update(imre_commit=a.commit,compiler=str(imre),runtime=str(rt),compiler_sha256=sha(imre),runtime_sha256=sha(rt))
    save(dest/'provenance.json',prov)
    def runlane(lane):
        d=dest/lane;d.mkdir(exist_ok=True)
        w=WORK/a.label/lane;w.mkdir(parents=True,exist_ok=True)
        build=None
        if not ref:
            exe=w/'program'
            b=run([imre,'build',SOURCE,'--no-cache','--runtime',rt,'--clang',CLANG,'--opt-level',lane[-1],'-o',exe],w,d,'build')
            build=b['exit']
            if build!=0:return [{'lane':lane,'case':name,'build_exit':build,'process_exit':None,'phase':'BUILD_TIMEOUT' if b['timed_out'] else 'BUILD_ERROR'} for name in CASES]
            (d/'program.sha256').write_text(sha(exe)+'\n')
        rows=[]
        for name in CASES:
            cd=d/name;cd.mkdir()
            cwd=w/name;cwd.mkdir(exist_ok=True)
            if ref:
                result=run([PY,'-B','-X','frozen_modules=off',SOURCE,name],cwd,cd,'process',{'PYTHONPATH':'/workspace/scratch/cpython/Lib'})
                match=None
            else:
                result=run([exe,name],cwd,cd,'process')
                oracle=HERE/'reference'/name
                refexit=json.loads((oracle/'process.json').read_text())['exit']
                so=(cd/'process.stdout').read_bytes()==(oracle/'process.stdout').read_bytes()
                if name=='wrong_bytes':
                    se=all('AssertionError: deliberate wrong-byte control' in (t/'process.stderr').read_text() for t in [cd,oracle])
                else:
                    se=(cd/'process.stderr').read_bytes()==(oracle/'process.stderr').read_bytes()
                match=result['exit']==refexit and so and se
            rows.append(dict(lane=lane,case=name,build_exit=build,process_exit=result['exit'],process_timeout=result['timed_out'],matches_reference=match))
            print(a.label,lane,name,'build',build,'process',result['exit'],'match',match,flush=True)
        return rows
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:
        rows=[r for group in pool.map(runlane,[''] if ref else ['ordinary.O0','ordinary.O3']) for r in group]
    save(dest/'summary.json',rows)
if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    main()

