from _io import BufferedWriter, FileIO
import io
import os
import sys

class Forward(io.RawIOBase):
    def __init__(self, target):
        self.target = target
        self.chunks = []

    def writable(self):
        return True

    def tell(self):
        return self.target.tell()

    def write(self, view):
        assert type(view) is memoryview and view.readonly
        self.chunks.append(bytes(view))
        return self.target.write(view)

    def close(self):
        super().close()
        self.target.close()


def disk_bytes(path):
    with FileIO(path, 'rb') as reader:
        return reader.read()


def run(expected):
    path = 'forward.bin'
    try:
        with FileIO(path, 'wb') as target:
            raw = Forward(target)
            writer = BufferedWriter(raw, 8)
            assert writer.raw is raw
            assert raw.target is target and isinstance(target, FileIO)
            assert writer.write(b'abc') == 3
            pending = disk_bytes(path)
            print('pending', pending, raw.chunks)
            assert pending == b'' and not raw.chunks
            writer.flush()
            flushed = disk_bytes(path)
            print('flushed', flushed, raw.chunks)
            assert flushed == b'abc' and raw.chunks == [b'abc']
            assert writer.write(b'd') == 1
            assert disk_bytes(path) == b'abc'
            writer.close()
            assert target.closed and raw.closed and writer.closed
        closed = disk_bytes(path)
        print('closed', closed, raw.chunks)
        assert raw.chunks == [b'abc', b'd']
        assert closed == expected, 'deliberate wrong-byte control'
    finally:
        os.unlink(path)


if __name__ == '__main__':
    if sys.argv[1] == 'correct':
        run(b'abcd')
    elif sys.argv[1] == 'wrong_bytes':
        run(b'abce')
    else:
        raise SystemExit('unknown control')
