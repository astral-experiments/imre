import _io
import io
import os
import sys

import importlib


class MockRawIOWithoutRead:
    """A RawIO implementation without read(), so as to exercise the default
    RawIO.read() which calls readinto()."""

    def __init__(self, read_stack=()):
        self._read_stack = list(read_stack)
        self._write_stack = []
        self._reads = 0
        self._extraneous_reads = 0

    def write(self, b):
        self._write_stack.append(bytes(b))
        return len(b)

    def writable(self):
        return True

    def fileno(self):
        return 42

    def readable(self):
        return True

    def seekable(self):
        return True

    def seek(self, pos, whence):
        return 0   # wrong but we gotta return something

    def tell(self):
        return 0   # same comment as above

    def readinto(self, buf):
        self._reads += 1
        max_len = len(buf)
        try:
            data = self._read_stack[0]
        except IndexError:
            self._extraneous_reads += 1
            return 0
        if data is None:
            del self._read_stack[0]
            return None
        n = len(data)
        if len(data) <= max_len:
            del self._read_stack[0]
            buf[:n] = data
            return n
        else:
            buf[:] = data[:max_len]
            self._read_stack[0] = data[max_len:]
            return max_len

    def truncate(self, pos=None):
        return pos


class MockRawIO(MockRawIOWithoutRead):

    def read(self, n=None):
        self._reads += 1
        try:
            return self._read_stack.pop(0)
        except:
            self._extraneous_reads += 1
            return b""


class CMockRawIO(MockRawIO, io.RawIOBase):
    pass


class MisbehavedRawIO(MockRawIO):
    def write(self, b):
        return super().write(b) * 2

    def read(self, n=None):
        return super().read(n) * 2

    def seek(self, pos, whence):
        return -123

    def tell(self):
        return -456

    def readinto(self, buf):
        super().readinto(buf)
        return len(buf) * 5


class CMisbehavedRawIO(MisbehavedRawIO, io.RawIOBase):
    pass


class MockNonBlockWriterIO:

    def __init__(self):
        self._write_stack = []
        self._blocker_char = None

    def pop_written(self):
        s = b"".join(self._write_stack)
        self._write_stack[:] = []
        return s

    def block_on(self, char):
        """Block when a given char is encountered."""
        self._blocker_char = char

    def readable(self):
        return True

    def seekable(self):
        return True

    def seek(self, pos, whence=0):
        # naive implementation, enough for tests
        return 0

    def writable(self):
        return True

    def write(self, b):
        b = bytes(b)
        n = -1
        if self._blocker_char:
            try:
                n = b.index(self._blocker_char)
            except ValueError:
                pass
            else:
                if n > 0:
                    # write data up to the first blocker
                    self._write_stack.append(b[:n])
                    return n
                else:
                    # cancel blocker and indicate would block
                    self._blocker_char = None
                    return None
        self._write_stack.append(b)
        return len(b)


class CMockNonBlockWriterIO(MockNonBlockWriterIO, io.RawIOBase):
    BlockingIOError = io.BlockingIOError

def rejects(exception, callback, *args):
    try:
        callback(*args)
    except exception:
        print('REJECT', exception.__name__)
        return
    raise AssertionError('missing rejection')


def disk():
    with io.FileIO('output.bin', 'wb') as raw:
        writer = _io.BufferedWriter(raw, 8)
        assert writer.raw is raw
        assert type(writer) is io.BufferedWriter
        assert writer.write(b'abc') == 3
        assert raw.tell() == 0
        print('DISK pending', raw.tell())
        writer.flush()
        assert raw.tell() == 3
        assert writer.write(b'd') == 1
        writer.close()
        assert writer.closed and raw.closed
    with io.FileIO('output.bin', 'rb') as raw:
        data = raw.read()
    print('DISK persisted', data)
    return data


def controls():
    assert disk() == b'abcd'
    with io.FileIO('output.bin', 'rb') as ro:
        rejects(io.UnsupportedOperation, _io.BufferedWriter, ro, 8)
    with io.FileIO('output.bin', 'wb') as raw:
        writer = _io.BufferedWriter(raw, 8)
        rejects(TypeError, writer.write, 'text')
        rejects(TypeError, _io.BufferedWriter.write, object(), b'z')
        writer.close()
        rejects(ValueError, writer.write, b'x')
    os.unlink('output.bin')


def wrong_bytes():
    data = disk()
    os.unlink('output.bin')
    assert data == b'abce', 'deliberate wrong-byte control'


def mock():
    raw = CMockRawIO()
    print('MOCK writable', raw.writable())
    writer = _io.BufferedWriter(raw, 8)
    print('MOCK retained', writer.raw is raw)
    assert writer.raw is raw
    assert writer.write(b'ab') == 2
    chunk = bytearray(b'cd')
    assert writer.write(chunk) == 2
    chunk[:] = b'XX'
    assert raw._write_stack == []
    writer.flush()
    print('MOCK flushed', raw._write_stack)
    assert raw._write_stack == [b'abcd']
    assert writer.write(b'ef') == 2
    writer.close()
    print('MOCK closed', raw.closed, raw._write_stack)
    assert raw.closed and writer.closed
    assert raw._write_stack == [b'abcd', b'ef']


class TraceRaw(CMockRawIO):
    def writable(self):
        print('CALL writable')
        return True

    def tell(self):
        print('CALL tell')
        return 0

    def write(self, data):
        print('CALL write', type(data).__name__, data.readonly, bytes(data))
        assert type(data) is memoryview
        assert data.readonly is True
        return super().write(data)

    def close(self):
        print('CALL close')
        super().close()


def traced():
    raw = TraceRaw()
    writer = _io.BufferedWriter(raw, 4)
    assert writer.raw is raw
    assert writer.write(b'hello') == 5
    assert writer.write(b'!') == 1
    writer.close()
    print('TRACE bytes', b''.join(raw._write_stack))
    assert b''.join(raw._write_stack) == b'hello!'


def overcount():
    raw = CMisbehavedRawIO()
    writer = _io.BufferedWriter(raw, 2)
    rejects(OSError, writer.write, b'xyz')
    print('OVERCOUNT sink', raw._write_stack)
    writer.close()


def nonblocking():
    raw = CMockNonBlockWriterIO()
    writer = _io.BufferedWriter(raw, 4)
    raw.block_on(b'c')
    assert writer.write(b'abcdef') == 6
    print('PARTIAL sink', raw._write_stack)
    assert b''.join(raw._write_stack) == b'ab'
    raw.block_on(b'c')
    rejects(BlockingIOError, writer.flush)
    writer.flush()
    data = raw.pop_written()
    print('RETRY sink', data)
    assert data == b'abcdef'
    writer.close()


if __name__ == '__main__':
    assert importlib.import_module('_io').BufferedWriter is io.BufferedWriter
    case = sys.argv[1]
    if case == 'mock':
        mock()
    elif case == 'traced':
        traced()
    elif case == 'controls':
        controls()
    elif case == 'wrong_bytes':
        wrong_bytes()
    elif case == 'overcount':
        overcount()
    elif case == 'nonblocking':
        nonblocking()
    else:
        raise SystemExit('unknown probe ' + case)

