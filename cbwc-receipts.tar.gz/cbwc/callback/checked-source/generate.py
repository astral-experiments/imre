import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
upstream = Path('/workspace/scratch/cpython/Lib/test/test_io.py')
src = upstream.read_bytes()
assert hashlib.sha256(src).hexdigest() == '6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
lines = src.splitlines(keepends=True)
classes = ('MockRawIOWithoutRead', 'MockRawIO', 'CMockRawIO', 'MisbehavedRawIO', 'CMisbehavedRawIO', 'MockNonBlockWriterIO', 'CMockNonBlockWriterIO')
nodes = {n.name:n for n in ast.parse(src).body if isinstance(n,ast.ClassDef)}
header = (root/'imports.py.txt').read_bytes()
output = [header]
info = {}
for name in classes:
    n = nodes[name]
    segment = b''.join(lines[n.lineno-1:n.end_lineno])
    info[name] = dict(start=n.lineno, end=n.end_lineno, sha256=hashlib.sha256(segment).hexdigest())
    output += [b'\n\n', segment]
output += [(root/'body.py.txt').read_bytes()]
code = b''.join(output)
(root/'probes.py').write_bytes(code)
(root/'inputs.json').write_text(json.dumps(dict(cpython_pin='5607950ef232dad16d75c0cf53101d9649d89115',upstream=str(upstream),upstream_sha256=hashlib.sha256(src).hexdigest(),classes=info,source_sha256=hashlib.sha256(code).hexdigest()),indent=2)+'\n')

