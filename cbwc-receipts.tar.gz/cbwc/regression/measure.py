from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from datetime import datetime, timezone
import json, subprocess, sys, time
stage,repo,head=sys.argv[1:4]
subset=sys.argv[4:]
work=Path('/workspace/scratch/cbwc-regress')/stage
out=Path('/workspace/shared/downloads/cbuffered-writer-class/regression')/stage
bindir=Path('/workspace/scratch/cbwc-bin-'+stage)
assert (bindir/'READY').read_text().strip()==head
repo=Path(repo)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
cpy=Path('/workspace/scratch/cpytools/bin/python3.14')
def hashfile(p):return sha256(p.read_bytes()).hexdigest()
def call(where,folder,name,args):
    t=time.monotonic();timestamp=datetime.now(timezone.utc).isoformat()
    event=dict(argv=list(map(str,args)),cwd=str(where),utc=timestamp,timed_out=False)
    paths=[folder/(name+'.'+ext) for ext in ('stdout','stderr')]
    with paths[0].open('wb') as stdout, paths[1].open('wb') as stderr:
        try: event['exit']=subprocess.run(args,cwd=where,stdout=stdout,stderr=stderr,timeout=(1800 if name=="build" else 500)).returncode
        except subprocess.TimeoutExpired:event.update(exit=None,timed_out=True)
    event.update(elapsed_s=round(time.monotonic()-t,3),stdout_sha256=hashfile(paths[0]),stderr_sha256=hashfile(paths[1]))
    (folder/(name+'.json')).write_text(json.dumps(event,indent=2)+'\n');return event
def run(job):
    fixture,opt=job
    source=repo/'tests/fixtures'/('io_buffered_writer_'+fixture+'.py')
    folder=out/(fixture+'.O'+str(opt));where=work/(folder.name+('-retry' if subset else ''))
    folder.mkdir(exist_ok=False,parents=True);where.mkdir(exist_ok=True,parents=True)
    exe=where/'program'
    build=call(where,folder,'build',[bindir/'imre','build',source,'--no-cache','--runtime',bindir/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','--opt-level',str(opt),'-o',exe])
    summary=dict(head=head,source_sha256=hashfile(source),build_exit=build['exit'],cases={})
    if not build['exit'] and not build['timed_out']:
        summary['exe_sha256']=hashfile(exe)
        for name,arg,expected in ([('normal',[],0),('wrong-byte',['--invert'],1)] if fixture=='bytesio' else [('normal',[],0)]):
            stock=call(where,folder,name+'-stock',[cpy,'-B',source,*arg])
            native=call(where,folder,name+'-native',[exe,*arg])
            if name=='normal':same=all(stock[k]==native[k] for k in ('stdout_sha256','stderr_sha256'))
            else:same=all(b'AssertionError' in (folder/(name+'-'+e+'.stderr')).read_bytes() for e in ('stock','native'))
            summary['cases'][name]=dict(stock_exit=stock['exit'],native_exit=native['exit'],matched=bool(same and native['exit']==stock['exit']==expected))
        exe.unlink()
    (folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    return [folder.name,summary['build_exit'],summary['cases']]
jobs=[(name,opt) for opt in (0,3) for name in ('type','bytesio')]
if subset:jobs=[(name,opt) for name,opt in jobs if name+'.O'+str(opt) in subset]
with ThreadPoolExecutor(2) as tp: list(tp.map(run,jobs))
rows=[]
for d in sorted(out.glob('*.O?')):
    summary=json.loads((d/'summary.json').read_bytes()); rows.append([d.name,summary['build_exit'],summary['cases']])
(out/'matrix.json').write_text(json.dumps(rows,indent=2)+'\n')
print(rows)
