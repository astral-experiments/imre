from pathlib import Path
from hashlib import sha256
import csv,json,sys
root=Path(__file__).resolve().parent
stage=sys.argv[1];dest=root/stage;old=root/'old-6f29a0d'
def events(folder):
    result=json.loads((folder/'results.json').read_text())
    checks={}
    for item in result:
        case=item['case'];f=folder/case;d=json.loads(f.with_suffix('.json').read_text())
        stdout=f.with_suffix('.stdout').read_bytes();stderr=f.with_suffix('.stderr').read_bytes();file=f.with_suffix('.file').read_bytes()
        assert sha256(stdout).hexdigest()==d['stdout_sha256'] and sha256(stderr).hexdigest()==d['stderr_sha256']
        assert stdout.decode()==item['stdout'] and stderr.decode()==item['stderr'] and file.hex()==item['file_hex'] and d['exit']==item['exit']
        assert not d['timed_out'];checks[case]=dict(exit=d['exit'],stdout=stdout,stderr=stderr,file=file)
    return checks
ref=events(root/'reference'/'stock'); out=csv.writer(sys.stdout,delimiter='\t',lineterminator='\n')
out.writerow(['case','opt','reference_exit','reference_file_hex','original_exit','original_file_hex','guard_exit','guard_file_hex','shutdown_diagnostic','python_post_atexit_hook','raw_receipt_sha256'])
for o in (0,3):
    label=f'ordinary.O{o}'; prev=events(old/label);now=events(dest/label)
    assert set(ref)==set(now)==set(prev) and len(now)==10
    for case,r in ref.items():
        n=now[case];p=prev[case];raw=(dest/label/(case+'.json')).read_bytes()
        out.writerow([case,o,r['exit'],r['file'].hex(),p['exit'],p['file'].hex(),n['exit'],n['file'].hex(),int(b'unflushed bytes at shutdown' in n['stderr']),int(b'HOOK closed after atexit' in n['stdout']),sha256(raw).hexdigest()])
