"""The same argv and stored writer state can mean different things at shutdown."""
import sys, os
from _io import BufferedWriter, FileIO
class Raw:
    def __init__(self, path, flag):
        self.fp=FileIO(path, 'w')
        self.flag=flag
    def writable(self):return True
    def tell(self):return self.fp.tell()
    @property
    def closed(self):
        return self.fp.closed or (sys.is_finalizing() and os.path.exists(self.flag))
    def close(self):self.fp.close()
    def write(self, buf):return self.fp.write(buf)
w=BufferedWriter(Raw(sys.argv[1],sys.argv[2]),8)
w.write(b'ABC')
