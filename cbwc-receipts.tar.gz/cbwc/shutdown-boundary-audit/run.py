import concurrent.futures, hashlib, importlib.util, json, os, sys
from pathlib import Path
here=Path(__file__).resolve().parent;sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('review_runner',here.parent/'independent/run.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
cases=('untouched','raw_closed','native_base_closed','raw_then_explicit','close_flush_fails','raw_discards','old_bytesio','flushed','closed','no_python_at_exit')
stage=sys.argv[1]; src=here/'audit.py'; dest=here/stage;dest.mkdir(exist_ok=True)
if stage!='reference':
  b=Path(sys.argv[2]);commit=sys.argv[3];assert (b/'READY').read_text().strip()==commit
  (dest/'meta.json').write_text(json.dumps(dict(commit=commit,source_sha256=h.digest(src),compiler_sha256=h.digest(b/'imre'),runtime_sha256=h.digest(b/'libimre_runtime.a')),indent=2)+'\n')
def lane(l):
  loc=dest/l;wd=Path('/workspace/scratch/cbwc-intact/review/boundary')/stage/l;wd.mkdir(exist_ok=True,parents=True)
  exe=wd/'probe'
  if l=='stock':
    cmd=[h.PY,'-B',src]
  else:
    build=h.run([b/'imre','build',src,'--no-cache','--runtime',b/'libimre_runtime.a','--clang',h.GG,'--opt-level',l[-1],'-o',exe],wd,loc/'build',1200)
    if build['exit']!=0:return
    (loc/'program.sha256').write_text(h.digest(exe)+'\n');cmd=[exe]
  rows=[]
  for tag in cases:
    sink=wd/(tag+'.tmp');sink.unlink(missing_ok=True)
    p=h.run([*cmd,tag,sink],wd,loc/tag,45)
    data=sink.read_bytes() if sink.exists() else None
    if data is not None:(loc/(tag+'.file')).write_bytes(data)
    rows.append(dict(case=tag,exit=p['exit'],timed_out=p['timed_out'],file_hex=data.hex() if data is not None else None,stdout=(loc/(tag+'.stdout')).read_text(),stderr=(loc/(tag+'.stderr')).read_text()))
  (loc/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
  if exe.exists():exe.unlink()
  print(stage,l,[(row['case'],row['exit'],row['file_hex']) for row in rows],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lane,('stock',) if stage=='reference' else ('ordinary.O0','ordinary.O3')))
