"""Classify live callback-backed writer shutdown separately from explicit flush/close."""
import sys
import atexit
from _io import BufferedWriter, FileIO, BytesIO
from io import RawIOBase

class Raw:
    def __init__(self, path, tag):
        self.fp = FileIO(path, 'w')
        self.tag = tag
        self.after_exit = False
    def writable(self):
        return True
    def tell(self):
        return self.fp.tell()
    @property
    def closed(self):
        if self.after_exit:
            print('HOOK closed after atexit')
        return self.fp.closed
    def write(self, buf):
        if self.tag == 'close_flush_fails':
            raise ValueError('raw failed')
        if self.tag == 'raw_discards':
            return len(buf)
        return self.fp.write(buf)
    def close(self):
        return self.fp.close()
    def after(self):
        self.after_exit = True

class BaseRaw(RawIOBase):
    def __init__(self, path):
        self.fp = FileIO(path, 'w')
    def writable(self):
        return True
    def tell(self):
        return self.fp.tell()
    def write(self, buf):
        return self.fp.write(buf)

tag, path = sys.argv[1], sys.argv[2]
if tag == 'old_bytesio':
    with FileIO(path, 'w') as marker:
        pass
    raw = BytesIO()
elif tag == 'native_base_closed':
    raw = BaseRaw(path)
else:
    raw = Raw(path, tag)
w = BufferedWriter(raw,8)
w.write(b'ABC')
if tag in ('raw_closed', 'native_base_closed'):
    atexit.register(raw.close)
elif tag == 'raw_then_explicit':
    raw.close()
    w.close()
elif tag == 'close_flush_fails':
    try:
        w.close()
    except ValueError:
        print('caught', raw.closed)
elif tag == 'flushed':
    w.flush()
elif tag == 'closed':
    w.close()
elif tag == 'no_python_at_exit':
    atexit.register(raw.after)
