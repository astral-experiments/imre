from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, sys, time
R=Path(__file__).resolve().parent
W=Path('/workspace/scratch/cbwc-oracle-review/shutdown-guard')
source=R/'shutdown_guard.py';pys=Path('/workspace/scratch/cpytools/bin/python3.14')
stage=sys.argv[1];target=R/stage;target.mkdir(exist_ok=True)
cases=('normal','override-close','override-flush','override-del','resurrected','detached','nothing-pending','two-aliases','exit37')
def h(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
meta={'source_sha256':h(source),'cpython_pin':'5607950ef232dad16d75c0cf53101d9649d89115','cpython_sha256':h(pys)}
if stage!='stock':
 b=Path(sys.argv[2]); sha=sys.argv[3]; assert (b/'READY').read_text().strip()==sha;meta.update(imre_head=sha,imre_sha256=h(b/'imre'),runtime_sha256=h(b/'libimre_runtime.a'))
save(target/'provenance.json',meta)
def run(tag,argv,path,working,deadline=50):
    argv=list(map(str,argv));start=time.monotonic()
    env=os.environ.copy();env['TMPDIR']=str(working);env['PYTHONDONTWRITEBYTECODE']='1'
    for key in ('IMREFLAGS','IMRE_ENCODED_FLAGS','PYTHONPATH'):env.pop(key,None)
    if stage=='stock':env['PYTHONPATH']='/workspace/scratch/cpython/Lib'
    out=path/(tag+'.stdout');err=path/(tag+'.stderr')
    with out.open('wb') as so,err.open('wb') as se:
        try:p=subprocess.run(argv,cwd=working,env=env,stdout=so,stderr=se,timeout=deadline);rc=p.returncode;expired=False
        except subprocess.TimeoutExpired:rc=None;expired=True
    save(path/(tag+'.json'),{'argv':argv,'cwd':str(working),'exit':rc,'timed_out':expired,'elapsed_s':round(time.monotonic()-start,3),'stdout_sha256':h(out),'stderr_sha256':h(err)})
    return rc
def lane(level):
    lv='stock' if level is None else f'O{level}'; dest=target/lv;dest.mkdir(exist_ok=True)
    working=W/stage/lv;working.mkdir(parents=True,exist_ok=True)
    exe=working/'program'
    if level is not None:
        if run('build',[b/'imre','build',source,'--no-cache','--runtime',b/'libimre_runtime.a','--clang','/workspace/scratch/tools/clang','--opt-level',level,'-o',exe],dest,working,600)!=0:return
        (dest/'exe.sha256').write_text(h(exe)+'\n')
    for name in cases:
        dest2=dest/name;dest2.mkdir(exist_ok=True);cwd=working/name;cwd.mkdir(exist_ok=True);rc=run('process',[pys,'-B',source,name] if level is None else [exe,name],dest2,cwd)
        sink=cwd/'sink.bin';save(dest2/'sink.json',{'exists':sink.exists(),'hex':sink.read_bytes().hex() if sink.exists() else None})
        print(stage,lv,name,rc,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lane,[None] if stage=='stock' else [0,3]))
