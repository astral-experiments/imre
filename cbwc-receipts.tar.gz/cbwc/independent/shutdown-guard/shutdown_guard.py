"""Process-exit state of genuine callback-backed BufferedWriter variants."""
import gc
import io
import sys

class Raw(io.RawIOBase):
    def __init__(self):
        self.sink = io.FileIO("sink.bin", "wb")
    def writable(self):
        return True
    def write(self, view):
        return self.sink.write(view)
    def close(self):
        self.sink.close()
        super().close()

class Declines(io.BufferedWriter):
    def __del__(self):
        pass

saved = []
class Resurrect(io.BufferedWriter):
    def __del__(self):
        saved.append(self)

def decline():
    pass

def make_resurrected(raw):
    stream = Resurrect(raw,4)
    stream.write(b"abc")

mode = sys.argv[1]
raw = Raw()
if mode == "resurrected":
    make_resurrected(raw)
    gc.collect()
    assert len(saved)==1 and not saved[0].closed
    print("resurrected")
else:
    p = Declines(raw,4) if mode=="override-del" else io.BufferedWriter(raw,4)
    if mode=="override-close":
        p.close = decline
    if mode=="override-flush":
        p.flush = decline
    if mode=="two-aliases":
        alias = p
    assert p.write(b"abcd" if mode=="nothing-pending" else b"abc") in (3,4)
    if mode=="detached":
        assert p.detach() is raw
    if mode=="exit37":
        sys.exit(37)
    print("armed",mode)
