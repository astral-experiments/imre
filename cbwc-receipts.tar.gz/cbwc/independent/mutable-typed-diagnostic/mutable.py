"""Separate native support-boundary evidence for mutable input to a Python raw writer."""
import array
import io
import sys
class Raw:
    def __init__(self):
        self.events = []
        self.sink = []
        self.source = None
        self.replacement = b""
        self.shut = False
    def writable(self):
        self.events.append("writable")
        return True
    @property
    def closed(self):
        self.events.append("closed")
        return self.shut
    def tell(self):
        self.events.append("tell")
        return 0
    def write(self, view):
        self.events.append("write")
        if self.source is not None:
            try:
                self.source.append(1)
            except BufferError:
                self.events.append("resize rejected")
            else:
                raise AssertionError("resized exported input during callback")
            self.source[:] = self.replacement
            self.source = None
        self.sink.append(bytes(view))
        return len(view)
    def close(self):
        self.shut = True

def check(mode):
    r = Raw()
    w = io.BufferedWriter(r,4)
    small = mode == 'small-overflow'
    b = bytearray(b'XY' if small else b'ABCD' if mode=='exact' else b'ABCDE')
    original = b'abc' if small else b'pq'
    if mode != 'empty':
        assert w.write(original) == len(original)
    r.events.clear()
    if small or mode == 'large':
        r.source = b
        r.replacement = b'mn' if small else b'VWXYZ'
    v = memoryview(b) if mode == 'memoryview' else array.array('B',b) if mode == 'array' else b
    try:
        returned = w.write(v)
    except NotImplementedError as exc:
        print('unsupported', str(exc), 'events', r.events, 'sink', r.sink)
        assert not small and r.events == [] and r.sink == []
        r.source = None
        w.flush()
        assert r.sink == ([] if mode == 'empty' else [original])
        print('after flush',r.sink)
    else:
        assert returned == len(v)
        w.flush()
        expected = (b'' if mode == 'empty' else original) + bytes(v)
        assert b''.join(r.sink) == expected
        print('accepted', returned,'events', r.events, 'sink', r.sink)
    w.close()
check(sys.argv[1])
