"""Verify raw independent callback and edge control receipts on one tested commit."""
from hashlib import sha256
from pathlib import Path
import json
import sys
r=Path(__file__).resolve().parent
stage=sys.argv[1]
cases=('reentrant','partial','nonblocking','invalid','error_chain','rawroot')
def digest(data):
    return sha256(data).hexdigest()
def status(rundir, stem):
    rec=json.loads((rundir/(stem+'.json')).read_text())
    stdout,stderr=((rundir/(stem+'.'+kind)).read_bytes() for kind in ('stdout','stderr'))
    assert digest(stdout)==rec['stdout_sha256'] and digest(stderr)==rec['stderr_sha256']
    return rec['exit'],rec['timed_out'],stdout,stderr
native=json.loads((r/stage/'meta.json').read_text())
assert native['source_sha256']==digest((r/'callback_review.py').read_bytes())
report={'stage':stage,'commit':native['commit'],'original_ids':0,'core':{},'edges':{}}
for opt in (0,3):
    lane=f'ordinary.O{opt}';d=r/stage/lane
    build=status(d,'build')
    assert build[:2]==(0,False)
    for case in cases:
        reference=status(r/'reference',case);actual=status(d,case)
        assert reference[:2]==(0,False)
        match=actual==reference
        report['core'][lane+'/'+case]=dict(build_exit=build[0],process_exit=actual[0],
                                           timed_out=actual[1],matches_reference=match)
    if (r/'edges'/stage/'meta.json').exists():
        ed=r/'edges'/stage;ev=json.loads((ed/'meta.json').read_text())
        assert ev['commit']==native['commit'] and ev['source_sha256']==digest((r/'edges/callback_edges.py').read_bytes())
        c=status(ed/lane,'build');p=status(ed/lane,'process')
        oracle=(r/'edges/oracle.stdout').read_bytes()
        direct=b"resize blocked\ncurrent_view b'abXX'\nactive_source [b'abcd', b'XX']"
        limit=b"direct_mutable unsupported []\nactive_source []"
        assert direct in oracle
        report['edges'][lane]=dict(build_exit=c[0],process_exit=p[0],timed_out=p[1],matches_reference=p==(0,False,oracle,b''),matches_only_expected_boundary=p==(0,False,oracle.replace(direct,limit),b''))
print(json.dumps(report,indent=2))
