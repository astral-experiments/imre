"""Lifecycle checks for mutable raw.closed and late overrides on an exact BytesIO."""
import io
import os
import sys

class Raw(io.RawIOBase):
    def __init__(self):
        self.flag = False
        self.sink = []
    @property
    def closed(self):
        return self.flag
    def writable(self):
        return True
    def write(self, data):
        self.sink.append(bytes(data))
        return len(data)
    def close(self):
        self.flag = True

def reopened():
    raw = Raw()
    w = io.BufferedWriter(raw, 8)
    w.write(b"abc")
    raw.flag = True
    w.close()
    raw.flag = False
    w.flush()
    print('explicit retry', raw.sink)
    assert raw.sink == [b"abc"]
    w.close()

mode = sys.argv[1]
if mode == 'reopened':
    reopened()
else:
    fd = os.open('sink.bin',os.O_CREAT | os.O_WRONLY | os.O_TRUNC,0o600)
    def redirect(chunk, write=os.write, sink=fd):
        return write(sink,chunk)
    if mode == 'restore-raw':
        stream = io.BytesIO()
        stream.write = redirect
        w = io.BufferedWriter(stream, 8)
        del stream.write
        del stream
    else:
        w = io.BufferedWriter(io.BytesIO(), 8)
        w.raw.write = redirect
    w.write(b'abc')
    if mode=='explicit-late':
        w.flush()
        w.close()
