"""Directed callback conversion and retry semantics beyond the original class."""
import _io
import errno
import io
import sys

class Raw(io.RawIOBase):
    def __init__(self, mode):
        self.mode = mode
        self.calls = 0
        self.first_view = None
        self.owner = None
        self.other = None
    def writable(self):
        return True
    def write(self, data):
        self.calls += 1
        print("callback", self.calls, type(data).__name__, data.readonly, bytes(data))
        if self.mode == "invalid-type":
            return 1.5
        if self.mode in ("raising-index", "reentrant-index"):
            return Index(self, len(data))
        if self.mode == "eintr":
            if self.calls == 1:
                self.first_view = data
                raise InterruptedError(errno.EINTR, "interrupted")
            print("retry argument identity", data is self.first_view)
            self.first_view = None
        if self.mode == "other-interrupt":
            raise InterruptedError(errno.EACCES, "not EINTR")
        return len(data)
class Index:
    def __init__(self, raw, count):
        self.raw = raw
        self.count = count
    def __index__(self):
        print("index")
        if self.raw.mode == "raising-index":
            raise ValueError("bad index")
        try:
            self.raw.owner.flush()
        except RuntimeError:
            print("same writer locked")
        else:
            raise AssertionError("recursive flush succeeded")
        self.raw.other.write(b"x")
        self.raw.other.flush()
        return self.count
def test(mode):
    raw = Raw(mode)
    writer = _io.BufferedWriter(raw, 2)
    raw.owner = writer
    other = Raw("success")
    raw.other = _io.BufferedWriter(other, 2)
    try:
        count = writer.write(b"abc")
        print("result", count)
    except Exception as exc:
        print("error", type(exc).__name__, str(exc), "context", type(exc.__context__).__name__)
    finally:
        writer.close()
        raw.other.close()
        raw.owner = None
        raw.other = None
if __name__ == "__main__":
    test(sys.argv[1])
