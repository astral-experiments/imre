import json,hashlib,sys,collections
from pathlib import Path
r=Path(__file__).parent;label=sys.argv[1]
cv=json.loads((r/(label+'-extra-controls.json')).read_text())
mv=json.loads((r/(label+'-mutable-results.json')).read_text())
assert len(cv)==16 and len(mv)==12
sha=cv[0]['head']
head_check={json.loads((r/fam/label/"provenance.json").read_text())['imre_head'] for fam in ('mutable','conversion','raised-blocked')};assert head_check=={sha}
summarize=lambda cells,key:dict(collections.Counter(str(x[key]) for x in cells))
s={'tested_sha':sha,'modes':'ordinary native O0 and O3, independent focused probes, zero original IDs',
   'conversion_and_blocking':{'cells':len(cv),'matches_reference':summarize(cv,'matches_reference'),'different':[x for x in cv if x['matches_reference'] is not True]},
   'mutable_inputs':{'cells':len(mv),'observations':summarize(mv,'observation'),'observed_differences':[x for x in mv if x['observation']!='MATCH']},
   'files_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/(label+'-extra-controls.json'),r/(label+'-mutable-results.json'))}}
p=r/(label+'-second-review.json');p.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k in ('tested_sha','modes')})); print(s['conversion_and_blocking']['matches_reference'],s['mutable_inputs']['observations']);print(p,hashlib.sha256(p.read_bytes()).hexdigest())
