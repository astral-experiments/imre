from pathlib import Path
import hashlib,json,csv,ast,collections,sys
R=Path(__file__).resolve().parents[2];section=R/'class'/'supplement';U=Path('/workspace/scratch/cpython/Lib/test/test_io.py')
def h(b):return hashlib.sha256(b).hexdigest()
def rows(p):return list(csv.DictReader(p.open(),delimiter='\t'))
source=U.read_bytes().splitlines(keepends=True)
reg={x['id']:x for x in rows(R/'class/stock/registration.tsv')}
ledger=rows(section/'public-opt-runtime.tsv')
want={'stress':{'test_writes','test_writes_and_flushes','test_writes_and_seeks','test_writes_and_truncates'},'thread':{'test_threads'}}
proof={};seen=set();caps=collections.Counter()
for fam,targets in want.items():
 m=json.loads((section/fam/'sources.json').read_text());assert h(U.read_bytes())==m['upstream_sha256']
 projected=Path('/workspace/scratch/cbwc-class/supplement')/fam/'module/test/test_io.py'
 p=projected.read_bytes().splitlines(keepends=True)
 for name,v in m['retained'].items():
    a,b=v['start']-1,v['end'];assert source[a:b]==p[a:b] and h(b''.join(p[a:b]))==v['sha256'],name
 mod=ast.parse(b''.join(p));included={m.name for cls in mod.body if isinstance(cls,ast.ClassDef) for m in cls.body if isinstance(m,ast.FunctionDef) and m.name.startswith('test_')}
 assert included==targets;proof[fam]=[h(projected.read_bytes()),len(m['retained']),sorted(included)]
for x in ledger:
 fam=x['projection'];id=x['id'];opt=int(x['ordinary_opt']);k=fam,id,opt
 assert id.rsplit('.',1)[1] in want[fam] and x['ordinal_in_667']==reg[id]['ordinal_in_667'] and x['occurrence']=='1' and k not in seen
 seen.add(k);caps[(str(opt),x['native_verdict'])]+=1
 p=section/x['raw_receipt'];q=json.loads(p.read_text());assert h(p.read_bytes())==x['raw_receipt_sha256']
 if p.name=='build.json':assert x['native_verdict']=='UNREACHED';continue
 assert q['argv'][1:]==[id];stdout=(p.parent/'callbacks.stdout').read_bytes();assert h(stdout)==q['stdout_sha256']
 frames=[line.split('\t',2)[0] for line in stdout.decode().splitlines() if line.split('\t',2)[1:2]==[id]]
 if x['native_verdict'] in ('PASS','SKIP','FAIL','ERROR'):
    assert frames.index('REGISTER')<frames.index('START')<frames.index(x['native_verdict'])<frames.index('STOP')
 if x['native_verdict']=='INTERRUPTED':assert 'START' in frames and 'STOP' not in frames
assert len(seen)==10
p=Path(__file__).parent/'supplement-ledger-audit.json';p.write_text(json.dumps({'source':proof,'ledger_sha256':h((section/'public-opt-runtime.tsv').read_bytes()),'verified':{str(k):v for k,v in caps.items()}},indent=2)+'\n');print(p,h(p.read_bytes()),caps)
