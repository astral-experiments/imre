"""Independently reconcile the raw selected process stream for every ledger row."""
import ast,collections,csv,hashlib,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];C=R/'class';tag=sys.argv[1];stage=C/tag
def rows(p):return list(csv.DictReader(p.open(),delimiter='\t'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
oracle={r['id']:r for r in rows(C/'stock/registration.tsv')}
ledger=rows(stage/'ledger.tsv'); objs=[];seen=set();sources={}
for r in ledger:
   id=r['id'];lv=int(r['ordinary_opt']);key=(lv,id)
   assert key not in seen and id in oracle and lv in (0,3);seen.add(key)
   assert r['ordinal_in_667']==oracle[id]['ordinal_in_667'] and r['occurrence']==oracle[id]['occurrence']=='1'
   loc=C/r['raw_receipt'];q=json.loads(loc.read_bytes());assert sha(loc)==r['raw_receipt_sha256'] and loc.is_relative_to(stage/f'O{lv}')
   if loc.name=='build.json':
       assert q['exit']!=0 and r['native_verdict']=='UNREACHED' and r['native_registered']=='0';objs.append((lv,'UNREACHED'));continue
   out=loc.parent/q['stdout'];err=loc.parent/q['stderr'];assert sha(out)==q['stdout_sha256'] and sha(err)==q['stderr_sha256']
   assert not q['argv'][1:] or id in q['argv'][1:]
   ev=[];reg=[];opened=False;closed=False
   for line in out.read_text(errors='replace').splitlines():
       a=line.split('\t',2)
       if len(a)!=3:continue
       kind,case,payload=a
       if kind=='REGISTER':reg.append(case)
       if case!=id:continue
       if kind=='START':assert not opened and not closed;opened=True
       if kind in ('ERROR','FAIL','PASS','SUBERROR','SUBFAIL','SKIP'):
           assert opened and not closed;ev.append((kind,ast.literal_eval(payload)))
       if kind=='STOP':assert opened and not closed;opened=False;closed=True
   if r['native_registered']=='1':assert len(set(reg))==len(oracle) and set(reg)==set(oracle)
   tags=[k for k,_ in ev]
   if closed:
       if set(tags)=={'PASS'}:v='PASS';assert tags==['PASS']
       elif set(tags)=={'SKIP'}:v='SKIP'
       elif any(k in ('ERROR','SUBERROR') for k in tags):v='ERROR'
       elif any(k in ('FAIL','SUBFAIL') for k in tags):v='FAIL'
       else:v='NO_VERDICT'
   elif opened and (q['timed_out'] or q['exit']):v='INTERRUPTED'
   elif opened:v='NO_VERDICT'
   else:v='UNREACHED'
   assert v==r['native_verdict'],(key,v,r['native_verdict'])
   if v in ('SKIP','PASS','ERROR','FAIL'):assert ast.literal_eval(r['callback_detail']) in [detail for k,detail in ev]
   objs.append((lv,v));sources[str(out.relative_to(R))]=sha(out)
assert len(ledger)==len(seen)==2*len(oracle)==86
res={'stage':tag,'ledger_sha256':sha(stage/'ledger.tsv'),'registration_sha256':sha(C/'stock'/'registration.tsv'),'confirmation':{f'O{lv}':dict(collections.Counter(v for l,v in objs if l==lv)) for lv in (0,3)},'raw_stdout_sha256':sources}
p=Path(__file__).parent/(tag+'-ledger-audit.json');p.write_text(json.dumps(res,indent=2)+'\n');print(tag,res['confirmation'],sha(p))
