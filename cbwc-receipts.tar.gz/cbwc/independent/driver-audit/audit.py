import ast,collections,csv,hashlib,json,pathlib,sys
R=pathlib.Path('/workspace/shared/downloads/cbuffered-writer-class')
C=R/'class'
U=pathlib.Path('/workspace/scratch/cpython/Lib/test/test_io.py')
P=pathlib.Path('/workspace/scratch/cbwc-class/module/test/test_io.py')
OLD=pathlib.Path('/workspace/shared/downloads/io-buffer-binding/discovery/oracle/regrtest-default/ordered-cases.json')
base='test.test_io.CBufferedWriterTest.'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def classes(p):
    code=p.read_text();return {n.name:(n,ast.get_source_segment(code,n)) for n in ast.parse(code).body if isinstance(n,ast.ClassDef)}
def simple(x):return json.dumps(x,indent=2,sort_keys=True)+'\n'
oracle=json.loads(OLD.read_text())
stockreg=list(csv.DictReader((C/'stock/registration.tsv').open(),delimiter='\t'))
reg={x['id']:int(x['ordinal_in_667']) for x in stockreg}
assert sorted(reg.values())==list(range(172,215))
assert [x['id'] for x in oracle if x['id'].startswith(base)]==list(reg)
ref=[{'id':x['id'],'ordinal':x['index'],'occurrence':x['occurrence'],'default_resource_verdict':x['reference_verdict'],'reason':x.get('reference_reason')} for x in oracle if x['id'] in reg]
u=classes(U);p=classes(P); expected=('CommonBufferedTests','SizeofTest','BufferedWriterTest','CBufferedWriterTest')
registered_methods={}
for name in expected:
    node,text=u[name]; assert p[name][1]==text
    for method in node.body:
        if isinstance(method,ast.FunctionDef) and method.name.startswith('test_'):
            registered_methods[base+method.name]=name
assert set(registered_methods)==set(reg)
assert all(registered_methods[r['id']]==r['original_owner'] for r in stockreg)
# Class body byte check includes every decorator and fixture. Separately verify loader, prepends and copied library.
assert all(u[n][1]==c for n,(v,c) in p.items())
ul=U.read_text().splitlines();pl=P.read_text().splitlines()
assert [x for x in pl[:49]]==ul[:49] and len(ul)==len(pl)
project=json.loads((C/'projection.json').read_text()); pins={}
for k,v in project['inputs'].items():
    if k in ('run.py','test/test_io.py'):continue
    source=U.parents[1]/k
    dest=P.parents[1]/k
    assert sha(source)==sha(dest)==v
    pins[k]=v
def stream(q,expect_full=False):
    r=q.read_text().splitlines(); tags=collections.Counter(); outcomes={k:[] for k in reg};starts=[];stops=[];known=[];details=[];order=[]
    for line in r:
        if line.count('\t')!=2:continue
        tag,k,s=line.split('\t',2);tags[tag]+=1
        if tag=='REGISTER':known.append(k)
        if tag=='START':starts.append(k);order.append(('START',k))
        if tag=='STOP':stops.append(k);order.append(('STOP',k))
        if tag in ('PASS','ERROR','FAIL','SUBERROR','SUBFAIL','SKIP'): 
            assert k in reg
            outcomes[k].append((tag,ast.literal_eval(s)));order.append(('OUTCOME',k))
            if tag!='PASS':details.append([tag,k,ast.literal_eval(s)])
    assert len(known)==len(set(known)) and (not known or list(reg)[:len(known)]==known)
    assert len(starts)==len(set(starts)) and len(stops)==len(set(stops)) and all(k in reg for k in starts)
    open_case=None
    for tag,k in order:
        if tag=='START':assert open_case is None;open_case=k
        if tag=='OUTCOME':assert k==open_case
        if tag=='STOP':assert open_case==k;open_case=None
    if expect_full:
        assert list(reg)==known==starts==stops and all([x[0] for x in v]==['PASS'] for v in outcomes.values())
    return {'file':str(q.relative_to(R)),'sha256':sha(q),'tags':dict(tags),'distinct_finished':len(stops),'open_case':open_case,
        'passed_with_stop':[k for k,v in outcomes.items() if k in stops and [x[0] for x in v]==['PASS']],
        'outcomes_other_than_success':details}
if len(sys.argv)==1:
    o={ 'scope':'Independent source, registration and stock callback audit',
        'upstream':sha(U),'focused':sha(P),'class_body_closure':sorted(p),
        'class_method_count':len(reg),'fixture':json.loads((C/'stock/provenance.json').read_text()),
        'inherited_setUp_tearDown':'No retained test class overrides any fixture',
        'hook_differences':project['hook_changes'],'copied_unmodified_support_file_count':len(pins),
        'direct_full':stream(C/'stock/callbacks.stdout',True),'direct_focused':stream(C/'stock-focused/callbacks.stdout',True),
        'default_resource_ledger_sha256':sha(OLD),'default_resource_rows':ref}
    assert all(not any(getattr(n,'name',None) in ('setUp','setUpClass','tearDown','tearDownClass') for n in p[k][0].body) for k in expected)
    dest=pathlib.Path(__file__).parent/'reference.json'
else:
    stage=sys.argv[1]; group=C/stage; paths=sorted(group.rglob('callbacks.stdout'))
    if not paths:
        assert all(json.loads((group/f'O{opt}'/'build.json').read_text())['exit']!=0 for opt in (0,3))
    o={'stage':stage,'streams':[stream(q) for q in paths]}
    dest=pathlib.Path(__file__).parent/(stage+'.json')
dest.write_text(simple(o));print(dest,sha(dest))
