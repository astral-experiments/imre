import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from datetime import datetime, timezone
SRC=Path(__file__).resolve().parent
S=SRC/'callback_review.py'
GG='/workspace/scratch/tools/clang'
PY='/workspace/scratch/cpytools/py/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14'
cases=['reentrant','partial','nonblocking','invalid','error_chain','rawroot']
def digest(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(argv,cwd,stem,t):
    mkdir=stem.parent; mkdir.mkdir(parents=True,exist_ok=True)
    env={k:v for k,v in os.environ.items() if k not in ('IMREFLAGS','IMRE_ENCODED_FLAGS','PYTHONPATH')};env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE='1')
    start=datetime.now(timezone.utc).isoformat();ts=time.monotonic();argv=list(map(str,argv));rc=None;timeout=False
    with stem.with_suffix('.stdout').open('wb') as out,stem.with_suffix('.stderr').open('wb') as err:
        try:rc=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=err,timeout=t).returncode
        except subprocess.TimeoutExpired:timeout=True
    row=dict(argv=argv,cwd=str(cwd),utc_start=start,elapsed_s=round(time.monotonic()-ts,3),exit=rc,timed_out=timeout,stdout_sha256=digest(stem.with_suffix('.stdout')),stderr_sha256=digest(stem.with_suffix('.stderr')))
    stem.with_suffix('.json').write_text(json.dumps(row,indent=2)+'\n');return row
def main():
    stage=sys.argv[1];folder=SRC/stage;folder.mkdir(exist_ok=True)
    work=Path('/workspace/scratch/cbwc-intact/review')/stage;work.mkdir(exist_ok=True)
    if stage=='reference':
        for case in cases:
            print(case,run([PY,'-B',S,case],work,folder/case,15)['exit'],flush=True)
        return
    binary=Path(sys.argv[2]);commit=sys.argv[3];assert (binary/'READY').read_text().strip()==commit
    (folder/'meta.json').write_text(json.dumps(dict(imre_sha256=digest(binary/'imre'),runtime_sha256=digest(binary/'libimre_runtime.a'),source_sha256=digest(S),commit=commit),indent=2)+'\n')
    def lane(opt):
        d=folder/f'ordinary.O{opt}'; cwd=work/f'ordinary.O{opt}';cwd.mkdir(exist_ok=True)
        exe=cwd/'probe';r=run([binary/'imre','build',S,'--no-cache','--runtime',binary/'libimre_runtime.a','--clang',GG,'--opt-level',str(opt),'-o',exe],cwd,d/'build',600)
        if r['exit']!=0:return
        (d/'program.sha256').write_text(digest(exe)+'\n')
        for case in cases:
            r=run([exe,case],cwd,d/case,45); oracle=json.loads((SRC/'reference'/(case+'.json')).read_text())
            print(stage,opt,case,r['exit'],all(r[k]==oracle[k] for k in ['exit','stdout_sha256','stderr_sha256']),flush=True)
        exe.unlink()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(lane,[0,3]))
if __name__=='__main__':main()
