from pathlib import Path
import hashlib,json,sys
H=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
tag=sys.argv[1]; base=H/'mutable'; ref=base/'stock'/'stock';rows=[]
for opt in [0,3]:
 lane=base/tag/f'O{opt}';build=read(lane/'build.json')
 for d in sorted(p for p in ref.iterdir() if p.is_dir()):
    raw=lane/d.name; p=raw/'process.json'; observed=None
    if p.is_file(): 
        ev=read(p);stdout=(raw/'process.stdout').read_text()
        assert ev['stdout_sha256']==sha(raw/'process.stdout') and ev['stderr_sha256']==sha(raw/'process.stderr')
        observed='MATCH' if stdout==(d/'process.stdout').read_text() and not (raw/'process.stderr').stat().st_size and ev['exit']==0 else 'MISMATCH'
        if d.name!='small-overflow' and ev['exit']==0 and not (raw/'process.stderr').stat().st_size and 'events [] sink []' in stdout and stdout.startswith('unsupported ') and 'after flush' in stdout:observed='UNSUPPORTED_BEFORE_RAW_EFFECTS'
    else:ev={'exit':None,'timed_out':False}
    rows.append({'case':d.name,'ordinary_opt':opt,'build_exit':build['exit'],'native_exit':ev['exit'],'timeout':ev['timed_out'],'observation':observed})
result=H/(tag+'-mutable-results.json');result.write_text(json.dumps(rows,indent=2)+'\n');print(sha(result));print([(r['case'],r['observation']) for r in rows])
