import json,hashlib,sys
from pathlib import Path
R=Path(__file__).parent
expected_sha=sys.argv[1]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(q):
    r=json.loads((q/'process.json').read_text());s=json.loads((q/'sink.json').read_text());o=(q/'process.stdout').read_bytes();e=(q/'process.stderr').read_bytes()
    assert h(q/'process.stdout')==r['stdout_sha256'] and h(q/'process.stderr')==r['stderr_sha256']
    return dict(process_exit=r['exit'],timed_out=r['timed_out'],sink=s['hex'],stdout=o.decode(errors='replace'),stderr=e.decode(errors='replace'),raw_sha256=h(q/'process.json'))
rows=[]
for family,tag in [('shutdown-guard','guarded'),('shutdown-state','guard-'+expected_sha)]:
    g=R/family;prov=json.loads((g/tag/'provenance.json').read_text())
    assert prov['imre_head']==expected_sha,prov
    cases=[d.name for d in sorted((g/'stock/stock').iterdir()) if (d/'process.json').is_file()]
    for opt in [0,3]:
        build=json.loads((g/tag/f'O{opt}'/'build.json').read_text())
        for c in cases:
            cp=record(g/'stock/stock'/c); native=record(g/tag/f'O{opt}'/c) if build['exit']==0 else {}
            if family=='shutdown-guard' and c in ['normal','override-close','override-flush','override-del','two-aliases']:
                expectation='guard_nonzero';target=1;target_sink=''
            elif c=='late-global':
                expectation='guard_nonzero';target=1;target_sink=''
            else:
                expectation='stock';target=cp['process_exit'];target_sink=cp['sink']
            ok=native.get('process_exit')==target and native.get('sink')==target_sink and not native.get('timed_out',False)
            if expectation=='guard_nonzero':
                ok=ok and native['stderr'].count('unflushed bytes at shutdown')==1
            else:
                ok=ok and native['stderr']==cp['stderr'] and native['stdout']==cp['stdout']
            rows.append(dict(family=family,case=c,opt=opt,build_exit=build['exit'],expected=expectation,meets_expected=ok,matches_reference=(cp['process_exit']==native.get('process_exit') and cp['sink']==native.get('sink') and cp['stderr']==native.get('stderr') and cp['stdout']==native.get('stdout')),stock=cp,native=native))
dst=R/('guard-shutdown-audit-'+expected_sha[:7]+'.json');dst.write_text(json.dumps(rows,indent=2)+'\n');print('rows',len(rows),'expected',sum(bool(x['meets_expected']) for x in rows),'stock',sum(bool(x['matches_reference']) for x in rows),'digest',h(dst));print([(x['case'],x['opt'],x['native'].get('process_exit'),x['native'].get('sink'),x['native'].get('stderr','')[-220:]) for x in rows if not x['meets_expected']])
