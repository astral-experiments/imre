"""How BufferedWriter handles an exception raised while flushing preexisting writes."""
import errno
import io
import sys

class Raw(io.RawIOBase):
    def __init__(self):
        self.blocked = True
        self.written = []
    def writable(self):
        return True
    def write(self, data):
        if self.blocked:
            raise BlockingIOError(errno.EAGAIN, 'special', 0)
        self.written.append(bytes(data))
        return len(data)

def run(mode):
    raw = Raw()
    writer = io.BufferedWriter(raw, 4)
    if mode.startswith('pending'):
        assert writer.write(b'abc') == 3
    try:
        n = writer.flush() if mode == 'pending-flush' else writer.write(b'12345')
        print('result', n)
    except BlockingIOError as exc:
        print('blocked', exc.args, exc.characters_written)
    raw.blocked = False
    writer.flush()
    print('retry sink', raw.written)
    writer.close()
run(sys.argv[1])
