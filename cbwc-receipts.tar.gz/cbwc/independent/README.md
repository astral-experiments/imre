# Raw callback controls

Each control starts in a fresh process and uses the public native BufferedWriter over a Python RawIOBase subclass. The reference is stock CPython 3.14.5. These six reviewer controls carry zero original unittest IDs. They cover a reentrant callback with collection, partial flush retry, partial nonblocking write retry, negative or oversized and one-time zero write results, close and flush exception context, and weak retention across GC and detach.

Each native lane compiles the same source once with ordinary Imre at O0 or O3. Exit status, stdout SHA-256 and stderr SHA-256 are compared with the corresponding stock process. Full raw streams and separate compiler/process timings accompany the results.

On public ff034f7b both ordinary builds succeeded, and all 12 core control subprocesses exited 1 during raw construction. At guarded 6f29a0da all 12 matched stock, including exit 0, stdout and stderr. Additional directed edge controls matched at both levels for a raw-raised BlockingIOError, reentry from raw.closed, a short mutable input modified during preflush, accepted-byte accounting and prevented resize. The candidate rejected a direct callback write of a mutable input at least as long as the buffer before calling raw.write. Stock accepted it and observed the in-place mutation. [Guarded raw verdicts](tested-6f29a0d/review.json) · [Guarded edge streams](edges/tested-6f29a0d) · [Stock edge stdout](edges/oracle.stdout)

A local callback-backed writer finalized correctly on both compilers. A writer held as a module global lost pending bytes at native exit at both optimization levels. The shutdown assessment records the linked CPython lifecycle and teardown probes. [Assessment and raw files](shutdown/ASSESSMENT.md)
