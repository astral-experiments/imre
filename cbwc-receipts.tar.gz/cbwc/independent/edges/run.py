from pathlib import Path
import concurrent.futures, importlib.util, json, os, sys
sys.dont_write_bytecode=True
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('probe_runner',here.parent/'run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
stage,b,commit=sys.argv[1:]; b=Path(b)
assert (b/'READY').read_text().strip()==commit
src=here/'callback_edges.py';folder=here/stage;folder.mkdir(exist_ok=True)
meta=dict(imre_sha256=runner.digest(b/'imre'),runtime_sha256=runner.digest(b/'libimre_runtime.a'),source_sha256=runner.digest(src),commit=commit)
(folder/'meta.json').write_text(json.dumps(meta,indent=2)+'\n')
def lane(o):
    log=folder/f'ordinary.O{o}';work=Path('/workspace/scratch/cbwc-intact/review')/('edges-'+stage)/f'ordinary.O{o}';work.mkdir(parents=True,exist_ok=True);exe=work/'probe'
    c=runner.run([b/'imre','build',src,'--no-cache','--runtime',b/'libimre_runtime.a','--clang',runner.GG,'--opt-level',str(o),'-o',exe],work,log/'build',900)
    if c['exit']!=0:return
    (log/'program.sha256').write_text(runner.digest(exe)+'\n')
    r=runner.run([exe],work,log/'process',45)
    print(stage,o,c['exit'],r['exit'],(log/'process.stdout').read_text(),flush=True)
    exe.unlink()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lane,(0,3)))
