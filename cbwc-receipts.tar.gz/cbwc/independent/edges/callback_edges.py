"""Observe additional Python callbacks. Native comparisons concern these exact visible effects."""
from io import RawIOBase
from _io import BufferedWriter

class Raw(RawIOBase):
    def writable(self):
        return True
    def tell(self):
        return 0
    def write(self, buf):
        self.done.append(bytes(buf))
        return len(buf)

def raised_block():
    class RawBlock(Raw):
        def write(self, buf):
            if self.once:
                self.once = False
                raise BlockingIOError(11, "raw", 99)
            return super().write(buf)
    raw = RawBlock()
    raw.once = True
    raw.done = []
    w = BufferedWriter(raw, 4)
    w.write(b'abc')
    try:
        w.write(b'BC')
    except BlockingIOError as err:
        print('raised_block', err.characters_written)
    w.close()
    print('after_raised_block', raw.done)

def active_source():
    class RawMutate(Raw):
        def write(self, buf):
            self.done.append(bytes(buf))
            if len(self.done) == 1:
                try:
                    self.source.append(0)
                except BufferError:
                    print('resize', 'blocked')
                else:
                    print('resize', 'accepted')
                    self.source.pop()
                self.source[2:] = b'XX'
                print('current_view', bytes(buf))
                return 2
            return len(buf)
    raw = RawMutate()
    raw.done = []
    raw.source = bytearray(b'abcd')
    w = BufferedWriter(raw, 2)
    try:
        w.write(raw.source)
    except NotImplementedError:
        print("direct_mutable", "unsupported", raw.done)
    w.close()
    print('active_source', raw.done)

def closed_reentry():
    class ClosedRaw(Raw):
        active = False
        @property
        def closed(self):
            if self.active:
                self.active = False
                self.owner.write(b'B')
            return super().closed
    raw = ClosedRaw()
    raw.done = []
    w = BufferedWriter(raw, 4)
    raw.owner = w
    w.write(b'A')
    raw.active = True
    try:
        w.flush()
    except RuntimeError as err:
        print('closed_reentry', type(err).__name__)
    w.close()
    print('closed_output', raw.done)


def short_mutable(step):
    class RawShort(Raw):
        def write(self, buf):
            if self.once:
                self.once = False
                try:
                    self.source.append(0)
                except BufferError:
                    print('short_resize', 'blocked')
                else:
                    print('short_resize', 'accepted')
                    self.source.pop()
                self.source[:] = b'XY'
                if self.step == 'block':
                    return None
            self.done.append(bytes(buf))
            return len(buf)
    raw = RawShort()
    raw.done = []
    raw.source = bytearray(b'de')
    raw.once = True
    raw.step = step
    w = BufferedWriter(raw, 4)
    w.write(b'abc')
    try:
        print('short_write', step, w.write(raw.source))
    except BlockingIOError as exc:
        print('short_block', step, exc.characters_written)
    w.close()
    print('short_result', step, raw.done)

raised_block()
active_source()
closed_reentry()
short_mutable('pass')
short_mutable('block')
