"""Compare implicit closure of live global and local Python callback-backed writers."""
import sys
import gc
from _io import BufferedWriter, FileIO

class Raw:
    def __init__(self, path):
        self.file = FileIO(path, 'w')
    def writable(self):
        return True
    def tell(self):
        return self.file.tell()
    @property
    def closed(self):
        return self.file.closed
    def write(self, buf):
        return self.file.write(buf)
    def close(self):
        return self.file.close()

def local(path):
    w = BufferedWriter(Raw(path), 8)
    w.write(b'ABC')

if sys.argv[1] == 'local':
    local(sys.argv[2])
    gc.collect()
else:
    w = BufferedWriter(Raw(sys.argv[2]), 8)
    w.write(b'ABC')
