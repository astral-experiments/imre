import concurrent.futures, importlib.util,sys,json
from pathlib import Path
here=Path(__file__).resolve().parent; sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('probe_runner',here.parent/'run.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
stage,b,commit=sys.argv[1:]; b=Path(b);src=here/'probe.py'; folder=here/stage;folder.mkdir(exist_ok=True)
def once(tag, command):
    loc=folder/tag;work=Path('/workspace/scratch/cbwc-intact/review')/('shutdown-'+stage)/tag;work.mkdir(parents=True,exist_ok=True);exe=work/'probe'
    if tag!='reference':
        assert (b/'READY').read_text().strip()==commit
        c=runner.run([b/'imre','build',src,'--no-cache','--runtime',b/'libimre_runtime.a','--clang',runner.GG,'--opt-level',tag[-1],'-o',exe],work,loc/'build',900)
        if c['exit']!=0:return
        (loc/'program.sha256').write_text(runner.digest(exe)+'\n')
        command=[exe]
    for shape in ('local','global'):
        sink=work/(shape+'.bin');sink.unlink(missing_ok=True)
        p=runner.run([*command,shape,sink],work,loc/shape,35)
        if sink.exists():
            (loc/(shape+'.file')).write_bytes(sink.read_bytes())
        print(tag,shape,p['exit'],sink.read_bytes() if sink.exists() else None,flush=True)
    if tag!='reference':exe.unlink()
(here/stage/'meta.json').write_text(json.dumps(dict(commit=commit,source_sha256=runner.digest(src),compiler_sha256=runner.digest(b/'imre'),runtime_sha256=runner.digest(b/'libimre_runtime.a')),indent=2)+'\n')
once('reference',[runner.PY,'-B',src]); 
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda t:once(t,[]),('ordinary.O0','ordinary.O3')))
