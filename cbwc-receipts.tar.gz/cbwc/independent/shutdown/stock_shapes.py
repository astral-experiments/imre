import atexit
import sys
from _io import BufferedWriter, FileIO
state = b'A'
class Raw:
    def __init__(self, path):
        self.file = FileIO(path, 'w')
    def writable(self): return True
    def tell(self): return self.file.tell()
    @property
    def closed(self): return self.file.closed
    def write(self, buf): return self.file.write(buf)
    def close(self): return self.file.close()
class Depend(Raw):
    def write(self, buf):
        self.file.write(bytes(buf) + str(state).encode())
        return len(buf)
class Refuses(BufferedWriter):
    def close(self): pass
class Resurrect(BufferedWriter):
    def __del__(self):
        global resurrected
        resurrected = self
tag = sys.argv[1]
kind = Refuses if tag == 'override' else Resurrect if tag == 'resurrect' else BufferedWriter
w = kind((Depend if tag.startswith('dependent') else Raw)(sys.argv[2]), 8)
w.write(b'X')
if tag == 'self':
    w.owner = w
if tag == 'raw_cycle':
    w.raw.owner = w
if tag == 'box':
    container = [w]
    del w
if tag == 'container_cycle':
    ownerlist = [w]
    ownerlist.append(ownerlist)
    del w
if tag == 'atexit_closes':
    atexit.register(w.raw.close)
if tag == 'atexit_changes':
    atexit.register(lambda: w.write(b'Y'))
if tag == 'dependent_singleunderscore':
    _holder = w
    del w
if tag == 'sysalias':
    sys.final_writer = w
    del w
if tag.startswith('pair_'):
    r = w.raw
    v = BufferedWriter(r, 8)
    v.write(b'Y')
    if tag == 'pair_reverse':
        first, second = v, w
        del w, v
