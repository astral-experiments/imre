import atexit
import sys
from _io import BufferedWriter, FileIO
flag = "flag"
class Raw:
    def __init__(self,p): self.fp=FileIO(p,'w')
    def writable(self): return True
    def tell(self): return 0
    @property
    def closed(self): return self.fp.closed
    def write(self,data):
        ns=globals()
        values=('w' in ns, ns.get('w') is None,'flag' in ns, ns.get('flag') is None, sys.is_finalizing(), '__main__' in sys.modules)
        self.fp.write(str(values).encode())
        return len(data)
    def close(self): self.fp.close()
w=BufferedWriter(Raw(sys.argv[1]),8)
w.write(b'X')
