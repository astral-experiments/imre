import atexit,sys,os
from io import BufferedWriter, FileIO, RawIOBase
case=sys.argv[1]; path=sys.argv[2]
trace_fd=os.open(path+'.trace',os.O_WRONLY | os.O_CREAT | os.O_TRUNC,0o600)
def event(msg, write=os.write, fd=trace_fd):
    write(fd,(msg+'\n').encode())
class Raw:
    def __init__(self):
        self.file=FileIO(path,'w')
    def writable(self): return True
    def tell(self): return self.file.tell()
    @property
    def closed(self): return self.file.closed
    def write(self, v, event=event, is_finalizing=sys.is_finalizing):
        event('write '+repr(bytes(v))+' final='+str(is_finalizing())+' globals='+str('w' in globals()))
        return self.file.write(v)
    def close(self, event=event):
        event('raw-close')
        return self.file.close()
class Writer(BufferedWriter):
    def close(self,event=event):
        event('writer-close')
        return super().close()
class Skip(Writer):
    def __del__(self,event=event):
        event('skip-del')
class Save(Writer):
    def __del__(self,event=event):
        event('save-del')
        global saved
        saved=self
R=Raw
W={'resurrect':Save,'override':Skip}.get(case,Writer)
w=W(R(),8); w.write(b'ABC')
if case=='selfcycle': w.loop=w
if case=='rawcycle': w.raw.writer=w
if case=='listcycle': w.raw.refs=[w]
if case=='container': holder=[w]; del w
if case=='rawalias': r=w.raw
if case=='nested': owner=w; w=W(owner,4);w.write(b'D')
def at(event=event):
    event('atexit')
    if case=='mutate': w.write(b'Z')
    if case=='close': w.close()
    if case=='drop':
        global_ref=globals()
        del global_ref['w']
atexit.register(at)

