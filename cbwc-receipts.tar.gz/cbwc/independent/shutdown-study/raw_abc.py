import atexit,sys,os
from io import BufferedWriter, FileIO, RawIOBase
case=sys.argv[1]; path=sys.argv[2]
trace_fd=os.open(path+'.trace',os.O_WRONLY | os.O_CREAT | os.O_TRUNC,0o600)
def event(msg, write=os.write, fd=trace_fd):
    write(fd,(msg+'\n').encode())
class Raw:
    def __init__(self):
        self.file=FileIO(path,'w')
    def writable(self): return True
    def tell(self): return self.file.tell()
    @property
    def closed(self): return self.file.closed
    def write(self, v, event=event, is_finalizing=sys.is_finalizing):
        event('write '+repr(bytes(v))+' final='+str(is_finalizing())+' globals='+str('w' in globals()))
        return self.file.write(v)
    def close(self, event=event):
        event('raw-close')
        return self.file.close()
class Writer(BufferedWriter):
    def close(self,event=event):
        event('writer-close')
        return super().close()
class Skip(Writer):
    def __del__(self,event=event):
        event('skip-del')
class Save(Writer):
    def __del__(self,event=event):
        event('save-del')
        global saved
        saved=self
class RawABC(Raw, RawIOBase): pass
if case.startswith('abc'):
    R=RawABC
else:
    R=Raw
if case.endswith('shared'):
    r=R()
    a=Writer(r,8); b=Writer(r,8)
    a.write(b'A'); b.write(b'B')
elif case.endswith('reversealias'):
    a=None; b=None; r=R(); b=Writer(r,8); a=Writer(r,8)
    a.write(b'A');b.write(b'B')
elif case.endswith('wrap'):
    r=R()
    a=Writer(r,8); b=Writer(a,8)
    a.write(b'A'); b.write(b'B')
elif case.endswith('self') or case.endswith('cyclefile') or case.endswith('rawcycle'):
    w=Writer(R(),8)
    if case.endswith('cyclefile'): w.raw.file.owner=w
    elif case.endswith('rawcycle'): w.raw.owner=w
    else: w.loop=w
    w.write(b'ABC')
else:
    w=Writer(R(),8)
    w.write(b'ABC')
atexit.register(lambda:event('atexit'))

