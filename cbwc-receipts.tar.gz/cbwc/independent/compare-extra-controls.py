from pathlib import Path
import hashlib,json,sys
root=Path(__file__).parent
label=sys.argv[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
allrows=[]
for suite in ('conversion','raised-blocked'):
    d=root/suite; meta=json.loads((d/label/'provenance.json').read_text())
    for l in (0,3):
        lane=d/label/f'O{l}';br=json.loads((lane/'build.json').read_text())
        for ref in sorted((d/'stock'/'stock').iterdir()):
            if not ref.is_dir():continue
            s=ref.name;out=lane/s/'process.json';rc=json.loads((ref/'process.json').read_text())['exit'];native_rc=match=None
            if out.exists():
                e=json.loads(out.read_text());native_rc=e['exit']
                for stream in ('stdout','stderr'):
                    assert digest(out.parent/f'process.{stream}')==e[f'{stream}_sha256']
                match=(e['exit']==rc and all(digest(out.parent/f'process.{stream}')==digest(ref/f'process.{stream}') for stream in ('stdout','stderr')))
            allrows.append(dict(suite=suite,case=s,ordinary_opt=l,head=meta['imre_head'],build_exit=br['exit'],reference_exit=rc,native_exit=native_rc,matches_reference=match))
p=root/(label+'-extra-controls.json');p.write_text(json.dumps(allrows,indent=2)+'\n')
print(len(allrows),sum(x['matches_reference'] is True for x in allrows),'match',digest(p))
