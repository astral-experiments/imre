"""Independent dynamic raw.write controls; every case runs in a separate process."""
import gc
import sys
import weakref
from _io import BufferedWriter
from io import RawIOBase

class Raw(RawIOBase):
    def __init__(self):
        self.writes = []
        self.chunks = []
        self.steps = []
    def writable(self):
        return True
    def tell(self):
        return sum(map(len, self.chunks))
    def write(self, buf):
        data = bytes(buf)
        self.writes.append((type(buf).__name__, buf.readonly, data))
        step = self.steps.pop(0) if self.steps else len(buf)
        if step is None:
            return None
        if isinstance(step, BaseException):
            raise step
        if 0 <= step <= len(buf):
            self.chunks.append(data[:step])
        return step

def reentrant():
    class Reentrant(Raw):
        def write(self, buf):
            gc.collect()
            try:
                self.owner.flush()
            except RuntimeError:
                print("reentry rejected")
            else:
                raise AssertionError("reentry accepted")
            return super().write(buf)
    raw = Reentrant()
    owner = BufferedWriter(raw, 8)
    raw.owner = owner
    owner.write(b'abcd')
    owner.flush()
    owner.close()
    print(raw.writes, raw.closed)

def partial():
    raw = Raw()
    owner = BufferedWriter(raw, 4)
    raw.steps = [1, None, 1, 1]
    owner.write(b'abc')
    try:
        owner.flush()
    except BlockingIOError as exc:
        print("blocked", exc.characters_written)
    else:
        raise AssertionError("flush should block")
    owner.flush()
    owner.close()
    print(raw.writes, b''.join(raw.chunks), raw.closed)

def nonblocking():
    raw = Raw()
    owner = BufferedWriter(raw, 4)
    raw.steps = [1, None]
    owner.write(b'abc')
    try:
        owner.write(b'defgh')
    except BlockingIOError as exc:
        print("blocked", exc.characters_written)
        tail = b'defgh'[exc.characters_written:]
    else:
        raise AssertionError("write should block")
    owner.write(tail)
    owner.close()
    print(raw.writes, b''.join(raw.chunks), raw.closed)

def invalid():
    raw = Raw()
    owner = BufferedWriter(raw, 4)
    owner.write(b'abc')
    for count in [-1, 20, 1 << 90]:
        raw.steps = [count]
        try:
            owner.flush()
        except OSError as exc:
            print("invalid", type(exc).__name__)
        else:
            raise AssertionError("invalid count accepted")
    raw.steps = [0, 1]
    owner.close()
    print(raw.writes, b''.join(raw.chunks), raw.closed)

def error_chain():
    class Fails(Raw):
        def close(self):
            super().close()
            raise RuntimeError("close")
    raw = Fails()
    owner = BufferedWriter(raw, 8)
    raw.steps = [ValueError("flush")]
    owner.write(b"abc")
    try:
        owner.close()
    except RuntimeError as exc:
        print(type(exc).__name__, type(exc.__context__).__name__, exc.__context__, owner.closed)
    else:
        raise AssertionError("close should fail")

def rawroot():
    raw = Raw()
    ref = weakref.ref(raw)
    owner = BufferedWriter(raw, 8)
    del raw
    gc.collect()
    print(ref() is owner.raw)
    owner.write(b"abc")
    raw = owner.detach()
    del owner
    gc.collect()
    print(raw is ref(), b''.join(raw.chunks), raw.closed)
    raw.close()

cases = dict(reentrant=reentrant, partial=partial, nonblocking=nonblocking, invalid=invalid,
             error_chain=error_chain, rawroot=rawroot)
cases[sys.argv[1]]()
