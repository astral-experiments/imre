# Public BufferedRWPair lifetime and CTextIOWrapperTest replay

Linux CPython 3.14.5, source 5607950ef232dad16d75c0cf53101d9649d89115.
Product PR #3968 was reviewed and tested at 1902912146f5688c9fcca1bf46fdaaecb6d94b20. Public squash 36c4f334e96c3bb5a8270ff8f8c85808715fec6d includes the earlier combined buffered providers from #3960. The public pair was built at the squash SHA. Both the compiler and static runtime identities are recorded in the component archives.

The 82 rows of originals.tsv are distinct unchanged test.test_io.CTextIOWrapperTest IDs. Stock passed 82. Both public boxed O0 and boxed O3 started and stopped 82 cases, with 82 setup errors, zero skips and zero original body passes. The original setUp at Lib/test/test_io.py:2832 calls codecs.register(lookupTestDecoder) before invoking each test method. The native codecs provider lacks register. See the intact-cwrapper archive for raw callbacks, full tracebacks, the absent selector and the isolated checks.

The real-files archive records explicit writer-first close, two real independent streams, and the EBADF raised by the reader with the writer's ENOSPC in its exception context. The implicit-lifetime archive covers acyclic reader-before-writer release and cyclic writer-first close. The finalizer-review archives include nested GC and weakref observations. All these controls are supplemental.

The public finalizer-review archive also records a separate reader control. Standalone implicit BufferedReader destruction and RWPair reader rollback on the public O0 runtime both omit the raw _dealloc_warn hook that stock invokes. All kernel descriptors close.

SHA256SUMS covers every other member of this archive. Component archives contain their own manifests and replay evidence.
