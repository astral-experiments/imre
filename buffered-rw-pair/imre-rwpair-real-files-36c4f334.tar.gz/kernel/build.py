from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path(__file__).resolve().parent;b=r.parents[2];pin=sys.argv[1];lvl=sys.argv[2];stage=r/'src';pair=b/'fs-family/provider-replay/pairs'/pin;out=r/'raw'/pin/('boxed-O'+lvl);out.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();limit=time.monotonic()+600
while not (pair/'ready').exists():
 if time.monotonic()>limit:raise TimeoutError(pair)
 time.sleep(2)
assert (pair/'commit').read_text().strip()==pin; hashes={n:h for h,n in (l.split() for l in (pair/'ready').read_text().splitlines())};assert all(sha(pair/k)==v for k,v in hashes.items()); args=list(map(str,[pair/'imre','build',stage/'trace_close.py','--module-root',stage,'--runtime-imports','--opt-level',lvl,'--no-cache','--runtime',pair/'libimre_runtime.a','--clang',b/'llvm/usr/bin/clang-19','-o',out/'suite'])); temp=out/'buildtmp';temp.mkdir(exist_ok=True)
with (out/'build.stdout').open('wb') as o,(out/'build.stderr').open('wb') as e: proc=subprocess.run(args,cwd=temp,env={**os.environ,'TMPDIR':str(temp),'LD_LIBRARY_PATH':str(b/'llvm/usr/lib/x86_64-linux-gnu')},timeout=800,stdout=o,stderr=e)
(out/'build.json').write_text(json.dumps(dict(pin=pin,pair=hashes,argv=args,driver_sha256=sha(stage/'trace_close.py'),exit=proc.returncode,binary_sha256=sha(out/'suite') if proc.returncode==0 else None),indent=2)+'\n');print(pin[:8],lvl,proc.returncode,flush=True);sys.exit(proc.returncode)
