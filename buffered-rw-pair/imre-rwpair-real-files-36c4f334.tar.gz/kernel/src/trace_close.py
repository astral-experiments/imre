import io
import _io
import os
import sys

mode = sys.argv[1]
assert io.BufferedRWPair is _io.BufferedRWPair
reader = io.FileIO('input.bin', 'r')
writer = io.FileIO('/dev/full' if mode == 'mixed' else 'output.bin', 'w')
try:
    pair = io.BufferedRWPair(reader, writer, 4)
    ri, wi = reader.fileno(), writer.fileno()
    print('descriptor-order', ri, wi, flush=True)
    if mode in ('dual-error', 'mixed'):
        if mode == 'mixed':
            assert pair.write(b'out') == 3
        os.close(ri)
        if mode == 'dual-error':
            os.close(wi)
        try:
            pair.close()
        except OSError as exc:
            context = exc.__context__
            print('chain', type(exc).__name__, exc.errno, type(context).__name__, context.errno, flush=True)
            assert type(exc) is OSError and exc.errno == 9
            assert type(context) is OSError and context.errno == (28 if mode == 'mixed' else 9)
        else:
            raise AssertionError('two failed descriptor closes were lost')
    else:
        assert pair.read(1) == b'A'
        assert pair.write(b'out') == 3
        pair.close()
    assert reader.closed and writer.closed and pair.closed
    print('closed', reader.closed, writer.closed, pair.closed, flush=True)
finally:
    reader.close()
    writer.close()
