from pathlib import Path
import ctypes,os,hashlib,json,signal,stat,struct,subprocess,sys,time
r=Path(__file__).resolve().parent;b=r.parents[2];pin,lane=sys.argv[1:3];out=r/'raw'/pin/lane;out.mkdir(parents=True,exist_ok=True);sha=lambda x:hashlib.sha256(x).hexdigest();code=r/'src/trace_close.py';env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','LD_PRELOAD','IMRE_PYTHON')};env.update(PYTHONDONTWRITEBYTECODE='1');cmd=list(map(str,([b/'python/managed/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14','-EB',code] if pin=='cpython' else [out/'suite'])));libc=ctypes.CDLL(None,use_errno=True);assert libc.prctl(36,1,0,0,0)==0
if pin!='cpython':
  build=json.loads((out/'build.json').read_text());assert build['exit']==0 and build['binary_sha256']==sha((out/'suite').read_bytes()) and build['driver_sha256']==sha(code.read_bytes());env['IMRE_PYTHON']=str(b/'fs-family/provider-replay/pairs'/pin/'imre')
for case in ('ordered','dual-error','mixed'):
 d=out/case;d.mkdir(exist_ok=False);w=d/'cwd';t=d/'tmpdir';w.mkdir();t.mkdir();probes=[w/'input.bin',w/'output.bin'];probes[0].write_bytes(b'A');probes[1].write_bytes(b'');ino=[f.stat().st_ino for f in probes]; fd=libc.inotify_init1(os.O_CLOEXEC|os.O_NONBLOCK);assert fd>=0;wd=libc.inotify_add_watch(fd,os.fsencode(w),24);assert wd>=0;timed=False;st=time.monotonic()
 with (d/'stdout').open('wb') as o,(d/'stderr').open('wb') as e:
  p=subprocess.Popen(cmd+[case],cwd=w,env={**env,'TMPDIR':str(t)},stdin=subprocess.PIPE,stdout=o,stderr=e,start_new_session=True)
  try:p.wait(timeout=45)
  except subprocess.TimeoutExpired:timed=True
  finally:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait(timeout=10);held=stat.S_ISFIFO(os.fstat(p.stdin.fileno()).st_mode) and not p.stdin.closed;p.stdin.close()
 ev=[]
 while True:
  try:data=os.read(fd,65536)
  except BlockingIOError:break
  i=0
  while i<len(data):
   watch,mask,cookie,l=struct.unpack_from('iIII',data,i);i+=16;n=data[i:i+l].split(b'\0',1)[0].decode();i+=l; ev.append([n,mask]);assert watch==wd and mask in (8,16)
 os.close(fd)
 try:adopted=os.waitpid(-1,os.WNOHANG)
 except ChildProcessError:adopted=[]
 assert adopted==[]; final=[]
 for j,f in enumerate(probes):
  s=f.stat(); assert s.st_ino==ino[j] and stat.S_ISREG(s.st_mode);val=f.read_bytes();final.append({'name':f.name,'inode':s.st_ino,'hex':val.hex(),'sha256':sha(val)});f.unlink()
 residue={'cwd':[x.name for x in w.iterdir()],'tmpdir':[x.name for x in t.iterdir()]};
 for f in (w,t):
  if not list(f.iterdir()):f.rmdir()
 rec=dict(revision=pin,lane=lane,case=case,argv=cmd+[case],exit=p.returncode,timeout=timed,stdin_held=held,adopted=adopted,elapsed_s=round(time.monotonic()-st,3),fixture_sha256=sha(code.read_bytes()),stdout_sha256=sha((d/'stdout').read_bytes()),stderr_sha256=sha((d/'stderr').read_bytes()),inotify_close_order=ev,final=final,residue=residue);(d/'result.json').write_text(json.dumps(rec,indent=2)+'\n'); print(pin[:8],lane,case,p.returncode,ev,(d/'stdout').read_text().splitlines()[-2:],flush=True)
