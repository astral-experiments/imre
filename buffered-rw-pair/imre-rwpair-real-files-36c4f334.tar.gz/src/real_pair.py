import io
import _io
import os
import sys

def boundary(label):
    print('inspect', label, flush=True)
    assert sys.stdin.readline() == 'recorded\n'

def closed_fd(fd):
    try:
        os.fstat(fd)
    except OSError as exc:
        assert exc.errno == 9
    else:
        raise AssertionError('descriptor still open')

def real(kind, invert):
    reader = io.FileIO('input.bin', 'r')
    writer = io.FileIO('output.bin', 'w')
    try:
        pair = kind(reader, writer, 4)
        try:
            rfd, wfd = reader.fileno(), writer.fileno()
            assert rfd != wfd and os.fstat(rfd).st_ino != os.fstat(wfd).st_ino
            assert type(pair) is io.BufferedRWPair and isinstance(pair, io.BufferedIOBase)
            assert pair.readable() and pair.writable() and not pair.seekable()
            first = pair.read(1)
            if invert:
                assert first == b'Z', 'reversed input byte'
            assert first == b'A' and reader.tell() == 4
            assert pair.read1(1) == b'B'
            target = bytearray(2)
            assert pair.readinto(target) == 2 and bytes(target) == b'\nC'
            assert pair.write(b'abc') == 3
            boundary('buffered')
            assert pair.write(b'de') == 2
            boundary('overflow')
            pair.flush()
            boundary('flushed')
            more = bytearray(b'FG')
            assert pair.write(more) == 2
            more[0] = 88
            assert pair.read() == b'DEFG'
        finally:
            pair.close()
        assert pair.closed and reader.closed and writer.closed
        closed_fd(rfd)
        closed_fd(wfd)
        pair.close()
        boundary('closed')
    finally:
        reader.close()
        writer.close()

def invalid(kind, mode):
    reader = io.FileIO('input.bin', 'r')
    writer = io.FileIO('output.bin', 'w')
    try:
        try:
            if mode == 'not-readable':
                kind(writer, writer, 4)
            elif mode == 'not-writable':
                kind(reader, reader, 4)
            elif mode == 'zero':
                kind(reader, writer, 0)
            else:
                pair = kind(reader, writer, 4)
                try:
                    pair.write('text')
                finally:
                    pair.close()
        except (io.UnsupportedOperation, ValueError, TypeError) as exc:
            print('error', mode, type(exc).__name__, str(exc), flush=True)
            if mode == 'zero':
                assert type(exc) is ValueError and 'strictly positive' in str(exc)
            elif mode == 'wrong-type':
                assert type(exc) is TypeError and 'bytes-like' in str(exc)
            else:
                assert type(exc) is io.UnsupportedOperation
                assert ('readable' if mode == 'not-readable' else 'writable') in str(exc)
        else:
            raise AssertionError('invalid input was accepted')
        if mode == 'wrong-type':
            assert reader.closed and writer.closed
        else:
            assert not reader.closed and not writer.closed
    finally:
        reader.close()
        writer.close()

class CloseReader(io.FileIO):
    def close(self):
        if self.fail:
            self.events.append('reader')
            raise RuntimeError('reader-close')
        super().close()

class CloseWriter(io.FileIO):
    def close(self):
        if self.fail:
            self.events.append('writer')
            raise LookupError('writer-close')
        super().close()

def close_errors(kind):
    r = CloseReader('input.bin', 'r')
    w = CloseWriter('output.bin', 'w')
    events = []
    r.events = w.events = events
    r.fail = w.fail = True
    try:
        pair = kind(r, w, 4)
        try:
            pair.close()
        except RuntimeError as exc:
            print('close-errors', events, type(exc).__name__, str(exc), type(exc.__context__).__name__, str(exc.__context__), flush=True)
            assert str(exc) == 'reader-close' and type(exc.__context__) is LookupError and str(exc.__context__) == 'writer-close'
            assert events == ['writer', 'reader'] and not pair.closed
            assert not r.closed and not w.closed
        else:
            raise AssertionError('expected reader close failure')
        r.fail = w.fail = False
        pair.close()
        assert r.closed and w.closed
    finally:
        r.fail = w.fail = False
        r.close()
        w.close()

kind = io.BufferedRWPair
assert kind is _io.BufferedRWPair
assert kind.__mro__[:3] == (kind, _io._BufferedIOBase, _io._IOBase)
mode = sys.argv[1]
if mode in ('real', 'inverted'):
    real(kind, mode == 'inverted')
elif mode == 'close-errors':
    close_errors(kind)
else:
    invalid(kind, mode)
print('done', mode, flush=True)
