from pathlib import Path
import ctypes,hashlib,json,os,select,signal,stat,subprocess,sys,time
r=Path(__file__).resolve().parent;b=r.parents[1];pin,lane=sys.argv[1:3]; folder=r/'raw'/pin/lane;folder.mkdir(parents=True,exist_ok=True);fixture=r/'src/real_pair.py';sha=lambda b:hashlib.sha256(b).hexdigest(); src=b'AB\nCDEFG'; expected={'buffered':b'', 'overflow':b'abc', 'flushed':b'abcde','closed':b'abcdeFG'};env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','LD_PRELOAD','IMRE_PYTHON')};env['PYTHONDONTWRITEBYTECODE']='1';args=[b/'python/managed/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14','-EB',fixture] if pin=='cpython' else [folder/'suite'];args=list(map(str,args)); assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
if pin!='cpython':
 stop=time.monotonic()+1100
 while not (folder/'build.json').exists():
  if time.monotonic()>stop:raise TimeoutError(folder)
  time.sleep(2)
 build=json.loads((folder/'build.json').read_text());assert build['exit']==0 and build['driver_sha256']==sha(fixture.read_bytes()) and build['binary_sha256']==sha((folder/'suite').read_bytes());env.update(IMRE_PYTHON=str(b/'fs-family/provider-replay/pairs'/pin/'imre'),LD_LIBRARY_PATH=str(b/'llvm/usr/lib/x86_64-linux-gnu'))
else:
 v=subprocess.check_output([args[0],'-EB','-c','import sys; print(sys.version); print(sys.platform); print(sys.implementation.name)']).decode().splitlines();assert v[0].startswith('3.14.5') and v[1:]==['linux','cpython'];(folder/'interpreter.json').write_text(json.dumps({'path':args[0],'sha256':sha(Path(args[0]).read_bytes()),'version':v},indent=2)+'\n')

def one(case):
 out=folder/case;out.mkdir();cwd=out/'cwd';tmp=out/'tmpdir'; cwd.mkdir();tmp.mkdir();paths=[cwd/'input.bin',cwd/'output.bin'];paths[0].write_bytes(src);paths[1].write_bytes(b''); before=[(x.stat().st_dev,x.stat().st_ino) for x in paths]; assert before[0]!=before[1]; events=[];elapsed=time.monotonic();buf=b'';pending=b'';timeout=False
 with (out/'stderr').open('wb') as err:
  p=subprocess.Popen([*args,case],cwd=cwd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,env={**env,'TMPDIR':str(tmp)},start_new_session=True)
  try:
   while time.monotonic()-elapsed<90:
    ready,_,_=select.select([p.stdout],[],[],1)
    if not ready:continue
    blob=os.read(p.stdout.fileno(),65536)
    if not blob:break
    buf+=blob;pending+=blob
    while b'\n' in pending:
     line,pending=pending.split(b'\n',1)
     if line.startswith(b'inspect '):
      phase=line[8:].decode();assert phase in expected; samples=[x.read_bytes() for x in paths];opened=[[],[]]
      for fd in Path(f'/proc/{p.pid}/fd').iterdir():
       try:s=fd.stat()
       except FileNotFoundError:continue
       for i,identity in enumerate(before):
        if identity==(s.st_dev,s.st_ino):opened[i].append(int(fd.name))
      events.append({'phase':phase,'input':samples[0].hex(),'output':samples[1].hex(),'open_fds':opened,'same_inodes':before==[(x.stat().st_dev,x.stat().st_ino) for x in paths]});p.stdin.write(b'recorded\n');p.stdin.flush()
   else:timeout=True
   if not timeout:p.wait(timeout=10)
  finally:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait(timeout=10);held=stat.S_ISFIFO(os.fstat(p.stdin.fileno()).st_mode) and not p.stdin.closed;p.stdin.close();buf+=p.stdout.read();p.stdout.close()
 adopted=[]
 while True:
  try:pid,st=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if not pid:raise RuntimeError('living adopted descendant')
  adopted.append([pid,st]);
 final=[]
 for i,path in enumerate(paths):
  st=path.stat();assert (st.st_dev,st.st_ino)==before[i] and stat.S_ISREG(st.st_mode);data=path.read_bytes();final.append({'name':path.name,'inode':st.st_ino,'size':st.st_size,'mode':oct(st.st_mode),'bytes':data.hex(),'sha256':sha(data)});path.unlink()
 residues={n:sorted(str(x.relative_to(a)) for x in a.rglob('*')) for n,a in [('cwd',cwd),('tmpdir',tmp)]};
 for a in (cwd,tmp):
  if not any(a.iterdir()):a.rmdir()
 (out/'stdout').write_bytes(buf);e=(out/'stderr').read_bytes();rec={'pin':pin,'lane':lane,'case':case,'argv':[*args,case],'exit':p.returncode,'timeout':timeout,'stdin_held':held,'adopted':adopted,'residue':residues,'events':events,'final':final,'stdout_sha256':sha(buf),'stderr_sha256':sha(e),'fixture_sha256':sha(fixture.read_bytes()),'elapsed_s':round(time.monotonic()-elapsed,3)};(out/'result.json').write_text(json.dumps(rec,indent=2)+'\n'); print(pin[:8],lane,case,p.returncode,e.decode(errors='replace').splitlines()[-1:] or 'clean',flush=True)
for x in sys.argv[3:] or ('real','not-readable','not-writable','wrong-type','zero','close-errors','inverted'):one(x)
