"""Validate exact mode receipts, kernel order, portable byte witnesses, and specified differences."""
from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent;data=json.loads((r/'packet.json').read_bytes()); source=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); total=0; keys=[];srcinput=b'AB\nCDEFG';milestones=[b'',b'abc',b'abcde',b'abcdeFG'];phases=['buffered','overflow','flushed','closed']
for f in sorted(r.glob('**/raw/*/*/*/result.json')):
 d=f.parent;rec=json.loads(f.read_bytes());case=rec['case'];kernel='kernel' in f.relative_to(r).parts;lane=rec['lane'];pin=rec.get('pin',rec.get('revision')); stock=pin=='cpython';prefix=r/'kernel' if kernel else r;fx=prefix/('src/trace_close.py' if kernel else 'src/real_pair.py');assert rec['fixture_sha256']==source(fx); assert (d/'stdout').exists() and rec['stdout_sha256']==source(d/'stdout') and rec['stderr_sha256']==source(d/'stderr'); o=(d/'stdout').read_text();e=(d/'stderr').read_text();assert rec['stdin_held'] and not rec['timeout'] and not rec['adopted'] and rec['residue']=={'cwd':[],'tmpdir':[]};assert rec['final'][0]['inode']!=rec['final'][1]['inode'];field='hex' if kernel else 'bytes'
 if not stock:
  b=json.loads((d.parent/'build.json').read_bytes());assert b['pin']==pin and b['exit']==0 and b['driver_sha256']==source(fx) and b['argv'][b['argv'].index('--opt-level')+1]==lane[-1] and '--runtime-imports' in b['argv'];assert len(b['binary_sha256'])==64 and b['pair']==data['build_pairs'][pin];assert rec['argv'][0]==b['argv'][b['argv'].index('-o')+1]
 role=data['pins'][pin]
 if role=='absent':
  assert rec['exit']==1 and "AttributeError: module 'io' has no attribute 'BufferedRWPair'" in e and not o and not rec['events']; assert [bytes.fromhex(z[field]) for z in rec['final']]==[srcinput,b'']
 elif kernel:
  assert rec['exit']==0 and e=='';assert [bytes.fromhex(z[field]) for z in rec['final']]==[b'A',b'out' if case=='ordered' else b'']; assert re.search(r'^descriptor-order (\d+) (\d+)$',o,re.M);assert o.endswith('closed True True True\n');assert rec['inotify_close_order']=={'ordered':[['output.bin',8],['input.bin',16]],'dual-error':[['input.bin',16],['output.bin',8]],'mixed':[['input.bin',16]]}[case]
  if case!='ordered':assert 'chain OSError 9 OSError '+('28' if case=='mixed' else '9')+'\n' in o
 elif case=='real':
  assert rec['exit']==0 and not e and o.endswith('done real\n');events=rec['events']; assert [ev['phase'] for ev in events]==phases; assert [bytes.fromhex(ev['output']) for ev in events]==milestones; assert all(bytes.fromhex(ev['input'])==srcinput and ev['same_inodes'] for ev in events);assert all([len(fds) for fds in ev['open_fds']]==[1,1] and ev['open_fds'][0]!=ev['open_fds'][1] for ev in events[:3]);assert events[3]['open_fds']==[[],[]];assert [bytes.fromhex(z[field]) for z in rec['final']]==[srcinput,b'abcdeFG']
 elif case=='inverted':
  assert rec['exit']==1 and e.strip().endswith('AssertionError: reversed input byte') and not rec['events'];assert [bytes.fromhex(z[field]) for z in rec['final']]==[srcinput,b'']
 elif case=='close-errors':
  assert rec['exit']==1
  if stock:assert "['writer', 'reader'] RuntimeError reader-close LookupError writer-close" in o and e.strip().endswith('ValueError: flush of closed file')
  else:assert not o and e.strip().endswith('NotImplementedError: BufferedReader with Python raw methods is unsupported')
 else:
  assert case in ('not-readable','not-writable','zero','wrong-type') and not rec['events'];assert rec['exit']==0 and not e and o==(r/'raw/cpython/stock'/case/'stdout').read_text();assert [bytes.fromhex(z[field]) for z in rec['final']]==[srcinput,b'']
 total+=1; keys.append([pin,lane,'kernel' if kernel else 'outer',case])
assert total==len(data['runs']) and sorted(keys)==sorted(data['runs']);print(f'{total} bounded process receipts verified. Real-file snapshots and inverted content assertions checked. Linux inotify and opposite errno provenance independently check writer-first close and the two-sided failure chain.')
