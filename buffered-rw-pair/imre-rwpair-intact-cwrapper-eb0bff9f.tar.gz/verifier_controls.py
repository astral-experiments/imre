"""Synthetic verifier fault injections only: no specimens below are original receipts."""
from qualify import case,cpbase,scan,here
keys,oracle=cpbase()
ref=here/'raw/cpython/ordinary';m,o,e=case(ref/'class');x=keys[0][-1]
good=scan((m,o,e),keys,oracle);assert not good['excluded'] and len(good['started'])==82
def invalidate(label,m,o,e):
    r=scan((m,o,e),keys,oracle);assert r['excluded'],label
    print(label,'=>',','.join(r['excluded']))
invalidate('registration ordinal drift',m,o.replace('select\t445\t','select\t444\t',1),e)
invalidate('single passed as whole class',*case(ref/'single'))
invalidate('success after stop',m,o.replace('success\t'+x+'\t\nstop\t'+x+'\t','stop\t'+x+'\t\nsuccess\t'+x+'\t',1),e)
invalidate('unexpected stdout',m,o+'outside-protocol\n',e)
invalidate('unraisable',m,o,e+'Exception ignored in: <function __del__>\n')
invalidate('timeout',dict(m,timeout=True),o,e)
invalidate('adopted child',dict(m,adopted=[[5252,0]]),o,e)
invalidate('leftover file',dict(m,residue=['testfile']),o,e)
invalidate('missing summary',m,o,e.replace('Ran 82 tests','Ran no tests'))
invalidate('exit contradicts callbacks',dict(m,exit=1),o,e)
# Verify a different pre-registration exception yields zero observed original callbacks.
q=scan((dict(m,exit=1),'',"Traceback (most recent call last):\nAttributeError: fixture second blocked symbol\n"),keys,oracle)
assert q['stage']=='before registration' and not q['originals'] and q['first_exception']=='AttributeError: fixture second blocked symbol'
# An extra successful subtest is observed but cannot qualify as the canonical transcript.
q=scan((m,o.replace('success\t'+x+'\t','subtest\t'+x+'\t'+x+' (extra=True)\tok\nsuccess\t'+x+'\t',1),e),keys,oracle)
assert q['originals'][x]['observed']=='success' and not q['originals'][x]['canonical_success_transcript']
print('alternate blocker and unexpected subtest: 0 attributable successes')
