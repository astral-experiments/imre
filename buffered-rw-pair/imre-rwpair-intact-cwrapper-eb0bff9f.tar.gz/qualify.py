"""Keep observed callbacks and rigorously qualified successes in separate fields."""
import argparse,collections,csv,hashlib,json,re,sys
from pathlib import Path
here=Path(__file__).resolve().parent
from verify import audit,digest
ROOT='test.test_io.CTextIOWrapperTest.'
TIMING=re.compile(r'(?m)^(Ran \d+ tests? in )[\d.]+s$')
def norm(text):return TIMING.sub(r'\g<1><duration>s',text)
def case(d):
    m=json.loads((d/'result.json').read_text()); assert all(digest(d/n)==m[n+'_sha256'] for n in ('stdout','stderr'))
    assert m['cwd']!=m['tmpdir'] and m['stdin_pipe'] and m['stdin_parent_held_through_wait']
    return m,(d/'stdout').read_text(errors='backslashreplace'),(d/'stderr').read_text(errors='backslashreplace')
def scan(triple, expected, oracle):
    m,o,e=triple
    lines=o.splitlines();discovery=lines[:1]==['discovery\t667'];cohort=lines[1:2]==['class\t82']
    reg=[];i=2 if discovery and cohort else 0
    while i<len(lines) and lines[i].startswith('select\t'):
        members=lines[i].split('\t')
        if len(members)!=5 or not all(x.isdigit() for x in members[1:4]):break
        reg.append((*map(int,members[1:4]),members[4]));i+=1
    obs=collections.defaultdict(list);extra=[];events=[]
    for l in lines[i:]:
        p=l.split('\t')
        if len(p)>=3 and p[0] in ('start','success','skip','failure','error','subtest','stop'):
            obs[p[1]].append(p);events.append((p[0],p[1]))
        else:extra.append(l)
    # A suite-level traceback, a real original exception, or no exception are distinguishable.
    started=[k for op,k in events if op=='start'];stopped=[k for op,k in events if op=='stop']
    expected_keys=[q[-1] for q in expected];reason=[]
    if not (discovery and cohort and reg==expected):reason.append('registration tuple mismatch')
    if started!=expected_keys or stopped!=expected_keys:reason.append('start/stop sequence mismatch')
    active=None
    for op,k in events:
        if op=='start' and active is None:active=k
        elif op=='stop' and active==k:active=None
        elif active!=k or op in ('start','stop'):reason.append('interleaved or misordered callbacks');break
    if active is not None:reason.append('incomplete final callback')
    if extra:reason.append('unexpected stdout')
    runner_runs=re.findall(r'(?m)^Ran (\d+) tests? in [\d.]+s$',e)
    if runner_runs!=[str(len(expected))]:reason.append('runner count mismatch')
    if m['timeout'] or m['adopted'] or m['residue']:reason.append('timeout, child or filesystem residue')
    if any(v in e for v in ('Exception ignored','Exception in thread','unraisablehook','ResourceWarning:','Could not run clang')):reason.append('unexpected stderr diagnostic')
    if m['exit'] not in (0,1):reason.append('abnormal process exit')
    rows={}
    for k,ev in obs.items():
        status=[s for s in ev if s[0] in ('success','error','skip','failure')];sub=[t for t in ev if t[0]=='subtest']
        raw=[s[0] for s in status]
        state=raw[0] if len(raw)==1 else 'multiple callbacks' if raw else 'subtest non-success' if any(t[-1]!='ok' for t in sub) else 'incomplete'
        if ev[0][0]!='start' or ev[-1][0]!='stop':state='incomplete'
        canonical=([['start',k,'']]+[['subtest',k,n,'ok'] for n in oracle.get(k,[])]+[['success',k,''],['stop',k,'']])
        rows[k]=dict(observed=state,callbacks=ev,canonical_success_transcript=(ev==canonical and k in oracle))
    non_success=any(c['observed'] in ('error','failure','multiple callbacks','subtest non-success') for c in rows.values())
    if len(started)==len(expected) and len(stopped)==len(expected) and m['exit']!=int(not expected or non_success):reason.append('exit contradicts callbacks')
    first=next((s[2] for k,ev in obs.items() for s in ev if s[0] in ('failure','error')),None)
    if not first and 'Traceback (most recent call last):' in e:
        first=next((ln for ln in reversed(e.splitlines()) if re.match(r'^[A-Za-z_][\w.]*?(?:Error|Exception)(?:: |$)',ln)),None)
    return dict(stage='original callbacks' if started else 'after module registration' if any(l.startswith('discovery\t') for l in lines) else 'before registration',discovery=discovery,cohort=cohort,registration=reg,started=started,excluded=reason,originals=rows,first_exception=first,returncode=m['exit'],stderr_markers=[s for s in ('Exception ignored','Exception in thread','ResourceWarning:','unraisablehook') if s in e])
def cpbase():
    stage=here/'stage'
    assert all(digest(stage/n)==v for n,v in json.loads((here/'upstream-hashes.json').read_text()).items())
    assert digest(stage/'Lib/callback_class.py')==json.loads((here/'provenance.json').read_text())['driver_sha256']
    stock=audit(here/'raw/cpython/ordinary')
    keys=[(r['module_ordinal'],r['class_ordinal'],r['occurrence'],r['identity']) for r in stock['results']]
    oracle={r['identity']:r['subtests'] for r in stock['results']}
    assert digest(here/'fresh-oracle.json')==digest(here/'oracle.json') and json.loads((here/'fresh-oracle.json').read_text())==stock
    return keys,oracle
def valid_process(m):return not m['timeout'] and not m['residue'] and not m['adopted']
def inspect(pin,lane,keys,oracle):
    root=here/'raw'/pin/lane;ref=here/'raw/cpython/ordinary';b=json.loads((root/'build.json').read_text())
    assert b['pin']==pin and b['lane']==lane and b['driver_sha256']==digest(here/'stage/Lib/callback_class.py')
    assert all(digest(root/('build.'+s))==b[s+'_sha256'] for s in ('stdout','stderr'))
    out=dict(build=b)
    if b['timeout'] or b['exit']!=0:return dict(**out,stage='compile failure or timeout',qualified=[],selections={})
    assert b['executable_sha256']
    raw={sel:case(root/sel) for sel in ('class','wrong','provider','single')}
    assert all(m['revision']==pin and m['lane']==lane and m['visible_helper']==b['argv'][0] and m['argv'][0]==b['argv'][b['argv'].index('-o')+1] for m,_,_ in raw.values())
    cl=scan(raw['class'],keys,oracle);si=scan(raw['single'],keys[:1],oracle);wrong=scan(raw['wrong'],[],oracle);p,po,pe=raw['provider']
    crm,co,ce=case(ref/'class');w,wo,we=case(ref/'wrong');s,so,se=case(ref/'single')
    wm,wout,werr=raw['wrong'];sm,sout,serr=raw['single'];cm,cout,cerr=raw['class']
    wr=bool(valid_process(wm) and wm['exit']==1 and wout==wo and norm(werr)==norm(we) and not wrong['excluded'])
    pr=bool(valid_process(p) and p['exit']==0 and not pe and po.splitlines()[:2]==['discovery\t667','class\t82'] and len(po.splitlines())==4 and po.splitlines()[-1]=='provider True True True True True True True')
    # A real selected failure in the single is admissible evidence for other IDs, but must match its class callback.
    sk=keys[0][-1];srow=si['originals'].get(sk,{});crow=cl['originals'].get(sk,{})
    if srow.get('observed')=='success':single_ok=valid_process(sm) and sm['exit']==0 and sout==so and norm(serr)==norm(se)
    else:single_ok=not si['excluded'] and srow.get('observed') in ('error','failure','skip') and srow.get('observed')==crow.get('observed')
    controls=dict(absent=wr,provider=pr,single=bool(single_ok))
    exact=cm['exit']==0 and cout==co and norm(cerr)==norm(ce)
    passed=[]
    if all(controls.values()) and not cl['excluded']:
        for k,val in cl['originals'].items():
            if not val['canonical_success_transcript']:continue
            if exact:passed.append(k);continue
            # Mixed-result groups need an isolated CPython comparison to separate unexpected stderr.
            n=next(q[1] for q in keys if q[-1]==k);nd=root/('confirm-'+str(n));rd=ref/('confirm-'+str(n))
            if not ((nd/'result.json').exists() and (rd/'result.json').exists()):continue
            nm,no,ne=case(nd);rm,ro,re_=case(rd)
            if all(valid_process(m) and m['exit']==0 for m in (nm,rm)) and no==ro and norm(ne)==norm(re_) and not scan((nm,no,ne),[keys[n-1]],oracle)['excluded']:passed.append(k)
    return dict(**out,stage=cl['stage'],first_exception=cl['first_exception'],selections={'class':cl,'single':si,'wrong':wrong,'provider':dict(rc=p['exit'],stdout=po,stderr=pe)},controls=controls,full_clean_transcript=exact,qualified=passed)
def gen(pins,lanes):
    keys,oracle=cpbase();ledger=here/'global-1038-ae0e69c.tsv'
    assert digest(ledger)=='f4f208cfd969ac9ca40a16f52ed9fc37b7ceef1a3fd0b98e408dd3afd07bc88c'
    with ledger.open() as f:history=list(csv.DictReader(f,delimiter='\t'))
    h={(r['id'],int(r['occurrence'])):r for r in history};assert len(history)==1038
    allruns={p:{l:inspect(p,l,keys,oracle) for l in lanes} for p in pins}
    rows=[]
    for ordinal,pos,occ,k in keys:
        prior=h[k,occ];g=int(prior['index']);assert g==pos+682 and prior['reference_verdict']=='PASS' and all(prior[n]=='UNREACHED' for n in ('ordinary.O0','ordinary.O3','boxed.O0','boxed.O3'))
        row=dict(global_1038=g,module_667=ordinal,class_82=pos,occurrence=occ,id=k,stock='success')
        for p,lanes in allruns.items():
            for name,run in lanes.items():
                o=run['selections'].get('class',{}).get('originals',{}).get(k,{})
                row[p[:8]+'_'+name+'_observed']=o.get('observed','unreached')
                row[p[:8]+'_'+name+'_qualified']=int(k in run['qualified'])
        rows.append(row)
    return dict(pins=pins,lanes=lanes,stock={'registered':667,'class':82,'passed':82,'subtests':6},runs=allruns,rows=rows)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('pins',nargs='+');p.add_argument('--tsv',action='store_true');p.add_argument('--only',choices=['boxed-O0','boxed-O3']);a=p.parse_args();j=gen(a.pins,[a.only] if a.only else ['boxed-O0','boxed-O3'])
    if a.tsv:
        w=csv.DictWriter(sys.stdout,fieldnames=list(j['rows'][0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(j['rows'])
    else:print(json.dumps(j,indent=2))
