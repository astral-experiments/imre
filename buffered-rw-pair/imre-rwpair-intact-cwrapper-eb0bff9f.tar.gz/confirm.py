"""For a mixed-result class, isolate every candidate success on both runtimes before attribution."""
import json,os,subprocess,sys
from pathlib import Path
from qualify import cpbase,here,inspect
keys,oracle=cpbase()
pin=sys.argv[1];lane=sys.argv[2]
result=inspect(pin,lane,keys,oracle)
if result.get('full_clean_transcript') or not all(result.get('controls',{'none':False}).values()) or result['selections']['class']['excluded']:
    sys.exit(0)
potential={i for i,v in result['selections']['class']['originals'].items() if v['canonical_success_transcript']}
for ordinal,n,occ,k in keys:
    if k not in potential:continue
    label='confirm-'+str(n)
    ref=here/'raw/cpython/ordinary'
    src=json.loads((ref/'class/result.json').read_text())['argv']
    if not (ref/label/'result.json').exists():
        subprocess.run([sys.executable,'-B',here/'run_one.py','ordinary','cpython',label,k,*src[:-1]],check=True,timeout=650)
    native=here/'raw'/pin/lane
    if not (native/label/'result.json').exists():
        cmd=json.loads((native/'class/result.json').read_text())['argv']
        subprocess.run([sys.executable,'-B',here/'run_one.py',lane,pin,label,k,*cmd[:-1]],check=True,timeout=650)
