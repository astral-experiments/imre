"""Build from the verified public compiler/runtime, exercise the same registered selections."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,signal,subprocess,sys,time
d=Path(__file__).resolve().parent;base=d.parents[1];p=sys.argv[1]
pair=Path(os.environ['CWRAPPER_PAIR']).resolve();llvm=Path(os.environ['CWRAPPER_LLVM']).resolve()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def lane(name):
    mode=name.split('-')[0];raw=d/'raw'/p/name;raw.mkdir(parents=True)
    lib=d/'stage/Lib';driver=lib/'callback_class.py'
    files=json.loads((d/'upstream-hashes.json').read_text());assert all(sha(lib.parent/path)==h for path,h in files.items())
    deadline=time.monotonic()+1800
    while not (pair/'ready').exists():
        if time.monotonic()>deadline:raise TimeoutError(pair)
        time.sleep(3)
    assert (pair/'commit').read_text().strip()==p
    hashes={n:h for h,n in [s.split() for s in (pair/'ready').read_text().splitlines()]}
    assert all(sha(pair/n)==h for n,h in hashes.items())
    exe=raw/'suite';cmd=list(map(str,[pair/'imre','build',driver,'--module-root',lib,'--opt-level',name[-1],'--no-cache','--runtime',pair/'libimre_runtime.a','--clang',llvm/'usr/bin/clang-19','-o',exe]))
    if mode=='boxed':cmd.append('--runtime-imports')
    scratch=raw/'buildtmp';scratch.mkdir()
    timeout=False;rc=None
    try:
        with (raw/'build.stdout').open('wb') as o,(raw/'build.stderr').open('wb') as e:
            proc=subprocess.Popen(cmd,cwd=raw,env={**os.environ,'TMPDIR':str(scratch),'LD_LIBRARY_PATH':str(llvm/'usr/lib/x86_64-linux-gnu')},stdout=o,stderr=e,start_new_session=True)
            try:rc=proc.wait(timeout=1200)
            except subprocess.TimeoutExpired:
                timeout=True
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                proc.wait(timeout=20)
    finally:pass
    (raw/'build.json').write_text(json.dumps(dict(pin=p,lane=name,compiler_runtime=hashes,driver_sha256=sha(driver),argv=cmd,exit=rc,timeout=timeout,stdout_sha256=sha(raw/'build.stdout'),stderr_sha256=sha(raw/'build.stderr'),executable_sha256=sha(exe) if exe.exists() else None),indent=2)+'\n')
    print(name,'BUILD',rc,timeout,flush=True)
    if rc!=0 or timeout:return
    def run(st):
        key,selector=st
        subprocess.run([sys.executable,'-B',d/'run_one.py',name,p,key,selector,exe],check=True,timeout=1900)
    selections=[('class','--class'),('single','test.test_io.CTextIOWrapperTest.test_append_bom'),('wrong','test.test_io.CTextIOWrapperTest.test_nonexistent_textio_selection'),('provider','--provider')]
    with ThreadPoolExecutor(2) as ex:list(ex.map(run,selections))
with ThreadPoolExecutor(len(sys.argv[2:])) as ex:list(ex.map(lane,sys.argv[2:]))
