import sys
if sys.argv[1] == 'hook-audit':
    import gc
    import io
    import os
    import sys

    events = []
    def observe(event):
        gc.collect()
        e = event.exc_value
        events.append((event.exc_type.__name__, e.errno, e.__context__ is None,
                       event.exc_traceback is not None, event.object is None,
                       event.err_msg.startswith("Exception ignored while finalizing file <_io.BufferedReader")))

    class FailingWriter(io.FileIO):
        count = 0
        def writable(self):
            self.count += 1
            if self.count == 2:
                os.close(r.fileno())
                return False
            return True

    def exercise():
        saved = sys.unraisablehook
        sys.unraisablehook = observe
        try:
            try:
                io.BufferedRWPair(r, w, 5)
            except io.UnsupportedOperation as primary:
                print('PRIMARY', str(primary), primary.__context__ is None)
            print('BEFORE', len(events), r.closed, w.closed)
            gc.collect()
            print('AFTER', len(events), r.closed, w.closed)
            print('EVENTS', events)
            assert events == [('OSError', 9, True, True, True, True)]
        finally:
            sys.unraisablehook = saved

    with io.FileIO('/dev/null','r') as r, FailingWriter('/dev/null','w') as w:
        exercise()
if sys.argv[1] == 'ordering-review':
    import gc
    import io
    import weakref

    events = []
    reader = io.FileIO('/dev/null', 'r')

    class Writer(io.FileIO):
        def close(self):
            events.append(('writer', reader.closed))
            return super().close()

    writer = Writer('/dev/null', 'w')
    pair = io.BufferedRWPair(reader, writer, 16)
    pair.write(b'abc')

    def old_callback(wr):
        events.append(('old', wr() is None, wr.__callback__ is None, reader.closed, writer.closed))

    def owner_only_callback(wr):
        events.append(('owner', wr() is None, wr.__callback__ is None, old_ref() is None, reader.closed, writer.closed))
        gc.collect()
        events.append(('after-nested-gc', reader.closed, writer.closed))

    def discarded_callback(wr):
        events.append(('discarded',))

    old_ref = weakref.ref(pair, old_callback)
    pair.wr = weakref.ref(pair, owner_only_callback)
    unused = weakref.ref(pair, discarded_callback)
    del unused
    keep_method = pair.write
    del pair
    print('retained', old_ref() is not None, reader.closed, writer.closed, events)
    assert events == [] and old_ref() is not None and not reader.closed and not writer.closed
    assert keep_method(b'x') == 1
    del keep_method
    print('released', old_ref() is None, reader.closed, writer.closed, events, flush=True)
    expected = [('owner', True, True, True, False, False), ('after-nested-gc', False, False), ('old', True, True, False, False), ('writer', True)]
    assert events == expected and old_ref() is None and reader.closed and writer.closed
    gc.collect()
    print('collected', events == expected)
    assert events == expected
if sys.argv[1] == 'ordering-resurrect':
    import gc
    import io
    import weakref

    class Keeper:
        def __del__(self):
            rescued.append(self)

    class ObserveWriter(io.FileIO):
        def close(self):
            events.append(('writer', reader.closed))
            return super().close()

    def callback(wr):
        events.append(('weak', wr() is None, reader.closed, writer.closed))

    reader = io.FileIO('/dev/null', 'r')
    writer = ObserveWriter('/dev/null', 'w')
    events = []
    rescued = []
    keeper = Keeper()
    keeper.pair = io.BufferedRWPair(reader, writer, 8)
    ref = weakref.ref(keeper.pair, callback)
    del keeper
    print('rescued', len(rescued), ref() is rescued[0].pair, reader.closed, writer.closed, events)
    assert len(rescued) == 1 and ref() is rescued[0].pair and not events
    assert rescued[0].pair.write(b'x') == 1
    gc.collect()
    assert not reader.closed and not writer.closed and not events
    rescued.clear()
    print('released', ref() is None, reader.closed, writer.closed, events, flush=True)
    assert events == [('weak', True, False, False), ('writer', True)] and ref() is None and reader.closed and writer.closed
    gc.collect()
    print('collected', events, len(rescued))
    assert len(rescued) == 0 and events == [('weak', True, False, False), ('writer', True)]
