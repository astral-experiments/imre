from pathlib import Path
import hashlib,json,sys,time,textwrap
here=Path(__file__).resolve().parent
root=here.parent
base=root.parent
sha='8dd5c5f9e1222a48ec4090dc87017ebd51545496'
controls=('hook-audit','ordering-review','ordering-resurrect')
ctrl=base/'textio/controls/run.py'
ns={'__file__':str(ctrl)}
exec(compile(ctrl.read_text().rsplit('lane(sys.argv[1])',1)[0],str(ctrl),'exec'),ns)
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
lane=sys.argv[1];out=here/lane;out.mkdir()
src=out/'combined.py'
src.write_text('import sys\n' + ''.join(f'if sys.argv[1] == {name!r}:\n' + textwrap.indent((root/name/'observe.py').read_text(),'    ') for name in controls))
if lane=='stock':
    cmd=[ns['ref'],'-IB',src]
else:
    pair=base/'fs-family/provider-replay/pairs'/sha
    deadline=time.monotonic()+480
    while not (pair/'ready').exists():
        if time.monotonic()>=deadline:raise TimeoutError(pair)
        time.sleep(2)
    hashes={name:h for h,name in [line.split() for line in (pair/'ready').read_text().splitlines()]}
    assert (pair/'commit').read_text().strip()==sha and all(digest(pair/n)==h for n,h in hashes.items())
    ns['env']['IMRE_PYTHON']=str(pair/'imre')
    b=out/'build';b.mkdir();binary=out/'probe';cmd=[binary]
    args=[pair/'imre','build',src,'--module-root',out,'--opt-level',lane[-1],'--runtime-imports','--no-cache','--runtime',pair/'libimre_runtime.a','--clang',base/'llvm/usr/bin/clang-19','-o',binary]
    m=ns['run'](args,b,b,500);m['hashes']=hashes;(b/'result.json').write_text(json.dumps(m,indent=2));assert m['rc']==0,(b/'stderr').read_text()
for name in controls:
    dst=out/name;dst.mkdir();cwd=dst/'cwd';cwd.mkdir();m=ns['run'](cmd+[name],cwd,dst,35)
    assert not list(cwd.iterdir())
    m.update(sha=sha if lane!='stock' else 'CPython-3.14.5',source_sha256=digest(src),original_control_sha256=digest(root/name/'observe.py'))
    same=all((dst/stream).read_bytes()==(root/name/'stock'/stream).read_bytes() for stream in ('stdout','stderr'))
    m['standalone_stock_raw_match']=same
    (dst/'result.json').write_text(json.dumps(m,indent=2))
    print(lane,name,m['rc'],same,(dst/'stdout').read_text(),(dst/'stderr').read_text(),flush=True)
    assert m["rc"] == 1 and not same and b"AssertionError" in (dst/"stderr").read_bytes()
    if name=="hook-audit":assert b"BEFORE 0 True False" in (dst/"stdout").read_bytes()
    else:assert b"('writer', False)" in (dst/"stdout").read_bytes()
if lane!='stock':binary.unlink()
