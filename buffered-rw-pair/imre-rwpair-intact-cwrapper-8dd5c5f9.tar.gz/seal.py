"""Publish verified raw streams, strict case ledger and replay sources across explicit revisions."""
import hashlib,json,os,re,subprocess,sys,tarfile,tempfile
from pathlib import Path
from qualify import here,digest
pin=sys.argv[1];pins=sys.argv[2:] or [pin]
assert pin in pins and all(re.fullmatch(r'[0-9a-f]{40}',p) for p in pins)
early=os.environ.get('RWEARLY');assert early in (None,'boxed-O0','boxed-O3')
extra=['--only',early] if early else []
name='imre-rwpair-intact-cwrapper-'+pin[:8]+('-'+early+'-early' if early else '')
shared=Path(os.environ.get('RWPUBLISH','/workspace/shared/downloads'))
shared.mkdir(parents=True,exist_ok=True)
def out(script,args,cwd=here):return subprocess.check_output([sys.executable,'-B',script,*args],cwd=cwd)
with tempfile.TemporaryDirectory(dir=here) as t:
    tmp=Path(t); payload={}
    for f in ['verify.py','run_native.py','run_one.py','confirm.py','qualify.py','seal.py','error_kinds.py','verifier_controls.py','verifier-controls.txt','README.md','upstream-hashes.json','oracle.json','fresh-oracle.json','provenance.json','global-1038-ae0e69c.tsv','stage/Lib/callback_class.py']:
        payload[f]=here/f
    for n in json.loads((here/'upstream-hashes.json').read_text()):payload['stage/'+n]=here/'stage'/n
    for p in [*pins,'cpython']:
        for f in (here/'raw'/p).rglob('*'):
            if f.parent.name.startswith('confirm-') and (early or not (f.parent/'result.json').is_file()):continue
            if (p=='cpython' or not early or f.relative_to(here/'raw'/p).parts[0]==early) and f.name in ('stdout','stderr','result.json','build.json','build.stderr','build.stdout'):
                payload[str(f.relative_to(here))]=f
    for n,opts in [('evidence.json',[]),('originals.tsv',['--tsv'])]:
        f=tmp/n;f.write_bytes(out('qualify.py',[*pins,*extra,*opts]));payload[n]=f
    for p in pins:
        for base in (here.parents[1]/'fs-family/provider-replay/checkouts'/p,here.parent/'repo'):
            if not base.exists():continue
            git=subprocess.run(['git','-C',base,'cat-file','-p',p],capture_output=True)
            if git.returncode==0:
                f=tmp/(p+'.commit');f.write_bytes(git.stdout);payload['git-commits/'+f.name]=f
                raw=subprocess.check_output(['git','-C',base,'ls-tree','-r',p,'--','crates/imre-runtime/src/dynamic/stdlib/io.rs','crates/imre-runtime/src/dynamic/stdlib/io/'])
                manifest=[]
                for line in raw.decode().splitlines():
                    left,path=line.split('\t',1);blob=left.split()[2]
                    data=subprocess.check_output(['git','-C',base,'cat-file','blob',blob]);manifest.append(dict(path=path,git_blob=blob,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
                assert manifest
                f=tmp/(p+'.io-sources.json');f.write_text(json.dumps(manifest,indent=2)+'\n');payload['git-commits/'+f.name]=f
                break
    m=tmp/'SHA256SUMS';m.write_text(''.join(digest(f)+'  '+n+'\n' for n,f in sorted(payload.items())))
    payload[m.name]=m;archive=tmp/(name+'.tar.gz')
    with tarfile.open(archive,'w:gz') as tar:
        for n,f in sorted(payload.items()):tar.add(f,arcname=n)
    r=tmp/'verify';r.mkdir()
    with tarfile.open(archive) as tar:tar.extractall(r,filter='data')
    subprocess.run(['sha256sum','--quiet','-c','SHA256SUMS'],cwd=r,check=True)
    assert out('verify.py',[],r)==(r/'fresh-oracle.json').read_bytes()
    assert out('verifier_controls.py',[],r)==(r/'verifier-controls.txt').read_bytes()
    for n,opts in [('evidence.json',[]),('originals.tsv',['--tsv'])]:assert out('qualify.py',[*pins,*extra,*opts],r)==(r/n).read_bytes()
    for f,n in [(archive,archive.name),(tmp/'originals.tsv',name+'.tsv')]:
        dest=shared/n
        if dest.exists():assert digest(dest)==digest(f)
        else:
            with dest.open('xb') as fp:fp.write(f.read_bytes())
            dest.chmod(0o644)
        print(dest,dest.stat().st_size,digest(dest),flush=True)
