"""Isolate candidate passes and representative error phases, without changing the original class."""
import collections,fcntl,json,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
from qualify import cpbase,here,inspect
keys,oracle=cpbase();pin,lane=sys.argv[1:3];res=inspect(pin,lane,keys,oracle)
group=res.get('selections',{}).get('class',{});obs=group.get('originals',{})
if not obs:sys.exit(0)
controls=all(res.get('controls',{}).values())
targets=set()
if not res.get('full_clean_transcript') and controls and not group['excluded']:
    targets.update(k for k,v in obs.items() if v['canonical_success_transcript'])
buckets=set()
for _ordinal,n,occ,k in keys:
    if k not in obs:continue
    o=obs[k];state=o['observed']
    if state!='success':
        sig=(state,tuple(x['type'] for x in o['exceptions']),tuple(o['phase_labels']),tuple(tuple(x['line'] for x in t['upstream_frames']) for t in o['tracebacks']))
        if sig not in buckets and len(buckets)<7:targets.add(k);buckets.add(sig)
for k in [keys[0][-1].rsplit('.',1)[0]+'.test_tell_after_readline_with_cr',keys[0][-1].rsplit('.',1)[0]+'.test_telling']:
    if k in obs:targets.add(k)
# The first real ID has an independent single in this lane and the stock run.
targets.discard(keys[0][-1])
def run(key):
    full,n,occ,k=key;label='confirm-'+str(n);ref=here/'raw/cpython/ordinary';native=here/'raw'/pin/lane
    with (here/('.ref-confirm-'+str(n)+'.lock')).open('w') as f:
        fcntl.flock(f,fcntl.LOCK_EX)
        if not (ref/label/'result.json').exists():
            cmd=json.loads((ref/'class/result.json').read_text())['argv']
            subprocess.run([sys.executable,'-B',here/'run_one.py','ordinary','cpython',label,k,*cmd[:-1]],check=True,timeout=650)
    if not (native/label/'result.json').exists():
        cmd=json.loads((native/'class/result.json').read_text())['argv']
        subprocess.run([sys.executable,'-B',here/'run_one.py',lane,pin,label,k,*cmd[:-1]],check=True,timeout=650)
with ThreadPoolExecutor(2) as ex:list(ex.map(run,[key for key in keys if key[-1] in targets]))
