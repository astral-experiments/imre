import gc
import io
import os
import sys

events = []
def observe(event):
    gc.collect()
    e = event.exc_value
    events.append((event.exc_type.__name__, e.errno, e.__context__ is None,
                   event.exc_traceback is not None, event.object is None,
                   event.err_msg.startswith("Exception ignored while finalizing file <_io.BufferedReader")))

class FailingWriter(io.FileIO):
    count = 0
    def writable(self):
        self.count += 1
        if self.count == 2:
            os.close(r.fileno())
            return False
        return True

def exercise():
    saved = sys.unraisablehook
    sys.unraisablehook = observe
    try:
        try:
            io.BufferedRWPair(r, w, 5)
        except io.UnsupportedOperation as primary:
            print('PRIMARY', str(primary), primary.__context__ is None)
        print('BEFORE', len(events), r.closed, w.closed)
        gc.collect()
        print('AFTER', len(events), r.closed, w.closed)
        print('EVENTS', events)
        assert events == [('OSError', 9, True, True, True, True)]
    finally:
        sys.unraisablehook = saved

with io.FileIO('/dev/null','r') as r, FailingWriter('/dev/null','w') as w:
    exercise()
