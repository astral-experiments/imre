import gc
import io
import weakref

events = []
reader = io.FileIO('/dev/null', 'r')

class Writer(io.FileIO):
    def close(self):
        events.append(('writer', reader.closed))
        return super().close()

writer = Writer('/dev/null', 'w')
pair = io.BufferedRWPair(reader, writer, 16)
pair.write(b'abc')

def old_callback(wr):
    events.append(('old', wr() is None, wr.__callback__ is None, reader.closed, writer.closed))

def owner_only_callback(wr):
    events.append(('owner', wr() is None, wr.__callback__ is None, old_ref() is None, reader.closed, writer.closed))
    gc.collect()
    events.append(('after-nested-gc', reader.closed, writer.closed))

def discarded_callback(wr):
    events.append(('discarded',))

old_ref = weakref.ref(pair, old_callback)
pair.wr = weakref.ref(pair, owner_only_callback)
unused = weakref.ref(pair, discarded_callback)
del unused
keep_method = pair.write
del pair
print('retained', old_ref() is not None, reader.closed, writer.closed, events)
assert events == [] and old_ref() is not None and not reader.closed and not writer.closed
assert keep_method(b'x') == 1
del keep_method
print('released', old_ref() is None, reader.closed, writer.closed, events, flush=True)
expected = [('owner', True, True, True, False, False), ('after-nested-gc', False, False), ('old', True, True, False, False), ('writer', True)]
assert events == expected and old_ref() is None and reader.closed and writer.closed
gc.collect()
print('collected', events == expected)
assert events == expected
