from pathlib import Path
import hashlib,json,sys
here=Path(__file__).resolve().parent
ctrl=here.parents[1]/'textio/controls/run.py'
ns={'__file__':str(ctrl)}
exec(compile(ctrl.read_text().rsplit('lane(sys.argv[1])',1)[0],str(ctrl),'exec'),ns)
pin=sys.argv[1];opt=sys.argv[2] if len(sys.argv)>2 else '0';out=here/(pin if opt=='0' else pin+'-boxed-O'+opt);out.mkdir();src=here/'observe.py'
if pin=='stock':cmd=[ns['ref'],'-IB',src]
else:
 pair=ns['base']/'fs-family/provider-replay/pairs'/pin
 hashes={n:h for h,n in [x.split() for x in (pair/'ready').read_text().splitlines()]}
 assert (pair/'commit').read_text().strip()==pin and all(hashlib.sha256((pair/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
 ns['env']['IMRE_PYTHON']=str(pair/'imre')
 b=out/'build';b.mkdir();cmd=[out/'probe'];args=[pair/'imre','build',src,'--module-root',here,'--opt-level',opt,'--runtime-imports','--no-cache','--runtime',pair/'libimre_runtime.a','--clang',ns['base']/'llvm/usr/bin/clang-19','-o',cmd[0]]
 m=ns['run'](args,b,b,250);m['hashes']=hashes;(b/'result.json').write_text(json.dumps(m,indent=2));assert m['rc']==0,(b/'stderr').read_text()
cwd=out/'cwd';cwd.mkdir();m=ns['run'](cmd,cwd,out,35);assert not list(cwd.iterdir());m['sha']=pin;m['src_hash']=hashlib.sha256(src.read_bytes()).hexdigest();(out/'result.json').write_text(json.dumps(m,indent=2))
print(pin,m['rc'],(out/'stdout').read_text(),(out/'stderr').read_text()); 
if pin!='stock':cmd[0].unlink()
