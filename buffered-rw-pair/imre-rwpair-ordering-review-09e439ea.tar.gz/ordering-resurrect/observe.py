import gc
import io
import weakref

class Keeper:
    def __del__(self):
        rescued.append(self)

class ObserveWriter(io.FileIO):
    def close(self):
        events.append(('writer', reader.closed))
        return super().close()

def callback(wr):
    events.append(('weak', wr() is None, reader.closed, writer.closed))

reader = io.FileIO('/dev/null', 'r')
writer = ObserveWriter('/dev/null', 'w')
events = []
rescued = []
keeper = Keeper()
keeper.pair = io.BufferedRWPair(reader, writer, 8)
ref = weakref.ref(keeper.pair, callback)
del keeper
print('rescued', len(rescued), ref() is rescued[0].pair, reader.closed, writer.closed, events)
assert len(rescued) == 1 and ref() is rescued[0].pair and not events
assert rescued[0].pair.write(b'x') == 1
gc.collect()
assert not reader.closed and not writer.closed and not events
rescued.clear()
print('released', ref() is None, reader.closed, writer.closed, events, flush=True)
assert events == [('weak', True, False, False), ('writer', True)] and ref() is None and reader.closed and writer.closed
gc.collect()
print('collected', events, len(rescued))
assert len(rescued) == 0 and events == [('weak', True, False, False), ('writer', True)]
