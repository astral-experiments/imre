from pathlib import Path
import hashlib,json
base=Path(__file__).resolve().parent
pin=(base/'revision.txt').read_text().strip()
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
for probe in ('standard','descriptor-order'):
    d=base/probe
    for lane in ('stock','boxed-O0','boxed-O3'):
        for case in (['build'] if lane!='stock' else [])+['normal','cycle']:
            r=d/lane/case
            receipt=json.loads((r/'result.json').read_text())
            assert receipt['rc']==0 and receipt['stdin_pipe'] and not any(receipt[k] for k in ('adopted','tmp_residue','timeout'))
            assert digest(r/'stdout')==receipt['stdout_sha256'] and digest(r/'stderr')==receipt['stderr_sha256']
            if case=='build':
                assert receipt['pin']==pin and set(receipt['pair'])=={'imre','libimre_runtime.a'}
                continue
            assert receipt['driver']==digest(d/'probe.py') and receipt['input_preserved'] and bytes.fromhex(receipt['output_hex'])==b'pending'
            assert (r/'stderr').stat().st_size==0
            want=(d/'stock'/case/'stdout').read_text()
            if probe=='descriptor-order' and case=='normal' and lane!='stock':
                assert "[(True, 'closed')]" in want
                want=want.replace("[(True, 'closed')]","[(False, 'open')]")
            assert (r/'stdout').read_text()==want
            if case=='cycle':assert "drop False False open open b''" in want
            else:assert "drop True True closed closed b'pending'" in want
            assert "collect True True closed closed b'pending'" in want
print(pin,'normal and cyclic ownership matched; acyclic callback sees reader open in Imre')
