import gc
import io
import os
import sys
from _io import BufferedReader, BufferedRWPair

class ReaderRaw:
    def __init__(self):
        self.file = io.FileIO("/dev/null", "r")
        self.events = []
        self.saved = []

    @property
    def closed(self):
        return self.file.closed

    def readable(self):
        return True

    def tell(self):
        return self.file.tell()

    def flush(self):
        self.events.append("flush")
        return self.file.flush()

    def close(self):
        self.events.append("close")
        return self.file.close()

    def _dealloc_warn(self, source):
        self.events.append("warn")
        assert type(source) is BufferedReader
        assert source.raw is self and not source.closed and not self.closed
        self.saved.append(source)

class Writer(io.FileIO):
    def writable(self):
        self.calls += 1
        if self.calls == 2:
            assert not self.reader.closed and not self.reader.saved
            self.reader.events.append("reject")
            return False
        return True

def observe(case):
    raw = ReaderRaw()
    fd = raw.file.fileno()
    if case == "rollback":
        writer = Writer("/dev/null", "w")
        writer.reader = raw
        writer.calls = 0
        try:
            BufferedRWPair(raw, writer, 8)
        except io.UnsupportedOperation as exc:
            assert str(exc) == "File or stream is not writable."
            assert exc.__context__ is None
            assert raw.closed and not writer.closed and writer.calls == 2
            raw.events.append("caught")
        else:
            raise AssertionError("missing writer rejection")
        finally:
            writer.close()
    else:
        buf = BufferedReader(raw, 8)
        if case == "explicit":
            buf.close()
        del buf
    gc.collect()
    assert raw.closed
    try:
        os.fstat(fd)
    except OSError as exc:
        assert exc.errno == 9
    else:
        raise AssertionError("descriptor remained open")
    print(case, raw.events, "held", len(raw.saved))
    if raw.saved:
        assert len(raw.saved) == 1 and raw.saved[0].closed and raw.saved[0].raw is raw
    raw.saved.clear()

observe(sys.argv[1])
