# BufferedRWPair implicit lifetime and observable close order

The reference was Linux CPython 3.14.5, 5607950ef232dad16d75c0cf53101d9649d89115. The revision file identifies the Imre source built for each boxed O0 and O3 run. These independent controls use two actual files, externally retained FileIO instances, distinct kernel descriptors, open stdin and isolated working directories. Acyclic drop and cyclic collection at both native levels match stock's bytes, raw closed attributes and EBADF state, with no lingering children or cleanup residue. A pending seven-byte write becomes visible before the execution stage ends.

A writer FileIO subclass independently records the input closed attribute and descriptor availability in its close callback. For a plain acyclic pair CPython and Imre both observe a closed input at writer.close. Both cyclic callbacks observe open input. CPython's exact acyclic BufferedRWPair deallocator clears weak references, then its private reader then writer, per Modules/_io/bufferedio.c:2289-2319. Public close and cyclic finalization close the writer first. These controls add zero original test registrations.

Run sha256sum -c SHA256SUMS and python3 -B qualify.py to verify the source identities, raw checker output and measured scope.
