import gc
import io
import _io
import os
import sys

def status(fd):
    try:
        os.fstat(fd)
    except OSError as e:
        assert e.errno == 9
        return 'closed'
    return 'open'

def snapshot(stage, r, w, rf, wf):
    with io.FileIO('output', 'r') as disk:
        data = disk.read()
    print(stage, r.closed, w.closed, status(rf), status(wf), repr(data), flush=True)

def run(case):
    assert io.BufferedRWPair is _io.BufferedRWPair
    r = io.FileIO('input', 'r')
    w = io.FileIO('output', 'w')
    try:
        rf = r.fileno()
        wf = w.fileno()
        assert rf != wf and os.fstat(rf).st_ino != os.fstat(wf).st_ino
        pair = io.BufferedRWPair(r, w, 16)
        assert pair.read(3) == b'src' and pair.write(b'pending') == 7
        if case == 'cycle':
            pair.loop = pair
        snapshot('before', r, w, rf, wf)
        del pair
        snapshot('drop', r, w, rf, wf)
        gc.collect()
        snapshot('collect', r, w, rf, wf)
        assert r.closed and w.closed and status(rf) == status(wf) == 'closed'
        with io.FileIO('output', 'r') as check:
            assert check.read() == b'pending'
    finally:
        r.close()
        w.close()

run(sys.argv[1])
