import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
rev=(root/'revision').read_text().strip()
blob=bytes.fromhex('c3bf0ac3bf0a')
def raw(f):
    d=json.loads((f/'result.json').read_text())
    out=(f/'stdout').read_bytes();err=(f/'stderr').read_bytes()
    assert d['stdin_pipe'] and not d['timeout'] and not d['adopted'] and not d['tmp_residue']
    assert d['stdout_sha256']==hashlib.sha256(out).hexdigest() and d['stderr_sha256']==hashlib.sha256(err).hexdigest()
    return d,out,err
base=(root/'src/positions.py').read_text().rsplit('run(sys.argv[1])',1)[0]
assert (root/'src/positions_final.py').read_text().startswith(base+'def cross_chunk')
print('lane\tcase\texit\tstdout_exact\tsemantic_outcome')
for lane in ('cpython','boxed-O0','boxed-O3'):
    if lane!='cpython':
        b,_,_=raw(root/lane/'build');assert b['sha']==rev and b['rc']==0
    chunks={'chunk-ascii':(b'abcdxy\n',(7,6)), 'chunk-utf8-ahead':('éabx\n'.encode(),(6,5)), 'chunk-utf8-line':('abcd€\n'.encode(),(8,6))}
    for case in ('upstream','inverted','boundary','direct',*chunks,'min-int'):
        d,out,err=raw(root/lane/case)
        sample=b'abcdxy\n' if case=='min-int' else (chunks[case][0] if case in chunks else blob)
        assert bytes.fromhex(d['sample_hex'])==sample and d['size']==len(sample) and not d['cwd_residue'] and d['sample_sha256']==hashlib.sha256(sample).hexdigest()
        assert d['fixture_sha256']==hashlib.sha256((root/'src/positions_final.py').read_bytes()).hexdigest()
        assert d['rc']==int(case=='inverted'),d
        if case=='min-int':
            assert not err and b'control-raw-and-tell (7, 6)' in out and b'custom-raw-position -9223372036854775808' in out and b'after-close True' in out
            if lane=='cpython':
                assert b"custom-text-position ('position', 9223372036854775807)" in out
                detail='release wraps to INT64_MAX'
            else:
                assert b"custom-text-position ('exception', 'OverflowError', 'text stream position out of range')" in out
                detail='guard raises catchable OverflowError'
            print(lane,case,d['rc'],out==(root/'cpython'/case/'stdout').read_bytes(),detail,sep='\t')
            continue
        if case in chunks:
            expected=(root/'cpython'/case/'stdout').read_bytes()
            assert not err and expected==out
            assert b"provider ('_io', 'TextIOWrapper', 'BufferedReader', 'FileIO')" in out
            assert ('raw-and-tell '+repr(chunks[case][1])).encode() in out and b'after-close True' in out
            print(lane,case,d['rc'],True,'logical position reconstructed: '+repr(chunks[case][1]),sep='\t')
            continue
        assert b"provider ('_io', 'TextIOWrapper', 'BufferedRandom', 'FileIO', 'w+', 'utf-8')" in out
        expected=(root/'cpython'/case/'stdout').read_bytes()
        exact=out==expected
        if case=='inverted':
            assert b'AssertionError: expected iteration to expose position' in err
        else:
            assert not err
        if case!='boundary':
            assert exact
            detail={'upstream':'expected OSError; iteration and EOF agree','inverted':'wrong assertion fails','direct':'direct read positions 3,6,6'}[case]
        else:
            diff=[x for x in out.decode().splitlines() if x not in expected.decode().splitlines()]
            assert all(line.startswith('after-flush ') for line in diff)
            assert b"first-tell ('exception', 'OSError'" in out and b"after-stop ('position', 6)" in out
            assert len(expected.splitlines())==len(out.splitlines())
            detail='all boundaries match' if exact else 'only mismatch: '+', '.join(diff)
        print(lane,case,d['rc'],exact,detail,sep='\t')
