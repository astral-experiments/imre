from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
namespace={'__file__':str(root/'run.py')}
exec(compile((root/'run.py').read_text().rsplit('lane(sys.argv[1])',1)[0],str(root/'run.py'),'exec'),namespace)
run=namespace['run'];ref=namespace['ref'];base=namespace['base']
revision=sys.argv[1];lane=sys.argv[2]
pair=base/'fs-family/provider-replay/pairs'/revision;src=root/'src/positions_final.py'
namespace['env']['IMRE_PYTHON']=str(pair/'imre')
out=root/'final'/revision/lane;out.mkdir(parents=True)
if lane=='cpython':
    cmd=[ref,'-B',src]
else:
    hashes={k:h for h,k in (x.split() for x in (pair/'ready').read_text().splitlines())}
    assert (pair/'commit').read_text().strip()==revision
    for n,h in hashes.items():assert hashlib.sha256((pair/n).read_bytes()).hexdigest()==h
    b=out/'build';b.mkdir();cmd=[out/'probe']
    args=[pair/'imre','build',src,'--module-root',src.parent,'--opt-level',lane[-1],'--no-cache','--runtime',pair/'libimre_runtime.a','--clang',base/'llvm/usr/bin/clang-19','-o',cmd[0]]
    if lane.startswith('boxed'):args.append('--runtime-imports')
    meta=run(args,b,b,300)
    meta.update(sha=revision,pair=hashes)
    (b/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
    assert meta['rc']==0,(b/'stderr').read_text()
data={'min-int':b'abcdxy\n','chunk-ascii':b'abcdxy\n','chunk-utf8-ahead':'éabx\n'.encode(),'chunk-utf8-line':'abcd€\n'.encode()}
for case in ['upstream','inverted','boundary','direct',*data]:
    dest=out/case;work=dest/'cwd';work.mkdir(parents=True);assert list(work.iterdir())==[]
    if case in data:
        (work/'sample').write_bytes(data[case])
        prior=(work/'sample').stat()
    meta=run(cmd+[case],work,dest,20)
    if case in data:
        assert (work/'sample').read_bytes()==data[case] and (work/'sample').stat().st_ino==prior.st_ino
    sample=work/'sample'
    if sample.exists():
        meta.update(sample_hex=sample.read_bytes().hex(),sample_sha256=hashlib.sha256(sample.read_bytes()).hexdigest(),size=sample.stat().st_size)
        sample.unlink()
    meta.update(case=case,fixture_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),revision=revision,lane=lane,cwd_residue=[x.name for x in work.iterdir()])
    assert not meta['cwd_residue']
    (dest/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(lane,case,meta['rc'],meta.get('size'),flush=True)
