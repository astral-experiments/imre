import _io
import io
import os
import sys

line = 'ÿ\n'

def tell_result(f):
    try:
        return ('position', f.tell())
    except Exception as e:
        return ('exception', type(e).__name__, str(e))

def report(name, value):
    print(name, repr(value), flush=True)

def requires_error(f, inverse=False):
    outcome=tell_result(f)
    report('iter-tell',outcome)
    is_error=outcome[:2]==('exception','OSError')
    assert (not is_error) if inverse else is_error, 'expected iteration to expose position' if inverse else 'expected OSError after next'

def run(case):
    with io.open('sample','w+',encoding='utf-8') as f:
        assert type(f) is _io.TextIOWrapper and type(f.buffer).__name__=="BufferedRandom" and type(f.buffer.raw) is _io.FileIO
        report('provider',(type(f).__module__,type(f).__name__,type(f.buffer).__name__,type(f.buffer.raw).__name__,f.mode,f.encoding))
        p0=f.tell()
        f.write(line)
        p1=f.tell()
        f.write(line)
        p2=f.tell()
        report('write-positions',(p0,p1,p2))
        assert (p0,p1,p2)==(0,3,6)
        f.seek(0)
        if case in ('upstream','inverted'):
            assert f.tell()==p0
            assert f.readline()==line
            report('readline-1',f.tell())
            assert f.tell()==p1
            assert f.readline()==line
            report('readline-2',f.tell())
            assert f.tell()==p2
            f.seek(0)
            n=0
            for value in f:
                n+=1
                report('iterator-line',value)
                assert value==line
                requires_error(f,case=='inverted')
            report('exhausted',(n,tell_result(f)))
            assert n==2 and f.tell()==p2
        elif case=='boundary':
            report('iter-alone',iter(f) is f)
            report('tell-before-next',tell_result(f))
            report('first-next',next(f))
            report('first-tell',tell_result(f))
            report('readline-inside',f.readline())
            report('after-readline-inside',tell_result(f))
            report('empty-direct-read',f.readline())
            report('after-empty-direct',tell_result(f))
            try:
                next(f)
            except StopIteration:
                report('after-stop',tell_result(f))
            f.seek(0)
            next(f)
            f.flush()
            report('after-flush',tell_result(f))
            f.seek(0)
            report('after-absolute-seek',tell_result(f))
            next(f)
            try:
                report('seek-cur',f.seek(0,io.SEEK_CUR))
            except Exception as e:
                report('seek-cur-exception',(type(e).__name__,str(e)))
            report('after-seek-cur',tell_result(f))
            f.seek(0,io.SEEK_END)
            report('after-seek-end',tell_result(f))
        elif case=='direct':
            report('direct-1',(f.readline(),tell_result(f)))
            report('direct-2',(f.readline(),tell_result(f)))
            report('direct-3',(f.readline(),tell_result(f)))
        else:
            raise AssertionError(case)
    report('after-close',f.closed)

run(sys.argv[1])
