"""Package one suite's complete native runs with its unchanged inputs and CPython oracle."""
from collections import Counter
from pathlib import Path
import gzip, hashlib, io, json, re, sys, tarfile
root = Path(__file__).resolve().parent
workspace = root.parent
ref = workspace.parent / 'io-reference'
suite, label = sys.argv[1:]
assert suite in ('file', 'fileio')
reg = json.loads((ref/'upstream-registration.json').read_bytes())['registrations'][suite]
ids = [row['id'] for row in reg['cases']]
size = {'file':36,'fileio':99}[suite]
assert len(ids) == len(set(ids)) == size
files = {}
def raw(key, path):
    value = path.read_bytes()
    files[key] = value
    return value
def dump(value):
    return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
def sha(value):
    return hashlib.sha256(value).hexdigest()
def hashed_streams(target, folder, name, metadata):
    for stream in ('stdout','stderr'):
        key = name+'.'+stream
        value = raw(target+'/'+key,folder/key)
        if stream+'_sha256' in metadata:
            assert sha(value) == metadata[stream+'_sha256']
def parse(output, errors):
    observed = [s[11:] for s in output.splitlines() if s.startswith('REGISTERED ')]
    assert observed == ids, (set(observed)^set(ids), 'registration order or count')
    result = {}
    active = None
    for line in errors.splitlines():
        if line.startswith(('====','----------------------------------------------------------------------')): break
        head = re.fullmatch(r'\w+ \((test\.test_\w+\.[^()]+)\)(?: \.\.\. (.*))?',line)
        if head:
            assert head[1] in ids
            active = head[1]
            status = head[2] or ''
        else:
            status = line.rsplit(' ... ',1)[-1]
        if active and re.fullmatch(r'ok|ERROR|FAIL|skipped .+',status):
            assert active not in result
            result[active] = status
            active = None
    assert list(result) == ids,(set(ids)-set(result),'outcome order')
    counts = Counter(v.split(' ',1)[0] for v in result.values())
    expected = f"OUTCOME {size} {counts['FAIL']} {counts['ERROR']} {counts['skipped']}"
    assert [s for s in output.splitlines() if s.startswith('OUTCOME ')] == [expected]
    return dict(passed=counts['ok'],failed=counts['FAIL'],errors=counts['ERROR'],skipped=counts['skipped'],registered=len(observed)),result
stage = json.loads(raw('source/stage.json',root/'stage.json'))
pin = stage['pin']
assert pin == '5607950ef232dad16d75c0cf53101d9649d89115'
for name, key, digest in [('test/test_'+suite+'.py','Lib/test/test_'+suite+'.py',reg['source_sha256']),('_pyio.py','Lib/_pyio.py',stage['_pyio.py'])]:
    value=raw('source/'+key,root/'stage'/name)
    assert sha(value) == digest and value == (ref/'cpython'/key).read_bytes()
driver = 'test_'+suite+'_driver.py'
assert sha(raw('source/'+driver,root/'stage'/driver)) == stage['scope'][suite]['entry']
files['source/registration.json'] = dump(reg)
for script in ('run.py','on-3673.py','public-after-truncate.py','retry-compiled.py','boxed-zero.py','replay-level.py','replay-level-two-suites.py','reference-whole.py','two-level.sh','pack-levels.py'):
    raw('harness/'+script,root/script)
raw('harness/supervise.py',workspace/'supervise.py')
for tag in ('supervise-before-native-gate.py','supervise-native-gate-v1.py'):
    raw('harness/'+tag,workspace/tag)
cp_loc=root/('reference-'+suite)
cp = json.loads(raw('cpython/result.json',cp_loc/'result.json'))
assert cp['exit'] == 0 and cp['pin'] == pin
hashed_streams('cpython',cp_loc,'run',cp)
cp_counts, cp_results = parse((cp_loc/'run.stdout').read_text(),(cp_loc/'run.stderr').read_text())
for suffix in ('log','json'):
    raw('cpython/independent-unittest.'+suffix,ref/('whole-'+suite+'.'+suffix))
def native(group, tag, lane, retry=''):
    folder=root/tag/(suite+'-'+lane)
    runloc=folder/retry if retry else folder
    target=group+'/'+tag+'/'+lane
    meta=json.loads(raw(target+'/tools.json',folder.parent/'tools.json'))
    b=json.loads(raw(target+'/build.json',folder/'build.json'))
    hashed_streams(target,folder,'build',b)
    assert b['exit']==0 and b['argv'][b['argv'].index('--opt-level')+1]==lane[-1]
    assert ('--runtime-imports' in b['argv']) == lane.startswith('boxed')
    assert b['argv'][2].endswith('/'+driver)
    regdata=json.loads(raw(target+'/registration.json',folder/'registration.json'))
    assert regdata['registered']==size and not regdata['other']
    if retry:
        initial=json.loads(raw(target+'/initial/run.json',folder/'run.json'))
        hashed_streams(target+'/initial',folder,'run',initial)
        assert initial['exit']==124
    run=json.loads(raw(target+'/run.json',runloc/'run.json'))
    hashed_streams(target,runloc,'run',run)
    rc=run.get('exit',run.get('sys_exit'))
    counts,outcomes=parse((runloc/'run.stdout').read_text(),(runloc/'run.stderr').read_text())
    assert rc==int(bool(counts['failed'] or counts['errors']))
    if retry: assert regdata['elf'] == run['elf_sha256']
    return dict(revision=meta['head'],tree=meta['tree'],binary_sha256=regdata['elf'],exit=rc,counts=counts,per_id=outcomes)
lanes={}
for route in ('boxed','ordinary'):
    if all((root/label/(suite+'-'+route+n)/'registration.json').exists() and (root/label/(suite+'-'+route+n)/'run.stdout').read_text().splitlines()[-1].startswith('OUTCOME ') for n in ('0','3')):
        for n in ('0','3'):
            lanes[route+n]=native('native',label,route+n)
assert lanes and 'boxed3' in lanes,'incomplete O0/O3 pair'
assert len({r['revision'] for r in lanes.values()})==1
head=next(iter(lanes.values()))['revision']
if suite=='file' and label!='public-3673':
    before=native('comparison','public-3673','boxed0')
else:
    before=native('comparison','public-30071-files','boxed0','retry-7200' if suite=='fileio' else '')
changes={lane:{'new_passes':[i for i in ids if row['per_id'][i]=='ok' and before['per_id'][i]!='ok'],'previous_passes_now_failing':[i for i in ids if row['per_id'][i]!='ok' and before['per_id'][i]=='ok']} for lane,row in lanes.items()}
paired={}
for route in ('boxed','ordinary'):
    if route+'0' in lanes:
        a=lanes[route+'0']['per_id'];b=lanes[route+'3']['per_id']
        paired[route]=dict(passing_at_both_levels=[i for i in ids if a[i]==b[i]=='ok'],different_status=[i for i in ids if a[i]!=b[i]])
files['results.json']=dump(dict(cpython=pin,original_suite='test.test_'+suite,source_sha256=reg['source_sha256'],scope='complete, unfiltered module',head=head,registration_matches_cpython_order=True,cpython_outcome=cp_counts,cpython_per_id=cp_results,native=lanes,paired=paired,comparison_boxed_O0=before,changes_against_comparison=changes))
files['README.md']=(f'# Complete CPython test.test_{suite}\n\nOriginal CPython 3.14.5 at {pin}. Public Imre revision {head}. Each reported lane discovered and ran all {size} original cases in CPython registration order. The test driver prints IDs, then runs unittest against the same suite. See results.json for every disposition, two-level intersections and the earlier boxed O0 comparison. A native process exits 1 when any original fails or errors.\n\nReproduce against the pinned CPython Lib/test package, staged _pyio.py and the supplied driver. The build and run JSON files contain the exact commands. The ELF digest is in registration.json. Raw stdout and stderr include the full failure tracebacks.\n').encode()
files['SHA256SUMS']=''.join(f'{sha(v)}  {n}\n' for n,v in sorted(files.items())).encode()
out=io.BytesIO()
with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as gz, tarfile.open(fileobj=gz,mode='w') as t:
    for n,v in sorted(files.items()):
        info=tarfile.TarInfo(n);info.size=len(v);info.mode=0o644;t.addfile(info,io.BytesIO(v))
body=out.getvalue()
dest=Path('/workspace/shared/downloads')/f'imre-io-test-{suite}-{size}-{head[:8]}-{sha(body)[:14]}.tar.gz'
if not dest.exists(): dest.write_bytes(body)
with tarfile.open(dest,'r:gz') as archive:
    sums=archive.extractfile('SHA256SUMS').read().decode().splitlines()
    assert len(archive.getnames())==len(sums)+1
    for entry in sums:
        checksum,n=entry.split('  ',1)
        assert sha(archive.extractfile(n).read())==checksum
print(dest,sha(body),len(body),len(sums),{l:r['counts'] for l,r in lanes.items()},flush=True)
