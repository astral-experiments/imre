import ctypes
import fcntl
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

# Adopt grandchildren on Linux so a timed-out compiler or test cannot orphan them.
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), "PR_SET_CHILD_SUBREAPER")
def reserve_native_build():
    # ELF builds compete with Cargo for this executor's cgroup memory budget.
    if Path(sys.argv[2]).name != "imre":
        return None
    capacity = Path(__file__).resolve().parent / "native-compile-capacity"
    if not capacity.is_dir():
        return None
    # A blocking kernel queue prevents fresh compiles from jumping ahead of
    # older three-slot waiters. This bounds admission independently of execution.
    admission = capacity.parent / "native-compile-admission.lock"
    def queue_deadline(signum, frame):
        raise TimeoutError("native compilation capacity wait expired before launch")
    previous = signal.signal(signal.SIGALRM, queue_deadline)
    signal.alarm(7200)
    try:
        # Give a waiting intact primary import a place on the kernel queue
        # for slot zero. This shares the same three permits as every other job.
        root = capacity.parent
        primary_sources = {
            str(root / "native-random-evidence/whole-registration/primary_entry.py"),
            str(root / "replay-common-intact/stage/intact-io/entry.py"),
        }
        whole_files = {str(root / "intact-io-companions/stage" / driver)
                       for driver in ("test_file_driver.py", "test_fileio_driver.py")}
        complete_source = sys.argv[4] if len(sys.argv) > 4 and sys.argv[3] == "build" else None
        index_source = str(root / "intact-io-companions/stage/test_file_index_driver.py")
        focused_sources = {
            index_source,
            str(root / "int-index-evidence/qualified/int_index_qualify.py"),
            str(root / "file-default-buffer-frontier/lifetime/lifetime_guard.py"),
            str(root / "intact-io-companions/stage/test_file_default_buffer_driver.py"),
        }
        if complete_source in primary_sources or complete_source in whole_files or complete_source in focused_sources:
            fd = (capacity / ("0" if complete_source in primary_sources else "1" if complete_source in whole_files else "2")).open("rb")
            fcntl.flock(fd, fcntl.LOCK_EX)
            stats = Path("/sys/fs/cgroup/memory.stat")
            while stats.exists() and int(dict(line.split() for line in stats.read_text().splitlines())["anon"]) >= 10 * (1 << 30):
                time.sleep(1)
            return fd
        with admission.open("rb") as gate:
            fcntl.flock(gate, fcntl.LOCK_EX)
            while True:
                stats = Path("/sys/fs/cgroup/memory.stat")
                anon = 0
                if stats.exists():
                    anon = int(dict(line.split() for line in stats.read_text().splitlines())["anon"])
                if anon < 10 * (1 << 30):
                    for slot in sorted(capacity.iterdir()):
                        fd = slot.open("rb")
                        try:
                            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        except BlockingIOError:
                            fd.close()
                            continue
                        return fd
                time.sleep(1)
    except TimeoutError as error:
        print(error, file=sys.stderr)
        raise SystemExit(125)
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, previous)

native_reservation = reserve_native_build()
p = subprocess.Popen(sys.argv[2:], start_new_session=True)
try:
    rc = p.wait(timeout=float(sys.argv[1]))
except subprocess.TimeoutExpired:
    print("deadline exceeded", file=sys.stderr, flush=True)
    rc = 124
    try:
        os.killpg(p.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
finally:
    # Reap all descendants. A detached child's own children become ours on exit.
    while True:
        try:
            pid, _ = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            break
        if pid:
            continue
        # The children file is optional on Linux. stat is available here.
        for entry in Path("/proc").iterdir():
            if not entry.name.isdecimal():
                continue
            try:
                stat = (entry / "stat").read_text().rsplit(")", 1)[1].split()
                if int(stat[1]) == os.getpid():
                    os.kill(int(entry.name), signal.SIGKILL)
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                continue
        time.sleep(0.025)
sys.exit(rc if rc >= 0 else 128 - rc)
