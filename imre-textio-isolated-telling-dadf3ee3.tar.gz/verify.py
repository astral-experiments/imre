"""Verify the isolated source fixture and distinguish setup errors from method passes."""
import hashlib,json,re
from pathlib import Path
r=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_bytes()); m=read(r/'provenance.json'); upstream=(r/'original-test_io.py').read_bytes();lines=upstream.splitlines(keepends=True);d=(r/'stage/focused.py').read_bytes();assert sha(upstream)==m['upstream_module_sha256'] and sha(d)==m['driver_sha256'];
for k,s in m['slices'].items():
 blob=b''.join(lines[s['first_line']-1:s['last_line']]);assert sha(blob)==s['sha256'] and d.count(blob)==1,k
for n,h in m['support'].items():assert sha((r/'stage'/n).read_bytes())==h
version=read(r/'raw/cpython/stock/interpreter.json')['version'];assert version[0].startswith('3.14.5') and version[1:]==['linux','cpython']
pins=['736c6a539c4ff6c3be604df412a3bde8ddafc384','dadf3ee31df4c2aeb7bf3ed210c0f242ca0ed248']; counts={}
for pin in ['cpython',*pins]:
 counts[pin]={}
 for lane in (['stock'] if pin=='cpython' else ['boxed-O0','boxed-O3']):
  f=r/'raw'/pin/lane; rec=read(f/'result.json');out=(f/'stdout').read_bytes();err=(f/'stderr').read_bytes();assert rec['pin']==pin and rec['lane']==lane and rec['stdin_held'] and not rec['timeout'] and not rec['adopted'];assert rec['residue']=={'cwd':[],'tmpdir':[]};assert sha(out)==rec['stdout_sha256'] and sha(err)==rec['stderr_sha256'];assert b'Ran 1 test in ' in err and b'Exception ignored' not in err
  if pin=='cpython':
   assert rec['exit']==0 and err.endswith(b'\nOK\n') and rec['witness']['bytes_hex']=='c3bf0ac3bf0a' and rec['witness']['size']==6 and out.startswith(b'witness\t'); counts[pin][lane]='method-pass'
  else:
   b=read(f/'build.json');assert b['exit']==0 and b['pin']==pin and b['driver_sha256']==sha(d) and b['argv'][b['argv'].index('--opt-level')+1]==lane[-1] and '--runtime-imports' in b['argv'] and b['argv'][0].split('/')[-2]==pin and len(b['binary_sha256'])==64
   assert rec['exit']==1 and err.endswith(b'\nFAILED (errors=1)\n') and b'in setUp\n    codecs.register(lookupTestDecoder)' in err and b"AttributeError: module 'codecs' has no attribute 'register'" in err and not out and rec['witness'] is None; counts[pin][lane]='setUp-error; method unreached'
print(json.dumps(counts,sort_keys=True));print('The real file contained c3bf0ac3bf0a before stock teardown; all five isolated processes left no residual files. No original registration credited.')
