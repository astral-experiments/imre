from pathlib import Path
import hashlib,ast,json
r=Path(__file__).resolve().parent; base=r.parents[1];stage=r/'stage';stage.mkdir(exist_ok=True);lib=base/'python/cpython-3.14.5/Lib'; sha=lambda s:hashlib.sha256(s).hexdigest();s=(lib/'test/test_io.py').read_bytes(); assert sha(s)=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af';tree=ast.parse(s);lines=s.splitlines(keepends=True);t={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}; c=t['TextIOWrapperTest']; methods={n.name:n for n in c.body if isinstance(n,ast.FunctionDef)}; manifest={}
def capture(name,node):
 b=b''.join(lines[node.lineno-1:node.end_lineno]);manifest[name]=dict(first_line=node.lineno,last_line=node.end_lineno,sha256=sha(b));return b
parts=[b'import codecs\nimport io\nimport _io\nimport sys\nimport unittest\nfrom test.support import os_helper\n\n',capture('StatefulIncrementalDecoder',t['StatefulIncrementalDecoder']),capture('lookupTestDecoder',t['lookupTestDecoder']),lines[c.lineno-1]]
for name in ('setUp','tearDown','test_telling'):parts.append(capture('TextIOWrapperTest.'+name,methods[name]))
parts.append(b'''class IsolatedTelling(TextIOWrapperTest):
    def tearDown(self):
        try:
            print("witness\\t" + os_helper.TESTFN, flush=True)
            assert sys.stdin.readline() == "recorded\\n"
        finally:
            super().tearDown()

setattr(IsolatedTelling, "open", io.open)
assert IsolatedTelling.open is io.open and io.open is _io.open
case = IsolatedTelling("test_telling")
assert case.open is io.open
result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
if result.testsRun != 1 or not result.wasSuccessful():
    raise SystemExit(1)
''');driver=b'\n'.join(parts);(stage/'focused.py').write_bytes(driver)
for n in manifest:
 a,b=manifest[n]['first_line'],manifest[n]['last_line'];assert driver.count(b''.join(lines[a-1:b]))==1
old=r.parent/'replay/stage/Lib';support={}
for src in (old/'test').rglob('*.py'):
 if src.name=='test_io.py':continue
 name=src.relative_to(old);new=stage/name;blob=src.read_bytes();assert (lib/name).read_bytes()==blob;new.parent.mkdir(parents=True,exist_ok=True);new.write_bytes(blob);support[str(name)]=sha(blob)
(r/'provenance.json').write_text(json.dumps(dict(commit='5607950ef232dad16d75c0cf53101d9649d89115',upstream_module_sha256=sha(s),slices=manifest,driver_sha256=sha(driver),support=support),indent=2)+'\n')
