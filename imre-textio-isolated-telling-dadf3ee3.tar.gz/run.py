from pathlib import Path
import ctypes,hashlib,json,os,select,signal,stat,subprocess,sys,time
r=Path(__file__).resolve().parent;b=r.parents[1];pin=sys.argv[1];lane=sys.argv[2];out=r/'raw'/pin/lane;out.mkdir(parents=True,exist_ok=True);w=out/'cwd';t=out/'tmpdir'; w.mkdir();t.mkdir(); env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','PYTHONWARNINGS','LD_PRELOAD','IMRE_PYTHON')};env.update(TMPDIR=str(t),PYTHONDONTWRITEBYTECODE='1');sha=lambda x:hashlib.sha256(x).hexdigest();args=[b/'python/managed/cpython-3.14.5-linux-x86_64-gnu/bin/python3.14','-EB',r/'stage/focused.py'] if pin=='cpython' else [out/'suite'];args=list(map(str,args));
if pin!='cpython':
 receipt=json.loads((out/'build.json').read_text());assert receipt['exit']==0 and sha(Path(args[0]).read_bytes())==receipt['binary_sha256'];env['IMRE_PYTHON']=str(b/'fs-family/provider-replay/pairs'/pin/'imre');env['LD_LIBRARY_PATH']=str(b/'llvm/usr/lib/x86_64-linux-gnu')
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0; started=time.monotonic(); buff=b''; witness=None; duration=120; timed=False
with (out/'stderr').open('wb') as err:
 p=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,cwd=w,env=env,start_new_session=True)
 try:
  while time.monotonic()-started<duration:
   ready,_,_=select.select([p.stdout],[],[],1)
   if not ready:continue
   part=os.read(p.stdout.fileno(),65536)
   if not part:break
   buff+=part
   for row in buff.split(b'\n')[:-1]:
    if row.startswith(b'witness\t') and witness is None:
     name=os.fsdecode(row.partition(b'\t')[2]);assert Path(name).name==name;path=w/name
     try:
      with path.open('rb') as f:data=f.read(); st=os.fstat(f.fileno()); assert stat.S_ISREG(st.st_mode)
      witness={'name':name,'type':'regular','inode':st.st_ino,'size':st.st_size,'bytes_hex':data.hex(),'sha256':sha(data)}
     except FileNotFoundError:witness={'name':name,'missing':True}
     p.stdin.write(b'recorded\n');p.stdin.flush()
  else:timed=True
  if not timed:p.wait(timeout=15)
 finally:
  try:os.killpg(p.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  p.wait(timeout=10);held=not p.stdin.closed and stat.S_ISFIFO(os.fstat(p.stdin.fileno()).st_mode);p.stdin.close();buff+=p.stdout.read();p.stdout.close()
adopted=[]
while True:
 try:k,v=os.waitpid(-1,os.WNOHANG)
 except ChildProcessError:break
 if not k:raise RuntimeError('unreaped live descendant')
 adopted.append([k,v]);
(out/'stdout').write_bytes(buff);err=(out/'stderr').read_bytes(); residue={n:sorted(str(x.relative_to(a)) for x in a.rglob('*')) for n,a in [('cwd',w),('tmpdir',t)]};
for a in (w,t):
 if not any(a.iterdir()):a.rmdir()
rec=dict(pin=pin,lane=lane,argv=args,elapsed=round(time.monotonic()-started,3),exit=p.returncode,timeout=timed,stdin_held=held,adopted=adopted,residue=residue,witness=witness,stdout_sha256=sha(buff),stderr_sha256=sha(err));(out/'result.json').write_text(json.dumps(rec,indent=2)+'\n');print(pin[:8],lane,p.returncode,witness,residue,flush=True)
