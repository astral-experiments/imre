import sys
if sys.argv[1] == 'existing_fixture':
    import check_existing_fixture
elif sys.argv[1] == 'openers':
    import check_openers
elif sys.argv[1] == 'readline':
    import check_readline
elif sys.argv[1] == 'writelines':
    import check_writelines
else:
    raise ValueError("unknown control")
