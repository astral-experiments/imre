import importlib
import io
import sys


def check(stream):
    assert stream.writelines([]) is None
    saved = stream.writelines
    for call, owner in ((lambda: stream.writelines(), "_IOBase"), (saved, type(stream).__name__)):
        try:
            call()
        except TypeError as error:
            assert str(error) == owner + ".writelines() takes exactly one argument (0 given)", str(error)
            print(str(error))
        else:
            raise AssertionError("missing TypeError")


with io.open("/dev/null", "wb") as stream:
    check(stream)


class Writer(io.BufferedWriter):
    pass


with Writer(io.FileIO("/dev/null", "wb")) as stream:
    check(stream)


class Custom(io.BufferedWriter):
    def writelines(self):
        return 47


with Custom(io.FileIO("/dev/null", "wb")) as stream:
    assert stream.writelines() == 47
    saved = stream.writelines
    assert saved() == 47

del sys.modules["_io"]
fresh = importlib.import_module("_io")
with fresh.open("/dev/null", "wb") as stream:
    check(stream)
with fresh.FileIO("/dev/null", "wb") as raw:
    with fresh.BufferedWriter(raw) as stream:
        assert stream.raw is raw
        assert type(stream) is fresh.BufferedWriter
        assert type(stream.raw) is fresh.FileIO
        assert fresh.BufferedWriter.write(stream, b"X") == 1
    assert raw.closed
