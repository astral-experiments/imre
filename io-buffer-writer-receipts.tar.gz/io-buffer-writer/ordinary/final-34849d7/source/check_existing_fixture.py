import sys
sys.path = ["."] + sys.path
import arithmetic
arithmetic.exercise("chunks.bin")
