import _io
import builtins
import gc
import importlib
import io
import sys

first = _io
original = io
builtin_open = builtins.open
saved_open = io.open
assert saved_open is _io.open and saved_open is builtin_open
with original.open("/dev/null", "wb") as old:
    del sys.modules["_io"]
    second = importlib.import_module("_io")
    assert first.BufferedWriter is not second.BufferedWriter
    assert second.open.__self__ is second
    second_open = second.open
    assert old.__class__ is first.BufferedWriter
    del sys.modules["io"]
    current = importlib.import_module("io")
    assert current.open is second_open
    fresh_class = current.BufferedWriter
    assert fresh_class is second.BufferedWriter
    with current.open("/dev/null", "wb") as fresh:
        assert type(fresh) is fresh_class
        assert isinstance(old, original.BufferedWriter) and not isinstance(old, fresh_class)
        assert isinstance(fresh, fresh_class) and not isinstance(fresh, original.BufferedWriter)
        assert current.BufferedWriter.write(fresh, b"X") == 1
        try:
            first.BufferedWriter.write(fresh, b"X")
        except TypeError:
            pass
        else:
            raise AssertionError("old descriptor accepted fresh stream")
        try:
            second.BufferedWriter.write(old, b"X")
        except TypeError:
            pass
        else:
            raise AssertionError("fresh descriptor accepted old stream")
    print("fresh and old writer classes and descriptors")
    # A prior-generation callable retains its class bindings after reload and GC.
    del sys.modules["_io"]
    del sys.modules["io"]
    third = importlib.import_module("_io")
    assert third.BufferedWriter is not fresh_class
    gc.collect()
    for func, expected in ((builtin_open, first.BufferedWriter), (saved_open, first.BufferedWriter),
                           (second_open, fresh_class), (third.open, third.BufferedWriter)):
        with func("/dev/null", "wb") as stream:
            assert type(stream) is expected
            assert expected.write(stream, b"Z") == 1
        print("saved opener returned its owning writer type")
    with second.FileIO("/dev/null","wb") as raw:
        with second.BufferedWriter(raw) as direct:
            assert type(direct) is fresh_class and direct.raw is raw
            assert type(direct.raw) is second.FileIO
    print("fresh constructor owns its supplied raw")
