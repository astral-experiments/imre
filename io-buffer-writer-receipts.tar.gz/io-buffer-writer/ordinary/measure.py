"""Run each BufferedWriter control independently and retain the compiler and binary receipts."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest
import json
import os
from pathlib import Path
import resource
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = Path('/workspace/scratch/io-writer-controls')
CPY = Path('/workspace/scratch/cpytools/bin/python3.14')
LIB = Path('/workspace/scratch/cpython/Lib')
PIN = '5607950ef232dad16d75c0cf53101d9649d89115'
CLANG = '/workspace/scratch/tools/clang'
LABELS = ('ordinary.O0','ordinary.O3','boxed.O0','boxed.O3')
SOURCES = {p.stem:p for p in sorted((HERE/'sources').glob('*.py'))}
if os.environ.get('IO_WRITER_FIXTURE'):
    SOURCES['permanent']=Path(os.environ['IO_WRITER_FIXTURE']).resolve()
REFERENCE=os.environ.get('IO_WRITER_REFERENCE','reference')
RESOURCE_ENV = {k:v for k,v in os.environ.items() if not k.startswith(('IMRE','PYTHON'))}
resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def sha(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()

def emit(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n')

def run(cmd,cwd,logs,name,timeout,extra=None):
    cmd=[str(x) for x in cmd]
    env={**RESOURCE_ENV,'TMPDIR':str(cwd),**(extra or {})}
    start=time.monotonic()
    with (logs/(name+'.stdout')).open('wb') as out, (logs/(name+'.stderr')).open('wb') as err:
        try:
            r=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=err,timeout=timeout)
            status,timed=r.returncode,False
        except subprocess.TimeoutExpired:
            status,timed=None,True
    data={'argv':cmd,'cwd':str(cwd),'exit':status,'timed_out':timed,'elapsed_s':round(time.monotonic()-start,3)}
    emit(logs/(name+'.json'),data)
    return data

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('label')
    parser.add_argument('--bindir',type=Path);parser.add_argument('--commit')
    parser.add_argument('--jobs',default=1,type=int);parser.add_argument('--only',action='append',choices=list(SOURCES))
    a=parser.parse_args();reference=a.label==REFERENCE;ref=HERE/REFERENCE;root=HERE/a.label
    root.mkdir(exist_ok=True)
    families=a.only or list(SOURCES)
    info={'cpython_commit':PIN,'cpython_executable':str(CPY),'reference_label':REFERENCE,'source_sha256':{n:sha(p) for n,p in SOURCES.items()}}
    if not reference:
        assert a.bindir and a.commit and (a.bindir/'READY').read_text().strip()==a.commit
        imre=a.bindir/'imre';rt=a.bindir/'libimre_runtime.a'
        info.update(imre_commit=a.commit,compiler=str(imre),compiler_sha256=sha(imre),runtime=str(rt),runtime_sha256=sha(rt))
    if (root/'provenance.json').exists():
        prior=json.loads((root/'provenance.json').read_text())
        assert all(info.get(key)==value for key,value in prior.items() if key!='source_sha256')
        assert all(info['source_sha256'].get(key)==value for key,value in prior['source_sha256'].items())
    emit(root/'provenance.json',info)
    jobs=[(lane,f) for lane in ([''] if reference else LABELS) for f in families]
    def measure(job):
        lane,family=job;source_file=SOURCES[family]
        work=WORK/a.label/lane/family;work.mkdir(parents=True,exist_ok=True)
        dest=root/lane/family;dest.mkdir(parents=True,exist_ok=True)
        if reference:
            result=run([CPY,'-B','-X','frozen_modules=off',source_file],work,dest,'process',75,{'PYTHONPATH':str(LIB)})
            return lane,family,None,result['exit'],None
        exe=work/'program'
        cmd=[imre,'build',source_file,'--no-cache','--runtime',rt,'--clang',CLANG,'--opt-level',lane[-1],'-o',exe]
        if lane.startswith('boxed.'):cmd.append('--runtime-imports')
        build=run(cmd,work,dest,'build',600)
        if build['exit']!=0:return lane,family,build['exit'],None,False
        (dest/'program.sha256').write_text(sha(exe)+'\n')
        result=run([exe],work,dest,'process',75)
        expected=json.loads((ref/family/'process.json').read_text())
        matches=result['exit']==expected['exit'] and all((dest/('process.'+stream)).read_bytes()==(ref/family/('process.'+stream)).read_bytes() for stream in ('stdout','stderr'))
        exe.unlink()
        return lane,family,build['exit'],result['exit'],matches
    summary=[]
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:
        for lane,family,compile_exit,process_exit,matches in pool.map(measure,jobs):
            row={'lane':lane,'family':family,'build_exit':compile_exit,'process_exit':process_exit,'matches_reference':matches}
            print(a.label,lane,family,compile_exit,process_exit,matches,flush=True);summary.append(row)
    if a.only and (root/'summary.json').exists():
        previous=json.loads((root/'summary.json').read_text())
        summary=[r for r in previous if r['family'] not in families]+summary
    emit(root/'summary.json',summary)

if __name__=='__main__':main()
