"""Check the existing boxed_io fixture and saved/direct writelines diagnostics."""
import importlib.util
from pathlib import Path
import shutil
import subprocess
import sys

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('controls', here/'measure.py')
ctl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ctl)
ctl.WORK = Path('/workspace/scratch/bw-ordinary-runs')
ctl.HERE = here
ctl.SOURCES = {p.stem:p for p in sorted((here/'sources').glob('*.py'))}
label, tree, *options = sys.argv[1:]
tree = Path(tree)
fixture = tree/'tests/fixtures/boxed_io.py'
commit = subprocess.check_output(['git','-C',tree,'rev-parse','HEAD'],text=True).strip()
for lane in ([''] if label=='reference' else ctl.LABELS):
    folder = ctl.WORK/label/lane/'existing_fixture'
    folder.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(fixture,folder/'arithmetic.py')
    (folder/'chunks.bin').write_bytes(b'0a\r\n\xffx!\n')
(here/label).mkdir(exist_ok=True)
ctl.emit(here/label/'fixture.json',{'fixture': str(fixture),'tree':commit,'fixture_sha256':ctl.sha(fixture)})
sys.argv[1:] = [label,'--commit',commit,*options]
ctl.main()
