"""Build one dispatching entry point per native lane, run each control in its own fresh process."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import measure as ctl

parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('tree', type=Path)
parser.add_argument('--bindir', type=Path)
parser.add_argument('--jobs', type=int, default=2)
parser.add_argument('--lane', choices=ctl.LABELS, action='append')
parser.add_argument('--only', action='append')
a = parser.parse_args()
root = Path(__file__).resolve().parent
sources = {p.stem:p for p in sorted((root/'sources').glob('*.py'))}
commit = subprocess.check_output(['git','-C',a.tree,'rev-parse','HEAD'],text=True).strip()
fixture = a.tree/'tests/fixtures/boxed_io.py'
out = root/a.label
out.mkdir(exist_ok=True)
work = Path('/workspace/scratch/bw-ordinary-runs')/a.label
work.mkdir(exist_ok=True)
group = out/'source'
group.mkdir(exist_ok=True)
driver = group/'driver.py'
for name,source in sources.items():
    dest = group/('check_'+name+'.py')
    shutil.copyfile(source,dest)
    assert ctl.sha(dest)==ctl.sha(source)
driver.write_text('import sys\n' + ''.join(
    ('if' if i==0 else 'elif') + ' sys.argv[1] == '+repr(name)+':\n    import check_'+name+'\n'
    for i,name in enumerate(sources))+'else:\n    raise ValueError("unknown control")\n')
meta = {'source_sha256': {n:ctl.sha(p) for n,p in sources.items()},'driver_sha256':ctl.sha(driver),
        'cpython_commit':ctl.PIN, 'cpython_executable':str(ctl.CPY),'reference':'reference'}
if a.bindir:
    assert (a.bindir/'READY').read_text().strip()==commit
    imre=a.bindir/'imre'
    runtime=a.bindir/'libimre_runtime.a'
    meta.update(imre_commit=commit,compiler=str(imre),runtime=str(runtime),
                compiler_sha256=ctl.sha(imre),runtime_sha256=ctl.sha(runtime))
ctl.emit(out/'provenance.json',meta)
ctl.emit(out/'fixture.json',{'fixture': str(fixture),'tree':commit,'fixture_sha256':ctl.sha(fixture)})

def compile_entry(source, lane, folder, logs, exe):
    cmd=[imre,'build',source,'--no-cache','--runtime',runtime,'--clang',ctl.CLANG,'--opt-level',lane[-1],'-o',exe]
    if lane.startswith('boxed'):cmd.append('--runtime-imports')
    build=ctl.run(cmd,folder,logs,'build',600)
    if build['exit']==0:(logs/'program.sha256').write_text(ctl.sha(exe)+'\n')
    return build['exit']


def measure_lane(lane):
    basename=lane or 'cpython'
    folder=work/basename
    folder.mkdir(exist_ok=True)
    dest=out/lane
    dest.mkdir(exist_ok=True)
    build_logs=dest/'driver'
    build_logs.mkdir(exist_ok=True)
    exe=folder/'program'
    build_rc=None
    # The ordinary compiler rejects branch-local imports in this launcher.
    # Keep ordinary entry scripts exactly as in the initial direct measurements.
    names = a.only or list(sources)
    use_group = a.bindir and lane.startswith('boxed') and any(name != 'existing_fixture' for name in names)
    grouped_exit=compile_entry(driver,lane,folder,build_logs,exe) if use_group else None
    rows=[]
    for name in names:
        direct = a.bindir and (lane.startswith('ordinary') or name == 'existing_fixture')
        build_rc=grouped_exit
        wd=folder/name
        wd.mkdir(exist_ok=True)
        logs=dest/name
        logs.mkdir(exist_ok=True)
        assert not (logs/'process.json').exists(),logs
        if name == 'existing_fixture':
            shutil.copyfile(fixture,wd/'arithmetic.py')
            (wd/'chunks.bin').write_bytes(b'0a\r\n\xffx!\n')
        binary = wd/'program' if direct else exe
        if direct:
            build_rc=compile_entry(sources[name],lane,wd,logs,binary)
        elif a.bindir:
            for file in build_logs.iterdir():
                if file.is_file():os.link(file,logs/file.name)
        rc=match=None
        if not a.bindir or build_rc==0:
            argv=([binary] if direct else [binary,name]) if a.bindir else [ctl.CPY,'-B','-X','frozen_modules=off',driver,name]
            data=ctl.run(argv,wd,logs,'process',75,None if a.bindir else {'PYTHONPATH':str(ctl.LIB)})
            rc=data['exit']
            ref=root/'reference'/name
            match=rc==0 and all((logs/('process.'+s)).read_bytes()==(ref/('process.'+s)).read_bytes() for s in ('stdout','stderr'))
        if direct and binary.exists():binary.unlink()
        row={'lane':lane,'family':name,'build_exit':build_rc,'process_exit':rc,'matches_reference':match}
        rows.append(row)
        print(a.label,basename,name,build_rc,rc,match,flush=True)
    if exe.exists():exe.unlink()
    ctl.emit(build_logs/'summary.json',rows)
    return rows
lanes=(a.lane or ('ordinary.O0','ordinary.O3','boxed.O0','boxed.O3')) if a.bindir else ('',)
with ThreadPoolExecutor(max_workers=a.jobs) as pool:
    results=[r for rows in pool.map(measure_lane,lanes) for r in rows]
ctl.emit(out/'summary.json',results)
