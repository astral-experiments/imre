import gc
import io
import sys
import _io
import importlib


class PeekReader(io.BufferedWriter):
    def start(self, data):
        self.data = data
        self.events = []
        self.peek_retry = True
        self.read_retry = True

    def peek(self, n):
        gc.collect()
        self.events.append(("peek", n))
        if self.peek_retry:
            self.peek_retry = False
            raise InterruptedError(4, "once in peek")
        return self.data[:3]

    def read(self, n):
        gc.collect()
        self.events.append(("read", n))
        if self.read_retry:
            self.read_retry = False
            raise OSError(4, "once in read")
        part = self.data[:n]
        self.data = self.data[n:]
        return part


with PeekReader(io.FileIO("/dev/null", "w")) as stream:
    stream.start(b"ab\ncd\ne")
    assert stream.readline(0) == b""
    assert stream.events == []
    assert stream.readline() == b"ab\n"
    assert stream.events == [("peek",1), ("peek",1), ("read",3), ("peek",1), ("read",3)]
    assert stream.readline(2) == b"cd"
    assert stream.readline(None) == b"\n"
    assert stream.readline(-42) == b"e"
    assert stream.readline() == b""
    print("subclass read, peek, GC, EINTR, limit and EOF")


class ReadOnly(io.IOBase):
    def read(self, n):
        assert n == 1
        return b"\n"


reader = ReadOnly()
assert reader.readline() == b"\n"
reader.read = lambda n: bytearray(b"bad")
try:
    reader.readline(1)
except OSError as e:
    print(str(e))
    assert str(e) == "read() should have returned a bytes object, not 'bytearray'"
else:
    raise AssertionError("read accepted bytearray")

reader.peek = lambda n: None
try:
    reader.readline(1)
except OSError as e:
    print(str(e))
    assert str(e) == "peek() should have returned a bytes object, not 'NoneType'"
else:
    raise AssertionError("peek accepted None")


class WrongErrno(io.IOBase):
    def read(self, n):
        raise InterruptedError(9, "preserve")


try:
    WrongErrno().readline(1)
except InterruptedError as e:
    assert e.errno == 9
else:
    raise AssertionError("wrong errno suppressed")

first = _io
del sys.modules["_io"]
second = importlib.import_module("_io")
for module in (first,second):
    with module.open("/dev/null","wb") as writer:
        assert writer.readline(0) == b""
        try:
            writer.readline(1)
        except io.UnsupportedOperation as e:
            assert str(e) == "read"
        else:
            raise AssertionError("write-only read succeeded")
    print("open writer has inherited readline")
