"""Index a completed run without counting build errors as native outcomes."""
import hashlib
import json
import sys
from pathlib import Path
root=Path(__file__).resolve().parent
for label in sys.argv[1:]:
    folder = root/label
    rows = json.loads((folder/'summary.json').read_text())
    files = [p for p in (folder/'summary.json',folder/'fixture.json',folder/'provenance.json') if p.is_file()]
    for row in rows:
        dest = folder/row['lane']/row['family']
        for name in ('build.json','build.stdout','build.stderr','program.sha256','process.json','process.stdout','process.stderr'):
            path=dest/name
            if path.is_file():
                files.append(path)
        if row['lane']:
            assert row['build_exit']==json.loads((dest/'build.json').read_text())['exit']
        run=dest/'process.json'
        if row['process_exit'] is not None:
            assert row['process_exit']==json.loads(run.read_text())['exit']
        if row['matches_reference']:
            assert row['process_exit']==0
            assert all((dest/('process.'+s)).read_bytes()==(root/'reference'/row['family']/('process.'+s)).read_bytes() for s in ['stdout','stderr'])
    manifest = ''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(folder).as_posix()+'\n' for f in sorted(files))
    (folder/'SHA256SUMS').write_text(manifest)
    print(label,len(rows),'rows',len(files),'files',hashlib.sha256(manifest.encode()).hexdigest())
