# BufferedWriter identity and inherited methods

These controls have no CPython test_io case IDs. The case denominator and unchanged unittest outcomes belong to the intact and six-case receipts.

* `existing_fixture` invokes `exercise("chunks.bin")` on an unchanged copy of Imre's `tests/fixtures/boxed_io.py`. The input bytes and import are the ones used by `tests/python_cli.py`. See `fixture.json` for the source hash and worktree.
* `writelines` checks saved and direct error owners, Python subclass overrides, old and freshly imported writer instances, and a writer constructed from its generation’s real FileIO.
* `openers` checks exact type and method receiver acceptance for three _io generations, including previously saved openers, builtins.open and Python garbage collection.
* `readline` exercises the inherited _IOBase implementation on a BufferedWriter subclass with live read/peek callbacks, collection, EINTR, size bounds, error results, and write-only handles from old and fresh modules. CPython gives each reimported module its own UnsupportedOperation. The superseded control incorrectly caught the first module’s class for both.

`build.json` records compiler status and elapsed time. `process.json` records the produced executable’s actual status and elapsed time. A source SHA, compiler/runtime SHA, individual captured stdout and stderr, and linked binary digest identify each applicable result. Ordinary lanes omit `--runtime-imports` and boxed lanes include it. Mismatches in historical rows are retained.

All extra raw identity assertions concern the exact FileIO instance supplied to a native BufferedWriter constructor. Existing pathname and descriptor openers keep their previous raw behavior. A pathname writer backed by an internal file can lack an exposed raw FileIO object.

For a complete labeled run use `python3 run.py LABEL TREE --bindir BIN_DIRECTORY`. The READY file must contain the worktree commit. Each completed run can be indexed and verified with `python3 seal.py LABEL` and `sha256sum -c SHA256SUMS` inside its directory.

## Driver and setup diagnostics

The four-branch driver produces the same stdout, stderr and exit status as direct execution for all four controls on pinned CPython. The ordinary Imre compiler rejects an import inside a branch of that driver. Ordinary receipts for final/public therefore use the individual input scripts. Boxed synthetic cases share a binary and run in separate processes.

The repository fixture needs its arithmetic.py library in the working directory when Imre compiles the entry script. Supplying it only when the native program runs takes a different module-loading path and fails at a list comprehension. The authoritative parent fixture runs are under `parent-seeded-dabdac2`. The earlier unseeded fixture and grouped ordinary compilations are driver diagnostics. The corresponding commands and raw outputs remain under `parent-final-dabdac2`, `parent-final-direct-dabdac2`, and `parent-final-boxed-fixture-dabdac2`. The native missing-BufferedWriter diagnostics for standalone synthetic programs from that parent are independent of this fixture setup.

`batch.py` builds direct entry scripts in the ordinary lanes and builds the repository fixture as its own entry in all lanes. The preseeded fixture bytes, working directories, binary digests, and each label's process records are retained. The earlier direct run at `tested-8d4797a` was superseded after eight completed ordinary executions; `retired.json` lists the uncompleted jobs.
