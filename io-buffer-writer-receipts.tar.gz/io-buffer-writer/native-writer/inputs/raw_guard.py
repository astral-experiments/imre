import io

raw = io.FileIO("raw_guard.bin", "w")
w = io.BufferedWriter(raw, 4)
def patched(data):
    print("raw callback", bytes(data))
    return len(data)
class Offset:
    def __index__(self):
        raw.write = patched
        return 0
w.write(b"ab")
try:
    print("position", w.seek(Offset()))
except NotImplementedError as error:
    print("declined", raw.tell(), str(error))
del raw.write
w.close()
