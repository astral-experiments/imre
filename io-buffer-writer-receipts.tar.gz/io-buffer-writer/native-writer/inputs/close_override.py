import io

class Fails(io.BufferedWriter):
    def flush(self):
        raise RuntimeError("injected flush failure")

raw = io.FileIO("failed.bin", "w")
w = Fails(raw, 32)
assert w.write(b"must stay pending") == 17 and raw.tell() == 0
try:
    w.close()
except RuntimeError as failure:
    print(str(failure), raw.closed, w.closed)
else:
    raise AssertionError("close should raise")
with io.FileIO("failed.bin", "r") as check:
    print(check.read())
