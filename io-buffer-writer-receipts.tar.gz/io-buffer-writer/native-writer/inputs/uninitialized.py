import io

class Writer(io.BufferedWriter):
    def __init__(self):
        pass

def show(operation):
    try:
        print("ok", operation())
    except Exception as error:
        print(type(error).__name__, str(error))

w = Writer()
print("uninitialized", w.raw, w.readable())
show(lambda: w.write())
show(lambda: w.write(b"a", b"b"))
show(lambda: w.write(b"a", size=2))
show(lambda: w.write(None))
show(lambda: w.write(b"a"))
show(w.close)
show(w.flush)
show(w.tell)
show(w.writable)
show(lambda: w.truncate(0))
with io.FileIO("arguments.bin", "w") as raw:
    io.BufferedWriter.__init__(w, raw, buffer_size=4)
    show(lambda: w.write())
    show(lambda: w.write(b"a", b"b"))
    show(lambda: w.truncate(b=1))
    show(lambda: w.seek())
    show(lambda: w.write(memoryview(b"ab")))
    show(w.tell)
    print(w.raw is raw, raw.tell())
    w.close()
    print(w.closed, w.readable(), raw.closed)
    show(lambda: w.write(b"a"))
