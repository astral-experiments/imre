import io

def show(operation, *args, **kwargs):
    try:
        value = operation(*args, **kwargs)
        print("ok", value)
    except Exception as error:
        print(type(error).__name__, str(error))

w = io.BufferedWriter.__new__(io.BufferedWriter)
print("uninitialized", w.raw, w.readable())
show(w.write)
show(w.write, b"a", b"b")
show(w.write, b"a", size=2)
show(w.write, None)
show(w.write, b"a")
show(w.close)
show(w.flush)
show(w.tell)
show(w.writable)
show(w.truncate, 0)

with io.FileIO("arguments.bin", "w") as raw:
    w.__init__(raw, buffer_size=4)
    show(w.write)
    show(w.write, b"a", b"b")
    show(w.truncate, b=1)
    show(w.seek)
    show(w.write, memoryview(b"ab"))
    show(w.tell)
    print(w.raw is raw, raw.tell())
    w.close()
    print(w.closed, w.readable(), raw.closed)
    show(w.write, b"a")
