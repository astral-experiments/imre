# Native BufferedWriter method controls

These are supplementary programs. They select no CPython unittest IDs. Each lane records the compiler and runtime hashes in provenance.json. Each program directory contains the actual build, executable, and reference process results in receipt.json, with stdout and stderr in separate files. The build command records whether the compiler used its ordinary default or explicit --runtime-imports mode.

The reference is CPython 3.14.5 at 5607950ef232dad16d75c0cf53101d9649d89115. The input sources and driver are in this directory. runner.py is a byte-identical copy of the io-buffer-binding/ordinary/measure.py campaign runner, with SHA-256 d5f8cb9a36f0123245b31685812097da7b97d260057e060861841b93cd1ed26d. Run measure.py to select this directory’s inputs and output location.

| Label | Programs and result |
| --- | --- |
| parent-db4916b-boxed | At O0 and O3 all three original diagnostic programs compiled, then exited 1 because io.BufferedWriter was unavailable. |
| parent-dabdac2-{boxed,ordinary} | The uninitialized-subclass program at O0 and O3 failed ordinary compilation because its base class had no fixed layout. Boxed builds exited 0 and their executables exited 1 at the class declaration because io.BufferedWriter was absent. |
| candidate-5dc98cf-{boxed,ordinary} | In four native lanes the no-op-initializer subclass and close-override probes compiled, ran and matched CPython. The raw_guard probe declined a late raw.write override before moving the raw position in all four. The exploratory arguments.py control hit a separate ordinary frontend restriction on unannotated variadic keyword parameters and an unavailable direct BufferedWriter.__new__ in boxed mode. |
| tested-8d4797a-{boxed,ordinary} | At O0 and O3 all 12 builds and native executions exited 0. uninitialized.py and close_override.py matched the reference in all eight checks. raw_guard.py in all four checks reported an explicit unsupported raw callback with descriptor position still 0. |

All 12 guarded builds and processes exited 0. The eight uninitialized and close-override comparisons matched CPython. The four late raw-override controls refused native fallback before moving the file position.

At guarded head 34849d7434f9b5f776a813d81b5952ec900b2318 the final-34849d7 labels use the exact parent dabdac24. The original unmodified regression and FD, finalization and shutdown probes live in the adjacent dedicated receipts. In the independent boxed shutdown probe, a pure-native self-cycle wrote ABC where CPython left the file empty. Replacing raw.write late with a bound alternate-file method makes CPython write to the alternate file. Imre leaves both files empty at shutdown.

uninitialized.py constructs a genuine subclass whose initializer leaves the native writer uninitialized, tests missing/extra/keyword arguments and type errors, then initializes the object using a real FileIO and tests writing, closure, and retained raw identity. close_override.py injects a raising flush, verifies both objects are closed, and verifies the output file stayed empty. In raw_guard.py an offset's __index__ installs raw.write during seek. CPython invokes the callback. Imre declines the operation before consuming or flushing pending bytes. The two stdout streams intentionally differ here.

Reinitializing an already attached FileIO and raw classes with Python-level I/O methods are outside this native descriptor scope. The closed property refers to the retained descriptor. A path-opened binary writer that has no exposed FileIO retains its existing raw-property limitation. Global finalization, socket/pipe buffering, unchanged originals and intact discovery have their own independent receipts.
