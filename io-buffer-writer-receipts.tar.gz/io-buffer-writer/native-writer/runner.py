"""Compare standalone BufferedReader programs with the pinned interpreter."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
WORK = Path("/workspace/scratch/io-buffer-binding-ordinary-runs")
CPY = Path("/workspace/scratch/cpytools/bin/python3.14")
CLANG = Path("/workspace/scratch/tools/clang")
def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()
def run(argv, cwd, env, logs, kind):
    argv = [str(a) for a in argv]
    start=time.monotonic()
    proc=subprocess.run(argv, cwd=cwd, env=env, capture_output=True, timeout=420)
    (logs/(kind+".stdout")).write_bytes(proc.stdout)
    (logs/(kind+".stderr")).write_bytes(proc.stderr)
    return dict(argv=argv,cwd=str(cwd),exit=proc.returncode,elapsed_s=time.monotonic()-start)
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("bindir",type=Path)
    parser.add_argument("commit")
    parser.add_argument("--boxed",action="store_true")
    parser.add_argument("--jobs",type=int,default=1)
    parser.add_argument("--files",nargs="+",default=["fixture","named","file","receiver","original_style"])
    parser.add_argument("--levels",nargs="+",type=int,default=[0,3])
    options=parser.parse_args()
    b=options.bindir
    assert (b/"READY").read_text().strip()==options.commit
    root=BASE/options.label; root.mkdir(exist_ok=True)
    provenance_path=root/"provenance.json"
    ancestry=dict(sha=options.commit,compiler=sha(b/"imre"),runtime=sha(b/"libimre_runtime.a"))
    previous=json.loads(provenance_path.read_text()) if provenance_path.exists() else {**ancestry, "inputs":{}}
    assert all(previous[k]==v for k,v in ancestry.items())
    previous["inputs"].update({s:sha(BASE/"inputs"/(s+".py")) for s in options.files})
    provenance_path.write_text(json.dumps(previous,indent=2)+"\n")
    def case(job):
        name,level=job
        lane=f"{name}.{'boxed' if options.boxed else 'ordinary'}.O{level}"; logs=root/lane
        cwd=WORK/options.label/lane
        for d in (logs,cwd): d.mkdir(parents=True,exist_ok=True)
        (cwd/"data.bin").write_bytes(b"abcdef")
        src=BASE/"inputs"/(name+".py")
        env={**os.environ,"TMPDIR":str(cwd)}
        oracle=run([CPY,"-IB",src],cwd,env,logs,"oracle");assert oracle["exit"]==0
        exe=cwd/"program";llvm=cwd/"program.ll"
        build=run([b/"imre","build",src,"--no-cache","--runtime",b/"libimre_runtime.a","--clang",CLANG,"--opt-level",level,"--emit-llvm",llvm,"-o",exe]+(["--runtime-imports"] if options.boxed else []),cwd,env,logs,"build")
        result=dict(oracle=oracle,build=build,process=None)
        if build["exit"]==0:
            process=run([exe],cwd,env,logs,"process")
            result.update(process=process,executable_sha256=sha(exe),matches_cpython=process["exit"]==0 and all((logs/("process."+stream)).read_bytes()==(logs/("oracle."+stream)).read_bytes() for stream in ["stderr","stdout"]))
            ir=llvm.read_bytes()
            result.update(llvm_sha256=sha(llvm), boxed_ir=b"@imre_dyn_" in ir)
            exe.unlink()
        llvm.unlink(missing_ok=True)
        (logs/"receipt.json").write_text(json.dumps(result,indent=2)+"\n")
        print(lane,result["build"]["exit"],result["process"] and result["process"]["exit"],result.get("matches_cpython"),flush=True)
    with concurrent.futures.ThreadPoolExecutor(options.jobs) as pool:
        list(pool.map(case,[(n,level) for level in options.levels for n in options.files]))
if __name__=="__main__":
    main()
