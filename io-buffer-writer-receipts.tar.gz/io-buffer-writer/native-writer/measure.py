"""Use the previously validated diagnostic runner for writer argument and ownership probes."""
from pathlib import Path
import runpy
base=Path(__file__).resolve().parent
runner=runpy.run_path(str(base/"runner.py"))
runner['main'].__globals__.update(BASE=base,WORK=Path('/tmp/io-native-writer-cases'))
runner['main']()
