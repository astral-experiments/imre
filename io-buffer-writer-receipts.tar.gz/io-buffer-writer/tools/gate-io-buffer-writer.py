"""Reconcile the signed writer evidence against the raw invocations and binary provenance."""
from collections import Counter
from hashlib import sha256
import csv
import io
import json
import re

CP = '5607950ef232dad16d75c0cf53101d9649d89115'
LANES = [(m, o) for m in ('ordinary','boxed') for o in (0,3)]
PRIMARY = {'permanent','stdio','generation','failure','detach'}
MORE = {'nonblocking','identity'}
IDS = {f'test.test_io.{c}MiscIOTest.{m}': n+i for c,n in [('C',603),('Py',626)]
       for i,m in enumerate(['test_abc_inheritance','test_abc_inheritance_official','test_abcs'])}

def req(ok,why):
    if not ok: raise ValueError(why)

def digest(v):return sha256(v).hexdigest()

def valid_hash(v):return isinstance(v,str) and re.fullmatch(r'[a-f0-9]{64}',v)

def event(e):
    req(e['argv'] and all(isinstance(x,str) for x in e['argv']) and e['cwd'].startswith('/')
        and e['elapsed_s']>=0 and (isinstance(e['exit'],int) or e.get('timed_out')),'process metadata')

def command(b, m, o, p):
    event(b);cmd=b['argv']; at=lambda s:cmd[cmd.index(s)+1]
    req(cmd[1]=='build' and '--no-cache' in cmd and ('--runtime-imports' in cmd)==(m=='boxed')
        and at('--opt-level')==str(o) and cmd[0]==p['compiler'] and at('--runtime')==p['runtime'],cmd)
    return at('-o')

def independent_review(files,commit,compiler,runtime,bindir,oracle,oracle_hash):
    required={k:set(v.split()) for k,v in {
        'probe':'boundary copy full borrowed final cycle callback nonblock partial wrong final_callback double_error',
        'edge':'pipe_seek negative_seek global global_cycle array',
        'hooks':'inherited_shutdown override_shutdown instance_shutdown instance_gc resurrection',
        'late':'late_raw_write'}.items()}
    seen=set()
    prefix='independent-writer-review/';docs=[json.loads(v) for k,v in files.items() if k.startswith(prefix+'runs/') and k.endswith('.json')]
    families={}
    for doc in docs:
        if doc.get('imre_commit')!=commit:continue
        req(doc['cpython_commit']==CP and doc['compiler_sha256']==compiler and doc['runtime_sha256']==runtime and doc['reference_binary_sha256']==oracle_hash,doc['label'])
        refs=[r for r in docs if not r.get('imre_commit') and r['sources']==doc['sources'] and r['reference_binary_sha256']==doc['reference_binary_sha256']]
        req(len(refs)==1,doc['label']+' oracle')
        ref=refs[0]['comparisons']['cpython']
        for family,sh in doc['sources'].items():
            req(family in required and family not in seen,family);seen.add(family)
            source='/workspace/shared/downloads/io-buffer-writer/'+prefix+'sources/'+family+'.py'
            req(digest(files[prefix+'sources/'+family+'.py'])==sh,family)
            for lane in ('boxed.O0','boxed.O3'):
                group=doc['comparisons'][lane][family]; b=group['build'];event(b)
                req(b['argv'][:3]==[bindir+'/imre','build',source] and b['argv'][b['argv'].index('--runtime')+1]==bindir+'/libimre_runtime.a',family+'/'+lane)
                req(b['exit']==0 and '--runtime-imports' in b['argv'] and '--no-cache' in b['argv']
                    and b['argv'][b['argv'].index('--opt-level')+1]==lane[-1] and valid_hash(group['executable_sha256']),family+'/'+lane)
                exe=b['argv'][b['argv'].index('-o')+1]; expected=ref[family]['controls']
                req(set(group['controls'])==set(expected)==required[family],family+'/'+lane)
                for name,row in group['controls'].items():
                    e=row['process'];ce=expected[name]['process']; event(e);event(ce)
                    req(e['argv'][:2]==[exe,name] and ce['argv'][:4]==[oracle,'-IB',source,name] and ce['exit']==0,name)
                    match=all(e[k]==ce[k] for k in ('exit','stdout','stderr')) and all(row.get(k)==expected[name].get(k) for k in ('output_bin_hex','alternate_bin_hex'))
                    req(match==row['matches_cpython'],family+'/'+lane+'/'+name)
                    families.setdefault(lane,{})[family+'/'+name]=match
    req(seen==set(required) and all(len(families[lane])==23 for lane in ('boxed.O0','boxed.O3')),'incomplete independent focused review')
    return {lane:{'total':len(rows),'matches':sum(rows.values()),'different':[k for k,v in rows.items() if not v]} for lane,rows in families.items()}

def validate(files,labels,six_dirs=None,ctl_dirs=None):
    def j(path):return json.loads(files[path])
    def h(path):return digest(files[path])
    frozen={}
    for path in files:
        if path.startswith('build/') and path.endswith('-binary-provenance.json'):
            x=j(path); a=x['artifacts']; pins={n:v['sha256'] for n,v in a.items()}
            req(all(valid_hash(v) and a[n]['has_worktree_source'] for n,v in pins.items()),path)
            req(x['commit'] not in frozen or frozen[x['commit']]==pins,'conflicting provenance')
            frozen[x['commit']]=pins
    def binary(p,commit):
        req(p['imre_commit']==commit and p['compiler_sha256']==frozen[commit]['imre']
            and p['runtime_sha256']==frozen[commit]['libimre_runtime.a'],commit)
    req(h('six/inputs.json')=='4ea69fcbff93b53e9e9bf3f189d34060e5e4ec54f51ca085758587fa442ead4c','authenticated six/inputs.json')
    inp=j('six/inputs.json');orig=inp['files']
    req(inp['cpython']==CP and list(inp['ids'].items())==list(IDS.items()) and len(orig)==30
      and inp['source_upstream_sha256']=='6325b930f5fc9aa8537640423d410e2237811952ae41c097fbb03100cf26f0af'
      and inp['source_archive_sha256']=='bb351d4237125eb2e135a5e68244d228c2893323fcee0713ffdb5c5d9c0b1510'
      and inp['pinned_signer_spki_sha256']=='6a012d499087c2b1f7c54707ca925c8e2e5d07d2d5025d94289254021db59ecc','original inputs')
    def sixstreams(e,d):
        event(e);out=[]
        for stream in ('stdout','stderr'):
            f='six/'+e[stream];req(f.startswith(d+'/') and e[stream+'_sha256']==h(f),f)
            out.append(files[f].decode())
        return '\n'.join(out)
    six=[]
    for stage in ['cpython']+[s for s in labels if s in ('base','tested','public') or s=='intermediate' and s in (six_dirs or {})]:
        folder=(six_dirs or {}).get(stage,stage);d='six/'+folder;p=j(d+'/provenance.json');commit=labels.get(stage)
        req(p['label']==folder and p['cpython_commit']==CP and p['inputs_sha256']==h('six/inputs.json')
            and p['runner_sha256'] in {h(k) for k in ('six/measure.py','six/measure_guarded.py') if k in files} and p['driver_sha256']==orig['run.py']
            and p['source_sha256']==orig['test/test_io.py'],d)
        if commit:
            binary(p,commit)
            p.update(compiler=p['bindir']+'/imre',runtime=p['bindir']+'/libimre_runtime.a')
        for m,o in LANES if commit else [('cpython',0)]:
            ld=f'{d}/{m}-O{o}';r=j(ld+'/receipt.json');rows=r['cases'];b=r['build'];proc=r['process']
            req(r['label']==folder and r['mode']==m and r['opt']==o and r['imre_commit']==commit
              and r['driver_sha256']==p['driver_sha256'] and r['source_sha256']==p['source_sha256']
              and [(c['selector'],c['local_occurrence']) for c in rows]==list(IDS.items()),ld)
            if commit:
                exe=command(b,m,o,p);sixstreams(b,ld)
                req(b['argv'][2]==inp['module_root']+'/run.py' and b['argv'][b['argv'].index('--module-root')+1]==inp['module_root'],ld)
                req((b['exit']==0)==bool(proc),ld)
                if proc:req(valid_hash(r['exe_sha256']) and proc['argv'][0]==exe,ld)
            else:req(b is None and proc['argv'][0]==p['reference_binary'],ld)
            if proc:
                out=sixstreams(proc,ld);selected=re.findall(r'^IMRE_GROUP_SELECTED (.+)$',out,re.M)
                emitted=re.findall(r'^IMRE_GROUP_VERDICT (\S+) (PASS|SKIP|FAIL|ERROR)$',out,re.M)
                req(proc['argv'][-6:]==list(IDS) and re.findall(r'^IMRE_MISSING_EXPORT (\S+ \S+)$',out,re.M)==r['missing_exports'],ld)
                if selected:
                    req(selected==list(IDS) and emitted==[(c['selector'],c['verdict']) for c in rows]
                        and re.search(r'^Ran 6 tests in ',out,re.M)
                        and proc['exit']==int(any(v in ('FAIL','ERROR') for _,v in emitted)),ld)
                else:
                    req(not emitted and proc['exit']!=0 and all(c['verdict']=='UNREACHED' for c in rows),ld)
                    if r['phase']=='load_tests error':req('IMRE_LOADER_ERROR Failed to call load_tests:' in out and r['first_error'] in out,ld)
            else:req(all(c['verdict'] in ('BUILD_ERROR','BUILD_TIMEOUT') for c in rows),ld)
            if not commit:req(all(c['verdict']=='PASS' for c in rows),ld)
            six.append(dict(stage=stage,receipt_label=folder,mode=m,opt=o,build_exit=b and b['exit'],shared_process_exit=proc and proc['exit'],
                            phase=r['phase'],first_error=r['first_error'],outcomes=dict(Counter(c['verdict'] for c in rows)),missing_exports=r['missing_exports']))
    controls={}
    specs=[('reference',None,'reference'),('reference-final',None,'reference-final')]
    specs.extend((k,c,(ctl_dirs or {}).get(k,k+'-'+c[:7])) for k,c in labels.items())
    if 'parent' in labels:specs.append(('parent-final',labels['parent'],'parent-'+labels['parent'][:7]+'-final-fixture'))
    for stage,commit,folder in specs:
        d='controls/'+folder;p=j(d+'/provenance.json')
        req(p['cpython_commit']==CP,d)
        if commit:binary(p,commit)
        paths={f:'controls/sources/'+f+'.py' for f in p['source_sha256']}
        if p.get('permanent_source'):
            paths['permanent']='controls/sources/'+p['permanent_source'].split('/controls/sources/')[-1]
        for f,checksum in p['source_sha256'].items():req(h(paths[f])==checksum,d+'/'+f)
        refdir=p.get('reference_label','reference');req(refdir in ('reference','reference-final'),d)
        summary=j(d+'/summary.json');seen=set()
        for row in summary:
            f=row['family'];lane=row['lane'];ld=d+('/'+lane if lane else '')+'/'+f
            req((lane,f) not in seen and f in p['source_sha256'],ld);seen.add((lane,f))
            def raw(key):
                e=j(ld+'/'+key+'.json');event(e)
                return e,[files[ld+'/'+key+'.'+s] for s in ('stdout','stderr')]
            if commit:
                m,o=lane.split('.O');req((m,int(o)) in LANES,ld)
                b,_=raw('build');exe=command(b,m,int(o),p)
                req(b['argv'][2].endswith('/'+paths[f]) and row['build_exit']==b['exit'],ld)
                if b['exit']!=0:
                    req(row['process_exit'] is None and ld+'/process.json' not in files and not row['matches_reference'],ld);continue
                req(valid_hash(files[ld+'/program.sha256'].decode().strip()),ld)
                e,streams=raw('process');ref='controls/'+refdir+'/'+f
                match=e['exit']==j(ref+'/process.json')['exit'] and streams==[files[ref+'/process.'+s] for s in ('stdout','stderr')]
                req(e['argv']==[exe] and row['process_exit']==e['exit'] and row['matches_reference']==match,ld)
            else:
                e,streams=raw('process')
                req(not lane and row['build_exit'] is None and row['process_exit']==e['exit']==0
                    and e['argv'][0]==p['cpython_executable'] and e['argv'][-1].endswith('/'+paths[f]),ld)
        fam={'permanent'} if stage in ('parent-final','pr_parent') else {'nonblocking','permanent'} if stage=='parent' else PRIMARY if stage=='base' else PRIMARY|MORE
        if stage in ('tested','public','intermediate'):fam={'permanent','identity','nonblocking','failure'}
        needed={(m+'.O'+str(o),f) for m,o in LANES for f in fam} if commit else {('',f) for f in fam}
        req(needed<=seen,d+' missing '+str(needed-seen))
        controls[stage]=dict(recorded=len(seen),matches=sum(r['matches_reference'] is True for r in summary),
                             differences=[r for r in summary if r['matches_reference'] is False],
                             cancelled=[r for r in summary if r.get('outcome')=='CANCELLED_BUILD'])
    intact={}
    for stage in ('base','public'):
        if stage not in labels:continue
        d='intact/native/'+stage;p=j(d+'/provenance.json');binary(p,labels[stage])
        req(p['cpython_commit']==CP and p['source_sha256']['test/test_io.py']==inp['source_upstream_sha256']
            and p['source_sha256']['run_intact_discovery.py']==h('intact/drivers/run_intact_discovery.py'),d)
        for m,o in ([('ordinary',0)] if stage=='base' else LANES):
            lane=f'{m}.O{o}';ld=d+'/'+lane;r=j(ld+'/result.json');b=r['build'];proc=r['process']
            req(r['scope']=='discovery' and r['level']==o and r['mode']==m and r['tests_run']==0,ld)
            exe=command(b,m,o,p);req((b['exit']==0)==bool(proc),ld)
            entry=b['argv'][2];root=b['argv'][b['argv'].index('--module-root')+1]
            req(root=='/workspace/scratch/bw-intact/Lib' and entry==root+'/run_intact_discovery.py',ld)
            req(p['expected_ordered_ids_sha256']==inp['ordered_ids_sha256'],ld)
            for e in [b]+([proc] if proc else []):
                event(e)
                for s in ('stdout','stderr'):req('intact/'+e[s] in files and ('intact/'+e[s]).startswith(ld+'/'),ld)
            if proc:
                req(valid_hash(r['executable_sha256']) and proc['argv']==[exe],ld)
                ids=re.findall(rb'^IMRE_IO_ID (.+)$',files['intact/'+proc['stdout']],re.M)
                order=b'\n'.join(ids)+b'\n' if ids else None
                req(len(ids)==r['observed_id_lines'] and r['ordered_ids_sha256']==(digest(order) if order else None),ld)
                if order:req(files[ld+'/observed.ids']==order,ld)
                all_counts=re.findall(rb'^IMRE_IO_DISCOVERED (.+)$',files['intact/'+proc['stdout']],re.M)
                complete=proc['exit']==0 and len(ids)==667 and all_counts==[b'667'] and r['ordered_ids_sha256']==p['expected_ordered_ids_sha256']
                req(r['discovery_complete']==complete,ld)
            else:req(r['observed_id_lines']==0 and r['ordered_ids_sha256'] is None and not r['discovery_complete'],ld)
            intact[stage+'/'+lane]=dict(build_exit=b['exit'],discovery_exit=proc and proc['exit'],ids=r['observed_id_lines'])
    if 'public' in labels:
        table=csv.DictReader(io.StringIO(files['public-six.tsv'].decode()),delimiter='\t')
        req(table.fieldnames==['mode','opt','ordinal_in_667','id_occurrence','canonical_id','method_verdict',
             'shared_build_exit','shared_process_exit','raw_receipt','raw_receipt_sha256'],'public-six TSV header')
        seen=set()
        for row in table:
            req(None not in row and None not in row.values(),'malformed public-six row width')
            m=row['mode'];o=int(row['opt']);name=row['canonical_id'];key=(m,o,name)
            req((m,o) in LANES and name in IDS and key not in seen,'public-six duplicate or unknown ID');seen.add(key)
            f='six/public/'+m+'-O'+str(o)+'/receipt.json'; r=j(f);entry=next(c for c in r['cases'] if c['selector']==name)
            req(int(row['ordinal_in_667'])==IDS[name] and int(row['id_occurrence'])==1
                and row['raw_receipt']==f and row['raw_receipt_sha256']==h(f) and row['method_verdict']==entry['verdict']
                and row['shared_build_exit']==('' if r['build']['exit'] is None else str(r['build']['exit']))
                and row['shared_process_exit']==('' if not r['process'] or r['process']['exit'] is None else str(r['process']['exit'])),f)
        req(len(seen)==24,'expected 24 occurrence/lane rows')
    review={}
    if 'public' in labels:
        cp=j('six/cpython/provenance.json');folder=(six_dirs or {}).get('tested','tested')
        review=independent_review(files,labels['tested'],frozen[labels['tested']]['imre'],frozen[labels['tested']]['libimre_runtime.a'],
                                 j('six/'+folder+'/provenance.json')['bindir'],cp['reference_binary'],cp['reference_sha256'])
    return dict(cpython=CP,commits=labels,original_occurrences=IDS,independent_writer_review=review,six_grouped=six,supplementary_controls=controls,intact_import=intact)
