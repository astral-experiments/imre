# Public native BufferedWriter and six MiscIO ABC methods

[PR #3783](https://github.com/astral-experiments/imre/pull/3783) merged as `5d6d2acd109147bee05b7c6e9e49a3c094c20a8b` with a head guard on `34849d7434f9b5f776a813d81b5952ec900b2318`. The tested parent was `dabdac24ddd59f565a5f67a7660c9c2ae2631506`, the earlier development parent was `db4916b0223c1d0e95385ed1fc2c6c4eb4400c58`, and the initial public baseline was `5b530f76ad62e28f08ad9e102f01f0383c5f5133`. The public first-parent patch has SHA-256 `07b0818ec6b50bde583f985809178505d52dd4a416cbb268b26f7cc841d220f9`. Native receipts record compiler, runtime and executable digests, argv, elapsed time and separate compiler/process statuses.

On the final parent the permanent fixture failed during ordinary compilation and during boxed import at both optimization levels. The public class identifies the native writer returned by binary open, is identical through both module exports, and registers with the public buffered ABC. Constructing it or a Python subclass over an exact native FileIO retains the same raw object. Controls cover actual write visibility before/after flush and close, bound and unbound writes, invalid receivers and data, OS failures, and retrying a partially accepted write on a real nonblocking pipe.

## Original results

Pinned CPython 3.14.5 at `5607950ef232dad16d75c0cf53101d9649d89115` passed all six selectors. The focused projection reuses the #3673 signed driver, unchanged methods, setup and teardown, and narrows the loader's class tuple to the two Misc classes. Its original fixture population resolves every entry in io.__all__. Each public lane has one native process for all six selectors. At original line 5095 it encountered the first missing export, io.BufferedRWPair. No native method or setup ran. The full unchanged module independently reached CBufferedRWPairTest.tp at line 2406 and stopped before any of its 667 IDs registered.

| Public lane | Six-selector build / process | Actual six-selector diagnostic | Intact build / process and first failure |
| --- | --- | --- | --- |
| ordinary O0 | 0 / 1 | AttributeError: module 'io' has no attribute 'BufferedRWPair' | 0 / 1, test_io.py:2406 |
| ordinary O3 | 0 / 1 | AttributeError: module 'io' has no attribute 'BufferedRWPair' | 0 / 1, test_io.py:2406 |
| boxed O0 | 0 / 1 | AttributeError: module 'io' has no attribute 'BufferedRWPair' | 0 / 1, test_io.py:2406 |
| boxed O3 | 0 / 1 | AttributeError: module 'io' has no attribute 'BufferedRWPair' | 0 / 1, test_io.py:2406 |

[Six canonical IDs, ordinals, per-ID occurrences and raw receipt hashes in all four lanes](public-six.tsv). The 24 rows represent six selectors requested in four shared processes. Each method's native disposition is UNREACHED. The distinct class controls add zero unittest IDs.

## Qualification

The checked-in fixture, fresh native FileIO generation/ABC identity, real nonblocking partial-write retry and flush/close error controls matched pinned CPython at ordinary and forced-boxed O0/O3 on the tested head and public squash. Direct ordinary mode uses default compiler selection and can lower a fixture to boxed IR. The separate test of direct typed sys.stdout.buffer access encounters a pre-existing compile diagnostic. A real fresh module's public and private writer constructors retain the supplied raw. Older path-open handles omit .raw, and an fd open through a reimported module can keep the first-generation FileIO. Explicit writer detach and underlying raw reinitialization are outside this leaf. Explicit native buffers larger than 8 MiB and Python raw callbacks are unsupported.

Independent review qualified the file-handle ownership, GC paths and method dispatch on the final tested head. Its 23 OS/GC controls matched CPython in 21 cases at each optimization level in forced-boxed mode. Verified behaviors include ordinary acyclic shutdown persistence, explicit/cyclic GC, close override and resurrection, real partial writes without duplicated bytes, retained raw descriptor identity, exception chaining, failed seeks, and contiguous array writes. Two directed cases differ at interpreter shutdown. An otherwise native self-referential global writer flushes pending bytes on Imre, while CPython leaves the file empty. Replacing raw.write with another file's Python-bound method after buffering redirects the data at CPython shutdown. Imre suppresses the native fallback and leaves both files empty. Neither result contributes an original unittest verdict.

The io owner retains the broader test_file work and the decoder. The shutil owner retains callback-backed BufferedReader. [IO coordination](https://github.com/astral-experiments/imre/pull/3356#issuecomment-6570396044) · [Nonblocking descriptor dependency](https://github.com/astral-experiments/imre/pull/3702#issuecomment-6570394092) · [BufferedReader owner](https://github.com/astral-experiments/imre/pull/3437)
