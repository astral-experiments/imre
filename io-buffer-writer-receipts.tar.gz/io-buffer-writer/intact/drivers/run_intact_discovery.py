import test.test_io as target
import unittest

loader = unittest.TestLoader()
suite = loader.loadTestsFromModule(target)
if loader.errors:
    for problem in loader.errors:
        print("IMRE_IO_LOADER_ERROR", problem)
    raise RuntimeError("test_io load_tests failed")
for group in suite:
    for case in group:
        print("IMRE_IO_ID", case.id())
print("IMRE_IO_DISCOVERED", suite.countTestCases())

