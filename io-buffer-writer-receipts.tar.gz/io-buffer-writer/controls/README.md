# BufferedWriter controls

These are independent native compatibility probes. Original CPython unittest methods and their verdicts live in the separate six-case receipts. A successful control requires a successful build, exit 0 from its generated native executable, and stdout and stderr identical to the pinned CPython 3.14.5 reference.

| Core probe | What it measures |
|---|---|
| permanent | Public/private type identity, subclass and ABC relationships, a retained real FileIO, write/flush/close behavior, rejected arguments and the subclass GC close override |
| identity | Old and fresh opener classes after reimport, builtins.open, an already-created stdout stream and the exact fresh FileIO retained by a fresh constructor |
| nonblocking | A real full pipe reports five accepted bytes with three already queued in an eight-byte buffer, a blocked flush reports zero, the retry emits each byte once, and the borrowed fd survives closure |
| failure | Closed raw descriptors, invalid types/sizes, and real write/flush/close failures on Linux /dev/full |

The final permanent fixture is byte-identical to the checked-in fixture, SHA-256 `917b1acc94d8df13542693d4be9796aa620fe8bae1e0110297bc551ba9604582`. The earlier fixture with SHA-256 `9168d869e750abdb629746d5411308cf9ba9930fa7815e21baeee40b9657f33d` remains under `sources/permanent.py` for its original before and intermediate measurements. Each revision has its own CPython reference. [Revised fixture](sources/final/permanent.py) · [Revised reference](reference-final/summary.json) · [Initial fixture](sources/permanent.py) · [Initial reference](reference/summary.json)

At the exact PR parent `dabdac24ddd59f565a5f67a7660c9c2ae2631506`, ordinary compilation rejected the unavailable sealed export in both optimization levels. Both forced-boxed binaries built and failed when importing the missing type. All 16 core probes on guarded `34849d7434f9b5f776a813d81b5952ec900b2318` passed across ordinary and forced-boxed compilation at `-O0` and `-O3`. [Exact parent](parent-dabdac2/summary.json) · [Guarded head](guarded-34849d7/summary.json)

The extra diagnostics preserve the bounds observed on intermediate heads. The direct stdio probe passed forced-boxed at both levels. In ordinary mode the compiler rejected direct `sys.stdout.buffer` type inspection. The legacy path opener's outer class was correct, and asking for its raw object raised AttributeError. Explicit constructor detach raised UnsupportedOperation. All 12 diagnostic cells completed on `5dc98cf`. On `8d4797a`, the boxed `-O3` legacy path/raw compilation was cancelled after the 16 core probes passed, with no native verdict. [Initial diagnostics](candidate-5dc98cf/summary.json) · [Revised intermediate diagnostics](tested-8d4797a/summary.json) · [Cancellation receipt](tested-8d4797a/boxed.O3/generation/CANCELLED.json)

Public squash `5d6d2acd109147bee05b7c6e9e49a3c094c20a8b` passed the same 16 controls. Each public build and binary exited 0 and every stream matched CPython. The fixture in the public tree has the same final SHA-256. [Public receipts](public-5d6d2ac/summary.json) · [Merged PR](https://github.com/astral-experiments/imre/pull/3783)
