import io
import os

with io.FileIO(os.devnull, "w") as raw:
    w = io.BufferedWriter(raw, 4)
    assert w.write(b"ab") == 2
    assert w.detach() is raw
    assert not raw.closed
    assert w.raw is None
    for operation in (w.flush, w.close, w.detach):
        try:
            operation()
        except ValueError as exc:
            print(str(exc))
        else:
            raise AssertionError("operation on detached stream succeeded")
    assert raw.write(b"x") == 1
print("detached raw survives wrapper")
