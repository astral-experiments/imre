import _io
import io
import sys

assert type(sys.stdout.buffer) is _io.BufferedWriter
assert type(sys.stderr.buffer) is io.BufferedWriter
assert isinstance(sys.stdout.buffer, io.BufferedIOBase)
assert not isinstance(sys.stdout.buffer, io.RawIOBase)
assert isinstance(sys.stdin.buffer, _io.BufferedReader)
assert not isinstance(sys.stdin.buffer, io.BufferedWriter)
assert sys.stdout.buffer.writable() and not sys.stdout.buffer.readable()
print("stdin, stdout, stderr buffered stream classes")
