import io
import os

def raises(expected, operation, *args):
    try:
        operation(*args)
    except expected as exc:
        print(type(exc).__name__, str(exc))
        return
    raise AssertionError("operation succeeded")

with io.FileIO(os.devnull, "w") as raw:
    raises(ValueError, io.BufferedWriter, raw, -1)
    raises(TypeError, io.BufferedWriter, raw, "4")
    w = io.BufferedWriter(raw, 4)
    raises(TypeError, w.write, None)
    assert w.write(b"ab") == 2
    raw.close()
    assert w.raw is raw and w.closed
    raises(ValueError, w.flush)
    raises(ValueError, w.write, b"x")
    assert w.close() is None
with io.FileIO("/dev/full", "w") as raw:
    w = io.BufferedWriter(raw, 8)
    assert w.write(b"xy") == 2
    raises(OSError, w.flush)
    raises(OSError, w.close)
    assert w.closed and raw.closed
print("closed raw and failed flush/close")
