import _io
import importlib
import io
import os
import sys

first = _io
first_public = io
saved_open = io.open
stream = sys.stdout.buffer

del sys.modules["_io"]
second = importlib.import_module("_io")
assert second.BufferedWriter is not first.BufferedWriter
assert first_public.BufferedWriter is first.BufferedWriter
with second.open(os.devnull, "wb") as writer:
    assert type(writer) is second.BufferedWriter
    assert type(writer.raw) is second.FileIO
with first_public.open(os.devnull, "wb") as writer:
    assert type(writer) is first.BufferedWriter

del sys.modules["io"]
second_public = importlib.import_module("io")
assert second_public.BufferedWriter is second.BufferedWriter
with second_public.open(os.devnull, "wb") as writer:
    assert type(writer) is second.BufferedWriter
    assert type(writer.raw) is second.FileIO
with saved_open(os.devnull, "wb") as writer:
    assert type(writer) is first.BufferedWriter
    assert type(writer.raw) is first.FileIO
with open(os.devnull, "wb") as writer:
    assert type(writer) is first.BufferedWriter
    assert type(writer.raw) is first.FileIO
assert type(stream) is first.BufferedWriter
print("opener and raw generations, saved open, builtins.open and stdout")
