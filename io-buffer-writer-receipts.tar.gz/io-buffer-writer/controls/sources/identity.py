import _io
import importlib
import io
import os
import sys

first_writer = _io.BufferedWriter
first_open = io.open
held = sys.stdout.buffer
assert type(held) is first_writer

del sys.modules["_io"]
second = importlib.import_module("_io")
assert second.BufferedWriter is not first_writer
with second.open(os.devnull, "wb") as stream:
    assert type(stream) is second.BufferedWriter
with first_open(os.devnull, "wb") as stream:
    assert type(stream) is first_writer

del sys.modules["io"]
public = importlib.import_module("io")
assert public.BufferedWriter is second.BufferedWriter
with public.open(os.devnull, "wb") as stream:
    assert type(stream) is second.BufferedWriter
with open(os.devnull, "wb") as stream:
    assert type(stream) is first_writer
assert type(held) is first_writer
with second.FileIO(os.devnull, "w") as raw:
    with public.BufferedWriter(raw, 8) as stream:
        assert type(stream) is second.BufferedWriter
        assert type(raw) is second.FileIO
        assert stream.raw is raw
        assert stream.write(b"x") == 1
print("old and fresh writer classes, fresh constructor retains raw")
