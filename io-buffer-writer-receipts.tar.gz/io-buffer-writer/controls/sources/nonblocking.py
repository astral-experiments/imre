import errno
import io
import os


def blocked(operation, *args):
    try:
        operation(*args)
    except BlockingIOError as exc:
        assert exc.errno == errno.EAGAIN
        assert exc.args[2] == exc.characters_written
        return exc.characters_written
    raise AssertionError("expected BlockingIOError")


reader, fd = os.pipe()
try:
    os.set_blocking(fd, False)
    os.set_blocking(reader, False)
    pad = 0
    while True:
        try:
            pad += os.write(fd, b"x" * 4096)
        except BlockingIOError:
            break
    assert pad > 0
    payload = b"abcdefghijkl"
    with io.FileIO(fd, "w", closefd=False) as raw:
        writer = io.BufferedWriter(raw, 8)
        assert writer.raw is raw
        assert writer.write(b"123") == 3
        count = blocked(writer.write, payload)
        assert count == 5
        assert blocked(writer.flush) == 0
        assert os.read(reader, pad) == b"x" * pad
        assert writer.write(payload[count:]) == len(payload) - count
        writer.close()
        assert raw.closed
        assert os.read(reader, 15) == b"123" + payload
    assert os.write(fd, b"z") == 1
    assert os.read(reader, 1) == b"z"
finally:
    os.close(fd)
    os.close(reader)
print("partial 5, flush 0, retry and borrowed fd")
