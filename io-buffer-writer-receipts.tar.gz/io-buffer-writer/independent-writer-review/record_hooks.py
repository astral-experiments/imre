"""Use the shared recorder for the supplementary shutdown and resurrection probes."""
import record

record.CASES = {"hooks": ["inherited_shutdown", "override_shutdown", "instance_shutdown", "instance_gc", "resurrection"]}
if __name__ == "__main__":
    record.main()
