"""Probe Python-level writer ownership while retaining and observing the real raw descriptor."""
import gc
import io
import sys

case = sys.argv[1]
raw = io.FileIO("output.bin", "w")
if case == "inherited_shutdown":
    class Writer(io.BufferedWriter):
        pass
    writer = Writer(raw, 8)
    writer.write(b"ABC")
    print("at_return", raw.tell())
elif case == "override_shutdown":
    class Writer(io.BufferedWriter):
        def close(self):
            print("CALLBACK subclass close")
    writer = Writer(raw, 8)
    writer.write(b"ABC")
    print("at_return", raw.tell())
elif case in ("instance_shutdown", "instance_gc"):
    writer = io.BufferedWriter(raw, 8)
    def close():
        print("CALLBACK instance close")
    writer.close = close
    writer.write(b"ABC")
    if case == "instance_gc":
        del writer
        gc.collect()
        print("after_gc", raw.closed)
    else:
        print("at_return", raw.tell())
elif case == "resurrection":
    rescued = []
    class Writer(io.BufferedWriter):
        def close(self):
            print("CALLBACK resurrect writer")
            rescued.append(self)
    writer = Writer(raw, 8)
    writer.write(b"ABC")
    del writer
    gc.collect()
    print("after_resurrection", len(rescued), raw.closed)
    if rescued:
        revived = rescued.pop()
        print("revived_write", revived.write(b"D"), raw.tell())
        del revived
        gc.collect()
        print("after_release", len(rescued), raw.closed)
