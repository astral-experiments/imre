import gc
import io
import os
import sys
name=sys.argv[1]

if name=="pipe_seek":
    rd,wr=int(sys.argv[2]),int(sys.argv[3])
    raw=io.FileIO(wr,"w",closefd=False)
    w=io.BufferedWriter(raw,8)
    w.write(b"abc")
    try: w.seek(0)
    except Exception as e: print("seek_error",type(e).__name__,getattr(e,"errno",None))
    try: print("before_close",os.read(rd,16))
    except BlockingIOError: print("before_close","BLOCKED")
    w.close()
    try: print("after_close",os.read(rd,16))
    except BlockingIOError: print("after_close","BLOCKED")
elif name=="negative_seek":
    raw=io.FileIO("output.bin","w")
    w=io.BufferedWriter(raw,8)
    w.write(b"ABC")
    try: w.seek(-1)
    except Exception as e: print("negative",type(e).__name__,getattr(e,"errno",None),raw.tell())
    w.close()
elif name=="global":
    raw=io.FileIO("output.bin","w")
    w=io.BufferedWriter(raw,8)
    w.write(b"ABC")
    print("at_return",raw.tell())
elif name=="global_cycle":
    raw=io.FileIO("output.bin","w")
    w=io.BufferedWriter(raw,8)
    w.me=w
    w.write(b"ABC")
    print("at_return",raw.tell())
elif name=="array":
    import array
    raw=io.FileIO("output.bin","w")
    w=io.BufferedWriter(raw,8)
    a=array.array("B",[65,66,67])
    try: print("accepted",w.write(a))
    except Exception as e: print("raised",type(e).__name__,str(e))
    w.close()
