"""Independent FileIO-backed BufferedWriter checks on real parent-supplied fds."""
import gc
import io
import os
import sys

def boundary():
    raw = io.FileIO("output.bin","w")
    w = io.BufferedWriter(raw,4)
    print("initial",w.tell(),raw.tell())
    print("exact",w.write(b"abcd"),w.tell(),raw.tell())
    print("half",w.write(b"ef"),w.tell(),raw.tell())
    print("full",w.write(b"gh"),w.tell(),raw.tell())
    print("overflow",w.write(b"i"),w.tell(),raw.tell())
    w.close()
    print("closed",raw.closed,w.closed)

def memcopy():
    raw=io.FileIO("output.bin","w")
    w=io.BufferedWriter(raw,8)
    pending=bytearray(b"ABC")
    w.write(pending)
    pending[0]=90
    w.close()

def filesystem_full():
    raw=io.FileIO("/dev/full","w")
    w=io.BufferedWriter(raw,4)
    print("accepted",w.write(b"x"))
    try: w.flush()
    except OSError as e: print("flush",type(e).__name__,e.errno,raw.closed,w.closed)
    try: w.close()
    except OSError as e: print("close",type(e).__name__,e.errno,raw.closed,w.closed)
    print("closed",raw.closed,w.closed,w.close())

def borrowed(fd):
    raw=io.FileIO(fd,"w",closefd=False)
    w=io.BufferedWriter(raw,4)
    w.write(b"ab")
    w.close()
    print("closed",raw.closed,w.closed,"borrowed",os.write(fd,b"X"))

def finalize(cycle):
    raw=io.FileIO("output.bin","w")
    w=io.BufferedWriter(raw,8)
    w.write(b"abc")
    if cycle: w.myself=w
    del w
    gc.collect()
    print("gc",raw.closed)
    raw.close()

def override_flush():
    class W(io.BufferedWriter):
        def flush(self):
            print("CALLBACK flush")
            raise OSError("override flush")
    raw=io.FileIO("output.bin","w")
    w=W(raw,8)
    w.write(b"ab")
    try: w.close()
    except OSError as e: print("overridden",str(e))
    print("closed",raw.closed,w.closed)

def nonblock(rd, wr):
    raw=io.FileIO(wr,"w",closefd=False)
    w=io.BufferedWriter(raw,4)
    print("accepted",w.write(b"ABC"))
    try: w.write(b"def")
    except BlockingIOError as e: print("partial_buffer",e.errno,e.characters_written)
    try: w.flush()
    except BlockingIOError as e: print("blocked_flush",e.errno,e.characters_written)
    print("drain",len(os.read(rd,65536)))
    w.flush()
    print("pending",os.read(rd,16))
    w.close()
    print("closed",w.closed,raw.closed,os.write(wr,b"X"))

def partial_raw(rd,wr):
    raw=io.FileIO(wr,"w",closefd=False)
    w=io.BufferedWriter(raw,4)
    print("initial_drain",len(os.read(rd,4096)))
    block=b"A"*4096+b"QRST"+b"B"*8192
    try: print("whole",w.write(block))
    except BlockingIOError as e: print("partial_direct",e.errno,e.characters_written)
    drained=os.read(rd,262144)
    print("after",len(drained),drained[-6:])
    w.flush()
    print("tail",os.read(rd,64))
    w.close()

def wrong():
    for obj in (io.BytesIO(),None):
        for f in (io.BufferedWriter.write,io.BufferedWriter.flush,io.BufferedWriter.close):
            try:
                if f is io.BufferedWriter.write: f(obj,b"a")
                else: f(obj)
            except Exception as e: print("descriptor",type(e).__name__)

def final_callback():
    class W(io.BufferedWriter):
        def close(self):
            print("FINAL_CLOSE called")
    raw=io.FileIO("output.bin","w")
    w=W(raw,8)
    w.write(b"abc")
    del w
    gc.collect()
    print("raw_closed",raw.closed)
    raw.close()

def double_error():
    raw=io.FileIO("output.bin","w")
    w=io.BufferedWriter(raw,8)
    w.write(b"abc")
    os.close(raw.fileno())
    try: w.close()
    except OSError as err:
        nested=err.__context__
        print("chain",err.errno,nested.errno if nested is not None else None,raw.closed,w.closed)

name=sys.argv[1]
if name=="boundary": boundary()
elif name=="copy": memcopy()
elif name=="full": filesystem_full()
elif name=="borrowed": borrowed(int(sys.argv[2]))
elif name=="final": finalize(False)
elif name=="cycle": finalize(True)
elif name=="callback": override_flush()
elif name=="nonblock": nonblock(int(sys.argv[2]),int(sys.argv[3]))
elif name=="partial": partial_raw(int(sys.argv[2]),int(sys.argv[3]))
elif name=="wrong": wrong()
elif name=="final_callback":final_callback()
elif name=="double_error":double_error()
