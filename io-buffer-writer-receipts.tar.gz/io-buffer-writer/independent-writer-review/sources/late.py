"""Replace a FileIO method only after a real writer has buffered a short write."""
import io

raw = io.FileIO("output.bin", "w")
writer = io.BufferedWriter(raw, 8)
writer.write(b"ABC")
sink = io.FileIO("alternate.bin", "w")
raw.write = sink.write
print("at_return", raw.tell())
