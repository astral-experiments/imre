"""Record a live writer with its raw.write method replaced after data was accepted."""
import record

record.CASES = {"late": ["late_raw_write"]}
if __name__ == "__main__":
    record.main()
