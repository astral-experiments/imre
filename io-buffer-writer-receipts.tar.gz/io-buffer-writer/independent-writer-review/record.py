"""Record isolated supplementary native writer semantics on genuine Linux filesystem descriptors."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time

SOURCES=Path(__file__).resolve().parent/"sources"
CASES={"probe":"boundary copy full borrowed final cycle callback nonblock partial wrong final_callback double_error".split(),
       "edge":"pipe_seek negative_seek global global_cycle array".split()}
CPY=Path("/workspace/scratch/cpytools/bin/python3.14")
CPY_COMMIT="5607950ef232dad16d75c0cf53101d9649d89115"
CLANG=Path("/workspace/scratch/tools/clang")
def digest(path):
    with path.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()

def command(argv,cwd,fds=(),timeout=45):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    timer=time.monotonic()
    args=list(map(str,argv))
    env={k:v for k,v in os.environ.items() if not k.startswith(("PYTHON","IMRE"))}
    env.update(TMPDIR=str(cwd), PYTHONDONTWRITEBYTECODE="1")
    try:
        p=subprocess.run(args,cwd=cwd,env=env,pass_fds=fds,capture_output=True,timeout=timeout)
        rc,out,err=p.returncode,p.stdout,p.stderr
    except subprocess.TimeoutExpired as e:
        rc,out,err=None,e.stdout or b"",e.stderr or b""
    return dict(argv=args,cwd=str(cwd),utc_start=start,elapsed_s=round(time.monotonic()-timer,6),exit=rc,
                timed_out=rc is None,timeout_s=timeout,stdout=out.decode(),stderr=err.decode())

def check(cmd, name, work):
    with tempfile.TemporaryDirectory(dir=work,prefix="case-") as temp:
        wd=Path(temp);args=[*cmd,name];fds=[];fixture={}
        try:
            if name=="borrowed":
                f=os.open(wd/"output.bin",os.O_RDWR|os.O_CREAT,0o600);fds.append(f);args.append(str(f))
                fixture=dict(kind="owned by parent, borrowed FileIO",fd=f)
            if name in ("nonblock","partial","pipe_seek"):
                r,w=os.pipe2(os.O_NONBLOCK);fds.extend((r,w));args.extend(map(str,(r,w)))
                total=0
                if name!="pipe_seek":
                    while True:
                        try:total+=os.write(w,b"P"*4096)
                        except BlockingIOError:break
                fixture=dict(kind="kernel pipe2 O_NONBLOCK",capacity=fcntl.fcntl(w,fcntl.F_GETPIPE_SZ),
                             prefill_bytes=total,read_fd=r,write_fd=w)
            rec=command(args,wd,tuple(fds));data=wd/"output.bin"
            row=dict(process=rec,output_bin_hex=data.read_bytes().hex() if data.is_file() else None,fixture=fixture)
            alternate=wd/"alternate.bin"
            if alternate.is_file(): row["alternate_bin_hex"]=alternate.read_bytes().hex()
            return row
        finally:
            for fd in fds:os.close(fd)

def outcome(row):
    p=row["process"]
    return p["exit"],p["stdout"],p["stderr"],row["output_bin_hex"],row.get("alternate_bin_hex")

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--work",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True);parser.add_argument("--label",required=True)
    parser.add_argument("--reference",type=Path);parser.add_argument("--bindir",type=Path);parser.add_argument("--commit")
    a=parser.parse_args();bin=a.bindir
    a.work.mkdir(parents=True,exist_ok=True)
    report=dict(label=a.label,scope="Supplementary OS-backed writer comparisons. Zero original unittest IDs.",
                cpython_commit=CPY_COMMIT,reference_binary_sha256=digest(CPY),sources={m:digest(SOURCES/(m+".py")) for m in CASES},
                comparisons={})
    if bin:
        assert a.commit and (bin/"READY").read_text().strip()==a.commit
        ref=json.loads(a.reference.read_bytes())
        assert ref["sources"]==report["sources"] and ref["reference_binary_sha256"]==report["reference_binary_sha256"]
        compiler,runtime=bin/"imre",bin/"libimre_runtime.a"
        report.update(imre_commit=a.commit,compiler_sha256=digest(compiler),runtime_sha256=digest(runtime),clang_sha256=digest(CLANG))
    for level in ((0,3) if bin else (None,)):
        lane="cpython" if level is None else f"boxed.O{level}"
        per=report["comparisons"][lane]={}
        for mod in sorted(CASES):
            names=CASES[mod]
            source=SOURCES/(mod+".py");block=per[mod]={};exe=a.work/(mod+"-native")
            if bin:
                cmd=[compiler,"build",source,"--runtime-imports","--no-cache","--runtime",runtime,"--clang",CLANG,
                     "--opt-level",str(level),"-o",exe]
                block["build"]=command(cmd,a.work,timeout=600)
                assert block["build"]["exit"]==0,block["build"]
                block["executable_sha256"]=digest(exe);base=[exe]
            else:base=[CPY,"-IB",source]
            results=block["controls"]={}
            for name in names:
                row=check(base,name,a.work)
                if bin:row["matches_cpython"]=outcome(row)==outcome(ref["comparisons"]["cpython"][mod]["controls"][name])
                results[name]=row
                if bin:
                    print(a.label,lane,name,row["matches_cpython"],repr(outcome(row)) if not row["matches_cpython"] else "",flush=True)
            if bin:exe.unlink()
    if bin:
        assert digest(compiler)==report["compiler_sha256"] and digest(runtime)==report["runtime_sha256"] and (bin/"READY").read_text().strip()==a.commit
    a.output.write_text(json.dumps(report,indent=2)+"\n")
if __name__=="__main__":main()
