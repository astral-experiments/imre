# Independent native BufferedWriter review

These 23 supplementary controls contribute zero original unittest IDs. The 17 general controls and five shutdown and resurrection controls have separate CPython receipts, as does the late raw.write replacement control. All runs use genuine Linux descriptors and isolated child processes. The nonblocking tests fill real kernel pipes to EAGAIN before starting each child. The raw records include compiler and runtime hashes, process boundaries and exits, stdout, stderr, and exact filesystem bytes after process exit.

The final reviewed Imre source is `34849d7434f9b5f776a813d81b5952ec900b2318`. The CPython oracle is 3.14.5 at `5607950ef232dad16d75c0cf53101d9649d89115`. A match means all four observed process results agree with the pinned interpreter (exit, stdout, stderr, and all observed output file bytes). Optimization levels use independent cache-disabled builds.

| Raw run | Lane | Matches | Diverging controls |
| --- | --- | --- | --- |
| candidate-5dc98cf | boxed.O0 | 11/17 | final_callback, double_error, pipe_seek, negative_seek, global_cycle, array |
| candidate-5dc98cf | boxed.O3 | 11/17 | final_callback, double_error, pipe_seek, negative_seek, global_cycle, array |
| final-34849d7 | boxed.O0 | 16/17 | global_cycle |
| final-34849d7 | boxed.O3 | 16/17 | global_cycle |
| hooks-8d4797a | boxed.O0 | 4/5 | inherited_shutdown |
| hooks-8d4797a | boxed.O3 | 4/5 | inherited_shutdown |
| hooks-final-34849d7 | boxed.O0 | 5/5 | — |
| hooks-final-34849d7 | boxed.O3 | 5/5 | — |
| late-final-34849d7 | boxed.O0 | 0/1 | late_raw_write |
| late-final-34849d7 | boxed.O3 | 0/1 | late_raw_write |
| tested-8d4797a | boxed.O0 | 16/17 | global |
| tested-8d4797a | boxed.O3 | 16/17 | global |

The 17 general cases cover buffer boundaries, mutable input copy, ENOSPC, borrowed descriptor ownership, explicit finalization and garbage collection, Python flush override, nonblocking partial writes, wrong receiver rejection, Python close override, dual-error exception chaining, unseekable and negative seeks, live and cyclic writers at normal shutdown, and array writes. The five additional cases cover a live inherited subclass, subclass and instance close overrides at shutdown, an instance override during collection, and resurrection.

Each entry in `runs/` records the exact invocation and SHA-256 of its sources. Replay the 17-control run with `python3 record.py` and the five-control run with `PYTHONDONTWRITEBYTECODE=1 python3 record_hooks.py`, and the late raw.write control with `PYTHONDONTWRITEBYTECODE=1 python3 record_late.py`, using the flags shown by `--help` and a matching compiler/runtime directory with a full-SHA `READY` marker.

## Observed final-head differences

- `global_cycle` returned 0 under CPython and 0 natively. CPython observed `{"primary_hex": "", "stderr": "", "stdout": "at_return 0\n"}`. Imre observed `{"primary_hex": "414243", "stderr": "", "stdout": "at_return 0\n"}`.
- `late_raw_write` returned 0 under CPython and 0 natively. CPython observed `{"alternate_hex": "414243", "primary_hex": "", "stderr": "", "stdout": "at_return 0\n"}`. Imre observed `{"alternate_hex": "", "primary_hex": "", "stderr": "", "stdout": "at_return 0\n"}`.
