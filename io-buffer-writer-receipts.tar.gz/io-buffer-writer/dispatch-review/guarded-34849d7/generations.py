import _io
import gc
import io
import os
import sys

def check(profile, opener, writer_type, reader_type, other_writer):
    output=opener('sample.bin','wb')
    print(profile, 'writer_class', type(output) is writer_type, isinstance(output, writer_type))
    print(profile, 'bound', output.write(b'a'))
    print(profile, 'unbound', writer_type.write(output, b'b'))
    try:
        other_writer.write(output,b'x')
    except TypeError:
        print(profile,'other rejected')
    else:
        print(profile,'other accepted')
    output.close()
    with opener('sample.bin','rb') as source:
        print(profile,'read',type(source) is reader_type,source.read())

first=_io
del sys.modules['_io']
import _io as second
old=io.open
new=second.open
WR1, WR2=first.BufferedWriter,second.BufferedWriter
RD1, RD2=first.BufferedReader,second.BufferedReader
print('classes differ',WR1 is not WR2,RD1 is not RD2)
print('opener receivers',old.__self__ is first,new.__self__ is second)
gc.collect()
check('old',old,WR1,RD1,WR2)
check('new',new,WR2,RD2,WR1)
os.unlink('sample.bin')
