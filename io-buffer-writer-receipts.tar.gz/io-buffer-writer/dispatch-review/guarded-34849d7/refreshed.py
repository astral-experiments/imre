import _io
import sys
del sys.modules['_io']
import _io as second

for label,mod in (('first',_io),('second',second)):
    w=mod.open('test.bin','wb')
    for n in (0,1):
        try:
            print(label,'readline',n,w.readline(n))
        except Exception as e:
            print(label,'readline',n,type(e).__name__,str(e))
    w.close()
