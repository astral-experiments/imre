"""Extract only the pinned input from the prior Ed25519-verified #3673 receipt."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = Path('/workspace/scratch/bw-six/module')
PACK = Path('/workspace/shared/downloads/io-buffer-binding-signed')
ARCHIVE = PACK/'io-buffer-binding-receipts.tar.gz'
def digest(data):
    return hashlib.sha256(data).hexdigest()
def openssl(*args):
    return subprocess.run(['openssl',*args],cwd=PACK,capture_output=True,check=True)
assert digest(openssl('pkey','-pubin','-in','signer-ed25519.pem','-outform','DER').stdout)=='6a012d499087c2b1f7c54707ca925c8e2e5d07d2d5025d94289254021db59ecc'
v=openssl('pkeyutl','-verify','-pubin','-inkey','signer-ed25519.pem','-rawin','-in','SHA256SUMS','-sigfile','SHA256SUMS.sig')
archive_digest=digest(ARCHIVE.read_bytes())
assert archive_digest=='bb351d4237125eb2e135a5e68244d228c2893323fcee0713ffdb5c5d9c0b1510'
manifest={line.split('  ',1)[1]:line[:64] for line in (PACK/'SHA256SUMS').read_text().splitlines()}
with tarfile.open(ARCHIVE) as archive:
    def read(name):
        m=archive.getmember('io-buffer-binding/'+name)
        assert m.isfile() and not m.issym()
        data=archive.extractfile(m).read()
        assert digest(data)==manifest[name]
        return data
    proof=json.loads(read('focused/reader/source-receipt.json'))
    original=json.loads(read('focused/generator/source-receipt.json'))
    order=read('focused/generator/ordered.ids').decode().splitlines()
    cases=original['case_ids_and_local_667_positions']
    assert len(order)==len(set(order))==667
    assert list(cases.values())==[603,604,605,626,627,628] and all(order[n-1]==s for s,n in cases.items())
    for rel,expected in proof['files'].items():
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts and rel.endswith('.py')
        data=read('focused/reader/module/'+rel)
        assert digest(data)==expected
        f=OUT/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
assert proof['files']['test/test_io.py']=='f9577855214be4c3d8819319d737a52ca34e513314d6ad86b3b4014aa1dcf54b'
assert proof['files']['run.py']=='398888d7f2439f6c386871ce2d270d7576a01b798e0351f518d779df75e1a338'
assert proof['files']['_pyio.py']=='1beee84c68ef6f7acb649dd5aada4c2f34f0476b01c293efe4afd9d0fe2d3ff1'
assert digest(Path('/workspace/scratch/cpython/Lib/test/test_io.py').read_bytes())==proof['upstream_sha256']
doc=dict(cpython=proof['cpython_commit'],source_upstream_sha256=proof['upstream_sha256'],files=proof['files'],
         signed_source_receipt_sha256=manifest['focused/reader/source-receipt.json'],source_archive=str(ARCHIVE),source_archive_sha256=archive_digest,
         signed_manifest_sha256=digest((PACK/'SHA256SUMS').read_bytes()),source_signature_verified=v.stdout.decode().strip(),
         pinned_signer_spki_sha256='6a012d499087c2b1f7c54707ca925c8e2e5d07d2d5025d94289254021db59ecc',
         ids=cases,ordered_ids_sha256=manifest['focused/generator/ordered.ids'],module_root=str(OUT))
(ROOT/'inputs.json').write_text(json.dumps(doc,indent=2)+'\n')
print('Verified signed prior archive; copied',len(proof['files']),'exact source files and verified all six IDs')
