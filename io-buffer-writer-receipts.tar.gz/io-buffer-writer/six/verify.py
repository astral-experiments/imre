"""Recheck each raw build/run and report fixture vs unittest outcomes."""
import argparse,hashlib,json,re
from pathlib import Path
root=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def digest(p):
    with p.open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()
def checked(c):
    for stream in ('stdout','stderr'):
        assert digest(root/c[stream])==c[stream+'_sha256']
    return ((root/c['stdout']).read_text(),(root/c['stderr']).read_text())
ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');a=ap.parse_args()
inputs=read(root/'inputs.json')
ids=inputs['ids']
assert list(ids.values())==[603,604,605,626,627,628]
for key,sha in inputs['files'].items():assert digest(Path(inputs['module_root'])/key)==sha
summaries=[]
for label in ['cpython','base','tested',*sorted(p.name for p in root.glob('guarded-*') if p.is_dir()),'public']:
    p=root/label/'provenance.json'
    if not p.exists():
        if a.partial:continue
        raise FileNotFoundError(p)
    prov=read(p); assert prov['label']==label and prov['inputs_sha256']==digest(root/'inputs.json') and prov['runner_sha256']==digest(root/('measure_guarded.py' if label.startswith('guarded-') else 'measure.py'))
    assert prov['source_sha256']==inputs['files']['test/test_io.py'] and prov['driver_sha256']==inputs['files']['run.py']
    if label!='cpython':
        b=Path(prov['bindir'])
        assert (b/'READY').read_text().strip()==prov['imre_commit']
        assert digest(b/'imre')==prov['compiler_sha256'] and digest(b/'libimre_runtime.a')==prov['runtime_sha256']
    lanes={q.parent.name for q in (root/label).glob('*/receipt.json')}
    if not a.partial:
        assert lanes==({'cpython-O0'} if label=='cpython' else {'ordinary-O0','boxed-O0','ordinary-O3','boxed-O3'}),(label,lanes)
    for lane in sorted(lanes):
        r=read(root/label/lane/'receipt.json'); assert r['label']==label and r['imre_commit']==prov['imre_commit'] and lane==r['mode']+'-O'+str(r['opt'])
        assert r['source_sha256']==prov['source_sha256'] and r['driver_sha256']==prov['driver_sha256']
        assert {c['selector']:c['local_occurrence'] for c in r['cases']}==ids and len(r['cases'])==6
        if label!='cpython':
            build=r['build'];so,se=checked(build);cmd=build['argv']
            assert (cmd[0],cmd[1],cmd[2])==(str(b/'imre'),'build',str(Path(inputs['module_root'])/'run.py'))
            assert cmd[cmd.index('--module-root')+1]==inputs['module_root'] and cmd[cmd.index('--runtime')+1]==str(b/'libimre_runtime.a') and cmd[cmd.index('--opt-level')+1]==str(r['opt'])
            assert '--no-cache' in cmd and ('--runtime-imports' in cmd)==(r['mode']=='boxed')
            if build['exit']==0: assert re.fullmatch('[0-9a-f]{64}',r['exe_sha256']) and r['process']['argv'][0]==cmd[cmd.index('-o')+1]
        case_results={c['selector']:c['verdict'] for c in r['cases']};proc=r['process']
        if proc:
            out,err=checked(proc); assert proc['argv'][-6:]==list(ids)
            selected=re.findall(r'^IMRE_GROUP_SELECTED (.+)$',out,re.M)
            emitted=dict(re.findall(r'^IMRE_GROUP_VERDICT (\S+) (PASS|SKIP|FAIL|ERROR)$',out,re.M))
            if selected:
                assert selected==list(ids) and emitted==case_results and re.search(r'^Ran 6 tests in ',out+'\n'+err,re.M)
                assert proc['exit']==int(any(v in ('ERROR','FAIL') for v in emitted.values()))
            else:
                assert not emitted and set(case_results.values())=={'UNREACHED'} and proc['exit']!=0
                if r['phase']=='load_tests error': assert 'IMRE_LOADER_ERROR Failed to call load_tests:' in out and 'in load_tests' in out and r['first_error'] in out
            assert re.findall(r'^IMRE_MISSING_EXPORT (\S+ \S+)$',out,re.M)==r['missing_exports']
        else:assert r['build']['exit']!=0 and set(case_results.values())<= {'BUILD_TIMEOUT','BUILD_ERROR'}
        summaries.append({k:r[k] for k in ('label','imre_commit','mode','opt','phase','first_error','missing_exports')}|{'build_exit':r['build']['exit'] if r['build'] else None,'process_exit':r['process']['exit'] if proc else None,'outcomes':case_results})
if not a.partial:
    (root/'verified.json').write_text(json.dumps(summaries,indent=2)+'\n')
    fields=['mode','opt','local_occurrence','original_id','method_verdict','phase','build_exit','process_exit','first_error','stdout','stderr']
    table=['\t'.join(fields)]
    for r in (r for r in summaries if r['label']=='public'):
        directory=root/'public'/f"{r['mode']}-O{r['opt']}"
        receipt=read(directory/'receipt.json');process=receipt['process']
        for name,status in r['outcomes'].items():
            table.append('\t'.join(str(v) for v in [r['mode'],r['opt'],ids[name],name,status,r['phase'],r['build_exit'],r['process_exit'],r['first_error'] or '',process['stdout'] if process else '',process['stderr'] if process else '']))
    assert len(table)==25
    (root/'public.tsv').write_text('\n'.join(table)+'\n')

for r in summaries:print(r['label'],r['mode'],r['opt'],r['build_exit'],r['process_exit'],r['phase'],r['first_error'],list(r['outcomes'].values()))
