# Six original MiscIO selectors

The grouped unittest runner, projected test_io module, complete real _pyio module and support modules are exact copies of the inputs in the signed #3673 packet. Preparation verifies its Ed25519 signature, archive digest, per-file hashes and original CPython order, then writes the pinned files into separate scratch space. The underlying CPython version is 3.14.5 at `5607950ef232dad16d75c0cf53101d9649d89115`. [Source proof](inputs.json) · [Preparation](prepare.py)

| Position in the local 667-ID suite | Original ID |
| --- | --- |
| 603 | `test.test_io.CMiscIOTest.test_abc_inheritance` |
| 604 | `test.test_io.CMiscIOTest.test_abc_inheritance_official` |
| 605 | `test.test_io.CMiscIOTest.test_abcs` |
| 626 | `test.test_io.PyMiscIOTest.test_abc_inheritance` |
| 627 | `test.test_io.PyMiscIOTest.test_abc_inheritance_official` |
| 628 | `test.test_io.PyMiscIOTest.test_abcs` |

The focused projection preserves the original case code, complete C and Py fixture mocks, per-class attributes, inherited lifecycle and teardown. In the original `load_tests`, its test-class tuple is restricted to the two retained classes. The following namespace construction and attachment are unchanged. The suite is loaded once with all six names in argv. A fixture error before selection is one failed shared process and yields no case verdicts. The four native configurations combine ordinary or `--runtime-imports` with `-O0` or `-O3`. [Original case definitions](https://github.com/python/cpython/blob/5607950ef232dad16d75c0cf53101d9649d89115/Lib/test/test_io.py#L4467-L4498) · [Original fixture](https://github.com/python/cpython/blob/5607950ef232dad16d75c0cf53101d9649d89115/Lib/test/test_io.py#L5075-L5111)

Each lane contains one receipt and raw build/process stdout and stderr. The provenance file identifies the exact binary, runtime and source hashes for its revision. `measure.py` uses fresh `--no-cache` builds. `python3 verify.py` rechecks the complete matrix and writes `verified.json`. All six passed their fresh CPython oracle run. [CPython output](cpython/cpython-O0/six.stdout) · [Runner](measure.py) · [Verifier](verify.py)
