"""Build and execute the signed #3673 six-case unittest projection."""
import argparse, concurrent.futures, datetime, hashlib, json, os, re, signal, subprocess, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SCRATCH=Path('/workspace/scratch/bw-six')
CPY=Path('/workspace/scratch/cpytools/bin/python3.14')
CLANG=Path('/workspace/scratch/tools/clang')
inputs=json.loads((ROOT/'inputs.json').read_text())
module=Path(inputs['module_root'])
ids=list(inputs['ids'])
def sha(p):
    with p.open('rb') as fh: return hashlib.file_digest(fh,'sha256').hexdigest()
def save(p,data):
    p.write_text(json.dumps(data,indent=2)+'\n')
def capture(args,folder,cwd,prefix):
    args=list(map(str,args)); env=os.environ.copy()
    for k in ('IMREFLAGS','IMRE_ENCODED_FLAGS','PYTHONPATH'):env.pop(k,None)
    env.update(TMPDIR=str(cwd),PYTHONDONTWRITEBYTECODE='1')
    start=datetime.datetime.now(datetime.timezone.utc).isoformat(); timer=time.monotonic()
    with subprocess.Popen(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True) as p:
        try:out,err=p.communicate(timeout=1800);status=p.returncode
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate();status=None
    so,se=folder/(prefix+'.stdout'),folder/(prefix+'.stderr')
    so.write_bytes(out);se.write_bytes(err)
    return dict(argv=args,cwd=str(cwd),utc_start=start,elapsed_s=round(time.monotonic()-timer,6),exit=status,
                stdout=str(so.relative_to(ROOT)),stderr=str(se.relative_to(ROOT)),stdout_sha256=sha(so),stderr_sha256=sha(se)),out.decode(errors='replace'),err.decode(errors='replace')
def originals(proc,out,err):
    names=re.findall(r'^IMRE_GROUP_SELECTED (.+)$',out,re.M)
    results=re.findall(r'^IMRE_GROUP_VERDICT (\S+) (PASS|SKIP|FAIL|ERROR)$',out,re.M)
    if not names:
        assert not results and proc['exit']!=0
        return {n:'UNREACHED' for n in ids}
    assert names==ids and len(results)==6 and [n for n,s in results]==ids
    assert re.search(r'^Ran 6 tests in ',out+'\n'+err,re.M)
    assert proc['exit']==int(any(s in ('FAIL','ERROR') for n,s in results))
    return dict(results)
ap=argparse.ArgumentParser();ap.add_argument('label',choices=['cpython','base','tested','public'])
ap.add_argument('--commit');ap.add_argument('--jobs',type=int,default=2)
ap.add_argument('--levels',nargs='+',type=int,choices=(0,3),default=[0,3]);ap.add_argument('--modes',nargs='+',choices=('ordinary','boxed'),default=['ordinary','boxed'])
o=ap.parse_args();native=o.label!='cpython';work=ROOT/o.label;work.mkdir(exist_ok=True)
assert len(ids)==6 and list(inputs['ids'].values())==[603,604,605,626,627,628]
for name,wanted in inputs['files'].items(): assert sha(module/name)==wanted,name
prov={'label':o.label,'imre_commit':o.commit,'cpython_commit':inputs['cpython'],'inputs_sha256':sha(ROOT/'inputs.json'),
      'runner_sha256':sha(Path(__file__)),'source_sha256':inputs['files']['test/test_io.py'],'driver_sha256':inputs['files']['run.py'],
      'env_overrides':{'TMPDIR':'each recorded cwd','PYTHONDONTWRITEBYTECODE':'1'},'env_removed':['IMREFLAGS','IMRE_ENCODED_FLAGS','PYTHONPATH']}
if native:
    b=Path('/workspace/scratch/bin-io-writer-'+o.label)
    assert o.commit and re.fullmatch('[0-9a-f]{40}',o.commit) and (b/'READY').read_text().strip()==o.commit
    prov.update(bindir=str(b),compiler_sha256=sha(b/'imre'),runtime_sha256=sha(b/'libimre_runtime.a'),clang=str(CLANG),clang_wrapper_sha256=sha(CLANG))
else: prov.update(reference_binary=str(CPY),reference_sha256=sha(CPY))
if (work/'provenance.json').exists(): assert json.loads((work/'provenance.json').read_text())==prov
else: save(work/'provenance.json',prov)
def lane(job):
    m,n=job;name=f'{m}-O{n}';folder=work/name;folder.mkdir(exist_ok=True)
    assert not (folder/'receipt.json').exists(),str(folder)
    cwd=SCRATCH/o.label/name;cwd.mkdir(parents=True,exist_ok=True)
    (cwd/'data.bin').write_bytes(b'abcdef')
    exe=cwd/'suite';exe.unlink(missing_ok=True)
    entry=module/'run.py';build=binary_hash=proc=None;out=err=''
    if native:
        cmd=[b/'imre','build',entry,'--module-root',module,'--no-cache','--runtime',b/'libimre_runtime.a','--clang',CLANG,'--opt-level',str(n),'-o',exe]
        if m=='boxed':cmd.append('--runtime-imports')
        build,_,_=capture(cmd,folder,cwd,'build')
        start=[exe] if build['exit']==0 else None
        if start:binary_hash=sha(exe)
    else: start=[CPY,'-I','-B','-c','import runpy,sys;sys.path.insert(0,sys.argv.pop(1));runpy.run_path(sys.argv.pop(1),run_name="__main__")',module,entry]
    try:
        if start:proc,out,err=capture(start+ids,folder,cwd,'six')
    finally:exe.unlink(missing_ok=True)
    if proc: results=originals(proc,out,err)
    else: results={i:'BUILD_TIMEOUT' if build['exit'] is None else 'BUILD_ERROR' for i in ids}
    exc=next((l for l in out.splitlines()+err.splitlines() if re.match(r'^(AttributeError|NameError|TypeError):',l)),None)
    missing=re.findall(r'^IMRE_MISSING_EXPORT (\S+ \S+)$',out,re.M)
    if proc and 'IMRE_LOADER_ERROR Failed to call load_tests:' in out: phase='load_tests error'
    elif proc and 'IMRE_GROUP_SELECTED ' in out: phase='unittest ran'
    elif proc: phase='before selection'
    else: phase='compile'
    save(folder/'receipt.json',dict(label=o.label,imre_commit=o.commit,mode=m,opt=n,build=build,process=proc,exe_sha256=binary_hash,
         source_sha256=prov['source_sha256'],driver_sha256=prov['driver_sha256'],cases=[dict(selector=i,local_occurrence=inputs['ids'][i],verdict=results[i]) for i in ids],
         phase=phase,first_error=exc,missing_exports=missing))
    print(o.label,name,phase,exc,missing,list(results.values()),flush=True)
    if not native: assert list(results.values())==['PASS']*6
jobs=[(m,n) for n in o.levels for m in o.modes] if native else [('cpython',0)]
with concurrent.futures.ThreadPoolExecutor(max_workers=o.jobs) as pool: list(pool.map(lane,jobs))
if native: assert sha(b/'imre')==prov['compiler_sha256'] and sha(b/'libimre_runtime.a')==prov['runtime_sha256']
